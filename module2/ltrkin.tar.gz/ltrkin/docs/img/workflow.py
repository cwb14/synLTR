#!/usr/bin/env python3
"""ltrkin workflow schematic for the README.

Writes next to this script: workflow.png (400 dpi, figure only), workflow.pdf (page 1 figure, page 2 short legend,
page 3 long legend) and workflow_numbers.tsv (every number quoted in the legends, with its source).
Schematic only: no data are read or drawn. Stand-alone: needs matplotlib only.
If ltrkin's src/ltrkin/constants.py and cli.py are found relative to this script (repository docs/img/, or the
benchmark tree), the legend numbers are checked against them and any mismatch is reported.

Usage: python workflow.py [-v]
"""
import argparse
import ast
import datetime
import glob
import math
import os
import re
import socket
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib import font_manager as fm  # noqa: E402
from matplotlib.backends.backend_pdf import PdfPages  # noqa: E402
from matplotlib.font_manager import FontProperties  # noqa: E402
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch, Polygon, Rectangle  # noqa: E402
from matplotlib.textpath import TextToPath  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
STEM = "workflow"

# ---------------------------------------------------------------------------------------------------- fonts
# matplotlib's font cache may not list system fonts: register Liberation Sans/Mono in-process if present,
# else fall back to Arial / DejaVu Sans (and Courier New / DejaVu Sans Mono for commands and file names).
for _d in ("/usr/share/fonts/truetype/liberation2", "/usr/share/fonts/truetype/liberation",
           "/usr/share/fonts/liberation-sans", "/usr/share/fonts/liberation", "/usr/local/share/fonts",
           os.path.expanduser("~/Library/Fonts"), "/Library/Fonts"):
    _fs = sorted(glob.glob(os.path.join(_d, "LiberationSans-*.ttf"))
                 + glob.glob(os.path.join(_d, "LiberationMono-*.ttf")))
    if any(f.endswith("LiberationSans-Regular.ttf") for f in _fs):
        for _f in _fs:
            fm.fontManager.addfont(_f)
        break
_NAMES = {f.name for f in fm.fontManager.ttflist}
SANS = next((n for n in ("Liberation Sans", "Arial", "DejaVu Sans") if n in _NAMES), "DejaVu Sans")
MONO = next((n for n in ("Liberation Mono", "Courier New", "DejaVu Sans Mono") if n in _NAMES), "DejaVu Sans Mono")
plt.rcParams.update({"font.family": SANS, "font.size": 8.5, "pdf.fonttype": 42, "ps.fonttype": 42,
                     "svg.fonttype": "none", "hatch.linewidth": 0.6, "axes.unicode_minus": False})

# ---------------------------------------------------------------------------------------------------- style
W, H = 180.0, 142.0                          # figure size, mm
INK = "#222222"
MUTED = "#5E5E5E"                            # secondary labels
# the tool's color system (bench/figures/fig1_ltrkin/fig1_ltrkin.py): same meanings
DARK = "#3C3C3C"                             # F (full) allele square
G1, G2, G3 = "#8C8C8C", "#BDBDBD", "#E4E4E4"  # context grays; G1 also reads of the first haplotype
GENEC = "#5A5A5A"                            # LTR blocks of an element
VERM, VERM_D, VERM_L = "#D55E00", "#8A3D00", "#ECB78C"   # E and new copies / their LTRs / S (solo LTR)
BLUE = "#0072B2"                             # second haplotype (its reads)
TSDC = "#111111"
LANE_FC, LANE_EC = "#F1F1F1", "#CFCFCF"      # command lanes
CARD_FC, CARD_EC = "#FFFFFF", "#D8D8D8"      # step cards
TRAY_FC, TRAY_EC = "#FFFFFF", "#CFCFCF"      # input / output file groups
ARROWC = "#9A9A9A"
READC = "#4A4A4A"                            # reads before phasing (haplotype unknown)
DNAC = "#8C8C8C"                             # flanking DNA (thin line)
TABC = "#2B2B2B"
FS_CMD, FS_TITLE, FS_LAB, FS_SM = 11.0, 10.5, 8.5, 8.0
ALLELE_FC = {"F": DARK, "S": VERM_L, "E": VERM, "N": "white"}
ALLELE_TC = {"F": "white", "S": INK, "E": "white", "N": INK}
LW_READ, LW_DNA = 1.8, 0.9                   # points


# ---------------------------------------------------------------------------------------------------- helpers
class Canvas:
    """One axes in mm over the whole figure (1 data unit = 1 mm), plus text measurement."""

    def __init__(self, fig):
        self.fig = fig
        self.ax = fig.add_axes([0, 0, 1, 1])
        self.ax.set_xlim(0, W)
        self.ax.set_ylim(0, H)
        self.ax.set_aspect("equal")
        self.ax.axis("off")
        self.r = fig.canvas.get_renderer()

    def width(self, t):
        bb = t.get_window_extent(self.r).transformed(self.ax.transData.inverted())
        return bb.x1 - bb.x0

    def measure(self, s, **kw):
        t = self.text(0, 0, s, **kw)
        w = self.width(t)
        t.remove()
        return w

    def text(self, x, y, s, **kw):
        kw.setdefault("fontsize", FS_LAB)
        kw.setdefault("color", INK)
        kw.setdefault("ha", "left")
        kw.setdefault("va", "center")
        return self.ax.text(x, y, s, **kw)


def rbox(ax, x0, y0, x1, y1, fc, ec, lw=0.6, r=1.8, z=0, ls="-"):
    ax.add_patch(FancyBboxPatch((x0, y0), x1 - x0, y1 - y0, boxstyle=f"round,pad=0,rounding_size={r}",
                                fc=fc, ec=ec, lw=lw, zorder=z, ls=ls))


def line(ax, xs, ys, color=G1, lw=1.0, z=2, **kw):
    kw.setdefault("solid_capstyle", "butt")
    ax.plot(xs, ys, color=color, lw=lw, zorder=z, **kw)


def arrow(ax, x0, y0, x1, y1, color=ARROWC, lw=1.2, ms=8, z=2, **kw):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=ms, color=color, lw=lw,
                                 shrinkA=0, shrinkB=0, zorder=z, **kw))


def badge(c, x, y, n, r=2.2):
    c.ax.add_patch(Circle((x, y), r, fc=TABC, ec="none", zorder=6))
    c.text(x, y, str(n), color="white", fontsize=FS_TITLE - 1, fontweight="bold", ha="center", zorder=7)


def step_head(c, x, y, n, title):
    badge(c, x + 2.2, y, n)
    c.text(x + 5.6, y, title, fontsize=FS_TITLE, fontweight="bold")


def cmd_tab(c, x, y, cmd):
    """Command name on a dark tab sitting on the lane's top edge (y)."""
    t = c.text(x + 2.4, y + 3.05, cmd, family=MONO, fontsize=FS_CMD, fontweight="bold", color="white", zorder=8)
    rbox(c.ax, x, y - 0.2, x + c.width(t) + 4.8, y + 6.1, fc=TABC, ec="none", r=1.5, z=7)


def doc_icon(ax, x, y, w=5.0, h=6.4, kind="text", z=4):
    """Document with a folded corner; lower-left at (x, y). kind: text | table | reads | element."""
    d = 1.5
    ax.add_patch(Polygon([(x, y), (x + w, y), (x + w, y + h - d), (x + w - d, y + h), (x, y + h)], closed=True,
                         fc="white", ec="#7A7A7A", lw=0.6, zorder=z))
    ax.add_patch(Polygon([(x + w - d, y + h), (x + w - d, y + h - d), (x + w, y + h - d)], closed=True,
                         fc="#D9D9D9", ec="#7A7A7A", lw=0.5, zorder=z + 0.1))
    if kind == "text":                       # sequence lines
        for k, f in enumerate((0.62, 0.75, 0.75, 0.5)):
            yy = y + h - 2.3 - k * 1.05
            line(ax, [x + 0.8, x + 0.8 + (w - 1.6) * f], [yy, yy], color="#BDBDBD", lw=0.55, z=z + 0.2)
    elif kind == "table":                    # tab-separated columns
        for k in range(4):
            yy = y + h - 2.3 - k * 1.05
            for a, b in ((0.8, 2.0), (2.4, 3.3), (3.7, w - 0.8)):
                line(ax, [x + a, x + b], [yy, yy], color="#BDBDBD", lw=0.55, z=z + 0.2)
    elif kind == "reads":                    # aligned long reads
        for k, (a, b) in enumerate(((0.7, 3.6), (1.4, 4.3), (0.7, 2.9), (1.9, 4.3))):
            yy = y + h - 2.3 - k * 1.05
            line(ax, [x + a, x + b], [yy, yy], color=G1, lw=0.8, z=z + 0.2, solid_capstyle="round")
    elif kind == "element":                  # an annotated element
        line(ax, [x + 0.4, x + w - 0.4], [y + h * 0.42] * 2, color=DNAC, lw=0.5, z=z + 0.15)
        element(ax, x + 0.8, x + w - 0.9, y + h * 0.42, 1.3, 0.7, z=z + 0.2)


def file_chip(c, x, y, name, kind="table", sub=None, stack=1):
    """Document icon(s) with the file name to the right; (x, y) = lower-left of the icon. Returns the right edge."""
    for k in reversed(range(stack)):
        doc_icon(c.ax, x + 1.1 * k, y - 0.9 * k, kind=kind, z=4 + 0.5 * (stack - k))
    xt = x + 5.0 + 1.1 * (stack - 1) + 1.6
    t = c.text(xt, y + 3.2 if sub is None else y + 4.3, name, family=MONO, fontsize=FS_SM, color=INK)
    right = xt + c.width(t)
    if sub:
        t2 = c.text(xt, y + 1.1, sub, fontsize=FS_SM, color=MUTED)
        right = max(right, xt + c.width(t2))
    return right


def chip_width(c, name, sub=None, stack=1):
    w = 5.0 + 1.1 * (stack - 1) + 1.6 + c.measure(name, family=MONO, fontsize=FS_SM)
    if sub:
        w = max(w, 5.0 + 1.1 * (stack - 1) + 1.6 + c.measure(sub, fontsize=FS_SM))
    return w


def tray(c, chips, x, y, gap=6.5, pad=1.9, right=None):
    """A row of file chips on a white rounded tray; chips = [(name, kind, sub, stack)]; (x, y) = lower-left of the
    first icon, or give `right` (tray right edge) to right-align. Returns (x0, x1, chip x positions)."""
    widths = [chip_width(c, n, sb, st) for n, _, sb, st in chips]
    if right is not None:
        x = right - pad - sum(widths) - gap * (len(chips) - 1)
    xs, xr = [], x
    for k, (name, kind, sub, stack) in enumerate(chips):
        xs.append(xr)
        file_chip(c, xr, y, name, kind=kind, sub=sub, stack=stack)
        xr += widths[k] + gap
    xr -= gap
    low = 0.9 if any(ch[3] > 1 for ch in chips) else 0.0
    rbox(c.ax, x - pad, y - pad - low, xr + pad, y + 6.4 + pad, TRAY_FC, TRAY_EC, lw=0.6, r=1.6, z=1)
    return x - pad, xr + pad, xs


def element(ax, x0, x1, yc, h, ltr, body=G2, ltrc=GENEC, z=3):
    """LTR retrotransposon as in fig1_ltrkin: body pointed at the 3' end, LTRs as darker end blocks."""
    tip = min(0.6 * h, 0.4 * (x1 - x0))
    y0, y1 = yc - h / 2, yc + h / 2
    ax.add_patch(Polygon([(x0, y0), (x1 - tip, y0), (x1, yc), (x1 - tip, y1), (x0, y1)], closed=True, fc=body,
                         ec="none", zorder=z))
    ax.add_patch(Rectangle((x0, y0), ltr, h, fc=ltrc, ec="none", zorder=z + 0.1))
    a = x1 - ltr
    ax.add_patch(Polygon([(a, y0), (x1 - tip, y0), (x1, yc), (x1 - tip, y1), (a, y1)], closed=True, fc=ltrc,
                         ec="none", zorder=z + 0.1))


def solo_ltr(ax, x0, x1, yc, h, color=GENEC, z=3):
    tip = min(0.6 * h, 0.4 * (x1 - x0))
    ax.add_patch(Polygon([(x0, yc - h / 2), (x1 - tip, yc - h / 2), (x1, yc), (x1 - tip, yc + h / 2),
                          (x0, yc + h / 2)], closed=True, fc=color, ec="none", zorder=z))


def tsd(ax, x0, yc, s=1.15, z=3.5):
    ax.add_patch(Rectangle((x0, yc - s / 2), s, s, fc=TSDC, ec="none", zorder=z))


def dna(ax, x0, x1, y, z=2):
    line(ax, [x0, x1], [y, y], color=DNAC, lw=LW_DNA, z=z)


def read(ax, x0, x1, y, color=READC, lw=LW_READ, z=3):
    ax.plot([x0, x1], [y, y], color=color, lw=lw, solid_capstyle="round", zorder=z)


def allele_sq(c, x, yc, a, s=3.2, letter=True, fs=FS_LAB, z=5):
    """One allele as a square in the colors of the genotype glyph: F dark, S light vermillion, E vermillion,
    N open. (x, yc) = left edge, vertical center."""
    if a == "N":
        c.ax.add_patch(Rectangle((x + 0.05 * s, yc - 0.45 * s), 0.9 * s, 0.9 * s, fc="white", ec=DARK,
                                 lw=0.7, zorder=z))
    else:
        c.ax.add_patch(Rectangle((x, yc - s / 2), s, s, fc=ALLELE_FC[a], ec="none", zorder=z))
    if letter:
        c.text(x + s / 2, yc, a, fontsize=fs, fontweight="bold", color=ALLELE_TC[a], ha="center", zorder=z + 1)


def gt_glyph(c, x, yc, gt, s=1.6, gap=0.25, letters=False, fs=FS_LAB):
    """Genotype as one square per haplotype (fig1_ltrkin call glyph). Returns the right edge."""
    for k, a in enumerate(gt.split("/")):
        allele_sq(c, x + k * (s + gap), yc, a, s=s, letter=letters, fs=fs)
    return x + len(gt.split("/")) * (s + gap) - gap


def hatch_band(ax, x0, x1, yc, h, z=2):
    ax.add_patch(Rectangle((x0, yc - h / 2), x1 - x0, h, fc="white", ec=G2, lw=0, hatch="//////", zorder=z))


# ---------------------------------------------------------------------------------------------------- steps
def draw_step1(c, x0, y0, x1, y1):
    """Read evidence: the four alleles a haplotype can carry, each with the reads that show it."""
    ax = c.ax
    rbox(ax, x0, y0, x1, y1, CARD_FC, CARD_EC, z=1)
    step_head(c, x0 + 2.0, y1 - 4.0, 1, "Read evidence")
    xc = x0 + 52.0                            # center of the site
    E2, LTR, FL, T, tg = 16.5, 5.0, 9.0, 1.15, 0.25   # half element, LTR, flank, TSD, TSD-element gap (mm)
    h = 3.0                                   # element height
    xa, xb = xc - E2, xc + E2
    left_end, right_end = xa - tg - T - FL, xb + tg + T + FL
    rows = {"F": y1 - 13.5, "S": y1 - 23.5, "E": y1 - 33.5, "N": y1 - 43.5}
    names = {"F": "full", "S": "solo LTR", "E": "empty site", "N": "missing"}
    rp = [2.75, 4.3, 5.85]                    # read offsets below the allele
    for a, y in rows.items():
        allele_sq(c, x0 + 3.0, y, a)
        c.text(x0 + 7.4, y, names[a], fontsize=FS_LAB)
    # F (the reference allele): full element between two TSDs; reads cross an element end into the internal
    # region, or span the whole site
    y = rows["F"]
    dna(ax, left_end, xa - tg - T, y)
    dna(ax, xb + tg + T, right_end, y)
    tsd(ax, xa - tg - T, y)
    tsd(ax, xb + tg, y)
    element(ax, xa, xb, y, h, LTR)
    read(ax, left_end + 1.0, xa + LTR + 6.5, y - rp[0])
    read(ax, xb - LTR - 6.0, right_end - 0.6, y - rp[1])
    read(ax, left_end + 3.0, right_end - 2.6, y - rp[2])
    # S: solo LTR between the two TSDs; reads span it
    y = rows["S"]
    s0, s1 = xc - LTR / 2, xc + LTR / 2
    dna(ax, s0 - tg - T - FL, s0 - tg - T, y)
    dna(ax, s1 + tg + T, s1 + tg + T + FL, y)
    tsd(ax, s0 - tg - T, y)
    tsd(ax, s1 + tg, y)
    solo_ltr(ax, s0, s1, y, h)
    read(ax, s0 - tg - T - FL + 0.8, s1 + tg + T + FL - 2.4, y - rp[0])
    read(ax, s0 - tg - T - FL + 2.6, s1 + tg + T + FL - 0.5, y - rp[1])
    # E: empty site, flanks joined at one TSD copy; reads span it
    y = rows["E"]
    e0, e1 = xc - T / 2, xc + T / 2
    dna(ax, e0 - FL, e0, y)
    dna(ax, e1, e1 + FL, y)
    tsd(ax, e0, y)
    read(ax, e0 - FL + 0.6, e1 + FL - 2.0, y - rp[0])
    read(ax, e0 - FL + 2.0, e1 + FL - 0.4, y - rp[1])
    # N: this haplotype lacks the site and its flanks (or they are rearranged): no read
    y = rows["N"]
    hatch_band(ax, left_end, right_end, y, h)
    # key to the glyphs
    ky = y0 + 3.4
    x = x0 + 4.0
    tsd(ax, x, ky)
    x += 2.1 + c.width(c.text(x + 2.1, ky, "TSD", fontsize=FS_SM, color=MUTED)) + 5.0
    ax.add_patch(Rectangle((x, ky - 1.5), 2.6, 3.0, fc=GENEC, ec="none", zorder=3))
    x += 3.6 + c.width(c.text(x + 3.6, ky, "LTR", fontsize=FS_SM, color=MUTED)) + 5.0
    dna(ax, x, x + 5.0, ky)
    x += 6.2 + c.width(c.text(x + 6.2, ky, "flank", fontsize=FS_SM, color=MUTED)) + 5.0
    read(ax, x + 0.4, x + 5.0, ky)
    c.text(x + 6.2, ky, "read", fontsize=FS_SM, color=MUTED)


def draw_step2(c, x0, y0, x1, y1):
    """Dosage: read phasing over the unique flanks, and read depth per haplotype."""
    ax = c.ax
    rbox(ax, x0, y0, x1, y1, CARD_FC, CARD_EC, z=1)
    step_head(c, x0 + 2.0, y1 - 4.0, 2, "Dosage")
    sub_y = y0 + 2.2
    # --- phasing: reads differ at heterozygous flank sites, so they form two groups; both groups carry the element
    px0, px1 = x0 + 3.5, x0 + 44.5
    ym = y1 - 9.0                                    # reference: element and its flanks
    ea, eb = px0 + 15.5, px0 + 25.5
    dna(ax, px0, ea, ym)
    dna(ax, eb, px1, ym)
    element(ax, ea, eb, ym, 2.4, 1.6)
    het = [px0 + 2.4, px0 + 6.6, px0 + 11.0, px1 - 11.2, px1 - 7.0, px1 - 2.8]
    reads = [(px0 + 0.6, ea + 4.2), (px0 + 3.2, px1 - 1.2), (eb - 3.8, px1 - 0.2)]
    ys = []
    for g, col in enumerate((G1, BLUE)):
        for k, (a, b) in enumerate(reads):
            yy = ym - 2.5 - (3 * g + k) * 1.42 - 0.6 * g
            sh = 1.0 * g
            ys.append(yy)
            read(ax, a + sh, b - sh * 0.5, yy, color=col, lw=1.6)
            if g == 1:                               # this group's bases differ from the reference
                for hx in het:
                    if a + sh + 0.5 <= hx <= b - sh * 0.5 - 0.5:
                        ax.add_patch(Rectangle((hx - 0.5, yy - 0.5), 1.0, 1.0, fc=INK, ec="none", zorder=4))
    for hx in het:                                   # heterozygous sites
        line(ax, [hx, hx], [ym - 1.4, min(ys) - 0.9], color=G3, lw=0.7, z=1.5)
    c.text((px0 + px1) / 2, sub_y, "phasing", fontsize=FS_SM, color=MUTED, ha="center")
    # --- depth: genome-wide mixture of 1 and 2 haplotype copies; sites with an empty allele mark one copy
    dx0, dx1 = x0 + 51.0, x1 - 3.0
    base = y0 + 8.0
    p1, p2 = dx0 + 7.0, dx0 + 18.5
    xs = [dx0 + i * (dx1 - dx0) / 200 for i in range(201)]

    def dens(x):
        return 6.6 * math.exp(-0.5 * ((x - p1) / 2.2) ** 2) + 4.9 * math.exp(-0.5 * ((x - p2) / 2.9) ** 2)
    yv = [base + dens(x) for x in xs]
    ax.fill_between(xs, base, yv, color=G3, lw=0, zorder=2)
    ax.plot(xs, yv, color=G1, lw=0.9, zorder=2.5)
    line(ax, [dx0, dx1], [base, base], color="#777777", lw=0.7)
    # haplotype copies under each peak: one, two
    line(ax, [p1 - 2.0, p1 + 2.0], [base - 1.6, base - 1.6], color=G1, lw=2.0, solid_capstyle="round")
    line(ax, [p2 - 2.0, p2 + 2.0], [base - 1.4, base - 1.4], color=G1, lw=2.0, solid_capstyle="round")
    line(ax, [p2 - 2.0, p2 + 2.0], [base - 2.7, base - 2.7], color=BLUE, lw=2.0, solid_capstyle="round")
    # calibration: sites with an empty or solo allele (e.g. F/E) have one full haplotype
    line(ax, [p1, p1], [base + 6.6, base + 7.9], color=DARK, lw=0.7, z=3)
    gt_glyph(c, p1 - 1.7, base + 8.9, "F/E", s=1.7, gap=0.0)
    c.text((dx0 + dx1) / 2, sub_y, "depth", fontsize=FS_SM, color=MUTED, ha="center")


def draw_step3(c, x0, y0, x1, y1):
    """Genotype: likelihood x prior learned from the sample -> genotype with GQ, and presence/absence."""
    ax = c.ax
    rbox(ax, x0, y0, x1, y1, CARD_FC, CARD_EC, z=1)
    step_head(c, x0 + 2.0, y1 - 4.0, 3, "Genotype")
    gts = ["F/F", "F/E", "F/S", "F/N"]
    base = y0 + 7.4
    sub_y = y0 + 2.2

    def bars(xl, heights, label):
        pitch, bw = 4.7, 2.9
        for k, (g, hgt) in enumerate(zip(gts, heights)):
            bx = xl + k * pitch
            ax.add_patch(Rectangle((bx, base), bw, hgt, fc=G1, ec="none", zorder=3))
            gt_glyph(c, bx + bw / 2 - 1.6, base - 1.7, g, s=1.5, gap=0.2)
        line(ax, [xl - 0.8, xl + 3 * pitch + bw + 0.8], [base, base], color="#777777", lw=0.7)
        c.text(xl + (3 * pitch + bw) / 2, sub_y, label, fontsize=FS_SM, color=MUTED, ha="center")
        return xl + 3 * pitch + bw
    # schematic heights, chosen so that likelihood x prior picks F/E (products 5.9, 18.2, 0.4, 3.2)
    xr = bars(x0 + 5.0, [0.9, 7.6, 0.6, 0.7], "likelihood")
    c.text(xr + 3.2, base + 3.8, "×", fontsize=FS_TITLE + 1, color=INK, ha="center")
    xr2 = bars(xr + 6.4, [6.6, 2.4, 0.6, 4.6], "prior")
    arrow(ax, xr2 + 2.2, base + 3.8, xr2 + 8.4, base + 3.8)
    gx = xr2 + 10.6
    gr = gt_glyph(c, gx, base + 5.2, "F/E", s=4.4, gap=0.0, letters=True, fs=FS_LAB)
    # GQ and pav: how sure the call is, and presence/absence
    tx = gx - 0.6
    for tag in ("GQ", "pav"):
        t = c.text(tx + 0.9, base - 0.9, tag, fontsize=FS_SM, color=INK, zorder=4)
        w = c.width(t)
        rbox(ax, tx, base - 2.6, tx + w + 1.8, base + 0.8, fc=G3, ec="none", r=0.8, z=3)
        tx += w + 1.8 + 1.4
    return gr


def draw_step4(c, x0, y0, x1, y1):
    """Source copy: each new copy -> nearest fixed copy of its family (internal-region divergence), with checks."""
    ax = c.ax
    rbox(ax, x0, y0, x1, y1, CARD_FC, CARD_EC, z=1)
    step_head(c, x0 + 2.0, y1 - 4.0, 4, "Source copy")
    yl = y1 - 9.6                                    # labels
    ye = yl - 4.0                                    # elements
    yr = y0 + 2.6                                    # divergence ruler
    CL, CLTR, CH = 7.0, 1.4, 2.8                     # every copy: length, LTR, height (a new copy copies its source)
    MS, MG = 1.5, 0.2                                # status markers: square and gap, as the step 3 genotype glyphs
    rx0 = x0 + 8.0
    nx1 = rx0 + CL
    # the checks take the right part, as wide as their labels; the ruler and its label end 4.5 mm before them
    labels = ["tie", "duplicated segment", "two parents", "same chromosome"]
    gw = [15.5, 20.0, 16.0, 18.0]                    # glyph widths
    cw = [max(g, c.measure(t, fontsize=FS_SM) + 3.0) for g, t in zip(gw, labels)]
    cx0 = x1 - 1.5 - sum(cw)
    r0 = (rx0 + nx1) / 2
    r1 = cx0 - 4.5 - 1.8 - c.measure("divergence", fontsize=FS_SM)

    def marked_label(xc, gt, text, min_x=None, **kw):
        """Status marker (genotype squares) then the label, centered on xc (but starting at min_x or later)."""
        wt = c.measure(text, fontsize=FS_LAB, **{k: v for k, v in kw.items() if k == "fontweight"})
        gx = xc - (2 * MS + MG + 1.0 + wt) / 2
        if min_x is not None:
            gx = max(gx, min_x)
        gx = gt_glyph(c, gx, yl, gt, s=MS, gap=MG)
        c.text(gx + 1.0, yl, text, fontsize=FS_LAB, **kw)
    # new copy (vermillion; F/E: an empty allele in some sample) and fixed copies (gray; F/F in every sample), placed
    # by their divergence from it; the nearest fixed copy is the source. Two farther copies if they fit, else one.
    element(ax, rx0, nx1, ye, CH, CLTR, body=VERM, ltrc=VERM_D)
    marked_label((rx0 + nx1) / 2, "F/E", "new copy", color=VERM_D)
    far = r1 - 9.5
    fixed = [rx0 + 19.5] + ([far - 9.0, far] if far - 9.0 >= rx0 + 19.5 + CL + 3.0 else [far])
    for fx in fixed:
        element(ax, fx, fx + CL, ye, CH, CLTR)
    c.text(fixed[0] + CL / 2, yl, "source", fontsize=FS_LAB, fontweight="bold", ha="center")
    src_end = fixed[0] + CL / 2 + c.measure("source", fontsize=FS_LAB, fontweight="bold") / 2
    marked_label((fixed[1] + fixed[-1] + CL) / 2, "F/F", "fixed", min_x=src_end + 2.5, color=MUTED)
    # ruler: divergence from the new copy
    line(ax, [r0, r1], [yr, yr], color="#777777", lw=0.7)
    line(ax, [r0, r0], [yr, yr + 1.0], color="#777777", lw=0.7)
    arrow(ax, r1 - 1.5, yr, r1 + 1.0, yr, color="#777777", lw=0.7, ms=5)
    c.text(r1 + 1.8, yr, "divergence", fontsize=FS_SM, color=MUTED)
    # copying: the source's RNA made the new copy
    ax.add_patch(FancyArrowPatch((fixed[0] + 2.0, ye - 1.7), (nx1 - 2.0, ye - 1.7),
                                 connectionstyle="arc3,rad=-0.33", arrowstyle="-|>", mutation_scale=7, color=VERM,
                                 lw=1.2, zorder=4))
    # --- checks
    line(ax, [cx0 - 2.0, cx0 - 2.0], [y0 + 2.0, y1 - 2.0], color=G3, lw=0.8)
    c.text(cx0 + 1.0, y1 - 4.0, "checks", fontsize=FS_SM, color=MUTED)
    mids = [cx0 + sum(cw[:k]) + cw[k] / 2 for k in range(4)]
    for m, lab in zip(mids, labels):
        c.text(m, y0 + 2.6, lab, fontsize=FS_SM, ha="center")
    gy = y0 + 10.2
    # tie: two fixed copies equally close
    m = mids[0]
    element(ax, m - 7.6, m - 2.2, gy, 2.2, 1.0, body=VERM, ltrc=VERM_D)
    for dy in (2.7, -2.7):
        line(ax, [m - 1.8, m + 2.0], [gy, gy + dy], color=G1, lw=0.9)
        element(ax, m + 2.3, m + 7.7, gy + dy, 2.2, 1.0)
    # duplicated segment: the new copy came with its flanks (flanks identical to the source's)
    m = mids[1]
    for dy, body, ltrc in ((2.7, G2, GENEC), (-2.7, VERM, VERM_D)):
        yy = gy + dy
        line(ax, [m - 9.5, m - 4.1], [yy, yy], color=DARK, lw=2.2)
        line(ax, [m + 4.1, m + 9.5], [yy, yy], color=DARK, lw=2.2)
        element(ax, m - 3.6, m + 3.6, yy, 2.2, 1.1, body=body, ltrc=ltrc)
    for xx in (m - 8.6, m - 6.8, m - 5.0, m + 5.0, m + 6.8, m + 8.6):
        line(ax, [xx, xx], [gy + 1.6, gy - 1.6], color=G1, lw=0.7, ls=(0, (1.2, 0.9)))
    # two parents: the new copy's internal region is a mosaic of two fixed copies
    m = mids[2]
    ax.add_patch(Rectangle((m - 7.0, gy + 2.1), 14.0, 1.5, fc=GENEC, ec="none", zorder=3))
    ax.add_patch(Rectangle((m - 7.0, gy - 3.6), 14.0, 1.5, fc=G2, ec="none", zorder=3))
    ax.add_patch(Rectangle((m - 7.0, gy - 0.75), 7.5, 1.5, fc=GENEC, ec="none", zorder=3))
    ax.add_patch(Rectangle((m + 0.5, gy - 0.75), 6.5, 1.5, fc=G2, ec="none", zorder=3))
    ax.add_patch(Rectangle((m - 7.0, gy - 0.75), 14.0, 1.5, fc="none", ec=VERM, lw=1.1, zorder=3.5))
    for xx in (m - 5.0, m - 1.5):
        line(ax, [xx, xx], [gy + 2.1, gy + 0.8], color=G1, lw=0.7, ls=(0, (1.2, 0.9)))
    for xx in (m + 2.5, m + 5.0):
        line(ax, [xx, xx], [gy - 2.1, gy - 0.8], color=G1, lw=0.7, ls=(0, (1.2, 0.9)))
    # same chromosome: the new copy on its source's chromosome
    m = mids[3]
    for dy in (2.5, -2.7):
        rbox(ax, m - 8.5, gy + dy - 0.95, m + 8.5, gy + dy + 0.95, fc=G3, ec=G1, lw=0.5, r=0.95, z=2)
    element(ax, m - 6.8, m - 2.6, gy + 2.5, 1.5, 0.7, z=3)
    element(ax, m + 2.6, m + 6.8, gy + 2.5, 1.5, 0.7, body=VERM, ltrc=VERM_D, z=3)
    ax.add_patch(FancyArrowPatch((m - 4.7, gy + 3.4), (m + 4.7, gy + 3.4), connectionstyle="arc3,rad=-0.5",
                                 arrowstyle="-|>", mutation_scale=6, color=VERM, lw=1.0, zorder=4))


def draw(fig):
    c = Canvas(fig)
    ax = c.ax
    A = 4.6                                           # length of the arrows between lanes and file trays
    TH = 6.4 + 2 * 1.9                                # tray height (icon + padding)
    # bottom-up: source outputs, lane 2, genotype outputs, lane 1, inputs
    yo2 = 1.1 + 1.9                                   # icon baseline of the source outputs
    L2 = (2.0, yo2 - 1.9 + TH + A, W - 2.0, yo2 - 1.9 + TH + A + 28.0)
    yo1 = L2[3] + A + 1.9
    L1 = (2.0, yo1 - 1.9 + TH + A, W - 2.0, yo1 - 1.9 + TH + A + 61.0)
    yi = L1[3] + A + 1.9 + 0.9
    # lane 1: ltrkin genotype; its inputs sit beside the command name, as on the command line
    rbox(ax, *L1, LANE_FC, LANE_EC, lw=0.7, r=2.5, z=0)
    cmd_tab(c, 6.0, L1[3], "ltrkin genotype")
    ix0, ix1, _ = tray(c, [("ref.fa", "text", None, 1), ("ltr_rts.gff3", "element", None, 1),
                           ("s1.bam  s2.bam  \u2026", "reads", "HiFi or ONT", 2)], 56.0, yi)
    xa = ix0 + 16.0                                   # lands above step 1
    arrow(ax, xa, yi - 1.9 - 0.9 - 0.2, xa, L1[3] + 0.2)
    S1 = (5.0, L1[1] + 3.0, 86.5, L1[3] - 5.0)
    S3 = (93.5, L1[1] + 3.0, 175.0, L1[1] + 25.5)
    S2 = (93.5, S3[3] + 4.5, 175.0, L1[3] - 5.0)
    draw_step1(c, *S1)
    draw_step2(c, *S2)
    draw_step3(c, *S3)
    yt = S1[3] - 4.0                                  # arrows join the step titles
    arrow(ax, S1[2] + 0.6, yt, S2[0] - 0.6, yt)
    arrow(ax, S3[0] + 41.0, S2[1] - 0.5, S3[0] + 41.0, S3[3] + 0.5)
    # genotype outputs; out.genotypes.tsv feeds ltrkin source
    ox0, ox1, oxs = tray(c, [("out.genotypes.tsv", "table", None, 1), ("out.vcf.gz", "table", None, 1)], 0, yo1,
                         gap=9.0, right=W - 4.0)
    arrow(ax, 0.5 * (ox0 + ox1), L1[1] - 0.2, 0.5 * (ox0 + ox1), yo1 - 1.9 + TH + 0.2)
    # lane 2: ltrkin source
    rbox(ax, *L2, LANE_FC, LANE_EC, lw=0.7, r=2.5, z=0)
    cmd_tab(c, 6.0, L2[3], "ltrkin source")
    arrow(ax, oxs[0] + 2.5, yo1 - 1.9 - 0.2, oxs[0] + 2.5, L2[3] + 0.2)
    S4 = (5.0, L2[1] + 3.0, 175.0, L2[3] - 4.0)
    draw_step4(c, *S4)
    # source outputs
    sx0, sx1, _ = tray(c, [("src.copies.tsv", "table", None, 1), ("src.sources.tsv", "table", None, 1),
                           ("src.locality.tsv", "table", None, 1)], 0, yo2, gap=9.0, right=W - 4.0)
    arrow(ax, 0.5 * (sx0 + sx1), L2[1] - 0.2, 0.5 * (sx0 + sx1), yo2 - 1.9 + TH + 0.2)
    top = yi + 6.4 + 1.9
    if top > H - 1.0:
        print(f"[{STEM}] warning: layout top {top:.1f} mm exceeds the figure height {H} mm", file=sys.stderr)
    return c


# ---------------------------------------------------------------------------------------------------- numbers
# Every number quoted in the legends: key -> (value, as written, source, constant or option checked)
NUMS = [
    ("min_mapq", 20, "20", "src/ltrkin/cli.py: --min-mapq default", "cli:min-mapq"),
    ("ploidy", 2, "2", "src/ltrkin/cli.py: --ploidy default", "cli:ploidy"),
    ("anchor_bp", 100, "100\u00a0bp", "src/ltrkin/constants.py: ANCHOR", "ANCHOR"),
    ("tau_abs_bp", 50, "50\u00a0bp", "src/ltrkin/constants.py: TAU_ABS", "TAU_ABS"),
    ("tau_rel", 0.03, "3%", "src/ltrkin/constants.py: TAU_REL", "TAU_REL"),
    ("junc_win_bp", 300, "300\u00a0bp", "src/ltrkin/constants.py: JUNC_WIN", "JUNC_WIN"),
    ("ph_flank_bp", 3000, "3\u00a0kb", "src/ltrkin/constants.py: PH_FLANK", "PH_FLANK"),
    ("ph_min_q", 20, "20", "src/ltrkin/constants.py: PH_MIN_Q", "PH_MIN_Q"),
    ("ph_min_dis", 2, "2", "src/ltrkin/constants.py: PH_MIN_DIS", "PH_MIN_DIS"),
    ("ph_dis_frac", 0.7, "70%", "src/ltrkin/phase.py: distinct = (dis >= min_dis) & (dis >= 0.7 * shared); "
     "docs/DESIGN.md (Read phasing)", "phase:dis_frac"),
    ("n_depth_points", 3000, "3,000", "src/ltrkin/constants.py: N_DEPTH_POINTS", "N_DEPTH_POINTS"),
    ("cal_min_sites", 30, "30", "src/ltrkin/constants.py: CAL_MIN_SITES", "CAL_MIN_SITES"),
    ("eb_min_per_class", 5, "5", "src/ltrkin/constants.py: EB_MIN_PER_CLASS", "EB_MIN_PER_CLASS"),
    ("gq_cap", 99, "99", "src/ltrkin/constants.py: GQ_CAP", "GQ_CAP"),
    ("pav_p", 0.99, "0.99", "src/ltrkin/constants.py: PAV_P", "PAV_P"),
    ("gq_status", 20, "20", "src/ltrkin/constants.py: GQ_STATUS", "GQ_STATUS"),
    ("min_internal_bp", 1000, "1\u00a0kb", "src/ltrkin/constants.py: MIN_INTERNAL", "MIN_INTERNAL"),
    ("tie_diffs", 0.5, "0.5", "src/ltrkin/constants.py: TIE_DIFFS", "TIE_DIFFS"),
    ("flank_bp", 500, "500\u00a0bp", "src/ltrkin/constants.py: FLANK", "FLANK"),
    ("flank_dup_id", 0.9, "90%", "src/ltrkin/constants.py: FLANK_DUP_ID", "FLANK_DUP_ID"),
    ("mosaic_gain", 3, "3", "src/ltrkin/constants.py: MOSAIC_GAIN", "MOSAIC_GAIN"),
    ("mosaic_alpha", 0.01, "0.01", "src/ltrkin/constants.py: MOSAIC_ALPHA", "MOSAIC_ALPHA"),
    ("n_genotypes_diploid", 10, "ten", "derived: multisets of 2 alleles from F, S, E, N; docs/DESIGN.md (Genotype "
     "prior: 5 sites per class = 50 for a diploid)", ""),
    ("bars_drawn", 4, "four", "schematic: genotypes drawn in step 3 (F/F, F/E, F/S, F/N)", ""),
    ("tsd_len", "4-6", "4–6\u00a0bp", "docs/DESIGN.md (Annotation boundary error: identical 4-6-mers); "
     "src/ltrkin/constants.py: DEFAULT_TSD comment", ""),
    ("glyph_ltr_kb", "0.4-1", "0.4–1\u00a0kb", "figures/SPEC.md Fig. W (glyph proportions of a typical element)", ""),
    ("glyph_int_kb", "4-10", "4–10\u00a0kb", "figures/SPEC.md Fig. W (glyph proportions of a typical element)", ""),
]
N = {k: t for k, _, t, _, _ in NUMS}
GE = "\u2265\u00a0"                             # "at least", kept on one line with its number


def find_repo():
    """ltrkin source tree relative to this script: <repo>/docs/img/ or <bench>/figures/workflow/."""
    for rel in (("..", ".."), ("..", "..", "..", "ltrkin")):
        root = os.path.normpath(os.path.join(HERE, *rel))
        if os.path.isfile(os.path.join(root, "src", "ltrkin", "constants.py")):
            return root
    return None


def check_numbers(verbose):
    """Compare the legend numbers with ltrkin's constants and CLI defaults, when the source tree is found."""
    root = find_repo()
    status = {}
    if root is None:
        return {k: "not checked (ltrkin source not found)" for k, *_ in NUMS}, None
    consts = {}
    tree = ast.parse(open(os.path.join(root, "src", "ltrkin", "constants.py")).read())
    for node in tree.body:
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant):
            for tgt in node.targets:
                if isinstance(tgt, ast.Name):
                    consts[tgt.id] = node.value.value
    cli = open(os.path.join(root, "src", "ltrkin", "cli.py")).read()
    for opt in ("min-mapq", "ploidy"):
        m = re.search(r'"--' + opt + r'".*?default=(\d+)', cli)
        if m:
            consts["cli:" + opt] = int(m.group(1))
    ph = os.path.join(root, "src", "ltrkin", "phase.py")
    if os.path.isfile(ph):
        m = re.search(r"dis >= ([0-9.]+) \* shared", open(ph).read())
        if m:
            consts["phase:dis_frac"] = float(m.group(1))
    bad = []
    for key, val, _, _, name in NUMS:
        if not name:
            status[key] = "fixed in text"
        elif name not in consts:
            status[key] = f"{name} not found"
            bad.append(key)
        elif consts[name] == val:
            status[key] = "matches"
        else:
            status[key] = f"MISMATCH: {name} = {consts[name]}"
            bad.append(key)
    if bad:
        print(f"[{STEM}] warning: legend numbers differ from ltrkin source: {', '.join(bad)}", file=sys.stderr)
    elif verbose:
        print(f"[{STEM}] legend numbers match {root}/src/ltrkin", file=sys.stderr)
    return status, root


def write_numbers(path, status):
    with open(path, "w") as f:
        f.write("key\tvalue\ttext\tsource\tcheck\n")
        for key, val, txt, src, _ in NUMS:
            f.write(f"{key}\t{val}\t{txt.replace(chr(160), ' ')}\t{src}\t{status.get(key, '')}\n")


# ---------------------------------------------------------------------------------------------------- legends
SHORT = [
    ("", "ltrkin reads which form of each annotated LTR retrotransposon every haplotype of a sample carries, from "
         "long reads anchored in the unique DNA around it, then traces each new insertion to its likely source "
         "copy. Recent transposition becomes a genotype."),
    ("1  Read evidence.", "Young copies are nearly identical inside, so only reads anchored in the unique DNA beside "
         "an element count. Reads across the site measure the allele's length; reads across an element end show "
         "the element. Alleles: full element (F), solo LTR left by recombination (S), empty site from before the "
         "insertion (E), nothing (N)."),
    ("2  Dosage.", "Reads are sorted by the small differences in the DNA beside the element: two distinct groups "
         "that both carry an allele put it on two haplotypes. Read depth, scaled to one haplotype at the sample's "
         "own sites with an empty or solo allele, tells one copy from two."),
    ("3  Genotype.", "The evidence is weighed against the genotype frequencies of the same sample, giving each "
         "element a genotype per sample (here F/E: a new insertion on one haplotype), its quality and a "
         "presence/absence call."),
    ("4  Source copy.", "Each new copy (an empty site in some sample) is matched to the most similar fixed copy of "
         "its family, its likely source. Checks flag ties, copies that arrived inside a duplicated segment rather "
         "than by insertion, copies with two parents, and whether new copies land on their source's chromosome "
         "more often than chance."),
]


def long_legend():
    return [
        ("", f"Element: an LTR retrotransposon of the annotation, an internal region between two long terminal "
             f"repeats (LTRs), flanked by the {N['tsd_len']} target-site duplication (TSD) made when it inserted. "
             f"Allele: what one haplotype carries at the element's reference position. Flank: the unique sequence "
             f"beside it. Reads: long reads aligned to the reference, mapping quality {GE}{N['min_mapq']}. "
             f"Colors: F dark gray, S light vermillion, E vermillion, N open; new copies vermillion; second "
             f"haplotype blue. Glyphs follow a typical element (LTR {N['glyph_ltr_kb']}, internal region "
             f"{N['glyph_int_kb']}), not to scale; nothing drawn is data."),
        ("Inputs.", "ref.fa, the reference assembly; ltr_rts.gff3, intact elements, each with two "
             "long_terminal_repeat features (from LTRquest, EDTA, LTR_retriever, LTRharvest or DANTE_LTR; family and "
             "clade are used when present); one sorted, indexed BAM per sample of PacBio HiFi or ONT reads aligned "
             "with minimap2. ltrkin source (optional) also reads the reference and the annotation (not drawn)."),
        ("1  Read evidence.", f"Young copies of a family are near-identical, so reads inside an element cannot be "
             f"placed; every read used is anchored in the flank. A spanning read covers {GE}{N['anchor_bp']} of "
             f"flank on both sides; its length change against the reference is matched to the full (none), solo "
             f"(internal region and one LTR removed, both TSDs kept) or empty allele (whole element removed, one TSD "
             f"copy left: the insertion is new), within the larger of {N['tau_abs_bp']} and {N['tau_rel']} of the "
             f"allele span. A junction read carries an element end and {GE}{N['anchor_bp']} of internal region "
             f"within {N['junc_win_bp']} of the LTR: the full element. Split reads at an empty site are recognized "
             f"from their clipped sequence. N (hatched): the haplotype gives no F, S or E read because the site and "
             f"its flanks are absent or rearranged; it shows only as missing depth (step 2)."),
        ("2  Dosage.", f"Phasing: reads are compared over {N['ph_flank_bp']} of flank on each side, on bases of "
             f"quality {GE}{N['ph_min_q']}, at heterozygous sites (vertical lines) linked to another such site; "
             f"black squares mark bases that differ from the reference. Two read groups are distinct when their "
             f"reads disagree at {GE}{N['ph_min_dis']} shared sites and at {GE}{N['ph_dis_frac']} of them; "
             f"the number of distinct groups carrying an allele is a lower bound on the haplotypes carrying it "
             f"(gray and blue: two). Identical haplotypes give one group, which is not counted as evidence of one "
             f"copy. Depth: one haplotype's depth is fitted at {N['n_depth_points']} random positions as a mixture "
             f"of one to ploidy copies (peaks), then recalibrated from the full reads at the sample's sites with an "
             f"empty or solo allele, whose number of full haplotypes is known (F/E marker; {GE}"
             f"{N['cal_min_sites']} sites)."),
        ("3  Genotype.", f"Each genotype (ploidy alleles from F, S, E and N; ploidy {N['ploidy']} by default) gets a "
             f"likelihood from the mix of F, S and E reads (each allele yields reads at a rate set by the sample's "
             f"read lengths; misclassification estimated from the sample), the total read count against the depth "
             f"(N yields none) and the phasing bound. The prior is the sample's genotype frequencies, learned over "
             f"all its sites (flat below {N['eb_min_per_class']} called sites per genotype). Bars: "
             f"{N['bars_drawn']} of the {N['n_genotypes_diploid']} diploid genotypes, labeled by their allele "
             f"squares; the product picks F/E. GQ: the phred-scaled chance that the call is wrong (capped at "
             f"{N['gq_cap']}). pav: present, absent or solo at an allele posterior {GE}{N['pav_p']}, else "
             f"uncertain. Sites with only ambiguously mapped reads are no-calls. Outputs: out.genotypes.tsv (read "
             f"counts, haplotypes per allele, genotype, GQ, posteriors, pav, flags), out.vcf.gz."),
        ("4  Source copy.", f"From calls with GQ {GE}{N['gq_status']}: new = an empty allele in at least one "
             f"sample (vermillion, F/E); fixed = full on every haplotype of every called sample (gray, F/F). The "
             f"internal region of each new copy ({GE}{N['min_internal_bp']}, nested elements removed) is aligned "
             f"to those of every fixed copy of its family; the least divergent is its likely source (arc), and "
             f"copies within {N['tie_diffs']} differences tie and share the weight. Checks: tie; duplicated segment "
             f"(same TSD as the source, or {N['flank_bp']} flanks {GE}{N['flank_dup_id']} identical: copied "
             f"with its surroundings, not inserted; left out of the locality test); two parents (one-breakpoint "
             f"scan, family-wise error {N['mosaic_alpha']}, {GE}{N['mosaic_gain']} more differences explained "
             f"than by one source); same chromosome (share of new copies on their source's chromosome, against each "
             f"chromosome's share of the genome and a permutation keeping source clusters). Outputs: "
             f"src.copies.tsv, src.sources.tsv (also ages, shared derived mutations), src.locality.tsv."),
        ("Limits.", "Only insertions present in the reference are genotyped. N cannot tell a missing site from a "
             "rearranged one. The nearest fixed copy is a proxy for the parent, which may be unsampled, lost or "
             "itself polymorphic."),
    ]


def text_page(pdf, paras, footer=None, fs=10.0):
    """One legend page as wide as the figure, height fitted to the text. Each paragraph: a bold run-in head, then
    the body, wrapped by width. Widths are unhinted font metrics (as the PDF backend sets the text), so a line
    placed after a head lands one space after it. Text stays text (fonttype 42)."""
    margin = 6.0 / 25.4                       # inches
    width_in = W / 25.4
    avail = (width_in - 2 * margin) * 72      # points
    t2p = TextToPath()
    fp_n = FontProperties(family=SANS, size=fs)
    fp_b = FontProperties(family=SANS, size=fs, weight="bold")

    def wpt(s, fp):
        return t2p.get_text_width_height_descent(s, fp, ismath=False)[0]
    sp = wpt("a a", fp_n) - wpt("aa", fp_n)
    blocks = []                               # paragraphs; each a list of lines (head or None, text)
    for head, body in paras + ([("", footer)] if footer else []):
        lines, cur, first = [], [], True
        x = (wpt(head, fp_b) + sp) if head else 0.0
        for w_ in [t for t in body.split(" ") if t]:
            ww = wpt(w_, fp_n)
            need = ww if not cur else sp + ww
            if cur and x + need > avail:
                lines.append(((head if first else None), " ".join(cur)))
                first, cur, x = False, [w_], ww
            else:
                cur.append(w_)
                x += need
        lines.append(((head if first else None), " ".join(cur)))
        blocks.append(lines)
    lh = fs * 1.30 / 72                        # inches per line
    gap = fs * 0.55 / 72
    n = sum(len(b) for b in blocks)
    hgt = 2 * margin * 0.8 + n * lh + gap * (len(blocks) - 1)
    fig = plt.figure(figsize=(width_in, hgt))
    y = 1 - (margin * 0.8) / hgt
    for b in blocks:
        for head, txt in b:
            x = margin / width_in
            if head:
                fig.text(x, y, head, fontsize=fs, fontweight="bold", va="top", ha="left", color=INK)
                x += (wpt(head, fp_b) + sp) / 72 / width_in
            fig.text(x, y, txt, fontsize=fs, va="top", ha="left", color=INK)
            y -= lh / hgt
        y -= gap / hgt
    pdf.savefig(fig)
    plt.close(fig)


# ---------------------------------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0],
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-v", "--verbose", action="store_true", help="print the outputs and the number check")
    a = ap.parse_args()
    status, _ = check_numbers(a.verbose)
    fig = plt.figure(figsize=(W / 25.4, H / 25.4))
    draw(fig)
    png = os.path.join(HERE, f"{STEM}.png")
    pdf_path = os.path.join(HERE, f"{STEM}.pdf")
    fig.savefig(png, dpi=400)
    script = os.path.abspath(__file__)
    foot = (f"Analysis: {socket.gethostname()}:{HERE} · Script: {script} · "
            f"{datetime.date.today().isoformat()}")
    with PdfPages(pdf_path) as pdf:
        pdf.savefig(fig)
        text_page(pdf, SHORT)
        text_page(pdf, long_legend(), footer=foot)
    plt.close(fig)
    tsv = os.path.join(HERE, f"{STEM}_numbers.tsv")
    write_numbers(tsv, status)
    if a.verbose:
        for p in (png, pdf_path, tsv):
            print(f"[{STEM}] wrote {p}", file=sys.stderr)


if __name__ == "__main__":
    main()
