"""Polyploid genotyping (--ploidy 4) on a synthetic autotetraploid with planted allele dosages."""
import csv
import os
import random
import subprocess

import pytest

from ltrkin.cli import main

from synth import rand_seq, make_family, make_copy, build_hap, write_gff, simulate_reads, mutate

DOSES = {  # element -> allele on haplotypes h1..h4 (h1 is the reference)
    "D4F": "FFFF", "D3F1E": "FFFE", "D2F2E": "FFEE", "D1F3E": "FEEE", "D2F2S": "FFSS", "D3F1N": "FFFN"}


@pytest.fixture(scope="module")
def tetra(tmp_path_factory):
    d = tmp_path_factory.mktemp("tetra")
    rng = random.Random(9)
    fam = make_family(rng, 450, 4500)
    A = rand_seq(rng, 40000 * len(DOSES) + 20000)
    ev = []
    for k, (eid, st) in enumerate(DOSES.items()):
        p = 20000 + 40000 * k
        e = dict(id=eid, p=p, copy=make_copy(rng, fam, 0.003), fam="f",
                 state={f"h{i + 1}": ("X" if a == "N" else a) for i, a in enumerate(st)})
        if "N" in st:
            e["xdel"] = (p - 8000, p + 14000)
        ev.append(e)
    ann = []
    haps = {}
    for i in range(4):
        h = build_hap(A, ev, f"h{i + 1}", ann if i == 0 else None, "chr1")
        haps[f"h{i + 1}"] = h if i == 0 else mutate(random.Random(100 + i), h, 0.004)   # 4 distinct haplotypes
    ref = d / "ref.fa"
    ref.write_text(">chr1\n" + haps["h1"] + "\n")
    write_gff(d / "el.gff3", ann)
    fq = d / "reads.fq"
    with open(fq, "w") as fh:
        for name, h in haps.items():
            simulate_reads(rng, {"chr1": h}, 10, 12000, 0.005, fh, name)
    bam = d / "reads.bam"
    subprocess.run(f"minimap2 -ax map-hifi -t 4 {ref} {fq} 2>/dev/null | samtools sort -o {bam} - 2>/dev/null && "
                   f"samtools index {bam}", shell=True, check=True)
    out = str(d / "p4")
    main(["genotype", "-r", str(ref), "-a", str(d / "el.gff3"), "-o", out, "-t", "2", "--ploidy", "4", str(bam)])
    return {r["element_id"]: r for r in csv.DictReader(open(out + ".genotypes.tsv"), delimiter="\t")}


def test_tetraploid_dosage(tetra):
    for eid, st in DOSES.items():
        r = tetra[eid]
        want = "/".join(sorted(st, key="FSEN".index))
        if "N" in st:      # a missing haplotype rests on depth: only its presence of E/S matters
            assert "E" not in r["genotype"] and "S" not in r["genotype"], (eid, r["genotype"])
            continue
        assert r["genotype"] == want, (eid, r["genotype"], r["gq"], r["n_F"], r["n_E"], r["n_S"], r["hap_F"])


def test_tetraploid_pav(tetra):
    assert tetra["D1F3E"]["pav"] == "present" and float(tetra["D1F3E"]["p_E"]) > 0.99
    assert tetra["D2F2S"]["pav"] == "present" and float(tetra["D2F2S"]["p_S"]) > 0.99
