### Task 14: Classifier

**Files:** Create `src/ltrpav/classify.py`, `tests/test_classify.py`; Modify `docs/DESIGN.md` (5.4: the TSD
allowance with d, builder call 4)

**Interfaces:**
- Consumes: `Window`, `AlnMap`, `refine_gap`, `Element`, `n_runs`, constants.
- Produces:

```python
STATES = ("P", "S", "T", "E", "D", "O", "G", "U")
@dataclass
class Call:
    eid: str; state: str; tier: str; flags: list[str]     # tier "high" | "medium" | "low" | "." (G, U)
    b_seqid: str | None; b_start: int | None; b_end: int | None; b_strand: str | None   # genome coords, 1-based
    ev: dict[str, float | int | str]                      # keys = CALL_COLUMNS evidence names
CALL_COLUMNS = ("eid", "a_seqid", "a_start", "a_end", "parent", "level", "state", "tier", "flags", "reason",
    "b_seqid", "b_start", "b_end", "b_strand", "wid", "cov_left", "cov_right", "cov_int", "cov_elem", "dl", "dr",
    "b_ins", "tsd_a", "tsd_b", "tsd_mm", "ident", "anchor_left", "anchor_right", "margin")
# reason: U cause (window status, "flank_unaligned", "inv_site") or "."
def classify_window(win: Window, aln: AlnMap | None, a_seq: str, b_seq: str,
                    elements: dict[str, Element], children: dict[str, list[str]]) -> list[Call]
def call_row(call: Call, e: Element, win: Window) -> dict    # one CALL_COLUMNS row
```

- [ ] **Step 1: Write the failing tests.** One test per `toy.case` (table in Task 12). A test helper `run_case(c)`
  runs `classify_window(win, align_window(c.a, c.b), c.a, c.b, {e.eid: e for e in c.elements}, children)`, with
  `win = Window(wid=0, a_seqid="a", a_start=0, a_end=len(c.a), b_seqid="b", b_start=0, b_end=len(c.b), strand=1, eids=<top-level eids>, status="ok", anchor_left=0, anchor_right=0, margin=1.0)`.

```python
@pytest.mark.parametrize("name", toy.CASES)
def test_case_state(name):
    c = toy.case(name, random.Random(7)); calls = {x.eid: x for x in run_case(c)}
    for eid, state in c.expect.items():
        assert calls[eid].state == state, (name, eid)
def test_flags_and_tiers():               # every flag, tier and reason in the Task 12 table's "expected" column
def test_window_status_propagates():      # status "breakpoint": every element and descendant U, reason "breakpoint"
def test_minus_strand_window_flags_inv(): # case E with B reverse-complemented and strand=-1: E + "inv", B coords flipped
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.** Rules are fixed here. Notation: `L = len(e.tsd) or TSD_DEFAULT`, `w = SLOP_TSD_MULT*L`;
  the parts (left LTR, internal, right LTR, whole) exclude the spans of `e`'s annotated descendants; `ident` =
  `aln.identity(s-1000, t+1000)`.

```
visit elements outermost-first (level order) within the window
0 inheritance: parent E -> E + host_empty; parent D/O/G/U -> same state + inherit (tier copied); parent P/S/T -> go on
1 if win.status != "ok" or aln is None: U (reason = status)
2 g = aln.gap_around(midpoint of e); no segment on a side -> U "flank_unaligned"
3 an inverted hit overlapping [s-w, t+w) -> U "inv_site"
4 B region between the flanking segments' images, widened by REFINE_PAD each side, contains N -> G
5 aligned element bp < MIN_SEG -> absent branch:
     g = refine_gap(...); b_ins = g.b1-g.b0; dl = s-g.a0; dr = g.a1-t
     overhang on a side is "explained" if other annotated elements (not ancestors of e, inside the gap), each
       widened by its own L, cover all but <= w of it -> treat that side as within w, flag adjacent
     b_ins >= MIN_SEG -> O
     elif dl <= w and dr <= w:  E if b_ins <= w (read TSD) else O (flag small_ins)
     else -> D (flag filler if b_ins > w)
6 else present branch:
     cov_left, cov_right, cov_elem >= COV_PRESENT -> P (+ nestB if aln.b_gaps_within(s, t) has one >= MIN_SEG)
     elif internal aligned bp < max(MIN_SEG, (1-COV_PRESENT)*len(internal)) and
          SOLO_LEN[0]*mean_ltr <= ltr aligned bp <= SOLO_LEN[1]*mean_ltr -> S (+ solo_tsd if both A TSD copies have
          >= L-1 bases aligned)
     else -> T
TSD read (E): B copy = b[g.b1 : g.b1+L] if g.a0 <= s - L/2 else b[g.b0-L : g.b0];
     tsd_mm = min Hamming(B copy, A[s-L:s]), Hamming(B copy, A[t:t+L]);
     tsd_match if tsd_mm <= max(1, floor(L*((e.k or 0) + (1-ident)) + 0.5))
tier: placement = win.margin >= MARGIN_HIGH and ident >= IDENT_MIN;
     evidence = P: true | S: solo_tsd | E: tsd_match | D: refined | T, O: false
     high if both, medium if one, low if neither; G and U get "."
B coords: window -> genome (strand -1: b = win.b_end - 1 - local); 1-based. P/S/T: image of the aligned element;
     E: the B TSD copy; D: last aligned B base before and first after; O: the B insertion; G/U: None
flag inv on every call from a strand -1 window (site inside an inverted block)
```

- [ ] **Step 4: Run.** Expected: PASS (all cases exact).
- [ ] **Step 5: Commit** `"Add state classifier with nested hierarchy"`.

---

