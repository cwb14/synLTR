# Task 16 report: pair genotyping orchestration (`genotype.py`)

> **Update:** unblocked by the controller's rulings. Now **DONE**: `c577e18` (window aligner flags), `9997549` (Task 16), `eb0b82e` (inverted hits count only at the site); review fix round 1: `92229c4` (strand-split window mapping, replacing `-P`) and `e0b7236` (fail fast on worker failure); fix round 2: `f9a4558` (workers exit when the parent dies). See the fix reports at the end.

**Status: BLOCKED.** The orchestration is implemented and verified. 8 of the 12 new tests pass. The other 4
fail because the toy elements `T.e` and `O.e` come out `U flank_unaligned` through the full pipeline (and
`inv_site.e` gets the right state, U, with the wrong reason, `flank_unaligned` instead of `inv_site`).

The cause is in an earlier module: the window aligner `localign._align_mappy` (Task 12), working on windows
that carry only `WINDOW_PAD` (500 bp) of flank (Task 11). Per the brief I stopped rather than patch around it.
**Nothing is committed** (the suite is red); every change is in the working tree on `plan1-engine`.

I tested a 1-line fix in `localign._align_mappy` with a throwaway pytest plugin; the repo was not changed. The
fix adds two minimap2 flags, `MM_F_NO_LJOIN | MM_F_ALL_CHAINS`. With it, all 12 genotype tests pass and the
full suite passes (456 tests), on 7 seeds with 0 misses in state, flags, tier and U reason.

## What I implemented

`src/ltrpav/genotype.py`: `genotype_pair(ctx, route, backend="mappy") -> Path`, plus `tsv_field` and
`WINDOW_COLUMNS`.

**Order of steps:**
1. Validate the elements first (duplicate eid, or a seqid absent from A, raises `ValueError` before any
   anchoring).
2. `anchor_pair`.
3. `preset_for_divergence(d)` (nan gives asm20).
4. Compute the pair key. If the pair is done, log "skip" and return.
5. `make_windows(ctx.a_elements, blocks, a_names, b_names, b_lengths=ctx.b_fa.lengths(),
   a_lengths=ctx.a_fa.lengths())`, then write the windows file.
6. Cut the windows (in A fai order) into chunks of `CHUNK_WINDOWS`. Each chunk has a key and a marker; only
   unfinished chunks are run.
7. With `threads == 1`, run in-process on the parent's `Fasta` handles. Otherwise use
   `multiprocessing.get_context("fork").Pool(min(threads, jobs))` with an initializer that opens both `Fasta`
   objects in each worker (same path and `cache_dir`). The elements dict and the children map (eid to child
   eids, A order) reach the workers through the fork, without pickling.

**Per window:** for an ok window, fetch A and B, reverse-complement B when `strand == -1`, and call
`align_window(a, b, preset, backend)`. For a non-ok window, A and B are `""` and the alignment is `None`. Then
`classify_window` and `call_row`. Each chunk is sorted and written, then marked done.

**Pair file:** a k-way merge (`heapq.merge`) of the sorted chunks plus the rows of elements in no window.
- An element in no window (it is not top-level and its parent is not annotated) gets U `no_anchor`, made by
  `classify_window` on an unresolved one-element window, with wid ".".
- Each element must appear exactly once. This is checked before the temp file is renamed into place, so the
  pair file never exists when the check fails. On failure the chunk markers are cleared (a rerun recomputes
  them) and a `RuntimeError` names the missing, duplicated or unknown eids.
- Then the pair is marked done.

**Outputs (gzip TSV, mtime 0, no file name in the header):**
- `ctx.outdir/pairs/<A>__<B>.calls.tsv.gz`, plus its `.done.json`. Header is `CALL_COLUMNS`; rows sorted by
  (A fai order, a_start, -a_end, level).
- `ctx.workdir/windows/<A>__<B>.tsv.gz`. Columns: `wid a_seqid a_start a_end b_seqid b_start b_end strand
  status anchor_left anchor_right margin eids`. 1-based inclusive; strand is +/-/.; eids are comma-joined.
- `ctx.workdir/calls/<A>__<B>/chunk_<n>.tsv.gz`, each with its `.done.json`.

**TSV formatting (ruling 4):** None and nan give "."; bool gives 1/0; float uses `format(x, ".6g")`; int and
str are written as they are. numpy scalars are handled.

**Logging:**
- One INFO milestone per pair, e.g. `A vs B: 20 windows (20 anchored), 1 chunk(s) (1 computed), 25 calls
  (3 P, 3 S, 9 E, 3 D, 4 G, 3 U) -> .../A__B.calls.tsv.gz, 0.3 s`.
- On a finished pair, INFO `calls done, skip (...)`.
- A WARNING when more than `U_WARN` (0.99) of the calls are U: `...: 25 of 25 calls are U: no orthologous
  alignment between A and B?`. Per-chunk lines are DEBUG.

**Small supporting changes to earlier modules (no behavior change):**
- `seqio.Fasta` keeps `cache_dir`, so a worker reopens the FASTA exactly as the parent did.
- `anchor.anchors_path(ctx, route)` is now the single source of the npz path; `anchor_pair` uses it.
- `_elements_digest` moved from `anchor/__init__.py` to `elements.elements_digest`; anchor imports it (same
  digest, so the same cache keys).
- `constants.U_WARN = 0.99` (thresholds live in constants.py).

## Blocking issue: the window aligner loses a flank in WINDOW_PAD windows (earlier module)

### Per element, toy end-to-end run (seed 7, `get_route("mm2")`, threads 2, d = 0.00073, preset asm5)

| element | expected | called (current mappy backend) | called (no-long-join + all-chains) |
|---|---|---|---|
| P.e | P  | P high | P high |
| P_nestB.e | P +nestB | P high [nestB] | P high [nestB] |
| S.e | S +solo_tsd | S high [solo_tsd] | S high [solo_tsd] |
| S_notsd.e | S -solo_tsd | S medium | S medium |
| T.e | T  | U . (flank_unaligned) **MISS** | T medium |
| E.e | E +tsd_match high | E high [tsd_match] | E high [tsd_match] |
| E_mm1.e | E +tsd_match | E high [tsd_match] | E high [tsd_match] |
| E_mm2.e | E -tsd_match medium | E medium | E medium |
| D_left.e | D  | D high | D high |
| D_both.e | D  | D high | D high |
| O.e | O  | U . (flank_unaligned) **MISS** | O medium |
| G.e | G  | G . | G . |
| G_near.e | G  | G . | G . |
| G_far.e | E  | E high [tsd_match] | E high [tsd_match] |
| inv_site.e | U (inv_site) | U . (flank_unaligned) **MISS** (reason) | U . (inv_site) |
| nested_E.h | P  | P high | P high |
| nested_E.c | E  | E high [tsd_match] | E high [tsd_match] |
| host_E.h | E  | E high [tsd_match] | E high [tsd_match] |
| host_E.c | E +host_empty | E high [host_empty] | E high [host_empty] |
| host_S.h | S  | S high [solo_tsd] | S high [solo_tsd] |
| host_S.c | D  | D medium | D medium |
| host_G.h | G  | G . | G . |
| host_G.c | G +inherit | G . [inherit] | G . [inherit] |
| adjacent_E.e1 | E +adjacent | E high [adjacent,tsd_match] | E high [adjacent,tsd_match] |
| adjacent_E.e2 | E +adjacent | E high [adjacent,tsd_match] | E high [adjacent,tsd_match] |

The same three misses appear with every seed the classifier tests use (7, 0, 4, 6, 9, 11, 14) and in the
lowercase, minus-strand and decoy variants. With the two flags there are 0 misses everywhere.

### Mechanism (measured on the pipeline's own windows)

`make_windows` keeps 500 bp of anchored flank at each window end (`WINDOW_PAD`); the windows are element +
2 x 500 bp. The classifier tests (Task 13) aligned whole toy cases, with 3-kb flanks, so this never showed.

**T and O: long join.** minimap2's asm presets join chains across long gaps (`-r1k,100k`, long join). The
left- and right-flank chains get joined across the element-sized indel. The base-level extension then Z-drops
at the indel, and everything past it is lost. mappy returns one hit:
- T: A[0,2500) -> B[0,2500) only; the right LTR + right flank, A[4900,5800) -> B[2500,3400), is missing.
- O: one 500-bp flank only.

Rule 2 then calls U flank_unaligned, correctly given that alignment.

**inv_site: secondary filtering.** The plus-strand flank chain (500 + 500 bp) is dropped as a weak secondary
under the 4.8-kb inverted hit, so no flank is aligned and rule 2 fires before rule 4a (inv_site).

**Flag experiments** (mappy 2.31, asm20, best_n 5, extra_flags):

| window | as is | NO_LJOIN (0x400) | ALL_CHAINS (0x800000, `-P`) | both | pad +500 | pad +1000 | pad +2500 |
|---|---|---|---|---|---|---|---|
| T.e | U | **T** | U | **T** | T | T | T |
| O.e | U | **O** | U | **O** | U | O | O |
| inv_site.e | U flank_unaligned | U flank_unaligned | **U inv_site** | **U inv_site** | U flank_unaligned | U flank_unaligned | U inv_site |

The preset does not matter: asm5, asm10 and asm20 give the same hits. A wider pad only partly helps (only 3-kb
flanks fix all three). It does not remove the mechanism: an inverted element more than about 2x the flank
length loses its flanks again. The flags address the mechanism. `alnmap_from_hits` already chains the
plus-strand hits itself (`_chain`, collinear, max mlen), so the extra LTR cross-match hits that ALL_CHAINS
reports are discarded there (seen in the T window: the right LTR on B's left LTR and vice versa).

### Proposed fix (not applied; it belongs to Task 12's module)

In `localign._align_mappy`:

```python
_NO_LJOIN, _ALL_CHAINS = 0x400, 0x800000  # minimap2 MM_F_NO_LJOIN, MM_F_ALL_CHAINS (-P)
aligner = mappy.Aligner(seq=b_seq, preset=preset, best_n=MAPPY_BEST_N, extra_flags=_NO_LJOIN | _ALL_CHAINS)
```

**Evidence:** I ran the full suite with a throwaway plugin that registers exactly this as the `mappy` backend
(preset check kept): **456 passed**, no warnings. That covers test_classify, test_localign and test_junction on
all seeds, plus all 12 genotype tests.

**Suggested regression test (Task 12):** align the T, O and inv_site toy cases cut to WINDOW_PAD flanks.

**Unmeasured:** ALL_CHAINS reports more hits per window, and its runtime cost on real maize windows is not
measured.

## Tests (`tests/test_genotype.py`, 12 tests, about 4.5 s in total; none above 1 s, so none is marked slow)

| test | what it checks | current backend | with the fix |
|---|---|---|---|
| test_tsv_field | ruling 4 formatting (None/nan/bool/int/float/numpy/str) | pass | pass |
| test_pair_end_to_end | every toy element's state == `expect` exactly, plus the toy flags, noflags, tiers and U reasons | FAIL (T.e) | pass |
| test_pair_file_has_each_element_once_and_threads_do_not_matter | each element exactly once; rows sorted; paths and markers; no temp files left; windows file (wids, top-level eids once, 1-based around the element); gzip FLG 0 and mtime 0 for pair, chunk and windows; threads=1 (in-process) byte-identical to threads=2 (pool) | pass | pass |
| test_pair_lowercase_target | B lowercased gives a byte-identical pair file | pass | pass |
| test_pair_minus_strand_target | B reverse-complemented: states == expect; every B site on "-" with "inv"; B coordinates exactly the plus run's, mirrored (>= 15 sites) | FAIL (T.e) | pass |
| test_pair_repetitive_flank_decoy | E case's L T e T R pasted mid-spacer ~90 kb past the E site (nearest spacer to +100 kb); sanity check that the region's best local hit is the full-length decoy; all states == expect; E.e's B site inside the ortholog | FAIL (T.e) | pass |
| test_pair_unrelated_genomes | random 300-kb B: every call U no_anchor; exactly one WARNING with "no orthologous alignment between A and B?" | pass | pass |
| test_resume | CHUNK_WINDOWS=6 (4 chunks), described below | pass | pass |
| test_rerun_after_annotation_change | a TSD-only edit (windows unchanged) is recomputed, not reused; removing the host_E host leaves its child in no window, giving U . no_anchor wid "." with every other state unchanged | FAIL (T.e) | pass |
| test_bad_elements_fail_before_anchoring | duplicate eid, or a seqid absent from A, raises ValueError and no work dir is created | pass | pass |
| test_pair_file_needs_each_element_once[missing/duplicate] | a broken classifier (call dropped or duplicated) gives RuntimeError, no pair file and no marker; after the fix, a rerun recomputes the cleared chunks and is correct | pass | pass |

test_resume, step by step:
1. The chunked output is byte-identical to the 1-chunk base run.
2. Delete chunk_0 and its marker, plus the pair file and its marker (an interrupted run); rerun. Only chunk_0
   is recomputed (the mtimes of chunks 1-3 are pinned to an old value and stay; their bytes and markers are
   unchanged) and the pair file is byte-identical.
3. Delete only the pair file and its marker; rerun. Only the merge runs.
4. Rerun the finished pair. "skip" is logged and no file is touched: pair, marker, windows and chunk mtimes
   all unchanged.

**Full suite:**
- Current backend: `4 failed, 452 passed in 27.11s`.
- With the throwaway fix plugin: `456 passed in 27.08s`.

`ruff check src tests`: All checks passed (ruff 0.17.4).

## TDD evidence

**RED** (before `genotype.py` existed):
```
$ mamba run -n ltrpav pytest -q -p no:cacheprovider tests/test_genotype.py
E   ImportError: cannot import name 'genotype' from 'ltrpav' (.../src/ltrpav/__init__.py)
!!!!!!!!!!!!!!!!!!!! Interrupted: 1 error during collection !!!!!!!!!!!!!!!!!!!!
```

**GREEN attempt** (after implementation):
```
$ mamba run -n ltrpav pytest -p no:cacheprovider -o addopts="" -q --strict-markers -rf tests/test_genotype.py
FAILED tests/test_genotype.py::test_pair_end_to_end - AssertionError: ('T.e',...
FAILED tests/test_genotype.py::test_pair_minus_strand_target - AssertionError...
FAILED tests/test_genotype.py::test_pair_repetitive_flank_decoy - AssertionEr...
FAILED tests/test_genotype.py::test_rerun_after_annotation_change - Assertion...
4 failed, 8 passed in 4.14s
```
All 4 fail on `T.e: assert 'U' == 'T'` (O.e would fail next).

**With the proposed localign fix** (throwaway plugin, repo unchanged):
```
$ PYTHONPATH=<scratchpad>/plug mamba run -n ltrpav pytest -p no:cacheprovider -o addopts="" -q -p fixplugin tests/test_genotype.py
12 passed in 4.67s
```

## Timing (toy pair: A 653 kb, B 567 kb, 25 elements, 20 windows; fresh outdir, anchoring included)

- threads 1: 0.68 s.
- threads 2: 0.32 s.
- Rerun of a finished pair: about 0.00 s (skip).
- The whole genotype test file: about 4.5 s.

## Files changed (uncommitted)

- `src/ltrpav/genotype.py` (new)
- `tests/test_genotype.py` (new)
- `src/ltrpav/anchor/__init__.py`: `anchors_path`; elements digest imported from `elements`
- `src/ltrpav/elements.py`: `elements_digest` (moved)
- `src/ltrpav/seqio.py`: `Fasta.cache_dir`
- `src/ltrpav/constants.py`: `U_WARN`

## Deviations from the brief and rulings (with reasons)

1. **Keys are a superset of ruling 5.**
   - Both keys also hold the A and B FASTA checksums and the elements digest. The chunk key also holds the
     chunk's wid range.
   - Why: with only {anchors npz} the pair key misses any annotation change under the mm2 route (it does not
     read elements), and even a removed element: the pair check runs before the windows, so a stale calls
     file would be reused. Element fields the windows do not hold (TSD, LTR bounds, k) would also reuse stale
     chunks.
   - The wid range covers a change of CHUNK_WINDOWS within one ltrpav version.
   - `test_rerun_after_annotation_change` covers this.
2. **"Assert before writing" is check-before-rename.** The pair file is streamed to a temp file and renamed
   only after the exactly-once check. A `RuntimeError` is raised rather than `assert`, which `-O` strips.
   Clearing the chunk markers on failure is my addition, so a rerun does not reuse bad chunks.
3. **"Concatenate the chunks in order" is a k-way merge of the sorted chunks.**
   - Why: ruling 4 sorts rows by element, but windows can interleave in element order. `make_windows` keeps
     `last_ok` across an unresolved element, so an ok window can absorb an element after an unresolved one.
     Unresolved windows also start at their element, ok windows at the pad.
   - When chunks do not interleave, the merge equals concatenation.
   - It streams, so memory stays bounded by the number of chunks.
4. **test_resume also deletes the pair file and its marker.**
   - Why: ruling 5 says a finished pair is skipped entirely, so deleting only chunk_0 of a finished pair
     changes nothing.
   - The test therefore simulates the interrupted state (chunk_0 and the pair unfinished), then checks that
     only chunk_0 is recomputed and the pair file is byte-identical. It also checks the merge-only case and
     the skip.
5. **Non-ok windows get `""` for A as well as B.** The classifier returns U from the window status without
   reading A.
6. **Windows file format** (columns, 1-based, strand symbols) was not specified; it is documented in the
   module docstring.

## Self-review findings (fixed before the report)

- Element validation moved before `anchor_pair`, so bad input fails fast instead of after anchoring. Added
  `test_bad_elements_fail_before_anchoring`.
- Log grammar: "1 chunks" became "chunk(s)".
- gzip writer: `filename=""` is passed explicitly. Otherwise `GzipFile` would write the temp file's name (with
  the PID) into the header, and the bytes would not be reproducible.
- No fork DeprecationWarning: checked that the process has a single thread at fork. OpenBLAS shuts its
  threads down in an atfork handler; mm2's thread pool is joined. The test output is clean.

## Concerns

1. **(Blocking)** The localign issue above. The other concerns do not block.
2. **The decoy never reaches the anchors.**
   - With the ruling's construction, the mm2 route already drops the pasted paralog at the alignment step:
     its 10.8-kb hit is a weak secondary next to the 26-kb collinear primary.
   - Raw blocks over A 170-190 kb: only A[150645,177049)->B[142440,168844) and A[181854,200000)->
     B[168844,186990). E.e's anchors have margin 1.0.
   - The test proves the end result (E at the ortholog, not P, with high tier). It does not exercise chain/net
     competition against a paralog. A decoy long enough to be reported (or a test at the chain level) would
     be needed for that.
3. **Keys depend on the anchors npz bytes.**
   - `np.savez_compressed` embeds zip timestamps, so any recomputation of the anchors (for example after
     deleting `work/`) changes the npz checksum and reruns every pair's genotyping, even if its inputs are
     identical. This follows from ruling 5.
   - A content hash of the blocks would avoid it, if wanted.
4. **Fork start method (ruling 2).** Fine on Linux. On macOS, fork is unsafe with some system frameworks.
   The parent holds no other threads at fork time.
5. **Parallelism granularity on real data.** CHUNK_WINDOWS = 2000 gives about 25-50 chunks for a maize pair,
   fewer than 64 threads. Not tuned here (fixed constant).

## On resume (after the localign fix lands)

Rerun `tests/test_genotype.py` and the full suite plus ruff, then commit `Add pair genotyping with chunked
workers and resume` (no trailers) with the six files above.

---

## Fix report (after the controller's ruling: apply the localign fix as a separate commit)

**Status: DONE.**
- `c577e18` Keep window flank chains separate in mappy
- `9997549` Add pair genotyping with chunked workers and resume

Both are plain messages with no trailers, committed with the global git identity. The working tree is clean.

### Commit c577e18: localign fix (window alignment only)

- **`constants.py`:**
  `MAPPY_WINDOW_FLAGS = 0x400 | 0x800000  # minimap2 MM_F_NO_LJOIN | MM_F_ALL_CHAINS; window alignment only`.
  The one-line reason above it reads: `NO_LJOIN: flanks not bridged over an element and Z-dropped; ALL_CHAINS:
  short flanks kept under an inversion`.
- **`localign._align_mappy`:** passes `extra_flags=MAPPY_WINDOW_FLAGS` and has a docstring giving the reason.
  The whole-genome mm2 route (`anchor/mm2.py`, its own aligner with `_EQX`) is unchanged.
- **`tests/test_localign.py::test_window_sized_flanks_align`:**
  - Parametrized over T, O and inv_site and over asm5, asm10 and asm20; each case runs seeds 7, 0, 4, 6, 9, 11
    and 14.
  - The toy case is cut to `WINDOW_PAD` bp of flank on each side, the way `make_windows` cuts a window. The test
    first asserts that A and B share that L and R.
  - Then both sides must have aligned_bp >= `MIN_SEG`, and inv_site must keep an inverted hit of >= MIN_SEG over
    the element.

**RED, before the flags (it fails without them):**
```
$ mamba run -n ltrpav pytest -p no:cacheprovider -o addopts="" -q --strict-markers tests/test_localign.py -k window_sized
E           AssertionError: (7, (505, 0))     # T: right flank lost   (x3 presets)
E           AssertionError: (7, (0, 505))     # O: left flank lost    (x3 presets)
E           AssertionError: (7, (0, 0))       # inv_site: no flank    (x3 presets)
9 failed, 86 deselected in 0.27s
```

**GREEN, with the flags:**
```
9 passed, 86 deselected in 1.57s
```

**Commit c577e18 checked on its own:** I ran a temporary `git worktree` at c577e18 with `PYTHONPATH=<worktree>/src`
(confirmed that `ltrpav` imported from the worktree and that `genotype.py` was absent there). The full suite gave
`454 passed in 26.64s` (445 baseline + 9 new). The worktree was removed afterward.

### Timing of align_window with and without the flags (toy windows)

The 20 windows of the toy pair (seed 7) as the pipeline builds them: A 134 kb and B 48 kb in total. Each figure
is the median of 30 repetitions, timing mappy index + map + `alnmap_from_hits` per window.

| preset | no flags | NO_LJOIN | ALL_CHAINS | both (now) | hits over 20 windows (none, both) |
|---|---|---|---|---|---|
| asm5 (pipeline's preset for the toy, d = 0.0007) | 1.68 ms | 1.81 ms | 4.58 ms | 4.80 ms | 34, 50 |
| asm20 | 1.25 ms | 1.06 ms | 3.49 ms | 3.30 ms | 34, 50 |

- The cost is 2.6-2.9x per window, and it comes from ALL_CHAINS; NO_LJOIN alone costs nothing.
- Cost on real maize windows is left to the bake-off, as ruled.

### Commit 9997549: Task 16

- Contains the six files listed above. The extra checkpoint-key inputs and the resume-test adjustment are
  accepted by the ruling.
- One change since the first report: `test_pair_end_to_end` is parametrized over the 7 seeds of test_classify
  (seed 7 reuses the shared run), so the end-to-end proof covers chance microhomology at the junctions. The file
  now has 18 tests.

```
$ mamba run -n ltrpav pytest -p no:cacheprovider -o addopts="" -q --strict-markers -rf tests/test_genotype.py --durations=6
0.80s setup    tests/test_genotype.py::test_pair_end_to_end[7]
0.74s call     tests/test_genotype.py::test_rerun_after_annotation_change
0.65s call     tests/test_genotype.py::test_pair_end_to_end[11]
...
18 passed in 8.64s
```
No test takes more than 1 s, so none is marked slow.

**Diagnostic sweeps with the fixed backend:**
- The 7 seeds (7, 0, 4, 6, 9, 11, 14): 0 misses in state, flags, tier or U reason for every element. The
  per-element table above (the "no-long-join + all-chains" column) is now the pipeline's output.
- Variants plain, decoy, minus strand and lowercase: 0 misses.
- E.e: `E high tsd_match` at B chr1:168846-168850 (+), inside the E site (B 165846-171850), not at the decoy
  (B 259361). On the minus-strand B it is at chr1:398091-398095 (-) with `inv`.

**Full suite and lint:**
```
$ mamba run -n ltrpav ruff check src tests
All checks passed!
$ mamba run -n ltrpav pytest -p no:cacheprovider -o addopts="" -q --strict-markers
472 passed in 32.69s
```

### New concerns from the flags (for the bake-off; the toy cannot show them)

1. **Cost.** 2.6-2.9x per window on the toy, all from ALL_CHAINS.
   `alnmap_from_hits._chain` is an O(n^2) pure-Python DP over the hits. On large repetitive windows (up to
   WINDOW_CAP = 500 kb), ALL_CHAINS may report many more hits than before, so the hit count per window is worth
   logging in the bake-off.
2. **Calls.** Rule 4a calls U inv_site whenever any inverted hit of >= MIN_SEG overlaps an absent element.
   ALL_CHAINS now also reports weak inverted secondaries that minimap2 used to filter (for example another TE
   copy inverted in B's window). Some former E/D calls on real data may therefore turn into U inv_site. Worth
   watching the inv_site rate in the bake-off.

The concerns from the first report (decoy never reaches the anchors; keys tied to the anchors npz bytes; fork on
macOS; chunk granularity) still stand. None of them blocks.

### Second ruling: count inverted hits only at the site (commit eb0b82e)

**Why:** this addresses my concern that weak inverted secondaries, now reported, could turn E/D into U inv_site.
The risk was real and came with `c577e18`. For an E case whose B window also holds a reverse-complemented copy of
the element's LTR 2 kb past the site, the old rule 4a fired (U inv_site):

| aligner flags | seeds where the old rule fired |
|---|---|
| none (before `c577e18`) | 0 of 7 |
| NO_LJOIN alone | 7 of 7 |
| ALL_CHAINS alone | 7 of 7 |
| both (current) | 7 of 7 |

**`src/ltrpav/classify.py`:**
- Rule 4a is now `_inverted_at_site(aln, s, t)`. It keeps the old conditions (an inverted hit of >= MIN_SEG A
  bases overlapping [s, t)) and adds one: the hit's B interval [b0, b1) must meet the site
  [min(lo, hi), max(lo, hi)], i.e. `b0 <= hi and b1 > lo`.
- lo = `_b_last_before(aln, s)` and hi = `_b_first_from(aln, t)`, the same anchors the G rule uses, without the
  REFINE_PAD widening. Rule 2 guarantees both exist.
- The module docstring's rule 4 and the new helper's docstring state the condition.

**DESIGN.md:** 5.4 does not describe the inverted-hit rule (its U row lists only anchors, ambiguity and
breakpoints), so per the ruling it is unchanged.

**`tests/test_classify.py`:**
- **`test_inverted_hit_rules`, updated** to pin the closed-interval semantics on the E case (site lo = 2999,
  hi = 3000):
  - Hits with B [2990, 3070), [3000, 3080) or [2920, 3000) count (U inv_site).
  - Hits with B [10, 90), [3001, 3081) or [2919, 2999) miss the site (E).
  - A 79-bp hit at the site, and a hit outside the element, are ignored (E).
  - The old far-B case `(10, 90)` flips from U inv_site to E. This is the intended change.
- **(a) `test_inverted_copy_off_the_site_is_not_inv_site[seed]`, new** (7 seeds): B = L T R with revcomp(LTR)
  inserted 2 kb past the site. The test first asserts that an inverted hit over the element at the copy is
  reported (the trap is real), then that the call is E with tsd_match.
- **(b) `test_inv_site_at_every_seed[None|WINDOW_PAD]`, new:** the toy inv_site case stays U inv_site at all 7
  seeds, both as the whole case and cut to WINDOW_PAD bp of flank as `make_windows` cuts a window.

**RED, before the refinement, with the new flags:**
```
$ mamba run -n ltrpav pytest -p no:cacheprovider -o addopts="" -q --strict-markers -rf tests/test_classify.py -k "inverted or inv_site_at"
E           AssertionError: (10, 90)                      # test_inverted_hit_rules: far-B hit still counted
E       AssertionError: ('U', 'inv_site', [])            # test_inverted_copy_off_the_site_is_not_inv_site, x7 seeds
8 failed, 2 passed, 201 deselected in 1.51s              # (b) passes: it is a "stays U inv_site" guard
```

**GREEN:**
```
$ ... -k "inverted or inv_site_at"         -> 10 passed, 201 deselected in 1.17s
$ ... tests/test_classify.py               -> 211 passed in 2.91s
$ ... tests/test_genotype.py               -> 18 passed in 8.46s   (7 end-to-end seeds and the variants unchanged)
$ mamba run -n ltrpav pytest -p no:cacheprovider -o addopts="" -q --strict-markers
481 passed in 33.90s
$ mamba run -n ltrpav ruff check src tests
All checks passed!
```

Commit `eb0b82e` "Count inverted hits only at the site" touches `src/ltrpav/classify.py` and
`tests/test_classify.py`. Plain message, no trailers; the tree is clean.

**Note (not changed; outside this ruling):** DESIGN.md 5.3 still says the window aligner is "minimap2/ksw2 through
mappy with long join". Since `c577e18` the window aligner runs without long join (MM_F_NO_LJOIN) and with all
chains. A one-line update to 5.3 would keep the design record accurate, if wanted.

---

## Review fix round 1 (two Important findings, fixed per the controller's rulings; minor findings deferred)

| commit | finding |
|---|---|
| `92229c4` Map window strands apart so best_n bounds the hits | 2 |
| `e0b7236` Fail fast when a genotyping worker dies | 1 |

Both are plain messages with no trailers. The working tree is clean.

### Finding 2: `-P` (MM_F_ALL_CHAINS) disabled best_n, so window hits were unbounded (commit 92229c4)

**Changes:**
- **`constants.py`:** `MAPPY_WINDOW_FLAGS` replaced by:
  - `MAPPY_FWD_FLAGS = 0x400 | 0x100000` (NO_LJOIN | FOR_ONLY), reason: flanks stay separate chains, never
    bridged over an element and Z-dropped.
  - `MAPPY_REV_FLAGS = 0x400 | 0x200000` (NO_LJOIN | REV_ONLY), reason: inverted hits mapped apart never outrank
    (and so drop) the short flank chains.
  - A comment line above the two names the minimap2 flags.
  - `MAPPY_BEST_N`'s reason is now accurate: "minimap2's default -N: secondaries kept per mapping (rivals);
    bounds the hits".
- **`localign._align_mappy`:** one mappy index of the B window, mapped twice: `aligner.map(a, extra_flags=
  MAPPY_FWD_FLAGS)` and `aligner.map(a, extra_flags=MAPPY_REV_FLAGS)`, both with `best_n=MAPPY_BEST_N`. The union
  goes to `alnmap_from_hits`: forward hits to the collinear chain, reverse hits to `inv`. The docstring explains
  why. The whole-genome mm2 route is unchanged.

**Small deviation from the ruling: one Aligner, not two.** mappy 2.31's `Aligner.map()` takes per-call
`extra_flags`; they are map-time options, and the index depends only on the preset. One index with two calls gives
hits identical to two Aligners on all 588 toy windows I checked (21 cases x 7 seeds x whole or 500-bp flanks x
asm5/asm20, comparing every coordinate, strand, mlen, blen, CIGAR and primary flag). The per-call flags do not
persist (a plain `map()` afterwards equals a fresh Aligner). It saves one index build per window; see the timings
below.

**Tests (`tests/test_localign.py`):**
- `test_window_sized_flanks_align` (T, O, inv_site x asm5/asm10/asm20 x 7 seeds) is unchanged and green.
- New `test_dense_window_hits_bounded[asm5|asm20]`:
  - The window holds 20 copies of one LTR family (2% apart) between unique 3-8-kb spacers, 231 kb in all; B
    lacks copies 2, 7 and 12 and differs by 0.5% substitutions.
  - A spy on `localign.alnmap_from_hits` counts the hits through the public `align_window` path.
  - The bound is per strand: at most one primary per A segment plus MAPPY_BEST_N secondaries, so
    2 x (41 + 5) = 92. It is linear in the copies. The test also asserts that >= 99% of the shared A aligns.

**Each test pins one problem.** Throwaway plugins (repo untouched) swap the backend:

| backend | `test_window_sized_flanks_align` (9) | `test_dense_window_hits_bounded` (2) |
|---|---|---|
| pre-`c577e18`: no flags | **9 failed**: `(7, (505, 0))` T, `(7, (0, 505))` O, `(7, (0, 0))` inv_site | passed (1 hit, long-joined) |
| `c577e18`: NO_LJOIN \| ALL_CHAINS (`-P`) | passed | **2 failed**: `[400]` (asm5), `[1007]` (asm20) hits > 92 |
| strand split (`92229c4`) | passed | passed |

```
$ mamba run -n ltrpav pytest -p no:cacheprovider -o addopts="" -q --strict-markers -rf tests/test_localign.py -k "dense or window_sized"
# before the change (with -P):   2 failed, 9 passed, 86 deselected in 9.73s   (AssertionError: [400], [1007])
# after the change:              11 passed, 86 deselected in 2.40s
```

**Calls unchanged.** On the toy, the strand split gives exactly the -P calls (state, reason, flags, tier) on all
21 cases x 7 seeds x whole/500-bp x asm5/asm20 (the reviewer's `probe_alt.py`: 0 differences).
`test_classify.py` (211) and `test_genotype.py` pass unchanged.

**Timings** (median ms per window; index + map + `alnmap_from_hits`).

Toy pair, the pipeline's own 20 windows (A 134 kb, B 48 kb in all), 30 repetitions:

| preset | no flags (pre-c577e18) | -P (c577e18) | strand split, 1 index (now) | strand split, 2 indexes |
|---|---|---|---|---|
| asm5 | 1.93 ms, 34 hits | 5.54 ms, 50 hits | **4.84 ms, 40 hits** | 5.10 ms, 40 hits |
| asm20 | 1.35 ms, 34 hits | 3.58 ms, 50 hits | **3.33 ms, 40 hits** | 3.65 ms, 40 hits |

Repeat-dense windows, one family (my construction; asm20; 3 repetitions):

| window | no flags | -P | strand split, 1 index | strand split, 2 indexes |
|---|---|---|---|---|
| 6 copies, 77 kb | 1 hit, 69 ms | 86 hits, 288 ms | 2 hits, 76 ms | 2 hits, 80 ms |
| 20 copies, 231 kb | 1 hit, 634 ms | 1,007 hits, 2,728 ms | **11 hits, 504 ms** | 11 hits, 528 ms |
| 40 copies, 468 kb | 1 hit, 3,281 ms | 4,391 hits, 15,126 ms | **5 hits, 1,502 ms** | 5 hits, 1,554 ms |

Every strategy aligned 100% of the shared A in these windows. On the reviewer's 3-family windows
(`probe_alt.py`, two-index split): 20 copies gave -P 324 hits / 827 ms against split 8 hits / 209 ms; 40 copies
gave -P 1,444 hits / 3,482 ms against split 7 hits / 644 ms.

**Cost summary:**
- About 2.5x the old single long-joined pass on small windows (two map passes), slightly under -P.
- 5-10x faster than -P on dense windows, with hits bounded.
- The real maize cost is still for the bake-off.

### Finding 1: a worker that dies hard hung the pair; a failing initializer looped (commit e0b7236)

**Changes (`src/ltrpav/genotype.py`):**
- `_run` uses `ProcessPoolExecutor(min(threads, jobs), mp_context=multiprocessing.get_context("fork"),
  initializer=_init_worker, initargs=init)`. Fork and copy-on-write elements are kept: Python 3.12 forks all
  workers before the manager thread starts, so no multi-threaded-fork warning. Chunks are submitted and collected
  with `as_completed`.
- **Worker died** (BrokenProcessPool: killed by a signal or the OOM killer, crashed, or the initializer raised):
  `RuntimeError("A vs B: a worker process died or could not start (killed by a signal or out of memory, or
  crashed); chunk(s) <unfinished> unfinished")`, chained from the BrokenProcessPool.
- **Chunk raised:** `RuntimeError("A vs B: chunk <n> failed: <Type>: <message>")`, chained, with the worker's
  traceback as the cause.
- `finally: pool.shutdown(wait=True, cancel_futures=True)`: pending chunks are cancelled; running ones finish and,
  being complete, are marked done. ProcessPoolExecutor pre-queues up to max_workers + 1 calls, so a few chunks past
  the failure may still finish; they are valid and are reused.
- A chunk is marked done only by the worker that finished it (unchanged), so a failed chunk is never marked.
- **Initializer:** a FASTA that cannot be opened (OSError, ValueError, RuntimeError: what `Fasta` and pysam raise)
  is kept and raised by that worker's tasks, so the parent's error carries the real cause (`chunk 0 failed:
  OSError: ...`) instead of "died".
  - Any other initializer exception raises in the initializer and fails fast as a broken pool.
  - Ruff 0.17.4 enables BLE001 (blind except) by default, so the catch is narrowed instead of adding the repo's
    first `noqa`.
- The in-process path (threads = 1) wraps chunk errors the same way, so messages name the pair and chunk either
  way.
- Before running chunks, stale `.chunk_*.tmp` files are removed: a worker killed mid-write (for example a sibling
  terminated when the pool breaks) can leave one.

**Tests (`tests/test_genotype.py`):** `test_worker_failure_fails_fast_and_resumes` runs four faults, each inside a
30-s SIGALRM `deadline` that turns a hang into a TimeoutError:
- **killed:** the worker SIGKILLs itself at window 8 (chunk 1). The patched code asserts that it runs in a worker
  before killing, so it can never kill pytest.
- **init_raises:** `_init_worker` replaced by a raising function (broken-pool path).
- **fasta_fails:** `genotype.Fasta` raises OSError inside the real initializer (deferred-error path).
- **raises:** ValueError("boom") at window 8.

For each fault the test asserts:
1. genotype_pair raises a RuntimeError naming the pair, with the expected message.
2. There is no pair file and no pair marker.
3. chunk_1 is never marked done (killed, raises).
4. The finished chunks' mtimes are pinned. A rerun inside the deadline is byte-identical to the base run; the
   pinned chunks keep their mtimes (reused); the chunk dir holds only chunks and markers, with no temp files.

**RED** (on the old `multiprocessing.Pool` code):
```
$ mamba run -n ltrpav pytest -p no:cacheprovider -o addopts="" -q --strict-markers -rf tests/test_genotype.py -k worker_failure
E       TimeoutError: still running after 30 s        # killed, init_raises, fasta_fails: the pool hangs
E       ValueError: boom                               # raises: bare worker error, no pair or chunk named
4 failed ... real 1m32.377s
```

**GREEN:**
```
4 passed, 18 deselected in 2.85s        # each <= 0.47 s, including the rerun
```

**The reviewer's `probe_pool.py` on the fix:**
- raise: `raised after 0.3 s: RuntimeError: A vs B: chunk 1 failed: ValueError: boom in window 8`. Chunks 0, 2
  and 3 finished; chunk 1 was not marked; the rerun recomputed only `chunk_1`; bytes == base.
- kill: `raised after 0.3 s: RuntimeError: A vs B: a worker process died or could not start (...); chunk(s) 0,
  1, 2, 3 unfinished` (cause BrokenProcessPool). The rerun recomputed all four; bytes == base; no temp files.
- initfail: `raised after 0.3 s: RuntimeError: A vs B: chunk 0 failed: OSError: cannot open FASTA in worker`.
  The rerun gave bytes == base.
- threads3: bytes == threads=1 bytes.

### Runs after both fixes

```
$ mamba run -n ltrpav ruff check src tests                 -> All checks passed!
$ ... pytest -q tests/test_localign.py                     -> 97 passed in 3.36s
$ ... pytest -q tests/test_classify.py                     -> 211 passed in 2.87s
$ ... pytest -q tests/test_genotype.py                     -> 22 passed in 10.25s
$ mamba run -n ltrpav pytest -p no:cacheprovider -o addopts="" -q --strict-markers --durations=5
487 passed in 36.80s                                       (slowest new test 0.70 s; no warnings)
```
Before committing 92229c4, I also ran the six test files that use the window aligner or anchoring on its state:
375 passed.

The open notes from earlier rounds still stand (the decoy never reaches the anchors; DESIGN.md 5.3's "with long
join" wording is stale since c577e18; keys tied to the anchors npz bytes; fork on macOS). Minor review findings
are deferred, as ruled.

---

## Review fix round 2: orphaned workers when the parent dies (commit f9a4558)

**Finding (Important):** if the genotyping parent is killed (SIGKILL, SIGTERM, the OOM killer), the
ProcessPoolExecutor workers were orphaned and never exited. They hold a write end of the inherited call queue, so
`call_queue.get()` never reads EOF. The reviewer measured both workers alive 12 s later with ppid 1.

**Changes (`src/ltrpav/genotype.py`; nothing else changed):**
- `_init_worker` takes the parent's pid as its first argument: `_run` passes `os.getpid()` first in `initargs`.
  It calls `_die_with_parent(parent)` before opening the FASTAs.
- **`_die_with_parent(parent)`:**
  1. Restores SIGTERM's default action (`signal.SIG_DFL`) in the worker. A handler inherited from the parent
     could otherwise turn the signal into an exception, which concurrent.futures would catch inside a task while
     the worker lived on.
  2. On Linux, `_pdeathsig()` calls libc `prctl(PR_SET_PDEATHSIG = 1, SIGTERM)` through
     `ctypes.CDLL(None, use_errno=True)`. The arguments are passed as `c_int` / `c_ulong` because glibc's prctl
     is variadic and reads unsigned longs. It returns False when the platform is not Linux, prctl is missing, or
     the call fails.
  3. Without prctl (macOS), it starts a daemon thread `_watch_parent` that checks `os.getppid()` once a second
     and calls `os._exit(1)` when it changes.
  4. Race guard: right after arming, `os.getppid() != parent` means the parent died before prctl took effect (the
     worker was already reparented), so the worker exits at once.
- The module docstring notes that a worker exits when the parent dies. Python 3.12 forks the workers from the
  calling (main) thread in `submit`, so the "parent" that PDEATHSIG watches is the thread running `_run`, which
  outlives the pool.

**Test (`tests/test_genotype.py::test_workers_exit_when_the_parent_dies[prctl|poll]`):**
- It runs on Linux only (it lists processes through /proc), under the 30-s `deadline` guard.
- A child process runs a genotyping parent (script `_PARENT`): 3 toy cases, CHUNK_WINDOWS = 1, threads = 2.
  Chunk 0 is slow in its worker (touches `run/slow`, then sleeps 120 s).
- The test waits for `slow`, records the two workers from /proc (pid and start time, so a reused pid is never
  mistaken for a survivor), SIGKILLs the parent, and requires both workers gone (no process, or a zombie)
  within 5 s. That covers the busy worker and the idle one blocked on the queue.
- `poll` switches prctl off (`genotype._pdeathsig = lambda: False` in the child), so the macOS fallback is
  exercised on Linux CI too.
- A `finally` kills any survivor, so a failure never leaks processes.

**RED** (before the fix):
```
$ mamba run -n ltrpav pytest -p no:cacheprovider -o addopts="" -q --strict-markers -rf tests/test_genotype.py -k parent_dies
E           AssertionError: workers alive 5 s after the parent died: [(1055691, '460532152'), (1055733, '460532152')]
E           AssertionError: workers alive 5 s after the parent died: [(1129912, '460532736'), (1129916, '460532736')]
2 failed, 22 deselected in 11.99s
$ ps -eo pid,ppid,stat,etime,cmd | grep "[p]arent\.py"    -> no leftover genotyping processes (cleanup works)
```

**GREEN:**
```
$ ... -k "parent_dies or worker_failure" --durations=6
1.62s call     tests/test_genotype.py::test_workers_exit_when_the_parent_dies[poll]
0.81s call     tests/test_genotype.py::test_workers_exit_when_the_parent_dies[prctl]
6 passed, 18 deselected in 5.43s
```

**Exit latency:** measured from the parent's SIGKILL until both workers are gone, 3 runs each, with the test's own
child script:
```
prctl: 2 workers gone 0.021, 0.016, 0.016 s after the parent's SIGKILL
poll:  2 workers gone 0.812, 0.819, 0.832 s after the parent's SIGKILL
```

**The reviewer's probes on the fix** (`rereview16/probe_parent_death.py` and `probe_parent_term.py`, mode `new`):
```
[new] parent 1754645, workers [1755853, 1755860]; SIGKILL the parent
[new]   +2 s: {1755853: 'gone', 1755860: 'gone'}
[new] parent 1902900, workers [1911873, 1911885]; SIGTERM the parent
[new]   +2 s: {1911873: 'gone', 1911885: 'gone'}
```

**Runs:**
```
$ mamba run -n ltrpav ruff check src tests                 -> All checks passed!
$ ... pytest -q tests/test_genotype.py                     -> 24 passed in 12.73s
$ mamba run -n ltrpav pytest -p no:cacheprovider -o addopts="" -q --strict-markers --durations=4
489 passed in 39.59s                                       (no warnings; slowest new test 1.61 s)
```

Commit `f9a4558` "Workers exit when the genotyping parent dies" touches `src/ltrpav/genotype.py` and
`tests/test_genotype.py`. Plain message, no trailers; the tree is clean.

**Notes:**
- The only step beyond the ruling's text is restoring SIGTERM's default action in the worker. Without it, an
  inherited Python SIGTERM handler that raises could leave the worker alive inside concurrent.futures' task
  loop.
- Minor review findings are still deferred, as ruled.
