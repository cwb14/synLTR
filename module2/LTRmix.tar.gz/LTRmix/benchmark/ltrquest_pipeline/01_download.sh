#!/usr/bin/env bash
# Resumable download of candidate assemblies + B73 proteins from MaizeGDB, then md5 check.
# Usage: 01_download.sh <outdir>
set -u
OUT=${1:?outdir}
BASE=https://download.maizegdb.org
UA='Mozilla/5.0 (X11; Linux x86_64)'
get() { # assembly filename
  local a=$1 f=$2; mkdir -p "$OUT/$a"
  curl -sS -f -L -A "$UA" --retry 8 --retry-delay 20 --retry-all-errors -C - \
       -o "$OUT/$a/$f" "$BASE/$a/$f" || { echo "FAIL $a/$f"; return 1; }
  echo "OK $a/$f $(stat -c %s "$OUT/$a/$f")"
}
pids=()
for a in Zm-B73-REFERENCE-NAM-5.0 Zv-TIL11-REFERENCE-PanAnd-1.0 Zv-TIL01-REFERENCE-PanAnd-1.0 \
         Zv-Ames21814-REFERENCE-CEMPS-1.0 Zx-TIL18-REFERENCE-PanAnd-1.0 Zx-TIL25-REFERENCE-PanAnd-1.0; do
  ( get "$a" "$a.md5"; get "$a" "$a.fa.gz.fai"; get "$a" "$a.fa.gz" ) &
  pids+=($!)
done
( get Zm-B73-REFERENCE-NAM-5.0 Zm-B73-REFERENCE-NAM-5.0_Zm00001eb.1.protein.fa.gz ) &
pids+=($!)
wait "${pids[@]}"
echo "--- md5"
for d in "$OUT"/*/; do
  a=$(basename "$d"); ( cd "$d" || exit
    for f in *.fa.gz; do
      want=$(grep -F "$f" "$a.md5" | grep -vE "$f\.[a-z]" | awk '{print $1}' | head -1)
      have=$(md5sum "$f" | cut -d' ' -f1)
      [ "$want" = "$have" ] && echo "MD5_OK $a/$f" || echo "MD5_CHECK $a/$f want=$want have=$have"
    done )
done
echo ALL_DONE
