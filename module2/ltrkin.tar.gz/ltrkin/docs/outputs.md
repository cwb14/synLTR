# ltrkin output reference

Every column of every output file. Coordinates are 1-based and inclusive, as in the GFF3. Reads count only when
they are anchored in unique flank with MAPQ >= `--min-mapq` (default 20).

## `ltrkin genotype`

### `<out>.genotypes.tsv`: one row per element x sample
| column | meaning |
|---|---|
| `element_id`, `chrom`, `start`, `end`, `strand` | the element, as annotated |
| `family`, `clade` | from the annotation (`.` or `unknown` when absent) |
| `length`, `ltr5_len`, `ltr3_len` | element and LTR lengths (bp) |
| `tsd` | target-site duplication: annotated, else identical 4-6-mers flanking the element; `.` if none |
| `n_inner`, `n_outer` | elements nested inside this one; elements this one sits inside |
| `sample` | read-group SM of the BAM (else the file name) |
| `n_F` | reads showing the full element: `n_F_span` + `n_F_left` + `n_F_right` |
| `n_F_span` | reads spanning the whole site with the full element (including split reads whose pieces were joined) |
| `n_F_other` | of `n_F_span`, reads that carry both element ends but another internal length |
| `n_F_left`, `n_F_right` | reads crossing the left / right element end into the internal region |
| `n_S`, `n_S_split` | reads showing a solo LTR; of them, reads split in two by the aligner |
| `n_E`, `n_E_split` | reads showing the empty site (pre-insertion allele); of them, split reads |
| `n_P` | reads crossing only into an LTR: element present, full or solo (not used for the genotype) |
| `n_O` | spanning reads whose length fits no allele |
| `n_U` | reads clipped at an element end whose clipped part matches neither the far flank nor the element |
| `n_lowq` | reads at the element ends with MAPQ below `--min-mapq` (not used) |
| `hap_F`, `hap_S`, `hap_E` | haplotypes seen carrying each allele by read phasing (a lower bound) |
| `phase_sites` | heterozygous sites in the flanks used for phasing |
| `other_delta_median` | median length change (bp) of the `n_O` reads; `.` if none |
| `r_F`, `r_S`, `r_E` | informative reads expected per haplotype carrying the allele, per unit of haplotype depth (from the sample's read lengths) |
| `exp_reads` | informative reads expected under the called genotype |
| `flank_depth`, `flank_ratio` | median read depth in the flanks, and its ratio to the sample's depth (-1: not measured) |
| `genotype` | alleles, one per chromosome copy: `F` full, `S` solo LTR, `E` empty site, `N` null (this haplotype has no such site); `./.` = no call |
| `gq` | genotype quality: phred-scaled probability that the genotype is wrong, capped at 99 |
| `vcf_gt` | the genotype in VCF coding (0 full, 1 empty, 2 solo, `.` null) |
| `p_F`, `p_E`, `p_S` | probability that at least one haplotype carries the full element / empty site / solo LTR |
| `pav` | presence/absence: `present` (p_F >= 0.99), `absent` (p_E >= 0.99, p_F <= 0.01), `solo` (p_S >= 0.99, p_F <= 0.01), else `uncertain` |
| `flags` | `PASS` or a comma-separated list (below) |

Flags:
| flag | meaning |
|---|---|
| `low_depth`, `high_depth` | informative reads < 0.25x or > 2.5x `exp_reads` (high: a possible collapsed duplication) |
| `other_allele` | >= 2 reads and >= 20% of spanning reads fit no allele length |
| `full_other_length` | >= 2 reads and >= 20% of spanning reads are full with another internal length (indel, nesting) |
| `unexplained_clips` | >= 2 reads and >= 20% of reads are `n_U` |
| `flank_depth_low` | flank depth below (ploidy - 0.5) / ploidy of the sample's depth: part of the region may be missing |
| `low_mapq` | >= 30% of the reads at the element ends map ambiguously: dosage from depth is unreliable |
| `no_reads` | no informative read |

### `<out>.vcf.gz`: the same calls as VCF 4.3
One record per element. `POS` and `REF` are the base before the element; the reference allele is the full element.
`ALT` = `<DEL:ME:LTR>` (empty site: the element and one TSD copy absent) and `<DEL:ME:SOLO>` (solo LTR).
INFO: `SVTYPE`, `END` (last base of the element), `SVLEN` (length change of each ALT), `ELEMENT`, `FAMILY`,
`CLADE`. FORMAT: `GT` (0 full, 1 empty site, 2 solo LTR, `.` null haplotype or no call; GQ 0 marks a no call), `GQ`,
`AD` (full, empty, solo reads), `FT` (flags, separated by semicolons). Indexed: `<out>.vcf.gz.tbi`. Characters
with a meaning in VCF (`;`, `=`, `,`, `%`, spaces) are percent-encoded in IDs and INFO values.

### `<out>.<sample>.evidence.json.gz`
The read evidence of each sample. A rerun with the same BAM, reference, annotation, options and ltrkin version
reuses it and skips reading the BAM; any change triggers a rescan.

## `ltrkin source`
Status of each element, from the genotype calls with GQ >= 20: **new** = an empty allele in at least one sample;
**fixed** = full on every haplotype in every called sample; **other** = the rest (solo-only copies are removed, not
new). Sites flagged `high_depth` or `unexplained_clips` are neither new nor fixed.

### `<out>.copies.tsv`: one row per candidate copy (both LTRs, internal region >= 1 kb)
| column | meaning |
|---|---|
| `element_id`, `chrom`, `start`, `end`, `family`, `clade` | the element |
| `status`, `n_called` | new / fixed / other; samples with a call of GQ >= 20 |
| `internal_len` | internal region (bp) |
| `ltr_diffs`, `ltr_k2p` | differences between the element's two LTRs, and their K2P divergence (an age proxy); given for new copies and their sources |
| `nearest_any_id`, `nearest_any_div` | nearest copy of any status, and its divergence (internal regions) |
| `nearest_fixed_id`, `nearest_fixed_div` | nearest fixed copy, and its divergence |

### `<out>.sources.tsv`: one row per new copy x tied nearest fixed copy (its likely source)
| column | meaning |
|---|---|
| `new_*`, `source_*` | IDs and coordinates of the new copy and of the source; `family`, `clade` |
| `divergence`, `aln_len`, `est_diffs` | divergence of the internal regions (nested elements excised), aligned length, estimated differences |
| `n_tied`, `weight` | fixed copies tied as nearest (within half a difference); each gets weight 1 / `n_tied` |
| `same_chrom`, `distance` | source on the same chromosome; distance between the two copies (bp) |
| `nearest_any_id`, `nearest_any_status`, `nearest_any_div` | the nearest copy of any status (a closer non-fixed relative is a sibling, not the source) |
| `new_ltr_diffs`, `source_ltr_diffs`, `source_older` | LTR differences of both copies; source older by >= 2 differences |
| `same_tsd`, `flank_identity` | same TSD, and identity of the 500-bp flanks: a duplicated segment rather than an insertion |
| `shared_derived`, `source_private`, `new_private`, `consensus_sites` | mutations shared with the source, private to each copy (polarized by the consensus of the 10 nearest relatives), and sites compared |
| `mosaic_left`, `mosaic_right`, `mosaic_breakpoint`, `mosaic_support`, `mosaic_conflicts`, `mosaic_p_adj` | two-parent (recombinant) test: the two parents, the breakpoint along the internal region, the sites supporting each side, conflicts, adjusted p |
| `flags` | `segdup` (same TSD or flank identity >= 0.9), `tied`, `closer_nonfixed_relative`, `recombinant`; else `PASS` |

### `<out>.locality.tsv`: do new copies sit on their source's chromosome?
One row per divergence limit x clade (and family).
| column | meaning |
|---|---|
| `max_divergence`, `level`, `group` | divergence limit of the pairs; clade or family; its name |
| `n_new`, `same` | new copies; weighted number whose source is on the same chromosome |
| `expected`, `obs_exp`, `p` | expected under the base-pair-share null (chromosomes in proportion to their size), observed / expected, p |
| `perm_expected`, `perm_obs_exp`, `perm_p` | the same under a permutation null that keeps clusters of copies from one source |
| `median_distance_mb` | median distance between same-chromosome pairs (Mb) |

### `<out>.work/`
Intermediate alignments (minimap2 PAF and their parsed tables), keyed to the inputs. A rerun with the same
inputs reuses them; delete the folder to recompute.
