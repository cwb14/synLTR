# Task 23 — controller rulings (bind as much as the brief; override it where they conflict)

Context the brief cannot know:
- Task 22's simulator (`ltrpav.sim`) writes `truth.tsv` with `ltrpav.sim.truth.TRUTH_COLUMNS` = genome, eid, name,
  seqid, start, end, origin, state, flags, events_x, events_y (start/end 1-based inclusive in X; flags
  comma-joined or ""). `genome` is X (the element's genome, label "A" or "B"); `state` is the element's truth in
  the other genome Y. `A.gff3`/`B.gff3` carry Name = the simulator eid, with ~10% of elements dropped (dropout).
- `ltrpav run` writes, per ordered pair, `<outdir>/pairs/<X>__<Y>.calls.tsv.gz` (header = `ltrpav.classify.
  CALL_COLUMNS`; one row per X element; flags comma-joined, empty cell when none; tier high|medium|low|".") and X's
  normalized elements at `<outdir>/work/elements/<X>.tsv` (`ltrpav.elements.read_elements`; Element.name = the
  GFF3 Name = the simulator eid).

1. Inputs. `score(calls_path, elements_path, truth_path) -> list[dict]`: calls_path = one ordered pair's calls file
   (.gz or plain); elements_path = X's elements TSV; truth_path = truth.tsv. X = the elements' genome (all elements
   must share one genome, else ValueError). Only truth rows with genome == X are used. Read calls and truth with
   the csv module by header name; fail fast (ValueError naming the file) on a missing column.
2. Join: call.eid -> Element.name -> truth row (X, name). Fail fast when a call's eid is not in the elements file
   or when any annotated element has no truth row (mismatched inputs; give the count and the first 5 names). An
   annotated element without a call row is scored as call U and counted as `n_missing_call`. Truth rows of elements
   absent from the annotation (dropout) are excluded from every denominator and counted as `n_unannotated`.
3. State rows for P, S, T, E, D, O, G (truth never holds U), for tier_set "all" and "high":
   - all: tp = #(call s, truth s); fp = #(call s, truth != s); fn = #(truth s, call != s)
   - high: tp = #(call s, tier high, truth s); fp = #(call s, tier high, truth != s); fn = #(truth s) - tp
   - precision = tp / (tp + fp), recall = tp / (tp + fn); None when the denominator is 0.
   Plus collapsed-class rows, state "present" (P/S/T) and "absent" (E), scored the same way on collapsed classes
   (the admixture analyses consume the collapsed class; the engine's classes are present P/S/T, absent E,
   missing D/O/G/U).
4. Flag rows per tier set, state "flag:inv" and "flag:host_empty", over the elements whose call state equals the
   truth state (and, for "high", whose call is high tier): tp = both flagged, fp = call only, fn = truth only.
5. One summary row per tier set (state "summary"): n_scored (annotated elements with a truth row),
   correct_resolved_frac = #(call == truth, truth in P/S/T/E, and tier high for "high") / #(truth in P/S/T/E),
   unresolved_frac = #(call U) / n_scored, n_unannotated, n_missing_call. All rows share one column order
   (`SCORE_COLUMNS`: state, tier_set, tp, fp, fn, precision, recall, n_scored, correct_resolved_frac,
   unresolved_frac, n_unannotated, n_missing_call); cells that do not apply are None.
6. `confusion(calls_path, elements_path, truth_path) -> list[dict]`: rows (tier_set, truth, call, n) for every
   observed (truth, call) pair; in "high", a call that is not high tier is counted as call "not_high". Sorted by
   tier_set, then the state order P S T E D O G U not_high. The bake-off write-up uses it to show where errors go.
7. CLI: `ltrpav-sim score --calls FILE --elements FILE --truth FILE --out PREFIX [-v]` writes PREFIX.score.tsv and
   PREFIX.confusion.tsv (header = column order; None -> "NA"; floats to 4 decimals). Reuse `ltrpav.cli._execute`
   as the `pair` subcommand does (same exit codes and `error:` line). Default log: start, done.
8. Tests (`tests/test_score.py`, csv module, tmp_path fixtures written by the test): the brief's tiny table (P
   precision 2/3, E recall 1/2), the high-tier restriction, dropout exclusion, missing call -> U, class rows, flag
   rows, summary fractions, confusion counts (including not_high), the two fail-fast mismatches, gz input, and the
   CLI end to end. Then one smoke run outside the test suite: `ltrpav-sim pair` (seed 3, region
   B73v5_chr10:2000001-8000000, the same --fasta/--annotation as the Task 22 run in its report) into
   scratchpad/score23/sim, `ltrpav run --threads 16` into scratchpad/score23/run, score both directions, and put
   the two summaries plus the P/E high-tier rows in the report.
