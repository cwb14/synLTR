# Task 11 Part P review: rescore tooling, R4 scoring fixes, rule 5 with no calls, ltrmix_absent.py

Date: 2026-11-14 (09:51-10:15). Reviewer read-only on sim/, runs/ and lq/; probes wrote only to
`/tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3t11p-review`
(below: `REV`). Probes used at most 7 processes (6 score threads plus the main process) and 1 process otherwise, each under 2 min.
Paths: `SIM=/data2/chris/maize_introgression/benchmark_pav/plan3/sim`.

## Spec Compliance

**Verdict: ✅ compliant with the brief as amended by rulings R4 and "rule 5 with no calls". Nothing is missing or
misunderstood. Two items are ⚠️: one ruling clause has no field, and the mutation and red-first runs were not re-run.**

### The package and the global constraints
- ✅ **The package is a faithful view.** The live sha256s of all 10 files equal the package header. I applied the
  package with `patch -p1` to the implementer's base copies, whose sha256s are 6fbe0794, 3287f3d0, c0c9dd3a, 3b449b85
  and 1768cc3b (the values sim/memo.md:218-223 recorded before Part P). The result matches all 10 live files byte for
  byte (`cmp`).
- ✅ **Protected files are unchanged.** RULES.md 4111826d...a293, run_one.sh e4136cd6, run_grid.sh 03d3a03d,
  common/env.sh 5728e569, lq/run_lq.sh 146d7bb9, evalib.py f9f61a20 and make_grid.py 5c6a541b all match.
- ✅ **memo.md records every change.** Its entry "Scoring fixes after the Part P smoke test" (sim/memo.md:271-300)
  lists each scoring change with old and new sha256s and a one-line reason: eval_run.py, eval_ltrmix.py,
  summarize.py, ltrmix_absent.py, rescore_all.sh and the four test files. It also corrects the Task 9 "62%" gotcha by
  appending, without editing the old text.
- ✅ **Nothing else was written in sim/.** The files changed since 08:20 are exactly the listed ones, plus the
  runners' logs and lq/. No `sim/rescore` exists, `sim/tables` is still dated 2026-11-13 03:58, and there is no
  `__pycache__` or `.pytest_cache`.
- ✅ **American English and no AI attribution.** I grepped every new and changed file, and the memo entry.

### Brief §1: `sim/rescore_all.sh`
- ✅ **Run set.** It takes every grid.tsv row with run.done and every finished `lq/<name>`, never the `*.100Mb`
  copies. Runs without run.done are listed, not fatal. An unknown `--names` entry exits 2.
  - My dry run, with logs and tables pointed at REV, selected 119 of 147, including lq/null_s101 and lq/null_s102.
  - It created neither directory.
- ✅ **Eval step.** It runs the same two commands as run_one.sh:162-163, in the run directory, under env.sh
  (rescore_all.sh:89-90).
  - It takes the same `RUNDIR/.lock` as run_one.sh:194-195.
  - run_one.sh writes run.done only at the end of a chain (run_one.sh:203, 237), so a run in progress is never
    rescored.
- ✅ **Check.** It requires the run name, an mtime at or after the start, the sha256 of every script on disk, and
  eval_ltrmix.json's `inputs.eval.json`. The `need` map matches the keys the files really record: eval.json has 5
  keys, eval_ltrmix.json has 3 plus `inputs.eval.json`, for grid and lq runs alike.
  - lq/null_s101's sim.done names `null_s101`, as its eval files do, so the check will pass for the LTRquest runs.
- ✅ **Outputs.** It writes a per-run log, rescore.log, check.out and check.err, rescore.exit and rescore.done.
  `--dry-run`, `--names` and `--no-summarize` work as described.
- ✅ **Default `--jobs 4`** (rescore_all.sh:39), per ruling R4. This supersedes the brief's 8.
  - Fix round 1 changed only that default, comments and the `--pa` argument. I diffed against the first version,
    7f514be2. So the earlier lock, failure, mismatch and parallel tests still apply.
- ✅ **The in-place test** of null_s101 and f0.18_Ta5000_r1 is reported (Part P, with the old scripts).

### Brief §2: the smoke test
- ✅ **Reported.** Wall time, sets loaded and the NA audit are in the report.
- ✅ **The two defects** were reported with reproductions and fixed only after the controller's rulings.

### Brief §3 and R4: `sim/ltrmix_absent.py`
- ✅ **Exhaustive and exclusive.** `classify` (ltrmix_absent.py:126-144) returns exactly one class per absent call:
  - E, D, O and G go by state;
  - P, S and T go through a total if-chain: in y's library gives c, or d when the two files disagree; annotated but
    not in the library gives d; otherwise S or T gives a and P gives b;
  - an unknown state is an error.

  `make_row` also asserts a + b + c + d = truth-present.
- ✅ **Library first** (ltrmix_absent.py:135), as "Ruling (cause order)" requires.
- ✅ **It reconciles with eval_ltrmix.** `reconcile` compares all 7 states and the pooled absent tp and fp. I ran it
  independently on null_s101:
  - absent calls 49,585 = E 18,769 + truth-present 18,973 + D/O/G 11,843;
  - c 13,757 (0.725), b 3,306, a 1,910, d 0; tp/fp 18,769 / 30,816;
  - all equal to the report's fix-round-1 table, and c_S_or_T 1,116 equals its "S or T copies".
- ✅ **Every kind, with `--pa`.** On all 116 finished grid runs (null, power, bneck, dropout, ptlike, reverse):
  - exit 0, 113 s, 119 MB, one process;
  - every run reconciled, d = 0 everywhere;
  - lq/null_s101 and lq/null_s102 listed "not attributed: coordinate-joined libraries";
  - the null and power pools equal the report's.

  The report had exercised `--pa` on the null and power kinds only.
- ✅ **The c/d split is meaningful on real data.** In null_s101's A1/B1 ortholog files, 1,743 of 1,743 partner names
  resolve to record names, and all 1,743 pairs are reciprocal. So d = 0 is genuine, not a format mismatch.
- ✅ **One binary truth for both tools.**
  - The class map `READINGS` is shared (ltrmix_absent.py:86-87).
  - Per-pair truth-state equality is enforced (ltrmix_absent.py:294).
  - In every row of my all-runs table, n_scored and n_excluded are identical across LTRmix, LTRpav `all` and LTRpav
    `high`.
  - strict_E is reconciled with eval_ltrmix's own counts (ltrmix_absent.py:304-317), and the `reading` column labels
    both readings.
- ✅ **The fixture tests are right.** I re-derived the fixture's EXPECTED, TOTALS, PA and NEITHER by hand from its
  tables; all are correct.

### R4: the empty A1 truth, and "rule 5 with no calls"
- ✅ **The realized FDR when the truth is empty** (eval_run.py:581-595, 621; eval_ltrmix.py:393-404). In my mirror
  rescore of f0.02_Ta50_r2, `tract_fdr_q05` reads {0, 0, NA "no tract at q <= 0.05"} in all four models and in both
  LTRmix modes. The blocks carry exactly the keys of the normal blocks.
- ✅ **Recall is NA for both tools, whatever the recipient** (eval_run.py:662-665, eval_ltrmix.py:369-371).
  - In my mirror rescore of f0.02_Ta50_r1, LTRpav's head-to-head goes from `all.bp_recall` 0.0 to accuracy NA (empty
    truth).
  - LTRmix is NA before and after, with only its 6 volatile fields changed. wrong_recipient is 1 for both.
- ✅ **Rule 5's pooled FDR reads all 36 runs.** In the C>A power runs `models.<m>.accuracy` is now always a dict.
- ✅ **No calls reads FAIL, never NA** (summarize.py:932-938). The no-calls branch comes after `nc.short`.
  - A stale, failed or absent eval loads as None (summarize.py:326-351), so it counts as missing.
  - The FAIL therefore cannot fire with a run missing or NA. The new test covers the missing case.
  - In the data, `any` and `decoy` have 0 q <= 0.05 tracts in all 36 runs; `main` and `anydecoy` have one run each.
  - The ruling reads the Clopper-Pearson clause as written (n = 0 gives the interval [0, 1]), so the bar's meaning
    is unchanged.
- ✅ **LTRquest runs** are listed as not attributed. The section 7 table is a later deliverable.
- ⚠️ **"(and the all-q FDR)" has no field.** The ledger's "Ruling (defect 1)" asks to record tract_fdr_q05 "(and the
  all-q FDR)". Neither tool's accuracy schema has an all-q FDR field for a non-empty truth either. The fix records
  `all.n_called` only, from which the all-q FDR follows (n_false = n_called). The report does not say how it read
  the clause. No reader exists in summarize.py.
- ⚠️ **Not re-run** (by instruction): the mutant runs (22 of 22, 3 of 3), the red-first runs and the 64-pass suite. I
  read each new test against the code instead (part 2).

### Spot-checks of "nothing else changed"
I built scratch mirrors in REV/mirror: the real run inputs symlinked, with an own `eval/`. Both scripts write only
under `RUN/eval/` (eval_run.py:1106-1108, 942; eval_ltrmix.py:707-709). I ran the installed eval_run.py
(`--threads 6`) and eval_ltrmix.py, then diffed leaf by leaf against the grid's old-script eval files
(REV/diff_eval.py; outputs in REV/diff_*.txt).
- **f0.50_Ta500_r2** (non-empty truth, both tools infer A1):
  - eval.json differs in 5 leaves (created, elapsed_s, run_dir, the two script sha256s);
  - eval_ltrmix.json differs in 6 (those, plus design.source and inputs.eval.json);
  - the 72 score files are byte-identical.

  This independently confirms one of the report's "34 of 36 identical".
- **f0.02_Ta50_r2 and r1** (empty truth): every changed leaf outside the volatile fields lies in `models.<m>.accuracy`,
  `head_to_head.paint.accuracy`, LTRmix's `paint.<mode>.{accuracy, n_tracts_q05_file}`, or their `na` entries. The
  score files are byte-identical.
- The real runs' `eval/` directories are untouched (mtimes Nov 13).
- The 6 grid runs scored after the 09:39 install record 3fb7a8c3 and 9de7eab6, all with run.exit 0.

## Strengths
- The fixes are minimal and symmetric. Both tools gained the same empty-truth block, built from the same
  `evalib.tract_fdr(..., {})` call with the same reasons, and the head-to-head checks the empty truth before the
  wrong-recipient branch in both scripts.
- ltrmix_absent.py imports eval_ltrmix's own join, so it does not reimplement the scoring. It also enforces
  reconciliation per truth state and per tier set, and fails rather than guessing. A whole class of silent divergence
  is closed.
- The test fixture is a real hand-worked table: 17 elements covering every cause and sub-count, both readings and the
  neither counts. Every value checks out by hand, and the failure tests (a tampered confusion cell, unequal truth, an
  LTRpav or LTRmix strict mismatch, a coordinate join) each have a test.
- rescore_all.sh handles the hard edges carefully:
  - explicit exits inside `||` subshells;
  - per-run locks shared with run_one.sh, and an output-dir lock;
  - an EXIT trap set only after the lock;
  - no tables after any failure;
  - a staleness check that matches summarize's own.
- The install was disciplined: development in a scratch copy, atomic moves, refusal if a live file had changed, and
  a live check that the first post-install run succeeded. The report discloses its own process slips (a mid-run edit
  of a scratch script).
- The report corrected the R1 premise (62% not-E, about 38% truly present) with a reconciled count, instead of
  attributing the wrong number.

## Issues

### Critical
None.

### Important
None.

### Minor
- **m1: two presence/absence head-to-heads, one unlabeled** (summarize.py:1410-1426).
  - **What.** genotype.tsv's "ltrmix pairs" rows already print a head-to-head on the strict E-only classes (absent =
    E). They are not labeled as strict, and the binary reading is absent there. The ruled table, with both readings
    labeled, is pa_readings.tsv (written by ltrmix_absent.py).
  - **Why it matters.** A reader of genotype.tsv sees LTRmix's absent precision 0.38 with no hint of the ruled
    binary 0.60.
  - **Fix.** Have SIM_RESULTS cite pa_readings.tsv for the head-to-head and say that genotype.tsv's rows are
    strict_E, or label those rows in summarize.py (a scoring change, so a memo entry).
- **m2: bp fields NA where their values are defined** (eval_run.py:589-590; eval_ltrmix.py:399-400).
  - **What.** With an empty truth, `bp_called` and `bp_true_positive` (0) are NA, although defined. bp precision,
    0 when calls exist, is NA as the ruling says.
  - **Effect.** tracts.tsv's pooled bp precision (summarize.py:806-810) leaves out the false-positive bp of those
    runs, while the tract FDR counts their false tracts. This is unchanged from before the fix, applies alike to
    both tools, and no bar is affected: both runs have 0 tracts at q <= 0.05, and the bars read q <= 0.05 only.
  - **Fix.** A reading for the controller to confirm or reverse. If kept, note in SIM_RESULTS that pooled bp precision
    excludes runs with no true tract.
- **m3: run counts include runs that add nothing** (summarize.py:790, 795).
  - **What.** `n_scored`, and the run count `n` of the pooled bp rows, now include right-recipient empty-truth runs
    that add 0 bp. The implementer disclosed this as concern 3.
  - **Fix.** Add a note to tracts.tsv's n_scored ("includes runs with no true tract") when SIM_RESULTS uses it.
- **m4: rule 5 never checks the size of the power set** (summarize.py:929-938).
  - **What.** Unlike `count_bar`'s `required`, rule 5 never checks that the C>A power set holds 36 runs. An empty set
    would now read FAIL "in any of the 0 C>A power runs" (before the fix: NA).
  - **Why.** This is unreachable with the frozen grid.
  - **Fix.** Optional: treat `nc.n_required == 0` as NA.
- **m5: a missing option value exits 1, not 2** (rescore_all.sh:42-45).
  - **What.** `--jobs` (or `--names`, `--logdir`, `--tables`) without a value exits 1 through `${2:?}`, but the header
    documents usage errors as exit 2. I checked: `--dry-run --jobs` exits 1.
  - **Fix.** Use `[[ $# -ge 2 ]] || usage`.
- **m6: with `--names`, the tables cover different run sets** (rescore_all.sh:214-223; ltrmix_absent.py:389-408).
  - **What.** With `--names` and without `--no-summarize`, the tables step reads every finished run. summarize treats
    runs not rescored as stale (missing), while ltrmix_absent.py, which has no staleness check, reads them.
  - **Effect.** The two tables then cover different run sets. The presence/absence numbers are unaffected (unchanged
    code, reconciled).
  - **Fix.** Warn or skip the tables when `--names` is given, or document the combination.
- **m7: test gaps.** No test covers:
  - (a) the empty-truth branch of eval_ltrmix.py:394 when `elements` is None;
  - (b) eval_run.py's sheet-order "wrong" recipient (R = A1, source "sheet order") with an empty truth;
  - (c) in the no-calls test, a present-but-NA run (only a missing run is tested).

  The code paths are shared or ordered correctly, so these are coverage gaps, not bugs.
- **m8: a missing blank line** (test_summarize.py:554). There is one blank line before `def
  test_rule6_decided_with_missing_runs` (ruff E302). It is the only lint finding the change introduces. Ruff's E402
  and E501 hits are pre-existing or follow the codebase's `sys.path` pattern.

### Outside the diff (pre-existing; for the controller's awareness)
- **summarize.py:959.** With no informative pair, the precision sign test passes vacuously (p_less 1.0). So bars.tsv
  will show "any (decoy): bp precision at q <= 0.05 vs default: PASS (+0 -0)" beside the no-calls FDR FAIL.
  - This has no effect on adoption, since recall and the FDR fail.
  - It reads against the reasoning of the ruling "rule 5 with no calls" ("the bar demands evidence").

## Checks I ran (scratch outputs in REV)
1. **sha256 checks.** I compared the sha256s of the 10 package files and 7 protected files with the package header and
   memo.md. Then I applied the package (`patch -p1`) to the base copies and compared the result with the live files
   (`cmp`): 10 of 10 the same.
2. **Mirror rescore.** I rescored f0.50_Ta500_r2, f0.02_Ta50_r2 and f0.02_Ta50_r1 in a mirror (REV/mirror_eval.sh,
   16-18 s each) and diffed leaf by leaf against the grid's eval files (REV/diff_eval.py; REV/diff_*.txt). Results are
   as above.
3. **`ltrmix_absent.py` on two runs** (null_s101 and the mirror's f0.02_Ta50_r2), with `--pa` (REV/absent.tsv,
   REV/pa.tsv). The sums, the reconciliation and the one-truth check pass.
4. **`ltrmix_absent.py` over every finished run**, with `--pa` (REV/all_absent.tsv, REV/all_pa.tsv,
   REV/all_absent.err): exit 0, 116 grid runs, 2 runs not attributed, d = 0.
5. **Partner format and reciprocity** in null_s101's orthologs.A1.B1 and orthologs.B1.A1.
6. **`rescore_all.sh --dry-run`** into REV (nothing created), plus the usage exit codes.
7. **Readers of the changed fields.** Only summarize.py reads `accuracy` or `tract_fdr_q05` in plan3. `tract_rows`,
   `q05`, `paired` and `rule5` handle the new dict with NA fields through `is not None` and `or 0`.
8. **Stale eval files load as missing** in summarize, so the no-calls FAIL needs all 36 runs current.
9. **q <= 0.05 tract counts** per model over the 36 C>A power runs (read from eval.json).
10. **Lint and syntax.** `ruff check --select E,F,W --line-length 120` on the changed Python files, and `bash -n` on
    rescore_all.sh.
11. **Stray writes.** Files changed in sim/ since 08:20, and the mtimes of `sim/tables`.

## Assessment
**Task quality:** Approved

**Reasoning:** Every brief item and every R4 and "rule 5 with no calls" ruling is implemented as written. I
confirmed that independently:
- the empty-truth fixes are symmetric for both tools on real runs;
- the non-empty output is unchanged apart from volatile fields;
- the cause attribution reconciles over all 116 finished runs of every kind.

The remaining items are Minor: labeling, counts, edge-case robustness and coverage.
