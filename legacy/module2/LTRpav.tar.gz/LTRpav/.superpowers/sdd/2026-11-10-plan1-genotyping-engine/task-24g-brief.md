# Task 24G: present calls must be anchored at their site (classifier rule 5a)

Inserted by controller ruling before the bake-off reruns.

## Why
An inspection of real chr10 disputes, in `inspect-disputes-report.md` in this directory, found a classifier defect.
Read Q5 there: the defect, the frozen proposal and its single measurement.

- **The defect.** Rule 5 (`classify._present`) calls P, S or T whenever >= MIN_SEG of the element's own bases align
  anywhere in the window's alignment chain. Nothing ties those bases to the element's flanks. E, by contrast, needs
  both gap edges within ±w.
- **The trigger.** In wide windows, `localign._chain` (maximum matched bases) can route the element through a
  same-family copy that lies between distant flank images. The result is a present call on a paralog, and nested
  elements are then read inside that wrong host.
- **On real chr10:**
  - 427 own P/S/T calls are unanchored. A's TSD flanks the B image at 2% of them, against 98% of anchored calls.
  - With nested calls included, 11% of the syntenic run's resolved calls are affected.
- **In the sims,** 36 of the 46 false present calls come from this defect.

## Requirement: implement the frozen rule exactly
The prototype is the monkeypatch of `_present` in
`/data2/chris/maize_introgression/benchmark_pav/bakeoff/inspect_disputes/measure_5a.py`. Port its logic into
`src/ltrpav/classify.py`; do not reinvent it.

**Rule 5a.** A P, S or T call needs the element's own aligned bases joined to its flank on at least one side:
1. Some AlnMap run (segments joined across A and B gaps < MIN_SEG, the runs `gap_around` already reads) crosses
   the element's start or end and holds >= MIN_SEG aligned A bases outside the element on that side.
2. If no run does, the call stands only if B's bases beside the element's image match an A TSD copy on both sides
   within `tsd_allowance`. This is the solo_tsd read that S already uses.
3. Otherwise the element is U, with reason `unanchored`. Rule 0 passes the U to its nested elements as it passes
   any host U (state U plus `inherit`).
4. There is no new constant.

## Also
- Update the `classify.py` module docstring to add rule 5a to the rule list.
- Update DESIGN.md where the classifier rules and U reasons are described, so that rule 5a and the `unanchored`
  reason appear in DESIGN 5.4 or wherever rule 5 lives.
- Keep every other rule unchanged. Rule 4g (O for B-only sequence >= MIN_SEG) stays as is, per controller ruling:
  DESIGN's O includes complex events, and the calls file's dl, dr and b_ins already let analyses separate O at the
  site from complex O.

## Tests (small synthetic fixtures; `tests/test_classify.py` and `tests/toy.py`)
- **Anchored on one side:** an element present with its aligned bases joined to the left flank only (a
  right-side truncation, or an adjacent insertion breaking the right junction) keeps its P or T call.
- **Unanchored:**
  - the element's bases align only to a same-family copy elsewhere in the B window;
  - the flanks align at their own images on both sides;
  - B has no TSD beside the copy.

  Expect U with reason `unanchored`.
- **The TSD exception:** the same geometry, but B's bases on both sides of the copy match A's TSD. The call stands.
- **Inheritance:** an element nested in an unanchored host is U with `inherit`.
- **Existing cases:** every existing toy case (`tests/toy.py`, all seeds) and classifier test stays green. If one
  changes, explain why in the report. Do not loosen the rule to keep a test.
- **The suite:** run it in full under `-W error`, and `ruff check .` from the repo root. Both must be clean.

## Constraints
- **The repo has one writer: you.** A read-only reviewer of Task 24F (commit 8dfc012) may still be running a
  focused probe. Keep the tree importable between edits, and commit once at the end.
- Commit with the subject "Require present calls to be anchored at their site". Use the existing git identity, set
  nothing, and add no trailers or AI attribution of any kind: the user is the sole author. Do not push.
- **Probes:** at most 8 threads, `timeout 15m`, foreground. Export `NUMPY_MADVISE_HUGEPAGE=0`. Use env
  `ltrpav_bench` (`/home/chris/bin/mambaforge/envs/ltrpav_bench/bin/python`).
- No subagents. American English.

## Check outside the suite (no full runs)
The prototype measured the rule on 15 datasets. Reproduce one of them with the real code: pick one of its sim
datasets and reclassify with rule 5a. The 43 sim calls the report says change to U include that dataset's share;
match the prototype's per-dataset counts exactly, and say which dataset you used. Read `measure_5a.py` and the
inspector's `memo.md` (same directory) for how it reclassified from one alignment. Explain any difference.

## Report
Write `task-24g-report.md` in this directory: what changed, test summary, the reproduction check, deviations.

Return ONLY:
- status;
- the commit;
- a one-line test summary;
- the reproduction check in one line;
- concerns.
