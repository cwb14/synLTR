# Task 16A report: compare_papers' final edits, final_papers.tsv, the PRELIM diff, FINAL.md

Status: DONE_WITH_CONCERNS (concerns are scope calls for the controller; no analysis defect found).
Date 2026-11-14, 17:36-18:20 EST. Snapshot 2 (SNAP_SHA=6282541 via common/env.sh) for every run; at most 2
single-threaded processes at once; no command over 2 min; nothing killed; `compare_papers.py` untouched (Task 15).
P=/data2/chris/maize_introgression; R=$P/benchmark_pav/plan3/real.

## 1. The edits (`$R/common/compare_papers.next.py`)

- Old: `$R/common/compare_papers.py` sha256 **1e04f43ed8df53db7dab8c8b667726bdc90402da2fece7d7c20171ca490d334a**
  (unchanged; Task 15 is running it).
- New: `$R/common/compare_papers.next.py` sha256 **47d2c20dc926a253094e815c8a0ef52dcc4f0060f4a7a58dc353fbd878a02145**
  (record this as compare_papers.py's new sha256 after the move).
- Tests: `$R/common/test_compare_papers.py` (sha256 d8fcd79d...a097, 19 tests); green log `test_compare_papers.out`
  (19 passed, `-W error`; its first line records the module's sha256); red logs `test_compare_papers.red.out`. The test
  module imports `compare_papers.next.py` while it exists, else `compare_papers.py`, so after the move it tests the
  moved file with no edit. Run: `cd $R/common && SNAP_SHA=6282541 bash -c '. ../../common/env.sh; python -m pytest -q
  -p no:cacheprovider test_compare_papers.py'`.

What changed (docstring "History" lists the same):
1. **Verdict constants** `PASS, MISS = "PASS", "MISS"`.
2. **New input `--sim`** (default `$P/benchmark_pav/plan3/sim`), `load_sim()`: reads `sim/tables/{bars,null,calibration,
   direction}.tsv` (rule 1 rows "D_pav all, pre-declared trio, the 30 nulls" and "D_pav (bottleneck nulls)"; rule 2 rows
   D_pav and dD; LTRmix's null and calibration rows; the `pt` direction row) and the per-run values the tables only
   summarize, from `sim/runs/{null_s,bn_null_s}<digits>/eval/eval.json` (as Task 13's reviewed score_six.py did):
   D_pav's Z (stratum all), its n, the K=0 n, and dD's Z (None if untestable). Fail-fast check: the per-run Z must
   reproduce null.tsv's run count, |Z| > 3 count, mean and SD (to 1e-4) for both null sets; it does (30 runs each; default
   mean +0.0720, SD 0.7173, 0 > 3; bottleneck −0.3160, 1.2944, 1). `null_quantile()`: k of n with |Z| ≥ |Z_obs|, max and
   95th percentile of |Z| (numpy linear), empirical p (k+1)/(n+1). Reproduces SIM_RESULTS: default max 1.97, p95 1.36;
   bottleneck max 3.14, p95 2.74.
3. **D_pav row** (section 2): bar kept, "D > 0, Z > 3". Cell adds "simulated nulls reaching |Z| 7.39: 0 of 30 default
   (max |Z| 1.97), 0 of 30 bottleneck (max |Z| 3.14); empirical p 0.032 and 0.032"; note gives rule 1 (PASS, 0 of 30),
   rule 2 ("not calibrated", SD 0.717, 95% 0.571-0.964) and says the verdict rests on the bottleneck nulls (ruling I4).
   Verdict rule (`dpav_verdict`): PASS iff D > 0 and Z > 3 and (rule 2 reads "calibrated" or no bottleneck null reaches
   |Z|), else MISS. My reading of "rests on the bottleneck null"; with 30 nulls it equals a bottleneck empirical p of
   1/31 (and p < 0.05); it matches Task 13's "holds there" reading. Real Z 7.39 passes either way.
4. **Three new rows** beside it (section 2, before the check strata; verdict "reported", the simulation bar's own
   outcome quoted in the cell): "simulated null of D_pav: rule 1" (with LTRmix's four D: 0 of 30 each; bottleneck
   D_self 1 of 30), "calibration of D_pav's null Z: rule 2 (a reading)" (LTRmix's four: calibrated), "empirical null
   distribution of D_pav's Z" (both sets' mean, SD, p95 and max of |Z|, k and p).
5. **dD** (R2): both gradient rows keep PRELIM's bar ("excess concentrated in young insertions") and verdict
   ("reported") and add the caveat "no simulated null of dD is available (rule 2: not demonstrated; dD testable in 1 of
   30 nulls ...), so its Z is the block jackknife's alone, not a calibrated test". New row "simulated null of dD: rule 2
   (a reading)": "not available: dD is testable in 1 of 30 default nulls (29 NA) and 3 of 30 bottleneck nulls;
   calibration not demonstrated", with SIM_RESULTS section 1's reason (K=0 holds 0-6 informative loci per null, mean 1.2
   of 301, from eval.json; this view 40, n_RD 32, n_SD 8). No null invented. (`calibration_reading()` turns the
   table's NA, n_used < n_required, into SIM_RESULTS' "not demonstrated".)
6. **Roles misread** (R2): `trio_sharing()` reads only the sharing rows whose scope names the declared trio's genomes
   (fatal error unless exactly one scope); the note says "roles fixed by --trio; the trio's own sharing rows and the sign
   of D_pav (+0.2898) agree with them" (or "DO NOT agree"), not "roles are inferred, never set", which was false under
   --trio; the source-"data" wording is unchanged (main3 gives a byte-identical row).
7. **Direction misread** (R2): reads the view's DFOIL-alt quartet of the recipient's and donor's taxa (four statistics,
   sign code, call), D_dir of that taxon pair, the view's status line from findings.txt ("direction is exploratory
   (DESIGN 7.6): not validated by simulation (Plan 3)"; else the rows' note), the PT-like reading from
   sim/tables/direction.tsv (predicted none, read in 3 of 3), and the other taxon pairs named as the view's D_dir rows
   name them. Verdict "reported" (exploratory, not validated: neither PASS nor MISS). A view without direction rows still
   gives PRELIM's "skipped" row (main3: byte-identical).
8. **`--prefix` on the cross-check** (Task 14): `<prefix>_ltrmix_crosscheck.tsv` (`output_paths()`); `--prefix` help
   updated; the tables dir is now made with `parents=True`.
9. **Two more six-genome misreads, beyond R2's list** (concern 1): row "4 amount"'s note said "no second donor in
   main3, so no f4-ratio"; it now quotes the view's own f4 line from findings.txt (`amount_note()`; an estimated f4 is
   named as the estimate). Row "multi-element absences, the six ingroup pairs pooled" pooled 30 directed pairs in a
   six-ingroup view; the item now names its count, "the 30 directed ingroup pairs pooled" (main3: "the 6 ...").

Method. First a behavior-preserving refactor: the rows to change became functions with their final signatures
(`output_paths, dpav_row, add_roles, add_admixture, add_gradient_own, add_gradient_mix, amount_note, mech_pooled_item,
add_direction`). Rerun on six/views/main into scratch with Task 13's `--prefix six_main`: six_main_papers.tsv,
ltrmix_crosscheck.tsv and both tables **byte-identical** to Task 13's (sha256 77f95239... both). Then tests, then fixes.

TDD evidence (`test_compare_papers.red.out`):
- Red phase 1 (refactored module, sha256 ea95e18d...cff6, before any fix): 17 failed, 2 passed (the two guards that
  must hold before and after: PRELIM's "data"-source roles wording; "skipped" direction without rows). Each failure is
  for its intended reason: constants `'PASS (prelim)' == 'PASS'`; cross-check name `'ltrmix_crosscheck.tsv' ==
  'final_ltrmix_crosscheck.tsv'`; roles read "sisters TIL11 + TIL01"; the disagree case lacks "DO NOT agree"; no
  SystemExit without the trio's rows; `null_quantile`, `dpav_verdict`, `load_sim` missing (1 + 1 + 3 tests, the
  new features); the D_pav primary-row tests (3) fail on the old label and, with a bottleneck null at |Z| 3.14 and Z
  3.10, on `'PASS (prelim)' == 'MISS'`; the dD test got 2 rows, not 3; the amount note contains "main3"; the pooled
  item reads "six"; direction `'skipped' == 'reported'`. (One fixture change after red, no assertion changed: the
  fake LTRmix calibration rows gained the real table's n_used/n_required columns.)
- Green after the fixes: 19 passed.
- Red phase 2 (two late fixes after reviewing the trial output: the roles note repeated the engine's note under
  --trio, and the third taxon pair was named "parviglumis>mexicana" from the DFOIL quartet's order while the engine
  names it "mexicana>parviglumis"): the extended tests run on a scratch copy with the earlier implementations restored
  fail (2 failed, 17 passed); on the final module 19 passed.
- Lint: `ruff --select F,E9,B` gives the same 8 findings as the original file (all PRELIM's own: B905, 3 B007, 4 B023);
  the test file and diff_prelim.py are clean.

## 2. The run and final_papers.tsv's verdicts

```bash
cd $R && SNAP_SHA=6282541 bash -c '. ../common/env.sh; export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
python common/compare_papers.next.py --run papers/views/main --prefix final'   # log papers/logs/compare_papers.*
```
1:39 wall, 1.19 GB, exit 0. Wrote only `papers/views/main/{final_papers.tsv, final_tables/, final_ltrmix_crosscheck.tsv}`
(listing before/after compared; inputs/*.fai unchanged against papers/logs/fai.after.tsv). final_papers.tsv sha256
19016fae...93ef9.

**152 rows: PASS 19, MISS 5, reported 128, skipped 0.**
- PASS: D_pav(B73,TIL01;TIL18) +0.2898 ± 0.0392, Z 7.39 (1,313/723; 0 of 30 default and 0 of 30 bottleneck nulls reach
  it); chromosomes by posterior mean ×2 (chr5, chr8, chr9); windows vs ELAI at 1, 2, 5, 10 Mb ×16 (r 0.256-0.383,
  p 0.001).
- MISS: chromosomes by class share ×2 (chr4, chr5, chr9); ZmPRR37a ±50 kb; 52 high-frequency regions ×2 (p 0.386, 0.374).
- Direction: reported (DFOIL-alt B73,PT;TIL25,TIL18 code 0000 "none"; D_dir +0.064, Z 0.90).
- final_ltrmix_crosscheck.tsv: byte-identical to main3's ltrmix_crosscheck.tsv (equal 58, different 1: the HF p).

Control (to separate the script's edits from the view's changes): the final script on main3,
`--run ../../main3_analyses --prefix main3 --out papers/control_main3` (1:19, exit 0; log papers/logs/control_main3.*):
113 rows, PASS 19, MISS 5, reported 88, skipped 1; its roles and direction rows equal PRELIM's.

## 3. The PRELIM diff

`$R/papers/final_vs_prelim.tsv` (made by `$R/papers/diff_prelim.py`; one row per row of PRELIM or final, with status,
columns changed, the columns the script edits change (PRELIM vs control) and the view changes (control vs final),
cause codes and both cells):
`cd $R/papers && python diff_prelim.py ../../../main3_analyses/prelim_papers.tsv control_main3/main3_papers.tsv
views/main/final_papers.tsv final_vs_prelim.tsv`.

PRELIM 109 rows; final 152. **Same 25, changed 78, removed 6, added 49** (4 by the script, 45 by the view). **No verdict
flipped**: 19 PASS (prelim) -> PASS, 5 MISS (prelim) -> MISS, 1 skipped -> reported (direction). No LTRmix cell and no
bar column changed. Main3 was engine 7d71073 (genotypes) with analyses at 12d3e6c; the final view is six/geno
(genotyped at 12d3e6c) analyzed at 6282541.

Cause codes (diff_prelim.py's header): script edits E1 verdict labels (24 rows), E2 D_pav row's null (1), E3 new
simulated-null rows (4), E4 dD caveat (2), E5 f4 status (1), E6 pooled pair count (1), E7 roles (1), E8 direction (1);
the view W1 loci merged across seven genomes (56), W2 roles fixed by --trio (1), W3 six ingroup genomes (42), W4
inversion blocks with more loci (21), W5 identity layer rerun (5). Combinations: E1 only 5; E1+W1 18; E1+E2+W1 1; E3 4;
E4+W1 2; E5+W1 1; E6+W3 1; E7+W2+W1 1; E8+W3 1; W1 33; W3 40; W4 21; W5 5 (133 rows).

Why each view cause moves numbers:
- **W1, same calls, different loci.** In all 9 pair files among B73, TIL18, TIL01 and Zd, every element's state and tier
  in six/geno equals main3's (eid, state, tier compared for TIL18->B73, ->TIL01, ->Zd and B73->TIL18: 0 differences;
  whole files differ only in anchor_left/anchor_right, the per-element anchor distances added by a050213 after main3,
  66,518 of 124,641 rows in TIL18__B73). The 11 mechanism rows of these pairs are identical. But loci are merged across
  seven genomes (522,478) instead of four (322,538): D_pav counts 14,011 loci (14,067), n_RD/n_SD 1,313/723
  (1,317/724); B73 discovers 126,101 loci (126,853), 7,484 informative (7,515). Hence small shifts in sections 2-9
  (D_pav −0.0007, Z −0.03; dD +0.001; window r ≤ 0.003; AUROC −0.0005; spacing +0.7 kb; tracts −3; HF p +0.04). The
  analysis code between 12d3e6c and 6282541 changed no default (paint: PAINT_DISCOVERY "recipient", PAINT_EMISSION
  "em"; stats: an optional block-size override; direction: note text).
- **W2.** The final view sets roles with --trio (roles row source "--trio"); the trio's sharing rows and D_pav's sign
  agree.
- **W3.** Six ingroup genomes: direction testable; outgroup bound per genome uses 5 discovering genomes instead of 2
  (2.7-3.2% -> 3.3-4.0%; same definition, recount equals stats.tsv); new rows for PT, TIL25, TIL11 (3 outgroup, 24
  mechanism pairs, 10 inversion blocks); the pooled mechanisms row pools 30 directed pairs.
- **W4.** More genomes discover loci both genomes of a pair resolve, so blocks hold more loci (Inv4m B73~TIL18 464 ->
  700, right end 188.08 -> 188.14 Mb, coverage 0.997 -> 1.000; B73~TIL01 170.43-183.12 679 -> 879); two B73~TIL01
  blocks near 161-170 Mb split in two each; B73~Zd 172.83 -> 172.84; Inv1n B73~TIL18 106.85-106.94 -> 106.90-106.96;
  Inv1n B73~TIL01 103.25-113.97 -> 90.51-114.28 (coverage 0.979 -> 0.986, 3 -> 2 blocks); all-pair block count 417 ->
  1,888 (21 genome pairs).
- **W5.** --identity rerun on the new loci: TIL01-TIL18 pairs 23,779 -> 23,118; s 0.0742% -> 0.0720% (0.24 SE); s_mix
  0.0822% -> 0.0784%; B73-TIL18 pairs below s 8.2% -> 7.9%.

Every changed, added and removed row, with its causes and its LTRpav cell before -> after (the TSV has every column):

**1 roles**
- sister pair, donor, recipient (from the data) [E7,W2,W1]: `sisters B73 + TIL01 (maize + parviglumis); donor TIL18 (mexicana); recipient B73 (maize, by the sign of D_p...` -> `sisters B73 + TIL01 (maize + parviglumis); donor TIL18 (mexicana); recipient B73 (maize, by the sign of D_p...`; note;

**2 admixture in B73**
- D_pav(B73,TIL01;TIL18) all (primary) [E1,E2,W1]: verdict PASS (prelim) -> PASS; `+0.2905 +- 0.0392 (Z 7.42); n_RD 1317, n_SD 724` -> `+0.2898 +- 0.0392 (Z 7.39); n_RD 1313, n_SD 723; simulated nulls reaching /Z/ 7.39: 0 of 30 default (max /Z...`; note;
- D_pav high_tier [W1]: `+0.3049 +- 0.0423 (Z 7.21); n_RD 1162, n_SD 619` -> `+0.3041 +- 0.0423 (Z 7.18); n_RD 1158, n_SD 618`;
- D_pav nested_collapsed [W1]: `+0.2793 +- 0.0382 (Z 7.30); n_RD 1136, n_SD 640` -> `+0.2789 +- 0.0383 (Z 7.29); n_RD 1135, n_SD 640`;
- D_pav no_outgroup_filter [W1]: `+0.2959 +- 0.0330 (Z 8.96); n_RD 2840, n_SD 1543` -> `+0.2985 +- 0.0331 (Z 9.03); n_RD 2832, n_SD 1530`;
- outgroup filter and resolution symmetry [W1]: `removed 0.809 of 123019 candidates; resolved B73 0.728, TIL01 0.710` -> `removed 0.807 of 121500 candidates; resolved B73 0.728, TIL01 0.710`; note;

**3 gene flow, not lineage sorting**
- recount check: D_pav all from the catalog [W1]: `+0.2905 (Z 7.42); n_RD 1317, n_SD 724; 425 blocks of 5,000,000 bp` -> `+0.2898 (Z 7.39); n_RD 1313, n_SD 723; 425 blocks of 5,000,000 bp`;
- D_pav K>=0.01 (LTRpav's bins, K2P of TIL18's copy) [W1]: `+0.2032 +- 0.0400 (Z 5.08); n_RD 965, n_SD 639` -> `+0.2020 +- 0.0401 (Z 5.04); n_RD 961, n_SD 638`;
- gradient dD = D(K=0) - D(K>=0.01) (LTRpav's bins) [E4,W1]: `+0.3968 +- 0.1268 (Z 3.13)` -> `+0.3980 +- 0.1268 (Z 3.14)`; note;
- D in LTRmix's bins: K > 0.01 [W1]: `+0.2032 (Z 5.08); n_RD 965, n_SD 639` -> `+0.2020 (Z 5.04); n_RD 961, n_SD 638`;
- gradient dD = D(K=0) - D(K>0.01) (LTRmix's bins) [E4,W1]: `+0.3968 +- 0.1268 (Z 3.13)` -> `+0.3980 +- 0.1268 (Z 3.14)`; note;
- D_pav's candidate loci, sisters' absence read as verified: E only (the tool's) [W1]: `+0.2905 (Z 7.42); n_RD 1,317, n_SD 724; K=0 +0.600 (32/8); 0<K<0.01 +0.612 (320/77); K>=0.01 +0.203 (965/63...` -> `+0.2898 (Z 7.39); n_RD 1,313, n_SD 723; K=0 +0.600 (32/8); 0<K<0.01 +0.612 (320/77); K>=0.01 +0.202 (961/63...`;
- D_pav's candidate loci, sisters' absence read as library-style: E, D or O absent [W1]: `+0.2872 (Z 7.74); n_RD 1,869, n_SD 1,035; K=0 +0.644 (37/8); 0<K<0.01 +0.586 (437/114); K>=0.01 +0.209 (139...` -> `+0.2866 (Z 7.71); n_RD 1,863, n_SD 1,033; K=0 +0.644 (37/8); 0<K<0.01 +0.586 (437/114); K>=0.01 +0.208 (138...`;
- D_pav's candidate loci, sisters' absence read as library-style presence too: P present;... [W1]: `+0.2806 (Z 7.92); n_RD 1,896, n_SD 1,065; K=0 +0.610 (33/8); 0<K<0.01 +0.580 (421/112); K>=0.01 +0.208 (144...` -> `+0.2798 (Z 7.88); n_RD 1,889, n_SD 1,063; K=0 +0.610 (33/8); 0<K<0.01 +0.580 (421/112); K>=0.01 +0.207 (143...`;
- the patterns the library-style reading adds (the absent sister D or O) [W1]: `+0.2793 (Z 5.23); n_RD 552, n_SD 311` -> `+0.2791 (Z 5.21); n_RD 550, n_SD 310`;
- resolution of B73 and TIL01 among D_pav's candidates, by age [W1]: `K=0 0.748 / 0.730 (n 1,416); 0<K<0.01 0.691 / 0.681 (n 7,499); K>=0.01 0.746 / 0.724 (n 14,555); all 0.728 ...` -> `K=0 0.748 / 0.729 (n 1,415); 0<K<0.01 0.691 / 0.680 (n 7,488); K>=0.01 0.745 / 0.723 (n 14,486); all 0.728 ...`;

**4 amount**
- posterior mean of TIL18-like ancestry (unweighted) [E5,W1]: `0.3696 (recount 0.3696); decoy 0.3165; excess +0.0531` -> `0.3693 (recount 0.3693); decoy 0.3159; excess +0.0534`; note;
- posterior mean (span-weighted) [W1]: `0.3699; decoy 0.3161; excess +0.0538` -> `0.3696; decoy 0.3155; excess +0.0541`;

**5 chromosomes 5, 8, 9 depleted**
- three lowest by posterior mean (unweighted) [E1]: verdict PASS (prelim) -> PASS;
- three lowest by posterior mean (weighted) [E1]: verdict PASS (prelim) -> PASS;
- three lowest by class share (unweighted) [E1]: verdict MISS (prelim) -> MISS;
- three lowest by class share (weighted) [E1]: verdict MISS (prelim) -> MISS;

**6 ancestry along the genome**
- class share (unweighted) vs ELAI, 0.1 Mb windows [W1]: `r=+0.278, p=0.0010, n=3886` -> `r=+0.277, p=0.0010, n=3882`;
- class share (weighted) vs ELAI, 0.1 Mb windows [W1]: `r=+0.278, p=0.0010, n=3886` -> `r=+0.277, p=0.0010, n=3882`;
- posterior (unweighted) vs ELAI, 0.5 Mb windows [W1]: `r=+0.245, p=0.0010, n=4137` -> `r=+0.244, p=0.0010, n=4137`;
- class share (unweighted) vs ELAI, 0.5 Mb windows [W1]: `r=+0.244, p=0.0010, n=2560` -> `r=+0.244, p=0.0010, n=2557`;
- class share (weighted) vs ELAI, 0.5 Mb windows [W1]: `r=+0.244, p=0.0010, n=2560` -> `r=+0.244, p=0.0010, n=2557`;
- posterior (unweighted) vs ELAI, 1 Mb windows [E1]: verdict PASS (prelim) -> PASS;
- posterior (weighted) vs ELAI, 1 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.273, p=0.0010, n=2106` -> `r=+0.272, p=0.0010, n=2106`;
- class share (unweighted) vs ELAI, 1 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.258, p=0.0010, n=1739` -> `r=+0.258, p=0.0010, n=1736`;
- class share (weighted) vs ELAI, 1 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.256, p=0.0010, n=1739` -> `r=+0.256, p=0.0010, n=1736`;
- posterior (unweighted) vs ELAI, 2 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.287, p=0.0010, n=1065` -> `r=+0.286, p=0.0010, n=1065`;
- posterior (weighted) vs ELAI, 2 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.285, p=0.0010, n=1065` -> `r=+0.284, p=0.0010, n=1065`;
- class share (unweighted) vs ELAI, 2 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.281, p=0.0010, n=1018` -> `r=+0.280, p=0.0010, n=1018`;
- class share (weighted) vs ELAI, 2 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.279, p=0.0010, n=1018` -> `r=+0.278, p=0.0010, n=1018`;
- posterior (unweighted) vs ELAI, 5 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.331, p=0.0010, n=431` -> `r=+0.330, p=0.0010, n=431`;
- posterior (weighted) vs ELAI, 5 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.330, p=0.0010, n=431` -> `r=+0.328, p=0.0010, n=431`;
- class share (unweighted) vs ELAI, 5 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.336, p=0.0010, n=430` -> `r=+0.333, p=0.0010, n=430`;
- class share (weighted) vs ELAI, 5 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.333, p=0.0010, n=430` -> `r=+0.330, p=0.0010, n=430`;
- posterior (unweighted) vs ELAI, 10 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.380, p=0.0010, n=219` -> `r=+0.378, p=0.0010, n=219`;
- posterior (weighted) vs ELAI, 10 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.384, p=0.0010, n=219` -> `r=+0.383, p=0.0010, n=219`;
- class share (unweighted) vs ELAI, 10 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.374, p=0.0010, n=219` -> `r=+0.372, p=0.0010, n=219`;
- class share (weighted) vs ELAI, 10 Mb windows [E1,W1]: verdict PASS (prelim) -> PASS; `r=+0.375, p=0.0010, n=219` -> `r=+0.372, p=0.0010, n=219`;

**7 tract scale**
- element AUROC of the posterior, ELAI >= 1 vs <= 0.2 (+-20 kb, >= 3 SNPs) [W1]: `0.7123 (n_pos 2647, n_neg 26700)` -> `0.7118 (n_pos 2641, n_neg 26589)`;
- element AUROC of the posterior, ELAI >= 1.5 vs <= 0.2 (+-20 kb, >= 3 SNPs) [W1]: `0.7675 (n_pos 778, n_neg 26700)` -> `0.7675 (n_pos 776, n_neg 26589)`;
- recall of ELAI dosage > 1 runs <10 kb (n=1807) [W1]: `all tracts 0.310 (560 of 1807; chance 0.231, 1.3x, binomial p 1e-14); q <= 0.05 0.000 (no tract)` -> `all tracts 0.309 (559 of 1807; chance 0.231, 1.3x, binomial p 1.3e-14); q <= 0.05 0.000 (no tract)`;
- recall of ELAI dosage > 1 runs 10-100 kb (n=523) [W1]: `all tracts 0.419 (219 of 523; chance 0.246, 1.7x, binomial p 4.4e-18); q <= 0.05 0.000 (no tract)` -> `all tracts 0.419 (219 of 523; chance 0.246, 1.7x, binomial p 3.9e-18); q <= 0.05 0.000 (no tract)`;
- recall of ELAI dosage > 1 runs 100-500 kb (n=218) [W1]: `all tracts 0.486 (106 of 218; chance 0.304, 1.6x, binomial p 1.3e-08); q <= 0.05 0.000 (no tract)` -> `all tracts 0.482 (105 of 218; chance 0.303, 1.6x, binomial p 2.7e-08); q <= 0.05 0.000 (no tract)`;
- recall of ELAI dosage > 1 runs >=500 kb (n=10) [W1]: `all tracts 0.500 (5 of 10; chance 0.520, 1.0x, binomial p 0.67); q <= 0.05 0.000 (no tract)` -> `all tracts 0.500 (5 of 10; chance 0.518, 1.0x, binomial p 0.67); q <= 0.05 0.000 (no tract)`;
- ELAI dosage inside called tracts (all) [W1]: `764 tracts, 469 Mb: mean dosage/2 0.215 vs genome 0.170; dosage >= 1 0.091 vs 0.049` -> `761 tracts, 469 Mb: mean dosage/2 0.215 vs genome 0.170; dosage >= 1 0.091 vs 0.049`;
- resolution: informative-locus spacing (median, mean) [W1]: `84.4 kb, 283.1 kb (7,515 informative of 126,853 loci; recount 84.4 / 283.1 kb)` -> `85.1 kb, 284.3 kb (7,484 informative of 126,101 loci; recount 85.1 / 284.3 kb)`;
- shortest callable tract (lower, upper bound) [W1]: `1 locus / 84.4 kb; 1 locus / 84.4 kb` -> `1 locus / 85.1 kb; 1 locus / 85.1 kb`;
- mean_donor_run_bp (L / (1 - pi)) [W1]: `470.7 kb (pi 0.3591)` -> `470.6 kb (pi 0.3588)`;
- tracts called (decoy tracts; q <= 0.05) [W1]: `770 (599; 0)` -> `767 (596; 0)`;
- fitted emissions [W1]: `e1 (RD, RS) 0.9993, 0.0006761; e0 0.0004861, 0.9995; state 1 is TIL18-like when e1[RD] > e0[RD]` -> `e1 (RD, RS) 0.9993, 0.0006758; e0 0.0005021, 0.9995; state 1 is TIL18-like when e1[RD] > e0[RD]`;

**8 named loci**
- ZmPRR37a +-50 kb [E1,W1]: verdict MISS (prelim) -> MISS; `6 loci (missing 5, old 1); max posterior 0.160, mean 0.140; no tract` -> `6 loci (missing 5, old 1); max posterior 0.159, mean 0.140; no tract`;
- HPC1 +-50 kb [W1]: `7 loci (missing 5, old 2); max posterior 0.212, mean 0.203; no tract` -> `7 loci (missing 5, old 2); max posterior 0.212, mean 0.202; no tract`;
- ZmLPCAT1 +-50 kb [W1]: `7 loci (missing 7); max posterior 0.905, mean 0.854; 1 tract(s), smallest q 0.855 (R+D loci in it: 2)` -> `7 loci (missing 7); max posterior 0.905, mean 0.854; 1 tract(s), smallest q 0.86 (R+D loci in it: 2)`; note;
- ZmLPCAT1 +-200 kb [W1]: `26 loci (missing 13, both 10, RD 2, old 1); max posterior 1.000, mean 0.751; 1 tract(s), smallest q 0.855 (...` -> `26 loci (missing 13, both 10, RD 2, old 1); max posterior 1.000, mean 0.751; 1 tract(s), smallest q 0.86 (R...`; note;

**9 high-frequency regions**
- mean posterior within 50 kb of the 52 regions (unweighted) [E1,W1]: verdict MISS (prelim) -> MISS; `0.386 inside vs 0.369 outside; shift p=0.3427` -> `0.382 inside vs 0.369 outside; shift p=0.3856`;
- mean posterior within 50 kb of the 52 regions (weighted) [E1,W1]: verdict MISS (prelim) -> MISS; `0.388 inside vs 0.369 outside; shift p=0.3297` -> `0.384 inside vs 0.369 outside; shift p=0.3736`;

**10 inversions**
- Inv4m: block B73~TIL18 B73v5_chr4:171.28-171.50 Mb [W4]: `12 loci, 2 discordant, 11 strand-inverted; spans 0.22 Mb on B73 (53.8 loci/Mb), TIL18_chr4:179,272,877-179,...` -> `13 loci, 2 discordant, 11 strand-inverted; spans 0.22 Mb on B73 (58.3 loci/Mb), TIL18_chr4:179,272,877-179,...`;
- Inv4m: block B73~TIL18 B73v5_chr4:172.81-188.08 Mb [W4]: removed
- Inv4m: block B73~TIL01 B73v5_chr4:161.21-169.95 Mb [W4]: removed
- Inv4m: block B73~TIL01 B73v5_chr4:170.00-170.43 Mb [W4]: removed
- Inv4m: block B73~TIL01 B73v5_chr4:170.43-183.12 Mb [W4]: `679 loci, 45 discordant, 584 strand-inverted; spans 12.69 Mb on B73 (53.5 loci/Mb), TIL01_chr4:193,414,679-...` -> `879 loci, 65 discordant, 746 strand-inverted; spans 12.69 Mb on B73 (69.3 loci/Mb), TIL01_chr4:193,414,679-...`;
- Inv4m: block B73~Zd B73v5_chr4:163.58-163.85 Mb [W4]: `13 loci, 0 discordant, 13 strand-inverted; spans 0.28 Mb on B73 (46.7 loci/Mb), Zd_chr4:155,377,047-155,688...` -> `17 loci, 0 discordant, 16 strand-inverted; spans 0.28 Mb on B73 (61.1 loci/Mb), Zd_chr4:155,377,047-155,688...`;
- Inv4m: block B73~Zd B73v5_chr4:172.83-173.21 Mb [W4]: removed
- Inv4m (chr4:172.88-188.13 Mb), expected in B73~TIL18 [W4]: `7 block(s) of B73 pairs within 10 Mb of a reference end, 2 in B73~TIL18; closest in B73~TIL18: left breakpo...` -> `13 block(s) of B73 pairs within 10 Mb of a reference end, 2 in B73~TIL18; closest in B73~TIL18: left breakp...`; note;
- Inv1n: block B73~TIL18 B73v5_chr1:106.85-106.94 Mb [W4]: removed
- Inv1n: block B73~TIL18 B73v5_chr1:115.00-115.51 Mb [W4]: `28 loci, 1 discordant, 25 strand-inverted; spans 0.51 Mb on B73 (55.2 loci/Mb), TIL18_chr1:104,759,683-105,...` -> `40 loci, 1 discordant, 32 strand-inverted; spans 0.51 Mb on B73 (78.8 loci/Mb), TIL18_chr1:104,759,683-105,...`;
- Inv1n: block B73~TIL01 B73v5_chr1:64.57-90.52 Mb [W4]: `481 loci, 43 discordant, 422 strand-inverted; spans 25.95 Mb on B73 (18.5 loci/Mb), TIL01_chr1:82,438,534-1...` -> `695 loci, 67 discordant, 611 strand-inverted; spans 25.95 Mb on B73 (26.8 loci/Mb), TIL01_chr1:82,438,534-1...`;
- Inv1n: block B73~TIL01 B73v5_chr1:103.25-113.97 Mb [W4]: removed
- Inv1n (chr1:65.00-115.00 Mb), expected in B73~TIL01 [W4]: `4 block(s) of B73 pairs within 10 Mb of a reference end, 2 in B73~TIL01; closest in B73~TIL01: left breakpo...` -> `10 block(s) of B73 pairs within 10 Mb of a reference end, 2 in B73~TIL01; closest in B73~TIL01: left breakp...`; note;

**11 outgroup error-rate upper bound**
- ingroup E at loci Zd carries: B73 [W3]: `0.0268 (321 of 11990)` -> `0.0329 (559 of 16999)`; note;
- ingroup E at loci Zd carries: TIL18 [W3]: `0.0323 (368 of 11385)` -> `0.0391 (634 of 16215)`; note;
- ingroup E at loci Zd carries: TIL01 [W3]: `0.0314 (376 of 11957)` -> `0.0388 (652 of 16823)`; note;

**12 mechanisms**
- multi-element absences, the 30 directed ingroup pairs pooled [E6,W3]: `0.391 of 314,059 absent elements in multi-element events; nested clusters absent as a unit 0.436 of those` -> `0.390 of 1,532,782 absent elements in multi-element events; nested clusters absent as a unit 0.437 of those`;

**13 identity layer**
- split s (isolation fit, TIL01-TIL18 pairs >= 200 LTR sites) [W5]: `0.0742% +- 0.0094% (n 23779 pairs)` -> `0.0720% +- 0.0093% (n 23118 pairs)`; note;
- s_mix (mixture guard) [W5]: `0.0822% (weights iso/flow/tail 0.9409/0.0000/0.0591; AIC mix 206817 vs iso 206813, as stats.tsv rounds them)` -> `0.0784% (weights iso/flow/tail 0.9499/0.0000/0.0501; AIC mix 201603 vs iso 201598, as stats.tsv rounds them)`;
- insertions younger than the split (u95 of the donor copy's LTR-LTR divergence < s) [W5]: `R+D 0 of 1315, S+D 0 of 722; D_young undefined (no young locus in either class); sites_needed 4,036` -> `R+D 0 of 1311, S+D 0 of 721; D_young undefined (no young locus in either class); sites_needed 4,159`;
- ortholog pairs below the split (diffs/sites < s) [W5]: `B73-TIL18 8.2% of 27029; TIL01-TIL18 3.2% of 23779` -> `B73-TIL18 7.9% of 26724; TIL01-TIL18 3.2% of 23118`;
- fit check of the isolation fit (observed/fitted fraction <= x) [W5]: `0: 0.0231/0.0265; 0.001: 0.0459/0.0491; 0.002: 0.0849/0.0978; 0.003: 0.1287/0.1512; 0.005: 0.2139/0.2534` -> `0: 0.0233/0.0267; 0.001: 0.0462/0.0494; 0.002: 0.0847/0.0977; 0.003: 0.1274/0.1503; 0.005: 0.2053/0.2509`;

**14 direction**
- direction of gene flow (DESIGN 7.6) [E8,W3]: verdict skipped -> reported; `skipped: direction skipped: needs two genomes per taxon, in at least two taxa (groups with two or more ingr...` -> `DFOIL-alt (B73,PT;TIL25,TIL18): DFO +0.001 (Z 0.02), DIL -0.060 (Z -1.41), DFI -0.051 (Z -1.10), DOL -0.081...`; note;

**2 admixture in B73**
- simulated null of D_pav: rule 1 [E3]: added (script)
- calibration of D_pav's null Z: rule 2 (a reading) [E3]: added (script)
- empirical null distribution of D_pav's Z [E3]: added (script)

**3 gene flow, not lineage sorting**
- simulated null of dD: rule 2 (a reading) [E3]: added (script)

**10 inversions**
- Inv4m: block B73~PT B73v5_chr4:164.42-165.04 Mb [W3]: added (view)
- Inv4m: block B73~PT B73v5_chr4:172.84-188.14 Mb [W3]: added (view)
- Inv4m: block B73~TIL25 B73v5_chr4:172.84-188.14 Mb [W3]: added (view)
- Inv4m: block B73~TIL11 B73v5_chr4:164.42-165.04 Mb [W3]: added (view)
- Inv4m: block B73~TIL18 B73v5_chr4:172.81-188.14 Mb [W4]: added (view)
- Inv4m: block B73~TIL01 B73v5_chr4:161.21-169.63 Mb [W4]: added (view)
- Inv4m: block B73~TIL01 B73v5_chr4:169.63-169.95 Mb [W4]: added (view)
- Inv4m: block B73~TIL01 B73v5_chr4:169.96-170.16 Mb [W4]: added (view)
- Inv4m: block B73~TIL01 B73v5_chr4:170.23-170.43 Mb [W4]: added (view)
- Inv4m: block B73~Zd B73v5_chr4:172.84-173.21 Mb [W4]: added (view)
- Inv1n: block B73~TIL25 B73v5_chr1:64.57-86.60 Mb [W3]: added (view)
- Inv1n: block B73~TIL25 B73v5_chr1:88.54-114.28 Mb [W3]: added (view)
- Inv1n: block B73~TIL25 B73v5_chr1:119.37-122.26 Mb [W3]: added (view)
- Inv1n: block B73~TIL11 B73v5_chr1:64.57-81.75 Mb [W3]: added (view)
- Inv1n: block B73~TIL11 B73v5_chr1:90.51-114.28 Mb [W3]: added (view)
- Inv1n: block B73~TIL11 B73v5_chr1:120.03-120.45 Mb [W3]: added (view)
- Inv1n: block B73~TIL18 B73v5_chr1:106.90-106.96 Mb [W4]: added (view)
- Inv1n: block B73~TIL01 B73v5_chr1:90.51-114.28 Mb [W4]: added (view)

**11 outgroup error-rate upper bound**
- ingroup E at loci Zd carries: PT [W3]: added (view)
- ingroup E at loci Zd carries: TIL25 [W3]: added (view)
- ingroup E at loci Zd carries: TIL11 [W3]: added (view)

**12 mechanisms**
- absences B73>PT: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences B73>TIL25: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences B73>TIL11: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences PT>B73: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences PT>TIL25: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences PT>TIL11: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences PT>TIL18: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences PT>TIL01: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL25>B73: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL25>PT: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL25>TIL11: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL25>TIL18: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL25>TIL01: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL11>B73: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL11>PT: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL11>TIL25: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL11>TIL18: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL11>TIL01: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL18>PT: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL18>TIL25: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL18>TIL11: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL01>PT: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL01>TIL25: frac_E by age; bounds at K>=0.01 [W3]: added (view)
- absences TIL01>TIL11: frac_E by age; bounds at K>=0.01 [W3]: added (view)

## 4. FINAL.md (`$R/papers/FINAL.md`, sha256 444e519d...87f8, 296 lines)

Written for the user (plain sentences, terms defined, statistics with every claim, nulls not presented as findings,
American English, no attribution). Citations checked against PubMed today: Yang et al. 2023 (PMID 38033071, doi
10.1126/science.adg8940), Barnes et al. 2022 (PMID 35771940, doi 10.1073/pnas.2100036119), Wu et al. 2023 (PMID
36643761, doi 10.1093/hr/uhac247), Pyhäjärvi et al. 2013 (PMID 23902747, doi 10.1093/gbe/evt109).
1. **The answer**: three plain verdict sentences (genome-wide yes, D_pav +0.29, Z 7.4, beyond all 60 nulls; young
   excess consistent with gene flow but untested, no dD null; local only at the Mb scale), then the verdicts per claim
   (D_pav PASS; windows PASS; chromosomes PASS by painting, MISS by class share; ZmPRR37a MISS; HF regions MISS; 19 PASS
   / 5 MISS / 128 reported rows; same as PRELIM; LTRmix the same except it passes class share).
2. **Terms**: D_pav, empty site, resolved, Z, simulated nulls and rules 1-2, empirical null quantile, K and dD,
   painting/posterior/informative/tract/q/decoy, ELAI, element AUROC, LTRmix and D_ins.
3. **Results against the papers**: the 10.3 table in PRELIM's format with LTRmix's columns as in PRELIM (rows 1-14 plus
   a row for the simulated null beside the bar); notes: the verdict rests on the bottleneck nulls (why, and both
   quantiles), dD has no null (why), the direction row (PT's Toronto caveat, the smallest detectable DFOIL effect ±0.13,
   PT-like prediction), Inv1n's source, the cross-check.
4. **Misses**: the five MISS rows with their dead_ends.md entries (2026-11-12 Plan 2 Task 12: class share, ZmPRR37a, HF
   regions) and the final numbers; no new entry needed (same misses); plus the q-value limit behind every tract bar
   (≥ 20 tracts above every decoy tract; SIM_RESULTS section 4).
5. **What changed from PRELIM, and why**: no verdict changed; the script's edits; the view's changes (same calls,
   seven-genome loci; --trio; six ingroup genomes; inversion blocks; identity rerun), with counts; PRELIM's open
   questions answered in simulation (rule 1 and calibration; the D_pav vs D_ins gap; the identity split).
6. **Caveats**: uncalibrated simulated null and optimistic simulated power; dD without null; one genome per taxon; B73
   CLR (resolved alike in every age bin); named "not mexicana" loci met by construction; inferred truth.
7. **Headline, mechanism, generality, predictions**, each labeled by how far tested. Headline (a method rule, tested in
   two lineages): "Transposon presence/absence, verified in each assembly and counted only on the donor's own
   insertions, detects introgression across the whole genome, but maps introgressed stretches only where they are many
   times longer than the spacing between informative insertions" (genome-wide: 3 real events beyond all 60 nulls;
   mapping: maize ~10-kb tracts vs 85-kb spacing, AUROC 0.71; sweet orange 1.7-23.8-Mb tracts vs 136-kb spacing, 4 of 4
   called, AUROC 0.99; neither certifies a tract at q ≤ 0.05). Mechanism (expected; the symmetry and the annotation
   blindness tested in simulation; the spacing limit measured). Generality: six genomes (positive control narrow PASS,
   negative control MISS explained in sign not size, D_pav does not separate the controls while SNP D and D_ins do),
   genus (control PASS where LTRmix failed), citrus (6 of 7; the CsA chr2 miss), EDTA; 3 events in 2 genera, 3 of 4
   negative controls pass. Predictions 1-4, each with what was seen.
- **Files**: views/main outputs, control_main3/, final_vs_prelim.tsv with its command, the script and its tests.

## 5. Concerns

1. **Edits beyond R2's list.** Besides R2's roles and direction misreads, I fixed two more rows whose text assumed
   main3's three ingroup genomes (item 9 in section 1): the amount note ("no second donor in main3") and the pooled
   mechanisms item ("the six ingroup pairs", 30 pairs here). Both are wording, tested red then green, and change no
   number. The roles fix also changes the note's wording under --trio ("roles are inferred, never set" was false).
   Revert-able if the controller prefers R2's list only.
2. **The D_pav verdict rule is my operationalization** of "the verdict rests on the bottleneck null": PASS iff D > 0,
   Z > 3 and (rule 2 calibrated, or no bottleneck null reaches |Z|). With 30 nulls this equals a bottleneck empirical p
   of 1/31 (also p < 0.05). It matches Task 13's reading; the real Z (7.39) passes under any reading. Tests pin the
   three branches (MISS when a bottleneck null reaches a Z of 3.10; PASS on the bar alone if calibrated).
3. **Per-run null Z come from sim/runs/*/eval/eval.json**, not sim/tables (the tables hold only summaries: mean, SD,
   counts; no per-run Z, no max or quantiles). The script fails unless the per-run values reproduce null.tsv.
4. **Output location.** I ran the rulings' command (default --out), so final_papers.tsv is
   `papers/views/main/final_papers.tsv`; the brief's Files list names `papers/final_papers.tsv`. A copy there is a
   one-line `cp` if wanted. FINAL.md links the views/main path.
5. **Extra files written** outside views/main: `papers/control_main3/` (main3 rescored by the final script; needed to
   separate causes), `papers/diff_prelim.py`, `papers/final_vs_prelim.tsv`, `papers/logs/{compare_papers,
   control_main3}.*`; in `common/`: `test_compare_papers.py`, `.out`, `.red.out`. No write in main3_analyses, six/,
   sim/ or views/main beyond compare_papers' three outputs.
6. **For 16B's stability reruns** with the moved script: (a) outputs are now `<prefix>_ltrmix_crosscheck.tsv`, so the
   unprefixed `ltrmix_crosscheck.tsv` Task 15 writes stays beside it (harmless, but stale-looking); (b) two notes in
   section 3 are PRELIM's fixed text, not computed ("they carry the same asymmetry as the empty-site patterns", "the
   two sisters are resolved alike in every age bin"); they hold on the final view (library-style D +0.287 vs +0.290;
   resolution gaps 0.011-0.022) but should be eyeballed on each stability view.
7. **Not fixed, out of scope:** Task 13's minor named-locus edge case (`start0 <= end + flank` admits a BED tract
   starting one base outside the window). Checked on the final view: 0 of 767 tracts hit it in the 8 named-locus
   windows, so no row is affected.
8. **dead_ends.md not edited**: the final misses are PRELIM's five, already investigated (2026-11-12 entries); FINAL.md
   cites them. If a "confirmed in the final run (Task 16)" line is wanted, that is 16B's or the controller's.
9. **FINAL.md's headline is a method rule whose principle (marker spacing limits local-ancestry resolution) is
   expected** for any marker-based painting; the literature was not searched for precedent and FINAL.md claims no
   novelty (it says the comparison adds no new biology). The real-data support for the annotation-blindness
   mechanism is mixed and stated so (genus control consistent; the six-genome negative control's 2.8x excess over SNP D
   unexplained; D_pav does not separate the six-genome controls).

## Fix round 1 (2026-11-14 18:40-19:00; review task-16a-review.md)

FINAL.md text only, plus M8-M9 in the test file. No verdict, table cell or output changed: the 20 table lines of
FINAL.md were not edited; nothing in papers/views/main was rerun or touched; compare_papers.py is unchanged
(47d2c20d...2145). Every Task 15 number was re-read from Task 15's own files, not the review: block/all_b{1,2,5,10,20}
and block/b{...}/stats.tsv (D_pav and D_pav_gradient rows), {mm2,cap5k,default4}/views/main/stats.tsv,
stability_trios.tsv (SE ratios = Z(5 Mb)/Z(b), the estimate being fixed), sim/runs/*/views/main/stats.tsv (block
lengths), citrus/views/{k1,k2} and genus/views/ctrl stats.tsv, papers/views/main/stats.tsv (distance rows). New
citation checked on PubMed: Kuritzin et al. 2016 (PMID 26967525, doi 10.1371/journal.pcbi.1004812).
FINAL.md sha256 now f3733339...4647 (352 lines; table lines' sha256 bfc1e4d8... unchanged in this round).

- **I1, robustness** (Task 15). New caveat "Robustness to analysis choices", FINAL.md:224-235: main D_pav +0.286 to
  +0.295, Z 6.0-8.4 under every route, cap and block length (6.04, 6.63, 6.89 mm2, 7.39, 7.42 default4, 7.49 cap5k,
  7.87, 8.39), 0 of the 24 bar rows change under route or cap; dD Z 2.83 under --anchor mm2 (same estimate +0.397,
  SE +11%; 34 young informative loci against 40) and 3.10 / 3.09 at 10 / 20 Mb; controls swap at 10-20 Mb (positive
  2.92, 2.76; negative 2.80, 2.79; no block length passes both); real SE 1.08x and 1.15x the 5-Mb value at 10 and
  20 Mb (median of 20 trios) and 1.18x from 1 to 5 Mb (20 of 20), simulated SE flat (0.061-0.063, SIM_RESULTS
  section 1); nulls jackknifed in about 103 blocks of 0.96-0.97 Mb (sim/runs/null_s101 etc.) against 425 blocks of
  5 Mb. Qualified lines: FINAL.md:24-27 (was 22: PASS robust; the nulls a guide, not like-for-like), :31-32 (was 24:
  dD at the threshold), :111-116 (row 2 note), :120-121 (row 3 note), :264-265 (detection bullet: results near Z 3
  move), :290-293 (was 248: positive control narrow at 5 Mb, swaps at 10-20 Mb), :315-319 (was 266: the tally). Terms
  :56 (block-length rule) and :57-61 (simulated genomes about 96 Mb, blocks about 1 Mb).
- **I2, the control tally.** Citrus controls called weak, with n and power: FINAL.md:304-308 (k1 21+8 = 29
  informative, SE 0.172, flags |D| > 0.52; k2 15+19 = 34, SE 0.218, |D| > 0.65; k1 already +0.45; 0 default and 2
  bottleneck nulls reach its Z 2.61; "consistent with no gene flow, not evidence that D_pav holds a null"). Rank
  agreement corrected, FINAL.md:296-299 (was 253): "nearly as the SNP D does (rho 0.90), except that the two controls
  swap". Tally rewritten, :315-319: genus control the most powerful (73+84 = 157 informative, SE 0.102, flags
  |D| > 0.31); six-genome control misses at 5 Mb and passes at 10-20 Mb; citrus controls could flag only |D| above
  about 0.5-0.65. Generality header :289 "the controls are weak or mixed". Prediction 2, :327-329, adds "but it will
  not order trios whose D differ by less than its SE".
- **M1** stale script names: FINAL.md:14-19 (compare_papers.py, sha 47d2c20d, `.task13` kept; the log shows the
  pre-install name with the same sha256), :348-350 (Files). The only `next.py` left is :18, that explanation.
- **M2** "only at the Mb scale": FINAL.md:33-37 ("at the Mb scale, not at the scale of the tracts"; significant at
  every window size, r 0.20-0.28 at 0.1-0.5 Mb, strongest 0.26-0.38 at 1-10 Mb) and :270-271.
- **M3** unlike counts in the dD note: FINAL.md:117-121 now compares shares of informative loci: about 0.4% in a
  default null (mean 1.17 of 301.4) against 2.0% here (40 of 2,036). Residual: compare_papers.py's own row note
  (`add_gradient_own`, :1126-1130) still sets "mean 1.2 of 301" beside "40"; changing it needs a rerun of
  papers/views/main, which this round forbids. For whoever next reruns the script.
- **M4** 0.66: FINAL.md:208-210: "0.67 here, 0.1949/0.2898, and Plan 3's rule 8 used 0.66, the ratio of PRELIM's
  rounded values, 0.19/0.29"; the interval 0.43-0.69 contains both.
- **M5** "more distant": dropped, FINAL.md:195-196.
- **M6** Zea nulls for citrus: FINAL.md:263-264 ("built for *Zea*, so for sweet orange they are a reference, not that
  system's null").
- **M7** TIL25 not a second donor: new row 4 note, FINAL.md:122-125 (the second-donor rule as findings.txt states it;
  PAV distance defined; TIL25~TIL18 0.3432 against B73~TIL18 0.3428, from views/main/stats.tsv).
- **M8** ties: test_compare_papers.py:193 adds `null_quantile(3.14, [3.14, -3.14, 1.0]).k == 2`. Red: against a
  scratch copy of compare_papers.py with `>=` mutated to `>` at :330, test_null_quantile fails (`assert 0 == 2`; 1
  failed, 18 passed; appended to test_compare_papers.red.out as "red phase 3"). Green on the installed module: 19
  passed (`test_compare_papers.out`, first line records compare_papers.py sha256 47d2c20d...). Test file sha256 now
  1bf4dbef...8603; ruff F/E9/B clean.
- **M9** import fallback: test_compare_papers.py:5-6 and :17 import compare_papers.py only. (The review marked M9 for
  16B; done here as the coordinator asked for all minors, so 16B need not.)
- **M10** precedent: FINAL.md:253-259: KKSC (Kuritzin et al. 2016) as the animal precedent for insertion-based
  hybridization tests; the spacing limit expected for any marker-based painting; what may be new (donor-only discovery
  with assembly genotyping, blind to sister annotation; an insertion-based local-ancestry painting), resting on DESIGN
  1a's survey, not searched again, so labeled unverified.
- **M11** jargon: `--trio` defined at first use, FINAL.md:12-13; Toronto Agreement defined in the row 14 note,
  :128-129. Also the row notes now run in row order (row 10, :126-127, before row 14).

## Fix round 2 (2026-11-14; re-review N1-N6, FINAL.md only)

FINAL.md sha256 edaa4da5...9f02, 356 lines; table lines unchanged (sha256 of the `| ` lines still bfc1e4d8...); no
other file touched. Figures re-read at source: six/views/all/stats.tsv (TIL11,TIL01;TIL18 n_RD 1,085, n_SD 811, SE
0.0451 -> 3 SE 0.135; PT,B73;TIL18 Z 3.15762), the 60 nulls' eval.json design.genome_bp (420 genomes, 93.5-102.1 Mb,
mean 97.6), sim/probes/task11/claims.txt section 1 (the 0.25/2/5-Mb SE probe is the "truth D probe").
- **N1** FINAL.md:320-323: "Of the controls that pass at 5 Mb, the genus control has the most power (157; |D| above
  about 0.31). The six-genome control, the most powerful (1,896; |D| above about 0.14), misses at the 5-Mb rule and
  passes with 10-20 Mb blocks ...".
- **N2** FINAL.md:295: margin "by 0.014" (3.1576 - 3.1434).
- **N3** FINAL.md:210-212: "Plan 3's rule 8 used 0.66, whose derivation is not recorded" (the 0.19/0.29 derivation
  dropped).
- **N4** FINAL.md:59-60 and :236: "93.5-102.1 Mb per genome after insertions, mean 97.6" / "on genomes of 93.5-102.1
  Mb".
- **N5** FINAL.md:113-114 and :235: the flat simulated SE is "measured on truth D (the same statistic with perfect
  genotypes)" / "the simulated SE, measured on truth D".
- **N6** FINAL.md:258-261: "What may be new relative to the published literature ..." and "(LTRmix, compared
  throughout this report, also paints, from LTR-RT classes that include presence/absence)".
