#!/usr/bin/env python3
"""Score the citrus run (lineage2/out, six genomes, every trio) against the published sweet-orange ancestry
(truth/CsA.P.bed, truth/CsB.M.bed; Wu B. et al. 2023 Hortic Res, Suppl. Table 4).

Per trio: inferred roles; genome-wide tests (D, Z); for trios whose recipient is CsA or CsB with the expected donor:
element AUROC of the ancestry and recent posteriors (truth: element midpoint inside a donor tract), base-pair
precision and recall of called tracts at q <= 0.05 / p_decoy <= 0.01 / all, and recall of each true tract (>= 50% of
its length covered). Controls (sour orange haplotypes as recipients): tract counts and Z.
Writes eval/trios.tsv, eval/tracts.tsv, eval/truth_tracts.tsv; prints a summary."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import glob
import os
import re
import sys

import numpy as np
import pandas as pd

L = sys.argv[1] if len(sys.argv) > 1 else "/data2/chris/maize_introgression/benchmark/lineage2"
OUT = os.path.join(L, "out")
EV = os.path.join(L, "eval")
os.makedirs(EV, exist_ok=True)
TRUTH = {"CsA": ("Cm", os.path.join(L, "truth/CsA.P.bed")), "CsB": ("Cr", os.path.join(L, "truth/CsB.M.bed"))}
TESTS = (("D_kmer", "all"), ("D_ins", "all"), ("D3_triples", "all"), ("D_self_outgroup", "LTR sites"))


def merge(iv):
    out = []
    for s, e in sorted(iv):
        if out and s <= out[-1][1]:
            out[-1][1] = max(out[-1][1], e)
        else:
            out.append([s, e])
    return out


def ov(a, b):
    s = 0
    for x0, x1 in a:
        for y0, y1 in b:
            s += max(0, min(x1, y1) - max(x0, y0))
    return s


def auroc(score, lab):
    score, lab = np.asarray(score, float), np.asarray(lab, bool)
    ok = np.isfinite(score)
    score, lab = score[ok], lab[ok]
    n1, n0 = lab.sum(), (~lab).sum()
    if n1 == 0 or n0 == 0:
        return np.nan
    r = pd.Series(score).rank().values
    return (r[lab].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)


def roles(d):
    f = open(os.path.join(d, "findings.txt")).read()
    m = re.search(r"Sister pair \(most single-copy k-mers shared\): (\S+) \+ (\S+); third genome: (\S+)\.", f)
    rec = re.search(r"D\(single-copy k-mers; (\S+?),", f)
    return m[1], m[2], m[3], rec[1] if rec else None


def main():
    rows, trows, mrows = [], [], []
    for d in sorted(glob.glob(os.path.join(OUT, "*_*_*"))):
        if not os.path.exists(os.path.join(d, "stats.tsv")):
            continue
        s1, s2, D, R = roles(d)
        S = s2 if R == s1 else s1
        st = pd.read_csv(os.path.join(d, "stats.tsv"), sep="\t")
        r = dict(trio=os.path.basename(d), recipient=R, sister=S, donor=D)
        for t, s in TESTS:
            x = st[(st.test == t) & (st.stratum == s)]
            if len(x):
                r[t], r[t + "_Z"] = float(x.iloc[0].D), float(x.iloc[0].Z)
        for mode in ("ancestry", "recent"):
            x = st[st.test == f"hmm_{mode}"]
            if len(x):
                r[f"{mode}_tracts"] = int(x.iloc[0].n_tracts)
                r[f"{mode}_decoys"] = int(x.iloc[0].n_decoy_tracts)
                r[f"{mode}_q05"] = int(x.iloc[0].n_tracts_q05)
        if R in TRUTH and TRUTH[R][0] == D:
            tb = pd.read_csv(TRUTH[R][1], sep="\t", header=None, names=["chrom", "s", "e"])
            T = {c: merge(list(zip(g.s, g.e))) for c, g in tb.groupby("chrom")}
            el = pd.read_csv(os.path.join(d, f"elements.{R}.tsv"), sep="\t")
            mid = (el.start + el.end) // 2
            lab = np.zeros(len(el), bool)
            for c, v in T.items():
                for s0, e0 in v:
                    lab |= ((el.chrom == c) & (mid >= s0) & (mid < e0)).values
            r["n_elements"], r["n_in_truth"] = len(el), int(lab.sum())
            for mode in ("ancestry", "recent"):
                pc = f"post_{mode}_{D}"
                if pc in el:
                    r[f"auroc_{mode}"] = auroc(el[pc], lab)
                    r[f"post_{mode}_in"] = float(el[pc][lab].mean())
                    r[f"post_{mode}_out"] = float(el[pc][~lab].mean())
                bedf = os.path.join(d, ("tracts" if mode == "recent" else "ancestry") + f".{R}.bed")
                if not os.path.exists(bedf):
                    continue
                bed = pd.read_csv(bedf, sep="\t")
                bed.columns = [c.lstrip("#") for c in bed.columns]
                for tag, sel in (("q<=0.05", bed.q <= 0.05), ("p_decoy<=0.01", bed.p_decoy <= 0.01), ("all", bed.q >= 0)):
                    bb = bed[sel]
                    C = {c: merge(list(zip(g.start0, g.end))) for c, g in bb.groupby("chrom")}
                    tp = sum(ov(C.get(c, []), T.get(c, [])) for c in set(C) | set(T))
                    cl = sum(e - s for v in C.values() for s, e in v)
                    tt = sum(e - s for v in T.values() for s, e in v)
                    trows.append(dict(trio=r["trio"], recipient=R, mode=mode, set=tag, n_called=len(bb),
                                      called_Mb=cl / 1e6, bp_precision=tp / cl if cl else np.nan,
                                      bp_recall=tp / tt if tt else np.nan))
                    for c, v in T.items():
                        for s0, e0 in v:
                            got = ov([[s0, e0]], C.get(c, []))
                            n_el = int(((el.chrom == c) & (mid >= s0) & (mid < e0)).sum())
                            mrows.append(dict(trio=r["trio"], mode=mode, set=tag, chrom=c, start0=s0, end=e0,
                                              Mb=(e0 - s0) / 1e6, n_elements=n_el, covered=got / (e0 - s0),
                                              called=got >= 0.5 * (e0 - s0)))
        rows.append(r)
    t = pd.DataFrame(rows)
    t.to_csv(os.path.join(EV, "trios.tsv"), sep="\t", index=False)
    pd.DataFrame(trows).to_csv(os.path.join(EV, "tracts.tsv"), sep="\t", index=False)
    pd.DataFrame(mrows).to_csv(os.path.join(EV, "truth_tracts.tsv"), sep="\t", index=False)
    with pd.option_context("display.width", 250, "display.max_columns", 40):
        cols = [c for c in ["trio", "recipient", "sister", "donor", "D_kmer", "D_kmer_Z", "D_ins_Z", "D3_triples_Z",
                            "D_self_outgroup_Z", "ancestry_q05", "recent_q05", "recent_tracts", "recent_decoys",
                            "auroc_ancestry", "auroc_recent"] if c in t]
        print(t[cols].round(3).to_string(index=False))
        if trows:
            print(pd.DataFrame(trows).round(3).to_string(index=False))
        if mrows:
            m = pd.DataFrame(mrows)
            print(m[m.set == "q<=0.05"].round(3).to_string(index=False))


if __name__ == "__main__":
    main()
