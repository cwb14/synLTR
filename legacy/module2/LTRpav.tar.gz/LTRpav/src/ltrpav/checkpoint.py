"""Stage checkpoints: cached input checksums, stage keys and done markers.

A stage runs as: key = stage_key(...); if is_done(marker, key): load the outputs; else clear_done(marker),
write the outputs, mark_done(marker, key, outputs). The key hashes the stage name, its inputs' checksums, its
parameters, the ltrpav version and the fingerprint of the code the stage runs, so a change in any of them
reruns the stage: an outdir finished by older code is recomputed, never reused. The versions of the external
tools a stage runs (`tool_version`) go into its parameters. The marker (JSON) is written last and atomically;
it records the key, any metadata the stage adds, and each output's size, relative to the marker's directory.

Code fingerprints: each cached stage is keyed on
`package_fingerprint` of only the modules its output depends on, declared once, in STAGE_MODULES. A set is the
static import closure of the module holding the stage's code (imports anywhere in a module, TYPE_CHECKING
blocks skipped; a submodule's package __init__ counts only where something is imported from it;
ltrpav/__init__.py and this module's bookkeeping left out), so an edit to a module in a stage's set changes
its key, and an edit outside it never does: the CLI, the locus catalog (loci.py), the outputs, the sample
sheet reader, the simulator. constants.py is in every set (each stage reads thresholds from it). A package
outside the engine, such as the analysis or plotting package, keys its own stages with its own fingerprint,
which adds the engine modules it runs (the analyses: `stage_key(..., fingerprint=package_fingerprint(
"ltrpav.analysis", *analysis.report.ENGINE_MODULES))`), and never invalidates genotyping.
"""
from __future__ import annotations

import contextlib
import functools
import hashlib
import json
import logging
import os
import shutil
import subprocess
import threading
from collections.abc import Iterator
from datetime import datetime, timezone
from pathlib import Path

from . import __version__

log = logging.getLogger("ltrpav.checkpoint")

CHECKSUM_CACHE = "checksums.json"  # name of the checksum cache file in a work directory
_BLOCK = 8 << 20  # bytes hashed per read: streams multi-Gb files in constant memory
# executable -> the arguments that print its version (first output line kept); None: it has no version flag
# (FastGA prints only its usage), so the sha256 of the binary itself stands in for the version
TOOL_VERSION_ARGS: dict[str, list[str] | None] = {
    "lastz": ["--version"], "minimap2": ["--version"], "FastGA": None, "blastn": ["-version"],
    "makeblastdb": ["-version"], "bcftools": ["--version"]}
_ROOT = Path(__file__).parent  # the ltrpav package: package_fingerprint resolves names under it

# the modules each cached stage's output depends on: the static import closure of the module holding its code
_ELEMENTS = ("ltrpav.annotation", "ltrpav.constants", "ltrpav.elements", "ltrpav.seqio")
_ANCHORS = ("ltrpav.anchor", "ltrpav.blocks", "ltrpav.chain", "ltrpav.constants", "ltrpav.elements",
            "ltrpav.seqio", "ltrpav.window")  # the anchor package imports every route; hybrid makes windows
_CALLS = (*_ANCHORS, "ltrpav.classify", "ltrpav.genotype", "ltrpav.junction", "ltrpav.localign")
STAGE_MODULES: dict[str, tuple[str, ...]] = {
    "elements": _ELEMENTS,  # annotation.elements_stage
    "anchor": _ANCHORS,  # anchor.anchor_pair: chained and netted blocks
    "raw": _ANCHORS,  # anchor._raw_blocks: a whole-genome route's raw blocks (in the anchor package)
    "blastdb": _ANCHORS,  # anchor.flanks._blast_db (flanks imports the anchor package's _raw_blocks)
    "mm2_index": ("ltrpav.anchor.mm2", "ltrpav.blocks", "ltrpav.constants"),  # anchor.mm2._aligner
    "genotype_pair": _CALLS,  # genotype.genotype_pair (it calls anchor_pair)
    "genotype_chunk": _CALLS,
}


def package_fingerprint(*modules_or_packages: str) -> str:
    """sha256 (hex) of the source of the named modules and packages (a package: every *.py under it), each
    file once: its path relative to the ltrpav package, its length and its bytes, in path order. Names are
    dotted and under ltrpav ("ltrpav.anchor", "ltrpav.chain"); an unknown one is a ValueError. Cached per
    process."""
    return _fingerprint(_ROOT, tuple(sorted(set(modules_or_packages))))


def stage_fingerprint(stage: str) -> str:
    """package_fingerprint of the stage's declared modules (STAGE_MODULES); a ValueError for a stage without
    a declared set (pass stage_key a fingerprint)."""
    if stage not in STAGE_MODULES:
        raise ValueError(f"stage {stage!r} has no module set in STAGE_MODULES; give stage_key its "
                         "fingerprint")
    return package_fingerprint(*STAGE_MODULES[stage])


@functools.cache
def _fingerprint(root: Path, names: tuple[str, ...]) -> str:
    files = {f for name in names for f in _source_files(root, name)}
    h = hashlib.sha256()
    for path in sorted(files, key=lambda p: p.relative_to(root).as_posix()):
        data = path.read_bytes()
        h.update(path.relative_to(root).as_posix().encode() + b"\0" + len(data).to_bytes(8, "little"))
        h.update(data)
    return h.hexdigest()


def _source_files(root: Path, name: str) -> list[Path]:
    """The *.py files of module or package `name` (dotted, under ltrpav) in the package directory `root`."""
    head, *parts = name.split(".")
    path = root.joinpath(*parts)
    if head == "ltrpav" and path.is_dir() and (path / "__init__.py").is_file():
        return sorted(path.rglob("*.py"))
    if head == "ltrpav" and parts and path.with_suffix(".py").is_file():
        return [path.with_suffix(".py")]
    raise ValueError(f"no ltrpav module or package {name!r} under {root}")


def tool_version(exe: str) -> str | None:
    """`exe`'s version: the first line its TOOL_VERSION_ARGS print, or "sha256:<16 hex>" of the binary when it
    has no version flag; None when it is not on PATH (or does not answer in 10 s). Cached per binary file."""
    path = shutil.which(exe)
    if path is None:
        return None
    real = os.path.realpath(path)
    try:
        st = os.stat(real)
    except OSError:
        return None
    args = TOOL_VERSION_ARGS.get(exe, ["--version"])
    return _tool_version(path, real, None if args is None else tuple(args), st.st_size, st.st_mtime_ns)


@functools.cache
def _tool_version(path: str, real: str, args: tuple[str, ...] | None, size: int, mtime_ns: int) -> str | None:
    """tool_version of the executable `path` (its binary `real`, of `size` and `mtime_ns`, keys the cache);
    args None: the binary's sha256."""
    if args is None:
        h = hashlib.sha256()
        with open(real, "rb") as fh:
            while chunk := fh.read(_BLOCK):
                h.update(chunk)
        return f"sha256:{h.hexdigest()[:16]}"
    try:
        r = subprocess.run([path, *args], capture_output=True, text=True, timeout=10, check=False,
                           stdin=subprocess.DEVNULL)
    except (OSError, subprocess.SubprocessError):
        return None
    lines = (r.stdout + "\n" + r.stderr).strip().splitlines()
    return lines[0].strip() if lines else None


def file_checksum(path: Path, cache: Path) -> str:
    """sha256 (hex) of the file at `path`, cached in the JSON file `cache` by (absolute path, size, mtime_ns).

    The file is streamed, never loaded whole. A damaged cache is rebuilt, with a warning. Each cache write is
    atomic; concurrent writers may drop each other's new entries, which only costs a recomputation.
    """
    path, cache = Path(path).resolve(), Path(cache)
    st = path.stat()
    entries = _read_json(cache)
    hit = entries.get(str(path))
    if isinstance(hit, dict) and hit.get("size") == st.st_size and hit.get("mtime_ns") == st.st_mtime_ns:
        return hit["sha256"]
    h = hashlib.sha256()
    buf = memoryview(bytearray(_BLOCK))
    with open(path, "rb") as fh:
        while n := fh.readinto(buf):
            h.update(buf[:n])
    sha = h.hexdigest()
    entries[str(path)] = {"size": st.st_size, "mtime_ns": st.st_mtime_ns, "sha256": sha}
    _write_json(cache, entries)
    return sha


def stage_key(stage: str, inputs: dict[str, str], params: dict, fingerprint: str | None = None) -> str:
    """sha256 (hex) of the canonical JSON (sorted keys) of the stage, its inputs, its params, the version and
    the fingerprint of its code: `fingerprint`, or by default stage_fingerprint(stage), the stage's declared
    modules (a stage outside STAGE_MODULES must pass its own, e.g. package_fingerprint of its package).

    `inputs` maps input names to checksums; `params` holds JSON values (Path and numpy scalars converted),
    among them the versions of the external tools the stage runs.
    """
    code = stage_fingerprint(stage) if fingerprint is None else fingerprint
    payload = {"stage": stage, "inputs": inputs, "params": params, "version": __version__, "code": code}
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=_jsonable)
    return hashlib.sha256(blob.encode()).hexdigest()


def is_done(marker: Path, key: str) -> bool:
    """True if `marker` records `key` and every output it lists still exists with its recorded size."""
    marker = Path(marker)
    try:
        with open(marker) as fh:
            rec = json.load(fh)
        if rec["key"] != key:
            return False
        return all((marker.parent / out["path"]).stat().st_size == out["size"] for out in rec["outputs"])
    except (OSError, ValueError, KeyError, TypeError):  # absent, unreadable or malformed: not done
        return False


def mark_done(marker: Path, key: str, outputs: list[Path], meta: dict | None = None) -> None:
    """Record that the stage keyed `key` wrote `outputs` (call it last, after every output is complete), with
    the stage's `meta` (JSON values, such as its code fingerprint; read back by `done_meta`).

    Written atomically (temp file + rename). Output paths are stored relative to the marker's directory, so a
    work directory stays valid when moved. A missing output is an error: nothing is written.
    """
    marker = Path(marker)
    base = os.path.abspath(marker.parent)
    recs = []
    for out in outputs:
        try:
            size = Path(out).stat().st_size
        except FileNotFoundError:
            raise FileNotFoundError(f"stage output {out} is missing; {marker} not written") from None
        recs.append({"path": os.path.relpath(os.path.abspath(out), base), "size": size})
    _write_json(marker, {"key": key, "outputs": recs, "version": __version__, "meta": meta or {},
                         "finished": datetime.now(timezone.utc).isoformat(timespec="seconds")})


def done_meta(marker: Path) -> dict | None:
    """The meta mark_done recorded beside the key ({} if none); None without a readable marker."""
    try:
        with open(marker) as fh:
            meta = json.load(fh).get("meta") or {}
        return meta if isinstance(meta, dict) else None
    except (OSError, ValueError, AttributeError):
        return None


def clear_done(marker: Path) -> None:
    """Remove `marker` before a stage rewrites its outputs.

    Otherwise a run interrupted mid-write would leave the old marker beside new, partial outputs, trusted
    again once the old key returns.
    """
    Path(marker).unlink(missing_ok=True)


def _jsonable(obj):
    if isinstance(obj, Path):
        return str(obj)
    if hasattr(obj, "item") and hasattr(obj, "dtype"):  # numpy scalar
        return obj.item()
    raise TypeError(f"stage parameter of type {type(obj).__name__} is not JSON-serializable")


def _read_json(path: Path) -> dict:
    try:
        with open(path) as fh:
            data = json.load(fh)
    except FileNotFoundError:
        return {}
    except (OSError, ValueError) as exc:
        log.warning("checksum cache %s is unreadable (%s); rebuilding it", path, exc)
        return {}
    if not isinstance(data, dict):
        log.warning("checksum cache %s is malformed; rebuilding it", path)
        return {}
    return data


def marker(path: Path) -> Path:
    """The done marker of the file `path`: beside it, named <name>.done.json."""
    return path.with_name(path.name + ".done.json")


@contextlib.contextmanager
def atomic_path(path: Path) -> Iterator[Path]:
    """A temporary path beside `path`, one per process and thread, renamed onto `path` when the block ends
    without an error and removed otherwise: a reader never sees a partial file. The caller writes the file."""
    tmp = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    tmp.unlink(missing_ok=True)
    try:
        yield tmp
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def atomic_write(path: Path, data: bytes | str) -> None:
    """Write `data` (text as UTF-8) to `path` through a temporary file renamed into place."""
    with atomic_path(path) as tmp:
        if isinstance(data, str):
            tmp.write_text(data, encoding="utf-8")
        else:
            tmp.write_bytes(data)


def _write_json(path: Path, data: dict) -> None:
    """Write `data` as JSON to `path` atomically (atomic_write)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write(path, json.dumps(data, indent=1, sort_keys=True) + "\n")
