### Task 22: Pair simulator on a real backbone

**Files:** Create `src/ltrpav/sim/{__init__,genome,pair,cli}.py`, `tests/test_sim.py`

**Interfaces:**
- Produces:

```python
class SimGenome:                       # seq: bytearray; prov: np.ndarray[int64] (ancestral id per base, new ids for inserts)
    def insert(self, pos: int, payload: bytes, prov: np.ndarray) -> None
    def delete(self, start: int, end: int) -> None
    def invert(self, start: int, end: int) -> None
    def gap(self, start: int, end: int) -> None          # replace with N, provenance kept
    def mutate(self, sub_rate: float, indel_rate: float, rng: np.random.Generator) -> None   # one-pass rebuild
    elements: dict[str, SimElement]                      # coordinates lifted after every edit
@dataclass
class Donor: seq: str; ltr_left: int; ltr_right: int; family: str | None; superfamily: str | None
@dataclass
class PairParams:      # defaults per 6 Mb, Zea-like; scale multiplies every count
    sub_rate: float = 0.006; indel_rate: float = 0.0006
    n_shared: int = 150; n_branch: int = 200; k_shared: tuple = (0.01, 0.03); k_branch: tuple = (0.0, 0.01)
    n_solo: int = 40; n_del_flank: int = 30; n_del_partial: int = 20; n_gap: int = 15; inv_len: int = 300_000
    dropout: float = 0.1; jitter: float = 0.05; scale: float = 1.0
def simulate_pair(backbone: str, backbone_elements: list[Element], donors: list[Donor], params: PairParams,
                  seed: int) -> tuple[SimGenome, SimGenome, list[dict]]   # truth rows, both directions
def write_pair(outdir: Path, A: SimGenome, B: SimGenome, truth: list[dict], params: PairParams, seed: int) -> None
    # A.fa, B.fa, A.gff3, B.gff3 (write_gff3; dropout, jitter), truth.tsv, samples.tsv, params.json
```

- CLI: `ltrpav-sim pair --fasta FA --region SEQ:START-END --annotation ANNOT --outdir DIR [--seed N] [--scale X]`.
  Donors are level-0, childless, high-confidence elements of the same annotation; up to 2000 are sampled with the
  seed.
- Truth rules: element `e` of X in the other genome Y, using provenance. Here `w = 2L`, and "contiguous" means
  Y keeps the ids of the w bases on each side of `e`'s target site in order, with only the target copy between them.

| e's history | condition in Y (checked in this order) | truth |
|---|---|---|
| any | an N run within REFINE_PAD of the site or over e's image | G |
| inserted in X after the split | an X-specific ancestor exists | that ancestor's truth (+ host_empty if E) |
| inserted in X after the split | site contiguous, nothing else inserted there | E |
| inserted in X after the split | site contiguous, a Y-specific insertion there | O |
| inserted in X after the split | otherwise | D |
| present before the split | solo event on e in Y's branch | S |
| present before the split | >= 80% of e's ids and of each LTR in Y | P (+ inv if inside the inversion) |
| present before the split | >= MIN_SEG of e's ids in Y | T |
| present before the split | otherwise | D |

- [ ] **Step 1: Write the failing tests** (small backbone: 400 kb random with 10 planted pre-existing elements).

```python
def test_inserted_element_and_tsds():    # A.fa holds the payload at the reported coords; equal 5-bp TSDs both sides
def test_solo_keeps_one_ltr_and_tsds():  # solo'd element in B: one LTR-length segment between the two TSD copies
def test_truth_engineered_events():      # one of each engineered event -> expected truth (E, P, S, D, T, G, host_empty)
def test_seed_determinism(tmp_path):     # same seed -> identical FASTA and truth bytes
def test_gff3_loads(tmp_path):           # load_annotation(A.gff3) count == elements * (1 - dropout) +- 3 sd
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.** Sequence of events:
  1. Ancestor = backbone.
  2. Shared insertions (positions uniform over the current sequence, so nesting arises naturally).
  3. Split.
  4. Per branch: insertions; solo-LTRs (hybrid LTR at a random crossover, both TSDs kept); flank deletions (50-2000
     bp beyond at least one end); internal partial deletions (20-60% of the internal region); `mutate`; gaps
     (100-bp N runs, a third of them within 20 bp of an element end or an empty site).
  5. One inversion in B.

  Young copies: both LTRs equal the donor's left LTR, then each mutated at K/2.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add real-backbone pair simulator with provenance truth"`.

---

