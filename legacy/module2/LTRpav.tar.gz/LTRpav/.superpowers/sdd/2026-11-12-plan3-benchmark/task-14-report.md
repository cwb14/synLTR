# Task 14 report: *Zea* genus event, sweet orange, EDTA portability

Status: DONE (Steps 1-4; Step 3 included). Date 2026-11-14, analyses 15:58-16:07 EST, scoring and writing to 16:32.
P=/data2/chris/maize_introgression; R=$P/benchmark_pav/plan3/real.

## Code, inputs, order (rulings R1)
- Snapshot 2: every command sourced common/env.sh (or common/view.sh) with SNAP_SHA=6282541; each step's log starts
  with `ltrpav=.../snap/6282541/src/ltrpav/__init__.py`; every stage marker (20 of them) holds analysis code
  b30e708915f6... (snapshot 2's stats/paint fingerprint in real/memo.md).
- Genotypes read only, through views: genus/geno, citrus/geno, edta/geno (block.done present). No file in any geno/
  is newer than its block.done after the run. Sheets: each block's samples.tsv.
- Order: Steps 1-2 analyses ran first (15:58-16:04:30). At 16:04, six/views/main had work/analysis/stats.done.json
  (15:58) and paint.done.json (15:59), stats.tsv carried both part keys and findings.txt listed no left-out part, so
  Step 3 ran (16:04:56-16:07:10). compare_papers.py already existed (real/common/compare_papers.py, Task 13, sha256
  1e04f43ed8df53db...; used only, not edited).
- Threads: 1 per command (OMP/OPENBLAS/MKL/NUMBA = 1), at most 5 at once; longest command 2:13 (genus all paint);
  peak RSS 556 MB. No process killed; stability/ and snap/12d3e6c untouched.

## Views and commands
Script: real/genus/run_view.sh BLOCK VIEW STEP [R,S,D] (view: common/view.sh BLOCK/geno BLOCK/views/VIEW
BLOCK/samples.tsv; stats/paint: ltrpav-stats/ltrpav-paint --samples views/VIEW/samples.tsv --outdir views/VIEW
[--trio]; ltrpav under `timeout 14m`; logs BLOCK/logs/VIEW.STEP.{log,time,exit}; all exits 0).
- genus: all (no --trio), p1 Zh,TIL18,Zn; p2 TIL01,TIL18,Zn; ctrl TIL18,TIL25,Zn; zd Zh,TIL18,Zd (stats then paint).
- citrus: c1 CsB,Cm,Cr; c2 CsA,Cr,Cm; k1 CaM,Cr,Cm; k2 CaP,Cm,Cr.
- edta: main B73,TIL01,TIL18; then in real/edta: `python ../common/compare_papers.py --run views/main --prefix
  edta_main` (1:29; outputs edta/views/main/edta_main_papers.tsv, edta_main_tables/, ltrmix_crosscheck.tsv).
- Scoring (env.sh, snapshot 2): genus/score_genus.py, citrus/score_citrus.py, edta/edta_vs_six.py; investigations
  citrus/investigate_c2.py, genus/zd_fourpoint.py. Exact command lines: real/genus/memo_entry_task14.md.

## Bars (DESIGN 10.4), each with its numbers
Null quantiles (ruling R3/I4): each D_pav Z is read against Task 11's 30 default nulls (max |Z| 1.97) and 30
bottleneck nulls (max 3.14), from sim/probes/task11/perrun.tsv (dpav_all_z); empirical p = (k+1)/31. In no case does a
bar's verdict differ from the bottleneck reading.

Genus (2 PASS, 0 MISS):
- P1 D_pav(Zh,TIL18;Zn) > 0 with Z > 3: **PASS**. +0.4804 ± 0.0755, Z 6.36; n_RD 245, n_SD 86 of 7,129 counted
  loci; 0/30 default and 0/30 bottleneck nulls reach |Z| 6.36 (p 0.032 each). LTRmix D_ins +0.458 (Z 7.37), D_kmer
  +0.177 (Z 17.0) (benchmark/genus/out/analysis/trio_summary.tsv).
- Control D_pav(TIL18,TIL25;Zn) |Z| < 3: **PASS**. −0.0701 ± 0.1024, Z −0.68; 73/84 of 7,244; 9/30 default, 22/30
  bottleneck reach it (p 0.32, 0.74); 95% interval −0.271 to +0.131. LTRmix D_ins(TIL25,TIL18;Zn) +0.307 (Z 3.26),
  failed; in LTRpav's orientation −0.307, the same sign as LTRpav's, outside its interval by 0.036.

Sweet orange (6 PASS, 1 MISS):
- Called tracts (tracts at any q cover >= 50%): CsB chr1 23.83 Mb 0.991 **PASS**; CsB chr2 3.56 Mb 0.513 **PASS**;
  CsB chr3 7.22 Mb 0.753 **PASS**; CsB chr9 1.74 Mb 0.820 **PASS**; CsA chr2 7.46 Mb 0.340 **MISS**. LTRmix recent
  (lineage2/eval/truth_tracts.tsv): 1.000, 0.980, 1.000, 0.687, 0.656.
- Controls (|Z| < 3 and no tract at q <= 0.05): k1 D_pav(CaM,Cr;Cm) +0.448 ± 0.172, Z 2.61 (21/8), 0 tracts at q <=
  0.05 (3 at any q, q 0.33) **PASS** (0/30 default, 2/30 bottleneck reach it: p 0.032, 0.097; inside the bottleneck
  null the verdicts rest on); k2 D_pav(CaP,Cm;Cr) −0.118 ± 0.218, Z −0.54 (15/19), 0 at q <= 0.05 (8 at any q)
  **PASS** (12/30, 24/30). LTRmix D_ins +0.058 (Z 0.93); +0.130 (Z 1.99, its roles Cm,CaP;Cr), −0.130 in LTRpav's
  orientation (same sign as LTRpav's −0.118).

## Reported items (no verdict)
- Genus P2 D_pav(TIL01,TIL18;Zn) +0.417 ± 0.080, Z 5.22 (153/63; 0/30, 0/30); LTRmix D_ins +0.265 (Z 4.03).
- Genus resolved fractions of D's candidate loci (Zn discovers, Zn present; 60,650): P1 Zh 0.227 / TIL18 0.205; P2
  TIL01 0.222 / TIL18 0.205; control TIL18 0.205 / TIL25 0.198 (spread 0.03). LTRmix's Zn synteny (<trio>/stats.tsv,
  donor_resolved): Zh 0.948, TIL18 0.578, TIL01 0.809, TIL25 0.353 (spread 0.60). zd: Zh 0.621 / TIL18 0.627 of 671.
- Genus young insertions (K2P < 0.01 of Zn's copy): P1 43 vs 13, dD +0.031 (Z 0.05); P2 7 vs 5 (dD not testable);
  control 7 vs 6. Paintings: p1 142 tracts (53 decoy), p2 106 (45), ctrl 28 (32), zd 26 (28); none at q <= 0.05.
- Genus all view (genus_trios.tsv): every Zn-donor trio with Zh or TIL01 in the sister pair has Z > 3 (3.72-6.81);
  the two mexicana do not differ (Z 0.68). Lead: TIL25,TIL18;TIL01 +0.162, Z 3.23 (sister pair ambiguous, p 0.08).
- Citrus C1 D_pav(CsB,Cm;Cr) > 0 with Z > 3: yes, +0.855 ± 0.051, Z 16.85 (179/14), beyond every null; LTRmix D_ins
  +0.469 (Z 4.82). C2 +0.297 ± 0.312, Z 0.95 (24/13); LTRmix +0.012 (Z 0.15).
- Citrus recall at q <= 0.05: 0 of 5 (no tract reaches q <= 0.05; LTRmix none either).
- Citrus base pairs at any q: CsB 12 tracts 40.33 Mb, precision 0.821, recall 0.879 (LTRmix recent 0.836/0.949);
  CsA 3 tracts 3.80 Mb, 0.717/0.313 (LTRmix 0.808/0.604); at q <= 0.05 none. Element AUROC 0.993 (CsB), 0.995 (CsA).
- Citrus admixture fraction: f4 CsB 0.139 ± 0.040 (D2 CsA), 0.145 ± 0.042 (D2 CaM) vs truth 0.126; CsA 0.015 ±
  0.014 / 0.015 ± 0.015 vs 0.029; painting excess +0.103 / +0.004.
- EDTA portability (edta_vs_six.tsv; LTRquest = six/views/main): D_pav +0.305 ± 0.051, Z 5.94 (498/265; 0/30, 0/30)
  vs +0.290 ± 0.039, Z 7.39; dD +0.472, Z 2.83 vs +0.398, Z 3.14; chromosomes (posterior) chr4,chr5,chr9 2/3 (p 0.183)
  vs chr5,chr8,chr9 3/3 (p 0.0083); window r 1 Mb 0.231 vs 0.274, 10 Mb 0.311 vs 0.378 (all p 0.001); AUROC 0.672 vs
  0.712; median spacing 233 vs 85 kb; Inv4m B73~TIL18 block covers the interval on both (171 vs 700 loci). LTRmix EDTA
  (benchmark/edta/out/benchmark_real.tsv): D_ins +0.270 (Z 7.4), chr4,chr5,chr9, r 0.241/0.300, AUROC 0.677, no
  B73~TIL18 inverted block.

## Decision 11: the zd case beside nodonor
- Fallback discovery (findings.txt): Zn. Not eligible: TIL01 (groups with TIL18), TIL25 (groups with TIL18). The
  unnarrowed DESIGN 7.1 wording would add TIL01 and TIL25 (score_genus.py checks that list against findings.txt's).
- Four-point sums (zd_fourpoint.txt): Zn 0.879 < 0.907, 0.943; TIL01's smallest sum pairs it with TIL18 (0.821), as
  TIL25's (0.798).
- D_pav(Zh,TIL18;Zd) −0.217 ± 0.384, Z −0.57; n_RD 9, n_SD 14 (23 informative of 351 counted, 671 candidates); 12/30
  default and 23/30 bottleneck nulls reach |Z| 0.57.
- nodonor (SIM_RESULTS section 11, recomputed from perrun.tsv and checked against tables/decision11.tsv): 0/30 nulls
  |Z| > 3, mean Z −0.26, SD 0.90, 177 informative loci per null; Z > 3 in 7/36 power runs (210 loci per run), 2 of the
  7 (f0.50_Ta500_r2 Z 3.19, f0.50_Ta5000_r2 Z 3.38) with A2 in discovery. The genus case has 23 loci (13%); its test
  can see only |D| > 0.63 even at the binomial SE, so it tests the rule's choice of genomes, not power.
- Extra evidence from the all view: for TIL01,TIL25;Zd the narrowed rule admitted TIL18 (a mexicana, like TIL25) by a
  near-tie (sums 0.788 vs 0.797, 0.806); that trio reads +0.160, Z 1.38. PAV distances to the unannotated Zd are all
  lower (0.34-0.39) than among annotated genomes (0.43-0.59). Rule unchanged; the user decides.

## MISS investigation (staged in real/genus/dead_ends_entry_task14.md; cause corrected in fix round 1, review C1)
CsA chr2 25.48-32.94 Mb (pummelo in CsA), covered 0.340 by the one called tract (25.76-28.29 Mb, 8 RD, q 0.5).
- The default painting (`--discovery recipient`) reads only CsA's own annotated loci, classed by CsA's own calls: 40
  inside, 8 informative (all RD, 26.00-27.38 Mb); none informative among its 22 loci in the last 5.56 Mb (74.6%); the
  tract ends 0.915 Mb past the last RD locus (L ln 2 = 0.928 Mb, L 1.34 Mb).
- The merged genotypes (citrus/geno/loci.tsv) hold 80 CsA-present loci in the tract, 12 donor-like (Cm P, Cr E; of
  CsA's 25 genome-wide), none sister-like; 3 in the last 5.56 Mb: L0003433 (28,948,751) and L0003502 (32,578,262) are
  solo LTRs in CsA (S, high) that CsA's annotation does not report; at L0003449 (29,247,698) CsA's own call into Cr is
  U (flank_unaligned, inherited from its host L0003447) while CsB's, Cm's and CaP's calls into Cr read E (high).
- Repaint view citrus/views/c2_any (`--discovery any`): one tract 25,464,219-32,578,552 (82 loci, 12 RD, q 1) covers
  0.951; CsA bp precision 0.998, recall 0.922 (default 0.717/0.313); L 4.81 Mb; no tract at q <= 0.05.
- LTRmix's near_donor is mostly presence/absence evidence: 13 of its 17 copies in the tract have Cr absent in LTRmix's
  own calls. At 3 (26,751,696; 29,207,276; 30,639,028) LTRmix reads Cr absent where LTRpav reads Cr present at tier
  high: an untested genotype disagreement.
- Cause: the default's discovery rule (own annotation, own calls) plus one unresolved own call; not a lack of
  informative loci and not presence/absence-only painting. The MISS stands (`any` not adopted, rule 5). Plan 4 lead:
  `any` covers this real tract (0.951) while it called no q <= 0.05 tract in the simulated power runs.

## Tests
- genus/test_score_genus.py: 8 passed (-W error); output test_score_genus.out.
- citrus/test_score_citrus.py: 10 passed (coordinate conventions, the 50% rule at the boundary, q filters, controls,
  null quantiles, the I4 disagreement note, AUROC, admixture row, fail-fast); output test_score_citrus.out.
- edta/test_edta_vs_six.py: 2 passed; output test_edta_vs_six.out. Fix round 1 adds edta/test_age_mix.py (2 passed).

## Files written (all under real/)
- genus/: run_view.sh; views/{all,p1,p2,ctrl,zd}/; logs/; score_genus.py, test_score_genus.py, test_score_genus.out;
  genus_results.tsv (18 rows), genus_trios.tsv (20 trios); zd_fourpoint.py, zd_fourpoint.txt; RESULTS.md;
  fai.start.task14.tsv, fai.end.task14.tsv; memo_entry_task14.md; dead_ends_entry_task14.md.
- citrus/: views/{c1,c2,k1,k2}/; logs/; score_citrus.py, test_score_citrus.py, test_score_citrus.out;
  citrus_results.tsv (17 rows), citrus_truth_tracts.tsv (9), citrus_bp.tsv (4); investigate_c2.py,
  investigate_c2.txt; RESULTS.md.
- edta/: views/main/ (with edta_main_papers.tsv, edta_main_tables/, ltrmix_crosscheck.tsv); logs/; edta_vs_six.py,
  test_edta_vs_six.py, test_edta_vs_six.out; edta_vs_six.tsv (12 rows); RESULTS.md.
- Not edited: real/memo.md, benchmark_pav/dead_ends.md (entries staged, ruling R2), six/, common/, stability/.

## fai check
inputs/*.fai snapshot (name, size, mtime, sha256) before (15:57) and after all jobs and scoring (16:31):
genus/fai.start.task14.tsv and fai.end.task14.tsv identical, 15 files (also identical to six/fai.start.task13.tsv).

## Concerns (none blocking)
1. Decision 11: the narrowed four-point rule itself admitted a same-species genome (TIL18) for one all-view trio by a
   0.009 margin; PAV distances to an unannotated genome are deflated. Reported in genus/RESULTS.md for the user.
2. The genus and citrus sheets have no outgroup, while the simulated nulls of ruling R3 were counted with the
   outgroup rule. I also read every Z against the simulations' no-outgroup count (max |Z| 2.22 default, 3.19
   bottleneck): no reading changes. Stated in both RESULTS.md files.
3. The citrus MISS comes from the default painting's discovery rule (fix round 1): merged discovery (`any`) covers the
   tract 0.951. A Plan 4 lead, not a fix: `any` was not adopted by rule 5.
4. compare_papers.py writes ltrmix_crosscheck.tsv without the --prefix (into --run); harmless here (separate view
   directories), noted for Task 16, which owns that script.
5. Two LTRmix values are quoted from benchmark/REPORT.md text, not a table: the genus young-insertion counts (section
   6b) and the citrus ancestry excess +0.101 (section 6c).

## Step 3
Done (six/views/main was ready; Task 13 had finished its stats and paint parts before Step 3 started).

## Fix round 1 (2026-11-14 16:50-17:10; review task-14-review.md; rulings "Task 14 C1" and "Task 14 I1, M1-M8")
No verdict changed: genus 2 PASS / 0 MISS; citrus 6 PASS / 1 MISS (CsA chr2 still MISS); EDTA reported only.
Paths below are under real/ (P=/data2/chris/maize_introgression; snapshot 2 through common/env.sh for every python).

**C1. The CsA chr2 MISS: cause rewritten in all five places.**
- citrus/RESULTS.md:19-27 (verdict 1), :52-58 (terms: the two discovery rules), :109-148 (the MISS section: what the
  default sees, what the merged genotypes hold, the repaint, what LTRmix used, cause, verdict, Plan 4 lead), :183-199
  (headline: mechanism and prediction replaced), the Files section (c2_any, investigate_c2); genus/dead_ends_entry_task14.md (whole entry
  rewritten: evidence, cause tested, untested, what would change it); genus/memo_entry_task14.md (outputs line on the
  MISS, gotcha on the default's discovery, fix round 1); this report: MISS investigation section and concern 3.
- New view: `bash genus/run_view.sh citrus c2_any view` then `bash genus/run_view.sh citrus c2_any paint CsA,Cr,Cm
  --discovery any` (logs citrus/logs/c2_any.{view,paint}.{log,time,exit}, exit 0, paint 3.6 s, 1 thread; the paint
  log names snap/6282541). run_view.sh now passes options after the trio (genus/run_view.sh:2-14, 29-30).
- Recomputed by `cd citrus && python investigate_c2.py --citrus . --truth $P/benchmark/lineage2/truth
  --ltrmix-elements $P/benchmark/lineage2/out/CsA_Cr_Cm/elements.CsA.tsv --fai $P/inputs/CsA.fa.fai >
  investigate_c2.txt` (rewritten script; it imports score_citrus.py's read_posterior, read_tracts, read_truth,
  tract_cover and bp_scores; read_posterior now also keeps lid, score_citrus.py:137):
  - default painting (view c2): 40 loci inside (RD 8, both 10, neither 7, missing 15), informative 8 at
    26,000,114-27,379,210; longest stretch without one 5.560 Mb (74.6%); after the last RD 22 loci (3.95 per Mb), 0
    informative (computed; genome-wide 1,231 of 7,528 = 0.164, P(0 of 22) = 0.020); tract end 0.915 Mb past the last
    RD, L ln 2 = 0.928 Mb.
  - merged genotypes (citrus/geno/loci.tsv, CsA merged P/S/T, classes by merged Cr and Cm): genome-wide 10,504 loci,
    RD 25, RS 1,301, both 4,419, neither 492, missing 4,267; inside the tract 80: RD 12, both 32, missing 29, neither 7,
    RS 0. After 27,379,210: 3 RD: L0003433 at 28,948,751 (CsA S high; discovery Cm only; Cm->Cr E high), L0003449 at
    29,247,698 (CsA P annot; CsA->Cr U flank_unaligned, inherit, parent L0003447; CsB->Cr, Cm->Cr, CaP->Cr E high;
    merged Cr E high), L0003502 at 32,578,262 (CsA S high; discovery CsB,Cm,CaP; Cr E high/medium/medium).
  - view c2_any: pi 0.0106, L 4,805,660 bp, informative 1,326 (RD 25, RS 1,301); tracts CsA_chr2:25,464,219-32,578,552
    (82 loci, 12 RD, 0 RS, q 1.0) and CsA_chr8:7,233-948,905 (q 1.0), 1 decoy tract, 0 at q <= 0.05; coverage of the
    7.458-Mb tract 0.9512 (q <= 0.05: 0); of the 1.256-Mb chr8 tract 0.7497; CsA bp at any q: called 8,056,005,
    truth 8,714,296, shared 8,036,225, precision 0.9975, recall 0.9222. Reviewer: 0.951, 0.998, 0.922 (reproduced).
  - LTRmix near_donor in the tract: 17; LTRmix in_Cr absent 13, present 4; in_Cm present 17; LTRmix Cr absent with
    LTRpav's own Cr call P at tier high at 3 copies: 26,751,696; 29,207,276; 30,639,028 (labeled an untested genotype
    disagreement). 4 of the 6 near_donor copies past 27.38 Mb have Cr absent (28,284,955; 29,207,276; 29,247,698;
    30,639,028).
- Plan 4 lead line: citrus/RESULTS.md:147-148 and the dead-ends entry's last bullet.
- The `any` painting is not scored as a bar anywhere: citrus_results.tsv is unchanged in its verdicts (17 rows,
  PASS 6, MISS 1, reported 10).

**I1. EDTA mechanism.** edta/RESULTS.md:18-23 (result 1), 40-42 (in short), 82-92 (two bullets: the loss is not random;
two shifts cancel), 104-121 (headline: mechanism and prediction replaced). Durable script edta/age_mix.py (+ test_age_mix.py, 2 passed):
`cd edta && python age_mix.py --ltrquest ../six/views/main/stats.tsv --edta views/main/stats.tsv > age_mix.txt`:
- informative loci LTRquest vs EDTA: K=0 40 vs 25 (EDTA keeps 0.625), 0<K<0.01 397 vs 222 (0.559), K>=0.01 1,599 vs
  516 (0.323), all 2,036 vs 763 (0.375); K2P < 0.01 437 vs 247 (0.565); young share 0.215 vs 0.324.
- strata D: K=0 +0.600 both; 0<K<0.01 +0.6121 vs +0.6847; K>=0.01 +0.2020 vs +0.1279 (difference −0.0741, 1.06
  combined SE, not independent); recomputed totals +0.2898 and +0.3054 equal the primary counts.
- reweighted: EDTA strata at LTRquest's age mix +0.2457; LTRquest strata at EDTA's age mix +0.3344 (reviewer 0.246,
  0.334).

**M1.** genus/RESULTS.md:100-103: dD defined where it is printed: D(K=0) +0.50 on 4 loci (3 vs 1) minus D(K>=0.01)
+0.47 = +0.031 (Z 0.05), not the 0.07 between the K<0.01 and K>=0.01 strata (genus/views/p1/stats.tsv rows D_pav K=0
D 0.5 n 4, D_pav_gradient dD 0.0309 z 0.053).
**M2.** genus/RESULTS.md:95-97 ("Equal resolution removes the most direct way...; it does not exclude a resolution
that depends on the state") and :197-200 ("gave equal observation rates here...; the rule does not guarantee them").
**M3.** genus/RESULTS.md:176-179. Recomputed with `python3 -c` over genus/views/{p1,p2,ctrl,zd}/tracts.<R>.bed and
decoy_tracts.<S>.bed (sum_post, q): p1 142 tracts, 53 decoy, 15 outscore the best decoy (121.2), best q 0.067; p2
106, 45, 13, 0.077; ctrl 28, 32, 0, 0.741; zd 26, 28, 0, 0.736. With the +1 correction q <= 0.05 needs >= 20 tracts
above every decoy tract.
**M4.** citrus/RESULTS.md:155-157: k1 f4 0.0179 ± 0.0090 (Z 2.00, D2 CsB) and 0.0176 ± 0.0076 (Z 2.33, D2 CaP), from
`awk -F'\t' '$2=="f4_ratio" && $5=="f"' citrus/views/k1/stats.tsv`; called a second reading from the same loci.
**M5.** LTRmix in LTRpav's orientation: genus/RESULTS.md:25-28 and :67 (control: −0.307, same sign as −0.070, outside
the 95% interval −0.271 to +0.131 by 0.036); citrus/RESULTS.md:78, :89-90, :158-159 (k2: −0.130, same sign as
−0.118). score_genus.py:198-210 and score_citrus.py:297-309 now print it when LTRmix's roles are LTRpav's with
recipient and sister swapped; tests added (test_score_genus.py test_bars, test_score_citrus.py test_controls).
genus_results.tsv and citrus_results.tsv regenerated (same verdict counts).
**M6.** genus/memo_entry_task14.md: one "## Task 14" heading with inline labels (date, purpose, code, env, inputs,
fai, files, commands, wall, outputs, gotchas, fix round 1, session), as Task 13's entry; the MISS cause corrected.
**M7.** edta/RESULTS.md:73-77: LTRmix's LTRquest values named at $P/LTRmix/benchmark/results/main3, the path
compare_papers.py reads (its LTRMIX constant), not the $P/benchmark/results/main3 copy, which holds a different file
set.
**M8.** citrus/investigate_c2.py computes every printed claim, including the "0 informative" line; it now decides
"inside" by the midpoint, as score_citrus.py does (40 loci either way).

**Tests (rerun, -W error):** genus/test_score_genus.py 8 passed; citrus/test_score_citrus.py 10 passed;
edta/test_edta_vs_six.py 2 passed; edta/test_age_mix.py 2 passed (new). Outputs in the matching .out files.
**fai:** genus/fai.start.task14.fix1.tsv (16:53) = genus/fai.end.task14.fix1.tsv (17:01), 15 files; no file in any
geno/ newer than its block.done.
**Files added or changed in this round:** genus/run_view.sh, score_genus.py, test_score_genus.py, genus_results.tsv,
RESULTS.md, memo_entry_task14.md, dead_ends_entry_task14.md, fai.{start,end}.task14.fix1.tsv; citrus/views/c2_any/,
logs/c2_any.*, score_citrus.py, test_score_citrus.py, citrus_results.tsv (and the other two tables, regenerated
unchanged in content but for the orientation text), investigate_c2.py, investigate_c2.txt, RESULTS.md; edta/age_mix.py,
test_age_mix.py, test_age_mix.out, age_mix.txt, RESULTS.md. Nothing outside genus/, citrus/ and edta/ was written.

## Fix round 1, re-review items N1-N4 (2026-11-14 ~17:30; wording only, no number or verdict changed)
- **N1** genus/dead_ends_entry_task14.md:26-33: "each with Cr E at tier high in the discoverers' calls" became "each
  with merged Cr E at tier high", and each locus now states its own calls' tiers: L0003433 Cm->Cr E (high); L0003502
  CsB->Cr E (high), Cm->Cr and CaP->Cr E (medium); L0003449 CsA->Cr U (flank_unaligned), CsB/Cm/CaP->Cr E (high)
  (as checked against the pair files in fix round 1).
- **N2** edta/RESULTS.md:91-93: "The same shifts raise dD" became "The age mix cannot move dD, a difference of stratum
  values: dD rises on EDTA only because its old-stratum D is lower (D at K=0 is +0.600 on both), and its Z falls with
  the locus count" (dD = 0.600 − 0.202 = +0.398 LTRquest; 0.600 − 0.128 = +0.472 EDTA; age_mix.txt).
- **N3** genus/memo_entry_task14.md:44: "−0.307 in this orientation, Z 3.26" became "Z −3.26".
- **N4** whitespace-only rewraps at width 120 (words checked identical before and after): genus/RESULTS.md:90-99 (the
  "Why LTRmix failed" bullet, broken line 97) and :100-105 ("Age of the excess", broken line 103);
  citrus/RESULTS.md:52-60 (the "Painting" term, broken line 57). Not touched, per "change nothing else": one more
  overlong line of the same kind remains at genus/RESULTS.md:85 (129 characters, the P1 bullet).
