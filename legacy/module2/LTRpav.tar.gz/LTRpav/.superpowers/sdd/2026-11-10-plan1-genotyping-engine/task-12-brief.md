### Task 12: Window alignment (`localign.py`) and toy builders

**Files:** Create `src/ltrpav/localign.py`, `tests/test_localign.py`; Modify `tests/toy.py`

**Interfaces:**
- Produces:

```python
@dataclass
class Gap: a0: int; a1: int; b0: int; b1: int            # A-unaligned [a0,a1), B-unaligned [b0,b1), window coords
class AlnMap:                                             # collinear gap-free segments, sorted by A
    seg_a: np.ndarray; seg_b: np.ndarray; seg_len: np.ndarray; seg_mm: np.ndarray
    inv: list[tuple[int, int, int, int]]                  # inverted hits (a0, a1, b0, b1)
    def aligned_bp(self, a0: int, a1: int) -> int
    def a2b(self, a: int) -> int | None
    def gap_around(self, a: int, min_seg: int = MIN_SEG) -> Gap | None   # flanking segments >= min_seg around A pos a
    def b_gaps_within(self, a0: int, a1: int) -> list[Gap]               # B insertions between segments inside [a0,a1)
    def identity(self, a0: int, a1: int) -> float                        # 1 - mm/len over segments overlapping [a0,a1)
def align_window(a_seq: str, b_seq: str, preset: str = "asm20", backend: str = "mappy") -> AlnMap
def register_backend(name: str, fn: Callable[[str, str, str], AlnMap]) -> None   # bake-off hook (Task 24)
def preset_for_divergence(d: float) -> str     # <=0.001 asm5; <=0.01 asm10; else asm20 (minimap2 manual)
```

- `tests/toy.py` adds the following:
  - `make_element(rng, ltr_len, int_len) -> tuple[str, int, int]` (seq, left and right LTR lengths).
  - `CASES: list[str]` and `case(name, rng) -> ToyCase`. `ToyCase` has fields `a`, `b` (window strings),
    `elements` (list of `Element`, seqid "a", 1-based, k = 0.0) and `expect` (dict eid -> state).
  - `build_pair(rng, cases=CASES) -> ToyPair`: every case laid end to end on seqid `chr1` with 20-kb random spacers.
    Fields `a`, `b`, `elements`, `expect`.
- Toy case constructions (they fix the classifier tests in Task 14):
  - **Shared pieces:** `L`, `R` = 3 kb random flanks; `T = "CTCTC"`; `e = LTR(400) + INT(4000) + LTR` with identical
    LTRs.
  - **Host `h`:** `LTRh + INTh[:2000] + T2 + c + T2 + INTh[2000:] + LTRh`, where `c` is a 3-kb element and
    `T2 = "GAGAG"`.
  - **Random fillers:** `X` = random sequence of the stated length; `N100` = 100 Ns.

| case | A | B | expected |
|---|---|---|---|
| P | L T e T R | A mutated 1% | P |
| P_nestB | L T e T R | L T e[:2400] X3k e[2400:] T R | P + nestB |
| S | L T e T R | L T LTR T R | S + solo_tsd |
| S_notsd | L T e T R | L T LTR R | S |
| T | L T e T R | L T LTR INT[:1600] LTR T R | T |
| E | L T e T R | L T R | E + tsd_match, high |
| E_mm1 / E_mm2 | L T e T R | L T' R, T' with 1 / 2 mismatches | E + tsd_match / E, medium |
| D_left | L T e T R | L[:-500] R | D |
| D_both | L T e T R | L[:-300] R[400:] | D |
| O | L T e T R | L T X2k T R | O |
| G | L T e T R | L T N100 R | G |
| G_near / G_far | L T e T R | N50 placed 20 / 500 bp before the junction in L, then T R | G / E |
| U_flank | L T e T R | L T X3k | U, reason flank_unaligned |
| inv_site | L T e T R | L T revcomp(e) T R | U, reason inv_site |
| nested_E | L T h T R | L T h-without-c (one T2) T R | h P; c E |
| host_E | L T h T R | L T R | h E; c E + host_empty |
| host_S | L T h T R | L T LTRh T R | h S; c D |
| host_G | L T h T R | L T N100 R | h G; c G + inherit |
| adjacent_E | L T e1 T T2 e2 T2 R | L T T2 R | e1 E, e2 E, both + adjacent |

- [ ] **Step 1: Write the failing tests**

```python
def test_identical_one_segment():          # 20-kb identical: aligned_bp(0, 20000) >= 19950
def test_insertion_makes_gap():            # A = B + 6-kb element at 10 kb: gap_around(13000) spans the element +-50 bp
def test_divergence_identity():            # mutate 2%: identity(0, len) within 0.98 +- 0.005
def test_inversion_recorded():             # 3-kb inverted piece in B: inv non-empty and not in the collinear segments
def test_preset_for_divergence():          # 0.0005 -> asm5, 0.005 -> asm10, 0.02 -> asm20
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement the alignment.**
  - Use `mappy.Aligner(seq=b_seq, preset=preset, best_n=5)` and keep every hit.
  - On `+` hits, run a collinear chain DP that maximizes `mlen`. `-` hits go to `inv`.
  - Each kept hit's CIGAR (M, =, X, I, D) becomes gap-free segments. Count mismatches on M runs by comparing bytes
    with numpy.
  - `backend` looks up the registry; `"mappy"` is the only built-in.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add window alignment map and toy builders"`.

---

