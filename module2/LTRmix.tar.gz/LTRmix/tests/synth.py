"""Tiny synthetic LTR-RT libraries for three genomes with species tree ((R,S),D) and known truth.

Insertion classes per locus (positions shared by all genomes; coordinates of D shifted, and one D segment inverted):
  old      inserted before every split: present in R, S, D
  rs       inserted on the R-S branch: R, S
  rd / sd  incomplete lineage sorting: equal expected numbers (D = 0 without gene flow)
  private  one genome only
Introgression (optional): inside the tract, R's haplotype is a recent copy of D's (R carries D's elements at
near-identity and loses its own R-S insertions). Decoy: a high-copy family of near-identical copies at random
positions in every genome (no orthology). Divergences are in substitutions per site.
"""
import os
import numpy as np

ACGT = np.array(list(b"ACGT"), np.uint8)


def _mut(seq, d, rng):
    s = seq.copy()
    n = rng.binomial(len(s), min(d, 0.75))
    if n:
        pos = rng.choice(len(s), n, replace=False)
        s[pos] = (s[pos] + rng.integers(1, 4, n).astype(np.uint8)) % 4
    return s


def _element(fam, ltr, age, rng):
    """New insertion copy: family master + copy-specific noise, identical LTRs at insertion, then LTR-LTR
    divergence 'age' accumulated as two independent halves (applied later along lineages via _mut on the whole)."""
    core = _mut(fam, 0.02, rng)
    l = core[:ltr].copy()
    return np.concatenate([l, core[ltr:], l])


def make_trio(outdir, seed=1, admix=True, n_chrom=3, chrom_len=3_000_000, spacing=8000, inversion=True,
              decoy=True, t_rs=0.0015, t_split=0.006, t_deep=0.02, ltr=250, elen=2000):
    rng = np.random.default_rng(seed)
    os.makedirs(outdir, exist_ok=True)
    fams = [rng.integers(0, 4, elen).astype(np.uint8) for _ in range(6)]
    loci = []   # (chrom, pos, class, fam)
    classes = ["old"] * 30 + ["rs"] * 25 + ["rd"] * 6 + ["sd"] * 6 + ["pR"] * 11 + ["pS"] * 11 + ["pD"] * 11
    for c in range(1, n_chrom + 1):
        for p in range(50_000, chrom_len - 50_000, spacing):
            loci.append((c, p + int(rng.integers(-2000, 2000)), classes[rng.integers(len(classes))],
                         int(rng.integers(5))))
    tracts = [(1, 900_000, 1_700_000), (2, 2_200_000, 2_600_000), (3, 400_000, 1_000_000)] if admix else []
    inv = (2, 1_000_000, 1_800_000) if inversion else None
    recs = {g: [] for g in "RSD"}
    truth = []
    for (c, p, cl, fi) in loci:
        tsd = "".join("ACGT"[x] for x in rng.integers(0, 4, 5))
        in_tract = any(c == t[0] and t[1] <= p <= t[2] for t in tracts)
        if cl == "old":
            age, carriers = t_deep + rng.exponential(0.01), "RSD"
        elif cl == "rs":
            age, carriers = rng.uniform(t_rs, t_split), "RS"
        elif cl in ("rd", "sd"):
            age, carriers = t_split + rng.exponential(0.005), ("RD" if cl == "rd" else "SD")
        else:
            age, carriers = rng.uniform(0, t_rs), cl[1]
        base = _element(fams[fi], ltr, age, rng)
        # LTR-LTR divergence at the root = age (two LTRs each mutate age/2 independently)
        root = base.copy()
        root[:ltr] = _mut(base[:ltr], age / 2, rng)
        root[-ltr:] = _mut(base[-ltr:], age / 2, rng)
        root[ltr:-ltr] = _mut(base[ltr:-ltr], age / 2, rng)
        # coalescence of carriers: R-S at t_rs, (R,S)-D deep; each carrier mutates from the shared node
        node_rs = _mut(root, max(age - t_split, 0) / 2, rng) if "D" in carriers else root
        seqs = {}
        if "D" in carriers:
            seqs["D"] = _mut(node_rs, min(age, t_split + 0.004) / 2, rng)
        rs_node = _mut(node_rs, (t_split - t_rs) / 2, rng) if ("R" in carriers or "S" in carriers) else None
        for g in "RS":
            if g in carriers:
                seqs[g] = _mut(rs_node, t_rs / 2, rng)
        if in_tract:
            # R carries D's haplotype here: D's element at near-identity; R's own R-S insertions are absent
            seqs.pop("R", None)
            if "D" in seqs:
                seqs["R"] = _mut(seqs["D"], 0.0004, rng)
        for g, s in seqs.items():
            recs[g].append((c, p, s, tsd, age, fi))
        truth.append(dict(chrom=c, pos=p, cls=cl, carriers="".join(sorted(seqs)), in_tract=in_tract))
    if decoy:
        dec = rng.integers(0, 4, elen).astype(np.uint8)
        for g in "RSD":
            for _ in range(40):
                c = int(rng.integers(1, n_chrom + 1))
                p = int(rng.integers(60_000, chrom_len - 60_000))
                recs[g].append((c, p, _mut(dec, 0.001, rng), "".join("ACGT"[x] for x in rng.integers(0, 4, 5)),
                                0.001, 9))
    paths = {}
    for g in "RSD":
        fa = os.path.join(outdir, f"{g}.fa")
        tb = os.path.join(outdir, f"{g}.tsv")
        with open(fa, "w") as f1, open(tb, "w") as f2:
            f2.write("seq_id\tk2p\ttsd\tstrand\tltr5_len\tltr3_len\n")
            for (c, p, s, tsd, age, fi) in sorted(recs[g], key=lambda r: (r[0], r[1])):
                pos = p
                if g == "D":
                    pos = p + 100_000
                    if inv and c == inv[0] and inv[1] <= p <= inv[2]:
                        pos = inv[1] + inv[2] - p + 100_000
                name = f"{g}_chr{c}:{pos}-{pos + len(s) - 1}#LTR/Gypsy/fam{fi}"
                f1.write(f">{name}\n{bytes(ACGT[s]).decode()}\n")
                f2.write(f"{name}\t{age:.5f}\t{tsd}\t+\t{ltr}\t{ltr}\n")
        paths[g] = f"{fa},{tb}"
    return paths, truth, tracts, inv
