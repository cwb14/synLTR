# Task 16: controller rulings (binding; they override task-16-brief.md where the two differ)

Task 16 runs in two dispatches:
- **16A: Steps 2-3a.** compare_papers.py's final edits, final_papers.tsv, the diff against PRELIM, and FINAL.md.
- **16B: Steps 3b-4.** benchmark_pav/plan3/RESULTS.md, memo_ltrpav.md, DESIGN 12, the suite and the commit. It runs
  after Task 15.

The controller ran Step 1 (below) and hands off to the user (Step 5).

## R1. Step 1 is done by the controller
- `real/papers/views/main` was made by `real/papers/run_final_view.sh` (logs `real/papers/logs/`; marker
  `real/papers/final_view.done`):
  - `common/view.sh` over `six/geno` with `six/samples.tsv`. This is a fresh view, not a `cp -a`: view.sh's links
    are relative and break at another path. The same RUN and SHEET make it identical in inputs to six/views/main.
  - then `ltrpav-stats --trio B73,TIL01,TIL18 --identity --threads 32`, then `ltrpav-paint --trio B73,TIL01,TIL18`;
  - snapshot 2 (6282541), with inputs/*.fai compared before and after.
- Never rerun stats in it: a `--block-size` or plain stats rerun would drop identity.tsv (Task 7 m1).
- Use snapshot 2 for everything: `SNAP_SHA=6282541` via `common/env.sh`.

## R2. compare_papers.py's final edits (16A)
The file is `real/common/compare_papers.py` (Task 13's copy, sha256 1e04f43e...). Edit it in place and record the old
and new sha256.
- The brief's edits:
  - the verdict constants become PASS and MISS;
  - new rows read `sim/tables/` for rules 1-2 and the null distributions of Z and dD.
- **The D_pav row.** Bar D > 0 and Z > 3, with rules 1-2's outcome beside it. The null Z is not calibrated (rule 2
  reading), so the row also gives the empirical null quantile of Z for both the default nulls (max |Z| 1.97) and the
  bottleneck nulls (max |Z| 3.14). The verdict rests on the bottleneck null (controller ruling (I4), 2026-11-14).
- **The dD row ("gene flow, not lineage sorting").** dD was NA in 29 of 30 simulated nulls (rule 2: not
  demonstrated). Say that a simulated null of dD is not available, give the reason from SIM_RESULTS, and keep the
  row's bar as PRELIM reads it, with that caveat. Never invent a null.
- **Fix Task 13's two misreads on six-genome views,** which matter for papers/views/main (seven genomes):
  - row "1 roles" reads only the declared trio's rows (B73,TIL01;TIL18), not every trio's sharing rows;
  - row "14 direction" reads the view's direction status, with the "not validated by simulation (Plan 3)" note.
- **Task 14's finding:** `ltrmix_crosscheck.tsv` must carry the `--prefix` like the other outputs.
- Write tests for the fixed rows on small synthetic inputs, and make each fail before its fix.
- Then run `compare_papers.py --run papers/views/main --prefix final` and diff `final_papers.tsv` against
  `main3_analyses/prelim_papers.tsv`. Explain every changed row; main3 was engine 7d71073.

## R3. FINAL.md (16A) and plan3/RESULTS.md (16B)
- **FINAL.md:**
  - the 10.3 table with LTRmix's columns as in PRELIM;
  - the misses with their dead_ends entries;
  - what changed from PRELIM, and why;
  - CLAUDE.md's closing four items, each labeled by how far it was tested: the headline sentence, the mechanism, the
    generality (six genomes, genus, citrus) and the predictions.
- **plan3/RESULTS.md:** one page. It links sim/SIM_RESULTS.md and every real benchmark's RESULTS.md (six, genus,
  citrus, edta, stability, papers/FINAL.md), with one line per bar (PASS or MISS). The Plan 4 leads include the
  brief's list and these:
  - the direction test: DFOIL-alt's handling of a saturated statistic, and a positive control whose classes are
    non-empty;
  - the `any` discovery variant covers the real CsA chr2 tract (0.951) but called no q <= 0.05 tract in the simulated
    power runs;
  - D_pav was higher with LTRquest annotation in 3 of 3 simulated runs;
  - D_pav does not separate the six-genome positive and negative controls, while SNP D and LTRmix's D_ins do;
  - the FOUR_LIST_NOTE wording;
  - genotype_all.sh hardening;
  - the stale-stats advice omits --identity (Task 7 m1);
  - the s and D gaps the simulations could not test.
- Writing: for a non-CS biologist. Never present a null as a finding. Give statistics with every claim. Use American
  English and no AI attribution.

## R4. Records (16B)
- **memo_ltrpav.md** (`$P/memo_ltrpav.md`), a Plan 3 section:
  - dates;
  - snapshots: 12d3e6c for genotyping, 4f3973e for the grid, 6282541 for the real analyses;
  - envs and versions: msprime, LTRquest commit 5042a1e;
  - calibration values;
  - inputs and exact commands, outputs, wall times against the estimates, and gotchas, including the 2026-11-14
    parallel workers and the thread ceiling;
  - `claude --resume 6b33811c-ca10-4dfe-94dc-c7d4becddd02`.
- **DESIGN 12, "Plan 3 outcome"** (3-6 lines), with calibrate.sh's exact calibration values beside the src drafting
  defaults.
- **Commit and suite.** The commit changes no src, so no new snapshot. Run the focused checks, commit "Record Plan 3
  benchmark outcome" (global identity, no attribution), then launch the full suite detached with env ltrpav's bin on
  PATH. The controller reads the result.
