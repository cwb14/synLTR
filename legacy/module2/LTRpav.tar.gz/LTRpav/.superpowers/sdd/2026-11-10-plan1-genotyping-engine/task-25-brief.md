### Task 25: Whole-genome run on B73, TIL18, TIL01 + Zd and QC against DESIGN 10.1

**Files (outside repo):** `benchmark_pav/main3/{samples.tsv, run.log, qc_report.py, QC.md}`,
`/data2/chris/maize_introgression/memo_ltrpav.md`, `benchmark_pav/dead_ends.md`

- [ ] **Step 1: Write the samples sheet.**
  - `B73 inputs/B73v5.fa run/B73v5_LTRs maize .`
  - `TIL18 inputs/TIL18.fa run/TIL18_LTRs mexicana .`
  - `TIL01 inputs/TIL01.fa run/TIL01_LTRs parviglumis .`
  - `Zd inputs/Zd.fa . diploperennis outgroup`

  Use absolute paths. Zd has no `.fai`; the tool indexes it into `work/`.
- [ ] **Step 2: Launch.** `setsid -f nohup /usr/bin/time -v mamba run -n ltrpav ltrpav run --samples samples.tsv --outdir . --threads 32 > run.log 2>&1 < /dev/null`.
  Verify the PID (SID = PID, PPID = 1). Check `run.log` milestones while it runs.
- [ ] **Step 3: QC report.** `qc_report.py` writes `QC.md` with one row per DESIGN 10.1 bar and a plain pass or miss:
  - reciprocity >= 0.95
  - `annot_agree` >= 0.95 and `e_in_annot` <= 2%
  - the sim high-tier precision (from Task 24)
  - independent annotator: agreement of calls with the EDTA structural elements in `inputs/annot_*` (reported)
  - outgroup impossible patterns: ingroup E at loci where Zd is P/S/T (reported as an error-rate estimate)
  - LTRmix comparison: `benchmark/results/main3/elements.B73v5.tsv` `in_TIL18`/`in_TIL01` against LTRpav P/E for
    the same element names (reported)
  - runtime and RSS per pair against the cost bar
- [ ] **Step 4: Write up.** Each miss gets a short `dead_ends.md` entry and an investigation note. Misses are never
  tuned away; a rule changes only for a reason independent of the truth, then gets rechecked.
  Write `memo_ltrpav.md` (CLAUDE.md format): date, purpose, env and versions, inputs, exact commands, outputs,
  gotchas, `claude --resume` name.
- [ ] **Step 5: Hand off.** Report the QC table to the user. Plan 2 (analyses) is written next, from these outputs.
