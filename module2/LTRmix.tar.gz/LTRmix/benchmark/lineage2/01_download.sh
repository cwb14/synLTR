#!/usr/bin/env bash
# Citrus generality test: 6 haplotype assemblies (NCBI GenBank) + RefSeq C. sinensis proteins; md5-checked.
set -u
RAW=/data2/chris/maize_introgression/inputs/raw
B=https://ftp.ncbi.nlm.nih.gov/genomes/all
UA='Mozilla/5.0 (X11; Linux x86_64)'
for p in GCA/022/201/045/GCA_022201045.1_DVS_A1.0 GCA/022/201/065/GCA_022201065.1_DVS_B1.0 \
         GCA/059/628/685/GCA_059628685.1_ASM5962868v1 GCA/047/301/065/GCA_047301065.1_ASM4730106v1 \
         GCA/046/470/815/GCA_046470815.1_ASM4647081v1 GCA/046/470/805/GCA_046470805.1_ASM4647080v1 \
         GCF/022/201/045/GCF_022201045.2_DVS_A1.0; do
  n=$(basename $p); d=$RAW/$n; mkdir -p $d
  curl -sS -f -A "$UA" --retry 5 -o $d/md5checksums.txt $B/$p/md5checksums.txt
  for f in ${n}_genomic.fna.gz $( [[ $n == GCF_* ]] && echo ${n}_protein.faa.gz ); do
    [[ $n == GCF_* && $f == *_genomic.fna.gz ]] && continue
    want=$(grep " ./$f$" $d/md5checksums.txt | cut -d' ' -f1)
    have=$( [ -s $d/$f ] && md5sum $d/$f | cut -d' ' -f1 )
    [ "$want" = "$have" ] || curl -sS -f -A "$UA" --retry 5 -o $d/$f $B/$p/$f
    have=$(md5sum $d/$f | cut -d' ' -f1)
    [ "$want" = "$have" ] && echo "MD5_OK $f" || echo "MD5_BAD $f"
  done
done
echo DOWNLOAD_DONE
