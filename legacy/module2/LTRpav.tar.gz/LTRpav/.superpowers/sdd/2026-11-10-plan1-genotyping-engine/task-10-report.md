# Task 10 report: Chaining and 1:1 orthologous net

## Status: DONE_WITH_CONCERNS

Commit: `4d96241 Add chaining DP and 1:1 orthologous net` on branch `plan1-engine`. It uses the existing global git
identity, has no trailers and was not pushed.

## Controller rulings applied (2026-11-10)

- **Q1 -> (b).** `chain_blocks` drops no chain. It gives every chain a unique id and a `chain_score`. Ids are ordered
  by decreasing score, with ties broken by the input index of the chain's first block. `net_blocks` is the only
  `MIN_CHAIN_SCORE` filter. A chain whose kept pieces sum to less than `MIN_CHAIN_SCORE` is dropped, but it credits its
  competitors first. The brief's test values are kept: paralog matches 900, expected margin 1 - 900/20000.
- **Q2 -> ignore edge slop.** A competitor is credited only when its block overlaps a claimed piece by more than
  `CHAIN_OVERLAP` bp on A or on B. This has its own test: two abutting chains that overlap by 50 bp both keep margin
  1.0.
- **All five assumptions accepted.** Own-chain pieces never compete. Competition uses the block's full A and B spans.
  B maps back to A through interval boundaries, clipped to the free A part. Claims are kept in bucketed sorted lists.
  Ties are broken by input index.

## What I implemented (`src/ltrpav/chain.py`)

- **`chain_blocks(blocks)`**
  - Groups blocks by (a_chrom, b_chrom, strand), with one global lexsort by (group, a_start, a_end).
  - Minus-strand blocks use y = (-b_end, -b_start).
  - The DP is `@njit(cache=True)` (`_chain_dp`) and runs over all groups in one call. Each block carries its group
    start and group `maxlen`, so the lookback never crosses a group. The recurrence, break condition and skip
    conditions are exactly as in the brief.
  - Extraction (`_extract_chains`, also numba) visits blocks by f descending (stable) and backtracks until it reaches
    a used block. A chain's score is f[end] - f[stop], or f[end] when the walk reaches a chain start.
  - Ids are assigned by (-score, input index of the chain's first block in A order). Rows are returned sorted by
    (chain, a_start, a_end), and `margin` is left untouched.
  - Blocks with an empty A or B span are skipped with one warning, because `a_to_b` would divide by zero on them.
- **`net_blocks(blocks)`**
  - Raises `ValueError` if any `chain < 0`, meaning the input was never chained.
  - Visits chains by (-chain_score, chain id) and each chain's blocks in A order. For each block:
    1. `_credit`: every claimed piece of an earlier, kept chain that the block's full A span or B span overlaps by
       more than `CHAIN_OVERLAP` bp gets comp[owner] = max(comp[owner], chain_score).
    2. `_trim`: computes the free A parts, which exclude the claims of other chains and the pieces already kept for
       this chain. Each part maps to B as `[a_to_b(x0), a_to_b(x1-1)+1)` on plus or `[a_to_b(x1-1), a_to_b(x0)+1)` on
       minus. Claimed B is then removed, which also covers this chain's own pending pieces, re-queried for every A
       part. What is left maps back through the inverse map at the boundaries, clipped to the A part, and is kept if
       it is at least `ANCHOR_MIN` bp. A block with nothing claimed on its A or B span is kept whole, with no
       round-trip rounding.
  - Each piece is a new row with the block's chain, strand and chain_score, and matches/alen scaled by the kept A
    fraction (Python `round`).
  - A chain claims its pieces if their scaled matches sum to at least `MIN_CHAIN_SCORE`. Otherwise its pending pieces
    are discarded, but its credits stand.
  - margin = 1 - comp/chain_score where comp > 0, else 1.0, stored as float32. Output is sorted by (a_chrom, a_start).
    When comp > 0, the competitor came later, so chain_score >= comp > 0. The division therefore never sees a
    non-positive score.
- **`_Claims`** holds disjoint intervals per chromosome, filed in 64-kb buckets, each bucket a sorted list
  (`insort` / `bisect_right(key=end)`). An interval is reported once even when it spans several buckets.

## Tests (`tests/test_chain.py`): 21 run in CI plus 1 marked slow

- **Brief tests:** `test_chain_bridges_insertion` (also checks the score, 9300),
  `test_chain_breaks_on_far_gap` (2 Mb gives 2 chains; 0.5 Mb gives 1 as a control), `test_minus_strand_chain`
  (also checks that the same blocks on '+' give 3 chains), `test_net_drops_paralog` (the brief's values unchanged),
  and `test_net_trims_b_overlap`.
- **Controller's test:** `test_net_edge_overlap_within_slop_is_not_competition`, run for A and for B at 50 and 150
  bp. At 50 bp both margins stay 1.0; at 150 bp the winner's margin is 0.1.
- **Minus strand:** `test_net_minus_strand_chains_compete_for_b` (two '-' chains claim the same B; the loser keeps
  A[100000,105000)->B[10000,15000), and the piece's own `a_to_b` still maps in the minus direction) and
  `test_net_minus_strand_trim_on_a` (a '-' block trimmed on A maps to the correct B end, B[0,5000)).
- **Other tests:**
  - `test_chain_keeps_weak_chains_and_orders_ids` covers ruling (b) and the tie-break. A two-block chain and a
    single-block chain tie at 2000; the test tells "first block in A order" apart from "lowest input index".
  - `test_chain_tail_off_used_block_scores_f_end_minus_f_stop` pins the brief's extraction score (-24500) and checks
    that the net handles a negative score.
  - `test_net_trims_own_chain_overlap` (80-bp overlap within one chain: stays 1:1, no self-competition).
  - `test_net_drops_chain_below_min_score` (a weak chain alone is dropped; a chain trimmed below the threshold is
    dropped but still credits the winner).
  - Guard tests: `test_chain_skips_empty_blocks`, `test_empty_input` and `test_net_requires_chained_blocks`.
  - `test_net_is_one_to_one_on_random_blocks`, run on two seeded fixtures. It checks that chain_blocks drops nothing
    and that ids follow score. It checks that the net output is sorted and disjoint on A per chromosome and on B per
    chromosome, that every piece is at least `ANCHOR_MIN`, that every kept chain has at least `MIN_CHAIN_SCORE`
    matches, and that every margin is finite and in [0, 1]. It checks that every piece lies inside a block of its
    chain and follows that block's `a_to_b` within 2 bp. It also checks that the fixture really exercises the net:
    more than 10 kept chains, more than 20 trimmed pieces, and both challenged and unchallenged rows.
  - `test_chain_and_net_1e6_blocks_under_60s` is marked `slow`.

## TDD evidence

RED, before the module existed:
```
$ mamba run -n ltrpav pytest tests/test_chain.py -m "not slow"
E   ModuleNotFoundError: No module named 'ltrpav.chain'
1 error in 0.17s
```
RED, against a stub that raises `NotImplementedError`, so each test fails on its own:
```
$ mamba run -n ltrpav pytest tests/test_chain.py -m "not slow"
19 failed, 1 deselected in 0.25s
```
The first GREEN run had 18 passing and 1 failing (`assert (6 > 10)`). The failure was my own precondition that the
fixture is non-trivial, not a behavior check. I investigated it (see Self-review), and the final run is:
```
$ mamba run -n ltrpav pytest tests/test_chain.py -m "not slow" -W error
21 passed, 1 deselected in 0.67s
# cold numba cache (cache files deleted first), -W error:
21 passed, 1 deselected in 1.27s
$ mamba run -n ltrpav pytest -m "not slow" -W error
68 passed, 1 deselected in 1.42s
$ mamba run -n ltrpav ruff check .
All checks passed!        # after `ruff check --fix` reflowed the constants import (I001)
```

## Timing: 10^6 blocks (seeded synthetic; 10 chromosome pairs, 70% collinear including inverted pairs, 30% paralogs)

```
generate 0.2s | chain_blocks 2.5s (299441 chains) | net_blocks 12.7s (701171 pieces, 849 chains kept) | chain+net 15.2s
Maximum resident set size: 896468 kB (0.9 GB)
$ mamba run -n ltrpav pytest tests/test_chain.py -m slow -W error --durations=1
15.62s call  tests/test_chain.py::test_chain_and_net_1e6_blocks_under_60s     1 passed
```
The run takes 15.2 s against a 60 s limit, and every block, weak chains included, goes through the Python net.
The timing script is at
`/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/time_1e6.py`.

## Files changed

- `src/ltrpav/chain.py` (new, 321 lines)
- `tests/test_chain.py` (new, 257 lines)

`blocks.py` and `constants.py` are unchanged.

## Self-review findings, all fixed before the commit

1. **Bug caught before the first run.** `_trim` added pieces to the chain's own claims only after the loop. A later
   free A part of the same block could then reuse B already taken by an earlier piece; with B shorter than A
   (r < 1), rounding can map neighboring A parts to the same B base. Pieces are now added the moment they are made.
2. **Property-test precondition.** I had required more than 10 kept chains without knowing the fixture. I checked
   why only 6 survived, and the behavior was correct. Each 1050-block orthologous run, plus and minus, forms one
   chain and keeps every piece, and 84% A coverage leaves little room for paralogs. I moved the test to fixtures with
   more free space (`frac_ortho` 0.5 and 0.3, two seeds) and added an explicit check that more than 20 pieces were
   trimmed. The invariants themselves are unchanged.
3. **Debug log cost.** The `log.debug` in `net_blocks` built a set of every kept chain id even with debug off. It is
   now guarded by `isEnabledFor`.

## Concerns

1. **Chains scoring ≤ 0 now reach the net. This is the main concern, and it needs a ruling.** The brief scores an
   extracted chain as f[end] - f[stop]. When a paralog's best DP predecessor is deep in a big orthologous chain, the
   predecessor's f outweighs even a link cost near 50,000. At extraction the walk stops at that used block, and the
   paralog chain is charged for the link: its score drops by 0.05 x the B shift, which is often below zero. Under
   ruling (b) these chains reach the net. They never credit a competitor, because a score ≤ 0 cannot raise comp. They
   are also netted after every positive chain.
   - **Measured on the random fixtures:** 532 of 946 chains score ≤ 0 (seed 1) and 768 of 1253 (seed 2). Most are
     single blocks, and 360 and 530 of them carry at least 1000 matches. In seed 2, two chains with negative scores
     are kept (scores down to -13389, margin 1.0), and the code handles them safely.
   - **Biology:** the paralogs affected are exactly the local ones. These are tandem or segmental copies within about
     1 Mb downstream on B, in the same chromosome pair and strand as the orthologous chain. They are discounted as
     competitors, so the orthologous chain's margin is overstated, which is the ambiguity ruling (b) meant to catch.
   - **Proposed one-line fix:** score each chain from its own first block,
     `score = f[end] - f[first] + matches[first]`. This is identical to the brief whenever the walk reaches a chain
     start, and gives the tail its standalone score (3000 instead of -24500 in the pinned test).
   - **Status:** not applied, because the algorithm is fixed. `test_chain_tail_off_used_block_scores_f_end_minus_f_stop`
     pins the current behavior and would be the one test to change.
2. **One exception to "chain_blocks drops nothing".** Blocks with an empty A or B span are skipped with a warning,
   because they cannot be mapped (division by zero in `a_to_b`). They are malformed input, not low-scoring.
3. **Rounding of the specified forward map.** `a_to_b` at end positions can lose up to ceil(r)-1 B bases at the far
   end of a trimmed part when B is at least 1.5 times longer than A. Untrimmed blocks are kept whole, so this touches
   only trimmed parts of very gappy blocks.
4. **Coarse margins.** As specified, a competitor credits each overlapped piece with its whole chain score, whatever
   the overlap size beyond `CHAIN_OVERLAP`. A long piece is marked challenged by a modest overlap.

---

## Record: questions raised before coding (answered by the rulings above)

- **Q1.** `test_net_drops_paralog` conflicted with the fixed algorithm. The 900-match paralog has chain score
  900 < `MIN_CHAIN_SCORE`, so `chain_blocks` would remove it and the margin would be 1.0. The options were (a) change
  the test value or (b) stop dropping in `chain_blocks`. Ruling: (b).
- **Q2.** Should edge overlaps of at most `CHAIN_OVERLAP` count as competition? Ruling: no.
- **Assumptions 1-5** (own-chain exclusion, full-span competition, boundary back-mapping with clipping, bucketed
  claims, tie-break by input index of the first block in A order with rows sorted by (chain, a_start, a_end)):
  accepted.

---

## Fix report 1: rulings on the concerns (2026-11-10)

Rulings:
- **Concern 1.** Apply the proposed fix: an extracted chain is scored by its own blocks.
- **Concern 2.** Accepted as is: blocks with an empty A or B span are skipped with a warning.
- **Concern 3.** Deferred: no change now to the rounding of the forward map.

Commit: `2e82b0d Score extracted chains by their own blocks` (no trailers, not pushed).

### Changes (`src/ltrpav/chain.py`)
- `_extract_chains(f, p, matches, visit)`: `score = f[end] - f[first] + matches[first]`, where `first` is the chain's
  first block in A order, the last one reached by the backtrack. It replaces the marginal `f[end] - f[stop]`. The two
  are identical when the walk reaches a chain start, because there f[first] = matches[first]. The score now counts
  the chain's own blocks and links only, so a branch that stops at a used block is no longer charged for the link
  into it.
- `chain_blocks` passes the same int64 `matches` array to the DP and to the extraction. Its docstring now states the
  scoring rule and why: tandem paralog branches compete at full strength in the net.

### Tests (`tests/test_chain.py`)
- The pinned test is renamed `test_chain_tail_off_used_block_scores_its_own_blocks`. It now asserts chain scores
  [50000, 3000]; the old score was -24500.
- New test `test_net_tandem_paralog_branch_lowers_ortholog_margin`. The orthologous chain is X1 A[0,10000) and X2
  A[10000,20000) on B[0,20000), score 20000. A two-block tandem branch, P A[12000,15000)->B[200000,203000) and
  P2 A[15000,18000)->B[203000,206000) with 2900 matches each, has its DP predecessor on X1:
  f[P] = 10000 + 2900 - 0.05·188000 - log2(2001).
  - Under the old scoring the branch scored f[P2] - f[X1] = -3611, credited nobody, and left X2's margin at 1.0.
  - It now scores 5800 and lowers X2's margin to 1 - 5800/20000 = 0.71.
  - The branch is still dropped, because it has no free A.

### TDD evidence
RED, with the updated tests run against the old scoring:
```
$ mamba run -n ltrpav pytest tests/test_chain.py -m "not slow" -W error
E         At index 1 diff: np.float64(-24500.0) != 3000
E         Obtained: -3610.9665054519064
E         Expected: 5800 ± 0.0058
2 failed, 20 passed, 1 deselected in 0.73s
```
GREEN, after the fix:
```
$ mamba run -n ltrpav pytest tests/test_chain.py -m "not slow" -W error
22 passed, 1 deselected in 1.31s
# cold numba cache (chain*.nbi/.nbc deleted), -W error:
22 passed, 1 deselected in 1.30s
$ mamba run -n ltrpav pytest tests/test_chain.py -m slow -W error --durations=1
15.97s call     tests/test_chain.py::test_chain_and_net_1e6_blocks_under_60s
1 passed, 22 deselected in 16.21s
$ mamba run -n ltrpav pytest -m "not slow" -W error
69 passed, 1 deselected in 0.75s
$ mamba run -n ltrpav ruff check .
All checks passed!
```

### New timing (10^6 blocks, same fixture and script as above)
```
generate 0.2s | chain_blocks 2.5s (299441 chains) | net_blocks 13.0s (701171 pieces, 849 chains kept) | chain+net 15.6s
Maximum resident set size: 890820 kB
```
Before the fix the same run took 15.2 s, so the speed is unchanged.

### Effect on the random fixtures (scratch: inspect_random2.py, inspect_random3.py)

| Fixture | Chains scoring ≤ 0, before -> after | Rows with margin < 1, before -> after |
|---|---|---|
| seed 1, frac_ortho 0.5 | 532/946 -> 0/946 | 1314 -> 1443 |
| seed 2, frac_ortho 0.3 | 768/1253 -> 0/1253 | 968 -> 996 |
| frac_ortho 0.7 | | 1264 -> 1517 |

- Kept chains with a negative score: 2 -> 0.
- In these fixtures the claimed space is identical: the same rows, kept chains and trimmed pieces. What changed is
  that competitors that were hidden are now recorded in the margins.

### Remaining notes
- A chain's own score can still be ≤ 0 if one of its internal links costs more than it gains. That is now
  theoretical (0 cases in the fixtures), and the net already handles it: such a chain credits nobody, and its margin
  is 1.0 if it is never challenged.
- A large branch can now outscore the chain it branched from and be netted first. That is intended: in the net, the
  best chain by its own score wins.

---

## Fix report 2: review round 1 (findings 1 and 2; 2026-11-10)

Commit: `81aaa8f Chain overlapping collinear blocks; enforce ANCHOR_MIN in the net` (no trailers, not pushed).
Minor findings were left for the final review, as instructed.

### Finding 1: `ANCHOR_MIN` now applies to unchallenged blocks
- `_trim` returns `[]` when `a1 - a0 < ANCHOR_MIN`, before the whole-block shortcut. Every piece is a subset of its
  block, so a shorter block can never yield one. The block still credits competitors first, as before.
- The `net_blocks` docstring now says that a block shorter than `ANCHOR_MIN` yields no piece and that an unchallenged
  block is kept whole as a single part. The `_trim` docstring says the same.
- The random fixture now draws block lengths of 20-5000 bp, about 1.6% below 100 bp. Against the old code, the
  property assertion `a_end - a_start >= ANCHOR_MIN` now fails on both seeds; it passes after the fix.

### Finding 2: the ruling on the DP's progression test
- **`_chain_dp`.** The old skip (`da < -CHAIN_OVERLAP or db < -CHAIN_OVERLAP`) is replaced. Block j may precede
  block i only if all four of x0[i]-x0[j], x1[i]-x1[j], y0[i]-y0[j] and y1[i]-y1[j] are at least `ANCHOR_MIN`,
  passed in as `min_step`, with y in strand-transformed coordinates.
  - Unchanged: `da, db <= CHAIN_MAX_GAP`, the break condition, the overlap correction
    `gain = matches[i] - max(0, -min(da, db))` and the gap cost.
- **Docstrings.** The `chain_blocks` docstring gives the new rule, the minimap2 analogy, and what it links (solo-LTR
  flanks, chunk-edge pieces) and does not link (tandem copies whose ends do not advance). The `_chain_dp` docstring
  names `min_step`.
- **`constants.py`.** The reason for `CHAIN_OVERLAP` is the ruling's wording verbatim: "overlaps up to this size
  between blocks of different chains are alignment-edge slop, not competition". Inline it would be 129 characters,
  against a project line length of 110, so it sits on its own line directly above the constant. `CHAIN_OVERLAP` is
  now used only in `_credit`.

### Tests (`tests/test_chain.py`): 29 run in CI plus 1 slow, up from 22 plus 1
- **(a)** `test_chain_links_solo_ltr_flanks`, with both probe5 constructions:
  - **Two flank blocks** of about 40 kb, each including a 1.5-kb LTR, overlapping by B[40000,41500). They form one
    chain (score 79515), and the net gives A[0,41500)->B[0,41500) and A[48000,88000)->B[41500,81500). The solo LTR is
    assigned to the first flank; all margins are 1.0. Before the fix these were two chains and the margin was 0.000.
  - **Upstream block plus the two flanks.** They form one chain (score 108915) with all margins 1.0; before the fix
    one margin was 0.420.
- **(b)** `test_chain_does_not_link_tandem_paralog`, with a tandem copy on B (nearly identical A span, adjacent on
  B) and a tandem copy on A (the mirror case). In both, the start does not advance by at least 100 bp, so they are
  not linked: two chains, and the ortholog's margin is 1 - 9000/10000.
- **(c)** `test_chain_links_same_diagonal_overlapping_pieces`, with 2 or 10 chunks of 110 kb, 10 kb overlaps, the
  probe6 construction. Each forms one chain (score 978200 for 10 chunks) with all margins 1.0, and the net output
  tiles A and B from 0 to the end exactly once. Before the fix it gave interleaved chains and margins of 0.018.
- **Finding 1 test:** `test_net_drops_blocks_below_anchor_min`, from probe1 1a/1b. An 80-bp block is dropped both
  when unchallenged and when 1 bp of its B is claimed by a better chain.
- **(d) The one existing test that encoded the old skip rule:** `test_net_trims_b_overlap`. Its two A regions,
  A[0,10000) and A[50000,60000), sat on the same chromosome and overlapped by 5 kb on B. Both ends advance on both
  genomes, so the new rule links them: f = 10000 + (9000 - 5000) - 0.05·45000 = 11750, one chain. The trim became an
  own-chain trim, and the winner's margin was 1.0 instead of the expected 0.1.
  - Adjustment: the second region moves to A chromosome 1, a distinct locus that cannot chain. The test's intent,
    expected spans and expected margins are unchanged.
  - No other existing test changed.

### TDD evidence
RED, with the new tests and the 20-bp fixture run against the old code (`test_net_trims_b_overlap` unchanged):
```
$ mamba run -n ltrpav pytest tests/test_chain.py -m "not slow" -W error
FAILED test_chain_links_solo_ltr_flanks[rows0-spans0], [rows1-spans1]
FAILED test_chain_links_same_diagonal_overlapping_pieces[2], [10]
FAILED test_net_drops_blocks_below_anchor_min        (Left contains one more item: (5100, 5180, 5100, 5180))
FAILED test_net_is_one_to_one_on_random_blocks[1-0.5], [2-0.3]   (a_end - a_start >= ANCHOR_MIN)
7 failed, 22 passed, 1 deselected in 0.73s
```
After the fix, before adjusting the existing test:
```
FAILED tests/test_chain.py::test_net_trims_b_overlap - assert np.float32(1.0) == 0.09999999999999998 ± 1.0e-06
1 failed, 28 passed, 1 deselected in 1.49s
```
GREEN, after the adjustment:
```
$ mamba run -n ltrpav pytest tests/test_chain.py -m "not slow" -W error
29 passed, 1 deselected in 0.68s          # also 29 passed with a cold numba cache (1.50s)
$ mamba run -n ltrpav pytest -m "not slow" -W error
76 passed, 1 deselected in 0.83s
$ mamba run -n ltrpav ruff check .
All checks passed!
```
Reviewer probes rerun against the fixed code:
- probe1 1a/1b: the 80-bp block is dropped in both cases.
- probe5: one chain, all margins 1.0.
- probe6: one chain of 10 pieces, all margins 1.0.
- probe4 (10-kb blocks): the 1.5-kb LTR1-only block cannot advance on B past the right flank, so it stays its own
  chain (score 1470). It credits that flank with margin 0.993 to 0.998, a real but tiny ambiguity: is the solo LTR
  LTR1 or LTR2?

### Timing (10^6 blocks; the shared server was heavily loaded)
```
$ mamba run -n ltrpav pytest tests/test_chain.py -m slow -W error --durations=1     # final run (load avg 77)
23.26s call     tests/test_chain.py::test_chain_and_net_1e6_blocks_under_60s     1 passed
# timing script, same 15 s window, load avg ~77:
default env:                generate 0.3s | chain_blocks 7.1s | net_blocks 17.2s | chain+net 24.3s
NUMPY_MADVISE_HUGEPAGE=0:   generate 0.3s | chain_blocks 2.9s | net_blocks 14.0s | chain+net 16.8s
```
- **An earlier run failed at 138.8 s.** It came during a contention spike: in that window even the unchanged data
  generation took 43.0 s instead of 0.3 s, `kcompactd` was at 96% CPU, swap was full, and two `rmfast` jobs ran at
  about 1500% CPU. Rerun minutes later, the slow test passed in 23.3 s.
- **The new DP costs nothing measurable.** Its loop bounds are unchanged; it took 0.42 s for 2×10^5 blocks.
- **Note on the hugepage guard.** `tests/test_chain.py` and my timing script import numpy before `ltrpav`, so the
  package's `NUMPY_MADVISE_HUGEPAGE=0` guard does not apply to them. That is a pre-existing pattern in every test
  module. Under memory pressure this alone moved chaining from 2.9 s to 7.1 s. A `tests/conftest.py` that sets the
  variable would make the slow test less sensitive to load. I did not add one, since it is outside these findings.

### Behavior worth knowing (probe: scratchpad edge_probe.py)
1. **A duplicated unit inside a collinear run is netted to its first copy, with no record of competition.**
   Example: B carries a tandem copy of A[2000,10000) at B[10000,18000), and the second alignment continues past it,
   (0,2000,12000)->(10000,20000). One chain results, with A[10000,12000)->B[18000,20000) and margins of 1.0. This is
   the mirror of the solo-LTR case and follows from the ruling's minimap2-style rule. It is a sound 1:1 reading, but
   the margin does not record which copy is orthologous.
2. **Exact duplicate blocks act as competitors (a concern for the mapping step).** A duplicate advances by 0, so it
   is not linked and becomes its own chain with an equal score. That gives margin 0.0 for a standalone block and
   0.909 for a 5-kb duplicate inside a 54-kb chain. A chunked mapper reports an alignment lying wholly inside an
   `MM2_OVERLAP` window from both chunks with identical coordinates. Those duplicates should be removed upstream,
   for example with `np.unique` on (a_chrom, a_start, a_end, b_chrom, b_start, b_end, strand) before
   `chain_blocks`. This needs a ruling on where that happens; I did not implement it.

### Files changed
- `src/ltrpav/chain.py`
- `src/ltrpav/constants.py` (the reason line for `CHAIN_OVERLAP`)
- `tests/test_chain.py`

### Fix report 2, addendum: rulings on fix-round-1 concerns (2026-11-10)

Commit: `c610c3e Drop exact duplicate blocks before chaining; THP guard for tests` (no trailers, not pushed).

Rulings:
- **Concern 1 (exact duplicates).** `chain_blocks` collapses them first. Implemented below.
- **Concern 2 (a duplicated unit inside a collinear run goes to its first copy).** Accepted as is; recorded only.
- **Concern 3 (the hugepage guard bypassed in tests).** Add `tests/conftest.py`. Implemented below.

**Changes**
- `src/ltrpav/chain.py`:
  - New `_distinct(blocks, idx)`. Rows equal on (a_chrom, a_start, a_end, b_chrom, b_start, b_end, strand)
    collapse to the row with the most matches, the first in input order on ties. It uses one lexsort by
    (key, -matches, input index) and keeps the first row of each key. The result stays in input order, so the
    stable group sort and the chain-id tie-break are unchanged.
  - `chain_blocks` calls it after the empty-span filter and logs the number removed at DEBUG on `ltrpav.chain`, not
    WARNING. Its docstring says duplicates are one alignment reported twice, never independent evidence of
    paralogy.
- `tests/conftest.py` (new): `os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")`, with a one-line comment. Test
  modules import numpy before `ltrpav`, so the package's guard would otherwise come too late.

**Tests**
- New `test_chain_collapses_exact_duplicates`:
  - One alignment reported three times, with matches 4900, 4800 and 4900 and alen 5001, 5002 and 5003. One row
    remains: matches 4900, alen 5001 (most matches, first on ties). DEBUG shows "dropped 2 exact duplicate
    block(s)", and nothing is logged at WARNING or above.
  - The standalone duplicated block keeps margin 1.0; before, it was 0.0.
  - Inside a chain (a 50-kb block, then a 5-kb block reported twice), the result is one chain with all margins 1.0;
    before, the margin was 0.909.
- The conftest was checked with a throwaway test, not committed, in a module that imports numpy first.
  `np._core.multiarray._get_madvise_hugepage()` was True without the conftest (the test failed) and False with it
  (the test passed). The throwaway file was deleted.

**Commands and output**
```
# RED: new test against the previous code
$ mamba run -n ltrpav pytest tests/test_chain.py -m "not slow" -W error
E       AssertionError: assert (3 == 1)
1 failed, 29 passed, 1 deselected in 0.73s
# GREEN
$ mamba run -n ltrpav pytest tests/test_chain.py -m "not slow" -W error
30 passed, 1 deselected in 0.65s
$ mamba run -n ltrpav pytest -m "not slow" -W error
77 passed, 1 deselected in 0.81s
$ mamba run -n ltrpav ruff check .
All checks passed!
# slow timing test, run once (uptime before: load average 84.36, 77.91, 69.87; after: 84.12, 78.17, 70.09)
$ mamba run -n ltrpav pytest tests/test_chain.py -m slow -W error --durations=1
18.56s call     tests/test_chain.py::test_chain_and_net_1e6_blocks_under_60s
1 passed, 30 deselected in 18.81s
```
The slow test took 18.6 s at load average 84, against 23.3 s at load 77 before the conftest; the guard now applies
inside the test. The server has 256 cores. The single 138.8 s failure earlier coincided with a memory-compaction
spike.
