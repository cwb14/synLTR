### Task 7: Command-line options and stage keys: `--discovery`, `--emission`, `--block-size`

**Files:**
- Modify:
  - `src/ltrpav/analysis/cli.py`, `report.py`, `stats.py`;
  - `tests/test_cli_analysis.py`;
  - `docs/DESIGN.md` 7.1, 7.3, 7.4, 8 and 10.4: the options and their roles.

**Interfaces:**
- Consumes: `paint(..., discovery, emission)` (Task 6); `stats.block_size`.
- Produces:
  - `ltrpav-paint --discovery {recipient,any}` (default `PAINT_DISCOVERY`).
  - `ltrpav-paint --emission {em,decoy}` (default `PAINT_EMISSION`).
  - `ltrpav-stats --block-size BP`: an integer >= `BLOCK_MIN`. Without it, DESIGN 7.3's rule applies.
  - `stats.block_size(cat, override: int | None = None) -> int`, and one row:
    `StatRow("pav", "jackknife", "all", "all", "block_bp", size, loci="none", note="rule" | "--block-size")`.
  - Stage keys and markers include `discovery`, `emission` and `block_size`. The stale-part check reads them from
    markers with `.get(name, default)`.
  - `ltrpav run` keeps the defaults and gains no option.

- [ ] **Step 1: Write the failing tests.**

```python
def test_paint_discovery_any_cli(tmp_path):  # rows' loci declare disc=any; posterior and tracts files written
def test_paint_emission_rerun(tmp_path):      # default paint, then --emission decoy: paint stage recomputed; the same
                                              # again: skipped; emission row "decoy"
def test_old_marker_reads_defaults(tmp_path): # a paint marker without the new keys: no KeyError; read as the defaults
def test_block_size_option(tmp_path):         # toy where 1-Mb blocks give >= 3 blocks; --block-size 1000000: block_bp
                                              # row 1000000, D_pav se finite and different from the
                                              # default; --block-size 5 -> exit 2
def test_plot_accepts_default_options(tmp_path):  # stats + paint (defaults) + plot: draws (Plan 2 sentinel rules hold)
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement** the options, keys and rows. Keep the plot stage's sentinel checks (Plan 2 final wave I2).
- [ ] **Step 4: Run** the suite, ruff and the engine-key check.
- [ ] **Step 5: Commit:** `"Expose the painting variants and the jackknife block size on the command line"`. This head is
  what Task 8 snapshots.

---

