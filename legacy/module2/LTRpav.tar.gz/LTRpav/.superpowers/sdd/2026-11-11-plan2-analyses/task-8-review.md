# Task 8 review: Mechanisms and missingness (DESIGN 7.8)

**Range:** 0332c9f..71b8648 (7bb87fc, 71b8648). **Files:** `src/ltrpav/analysis/mechanisms.py` (new),
`tests/test_mechanisms.py` (new). **Reviewer scratch:** `/data2/chris/maize_introgression/benchmark_pav/plan2_reviews/task8/`.

**Verdicts:** Spec ✅ (two ⚠️ notes). Task quality: **Needs fixes**: 0 Critical, 1 Important, 4 Minor.

## Spec Compliance

✅ **Matches the brief and the controller rulings.**

- **Files and interfaces:**
  - Only the two new files changed; no engine module was touched.
  - `MECH_COLUMNS`, `pair_calls`, `o_kind`, `d_kind`, `pair_mechanisms`, `dollo`, `mechanisms` and `write_mechanisms`
    have the brief's signatures.
  - Engine constants are read from `ltrpav.constants`, with no copies.
- **Brief tests:**
  - The 7 tests and the `_table` helper are AST-identical to the brief (`ast_check.py`).
  - `python -m pytest -W error tests/test_mechanisms.py`: 16 passed.
  - `ruff check` is clean on both files. CI runs `ruff check` only, so `ruff format` is not a gate.
- **Commits:** author and committer are cwb14. There are no trailers and nothing mentions Claude or Anthropic. The
  first commit's message is the brief's.
- **The rule split:**
  - `d_kind` and `o_kind` use w = `SLOP_TSD_MULT` × len(tsd), or × `TSD_DEFAULT` without a TSD.
  - O_inside follows the ruling, and the lower bound is `frac_D_inside + frac_O_inside`.
  - Inherited D and O (rule 0, dl and dr ".") count as D_beyond and O_complex, per the ruling.
- **Tables:**
  - The states, absence, events, missingness and branches tables follow the brief's rules.
  - The states table keeps nonzero rows for named families, and every metric for each rollup, per the ruling.
- **Dollo:** `dollo` raises without an outgroup or an outgroup-rooted tree; `mechanisms` writes one skip line
  instead (ruling).
- **Stats rows:** tests `mechanisms`, `absence_events`, `missingness` and `branches`, plus the resolution rows
  required by the Task 3 constraint.
- **Findings:** the bounds by age, the multi-element split and the per-branch counts.
- **Global constraints:**
  - O at the site means |dl|, |dr| <= w.
  - Missing states never count as absence: Dollo's missing sets, resolved = P/S/T/E. The table's E + D + O
    "absent" is descriptive, as plan review I3 accepted.
  - The evidence (dl, dr, tsd_a) is read per ordered pair from the pair files.
  - `b_ins` is not needed by `o_kind` as specified.
  - Analysis code stays in `analysis/`.

⚠️ **The dispatch's constraint "ancestral absences = E plus O at the site" contradicts its own cited sources.**
- Plan review I3 (`plan2-review.md`:240-262) and revised decision 41 (`plan2-draft-summary.md`:207-210) both make O at
  the site *undetermined*: an independent insertion at the site leaves the absence ancestral, while a replacement
  makes it derived.
- Both give 1 - frac_E as the upper bound, and the brief does too.
- The code follows I3 and decision 41. If E + O_site was really meant, the upper bound becomes 1 - frac_E - frac_O_site:
  main3 B73>TIL18 'all' 0.646 instead of 0.651.

⚠️ **The brief contradicts itself on the branches table.** It says "event and branch rows carry superfamily, family
and age all", and also "per (branch, superfamily) and all". The code writes both the superfamily rows and the `all`
rows, which satisfies the more specific rule and the brief's tests.

## Independent verification (named risks)

1. **The dl/dr sign against classify.py rule 4.**
   - `classify.py`:192 sets dl = s - g.a0 and dr = g.a1 - t (balanced), so negative values lie inside the element,
     and :193-194 read "below -w, B keeps part of the element". `d_kind` and `o_kind` test dl < -w or dr < -w.
   - Engine-level probe (`sign_probe.py`): the real `classify_window` (mappy) ran on constructed B sequences, the
     construction of `test_element_remnant_is_d_not_e`, with seeds 7 and 1. Each call was read through `_metric`:

     | B at the site | engine call (dl, dr) | read as |
     |---|---|---|
     | 60-bp remnant, left | D (-60, 0) | D_inside |
     | 60-bp remnant, right | D (-1, -59) | D_inside |
     | 300 bp of flank lost | D (305, 0) | D_beyond |
     | remnant + 500 bp B-only | O (-60, -2) | O_inside |
     | 500 bp B-only at the site | O (-2, -2) | O_site |
     | flank lost + B-only | O (304, -2) | O_complex |
     | empty site | E (2, 3) | n_E |

   - Rule 4 and the three constants are unchanged since main3's engine 7d71073 (`git diff 7d71073 HEAD`).
2. **w per element.**
   - `_Site` sets L = len(e.tsd) or TSD_DEFAULT, and `tsd_a = e.tsd` (`classify.py`:418-419, 428). `_w` does the
     same from `tsd_a`. "." gives TSD_DEFAULT, and so does an empty string, as in the classifier.
   - On main3 (B73>TIL18, TIL01>Zd, TIL18>B73; 390,124 calls):
     - `tsd_a` equals the element table's TSD on every call.
     - The classifier's own rules hold with this w: no E lies outside -w..w except as `adjacent`, no D has both ends
       within w, and no E or small_ins lies inside. That is 0 contradictions.
     - E calls with |d| in 11-12 at 6-bp TSDs exist; they need the element's own w.
     - Element TSD lengths: 4 bp 2,447; 5 bp 89,437; 6 bp 1,081; none 34,671 (B73).
     - Only 1-2 calls per pair would flip under w = 10 everywhere.
   - `_metric` cases with 4- and 6-bp TSDs, "." and an empty string are all right.
3. **Dollo** (`test_dollo_probe.py`):
   - `_place` was checked against an independent set-based reading of the rule: 300 random trees of 3-7 genomes
     (1-2 outgroups) and 120,000 patterns (81,163 placed, 31,604 incongruent, 7,233 with no present genome). All
     identical.
   - A hand-built 9-locus toy run matches every count worked out by hand: an incongruent locus (S E inside a
     root clade), missing S/G/U, a D outside the clade, solo plus truncation on sibling leaves, before_root plus a
     deletion, and a Copia/Gypsy split.
   - main3 recount from loci.tsv's merged states with no ltrpav code (`dollo_main3.py`): every nonzero
     (branch, superfamily) row is identical; 316,818 placed and 5,720 incongruent.
4. **Event grouping.** My own union-find, over parent links with host_empty for E and inherit for D, plus
   `adjacent` per (state, wid), equals the code on the three main3 pairs. Every linked host is found with the same
   state. B73>TIL18:
   - E: 17,413 single + 4,140 clusters (9,235 elements);
   - D: 14,805 single + 5,842 multi-element events (12,842 elements).
5. **U reasons.**
   - The engine has 5 window statuses (`window.py`:33) and 5 classifier reasons: no_alignment, flank_unaligned,
     inv_site, ambiguous, unanchored.
   - Rule 0 passes the host's reason on, and the tally takes whatever string appears.
   - B73>TIL18 holds 9 of the 10 reasons. The fractions equal my tally: unanchored 0.0684, inv_site 0.0222,
     flank_unaligned 0.0141, breakpoint 0.0133, ambiguous 0.0090, span_cap 0.0075, no_right_anchor 0.0043,
     no_left_anchor 0.0040, no_anchor 0.0036; U 0.1463, G 0.00016.
6. **main3 B73 -> TIL18 recomputed** from the raw pair file and `work/elements/B73.tsv`, with no ltrpav code
   (`indep_pair.py`). The table below matches the report digit for digit:

   | age | n_absent | E | D_inside | O_inside | D_beyond | O_site | O_complex | upper | lower |
   |---|---|---|---|---|---|---|---|---|---|
   | K=0 | 4,028 | 0.4598 | 0.0119 | 0.0017 | 0.3066 | 0.0077 | 0.2123 | 0.540 | 0.0137 |
   | 0<K<0.01 | 28,949 | 0.3841 | 0.0105 | 0.0017 | 0.3475 | 0.0046 | 0.2516 | 0.616 | 0.0122 |
   | K>=0.01 | 43,441 | 0.3149 | 0.0194 | 0.0093 | 0.3489 | 0.0045 | 0.3030 | 0.685 | 0.0288 |
   | all | 76,418 | 0.3487 | 0.0157 | 0.0060 | 0.3461 | 0.0047 | 0.2788 | 0.651 | 0.0217 |

   - Inherited calls: 6,987 D and 5,545 O.
   - Running the code itself through a symlinked view: all 20,517 B73>TIL18 rows of states, absence, events and
     missingness are identical to my recount (to 6 significant digits). So are all 21,702 TIL01>Zd rows and all
     20,257 TIL18>B73 rows.
   - Cost: mechanisms 12.8 s, peak 0.60 GB.
   - main3 is untouched: 0 files are newer than `before.stamp`, and `work/checksums.json` still shows 15:33:46.

## Strengths

- **Faithful to the engine.** w, the sign, and the inherited-call handling mirror `classify.py` exactly, and the
  probes above confirm it. The docstring states what is read from the engine and why it must match.
- **Correct, efficient Dollo.**
  - Bitmask clades are checked against the run's genomes and the outgroup root.
  - Each (pattern, superfamily) is placed once, through `np.unique`.
  - `_place` agrees with an independent brute force on 120,000 patterns.
- **Streaming and cheap.** Each pair file and element table is read once. 1.17 M calls take 12.8 s at 0.6 GB.
- **Fail-fast on mismatched inputs, as the engine's merge does.** Each error names the file and line: a foreign
  eid, a duplicate, a missing call, an unknown state, non-integer dl or dr, a bad header or width, an unreadable
  gzip. A family or superfamily literally named "all" is counted once.
- **Honest findings text.** "The bounds bracket the derived share; they do not measure it." It reports where K2P is
  missing. Resolution warnings flow through `stats.resolution`.
- **Thorough self-checks.** The report's awk and pav_matrix rechecks were real. Every number I recomputed matched.

## Issues

### Critical
None.

### Important

**I1. "Shown derived" (D_inside, O_inside) counts calls whose inside gap end lies past a nested child or deep
inside the element. Those calls do not show that B carried the element. On main3 they are 42% of the lower bound and
95% of O_inside.**

- **Where:**
  - rule: `mechanisms.py`:178-193 (`o_kind`, `d_kind`), :196-212 (`_metric`);
  - claims: :17-22 (docstring), :111-116 (notes "derived, shown"), :358-366 (findings "a lower bound: a gap end inside
    the element, so B carried it");
  - engine root cause: `classify.py`:184.
- **What:**
  - The rule's premise (brief, plan review I3, and the O_inside ruling) is that a gap end more than w inside means
    "B keeps fewer than MIN_SEG aligned bases of it but still some of its sequence, so B carried the element".
  - That holds when the stretch between the element's end and the gap end is a remnant of the element's own
    sequence, contiguous with B's flank. That is the geometry of the engine's `test_element_remnant_is_d_not_e`.
  - It does not hold when that stretch is a nested child, or is deep and mostly unaligned. The classifier reads
    the gap around the element's *midpoint* (`gap_around((s + t) // 2)`, `classify.py`:184). Children are excluded
    from the aligned-bp counts, but not from that geometry.
  - Example: host `B73|B73v5_chr1:34769093-34792184`, 23 kb, D with dl -9,317 and dr -10,946.
    - Its gap is a 2.8-kb deletion *inside* its nested child (`...34770739-34784390`), which is 79% aligned in TIL18.
    - The host's own sequence has fewer than 80 aligned bases.
    - So TIL18 holds an element that A annotates as nested in the host, but none of the host itself. The D_inside
      call says the opposite.
- **Measured on main3 B73>TIL18** (`inside_child.py`, `child_cov.py`, `lower_variants.py`). The 1,657 calls with an
  inside gap end split three ways:

  | geometry | D_inside | O_inside |
  |---|---|---|
  | own remnant: stretch 11-79 bp, no child | 930 | 24 |
  | child kept: a nested child spans at least half the stretch | 114 | 345 |
  | deep, no child: an isolated hit under MIN_SEG bounds the gap | 153 | 91 |

  - The children in "child kept" stretches have own coverage in TIL18 of median 0.49; 26% are at 0.8 or more.
    Their own calls are D or O "inherit".
  - How the lower bound changes with the inside rule:

    | inside rule | K=0 | 0<K<0.01 | K>=0.01 | all |
    |---|---|---|---|---|
    | as implemented | 0.0137 | 0.0122 | 0.0288 | 0.0217 |
    | no child in the stretch | 0.0122 | 0.0110 | 0.0216 | 0.0171 |
    | no child, depth <= 150 (REFINE_PAD) | 0.0119 | 0.0100 | 0.0171 | 0.0141 |
    | no child, depth <= 79 | 0.0112 | 0.0092 | 0.0155 | 0.0129 |

- **Why it matters:**
  - The lower bound is the one quantity the findings call "shown". About 40% of it rests on geometry that does not
    show the element was carried. "Child kept" fits an adjacent, mis-paired or paralogous copy better than a carried
    host.
  - The K>=0.01 lower bound, the report's age contrast, roughly halves.
  - The O_inside ruling assumed the D_inside geometry, but only 24 of 460 O_inside calls have it.
- **Fix** (needs a controller ruling, because it changes the brief's `d_kind`/`o_kind` rule):
  - Count a gap end as inside only when the stretch it cuts off is the element's own sequence: no annotated child
    in it. Children spans come from A's element table, which `_element_info` already reads through the `parent`
    links.
  - Also count it only when that stretch is a short remnant: depth under MIN_SEG, matching the engine's own "less
    aligned sequence counts as none", or at most REFINE_PAD if the ruling prefers the reach of exact junction
    refinement.
  - Send the rest to the undetermined classes, or to a separately named undetermined bucket, so nothing is hidden.
  - Add a toy test of a host with a kept nested child, which must not be D_inside.
  - Update the notes and the findings line.
  - Residual caveat to say in the note: of the remnants, 344 of 1,197 D_inside lie only 11-20 bp inside. An
    annotated end misplaced by more than 2 TSD lengths into the flank gives the same signal, so "shown" assumes
    exact annotated ends, as the engine's E/D split already does.

### Minor

**M1. No test pins w per element (named risk 2).**
- Where: `tests/test_mechanisms.py`:37-40; `tests/catalog_toy.py`:59 (`TSD = "ACGTA"` on every call).
- Every TSD in the suite is 5 bp or None, so w is always 10.
- The mutant `_w = lambda tsd: SLOP_TSD_MULT * TSD_DEFAULT` passes all 16 tests (`mutants.py w_default`).
- Fix: add cases such as `d_kind(-9, 0, "ACGT") == "D_inside"`, `d_kind(-11, 0, "ACGTAC") == "D_beyond"` and
  `o_kind(12, -12, "ACGTAC") == "O_site"`. Add one pair-file call with a 6-bp `tsd_a` through `mechanisms`.

**M2. No test pins adjacency grouping per window (named risk 4).**
- Where: `tests/test_mechanisms.py`:67-79; `mechanisms.py`:396.
- The only `adjacent` calls in the suite share wid 7, so a mutant that keys adjacency by state alone passes all
  tests (`mutants.py adjacent_ignores_wid`).
- Fix: add a second adjacent E pair in another wid, and an adjacent D in wid 7. Expect separate events and no
  E-D merge. A host -> child -> grandchild chain would also pin the transitive links.

**M3. Several fail-fast paths are untested.**
- Where: `mechanisms.py`:204 (unknown state), :210 (non-integer dl or dr), :258 (duplicate call), :270 (an element
  without a call), :170 (a truncated or corrupt gzip). Only the header, width, missing-file and foreign-eid paths are
  tested (`tests/test_mechanisms.py`:236-259).
- Fix: one parametrized test that edits a toy pair file.

**M4. The age bounds in the report's Concern 3 and in progress.md quote the current lower bounds.**
- These are 0.012 / 0.011 / 0.019, and then 0.0137 / 0.0122 / 0.0288 with O_inside. The report reads them as
  "does not rise with age".
- Under I1's remnant-only rule they are 0.0112 / 0.0092 / 0.0155.
- No code change: re-quote the bounds after I1 is ruled on, so later tasks (11 panel F, 12 item 12) do not carry
  the inflated K>=0.01 value.

### Acknowledged, not counted
- **Analysis fingerprint.** It does not cover `ltrpav.constants` or `ltrpav.genotype`. That is Task 10's question,
  by ruling, and the docstring now says so.
- **Two adjacent clusters in one window count as one event.** The pair files keep no gap ids (decision 43).
- **Dollo runs on merged states.** Members are P, so no loss lands on a clade holding a member.
- **Adjacent O calls fall in O_complex** under the |dl|, |dr| <= w definition. That is 60 of 16,578 own-junction O
  calls on B73>TIL18, which is negligible.
- **There are no small_ins O calls in B73>TIL18.** That is the engine's matter, not this task's.

## Assessment

**Task quality: Needs fixes.**

The code is correct against its specification. The sign, w, Dollo, the events, the U tally and the main3 numbers
were all reproduced independently and exactly. It is well structured, fast and fails fast.

**I1 is a design-level flaw that real data expose.** The "shown derived" lower bound counts as shown the calls
whose inside gap end lies past a nested child or deep in unaligned sequence. That is 42% of the bound on main3, and
95% of O_inside. The fix needs a ruling, because it narrows the brief's `d_kind` and the O_inside ruling. M1 and M2
are cheap tests that pin two of the named risks against regression.

## Probe files (scratch)
`/data2/chris/maize_introgression/benchmark_pav/plan2_reviews/task8/`:
- `indep_pair.py`: independent per-pair recount with consistency checks; outputs `indep_*.tsv`.
- `diff_tables.py`: diffs a recount against the code's output.
- `sign_probe.py`: engine-level sign and w probe.
- `test_dollo_probe.py`: brute force plus the hand-built toy.
- `dollo_main3.py`: independent Dollo recount from loci.tsv.
- `run_impl.py`: the code on main3 through `view/`; outputs `impl_mechanisms.tsv`, `impl_run.out`.
- `inside_depth.py`, `inside_kind.py`, `inside_child.py`, `child_cov.py`, `lower_variants.py`: the I1 measurements.
- `mutants.py`: the M1 and M2 mutants.
- `ast_check.py`: brief-test AST check.
- `before.stamp`: the read-only proof for main3.

## Re-review (scoped), fix round 1: 71b8648..512e344

**Commit:** 512e344 "Count an inside gap end as derived only when its remnant is shown". The diff touches only
`mechanisms.py` and `test_mechanisms.py`.

**Verdicts:** 5 ADDRESSED (I1, M1-M4), 0 PARTIAL, 0 NOT ADDRESSED. New problems: 1 Minor (N1); no new Critical or
Important.

**Checks at 512e344:**
- `python -m pytest -W error tests/test_mechanisms.py`: 25 passed.
- `ruff check` is clean.
- The brief's 7 tests and `_table` are still AST-identical.
- Author and committer are cwb14; there are no trailers.

| Finding | Verdict | Evidence |
|---|---|---|
| I1 shown remnant | ADDRESSED | See "I1 in detail" below. |
| M1 w per element | ADDRESSED | `test_w_is_the_elements_own`: unit cases for 4- and 6-bp TSDs, None and "", plus a pair file rewritten with a 6-bp and a "." `tsd_a`. My `w_default` mutant now fails it. |
| M2 adjacency per window | ADDRESSED | `test_events_group_adjacent_calls_per_window_and_state`: two windows stay apart, an adjacent D in an E window stays a D event, and a host -> child -> grandchild chain is one event. My `adjacent_ignores_wid` mutant now fails it. A mutant linking hosts of any state survives, but it is equivalent on engine data: a host_empty E's host is always E, an inherit D's always D. |
| M3 fail-fast paths | ADDRESSED | `test_damaged_pair_file_fails_fast` covers 5 cases (unknown state, text dl, duplicate, missing call, truncated gzip). Each asserts the pair file's name. |
| M4 re-quoted bounds | ADDRESSED | The report's earlier tables are marked superseded, and the "Fix round 1" table holds the new bounds. The ledger's latest Task 8 line (progress.md:84) carries them. |

**I1 in detail.**
- `_inside` implements the ruling. A gap end more than w inside is shown when -d < MIN_SEG and -d <= own at that
  end. `own` is the element's own bases before its first direct child at the left end, and after its last at the
  right.
- Calls that are inside but not shown go to `D_inside_unshown` and `O_inside_unshown`, which sit in n_absent but
  not in the lower bound. Inherited calls are unchanged.
- The notes, the findings line and the docstring are updated, including the "assumes exact annotated ends" caveat.

**The three risks you named:**
1. **One shown end is enough** (`fix_edge_probe.py`).
   - A shown end gives D_inside or O_inside, whether the other end is beyond (300), within w, deep (-3000) or
     child-blocked.
   - Both ends blocked give unshown. A beyond-only D with a child near the left end stays D_beyond. O at the site
     with a child stays O_site.
   - With the real classifier: a 40-bp remnant whose right flank is lost gives D (dl -39, dr 304) -> D_inside.
     Adding 500 bp of B-only sequence gives O (dl -40, dr 305) -> O_inside.
   - This is sound: the shown remnant is evidence on its own, and the other end's geometry does not undo it.
2. **The MIN_SEG boundary.**
   - Remnants of 79 bp are shown; 80 and 81 bp are unshown. The tests pin -79 and -80.
   - At the w boundary, -10 is not inside and -11 is inside and shown.
   - The engine agrees with the strict "<". A 79-bp remnant is D (dl -78) -> D_inside. Remnants of 80 and 120 bp
     come out T (own aligned >= MIN_SEG), so they never reach rule 4.
   - A D or O deeper than 79 bp can therefore only come from unaligned sequence, and "unshown" is right for it.
3. **Children partly overlapping the remnant.**
   - `_element_info`'s `own` was checked against a per-base brute force ("any child base in the stretch") for
     stretches of 11-199 bp at both ends, counting direct children and also all descendants. That gave 0
     mismatches.
   - The synthetic table holds several children at both ends, a child at the host's first base and one ending at
     its last base (own (0, 0)), overlapping siblings, a grandchild, and a child poking out of the host (own -51:
     never shown).
   - At the exact boundary, own 39 with -d 40 is unshown (one child base) and own 40 is shown. The tests pin both.

**main3** (read-only through `view/`; 0 files newer than `before2.stamp`; `checksums.json` still shows 15:33:46):
- An independent recount (`indep_pair2.py`, no ltrpav code) tests each stretch against every direct child base
  rather than through `own`. It equals the code on **all nine ordered pairs**: 188,687 per-pair rows of states,
  absence, events and missingness.
- The Dollo rows (189) are unchanged.
- B73>TIL18 matches the implementer's table at every digit:

  | age | D_inside | O_inside | D_inside_unshown | O_inside_unshown | lower |
  |---|---|---|---|---|---|
  | K=0 | 0.0107 | 0.0005 | 0.0012 | 0.0012 | 0.0112 |
  | 0<K<0.01 | 0.0091 | 0.0001 | 0.0015 | 0.0016 | 0.0092 |
  | K>=0.01 | 0.0151 | 0.0004 | 0.0044 | 0.0089 | 0.0155 |
  | all | 0.0126 | 0.0003 | 0.0031 | 0.0057 | 0.0129 |

  - Counts: D_inside 961, D_inside_unshown 236, O_inside 24, O_inside_unshown 436. The upper bound is 0.651.
  - The "no child base" rule gives the same counts as my "< half a child" measurement.

**New problems.**

**N1 (Minor): the findings line prints a nonzero O_inside as "0.000".**
- Where: `mechanisms.py`, the `_absence` findings line (`_f3`).
- After the fix O_inside is 0.0003 (24 calls), so the main3 line reads "shown derived = frac_D_inside +
  frac_O_inside = 0.013 + 0.000 = 0.013". The by-age lower bounds print as 0.011 / 0.009 / 0.016.
- The table and stats rows keep full precision; only the prose rounds a real term to zero.
- Fix: print the bound terms with 4 decimals or 3 significant digits.

**Carry forward (not findings of this task).**
- Plan text for Task 11 panel F ("fates of absences: E, D inside, D beyond, O at the site, complex O") and Task 12
  item 12 predates both rulings. It should list O_inside and the two unshown classes, read as undetermined, so the
  figure and report use the shown-only lower bound (0.0129, not 0.0217).

**Assessment: Task quality: Approved.** I1 and M1-M4 are fixed as ruled. The rule matches an independent recount
on every main3 pair, and the three named risks behave correctly at their boundaries. N1 is cosmetic.

**Re-review probe files** (same scratch directory):
- `indep_pair2.py`, `indep2_*.tsv` / `.out`: the independent recount under the ruled rule.
- `impl2_mechanisms.tsv`, `impl2_run.out`: the code at 512e344 on main3.
- `fix_edge_probe.py`: the edge probes.
- `mutant_*.out`: the mutant reruns.
- `before2.stamp`: the read-only proof for main3.
