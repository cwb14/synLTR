# LTRmix

Admixture and introgression between genomes from their **LTR-retrotransposon libraries alone**: no genome sequence,
gene annotation, SNP calling or outgroup.

Give it the LTR-RT library of three (or more) genomes, e.g. LTRquest output. It finds which two genomes are sisters,
tests whether one sister shares more with the third genome than the other does (gene flow), dates that sharing with
the LTR clock, paints the recipient's chromosomes, and reports large inversions.

![LTRmix workflow](docs/workflow.png)

## Why LTR-RTs are enough

| LTR-RT property | What LTRmix does with it |
|---|---|
| An insertion is a derived state (absence is ancestral) | Presence/absence patterns are polarized without an outgroup |
| The 5-bp target-site duplication (TSD) marks one insertion event | Orthology between libraries is certified (chance agreement ~0.3%) |
| The two LTRs were identical at insertion | Their divergence dates the insertion; each LTR is an outgroup for the other |
| Orthologous copies coalesced after the insertion | Ortholog divergence cannot exceed LTR-LTR divergence (paralog filter) |

## Run

```bash
mamba env create -f environment.yml        # env 'ltrmix'
mamba activate ltrmix
python ltrmix.py --genome B73=run/B73v5_LTRs --genome TIL18=run/TIL18_LTRs --genome TIL01=run/TIL01_LTRs \
                 --outdir out -t 32
```

`--genome LABEL=LIB` per genome: an LTRquest output prefix (reads `PREFIX_depth*_clean_ltr.{fa,tsv}`), or
`FASTA[,TABLE]` with headers `chrom:start-end[#class]` and an optional table (`seq_id` plus any of `k2p`, `tsd`,
`strand`, `ltr5_len`, `ltr3_len`). Without K2P, the age strata and clock test are skipped; without TSDs, the
orthology certificate is skipped. Three maize-sized libraries (1.7 Gb each) take ~12 min with 32 threads and
~55 GB RAM. With four or more genomes every trio is analyzed, and a second donor genome (one that is the donor's own closest
relative) adds an admixture-fraction estimate.

## Outputs

| File | Content |
|---|---|
| `findings.txt` | Plain-language summary of every test |
| `stats.tsv` | Every statistic with standard error and Z (5-Mb block jackknife) |
| `elements.<recipient>.tsv` | Per element: status and divergence in the other genomes, evidence class, posterior of donor ancestry |
| `tracts.<recipient>.bed`, `ancestry.<recipient>.bed` | Tracts of recent sharing with the donor (near-identity) and of donor-like ancestry, each with a target-decoy q-value (`high`: q <= 0.05) and `p_decoy` |
| `decoy_tracts.<sister>.bed` | The same caller run on the sister (the chance level behind q) |
| `orthologs.<A>.<B>.tsv.gz` | Library-only orthologs, divergence and TSD agreement, for every genome pair in both directions |
| `blocks.tsv`, `inversions.tsv` | Collinear blocks between genome pairs; blocks inverted relative to their chromosome pair |
| `overview.png`, `overview.pdf` | One figure per trio: recipient chromosomes painted against the sister control, an example tract, D by insertion age, identity spectrum, genome-wide tests; the PDF adds short and long legends (`overview_numbers.tsv`: every legend number and its source). Redraw with `python ltrmix_plot.py OUTDIR [--mu RATE]`; skip with `--no-figure` |

## Tests reported

- **D_kmer**: k-mers present once in each genome that carries them, shared by exactly two genomes.
- **D_ins**: insertions shared by a sister and the third genome, absent (inside a syntenic interval) from the other
  sister; stratified by insertion age (K2P of the donor copy). Incomplete lineage sorting gives D = 0 at every age,
  so an excess concentrated in young insertions points to gene flow without assuming a clock rate. Calling a single
  insertion younger than the split needs the split in the same units (see `DESIGN.md`).
- **D3**: divergence of ortholog triples (both sisters measured on the donor's record).
- **D_self**: ABBA/BABA on LTR sites polarized by the element's other LTR; insensitive to unequal branch lengths.
- **Identity spectrum**: recipient-donor vs sister-donor orthologs by divergence; the near-identical excess is a lower
  bound on the admixed fraction.
- With a second donor genome: **f_ratio** (insertion patterns and identity spectrum), an f4-ratio analogue.

## Benchmark (maize B73 / *Zea mays* ssp. *mexicana* TIL18 / ssp. *parviglumis* TIL01; two more admixture events)

Full benchmark: `benchmark/REPORT.md` (Yang et al. 2023 *Science*; Barnes et al. 2022 *PNAS*; simulations;
controls; a wild *Zea* exchange; sweet orange). From LTR-RT libraries alone:

| Question | Result |
|---|---|
| Gene flow between maize and mexicana? | Yes: four tests Z = 4.4–8.4 (outgroup-based SNP test on the same assemblies: Z = 9.2) |
| Gene flow or lineage sorting? | Gene flow: D falls from +0.51 (identical LTRs) to +0.08–0.13 (old insertions), and lineage sorting gives D = 0 at every age (no clock rate needed); 7.6% of maize–mexicana orthologs coalesce after the split (in the data's own units) vs 3.5% of parviglumis–mexicana. At an assumed 3×10⁻⁸ per site per year, 13 shared insertions are younger than a 30-kyr split vs 1, but measured rate-free the split (0.05–0.07% LTR divergence) is too recent for single elements to resolve |
| Which chromosomes? | Chr 5, 8, 9 lowest, as published (chance 1/120) |
| Where along the genome? | Tracks ELAI: r = 0.28 at 1 Mb, 0.36 at 10 Mb (whole-genome k-mers 0.33, 0.43) |
| Inversions? | Inv4m (within 0.03/0.3 Mb of the published breakpoints) and Inv1n (carried by parviglumis TIL01) |
| Positive control? | Highland landrace PT shares more with mexicana than B73 does (Z = 3.3–4.6), carries a young mexicana Inv4m haplotype (inverted vs B73 at 173.2–187.8 Mb; 63% of its orthologs there near-identical to mexicana TIL25), and shares its HPC1 haplotype with TIL25 (5 vs 27 differences to B73 in the gene) |
| Agreement with SNP tests? | Across 7 trios of 6 genomes, LTR-RT D tracks gene-space SNP D with an outgroup (k-mers r = 0.99, insertions r = 1.00) |
| Direction of gene flow? | Not identified by trios (as for SNP D). The ELAI agreement shows the published mexicana→maize ancestry is part of the signal; whether some flowed from maize into the sampled mexicana is open |
| Individual introgressed tracts? | No for maize B73 (old admixture, ~10-kb tracts, one mexicana genome that is only a distant relative of the source) |
| False positives? | 0/30 null simulations with \|Z\| > 3; two-mexicana control flat by k-mers (\|Z\| ≤ 1.7) |
| Another admixture, another annotator? | PanAnd EDTA calls: huehuetenangensis and parviglumis share more with *Z. nicaraguensis* than mexicana does (k-mer Z = 6–18; confirmed on whole assemblies), as Chen et al. 2022 report. With a donor this distant, insertion tests lose synteny coverage and fail the control; ltrmix warns |
| Recent admixture, outside grasses? | Sweet orange (pummelo × mandarin, a few generations): the 12.6%-mandarin haplotype gives Z = 4.0–5.3; every published tract ≥ 1.7 Mb painted (69–100% covered), base-pair precision 0.84, recall 0.95; sour-orange controls flat. No tract certified at q ≤ 0.05 (too few tracts for the decoy rule) |

## Limits

- Very recent admixture gives few, long tracts; with fewer than ~20 tracts the target-decoy rule cannot reach
  q <= 0.05 (sweet orange: 15 tracts, 4 decoys, none 'high' although 94% of the true sequence is painted). Read the
  per-element posteriors (`elements.<R>.tsv`) and the decoy-corrected excess there.
- A distant donor (diverged for about the lifetime of intact LTR-RTs) leaves little synteny with the sisters:
  `findings.txt` then warns (`donor_resolved` in stats.tsv) and only D_kmer should be used.
- One haplotype per taxon cannot separate most introgressed segments from incomplete lineage sorting: local calls
  are reliable only where the recipient shares recent ancestry (near-identity) with the sampled donor genome.
  Power grows with the number of donor genomes.
- D_kmer, D_ins and D3 count changes on terminal branches and assume equal branch lengths (as the three-taxon D3 test
  does); unequal assembly-error or TE-turnover rates between sisters bias them. D_self does not have this weakness.
- One-sided annotation dropout biases presence/absence statistics toward the better-annotated sister; `completeness_ratio`
  in `stats.tsv` (the donor's old insertions found in one sister vs the other) flags it, and D3 and D_self
  are robust to it.
- Old inversion polymorphisms bias the posterior over whole inverted blocks: where one genome carries an
  arrangement that split before the taxa did, the recipient looks closer to whichever genome shares its
  arrangement (maize: Inv1n up, Inv4m and chr8/chr9 blocks down). Check `inversions.tsv` and ortholog divergence
  before reading painting inside an inverted block (see `DESIGN.md`).
- Painting resolution is the spacing of informative elements (B73: median 25 kb, mean 67 kb), which is not yet
  reported by the tool.

## Files

| File | Role |
|---|---|
| `ltrmix.py` | The method: library loading, k-mer index, library-only orthology, trio tests, HMM painting, outputs |
| `ltrmix_plot.py` | The overview figure of a trio (called by `ltrmix.py`; also a CLI to redraw) |
| `tests/synth.py`, `tests/test_ltrmix.py`, `tests/test_ltrmix_plot.py` | Synthetic trios with a planted tract, an inversion, a decoy family and a true negative; figure tests (19 tests) |
| `DESIGN.md` | Decisions and the reasons for them, including the failures that shaped them |
| `environment.yml` | Dependencies (python >= 3.10, numpy, numba, scipy, python-edlib, matplotlib, pandas, pytest) |
| `environment.lock.yml` | Exact package versions of the environment the benchmark ran in (includes msprime for the simulator) |
| `benchmark/` | Record of the validation: report, figures, scripts and summary tables (see `benchmark/README.md`) |
| `docs/workflow.png`, `docs/workflow.pdf` | Workflow diagram (the PDF adds legend pages); `docs/workflow.py` redraws both |
| `docs/idea_synteny_input.md` | Unimplemented idea: optional synteny file for distant donors (problem, evidence, design, test) |
| `PROMPT.md`, `PLAN.md` | The original request, verbatim, and the plan approved before any code was written |

Self-contained: copy the directory anywhere. No caching or checkpointing: a maize-sized trio runs in ~10 min, six
maize-sized genomes in about an hour and a half (32 threads).

## Status

Worth keeping as a screening and mapping tool for gene flow when one assembly per taxon is all there is: validated
on three independent admixture events (maize–mexicana, wild *Zea*, sweet orange), two annotators, and simulations
(see the benchmark). To make it robust or publishable:
- a calibrated confidence for few, long tracts (the target-decoy rule needs ~20 tracts);
- an optional gene-synteny input for donors ~100 kyr to ~1 Myr away, so insertion tests keep their synteny
  (evidence, design and test plan: `docs/idea_synteny_input.md`);
- an inversion flag: old-arrangement blocks left out of the HMM fit and summaries, and tested instead for an
  introgressed arrangement (recipient unusually close to the genome sharing its arrangement);
- a resolution report (informative-element spacing, shortest callable tract) and summary windows counted in
  informative elements rather than bp;
- several genomes per taxon (pangenomes) to separate old, short tracts from lineage sorting;
- a test outside plants (endogenous retroviruses in animals) and in a TE-poor genome;
- packaging (bioconda) and a small public example dataset.
