#!/usr/bin/env bash
# How genotype errors propagate into `ltrkin source`: source on assembly-truth genotypes vs on ltrkin calls at
# 20x and 60x, both restricted to confirmed-truth sites. usage: source_check.sh <version tag> <ltrkin src dir> [S] [ref]
set -euo pipefail
V=$1; SRC=$(readlink -f "$2"); S=${3:-Camara}; ref=${4:-hap1}
W=$(dirname "$(readlink -f "$0")")
REF=$(readlink -f data/$S/${S}_$ref.fa)
GFF=$(readlink -f "$(python -c "import yaml; print(yaml.safe_load(open('config.yaml'))['gff'].format(S='$S', ref='$ref'))")")
O=$S/source; mkdir -p $O
python $W/../truth_to_genotypes.py $S/truth/${ref}_truth.tsv $S $O/truth_confirmed.genotypes.tsv --confirmed
python - "$O" "$S/calls/$V/sub/${ref}" "$V" <<'PY'
import sys, pandas as pd
O, pre, V = sys.argv[1:4]
t = pd.read_csv(f"{O}/truth_confirmed.genotypes.tsv", sep="\t")
keep = set(t[t.gq > 0].element_id)
for d in (20, 60):
    g = pd.read_csv(f"{pre}_d{d}_s1.p2.genotypes.tsv", sep="\t")
    m = ~g.element_id.isin(keep)
    g.loc[m, "genotype"] = "N/N"; g.loc[m, "gq"] = 0
    g.to_csv(f"{O}/{V}_d{d}_confirmedsites.genotypes.tsv", sep="\t", index=False)
PY
cd $O
for n in truth:truth_confirmed ${V}_d20:${V}_d20_confirmedsites ${V}_d60:${V}_d60_confirmedsites; do
  t=${n%%:*}; g=${n#*:}.genotypes.tsv
  [[ -s src_$t.sources.tsv ]] || PYTHONPATH=$SRC python -m ltrkin.cli source -r $REF -a $GFF -g $g -o src_$t -t 4 -v > src_$t.log 2>&1
done
for t in ${V}_d20 ${V}_d60; do echo "== $t"; python $W/../compare_sources.py src_$t.sources.tsv src_truth.sources.tsv $t truth; done
