"""Follow-up rerun on main3 (read-only view): all TIL01-TIL18 pairs through the identity layer's own job and
worker code (D's element +- WINDOW_PAD, orientation from the call's b_strand), the layer's split routine, and the
reviewer's 96 slid pairs (placement.tsv: a LASTZ LTR end > 30 bp off its site end where minimap2's is on)
before and after. Usage: rerun_main3.py VIEW THREADS PLACEMENT_TSV"""
import csv, logging, sys, time
from pathlib import Path
import numpy as np
from ltrpav.samples import read_samples
from ltrpav.seqio import Fasta, revcomp
from ltrpav.localign import align_window
from ltrpav.constants import WINDOW_PAD
from ltrpav.analysis.catalog import load_catalog, STATE_CODE
from ltrpav.analysis.relations import pav_distances, discover
from ltrpav.analysis.stats import Findings, block_size
from ltrpav.analysis.trio import Trio
from ltrpav.analysis import identity as idm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
view, threads, placement = Path(sys.argv[1]), int(sys.argv[2]), Path(sys.argv[3])
t0 = time.monotonic()
samples = read_samples(view / "samples.tsv")
cat = load_catalog(view, samples, view / "samples.tsv")
trio = Trio("B73", "TIL01", "TIL18", True)
R, S, D = trio.R, trio.S, trio.D
gd, gs = cat.g(D), cat.g(S)
dist = pav_distances(cat)[0]
size = block_size(cat)
c = discover(cat, R, S, D, dist, "E")
pmask = {S: cat.member[:, gd] & (cat.proj[D][:, gs] == STATE_CODE["P"])}
loci = np.flatnonzero(pmask[S])
elements = {D: idm._elements(cat, D, loci)}
jobs = [((), idm._job(cat, int(i), [D], elements, pmask, D)[1]) for i in loci]
print(f"{len(jobs):,} {S}-{D} pairs; b_strand 0 in {sum(1 for j in jobs if j[1][5][0][4] == 0)}", flush=True)
t = time.monotonic()
res = idm._align_all(cat, jobs, threads)
dt = time.monotonic() - t
print(f"aligned {len(jobs):,} pairs in {dt:.1f} s at {threads} threads: {len(jobs) / dt:.2f} pairs/s", flush=True)
tab = idm._Tables(cat, loci, jobs, res, D)
sd = tab.fit_pairs(S)
f = Findings()
t = time.monotonic()
rows, s = idm._split(cat, trio, c, size, sd, f)
print(f"split routine in {time.monotonic() - t:.1f} s; skipped (no b_strand) {tab.n_skipped}", flush=True)
for _, line in f.items():
    print(line, flush=True)
v = {r.statistic: r for r in rows}
for st in ("s", "m", "s_mix", "m_mix", "w_iso", "w_flow", "w_tail", "m_flow", "m_tail", "aic_mix", "aic_iso", "n_pairs"):
    print(f"{st}\t{v[st].value}\t{v[st].se}", flush=True)
print(f"frac_SD_below {np.mean(sd[1] / sd[2] < s):.4f}", flush=True)

# the reviewer's 96 slid pairs, before (placement.tsv, LASTZ on the bare element) and after (this run)
T = 30
def num(x):
    return None if x == "." else int(x)
def off_end(o):
    return o is None or abs(o) > T
old, flagged = {}, []
for r in csv.DictReader(open(placement), delimiter="\t"):
    lz = [(num(r["lz_s5"]), num(r["lz_d5"]), num(r["lz_off5"])), (num(r["lz_s3"]), num(r["lz_d3"]), num(r["lz_off3"]))]
    mm = [(num(r["mm_s5"]), num(r["mm_d5"]), num(r["mm_off5"])), (num(r["mm_s3"]), num(r["mm_d3"]), num(r["mm_off3"]))]
    flag = any(not (a[0] == 0 and b[0] == 0) and off_end(a[2]) and not off_end(b[2]) for a, b in zip(lz, mm))
    old[r["eid"]] = (lz[0][0] + lz[1][0], lz[0][1] + lz[1][1], mm[0][0] + mm[1][0], mm[0][1] + mm[1][1], r)
    if flag:
        flagged.append(r["eid"])
new = {str(cat.eid[i, gd]): (sites, diffs) for i, sites, diffs in tab.pairs[S]}
print(f"reviewer's slid pairs: {len(flagged)}; all pairs compared {len(set(old) & set(new)):,}", flush=True)
changed = [e for e in flagged if new[e] != old[e][:2]]
print(f"slid pairs whose (sites, diffs) changed: {len(changed)} of {len(flagged)}", flush=True)
def div(s_, d_):
    return d_ / s_ if s_ else float("nan")
ob = np.array([div(*old[e][:2]) for e in flagged]); nb = np.array([div(*new[e]) for e in flagged])
mb = np.array([div(old[e][2], old[e][3]) for e in flagged])
ok = np.isfinite(ob) & np.isfinite(nb) & np.isfinite(mb)
print(f"slid pairs, median div: before {np.median(ob[ok]):.4f}, after {np.median(nb[ok]):.4f}, minimap2 "
      f"{np.median(mb[ok]):.4f}; |after - minimap2| <= 0.005: {int((np.abs(nb - mb)[ok] <= 0.005).sum())} of "
      f"{int(ok.sum())} (before {int((np.abs(ob - mb)[ok] <= 0.005).sum())})", flush=True)
other = [e for e in set(old) & set(new) if e not in set(flagged)]
diff_other = sum(new[e] != old[e][:2] for e in other)
print(f"other pairs whose (sites, diffs) changed: {diff_other} of {len(other):,}", flush=True)

# the reviewer's placement metric on the slid pairs, x now padded: LTR outer-end offsets from the site ends
fa = {g: Fasta(next(s_.fasta for s_ in samples if s_.label == g)) for g in (S, D)}
el = elements[D]
still = 0
for e in flagged:
    r = old[e][4]
    i = int(r["locus"])
    x_el = el[e]
    x0 = max(0, x_el.start - 1 - WINDOW_PAD)
    x = fa[D].fetch(x_el.seqid, x0, x_el.end + WINDOW_PAD)
    ltrs = ((x_el.ltr_left[0] - 1 - x0, x_el.ltr_left[1] - x0), (x_el.ltr_right[0] - 1 - x0, x_el.ltr_right[1] - x0))
    bs, be = int(cat.pstart[D][i, gs]), int(cat.pend[D][i, gs])
    y0 = bs - 1 - WINDOW_PAD
    sq = cat.seqids[S][int(cat.pseq[D][i, gs])]
    y = fa[S].fetch(sq, max(0, y0), be + WINDOW_PAD)
    lead = WINDOW_PAD + min(0, y0)
    tail = len(y) - (be - max(0, y0))
    if cat.pbstrand[D][i, gs] < 0:
        y = revcomp(y)
        lead, tail = tail, lead
    want_l, want_r = lead, len(y) - tail - 1
    aln = align_window(x, y, "asm20", "lastz")
    yof = np.full(len(x), -1, np.int64)
    for a, bb, n in zip(aln.seg_a.tolist(), aln.seg_b.tolist(), aln.seg_len.tolist()):
        yof[a:a + n] = np.arange(bb, bb + n)
    offs = []
    for (a0, a1), outer, want in ((ltrs[0], "left", want_l), (ltrs[1], "right", want_r)):
        m = yof[a0:a1]
        idx = np.flatnonzero(m >= 0)
        if not idx.size:
            offs.append(None)
            continue
        j = idx[0] if outer == "left" else idx[-1]
        offs.append(int(m[j] - (want + (j if outer == "left" else j - (a1 - a0 - 1)))))
    lz_old = [num(r["lz_off5"]), num(r["lz_off3"])]
    mm_on = [not off_end(num(r["mm_off5"])), not off_end(num(r["mm_off3"]))]
    slid_now = any(off_end(o_new) and on and off_end(o_old) for o_new, on, o_old in zip(offs, mm_on, lz_old))
    still += slid_now
print(f"slid pairs whose slid LTR is still off its site end (> {T} bp) with x padded: {still} of {len(flagged)}",
      flush=True)
print(f"total {time.monotonic() - t0:.1f} s", flush=True)
