# ltrkin: literature and software review

Date: 2026-11-10. Scope: the questions in the brief for `ltrkin genotype` and `ltrkin source` (see `DESIGN.md`).
Tags: **[Abs]** = abstract only read; **UNVERIFIED** = not confirmed in a primary source in this pass. Untagged
claims were checked in the full text. **ltrkin check** = a quick measurement on project data (method in section D).

## Key findings
1. No published long-read tool genotypes reference LTR-RTs with **solo LTR as its own allele**. Generic SV
   genotypers are biallelic. The only per-locus solo/provirus precedent uses short-read depth (Thomas 2018).
2. The best generic force-genotyper, kanpig, reaches **82%** single-sample genotype concordance on assembly-derived
   truth; cuteSV-fc, Sniffles2-fc and SVJedi-graph reach **64–74%**. kanpig handles only SVs of 10 kb or less, and
   **47–55% of intact Poa LTR-RTs are longer than 10 kb**.
3. Every tool genotypes SVs with close neighbors badly (**> 30% discordance**). For ltrkin, nested elements are
   this case.
4. TE-specific long-read tools (TLDR, xTea, PALMER, TELR) find **non-reference** insertions. Only LoRTE and
   TrEMOLO's assembly module address reference-TE presence/absence, and neither has a diploid model.
5. Read error does not limit Δ tolerance: ONT R10.4.1 SUP reads show a **median net −8 bp per 10 kb** (5–95%: −60
   to +23; ltrkin check). τ = 3% is a 5-fold margin; derive τ from the data.
6. **Active "master" copies are often polymorphic, not fixed.** This holds for 38/86 intact human L1s, and for the
   copy-number GWAS peaks of rice Tos17 and Karma.
7. **New copies are often recombinant.** Only 5 of 32 sequenced new ONSEN copies had a single parent.
8. Each new copy's LTRs take U3 from the template's 3′ LTR and U5 from its 5′ LTR. We found one use of this rule
   to assign parents (ONSEN, Sanchez 2017).
9. LTR–LTR gene conversion affects **23% of angiosperm LTR-RTs on average (40% in maize)**, which biases LTR ages
   toward "younger".
10. Accepted benchmark practice: assembly-derived truth, stratification by repeat context (low-complexity regions
    hold **69% of HG002 SVs and 77–91% of caller errors**), and Mendelian or phase consistency.

## A. Long-read genotyping of known TE and SV alleles

| Tool | Evidence used | Genotype model | Reported performance | Failure modes / notes |
|---|---|---|---|---|
| LoRTE (Disdero & Filée 2017, [10.1186/s13100-017-0088-x](https://doi.org/10.1186/s13100-017-0088-x)) | Reference TEs: 200-bp flanks MEGABLASTed to PacBio CLR reads; < 50 nt between them = absent | None; "possible polymorphism" if reads disagree | *Drosophila* simulation: 98% of deletions found at ≥ 9×, no FPs | Non-unique flanks are "irresolvable"; 10% CLR error weakens deletion calls; Python 2.7 |
| TLDR (Ewing 2020, [10.1016/j.molcel.2020.10.024](https://doi.org/10.1016/j.molcel.2020.10.024)) [Abs] | ONT reads with full TE inserts + methylation | None | 84% of simulated insertions (TrEMOLO benchmark) | Non-reference only |
| xTea long-read (Chu 2021, [10.1038/s41467-021-24041-8](https://doi.org/10.1038/s41467-021-24041-8)) | Clipped + spanning reads; transductions | Genotyper for short reads only | 95.8% recall, 99.9% precision, simulated (Seymen 2025 preprint, [10.1101/2025.09.29.679192](https://doi.org/10.1101/2025.09.29.679192); UNVERIFIED) | Non-reference only |
| PALMER (Zhou 2020, [10.1093/nar/gkz1173](https://doi.org/10.1093/nar/gkz1173)) [Abs] | Masked reads; reports TSD, 3′ transduction | None | 203 non-reference L1Hs in NA12878 | L1-specific |
| TELR (Han 2022, [10.1093/nar/gkac794](https://doi.org/10.1093/nar/gkac794)) [Abs] | Local assembly of candidates | Allele frequency | 1% recall in TrEMOLO's simulation | Non-reference only |
| TrEMOLO (Mohamed 2023, [10.1186/s13059-023-02911-2](https://doi.org/10.1186/s13059-023-02911-2)) | Sample assembly vs reference (INS and DEL); clipped reads | Frequency = supporting / spanning reads | 96.7% of simulated insertions | Needs a sample assembly; FPs with poor assemblies |
| GraffiTE (Groza 2024, [10.1038/s41467-024-53294-2](https://doi.org/10.1038/s41467-024-53294-2)) | Discovery → TE graph; GraphAligner + vg call (long) or PanGenie (short) | Graph genotyper | "High concordance" with GIAB (Fig. 2, numbers not extracted) | Discovery-dependent |
| SVJedi (Lecompte 2020, [10.1093/bioinformatics/btaa527](https://doi.org/10.1093/bioinformatics/btaa527)) [Abs]; SVJedi-graph (Romain & Lemaitre 2023, [10.1093/bioinformatics/btad237](https://doi.org/10.1093/bioinformatics/btad237)) | Reads on a variation graph; informative if ≥ 100 bp past a breakpoint on each side | Likelihood, p_e = 5×10⁻⁵, ≥ 3 reads | HG002: 94.6% (CLR 30×), 94.1% (HiFi 25×), 90.4% (ONT 40×); > 99% on overlapping deletions | Errors mostly hom-alt called het |
| LRcaller (Beyter 2021, [10.1038/s41588-021-00865-4](https://doi.org/10.1038/s41588-021-00865-4)) [Abs] | Re-aligns reads to REF/ALT (details UNVERIFIED) | Likelihood | Mendelian concordance 0.96–0.98; INS F1 0.67–0.87 (Duan 2022, [10.1186/s12864-022-08548-y](https://doi.org/10.1186/s12864-022-08548-y)) | F1 0.52 → 0.01 with 100–1000 bp breakpoint error; > 128 GB RAM |
| Sniffles2 `--genotype-vcf` (Smolka 2024, [10.1038/s41587-023-02024-y](https://doi.org/10.1038/s41587-023-02024-y)) | CIGAR indels, split (SA) and clipped reads | Binomial; P(alt read) = 1−β / 0.5 / β, β = 0.05; GQ = −10 log₁₀(L₂/L₁) | Concordance 67.1% single-sample, 12.2% multi-sample (kanpig paper); trio Mendelian error 9.13% | Absent SVs not called 0/0; het:hom 1.10 vs ~4.58 expected |
| cuteSV `-Ivcf` / cuteFC (Jiang 2025, [10.1186/s13059-025-03642-2](https://doi.org/10.1186/s13059-025-03642-2)) [Abs] | Signature clustering | Maximum likelihood | 63.8% (kanpig paper); INS/DEL F1 0.69–0.90 (Duan 2022) | Most robust to breakpoint error |
| kanpig (English 2025, [10.1038/s41467-025-58577-w](https://doi.org/10.1038/s41467-025-58577-w)) | k-mer pileups in SV neighborhoods; primary reads that **fully span**; MAPQ ≥ 5; SVs 50 bp–10 kb | ≤ 2 haplotype clusters | 82.1% single-, 86.6% multi-sample; ONT R9 77.8%, R10 80.1% | No split/clipped reads; no SVs > 10 kb |
| SVUPP (Li 2025, [10.1093/bioinformatics/btaf587](https://doi.org/10.1093/bioinformatics/btaf587)) | cuteSV2 + SNP-based read phasing | Phased likelihoods | Beats cuteSV2, Sniffles2, kanpig on isolated SVs | All tools > 30% discordant at close neighbors |
| PanGenie (Ebler 2022, [10.1038/s41588-022-01043-w](https://doi.org/10.1038/s41588-022-01043-w)) [Abs] | Short-read k-mers + phased assemblies | HMM | > 90% accuracy for large insertions at 30× (preprint; UNVERIFIED) | Needs phased assemblies; diploid |

**Solo LTR as an allele state.** None of the tools above models it. Thomas et al. 2018
([10.1186/s13100-018-0142-3](https://doi.org/10.1186/s13100-018-0142-3)) explain why: provirus and solo alleles
"share the exact same junctions with flanking host DNA". Their short-read `findsoloLTR` calls solo when depth over the
provirus is < 50% of flank depth (< 10% for two solo alleles), at MAPQ ≥ 30; 6/6 tested loci validated. A spanning
long read resolves this directly.

## B. Benchmark designs
- **Simulation.** PBSIM3 (Ono 2022, [10.1093/nargab/lqac092](https://doi.org/10.1093/nargab/lqac092)) [Abs; README]
  makes HiFi via multi-pass (`--pass-num`) then `ccs`, and ONT via `ERRHMM/QSHMM-ONT(-HQ)`. `--hp-del-bias` models
  ONT homopolymer deletions. Badread (Wick 2019, [10.21105/joss.01316](https://doi.org/10.21105/joss.01316)) [README]
  for ONT: `nanopore2023` model, identity β(95, 99, 2.5), 1% chimeras, junk and random reads each. For HiFi:
  `--error_model pacbio2021 --qscore_model pacbio2021 --identity 30,3`. Set indel rates from measured data (section D).
- **Truth.** GIAB HG002 v0.6 (Zook 2020, [10.1038/s41587-020-0538-8](https://doi.org/10.1038/s41587-020-0538-8))
  [Abs] has 12,745 SVs; Tier 1 covers 2.51 Gb with 5,262 INS and 4,095 DEL. HG002-Q100 v1.1 has about 28,188 SVs in
  2.76 Gb (UNVERIFIED, preprint of Qin & Li 2025). Assembly-derived truth is harder: SVJedi-graph scores about 94% on
  GIAB but 74% on kanpig's assembly-derived set.
- **Matching.** Truvari (English 2022, [10.1186/s13059-022-02840-6](https://doi.org/10.1186/s13059-022-02840-6)):
  refdist 500, pctseq 0.7, pctsize 0.7 (UNVERIFIED for the current version). Needed only for baseline output; ltrkin
  sites match by element ID.
- **Phase consistency.** Use WhatsHap `haplotag` ([10.1101/085050](https://doi.org/10.1101/085050)) [Abs] or
  LongPhase, which co-phases SNPs and SVs ([10.1093/bioinformatics/btac058](https://doi.org/10.1093/bioinformatics/btac058))
  [Abs]. SVUPP shows read phase improves genotypes. We found no standard "haplotag consistency" metric.
- **Mendelian.** Trio inconsistency: Sniffles2 9.13% (1.29% missing), re-genotyped cuteSV 8.88% (3.45% missing).
- **Stratification.** GIAB stratification BEDs (Dwarshuis 2024,
  [10.1038/s41467-024-53260-y](https://doi.org/10.1038/s41467-024-53260-y)) [Abs]. Low-complexity regions are 1.2% of
  GRCh38 but hold 69.1% of HG002 SVs and 77.3–91.3% of erroneous calls (Qin & Li 2025,
  [10.1093/gigascience/giaf154](https://doi.org/10.1093/gigascience/giaf154)) [Abs].
- **Accepted numbers.**
  - Isolated SVs at 25–40×: 90–95% genotype accuracy.
  - Assembly truth: 80–87%.
  - F1 gains flatten above 20× (Duan 2022).
  - Neighboring SVs: < 70% for every tool.

## C. Source ("master") identification
- **Models.**
  - In the master-gene model, a few copies seed each subfamily (Deininger 1992,
    [10.1016/0168-9525(92)90262-3](https://doi.org/10.1016/0168-9525(92)90262-3)) [Abs]. Tree shape and shared
    variants separate it from the random-template (transposon) model (Clough 1996,
    [10.1007/bf00163211](https://doi.org/10.1007/bf00163211)) [Abs].
  - A formal test rejects a strict master for mouse ID elements (Johnson & Brookfield 2006,
    [10.1093/molbev/msj034](https://doi.org/10.1093/molbev/msj034)) [Abs].
  - In young Alu subfamilies, 10–20% of members are secondary sources and give rise to 20–40% of copies (Cordaux
    2004, [10.1016/j.tig.2004.07.012](https://doi.org/10.1016/j.tig.2004.07.012); network phylogeny) [Abs].
    Low-activity "stealth drivers" persist for about 20 Myr (Han 2005,
    [10.1101/gr.3492605](https://doi.org/10.1101/gr.3492605)) [Abs].
- **L1.**
  - 38/86 intact L1s are polymorphic, and six hot L1s carry 84% of activity (Brouha 2003,
    [10.1073/pnas.0831042100](https://doi.org/10.1073/pnas.0831042100)) [Abs]. Most of 68 polymorphic non-reference
    L1s were highly active (Beck 2010, [10.1016/j.cell.2010.05.021](https://doi.org/10.1016/j.cell.2010.05.021)) [Abs].
  - 3′ transductions fingerprint sources: a handful of source L1s per tumor seed tens to hundreds of events (Tubio
    2014, [10.1126/science.1251343](https://doi.org/10.1126/science.1251343); Rodriguez-Martin 2020,
    [10.1038/s41588-019-0562-0](https://doi.org/10.1038/s41588-019-0562-0)) [Abs].
  - SVA sources are themselves polymorphic (Chu 2023, [10.1093/nar/gkad821](https://doi.org/10.1093/nar/gkad821))
    [Abs].
- **Mouse.** Genome screens plus an ex vivo assay identified master IAP copies (Dewannieux 2004,
  [10.1038/ng1353](https://doi.org/10.1038/ng1353)) [Abs] and 3 of 9 coding-competent MusD copies as masters for ETn
  (Ribet 2004, [10.1101/gr.2924904](https://doi.org/10.1101/gr.2924904)) [Abs].
- **Plant LTR-RTs.**
  - Tos17 gives 5–30 new copies per regenerated plant (Hirochika 1996,
    [10.1073/pnas.93.15.7783](https://doi.org/10.1073/pnas.93.15.7783)) [Abs]. Nipponbare's chr7 copy is the one active
    in culture. A copy-number GWAS across 3000 genomes instead finds polymorphic Tos17 (404 varieties) and Karma
    insertions (Carpentier 2019, [10.1038/s41467-018-07974-5](https://doi.org/10.1038/s41467-018-07974-5)).
  - Tnt1's source copy was never identified (Grandbastien 1989, [10.1038/337376a0](https://doi.org/10.1038/337376a0))
    [Abs].
  - EVADÉ is single-copy in Col-0 (Mirouze 2009, [10.1038/nature08328](https://doi.org/10.1038/nature08328);
    Marí-Ordóñez 2013, [10.1038/ng.2703](https://doi.org/10.1038/ng.2703)) [Abs]. In Tsu-0 *met1*, HiFi reads assigned
    somatic insertions to source copies by unique placement (MAPQ ≥ 50) of the inserted segment. Only 2 of 4 intact
    EVD copies moved; one immobile copy had intact ORFs and 100% LTR identity (Movilli 2025,
    [10.1186/s13059-025-03691-7](https://doi.org/10.1186/s13059-025-03691-7)).
  - ONSEN: Ito 2011 ([10.1038/nature09861](https://doi.org/10.1038/nature09861)) [Abs]; parents are covered under the
    template rule below.
  - ALE-seq finds active families from extrachromosomal LTRs (Cho 2019,
    [10.1038/s41477-018-0320-9](https://doi.org/10.1038/s41477-018-0320-9)) [Abs].
- **Phylogenetics of local assemblies.** TELR showed in-vitro expansions from "single or multiple source lineages"
  (Han 2022) [Abs].
- **New polymorphic copy vs nearest fixed relative.** We found no study that does this. The closest are transduction
  tracing, HiFi insert placement (Movilli 2025) and ONSEN parent reconstruction. This part of ltrkin appears new.
- **Template rule.** Reverse transcription rebuilds both LTRs as U3 + R + U5:
  - U3 is copied from the RNA's 3′ end, that is the template's 3′ LTR.
  - U5 is copied from the RNA's 5′ end, that is the template's 5′ LTR.

  Gilboa 1979 ([10.1016/0092-8674(79)90357-x](https://doi.org/10.1016/0092-8674(79)90357-x)) [Abs] gives the
  strand-transfer model; Temin 1981 ([10.1016/0092-8674(81)90353-6](https://doi.org/10.1016/0092-8674(81)90353-6)) is
  UNVERIFIED (not read). **Use for parents:** Sanchez 2017
  ([10.1038/s41467-017-01374-x](https://doi.org/10.1038/s41467-017-01374-x)) inferred the LTR origins of 75 new ONSEN
  copies from SNPs that separate the U3 and R/U5 parts of old members' 5′ and 3′ LTRs. Most LTR recombination fell in
  R, at the first template switch, and 27/32 fully sequenced copies had two parents. We found no other genome-scale
  use (UNVERIFIED absence).

## D. Biology that sets defaults

| Parameter | Value | Source |
|---|---|---|
| TSD length | 4–6 bp, family-specific; MusD/ETn 6 bp; HERV-K HML-2 exceptions of 111 and 250 bp | Ou & Jiang 2018 ([10.1104/pp.17.01310](https://doi.org/10.1104/pp.17.01310); UNVERIFIED, via search); Wicker 2007 ([10.1038/nrg2165](https://doi.org/10.1038/nrg2165)) [Abs]; Ribet 2004; Kahyo 2017 ([10.1186/s12864-017-3872-6](https://doi.org/10.1186/s12864-017-3872-6)) [Abs] |
| Solo : intact | Rice about 1.6 solo per complete; *Vitis* 1.28; maize and conifers complete-rich (*Pinus* 1 solo : 3.7–7.5 complete). Rice < 25% intact. Human about 90% of HERVs solo; HERV-K 553 : 23 | Cossu 2017 ([10.1093/gbe/evx260](https://doi.org/10.1093/gbe/evx260)); Ma 2004 ([10.1101/gr.1466204](https://doi.org/10.1101/gr.1466204)) [Abs]; Thomas 2018 |
| LTR–LTR gene conversion | 23% of LTR-RTs (angiosperm mean): 1 event in *A. thaliana*, 40% in maize, 36–55% in spruce. Rodents: most LTRs; primates: few. Ectopic conversion among human LTRs | Cossu 2017; Kijima & Innan 2010 ([10.1093/molbev/msp295](https://doi.org/10.1093/molbev/msp295)) [Abs]; Trombetta 2016 ([10.1038/srep28710](https://doi.org/10.1038/srep28710)) [Abs] |
| HiFi reads | 13.5 kb, 99.8% (Wenger 2019, [10.1038/s41587-019-0217-9](https://doi.org/10.1038/s41587-019-0217-9)) [Abs]; 10–25 kb (Hon 2020, [10.1038/s41597-020-00743-4](https://doi.org/10.1038/s41597-020-00743-4)) [Abs]; PacBio 16S raw reads: insertions 0.137%, deletions 0.064% | Zhang 2023 ([10.1128/aem.00605-23](https://doi.org/10.1128/aem.00605-23)) |
| ONT reads | R10.4.1 simplex SUP median identity 99.26% (Hall 2024, [10.7554/elife.98300](https://doi.org/10.7554/elife.98300)). Insertions / deletions: R9.4.1 1.53% / 2.66% (net −1.1%), R10.4.1 0.46% / 0.62% (net −0.16%) | Zhang 2023 |
| ltrkin check, ONT | C11 and P3, R10.4.1 dorado SUP v5.2: N50 13 kb, median 1.1–1.7 kb, 57–59% of bases in reads ≥ 10 kb. Small indels: insertions 0.27–0.37%, deletions 0.41–0.50%. Net per 10 kb: median −8 bp, 5–95% −60 to +23 | Project BAMs |
| ltrkin check, HiFi | *P. supina* on its own assembly: N50 17.7 kb, median 17.5 kb. Net per 10 kb: median +2 bp, 5–95% −27 to +46 (includes heterozygous indels) | Project BAMs |
| Element length | Intact LTR-RTs: *P. supina* median 9.5 kb, 47% > 10 kb, 13% > 17 kb; *P. annua* median 10.8 kb, 55% > 10 kb; mean LTR 1.3–1.5 kb | LTRquest GFFs |
| Long deletions in CIGAR | Single-alignment `D` up to 18.8 kb (ONT) and 19.6 kb (HiFi) observed | Project BAMs |

ltrkin check method: `samtools view -F 0x904 -q 20` on Pa1A:100–120 Mb (C11), Pa2A:60–80 Mb (P3) and
Ps2B:40–60 Mb (supina). Per read, CIGAR I and D (< 50 bp) were summed over aligned spans ≥ 10 kb. The numbers include
real variation and come from one region per sample.

## Implications for ltrkin

**Rules to adopt**
1. **Keep solo as its own allele** (no long-read precedent). Validate it two ways: depth inside vs outside the
   internal region (the Thomas 2018 logic), and C11/P3 solo calls against their assemblies.
2. **Set τ from the data.** Per sample, use the 99th percentile of |Δ|/span at confident F/F spanning reads, with a
   50-bp floor and 3% as a cap. Current chemistries sit within ±0.6% (5–95%).
3. **Both BAM modes are required.** The project's ONT `lrhq.clean` and supina HiFi BAMs keep primary alignments only.
   Empty alleles of elements > ~19 kb are always split, and shorter ones may be. Keep the single-piece rescue.
4. **Stratify and flag nesting** (LTRquest `depth`); every tool fails there.
5. **`source`: report the nearest copy of any status first** and the nearest fixed copy second. Real masters are
   often polymorphic. Label the fixed-copy assignment a conservative proxy.
6. **Add a two-parent (mosaic) test**: find the nearest parent per window (for example 1 kb) along the internal
   region before reporting a single source. In the ONSEN burst, 84% of new copies were recombinant.
7. **Add a U3/U5 directional test** for candidate parents whose 5′ and 3′ LTRs differ: the child's U3 should match the
   parent's 3′ LTR and its U5 the parent's 5′ LTR. Iso-Seq TSSs can locate the U3/R boundary. The test is informative
   only for old parents.
8. **LTR-age checks are one-sided**: gene conversion makes copies look younger. Rank sources by internal-region
   divergence.
9. **TSDs**: learn each family's modal length (4–6 bp), allow 1 mismatch, and route long duplications to `other`.
10. **Full allele from junction reads**: ONT reads rarely span 10-kb elements (median read 1–2 kb), and HiFi reads
    rarely span the 13% of supina elements longer than 17 kb.

**Risks**
- `empty` in the assembly plant's own reads means a misassembly or a collapsed haplotype; flag it.
- Segmental duplications copy flanks, so MAPQ alone fails; keep the flank check and the `high_depth` flag.
- R9 or older ONT data carry a −1.1% net bias.
- In the outcrossing *P. supina*, phase blocks limit the haplotag test. Define it as allele × haplotype
  association (Fisher test) at heterozygous calls, and both haplotypes carrying the element at homozygous calls.

**Baselines**
1. **Sniffles2 `--genotype-vcf`**, encoding empty and solo as two overlapping DEL records. Run it on BAMs that keep
   supplementary alignments: the ONT `lrhq.bam`, and a HiFi re-alignment.
2. **SVJedi-graph**: it is built for overlapping alleles, as solo vs empty are, and reaches about 94% on HiFi HG002.
3. **kanpig**: best published concordance. Expect it to fail above 10 kb, and report that as a length stratum.
4. **Ad hoc caller v2** and the TIP caller (M4), as planned. LoRTE (CLR-era, no genotypes): cite, don't run.

Report precision, recall and 3 × 3 allele-state concordance. Stratify by element length (< 5, 5–10, 10–17,
> 17 kb), LTR identity, nesting depth, family copy number and read depth. Target at least 95% concordance for
isolated elements at ≥ 20× HiFi; the accepted SV range is 90–95%.
