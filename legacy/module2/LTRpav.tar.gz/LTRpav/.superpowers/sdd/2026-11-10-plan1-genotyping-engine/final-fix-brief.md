# Plan 1 final fix wave (one dispatch; review: final-review.md)

The final whole-branch review is `final-review.md`, in this directory. It covers b3f0c8f..7d71073 and asks for
"merge with fixes": 1 Critical, 3 Important and 8 new Minor. It also re-checked the 44 deferred minors from the
ledger: 35 still apply, 6 are partly fixed and 3 are fixed or moot. Read the whole review first.

## Work in a git worktree, never in the main working tree
A whole-genome run is executing from the main working tree (`benchmark_pav/main3/`, ltrpav imported from
`/data2/chris/maize_introgression/LTRpav/src`). Do not edit, check out, stash or reset anything in
`/data2/chris/maize_introgression/LTRpav`.

1. Create the worktree:
   `git -C /data2/chris/maize_introgression/LTRpav worktree add -b plan1-final-fixes
   /data2/chris/maize_introgression/LTRpav_finalfix 7d71073`.
   This writes only git metadata and the new directory.
2. **Test the worktree's code, never the main tree's:**
   `cd /data2/chris/maize_introgression/LTRpav_finalfix && PYTHONPATH=$PWD/src PATH=/home/chris/bin/mambaforge/envs/ltrpav_bench/bin:$PATH NUMPY_MADVISE_HUGEPAGE=0 python -m pytest -W error`.
   - Confirm once that `ltrpav.__file__` points into the worktree, from both a plain `python -c` and the `ltrpav`
     console script.
   - Subprocess CLI tests inherit PYTHONPATH.
3. Commit on branch `plan1-final-fixes` only. The controller fast-forwards `plan1-engine` after the run ends. Do not
   merge or rebase anything yourself.

## Rulings (controller)
**C1, LASTZ under asm5/asm10 scoring.**
- Pin LASTZ to asm20 scoring whatever the pair's d. asm20 is the only configuration the bake-off measured and chose;
  asm10 and asm5 were never validated.
- mappy keeps PRESET_CUTS.
- Test: reuse the reviewer's close-pair probe, scaled down to a pytest fixture. A close pair with 5%-divergent
  patches is called right under LASTZ.
- Update the docstrings and DESIGN 5.3.

**I1, QC reciprocity and annot_agree.**
- Compute both as DESIGN 10.1 defines them, following the review's definitions:
  - reciprocity among loci resolved both ways;
  - annot_agree without B elements that span the site.
- Keep the old quantities only if the review shows they answer a different, named question. If so, give them new
  names; do not leave them under the bar's name.
- Tests with hand-computed values.
- **Never change the bars.**

**I2, stale checkpoints.**
- Every stage key includes an engine fingerprint: the sha256 of the package's own source files, plus the versions of
  the external tools the stage uses (lastz, minimap2 and so on, as applicable). Record LASTZ and its version in the
  manifest.
- Any engine change therefore recomputes; correctness comes before cache reuse.
- Tests:
  - a key changes when a source byte changes, simulated through a patched fingerprint function;
  - an outdir finished by an "older engine" recomputes.
- Note in DESIGN 8: outdirs from an older engine are recomputed, not reused.

**I3, malformed annotation records.**
- GFF3, BED and LTRquest loaders warn and skip a malformed record, with file:line and the reason.
- They fail fast with a one-line error on structural problems: a missing required column, an unreadable file, or
  zero usable records.
- Count the skipped records in the log and the manifest.
- Unused feature types, such as a bad `gene` line in a GFF3, must never abort a run.
- Tests for each loader.

**The 8 new minors and the 41 deferred minors** (still applies or partly fixed).
- Fix every one that is safe and cheap. Include at least:
  - the merged windows' per-element anchor distances (24H minor 2);
  - DESIGN 5.1's flank-cap text. Its wording is in `task-24b-report.md`'s "Fix round 1". Say that 2 kb matches the
    10-20-kb caps "at about half their cost": 2 kb costs 0.89x as much as 5 kb.
  - DESIGN section 9's stale lines;
  - LASTZ_SCORING and LASTZ_SEED moved into constants.py;
  - cleanup of /dev/shm and orphaned lastz processes on worker death;
  - the inv_site LASTZ test on window-sized flanks;
  - the rule 5a docstring's 88 kb.
- List each one you skip, with the reason, in your report. The controller adjudicates the residuals.
- No new CLI option, threshold or constant without a one-line reason and a link to the finding that needs it.

## Calls must not change except where a finding requires it
- After all commits, run a default `ltrpav run` from the worktree's code, using `PYTHONPATH` and a scratch outdir, on
  sims R1_s1 and R3_s2, both directions.
- Compare against the bake-off's `flank-mm2_2k_lastz` calls:
  - `D/runs/<sim>/flank-mm2_2k_lastz/`, where D = `/data2/chris/maize_introgression/benchmark_pav/bakeoff`;
  - also the chr10 B73v5->TIL18 genotype-only run with the flank-mm2_2k anchors.
- Expected differences come only from 24H's later changes (rule 5a (a), the window merge, the minus-strand chain),
  the merged windows' anchor columns, and any change this wave makes deliberately. Explain every differing call.

## Constraints
- **Commits:** one per finding group, with plain subjects. Use the existing identity, set nothing, and add no
  trailers or AI attribution: the user is the sole author. Never push.
- **Verification:** after each commit, the full suite under `-W error` (from the worktree, as above) and `ruff check
  .` must be clean.
- **Probes:** at most 16 threads, each under `timeout 15m` in the foreground. Export `NUMPY_MADVISE_HUGEPAGE=0`.
  Scratch goes only under `/data2/chris/maize_introgression/benchmark_pav/final_fix/`.
- **Running jobs:** never touch the main3 run (PID 2457144), its outputs or its sampler.
- No subagents. American English.

## Report
Write `final-fix-report.md` in this directory. If the harness refuses the write, return the text instead. Include:
- per finding: fixed, partly fixed or skipped, with the commit and test;
- the calls comparison;
- the worktree path and branch head.

Return ONLY:
- the branch head;
- the commit list;
- counts of fixed, partly fixed and skipped;
- one line per skipped Critical or Important finding (there should be none);
- the calls-comparison summary;
- concerns.
