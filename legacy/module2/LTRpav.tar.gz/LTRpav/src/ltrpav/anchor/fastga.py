"""Route "fastga" (whole genome): FastGA's alignment of A against B, read as PAF with =/X CIGARs.

FastGA (Myers) is a fast, low-memory whole-genome aligner. Both FASTAs are symlinked into <workdir>/fastga/
(<label>.fa, or <label>.fa.gz for gzip/bgzip input) so its .1gdb/.gix files land there, never next to user
data; `-k` keeps them for the pair's siblings. The PAF (-pafx: CIGAR with =/X) is streamed through gzip into
<workdir>/fastga/<X>__<Y>.fastga.paf.gz (X, Y the sorted labels; query = X) and read with `read_paf`, which
cuts each record at its indels of >= SPLIT_INDEL bp.
"""
from __future__ import annotations

import contextlib
import fcntl
import gzip
import logging
import os
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from typing import TYPE_CHECKING

from ..blocks import read_paf
from ..checkpoint import CHECKSUM_CACHE, atomic_path, file_checksum, tool_version
from ..constants import SPLIT_INDEL

if TYPE_CHECKING:
    import numpy as np

    from . import PairContext

log = logging.getLogger("ltrpav.anchor")

PAF_FORMAT = "-pafx"  # PAF with =/X CIGAR (cg:Z:), so read_paf splits at long indels and counts '=' matches
_GZIP_SUFFIXES = (".gz", ".bgz")


class FastgaRoute:
    """Whole-genome route: FastGA of the sorted-first label (query, A) against the other (target, B)."""

    name = "fastga"
    whole_genome = True
    reads_elements = False

    def params(self, ctx: PairContext) -> dict:
        return {"format": PAF_FORMAT, "split_indel": SPLIT_INDEL, "FastGA": tool_version("FastGA")}

    def raw_blocks(self, ctx: PairContext) -> np.ndarray:
        exe = shutil.which("FastGA")
        if exe is None:
            raise RuntimeError("route 'fastga' needs the FastGA binary on PATH (not found)")
        x, y = sorted((ctx.a.label, ctx.b.label))
        swap = ctx.a.label != x  # PAF query is always X; read it swapped when A is Y
        fadir = ctx.workdir / "fastga"
        tmpdir = ctx.workdir / "tmp"
        fadir.mkdir(parents=True, exist_ok=True)
        tmpdir.mkdir(parents=True, exist_ok=True)
        qx, ty = (ctx.a_fa, ctx.b_fa) if not swap else (ctx.b_fa, ctx.a_fa)
        sums = ctx.workdir / CHECKSUM_CACHE
        links = [_link(fadir, x, qx.path, sums), _link(fadir, y, ty.path, sums)]
        out = fadir / f"{x}__{y}.fastga.paf.gz"
        cmd = [exe, PAF_FORMAT, f"-T{max(1, ctx.threads)}", f"-P{tmpdir}", "-k", links[0].name, links[1].name]
        log.debug("%s vs %s (fastga): %s", x, y, " ".join(cmd))
        t0 = time.perf_counter()
        with (_locked(sorted({_stem(lk) for lk in links})), atomic_path(out) as tmp,
              tempfile.TemporaryFile() as err):
            proc = subprocess.Popen(cmd, cwd=fadir, stdout=subprocess.PIPE, stderr=err)
            try:
                with open(tmp, "wb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", mtime=0,
                                                           filename="") as gz:
                    shutil.copyfileobj(proc.stdout, gz, 1 << 20)
                code = proc.wait()
            finally:
                proc.stdout.close()
                if proc.poll() is None:
                    proc.kill()
                    proc.wait()
            if code != 0:
                err.seek(0)
                tail = err.read().decode(errors="replace").strip()[-2000:]
                raise RuntimeError(f"FastGA failed on {x} vs {y} (exit {code}): {tail}")
        log.info("%s vs %s (fastga): aligned in %.1f s", x, y, time.perf_counter() - t0)
        a_index = {n: i for i, n in enumerate(ctx.a_fa.lengths())}
        b_index = {n: i for i, n in enumerate(ctx.b_fa.lengths())}
        return read_paf(out, a_index, b_index, swap=swap, split_indel=SPLIT_INDEL)


def _stem(link: Path) -> Path:
    """The genome's index file stem: its link without .fa / .fa.gz."""
    return link.with_name(link.name.removesuffix(".gz").removesuffix(".fa"))


@contextlib.contextmanager
def _locked(stems: list[Path]):
    """Exclusive flock on <stem>.lock for each stem, taken in sorted order (no deadlock), so pairs sharing a
    genome never build or read its index at the same time. Held across the FastGA run."""
    with contextlib.ExitStack() as stack:
        for stem in stems:
            fh = stack.enter_context(open(stem.with_name(stem.name + ".lock"), "w"))
            fcntl.flock(fh, fcntl.LOCK_EX)
        yield


def _link(fadir: Path, label: str, source: Path, sums: Path) -> Path:
    """<fadir>/<label>.<sha256[:12]>.fa[.gz] -> source. The checksum in the name gives a changed FASTA its
    own index files: FastGA (run with -k) does not check that an existing index matches its source."""
    ext = ".fa.gz" if Path(source).suffix in _GZIP_SUFFIXES else ".fa"
    link = fadir / f"{label}.{file_checksum(source, sums)[:12]}{ext}"
    target = Path(source).resolve()
    if not (link.is_symlink() and Path(os.readlink(link)) == target):
        with atomic_path(link) as tmp:  # atomic: concurrent pairs linking the same genome never collide
            tmp.symlink_to(target)
    return link
