# Task 24H review: 568f90d..7d71073 (items 0-4)

Reviewer scope: the diff, the brief, the item-4 ruling, PARAMS.md section 4 and the bake-off `backends.py`, with one
focused check for each named risk. Read-only on the checkout (git status unchanged; plan1-engine at 7d71073).
Reviewer scratch: `D/review24h/` (D = /data2/chris/maize_introgression/benchmark_pav/bakeoff), ltrpav_bench env,
8 threads, `timeout 15m`.

## Spec Compliance

Verdict: ✅ compliant. Notes are marked ⚠️.

### What I checked myself (not taken from the report)

| Check | Result |
|---|---|
| Item 0 exact port: `git archive 4ae76b8` run on sim R3_s2 (default `ltrpav run`), both directions | calls byte-identical to `D/runs/R3_s2/flank-mm2_2k_lastz`; loci.tsv, pav_matrix.tsv and qc.tsv identical too |
| Item 0 exact port on real data: chr10 B73v5->TIL18 with the flank-mm2_2k anchors | calls and windows byte-identical to `D/chr10/runs/flank-mm2_2k_lastz` (105.7 s at 8 threads) |
| Item 0's command line against `backends.py` | same options in the same order (`--chain` appended on plus only); same field mapping (zstart1/end1 = B -> r_st/r_en, zstart2+/end2+ = A -> q_st/q_en); same strand -> `inv` route through `alnmap_from_hits` |
| HEAD reproduces the implementer's outputs | R3_s2 calls and chr10 B73v5->TIL18 calls byte-identical to `task24h_scratch/item4/sims_chained` and `item4/chr10_chained` |
| chr10 item 0 -> HEAD transitions | 175 calls differ: item 1, 30 to U (T/medium 16, P/high 5, O/medium 4, E/high 3, P/medium 1, one inherited flag); item 4, 145 U inv_site to O 101, D 20, U ambiguous 19, E/high 5. Matches the report exactly |
| Acceptance 1 (HEAD's `align_window(..., "lastz")`, the implementer's timing script) | mm2 TIL18>TIL01 wid 1277: 14.4 s (187 inverted hits); flank-mm2_2k TIL01>TIL18 wid 1466: 35.0 s (169 inverted hits). Both <= 60 s |
| Acceptance 2 | The pooled reproduction row equals the bake-off's own `scores/final/pooled.tsv` row for flank-mm2_2k_lastz, field for field (crf 4613/4960; P high 2799/2; E high 1320/8). Chained row: P high 0.9993, E high 0.9940, crf 0.9306 (4616/4960). Both bars met with margin |
| Focused tests, `-W error`, bench bin first on PATH | test_lastz, test_window, test_localign, test_smoke: 154 passed; rule 5a and QC subsets of test_classify and test_loci: 30 passed; test_cli fail-fast plus the default toy run: 10 passed. No warnings |
| Missing-binary tests with PATH=/usr/bin:/bin | 5 passed. test_lastz under the same PATH: 7 passed, 26 skipped ("lastz not on PATH"), as designed |
| `ruff check --no-cache .` | All checks passed |
| Authorship | 5 commits, existing identity (cwb14), no trailers, no AI mention in messages or diff |
| American English in added lines | no British spellings found |

I did not run the full suite (the review brief forbids it). The report's 784 is unverified, but every file this
diff touches was run, except test_genotype, which only renames the backend to `backend="mappy"`.

### Item 0: LASTZ port, the default
- ✅ The backend is built into `localign.py`, registered as `lastz`; `DEFAULT_BACKEND = "lastz"` in constants.py with a reason citing the bake-off. `cli.BACKEND`, `genotype_pair` and `align_window` default to it, and mappy stays registered.
- ✅ No CLI option.
- ✅ Fail fast: `cli._backend` runs in `ltrpav run` and `ltrpav-genotype` after the route check, before any output (one line, exit 1; tests assert nothing is written).
- ✅ The missing-binary test builds its own PATH of stubs (the Task 24G minor is fixed).
- ✅ environment.yml already pins lastz=1.04.60. Both envs hold build hab16a5f_0.
- ✅ Exact port: independently confirmed above, on a sim and on chr10.
- ✅ Tests: the 21 toy cases x 7 seeds; P/E/T/O on WINDOW_PAD flanks; the default backend; options; CIGAR parsing; failure paths; missing binary.
- ✅ DESIGN 5.3; the commit subject is as briefed.
- ⚠️ `LASTZ_SCORING` and `LASTZ_SEED` are new module constants outside constants.py (Minor 3).

### Item 1: rule 5a
- ✅ (a): the crossing run needs >= MIN_SEG aligned A bases on both sides of the junction. The element side is counted by `_own` (children's spans excluded, the classifier's convention), bounded by the run and the element (`min(a1, t)`, `max(a0, s)`). Runs are contiguous on A, so `aligned_bp` over the run's extent counts only that run's segments. Correct.
- ✅ (b): the TSD exception needs the extrapolated LTR image strictly inside rule 3's lo/hi. The reading is sound: under a collinear AlnMap the aligned image always lies between lo and hi, so only the extrapolated ends can cross.
- ✅ `_solo_tsd` was split into `_ltr_image` and `_tsd_beside` with the same arithmetic (checked line by line).
- ✅ No new constant.
- ✅ The four requested tests exist and are minimal hand-built maps that isolate each clause (checked by hand).
- ✅ Docstring and DESIGN 5.4 updated.
- ⚠️ (b) is inert on data, as the implementer reports. The case-12 probe (rerun here) shows both crossing runs carry a 1-base flank tail, so lo and hi sit at the copy itself. Closing case 12 needs a different rule; that is a controller decision, not an implementation defect.

### Item 2: window merge
- ✅ `PADDED_CAP = WINDOW_CAP + 2*WINDOW_PAD - 1` is exactly the longest window `make_windows` builds on A and on B. `small` caps both `aR - aL` and `|bR - bL|` at WINDOW_CAP, and the window is `[aL-PAD+1, aR+PAD)`, on either B strand.
- ✅ The choice is stated, with the -1 explained.
- ✅ Clipped windows at sequence ends loosen the anchor-span reading by at most PAD-1 per end, but never allow a window longer than PADDED_CAP. Documented in the report, not in code (harmless).
- ✅ Required test present; a second test pins PADDED_CAP to make_windows. `PADDED_CAP` is derived, not a new free parameter.
- ⚠️ Merging identical windows now rewrites interior elements' `anchor_left`/`anchor_right` (Minor 2).

### Item 3: e_in_annot
- ✅ The exemption is applied inside the E branch only. Ancestor nodes map to the same pc rows (`node - offset[a]`), filtered to P/S/T on the same B seqid, with a closed-interval overlap test. The rename `ancestor_roots` -> `ancestors` keeps the shared filter identical, and no stale callers remain in src or tests.
- ✅ The argument for e_in_annot only holds. In the shared filter, "overlaps the host's image" would also exempt a nested child's own B ortholog, which lies inside the host's image, and drop correct nested P calls from annot_agree's numerator and denominator.
- ✅ Docstring, DESIGN 10.1 note, tests and the scratch recompute are all present.
- ⚠️ "Overlaps", as briefed, also exempts the 7-11 per direction where h lies inside the host's image (report concern 4). A containment test would be tighter. That is the controller's call.

### Item 4: minus strand chained
- ✅ `--chain` moved into the shared `lastz_args`; each strand is still its own LASTZ run. Minus hits reach `inv`: confirmed by the stub test, by 187/169 inverted hits on the satellite windows, and by my probe (toy `inv_site` on WINDOW_PAD flanks stays U inv_site at all 7 seeds).
- ✅ No new parameter. Both acceptance criteria met (checked above).
- ⚠️ `inv` now holds one minus-strand chain, not every inverted hit. The 145 chr10 inv_site calls that moved are mostly non-inverted in the AnchorWave read-out, which does turn minus-strand MAF blocks into inverted hits. The evidence supports the change; DESIGN 5.3 states it.
- ⚠️ Residual risk for Task 25: there is still no per-window time guard. Chaining bounds the two known windows (35 s worst), but an unseen satellite type (teosinte knobs) would show up only as a long chunk.

## Strengths
- The port is exact on real data, not only on the sims, and the deviations are named and harmless: an unknown preset fails up front, `stdin=DEVNULL`, the binary is looked up per window, and the logger prefix changed.
- The fail-fast path is hermetic. The test builds PATH from stubs of every executable the engine runs minus one, so it no longer depends on the caller's PATH.
- The rule 5a tests are hand-built AlnMaps that make each clause the only one that can decide, with the thin case on both sides and at MIN_SEG-1 and MIN_SEG.
- PADDED_CAP is derived exactly, including the -1, and pinned to make_windows by a test, so the two cannot drift apart silently.
- The QC change is tightly scoped, with a measured reason not to touch annot_agree.
- Item 4 was handled well. Acceptance was declared first. The reproduction row validates the pooling against the bake-off's own numbers. The chr10 transitions are fully accounted for, and the report is candid about what did not work: (b) is inert, (a)'s cost through inheritance, concern 4.

## Issues

### Critical
None.

### Important
None.

### Minor

1. **Done markers do not see this task's behavior changes.** `src/ltrpav/genotype.py:84`, `src/ltrpav/checkpoint.py:53`, `src/ltrpav/__init__.py:8`.
   - What: the pair and chunk keys hold the inputs, backend name, preset, route and `__version__` (still `0.1.0.dev0`). Items 1, 2 and 4 change calls under the same backend name and version, so a rerun into an outdir finished by an earlier engine logs "calls done, skip" and keeps the old calls. The manifest would then say `backend: lastz` for calls made with the bake-off's options or the old rule 5a.
   - Why it matters: Task 25 follows. Reusing any earlier outdir (for example the chr10 run dirs) would silently mix engines. The mechanism predates this task, but this is the first task to change calls without changing a keyed field.
   - Fix: bump `__version__` (this also invalidates anchors), or add the backend's options (`lastz_args(preset)`) to the genotype params. At minimum, Task 25 should start from fresh outdirs and copy only anchors, as this task's checks did.

2. **Merged windows report another element's anchor distances.** `src/ltrpav/window.py:89-92` (field documented at `:35` as "bp from element to anchor"); copied into every call at `classify.py:410`.
   - What: a merged window keeps the first window's `anchor_left` and the last one's `anchor_right`. Item 2 now merges identical windows, so in the 22-window mm2 TIL18->TIL01 group an element 152,683 bp from its left anchor reports 11,001 (`task24h_scratch/item2/compare_mm2_TIL18_TIL01.log`). 44 chr10 mm2 calls carry another element's distances.
   - Why it matters: this is an evidence column only. States and tiers are unchanged, and the margin is the shared anchors'. But any Task 25 filter on anchor distance would treat interior elements of merged windows as tightly anchored. Overlap merges already did this; item 2 extends it.
   - Fix: carry the window's anchor positions and derive each element's distances in classify, or document the columns as the merged window's outermost elements' distances.

3. **LASTZ settings live outside constants.py.** `src/ltrpav/localign.py:291-292`.
   - What: `LASTZ_SCORING` and `LASTZ_SEED` are new module constants. The mappy backend's settings (`MAPPY_BEST_N`, `MAPPY_*_FLAGS`) and `PRESET_CUTS` live in constants.py, and `LASTZ_SCORING["asm20"]` duplicates `SCORE`.
   - Why it matters: the task's constraint is that constants live in constants.py with a one-line reason. The values are the bake-off's and carry reasons, so this is placement only.
   - Fix: move both to constants.py with one-line reasons (build the asm20 entry from `SCORE`).

4. **DESIGN section 9 is stale after this task.** `docs/DESIGN.md:443-451`.
   - What: lines 443-444 say a default run "reproduced the bake-off's LASTZ calls byte for byte". That is true of item 0 only: item 4 changes 12 sim calls and 126 chr10 calls; 5.3 says so, section 9 does not. Lines 445-451 still list "a run that reaches only a few bases into the element" and "windows just over WINDOW_CAP are never merged" as caveats to address before Task 25. Items 1(a) and 2 addressed them; the TSD-exception and repetitive-flank loopholes remain open.
   - Fix: write "byte-identical before the minus strand was chained (5.3)", and mark the two caveats resolved, keeping the open ones.

5. **A killed worker leaves its LASTZ temp dir and child behind.** `src/ltrpav/localign.py:374` with `genotype._die_with_parent`.
   - What: workers die by SIGTERM with the default action, so `TemporaryDirectory` cleanup never runs. The lastz child has no parent-death signal and runs on, orphaned, until it finishes. The implementer hit one leftover dir.
   - Why it matters: /dev/shm is RAM. Each crash or SLURM kill can leave one window's pair of FASTAs (up to about 1 MB) per worker, until reboot. Item 4 bounds an orphan's CPU to about 35 s on the worst known window.
   - Fix: put the worker PID in the temp prefix and remove `ltrpav_lastz_*` dirs of dead PIDs at pair start or in `_init_worker`. Optionally set PR_SET_PDEATHSIG on the lastz child.

6. **No LASTZ test of `inv_site` on window-sized flanks.** `tests/test_lastz.py:23`.
   - What: `CUT` covers P, E, T and O. The mappy suite checks inv_site on WINDOW_PAD flanks, but no LASTZ test does, although item 4 changed exactly what feeds `inv`. My probe passes at all 7 seeds.
   - Fix: add `"inv_site"` to `CUT`. D_left is not valid under the cut: the cut removes the 500 bp of left flank that B keeps.

7. **The case-12 distance in the rule 5a docstring is off.** `src/ltrpav/classify.py:279`.
   - What: the docstring says "a copy 95 kb from the empty site". The dispute inspection (`inspect-disputes-report.md:171`) and this task's report say 88 kb, and the probe's geometry gives 87.7 kb from the left flank's image.
   - Fix: write 88 kb.

## Assessment
**Task quality: Approved.** The port is byte-exact on sims and chr10. Rule 5a(a), the padded-cap merge, the e_in_annot exemption and the chained minus strand are correct and well tested, and both item-4 acceptance criteria hold when re-measured. The remaining issues are minor. Before Task 25, the controller should note Minor 1 (use fresh outdirs or bump the version) and Minor 2 (the anchor-distance columns in merged windows).
