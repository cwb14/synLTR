#!/usr/bin/env python3
"""Overview of the ELAI truth for selected lines: genome-wide and per-chromosome ancestry (dosage/2), tract lengths."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import pandas as pd, numpy as np, sys
d = pd.read_csv(sys.argv[1], sep="\t")
lines = [c for c in d.columns if c.endswith(".amp")]
print("n SNP", len(d), "; n_called median", d.n_called.median())
print("mean dosage/2 across all lines (panel mean ancestry):", round(d.mean_dosage.mean()/2, 4))
for l in lines:
    x = d[l].where(d[l] > -900)
    print(l, "called", int(x.notna().sum()), "mean_ancestry", round(x.mean()/2, 4), "frac>1.8", round((x > 1.8).mean(), 4),
          "frac<0.2", round((x < 0.2).mean(), 4))
print("\nper-chrom mean ancestry (dosage/2):")
out = {}
for l in ["mean_dosage"] + lines:
    x = d[l].where(d[l] > -900)
    out[l] = (x/2).groupby(d.chrom).mean().round(3)
print(pd.DataFrame(out).to_string())
# tracts in B73: contiguous SNP runs with dosage > 1
x = d[["chrom", "pos", "B73.amp"]].copy()
x = x[x["B73.amp"] > -900]
def tracts(x, thr):
    res = []
    for c, g in x.groupby("chrom"):
        on = (g["B73.amp"].values > thr)
        p = g.pos.values
        i = 0
        while i < len(on):
            if on[i]:
                j = i
                while j+1 < len(on) and on[j+1]:
                    j += 1
                res.append((c, p[i], p[j], j-i+1))
                i = j+1
            else:
                i += 1
    return pd.DataFrame(res, columns=["chrom", "s", "e", "n"])
for thr in (1.0, 1.8):
    t = tracts(x, thr); t["len"] = t.e - t.s + 1
    print(f"\nB73 tracts dosage>{thr}: n={len(t)} total_Mb={t.len.sum()/1e6:.1f} median={t.len.median():.0f} mean={t.len.mean():.0f} "
          f"q90={t.len.quantile(.9):.0f} q99={t.len.quantile(.99):.0f} max={t.len.max()} frac_bp_in_tracts_ge100kb={t.len[t.len>=1e5].sum()/t.len.sum():.3f} ge1Mb={t.len[t.len>=1e6].sum()/t.len.sum():.3f}")
    print(t.sort_values("len", ascending=False).head(12).to_string(index=False))
# SNP spacing
sp = d.groupby("chrom").pos.apply(lambda s: s.diff().dropna()).reset_index(drop=True)
print("\nSNP spacing median", sp.median(), "mean", round(sp.mean()), "q99", sp.quantile(.99))
for name, c, s, e in [("HPC1_v4", 3, 8542107, 8544078), ("ZmLPCAT1_v4~", 5, 195450000, 195550000)]:
    w = d[(d.chrom == c) & (d.pos >= s-50000) & (d.pos <= e+50000)]
    print(name, "n SNP", len(w), "B73 mean dosage", round(w["B73.amp"].where(w["B73.amp"] > -900).mean(), 3), "panel mean", round(w.mean_dosage.mean(), 3), "frac>1.8 max", w["frac_gt1.8"].max() if len(w) else None)
