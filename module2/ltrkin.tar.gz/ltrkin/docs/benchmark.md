# ltrkin benchmarks

Date: 2026-11-10. Tool version 0.1.0. Bulky outputs were kept outside the
repository. The scripts are in `benchmark/`.

## Summary
| what | truth | headline |
|---|---|---|
| unit tests | synthetic diploid with planted states; planted genealogy | 23 pass (all allele states, both BAM modes, nesting, decoy, ties, segmental duplication, two-parent mosaic, hash-seed reproducibility) |
| zygosity, real (*P. supina*, HiFi 63x) | read phasing (haplotags) in two phased regions | F/F precision 0.984, recall 0.50; one-haplotype precision 0.91 (F/E 0.96) |
| presence/absence, real (*P. annua* C11, P3; ONT ~18x) | each accession's own assembly | absent precision 0.999-1.000, recall 0.87; present precision 0.997-0.998, recall 0.996-0.998 (`pav`, final code); TIP caller (purpose-built) absent 0.999 / 0.86-0.88 |
| simulated reads (430 planted sites in real *P. supina* sequence; HiFi/ONT 10-40x; both BAM modes) | planted states | concordance HiFi 92.8 / 95.3 / 99.5% and ONT 90.2 / 95.8 / 98.4% at 10 / 20 / 40x (99.7-100% at GQ >= 20); Sniffles2 force-genotyping 76-80%; no false empty or solo call; details in `benchmark_genotype_sim.md` |
| source assignment (simulated genealogies, 9 scenarios) | known parents | parent sampled and fixed: exact parent 0.57-0.82 in the 7 scenarios with >= 85 such copies (0.38-0.47 in two small high-loss sets); parent among tied sources 0.67-0.85 |
| two-parent (recombinant) test | simulated template switches | false positives 0.000 in 6 scenarios without recombination; power 0.51-0.52 |
| locality test calibration | random placement, 200 re-placements x 9 scenarios | false positive rate at alpha 0.05: 0.015-0.065 |
| candidate search completeness (*P. supina*, exhaustive check) | exhaustive pairwise alignment, 100 new copies | nearest fixed copy missed 0/4 at <= 0.2% and 1/14 at 0.2-0.5% divergence; exhaustive best among ltrkin's tied sources 0.88 overall |

## 1. Zygosity against read phasing (*P. supina*)
- **Data.** *P. supina* HiFi reads (~63x) on the plant's own assembly, primary alignments only. ltrkin genotyped all
  27,945 annotated elements in 3 min 23 s with 8 threads and 328 MB of memory.
  - Fitted model: depth mode 63, mean read span 17.8 kb, read error 0.001.
- **Truth** (`benchmark/haplotag_eval.py`). Reads haplotagged by SNV phasing in two regions (Ps1B 45.7-60.2 Mb,
  Ps2B 47.0-59.8 Mb). A carrying read is anchored in the flank and reaches the internal region. Tags count only if
  they rest on a net agreement of >= 5 phased alleles.
  - **two_hap:** both haplotypes carry the element.
  - **one_hap:** one carries it, and the other is sampled nearby.
  - The truth does not use ltrkin's model.
- **Results (GQ >= 20).** 1,348 elements, 1,195 with truth.

  | ltrkin call | one_hap | two_hap | precision |
  |---|---|---|---|
  | F/F | 6 | 378 | 0.984 |
  | F/E | 187 | 7 | 0.964 |
  | F/N | 150 | 27 | 0.847 |
  | F/S | 17 | 2 | 0.89 |

- **Recall.** two_hap 0.50 (378/753); one_hap 0.80.
- **Why F/F recall is low.** Most misses are GQ < 20 at sites whose read depth lies between the one- and
  two-haplotype levels (median flank depth 50 vs a mode of 63). Mapping quality is not the cause: all-read depth
  equals MAPQ >= 20 depth there. The null allele rests on depth, and the model stays conservative where depth is
  ambiguous.
- **Comparison.** The ad hoc caller ltrkin replaces (count thresholds, no depth term) had a homozygous precision of
  0.51 on the young copies of the same regions. Hemizygous copies (the other haplotype lacks the site and its flanks)
  were called homozygous.
- **Weak-tag artifact.** Weakly tagged reads (|score| < 5) make the truth itself wrong: at 27 F/E sites the tags had
  median scores of 1-9, vs 46-85 at true heterozygotes, and showed both haplotypes carrying the element.

## 1b. Presence/absence against assemblies (*P. annua*)
- **Data.** ONT reads (BAMs keep supplementary alignments) of five accessions on the *P. annua* reference; 71,621
  elements.
  - Fitted depth: C11 18x, P3 17x, R1 7x, I3 and J10 4x.
  - Run time: 23 min for all five accessions (71,621 elements each) with 8 threads; peak memory 1.35 GB.
- **Truth.** The orthologous-site state in the C11 and P3 assemblies, independent of reads: present, or an empty
  site. The accessions are inbred, so truth is homozygous.
- **Baseline.** The project's TIP caller, excluding its calls copied from the assemblies.
- **Results** (`benchmark/assembly_eval.py`):

  | call | C11 absent P / R | C11 present P / R | P3 absent P / R | P3 present P / R |
  |---|---|---|---|---|
  | ltrkin genotype, GQ >= 20 | 1.000 / 0.21 | 0.9999 / 0.50 | 1.000 / 0.21 | 0.9997 / 0.43 |
  | ltrkin `pav` (allele posterior >= 0.99), before the read fixes | 1.000 / 0.847 | 0.9966 / 0.998 | 0.9993 / 0.843 | 0.9954 / 0.996 |
  | **ltrkin `pav`, final code** | **1.0000 / 0.872** | **0.9979 / 0.998** | **0.9993 / 0.873** | **0.9973 / 0.996** |
  | ltrkin `--ploidy 1` (inbred model), `pav`, final code | 0.984 / 0.912 | 0.9997 / 0.996 | 0.982 / 0.916 | 0.9992 / 0.993 |
  | TIP caller | 0.9996 / 0.864 | 0.9997 / 0.994 | 0.9993 / 0.879 | 0.9995 / 0.992 |

- **Why GQ alone fails here.** At 9x per haplotype the genotype quality is dominated by dosage uncertainty (F/F vs
  F/N). That is why `ltrkin genotype` reports allele-presence posteriors (`p_F`, `p_E`, `p_S`) and a `pav` call.
  `--ploidy 1` is the natural model for inbred lines.
- **Ploidy 1 vs ploidy 2.** Ploidy 1 raises absence recall to 0.91 but lowers absence precision to 0.98. Residual
  heterozygous sites are forced to one allele, which the collapsed assembly may not share. Ploidy 2 with `pav` is
  the conservative default.
- **Strata.** Recall is stable across element length (< 5 to > 17 kb), age and nesting. Absent recall is 0.80-0.88
  in every stratum, and only 0.4-2.3% of elements stay uncertain.

## 2. Source assignment on simulated genealogies
- **Simulation** (`benchmark/sim_source.py`):
  - families evolve by point mutation;
  - active copies transpose, and a new copy inherits its parent's internal region plus reverse-transcription errors;
  - LTRs follow the template rule (U3 from the 3' LTR, U5 from the 5' LTR);
  - copies are lost at random;
  - recent insertions are usually still polymorphic ("new").
- **Scoring** (`eval_source.py`): the relation of each assigned source to the new copy in the true genealogy.
- **Results** (weights of tied candidates; "parent sampled & fixed" = the true parent is in the genome and fixed):

  | scenario | new copies | parent fixed: exact | parent fixed: in ties | parent new: ancestor assigned | flag "closer non-fixed relative" when parent not fixed / fixed |
  |---|---|---|---|---|---|
  | default (half of copies active) | 248 | 0.72 | 0.74 | 0.60 | 0.77 / 0.18 |
  | few masters (10% active) | 198 | 0.59 | 0.67 | 0.44 | 0.38 / 0.16 |
  | all copies active | 458 | 0.82 | 0.85 | 0.69 | 0.72 / 0.17 |
  | high loss of copies | 123 | 0.75 | 0.78 | 0.33 | 0.45 / 0.21 |

  (First-pass numbers, before the final code: see the rerun section below.)
- **Reading.** The nearest fixed copy is the true parent in 59-82% of cases when the parent is sampled and fixed. A
  sibling is the commonest error. When the parent is itself polymorphic, the nearest fixed copy is usually an
  ancestor (the parent's lineage), and the "closer non-fixed relative" flag fires in 38-77% of such cases.
- **Evidence columns separate true parents from other assignments:**
  - source-private mutations: median 1 vs 2-3;
  - any shared derived mutation: 0.72-0.97 vs 0.53-0.84;
  - source clearly older: 0.50-0.69 vs 0.22-0.34. The age check is one-sided, because LTR gene conversion makes
    copies look younger.

## 2b. Two-parent (recombinant) test
- **Model.** In the simulation (`sim_source.py --p-rec`), a new copy's internal region switches from its parent to
  a co-packaged partner at a random breakpoint.
- **Test.** For each ordered candidate pair, the diagnostic sites are labeled by the parent the new copy follows.
  The exact scan test (maximum of the running sum, reflection principle) gives a p-value, with Bonferroni over pairs.
  The mosaic must also explain >= 3 more differences than the best single candidate.
- **Validation.** Three recombinant simulations (one fresh, not used for design) and six without recombination (one
  fresh).

  | | value |
  |---|---|
  | false positives without recombination | 0.000 in all six |
  | power | 0.52 in each recombinant set |
  | power when the parents differ at 21-50 sites | 0.43-0.80 |
  | power when they differ at > 50 sites | 0.56-0.85 |
  | flagged single-parent copies in recombinant sets | 0.02-0.09 (probably copies with mosaic ancestors) |

- **Design history.** Two earlier rules had no null model and failed: a cap of one conflict per side (power 0.45),
  and net support per side (false positives up to 0.43). Both are kept in the bug list below.

## 3. Locality test calibration
- **Design** (`calibrate_locality.py`): each simulated genome's copies are re-placed at random 200 times, keeping
  per-chromosome counts.
- **Two nulls:**
  - per-copy bp share (Poisson-binomial);
  - a permutation that shuffles new copies' chromosome labels and keeps every source with its offspring cluster.
- **Result:** false positive rates at alpha 0.05 of 0.040-0.065, and at alpha 0.01 of 0-0.025; median O/E 1.00 in
  every scenario.
- **Why the permutation null matters on real data:** it also controls for chromosomes rich in both sources and new
  copies.

## Bugs and design failures found by the benchmarks (fixed)
- **Genotype quality as the presence/absence criterion.** Absence recall was 0.21 at 18x ONT because the depth term
  makes GQ low wherever dosage is uncertain. Fixed: allele-presence posteriors and a `pav` call.
- **Two-parent test without a null model.** Fixed: exact scan test with Bonferroni over pairs (section 2b).
- **Python set order** leaked into depth sampling: genotypes differed between runs at borderline sites. Fixed by
  sorting; now tested across hash seeds.
- **Two-parent test false positives.** A pair of unrelated candidates could "explain" a copy segment by segment
  using only their own private mutations. Fixed: a mosaic must explain >= 3 more differences than the best single
  candidate. Tested.
- **Nested elements paired with their own host.** An outer element's internal region contains the inner element:
  252 of 314 same-chromosome pairs on real data at <= 0.2%. Fixed: inner elements are excised from internal regions,
  and host or overlap pairs are excluded. A regression test fails without the fix.

## Known issue (open, v0.1)
- **One-sided full reads need an aligned base 100 bp past the LTR.** This rule was added after the simulated-reads
  benchmark, to stop reads that cross a hemizygous deletion from counting as full. On real *P. supina* HiFi it also
  drops genuine reads at alleles with an internal deletion of >= 50 bp just past the LTR.
- **Effect.** 5 of 1,195 haplotag-truth elements flipped from F/F to F/N, with carrying reads 65 -> 29 and 74 -> 41.
  - F/F precision 0.984 -> 0.986; recall 0.50 -> 0.48;
  - F/N precision 0.85 -> 0.80;
  - the conservative direction for source assignment.
- **Proposed fix (not yet run).** Require the junction base and the LTR end to be aligned (not inside a deletion of
  >= 50 bp), instead of the base 100 bp into the internal region. This excludes reads whose alignment crosses a
  deletion covering the junction (the hemizygous case) and keeps reads with small internal-deletion alleles.
  Rerun both the simulated and the haplotag benchmarks after the change.
