# Task 13 report: exact junction refinement (`junction.py`)

Status: DONE_WITH_CONCERNS. Commit `78e236f Add exact junction refinement` (branch plan1-engine, no trailers).

## What I implemented

`src/ltrpav/junction.py`: `refine_gap(a_seq, b_seq, gap, pad=REFINE_PAD) -> Gap`.

- **Windows.** R4 midpoint split when `a1 - a0 < 2*pad`, otherwise the brief's `Al`/`Ar`; `Bj = b[b0-pad : b1+pad]`; all clipped to the sequences.
  - Returns `gap` itself (the same object) when `b1 - b0 > 2*pad`.
  - Raises `ValueError` on a gap outside the sequences, on reversed edges, or on `pad < 1`.
- **The two DPs.** `_part` is one numba `@njit(cache=True)` Gotoh DP with rolling rows.
  - Global at the start. It returns, per column j, `max_i H[i][j]` over any final state (the brief's `Fbest`) and the `i` behind it.
  - The right part runs on reversed strings, so it is global at the end; ties there take the smallest k.
  - Scoring follows `SCORE`: a gap of n bases costs 6+2n. N, and any non-identical pair, is a mismatch. Lowercase counts as uppercase.
- **Combine.** `_split` (numba) gives the same result as the brief's combine over all j1 <= j2, junction penalty 0 or 6+2(j2-j1), but in O(n). For each j2 only two j1 can win: j2 itself, or the best earlier j1 kept as a running maximum.
- **Slide.** `_slide` gives the largest k with `a[a0+t] == a[a1+t]` (ignoring case) for all t < k, up to the sequence end.
  - Computed only when b0 == b1 and a1 > a0.
  - The a1 > a0 guard matters: an empty "deletion" would otherwise slide to the end of the sequence.
- **`Gap`.** New field `slide: int = 0` in `localign.Gap`, with a docstring. Existing constructors and equality tests are unchanged.

## Deviation 1: one added tie rule, needed for the brief's own `test_filler`

Tie order used: **fewest gaps opened inside the two parts**, then the brief's smallest j2-j1, then smallest i, then smallest k (then smallest j1, for determinism).

**Why the literal brief cannot work.** `Fbest[j] = max_i F[i][j]` includes paths that end in a B-only gap. So for any j1 < j2:

    Fbest[j2] >= Fbest[j1] - (6 + 2(j2-j1))

That is, the junction insertion always ties with the same bases taken as a terminal gap inside F. "Smallest j2-j1" then always picks the hidden version, so **b1 > b0 can never be returned**, for any filler.

B-only sequence next to B's TSD copy also ties with a flank gap beside A's other TSD copy, and is hidden the same way.

A pure-Python prototype of the literal brief (scratch `proto_literal.py`, seed 1):

    GATTACA  -> A gap 5003 (element+10 = 5010), B gap 0
    GGGGGGG  -> A gap 5010, B gap 0                  (filler hidden in a flank)
    T+N100   -> A gap 5005, B gap 0                  (toy "G" case: looks exactly like an empty site E)

**The fix.** Every DP score is multiplied by `w = len(al)+len(ar)+2*len(bj)+1`, and each gap opened inside a part costs one extra unit. The two parts can open at most w-1 gaps, so the extra unit only ever decides between equal scores. The junction gap does not pay it. The rule is parsimony: B-only sequence at the junction belongs to the junction event, not to an extra flank indel. It changes nothing when scores are not tied.

- Removing the extra unit fails four tests: `test_filler`, `test_perturbed_inputs`, `test_b_only_sequence_beside_tsd` and `test_dp_matches_brute_force`.
- With it, the toy G and host_G cases report the 100-N run as [b0, b1), with A losing element + TSD.

## Deviation 2: `test_filler` uses GGGGGGG, not GATTACA

GATTACA cannot give `b1 - b0 == 7` under `SCORE`. Facing the 7 A bases before R ("CA" + T = CACTCTC) it has 2 matches and 5 mismatches: 2 - 20 = -18. Inserting it scores -(6 + 2*7) = -20, so the exact optimum aligns it.

- `test_filler` now uses GGGGGGG. The element's 40 bp inside each terminal TG/CA contain no G, so no filler base can align profitably; I worked through the alternatives, and the insertion is the unique optimum.
- `test_filler` asserts `g == true gap` (b1 - b0 == 7, slide 0) over 5 seeds with edges jittered by ±40.
- GATTACA's behavior is pinned in `test_filler_that_aligns_better`: B gap 0, A gap = element + 3, and the placement with the filler fully in the right flank lies in the slide range.

## Tests (`tests/test_junction.py`, 13 tests, 0.84 s)

**Brief and controller tests:**
- `test_empty_site`: 20 seeds, jittered edges.
  - Controller's assertions: A gap = element + 5, B contiguous, `a0 <= len(L)`, `a0 + slide >= len(L) + 5`.
  - Every placement in the slide range rebuilds B exactly; the placement is leftmost and the slide maximal.
  - At least 5 seeds have chance microhomology.
- `test_flank_deletion`: exact 300+5+element+5; the true placement lies in the slide range.
- `test_filler`: see Deviation 2.
- `test_large_b_insertion_unchanged`: `is gap`; the boundary is checked at pad=50 (B gap 100 is refined, 101 is returned unchanged).
- `test_short_gap_midpoint_split`: 120-bp deletion, 5 A-edge × 4 B-edge combinations, including (x+30, x+90), where the brief's windows would skip A [x+90, x+180). Exact length, rebuilds B.
- `test_slide_microhomology`: 10 seeds with a 4-bp direct repeat.
  - The full placement set is found by brute force over A. The refined gap must equal its leftmost member, and slide = rightmost - leftmost (>= 4).
  - Seed 0 is built with no chance extension and gives slide == 4 exactly.
- `test_perturbed_inputs`: every corner of a ±40 grid on all four edges (162 refinements) gives the same exact gap for the empty site, flank deletion and filler.

**Added:**
- `test_b_only_sequence_beside_tsd`: 7- and 100-N runs after and before B's TSD, an exact Gap each time. This is the regression test for Deviation 1.
- `test_no_indel`: an empty gap in collinear sequence stays empty, slide 0.
- `test_soft_masked_input`: only the element lowercased, plus fully lowercased A or B, all give the same result. Some seeds have slides that cross the mask edge.
- `test_rejects_bad_input`.
- `test_dp_matches_brute_force`: 250 random tiny windows (alphabets AC/ACG/ACN/ACGT, so ties are common) plus 7 structured cases, against an independent reference.
  - The reference uses full-matrix Gotoh with (score, -gaps) tuples, computes the right part forward on each suffix (no reversal trick), and enumerates every (i, j1, k, j2).
  - Four of the structured cases came from a 200k-case search for column ties (several i, or several k, tie at one j and the brief's smallest-i / smallest-k rule decides the split).

**Mutation check.** The file was restored from a backup each time, with a diff-verified restore.

| mutation | tests that catch it |
|---|---|
| no extra unit per gap (literal brief ties) | filler, perturbed_inputs, b_only_beside_tsd, brute_force |
| brief's literal windows (R4 off) | short_gap_midpoint_split, no_indel |
| no empty-gap guard in slide | no_indel |
| largest j2-j1 first | brute_force |
| N matches N | brute_force |
| F column ties take the largest i / R ties take the largest k | brute_force (only after adding the searched cases) |
| case-sensitive slide | soft_masked_input (only after masking only the element) |

## TDD evidence

RED (before `junction.py` existed):

    $ mamba run -n ltrpav pytest tests/test_junction.py -q
    E   ModuleNotFoundError: No module named 'ltrpav.junction'
    !!!!!!!!!!!!!!!!!!!! Interrupted: 1 error during collection !!!!!!!!!!!!!!!!!!!!

GREEN (final state, committed):

    $ mamba run -n ltrpav pytest tests/test_junction.py -W error
    13 passed in 0.84s
    $ mamba run -n ltrpav pytest -W error
    192 passed in 19.98s          (179 before + 13 new; no warnings, numba cache=True included)
    $ mamba run -n ltrpav ruff check src tests
    All checks passed!

## Timing (scratch `timing.py`, 500 refinements each, ±40 bp jitter, one core)

| pad | A windows | case | refinements/s | ms each |
|---|---|---|---|---|
| 150 (default) | 300 bp | pure deletion | 1782 | 0.56 |
| 150 | 300 bp | 220-bp B gap | 859 | 1.16 |
| 300 | 600 bp | pure deletion | 484 | 2.06 |
| 300 | 600 bp | 520-bp B gap | 209 | 4.78 |

The cost is the full DP over each window pair. Restricting the DP to a band around the known diagonal would speed it up if it is ever needed.

## End-to-end on the toy cases (mappy `align_window`, then `gap_around`, then `refine_gap`; scratch `toy_refine*.py`)

| case | refined A gap / B gap / slide | note |
|---|---|---|
| E, E_mm1, E_mm2, G_far | 4805 / 0 / 5 | element + TSD, both TSD copies in range |
| D_left / D_both | 5310 / 0, 5510 / 0 | exact |
| S / S_notsd / T | 4400 (slide 400) / 4405 / 2400 | |
| O | unchanged (B gap 1998) | |
| G, host_G | A loses element + T2, B gap = the 100 N | needs Deviation 1 |
| nested_E (child) | 3005, slide 7 | child + GAGAG; range covers both copies + 2 chance bp |
| host_E / host_S / adjacent_E | 7815 / 7410 (slide 400) / 9610 | exact |
| **G_near** | A gap 4857, B gap 0 | see concern 2 |

## Files changed

- `src/ltrpav/junction.py` (new)
- `src/ltrpav/localign.py` (`Gap.slide` field and docstring)
- `tests/test_junction.py` (new)

## Self-review findings (all fixed before the commit)

- The two column-tie mutations and the case-sensitive-slide mutation first survived. I added the searched tie cases and made the soft-mask test mask only the element; both are now caught.
- Lines over 110 characters, and a lambda-based check, in the tests: rewritten. Ruff's default rules do not flag line length; I checked it with awk.
- `_split`'s O(n) combine is checked against the brute-force reference, not only by reasoning.

## Concerns

1. **Deviation 1 (tie rule) needs your sign-off.** It is the minimal change I found that makes `test_filler` achievable and keeps N runs and fillers visible in [b0, b1). Without it, the toy G case looks exactly like an empty site (E).
2. **N runs near the junction are absorbed by the free deletion** (inherent to "treat N as a mismatch" plus a free A deletion).
   - An N run of 4 or more bases within the window costs 4 per base as mismatches, but 6 + 2 per base as B-only sequence, while the A bases opposite it go into the free deletion.
   - G_near (B = L[:-70] + N50 + L[-20:] + T + R) therefore refines to an A gap of element + TSD + 52 bp of left flank, B gap 0. This scores 93 against 50 for the expected split; I checked with the brute-force reference.
   - Task 14 should check B for N within about `pad` of the junction before calling D.
   - More generally, unalignable flank sequence (over ~60% mismatches) next to the junction is treated as part of the gap.
3. **Short-filler B gaps are score-optimal, not the true event.** Fillers of fewer than ~8 bp with 2+ chance matches get aligned (GATTACA). A chance-matching base just past an inserted run can also keep the insertion inside a flank alignment, when that scores strictly higher. Task 14 should not read b1 - b0 as the exact filler length.
4. **"Leftmost" means leftmost within the refinement windows.** If identical repeats at the deletion ends reach more than `pad` beyond the local aligner's edges, the DP cannot see further left. The slide still runs right to the sequence end. Task 12 measured mappy reporting the leftmost placement, so I don't expect this. A short sequence-level left shift would remove the limit; I did not add it because it was not specified.
5. **Slide's B coordinates assume a diagonal alignment.** The placements (b0 + t) assume B continues gap-free beyond the junction, as in your definition (standard sequence-based indel normalization).

Scratch evidence in /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/: `proto_literal.py`, `tie_search.py`, `mutate.sh`, `timing.py`, `toy_refine.py`, `toy_refine2.py`, `gnear_debug.py`.

---

# Fix round 1 (review findings 1 and 2)

Commit `5127b57 Normalize junctions to the leftmost placement; skip refinement across N` (no trailers).

## Changes

- **Finding 1 (leftmost past the window).** After the DP, a pure deletion (y0 == y1 and x1 > x0) moves left one base at a time, all four coordinates together. It keeps moving while x0 > 0, y0 > 0 and `a[x0-1] == a[x1-1]` (ignoring case). Only then is the slide computed, so the range is [leftmost, rightmost] on the whole sequence.
  - Docstrings corrected: `refine_gap`, the module docstring, and `Gap.slide` in localign.py. `Gap.slide` now states the left-normalized property: the base before a0 differs from the base before a1.
  - A gap with B-only sequence, or no indel at all, returns as before, with slide 0.
- **Finding 2 (ruling).** `refine_gap` returns the input gap itself when the clipped window Bj = B[b0 - pad, b1 + pad) holds an N or n. The check runs after the large-B-insertion check and before the DP, and the rule is stated in both docstrings.

## Tests (`tests/test_junction.py`: 15 tests)

- **New `test_long_repeat_left_normalized`.** Three solo LTRs (400-bp LTRs, longer than pad) and one tandem array (7-bp unit × 100, one unit deleted). In each, the brute-force placement range is longer than 2*pad. Every input must return want = (leftmost, slide = rightmost - leftmost). The inputs:
  - the rightmost placement;
  - a moved rightmost: the reviewer's off-diagonal Gap(r-40, r+n+30, r-20, r-20) for the solo LTRs, and ±40 along both diagonals for the array (see new observation 1);
  - the mid-range placement.
- **New `test_n_in_b_window_returns_input`.**
  - Returned as the same object: the G_near-like N50 (both cases), N100 at the junction, and a single N at either end of Bj.
  - Refined normally (A gap = e+5, B contiguous): a single N just outside either end, and an N run 500 bp away.
- **Rewritten `test_b_only_sequence_beside_tsd`.** Its N-run fillers now fall under the N rule, so it uses real-base fillers that cannot align, over 3 seeds:
  - AAAAAAA after the TSD, with A kept out of the element ends;
  - GGGGGGG before the TSD, with G kept out.

  It remains the regression test for the parsimony tie rule.

**Mutation check** (file restored after each):

| mutation | tests that catch it |
|---|---|
| no left normalization | long_repeat_left_normalized |
| no N rule; uppercase N only; N looked for in [b0, b1) only | n_in_b_window_returns_input (all three) |
| no parsimony unit | filler, perturbed_inputs, b_only_sequence_beside_tsd, dp_matches_brute_force |

**Reviewer probes after the fix:**
- probe1 section 2: all three inputs (leftmost, rightmost, rightmost-40) return [2005, 2409] with slide 404 (seed 0; seeds 1-2 likewise). Before the fix, the rightmost input gave a0 2259, slide 150.
- probe4: N50 at -70 now returns the input gap. Before, A grew by 53-62 bp.

**Toy cases end to end:** G, G_near and host_G now return the mappy gap unchanged. Every other case is identical to the table above.

## Commands and output

    $ mamba run -n ltrpav pytest tests/test_junction.py -W error
    15 passed in 0.78s
    $ mamba run -n ltrpav pytest -W error
    194 passed in 19.08s
    $ mamba run -n ltrpav ruff check src tests
    All checks passed!

## Status of the first report's concerns

- Concern 2 (N absorbed by the free deletion): handled by the ruling.
- Concern 4 (leftmost only within the windows): resolved by Finding 1.
- Concerns 1, 3 and 5 stand.

## New observations (not fixed; for the final review)

1. **Off-diagonal window starts inside periodic sequence.** Suppose a0 - b0 (or a1 - b1) sits off the flank's true diagonal by an offset that is not a multiple of the period. The left part is global at the start, so it can realign by whole periods, and the free deletion absorbs the remaining offset.
   - Tandem array, input Gap(r-40, r+n+30, r-20, r-20): an offset of 20 or 21 gives a 28-bp deletion (the true one is 7). An offset of 1 is correct.
   - In non-periodic sequence the forced start gap is a constant and harmless; the solo-LTR cases pass with the same input.
   - The local aligner's run ends sit on the diagonal, so pipeline inputs should be unaffected.
   - Same mechanism as the deferred asymmetric-clipping finding (probe1 section 1): window starts off the diagonal.
2. **R4 midpoint versus very short deletions.** The midpoint must fall inside the deletion's placement range.
   - For a 7-bp deletion with on-diagonal edge errors of -20/+30, m lands 1 bp past the range. The DP then returns a placement just past it (a0 2696, against a valid range ending at 2695), with one mismatch.
   - Gaps that reach `refine_gap` from `gap_around` are at least 80 bp (MIN_SEG). For those, the two edge errors would have to differ by about 40 bp before this happens.

Scratch: `tandem_diag.py` in the scratchpad directory above.
