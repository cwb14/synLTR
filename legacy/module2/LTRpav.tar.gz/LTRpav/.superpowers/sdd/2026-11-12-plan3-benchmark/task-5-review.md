# Task 5 review: `ltrpav-sim pop`, orchestration, outputs and command line

Range 239eb8f..78abe50 (0a99f40 donors move; 78abe50 pop). Read-only review. Scratch:
`/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t5review/`
(written `$R` below). Env `ltrpav` (nothing installed), `NUMPY_MADVISE_HUGEPAGE=0`, at most 4 processes per probe,
every probe under `timeout 15m`, detached with `setsid -f nohup` (SID = PID, PPID 1 checked).

## Spec Compliance

| | Requirement | Where | Evidence |
|---|---|---|---|
| ✅ | donors.py: `pick_donors`, `shift_element` moved verbatim, `MAX_DONORS`; pair imports them | donors.py:22-58; cli.py:21, :213-215 | diff is a pure move; `ltrpav-sim pair` byte-identical (below) |
| ✅ | `backbone_elements(elements, seqid, start, end)`: wholly inside, shifted, 0-based half-open, crossing excluded, parents kept | donors.py:61-82 | test_pop_edge_element_excluded (tests/test_pop_cli.py:291-312) pins names, coords, LTRs, strand, parent, a 20,000 shift |
| ✅ | Streams: donors [seed, 0]; chromosome c [seed, c] (ancestry seed first draw, then draw_events, build_chrom); gaps [seed, 100, g]; annotation [seed, 200, g]; stated in the docstring | pop.py:13-21, :220-223, :339, :351-352; donors.py:40 | test_pop_streams (:232-274) rebuilds every stage from the raw functions and compares sequences, gaps, Copy records, annotations, tracts |
| ✅ | No rng state crosses a process; results independent of threads and completion order | pop.py:208-214 (initargs: seed int only), :239-270 (dict by c, returned in job order) | `$R/probe`: 5 separate CLI processes, threads 1/3/3 at PYTHONHASHSEED 0/12345/777, and a second config at threads 1/3: all 55 files byte-identical within each config |
| ✅ | R4: c to draw_events, c - 1 to build_chrom | pop.py:222-223 | test_pop_streams; iids `i01...`, `i02...` in insertions.tsv |
| ✅ | R4: backbone eids unique across chromosomes, asserted | pop.py:306-314 (before simulating), :404-406 (at join) | names are source spans `seqid:start-end` (donors.py:73) |
| ✅ | R1: Copy.chrom == index into seqs/seqids, asserted once at join | pop.py:387-411 (:401-403) | probe genomes load; insertion_rows' own chrom check passes |
| ✅ | Donors once, whole annotation, Plan 1 stream | pop.py:295-296 | test_pop_streams compares against `pick_donors(all, fa, seed)` |
| ✅ | Outputs: `<label>.fa`, A/B/C `.gff3`, samples.tsv (relative paths, O1 `.`/outgroup), truth/X__Y for every annotated X and other Y, insertions.tsv, tracts BEDs, fractions.tsv, params.json | pop.py:432-463 | test_pop_writes_outputs (:133-201) pins the exact file set (36 truth files) and read_samples; probe file lists match |
| ✅ | insertions.tsv = INSERTION_COLUMNS + fate per sample, rows as insertion_rows gives them (R4) | pop.py:366, :452-454 | header checked in test and in `$R/probe/a_t1/truth/insertions.tsv` |
| ✅ | Tract BEDs for the recipient taxon; fractions for every sample | pop.py:356-365, :383, :455-460 | C>A (A1, A2), A>C (C1 only), C>A1 (A1 tracts, A2 empty) checked by hand in `$R/probe/b_t1`, `$R/cli/ac` |
| ✅ | params.json: seed, PopParams, regions, FASTA and annotation path+sha256, ltrpav/msprime/tskit versions, trees per chromosome, events requested/realized/dropped (Task 2's six counters + gap_off_chromosome, totals with per-chromosome and per-genome detail), truth counts, simplifications | pop.py:323-330, :334-349, :367-379, :461-463 | test asserts totals = sums of details and requested = realized + dropped; I read `$R/probe/b_t1/params.json` |
| ⚠️ | "realized" = "what the genomes hold" | pop.py:28-29 vs :227-229 | indel deletions popbuild never applies are counted as realized: Minor m1 |
| ✅ | R1: four named simplifications, one line each | pop.py:74-79 | wording matches the ruling |
| ⚠️ | R2: the parent never holds a second copy of a genome's sequence | pop.py:338-339, :396-410, :417-423 | holds between calls; inside Task 3's add_gaps, one genome is transiently held 3 times: Minor m2 |
| ✅ | R2: peak RSS of a 20-Mb, 7-genome run reported | report; `p3t5/rss/t2.err` | log confirms 5:38.46, max RSS 837,172 kB, exit 0; PSS peak 1,659 MB |
| ✅ | CLI: `--demography` JSON, flags override it, Demog re-checks | cli.py:233-245 | test_pop_demography_json (`--f`); `$R/cli/ac`: JSON pulse C>A, f 0.1, ta 3000, per_taxon 2, bottleneck null overridden by `--pulse A>C --bottleneck 2000,500 --per-taxon 1 --f 0.5 --ta 1000` |
| ✅ | Fail fast: overlap, too-short region, dropout-genome outgroup/unknown/>= 1, missing msprime; one `error:` line, exit 1; usage exit 2 | pop.py:163-182, :299-305, :103-125, :185-192; cli.py:163-185 | tests :315-367; by hand: unknown JSON key, unknown seqid, region outside a sequence, `C1>A1` without sub_c, duplicate label, missing JSON: exit 1, one line; `--threads 0`, `--dropout 1`: exit 2. No outdir on any failure |
| ✅ | MSPRIME_HELP | pop.py:284 | test_pop_without_msprime (:352-367): stderr is exactly `error: <MSPRIME_HELP>` |
| ✅ | Plan 1 `pair` byte-identical | cli.py:206-230 | `$R/pair`: 239eb8f snapshot (PYTHONPATH, `ltrpav.__file__` confirmed) vs HEAD on toy s1:1-300000, seeds 1 and 4: 7 of 7 files identical; seeds differ from each other |
| ✅ | Brief's 9 tests + 2 added, importorskip first | tests/test_pop_cli.py:8, :133-396 | `$R/test_pop_cli.log`: 10 non-slow passed, exit 0; slow test's log (`p3t5/slow/slow.log`): 11 passed, exit 0 |
| ✅ | Slow end-to-end: pop -> genotype (8 threads) -> merge -> stats --trio -> score, P and E rows with tp > 0 | :371-396 | run once by the implementer (constraint: a slow test runs once); not rerun |
| ✅ | DESIGN 10.2 paragraph; `__init__` exports | DESIGN.md:577-589; sim/__init__.py:6-12 | read |
| ✅ | Global constraints: engine untouched, author cwb14, no trailers, ruff clean, inputs untouched | `git diff --stat` (sim/, tests/, DESIGN only) | `ruff check .` passes; `inputs/*.fai` mtimes Nov 6-7; no file in inputs/ or run/ newer than the brief |

## Strengths

1. **The stream contract is written once and tested exactly.** pop.py:13-21 states every stream. test_pop_streams
   (tests/test_pop_cli.py:232-274) rebuilds each chromosome from `[seed, c]` with the raw ancestry, draw_events and
   build_chrom calls, then gaps and annotations from their streams. It compares sequences, gaps, every Copy, every
   annotation and the tracts. With 1,000 gaps per Mb and regions that end on an element, it also drives
   gap_off_chromosome above 0 and checks it per genome.
2. **Determinism holds across processes.** test_pop_deterministic runs both thread counts in one interpreter, so it
   shares one string-hash seed. I ran separate processes instead (`$R/scripts/probe.sh`):
   - config a (C>A, f 0.2): threads 1, 3 and 3, at PYTHONHASHSEED 0, 12345 and 777;
   - config b (C>A1 with sub_a, a bottleneck, `--dropout-genome A2=0.3 C1=0`): threads 1 and 3.
   All 55 files are byte-identical within each config, and the two configs differ.
3. **Results are collected by chromosome, not by completion.** `done` stores `out[r.c]`; the return is in job order
   (pop.py:239-270). The implementer's B73 log shows c02 finishing before c01, with identical outputs claimed and
   my toy probe confirming the mechanism.
4. **Contracts are asserted where they can break.** R4's unique names fail before any simulation (pop.py:306-314),
   and the join re-checks Copy.chrom and id disjointness (pop.py:401-406). Every fail-fast check runs before the
   first INFO line, and no outdir is created on failure.
5. **Accounting is internally consistent and tested.** Totals are the sums of the details, and requested = realized
   + dropped for insertions, losses, SNPs and gaps (tests/test_pop_cli.py:173-187). Truth counts in params.json equal
   the files' (:188-193).
6. **Memory discipline in the parent.** _join moves each sample's bytes out of the worker result
   (pop.py:399-400). add_gaps is called one genome at a time with that genome's stream (pop.py:338-339). FASTA goes
   out in 1-Mb blocks (pop.py:417-423), and the annotation's Element list is freed before the fork (pop.py:316).
7. **Plan 1 is preserved.** The move is verbatim. I confirmed pair's byte identity on the toy at two seeds against a
   239eb8f snapshot, and the full suite passes.

## Issues

### Critical
None.

### Important
None.

### Minor

**m1. "Realized" indels include deletions that never happen.**
- pop.py:227-229 counts every drawn indel as realized: `"indels": len(ev.indel_pos)` and `indel_deletions`.
- popbuild's indel_skip (popbuild.py:410; rule at :19-24) drops a deletion on every carrier when an older removal
  covers it. Such a deletion is in no genome.
- The docstring defines realized as "what the genomes hold" (pop.py:28-29), and the invariant requested =
  realized + dropped hides the gap.
- Measured on probe a (`$R/scripts/indel_skip.py`): 172 of 1,645, 116 of 1,581 and 142 of 1,053 deletions on
  c01-c03, so about 10% of realized deletions are not in any genome.
- No truth or sequence is affected; only the reported counter is.
- Fix, either:
  - report the skipped count (it needs build_chrom or `_Chrom` to expose `len(indel_skip)`); or
  - define indels as drawn in the docstring and name popbuild's skip rule there.

**m2. add_gaps transiently triples one genome in the parent (R2's "never a second copy").**
- add_gaps (Task 3, popbuild.py:932, :948) builds `bufs` (a second copy). Its list comprehension then builds new
  bytes (a third copy) before `g.seqs` is rebound.
- pop.py bounds this to one genome by calling add_gaps per genome (:338-339), and the implementer named it
  (report concern 3).
- On a 10 x 10-Mb grid genome of about 200 Mb, this is about 400 MB of extra memory for a moment, far inside the
  budget.
- pop.py's docstring (:22-24) says the parent "keeps one copy of each genome's sequence". Qualify it.
- If R2 is meant literally, convert per chromosome inside add_gaps (`g.seqs[ch] = bytes(buf)`, freeing each
  buffer). That is a popbuild change, outside Task 5's file list, so it belongs in the ledger.

**m3. The streams stay apart only because MAX_CHROMS < 100, and seeds of 2^32 or more can alias.**
- numpy's SeedSequence zero-pads entropy shorter than its 4-word pool. I verified in env ltrpav (numpy 2.5.4)
  that `[s, 100, 0]` gives the same stream as `[s, 100]`.
- So chromosome 100 would reuse genome 0's gap stream, and chromosome 200 its annotation stream.
- MAX_CHROMS = 99 (pop.py:72) prevents this today, but its comment justifies it only by the iid digits. Raising
  it for a fragmented assembly would silently correlate streams.
- An integer seed of 2^32 or more becomes two words. With s = x + 100·2^32, `[s, c]` gives the same stream as
  `[x, 100, c]`, so runs with different seeds can share streams.
- `_seed` accepts any n >= 0 (cli.py:119-126; Plan 1 has the same convention). The grid uses small seeds, so
  nothing is affected now.
- Fix:
  - add a comment, or an assert, tying MAX_CHROMS < 100 to the stream layout;
  - bound seeds below 2^32 in `_seed` and simulate_pop.

**m4. write_pop never clears an existing outdir.**
- pop.py:438-463 writes files into the outdir as it is. Rerunning into the same directory with fewer genomes, or
  a pulse into another taxon, leaves stale `truth/X__Y.tsv` and `truth/tracts.*.bed` files.
- Task 8's scorer would pick those up if it globs.
- The implementer flagged this for Task 8.
- Fix, either:
  - refuse a non-empty outdir;
  - remove `truth/` before writing; or
  - make Task 8 always use fresh directories, and say so in its memo.

**m5. Some outputs and overrides are untested.**
- fractions.tsv's `fraction` (tract_bp / backbone_bp, pop.py:364) is never checked. A mutant dividing by genome
  length would survive (tests/test_pop_cli.py:195-201).
- `--pulse`, `--bottleneck` and `--per-taxon` overriding a JSON value are not tested; only `--f` is (:213-229). I
  checked them by hand (`$R/cli/ac`).
- No count is pinned, although some are known by construction: the module run's per-chromosome backbone counts
  in params.json, and A2's empty tract file under C>A1.

**m6. test_pop_deterministic cannot see hash-seed dependence.** Both runs share one interpreter (:204-210). My
cross-process probe found no such dependence. Optionally, run the threads-2 side in a subprocess with a different
PYTHONHASHSEED, so the grid's real situation (separate processes) is what the test pins.

Not issues, noted for the record:
- Report concern 1 (simulated insertions roughly double each genome) is Task 6/7 calibration, not a Task 5 defect.
- On real input, pick_donors may log a WARNING before a later fail-fast error. There is still exactly one
  `error:` line.

## Assessment

**Approved.**
- Spec: met. Two items are partial (⚠️): m1, the realized indel counter, and m2, add_gaps' transient copies in Task
  3 code. Neither affects truth, sequence or determinism.
- Quality: Approved. 0 Critical, 0 Important, 6 Minor.
- Determinism, the seed streams, the wiring contracts (c and c - 1, unique eids, Copy.chrom) and pair's byte
  identity were each verified independently.
- Suite: the implementer's detached `-m "not slow" -W error` run has finished. suite.done is 0, and suite.log shows
  1,261 passing tests with no failure, error or skip marks. `ruff check .` passes.
