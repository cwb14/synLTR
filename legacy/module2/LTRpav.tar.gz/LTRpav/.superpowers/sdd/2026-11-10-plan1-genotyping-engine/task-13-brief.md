### Task 13: Exact junction refinement

**Files:** Create `src/ltrpav/junction.py`, `tests/test_junction.py`

**Interfaces:**
- Consumes: `Gap`, constants `SCORE`, `REFINE_PAD`.
- Produces: `refine_gap(a_seq: str, b_seq: str, gap: Gap, pad: int = REFINE_PAD) -> Gap`. It returns the input
  unchanged when `gap.b1 - gap.b0 > 2*pad` (large B insertion: O, no boundary needed).

- [ ] **Step 1: Write the failing tests.** Use `L`, `R` = 2 kb of random sequence, element `e` (5 kb, starts "TG",
  ends "CA") and TSD `T = "CTCTC"`. Start each test from a perturbed gap (edges moved by about 40 bp). Deleted
  lengths must be exact (they are the same under any equivalent placement); positions within the stated slack.

```python
def test_empty_site():      # A = L+T+e+T+R, B = L+T+R
    g = refine_gap(a, b, perturbed)
    assert g.a1 - g.a0 == len(e) + 5 and g.b1 == g.b0 and len(L) - 5 - 3 <= g.a0 <= len(L) + 3
def test_flank_deletion():  # B = L[:-300] + R
    assert g.a1 - g.a0 == 300 + 5 + len(e) + 5 and g.b1 == g.b0
def test_filler():          # B = L + "GATTACA" + R
    assert g.b1 - g.b0 == 7
def test_large_b_insertion_unchanged(): ...
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.** This algorithm is fixed here.

```
Al = a[a0-pad : min(a1, a0+pad)]    (start aL0)      Ar = a[max(a0+pad, a1-pad) : a1+pad]  (start aR0)
Bj = b[b0-pad : b1+pad]             (start bj0)      all clipped to sequence bounds
F = Gotoh(Al, Bj) global at both starts (match +1, mismatch -4, open -6, extend -2)  -> Fbest[j] = max_i F[i][j]
R = Gotoh on reversed strings (global at both ends)                                  -> Rbest[j] = max_k R[k][j]
best = argmax over j1 <= j2 of Fbest[j1] + Rbest[j2] - (0 if j2 == j1 else 6 + 2*(j2-j1))
ties: smallest j2-j1, then smallest i, then smallest k
return Gap(aL0 + i*, aR0 + k*, bj0 + j1*, bj0 + j2*)
```

  The A sequence between the two parts is deleted at no cost (it is the element). Numba-jit both DPs.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add exact junction refinement"`.

---

