# Plan 3 drafter brief: simulation grid and real benchmark

Write the implementation plan for Plan 3 of LTRpav:
`/data2/chris/maize_introgression/LTRpav/docs/plans/2026-11-12-plan3-benchmark.md`. The plans directory is
gitignored; do not commit it.

## Read first
1. The writing-plans skill: load it with the Skill tool (`superpowers:writing-plans`). Follow its format: the
   header, Global Constraints, Review Focus, tasks with Files and Interfaces, steps with exact values, and the
   self-review.
2. The spec: `/data2/chris/maize_introgression/LTRpav/docs/DESIGN.md`. Read it all.
   - Sections 10.2-10.4 and 11, steps 4-5, define Plan 3.
   - Section 12 records the decisions so far. Its "Plan 2 outcome" names what Plan 3 must settle.
3. Format models: Plans 1 and 2, `docs/plans/2026-11-10-plan1-genotyping-engine.md` and
   `docs/plans/2026-11-11-plan2-analyses.md`. Skim them for structure and level of detail; do not copy their
   content.
4. The user's rules: `/home/chris/.claude/CLAUDE.md`. Read especially Compute, Biological Analyses, Design
   Philosophy, Testing, Memo Files and Figures.
5. Plan 2's preliminary result: `/data2/chris/maize_introgression/benchmark_pav/main3_analyses/PRELIM.md`.
   - Its numbers are being refreshed by Plan 2's final fix wave, which is running now.
   - Use it for what is known: resolution, the misses, the open gaps.

## Scope (controller rulings)
- **R1. Scope.**
  - Plan 3 is DESIGN 11 steps 4-5:
    - the simulation grid (10.2), with LTRmix run on the same simulated genomes;
    - the real benchmark (10.3 rerun at the end, and 10.4: six genomes, the *Zea* genus event, sweet orange,
      portability with EDTA calls, stability).
  - Plan 4 holds the head-to-head REPORT.md (10.5), the final figures and the packaging.
  - Plan 3 produces, per benchmark: result tables, bars evaluated as PASS or MISS, memos and dead_ends entries.
- **R2. Carry-overs from Plan 2. Each gets a task or a line in an existing one.**
  - The simulated null and the power of D_pav and of the painting: bar |Z| > 3 in at most 5% of 30 null runs.
  - Direction (7.6) accuracy, with unequal Ne between taxa (the maize bottleneck) in both the null and the
    gene-flow runs.
  - The painting's "any discovery" variant, evaluated against the default.
  - The painting's EM degeneracy. On main3 the fitted emissions sit near 0 and 1, so the posterior copies each
    informative insertion's class, and no tract reaches q <= 0.05. Test a decoy-anchored emission model on the
    simulations.
    - It is adopted only if it improves calibration or power on simulations with known truth.
    - It is never judged by main3's outcome.
  - The six-genome controls: positive control PT; negative control {TIL11, TIL01; TIL18}; TIL25 as donor; direction
    mexicana <-> maize, reported with its simulated power.
  - Decision 11 (C3: the four-point fallback narrowing of DESIGN 7.1) awaits the user's confirmation. Plan 3 runs
    the default and reports where the fallback would matter. It does not change the rule.
  - Plan 2's open science questions: the split s gap (0.074% vs LTRmix 0.048%) and the D_pav vs D_ins gap
    (+0.29 vs +0.19). Plan 3's simulations, with known truth, can test candidate causes. Add a task only if it is
    cheap; otherwise list each as a Plan 4 lead.
- **R3. Commands.** Benchmark loops use `ltrpav-genotype` + `ltrpav-merge`, then `ltrpav-stats` and `ltrpav-paint`.
  `ltrpav run` now runs the analyses itself and exits 3 when they fail, so do not use it in the loops. Check these
  commands' current `--help` in the env `ltrpav`.
- **R4. Simulator.**
  - Extend Plan 1's simulator (`src/ltrpav/sim/`, command `ltrpav-sim`) to the population level DESIGN 10.2
    describes:
    - msprime genealogies with admixture, with LTRmix's demography as the default;
    - unequal Ne;
    - 2 genomes per taxon for direction;
    - LTR-RT insertions from real families on a real chromosome backbone;
    - solo LTRs, deletions and assembly gaps;
    - annotation dropout and boundary jitter;
    - a few runs annotated by LTRquest itself.
  - First read what the simulator already does, and what LTRmix's simulator does
    (`/data2/chris/maize_introgression/LTRmix/benchmark/sim/`). Reuse designs; keep LTRpav standalone.
  - New dependencies (msprime, for example) go into the env `ltrpav` and environment.yml. The lock file is refreshed
    by commit 84c8088's portable procedure.
- **R5. LTRmix on the same simulations.**
  - Plan how LTRmix runs on LTRpav's simulated genomes: its inputs (annotations or library), its commands and their
    cost.
  - LTRmix is at `/data2/chris/maize_introgression/LTRmix` and is read-only. Run it from its own environment, with
    outputs under `benchmark_pav/`.
- **R6. Inputs and provenance.**
  - List every real input (FASTA, annotation, truth) with its path and provenance. Look in
    `/data2/chris/maize_introgression/inputs/`, `run/`, `benchmark/`, `benchmark_data/` and LTRmix's
    `benchmark/{genus,lineage2,results,edta,ltrquest_pipeline}`.
  - A missing LTRquest annotation is produced with the latest LTRquest from GitHub, in a pinned env
    `ltrquest_<commit>`. Keep the `*.work` directories (user memory).
  - Name which genomes are annotated and which are genotype-only.
- **R7. Compute budget.**
  - The lab server allows 32 threads for a big job, plus 16 for probes.
  - Measured rates:
    - main3, 4 genomes: 9 directed pairs in 2 h 11 min at 32 threads, peak 19.6 GiB;
    - analyses on main3: stats 26 s; identity about 105 pairs/s at 16 threads; paint 22 s.
  - Estimate every job's cost from these rates and from a timing probe of the simulator. The probe is at most 15 min
    and 16 threads, in your scratch.
  - Give the plan's total wall time.
  - If the full DESIGN 10.2 grid exceeds about 4 days of wall time, propose a principled reduction and say why: for
    example, chromosome-scale backbones instead of whole genomes, or fewer admixture times. Never use fewer than
    DESIGN's 30 null replicates.
  - Every long job is detached (`setsid -f nohup ... < /dev/null`), with its PID verified, a done/exit marker and a
    memo.
- **R8. Science.**
  - Bars are DESIGN's. Misses are reported and investigated, never tuned away (DESIGN 10; CLAUDE.md Design
    Philosophy).
  - Thresholds come from principle.
  - Truth is used only to score.
- **R9. Code placement.**
  - Package code goes in `src/` with pytest tests on small synthetic fixtures.
  - Benchmark-specific scoring (maize, citrus) lives in `benchmark_pav/`, never in `src/`. Plan 2's Global
    Constraint: nothing in `src/` names Zea, maize or chromosome names.
  - Engine modules change only for a defect a benchmark finds. Such a change gets its own task and review, because
    an engine change invalidates genotyping keys.
- **R10. Interfaces in flux.** Plan 2's final fix wave is running. It adds sentinel rows to stats.tsv, moves shared
  analysis helpers into a public module, and changes the inversion grouping. Reference CLI commands and stats.tsv
  row names, not private functions.

## Process
- Investigate as needed: read code, run `--help`, run timing probes. Run no long job; at most 16 threads and 15 min
  per probe. Scratch goes only under
  `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/plan3draft/`.
- Read-only: main3/, inputs/, run/, benchmark/, LTRmix/, and `src/` (the fix wave is editing it).
- No subagents.
- The plan is written for an engineer who has not seen this codebase. Give exact values and decisions; avoid
  transcripts of code.
- Self-review per the skill. Then write a one-page summary next to the plan, `plan3-draft-summary.md` in the same
  directory as this brief, holding:
  - the task list;
  - the compute estimate;
  - each call you made where DESIGN was silent, one line each with its reason;
  - the questions only the user can answer. There should be none or few; the user is away, so make a call and mark
    it.

Return only:
- the plan path;
- the task count;
- the total wall-time estimate;
- the number of calls made;
- any blocker.
