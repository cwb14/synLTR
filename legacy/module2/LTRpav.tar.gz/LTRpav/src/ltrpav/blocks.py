"""Alignment blocks: PAF -> compact numpy structured array (0-based half-open)."""

from __future__ import annotations

import gzip
import logging
import re
import sys
from pathlib import Path

import numpy as np

from .constants import RECORD_WARNINGS, SPLIT_INDEL

log = logging.getLogger("ltrpav.blocks")

BATCH_LINES = 1_000_000  # lines parsed per structured-array batch
CIGAR_OPS = "MIDNSHP=X"  # SAM CIGAR op codes 0-8 (mappy reports ops by code)
_CIGAR = re.compile(r"(\d+)([MIDNSHP=X])")
_CIGAR_FULL = re.compile(r"(?:\d+[MIDNSHP=X])+")
_INDEL = re.compile(r"(\d+)[IDN]")
_Q_OPS = frozenset((0, 1, 7, 8))  # M, I, =, X consume the query
_R_OPS = frozenset((0, 2, 3, 7, 8))  # M, D, N, =, X consume the reference

BLOCK_DTYPE = np.dtype([
    ("a_chrom", "i4"), ("a_start", "i8"), ("a_end", "i8"),
    ("b_chrom", "i4"), ("b_start", "i8"), ("b_end", "i8"),
    ("strand", "i1"), ("matches", "i4"), ("alen", "i4"),
    ("chain", "i4"), ("chain_score", "f8"), ("margin", "f4"),
])  # chain=-1, margin=nan until set

_ROW = [("a_chrom", "i4"), ("a_start", "i8"), ("a_end", "i8"), ("b_chrom", "i4"),
        ("b_start", "i8"), ("b_end", "i8"), ("strand", "i1"), ("matches", "i4"), ("alen", "i4")]


def blocks_from_rows(rows: list[tuple]) -> np.ndarray:
    """Blocks from (a_chrom, a_start, a_end, b_chrom, b_start, b_end, strand, matches, alen) tuples."""
    tmp = np.array(rows, dtype=_ROW)
    out = np.zeros(len(tmp), dtype=BLOCK_DTYPE)
    for name, _ in _ROW:
        out[name] = tmp[name]
    out["chain"] = -1
    out["margin"] = np.nan
    return out


def read_paf(path: Path, a_index: dict[str, int], b_index: dict[str, int],
             swap: bool = False, split_indel: int = SPLIT_INDEL) -> np.ndarray:
    """Read a PAF (plain or .gz) into blocks. A = query, B = target (swapped if `swap`).

    A record carrying a cg:Z: CIGAR is split at its I/D ops of >= split_indel bp into sub-blocks with exact
    coordinates on both genomes (`split_cigar`, strand-aware), so a long indel lies between blocks, never
    inside one. A sub-block's matches are its '=' columns when the CIGAR uses =/X, else the record's matches
    prorated by sub-block alen (its aligned and shorter-indel columns). A record without a CIGAR, or without
    an indel that long, stays one block with the record's matches and alignment length; so does a record whose
    CIGAR is malformed or disagrees with its coordinates, counted in one warning. Lines starting with '#' or
    blank are skipped; a record with < 12 fields, or with coordinates or counts that are not integers or spans
    that are empty, is malformed: skipped, with a warning naming the file and line for the first
    RECORD_WARNINGS and a count in one warning. Records with a seqid missing from its index are skipped and
    counted in one warning.
    """
    path = Path(path)
    opener = gzip.open if path.suffix == ".gz" else open
    qi, ti = (b_index, a_index) if swap else (a_index, b_index)
    parts: list[np.ndarray] = []
    rows: list[tuple] = []
    skipped = bad_cigar = malformed = 0
    with opener(path, "rt") as fh:
        for n, line in enumerate(fh, 1):
            if line.startswith("#") or not line.strip():
                continue
            f = line.rstrip("\r\n").split("\t")
            try:
                if len(f) < 12:
                    raise ValueError(f"{len(f)} fields, PAF has 12")
                qs, qe, ts, te, nm, al = (int(f[i]) for i in (2, 3, 7, 8, 9, 10))
                if not (0 <= qs < qe and 0 <= ts < te):
                    raise ValueError(f"empty or negative span: query {qs}-{qe}, target {ts}-{te}")
            except ValueError as exc:
                malformed += 1
                if malformed <= RECORD_WARNINGS:
                    log.warning("%s:%d: PAF record skipped, malformed: %s", path, n, exc)
                continue
            q, t = qi.get(f[0]), ti.get(f[5])
            if q is None or t is None:
                skipped += 1
                continue
            strand = 1 if f[4] == "+" else -1
            pieces = [(qs, qe, ts, te, nm, al)]
            cg = next((x for x in f[12:] if x.startswith("cg:Z:")), None)
            if cg is not None and any(int(n) >= split_indel for n in _INDEL.findall(cg)):
                try:
                    pieces = _paf_pieces(cg[5:], qs, qe, ts, te, strand, nm, split_indel)
                except ValueError:
                    bad_cigar += 1
            for q0, q1, r0, r1, m, n in pieces:
                if swap:
                    rows.append((t, r0, r1, q, q0, q1, strand, m, n))
                else:
                    rows.append((q, q0, q1, t, r0, r1, strand, m, n))
            if len(rows) >= BATCH_LINES:
                parts.append(blocks_from_rows(rows))
                rows = []
    if rows:
        parts.append(blocks_from_rows(rows))
    if malformed:
        log.warning("skipped %d malformed PAF record(s) (%s)", malformed, path)
    if skipped:
        log.warning("skipped %d PAF records with seqids not in the index (%s)", skipped, path)
    if bad_cigar:
        log.warning("kept %d PAF record(s) whole: CIGAR malformed or disagreeing with the coordinates (%s)",
                    bad_cigar, path)
    return np.concatenate(parts) if parts else np.zeros(0, dtype=BLOCK_DTYPE)


def _paf_pieces(cg: str, qs: int, qe: int, ts: int, te: int, strand: int, matches: int,
                split_indel: int) -> list[tuple[int, ...]]:
    """Sub-blocks (q0, q1, r0, r1, matches, alen) of one PAF record from its CIGAR string `cg`.

    ValueError if the CIGAR is malformed, disagrees with the record's coordinates or aligns nothing. With M
    ops the record's matches are prorated by sub-block alen (cumulative rounding keeps their total).
    """
    if not _CIGAR_FULL.fullmatch(cg):
        raise ValueError(f"malformed CIGAR {cg[:40]!r}")
    ops = [(int(n), CIGAR_OPS.index(c)) for n, c in _CIGAR.findall(cg)]
    if (sum(n for n, op in ops if op in _Q_OPS) != qe - qs
            or sum(n for n, op in ops if op in _R_OPS) != te - ts):
        raise ValueError("CIGAR disagrees with the record's coordinates")
    pieces, has_m = split_cigar(ops, qs, ts, te, strand, split_indel)
    if not pieces:
        raise ValueError("CIGAR aligns no column")
    if not has_m:
        return pieces
    total = sum(p[5] for p in pieces)
    out, cum, prev = [], 0, 0
    for q0, q1, r0, r1, _, alen in pieces:
        cum += alen
        m = round(matches * cum / total)
        out.append((q0, q1, r0, r1, m - prev, alen))
        prev = m
    return out


def split_cigar(ops, q_st: int, r_st: int, r_en: int, strand: int, split_indel: int, *,
                begin: int | None = None, stop: int | None = None) -> tuple[list[tuple[int, ...]], bool]:
    """One alignment cut at each indel (I, D or N) of >= split_indel bp, kept only on query positions
    [begin, stop): ([(q0, q1, r0, r1, eq, alen)], has_m).

    `ops` holds (length, op) pairs, op indexing CIGAR_OPS, in reference order as in SAM, PAF cg:Z: and mappy:
    on the minus strand the query runs backward, so the walk takes the ops in reverse, from r_en down, and the
    pieces come out in query order. Coordinates are forward-strand, 0-based half-open. An op crossing `begin`
    or `stop` is cut there with exact reference coordinates, and a reference-only op at a cut belongs to the
    window starting there, so the pieces of adjacent query windows abut exactly and every aligned (=/X/M)
    column is kept once (the unaligned columns of an indel shorter than split_indel stranded at a cut can be
    lost: up to split_indel - 1 per cut, never a match).
    eq counts '=' columns, alen the M, =, X and shorter-indel columns; has_m tells whether M ops hide the
    match count. S, H and P ops raise ValueError.
    """
    plus = strand > 0
    step = 1 if plus else -1
    lo = q_st if begin is None else begin
    hi = sys.maxsize if stop is None else stop
    q, r = q_st, (r_st if plus else r_en)
    q0, r0, eq, cols, has_m = q, r, 0, 0, False
    out = []
    for length, op in (ops if plus else reversed(ops)):
        if q >= hi:
            break
        if op == 7 or op == 8 or op == 0:  # =, X, M: query and reference advance
            has_m = has_m or op == 0
            if q < lo:  # the part before `begin` is not kept: a piece starts at `begin` at the earliest
                k = min(length, lo - q)
                q += k
                r += step * k
                length -= k
                q0, r0 = q, r
            n = min(length, hi - q)
            if op == 7:
                eq += n
            cols += n
            q += n
            r += step * n
        elif op == 1 or op == 2 or op == 3:  # I: query only; D, N: reference only
            big = length >= split_indel  # judged on the whole op, even when a cut falls inside it
            if op == 1:
                if q < lo:
                    k = min(length, lo - q)
                    q += k
                    length -= k
                    q0, r0 = q, r
                n = min(length, hi - q)
            elif q < lo:  # a deletion before `begin`
                r += step * length
                q0, r0 = q, r
                continue
            else:
                n = length
            if not big:
                cols += n
            elif q > q0 and r != r0:
                out.append((q0, q, min(r0, r), max(r0, r), eq, cols))
            if op == 1:
                q += n
            else:
                r += step * n
            if big:
                q0, r0, eq, cols = q, r, 0, 0
        else:
            raise ValueError(f"CIGAR op {CIGAR_OPS[op] if 0 <= op < len(CIGAR_OPS) else op} not allowed")
    if q > q0 and r != r0:
        out.append((q0, q, min(r0, r), max(r0, r), eq, cols))
    return out, has_m


def a_to_b(block: np.void, apos: int) -> int:
    """Map an A position to B by linear scaling, clamped to [b_start, b_end - 1]; a block with an empty A span
    maps every position to its first B base on its strand."""
    a0, a1 = int(block["a_start"]), int(block["a_end"])
    b0, b1 = int(block["b_start"]), int(block["b_end"])
    off = round((apos - a0) * (b1 - b0) / (a1 - a0)) if a1 > a0 else 0
    pos = b0 + off if block["strand"] > 0 else b1 - 1 - off
    return max(b0, min(b1 - 1, pos))


def swap_blocks(blocks: np.ndarray) -> np.ndarray:
    """New array with A and B roles exchanged (strand and other fields unchanged)."""
    out = blocks.copy()
    for s in ("chrom", "start", "end"):
        out[f"a_{s}"] = blocks[f"b_{s}"]
        out[f"b_{s}"] = blocks[f"a_{s}"]
    return out


def save_blocks(path: Path, blocks: np.ndarray, a_names: list[str], b_names: list[str]) -> None:
    """Write blocks and both name lists to one compressed .npz."""
    with open(path, "wb") as fh:
        np.savez_compressed(fh, blocks=blocks, a_names=np.array(a_names, dtype=np.str_),
                            b_names=np.array(b_names, dtype=np.str_))


def load_blocks(path: Path) -> tuple[np.ndarray, list[str], list[str]]:
    with np.load(path, allow_pickle=False) as z:
        return (z["blocks"].astype(BLOCK_DTYPE, copy=False),
                [str(x) for x in z["a_names"]], [str(x) for x in z["b_names"]])
