# Task 5 review: Inversions (6e1a365..f01d82c)

## Spec Compliance
- ✅ Merge rule matches the brief (fewest u+v by ascending t, u+v+gap < min(|A|,|B|), merged block is next A, INV_MIN_LOCI counted on distinct y outside discordant rows). Hand-ran "one locus moved +50 kb" (A ends before the moved row, B starts at it; u=0,v=1; n_discordant 1) and "30-locus nested re-inversion" (28 rows between + 1 trimmed = 29). Both agree with the tests. All nine cases pass.
- ✅ Dominant direction per (seq_x, seq_y) group; wholly reversed group yields no block (dom=-1, no +1 steps).
- ✅ Keys are (genome, fai index) throughout; toy catalogs give every genome chr1..chr4, so collisions are exercised implicitly. Names only in write_inversions / findings.
- ✅ INV_COLUMNS, 1-based inclusive coordinates, "lo-hi", "." for None; inside() is inclusive 1-based. No BED output in this task.
- ✅ Containment: I ran test_block_found on seeds 3 and 5 (parametrized copies, removed afterwards): pass. Probed all blocks on seeds 2, 3, 5: true breakpoints 300001 and ~700000 fall in every interval on x and y, for all three S pairs.
- ⚠️ y breakpoints deviate from "same rows' y coordinates" (uses rows bounding the y extent); controller-accepted. Reasoning checked and sound.
- ⚠️ ruff clean; tests pass under -W error.

## Strengths
- Clear docstrings; `_merge` is a faithful, readable transcription of the rule.
- Containment test is a real property (flank-width bound computed independently from the other genome's loci), not a tuned tolerance.

## Issues
### Critical
None.
### Important
- inversions.py:_block (start_y/end_y = min/max of y over all `sub` rows): displaced (discordant) rows are included, so a locus moved away (50 kb in the test case, or a transposed locus Mb away) inflates start_y/end_y. inside() on the y side, and inversions.tsv start_y/end_y, then paint non-inverted sequence and disagree with bp_left_y/bp_right_y. Fix: take the y extent from rows not marked discordant (pass the `bad` mask out of reversed_blocks, or compute on rows whose y lies within the block's flank-bounded range). No test covers y extent with a displaced locus.
### Minor
- test_block_found checks only the non-S genome's axis per pair, so for R~S the S (y) side is never asserted (my probe shows it is correct). Assert both axes.
- test_block_found right bound allows `a - 150` slack (element length) on the left side of the right interval; acceptable, but the 150 is a magic number.
- Dominant direction is by step-sum: an inversion covering > half of a group's loci flips dominant and reports the collinear remainder as the block. Inherent to the brief; worth a line in the findings text.
- tests/test_inversions.py: semicolon-packed lines (brief's style); fine.

## Assessment
Spec: compliant (with the accepted y-bound deviation).
Task quality: Needs fixes (one Important: y extent inflated by discordant rows).

## Re-review (fix 14d76e9)
- I1 (y extent inflated by discordant rows): ADDRESSED. _find returns non-discordant rows; start/end extents use them; test displaces a locus 5 Mb and checks extent and inside().
- Minor, S axis unasserted: ADDRESSED (both axes per pair; seeds 3 and 5 pass on my run of the whole file, plus seed 2).
- Minor, 150 magic number: ADDRESSED (TOY_LENGTH). Reason is right: a locus starting at or before 700000 can end up to the 150-bp element past it.
- Minor, dominant flip: ADDRESSED (InvBlock.dominant, findings line, test with 80% inversion and a negative control).
- Style: left as ruled.
- New breakage: none. `dominant` is a trailing field with default 1; the only constructor call in src passes it, the test's 15-positional-arg InvBlock still works, write_inversions does not emit it (INV_COLUMNS unchanged). ruff clean, -W error pass.
Counts: 4 ADDRESSED, 0 PARTIAL, 0 NOT ADDRESSED. Task quality: Approved.
