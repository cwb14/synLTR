import os
import subprocess
import sys


def test_import_sets_thp_guard():
    """Importing ltrpav sets NUMPY_MADVISE_HUGEPAGE=0 unless the user chose a value; checked in a fresh
    interpreter without the variable, since the test session's conftest sets it before numpy loads."""
    env = {k: v for k, v in os.environ.items() if k != "NUMPY_MADVISE_HUGEPAGE"}
    code = "import os, ltrpav; print(os.environ.get('NUMPY_MADVISE_HUGEPAGE'))"
    for value, want in ((None, "0"), ("1", "1")):
        run_env = env if value is None else {**env, "NUMPY_MADVISE_HUGEPAGE": value}
        out = subprocess.run([sys.executable, "-c", code], env=run_env, capture_output=True, text=True, check=True)
        assert out.stdout.strip() == want

