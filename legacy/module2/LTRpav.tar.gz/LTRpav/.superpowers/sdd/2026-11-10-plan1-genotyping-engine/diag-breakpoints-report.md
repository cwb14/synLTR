# Diagnostic report: why the mm2 route leaves ~45% of real chr10 elements unresolved

Date 2026-11-11. Read-only on the repo (HEAD bfeeb55) and on the bake-off outputs. Every script, table, figure and
scratch run is in `D/diag_breakpoints/` (D = `/data2/chris/maize_introgression/benchmark_pav/bakeoff`). Env
`ltrpav_bench` (`bench_tools` only to render the dotplots, because `ltrpav_bench` has no matplotlib and is not
modified). At most 4 threads, every probe in the foreground under `timeout 15m`.

## Summary

Status: DONE_WITH_CONCERNS.

**Cause: the hypothesis holds.**
- The flat net admits short paralogous chains into the A gaps of the orthologous chains. A B73-only TE region
  pairs with a TIL18-only TE copy of the same family elsewhere, because no better chain claims either side.
- Fills outside their parent's B gap make up 23.3 Mb, or 31% of the B73v5 -> TIL18 net's A bp (6,037 of 14,847
  blocks), and 26-34% in all six chr10 directions.
- 1,931 of the 1,949 breakpoint windows (99.1%) have such an off-path fill among their candidate anchors.
- In all 573 span_cap windows the nearest pair holds an off-path block, and that pair is a median 43.5 Mb apart
  in B.
- The margin flags only about half of these fills (46% below 0.5). The sims hardly have them (2.5-3.5% of the
  net), which is why they show 0-2.3% breakpoints.

**Fix.** A syntenic net with a two-frame fill test and no new parameter.
- **Rule.** A trimmed piece is dropped before it claims when it is a fill out of place in both genomes. Out of
  place means its B span lies outside its A-parent's B gap, and its A span outside its B-parent's A gap.
- **Measured on chr10 B73v5 -> TIL18.** Breakpoint windows fall from 2,054 to 175 and span_cap from 604 to 117.
  Top-level elements in ok windows rise from 3,858 to 6,163 (awpaf: 6,305), and U calls fall from 4,295 to 1,412
  (awpaf: 2,174).
- **Agreement holds.** P/E agreement with the AnchorWave read-out stays 99.3% (stock 99.5%), and class agreement
  with the awpaf route stays 99.5%. 90.5% of the windows ok under both nets keep an identical B window. Of the
  226 that moved or flipped strand, 225 had been off AnchorWave's path (the other sat at a path break), and 142
  now lie on it.
- **Cost.** The net takes +0.3 s, and chr10 genotyping takes about twice as long.
- **Sims.** They are unchanged, except R1_s1 A -> B (unresolved 4.6% -> 3.8%). High-tier P/E precision is
  unchanged.
- **One flaw, with a correction proposed but not measured.** The B-frame "top" escape lets 35 paralog chains
  through into uncovered TIL18 sequence (centromere gap).

Terms used below.
- **Net class** (UCSC netClass sense, `diaglib.NetIndex`, post hoc on the cached net). A kept block is **top** if no
  better chain (lower chain id, i.e. higher chain score, netted earlier) has an A extent (first to last kept
  piece) that contains it. Otherwise it is a **fill**, and its parent is the innermost such chain. A fill is
  **syn** if its B span lies inside the parent's B gap (between the parent's two pieces flanking it on A), with
  the same strand. It is **inv_in** if inside that gap on the opposite strand, **nonsyn** if outside the gap on
  the same strand, and **inv_out** if outside on the opposite strand. The brief's "inv" is inv_in plus inv_out.
- **AW path** (`diaglib.on_path`). Take the AnchorWave-aligned A bases bracketing a block's A interval: the last
  one at or before its start and the first one at or after its end. A block is **on** path if its B interval lies
  between their B images (100 bp slop, CHAIN_OVERLAP) with AnchorWave's strand. It is **off** otherwise. Two
  further labels: **break** when the brackets fall in AnchorWave blocks of different strands, **edge** when a
  bracket is missing.

## Q1. Cross-tab, and how general the problem is

`q1_crosstab.py` -> `q1_elements_<A>__<B>.tsv.gz` (one row per element: both window statuses, both calls and the
read-out call), `q1_crosstab.tsv`, `q1_status_fractions.tsv`.

**B73v5 -> TIL18, top-level elements.** An unresolved window holds exactly one top-level element, so rows here
are windows of unresolved elements.

| mm2 \ awpaf | ok | breakpoint | span_cap | no_left_anchor | no_right_anchor | total |
|---|---|---|---|---|---|---|
| ok | 3,783 | 18 | 54 | 1 | 2 | 3,858 |
| breakpoint | **1,949** | 17 | 66 | 9 | 13 | 2,054 |
| span_cap | **573** | 7 | 20 | 1 | 3 | 604 |
| total | 6,305 | 42 | 140 | 11 | 18 | 6,516 |

**B73v5 -> TIL18, calls of all 9,064 elements, collapsed** (present = P/S/T, absent = E, missing = D/O/G).

| mm2 \ awpaf | present | absent | missing | U | total |
|---|---|---|---|---|---|
| present | 2,302 | 3 | 43 | 108 | 2,456 |
| absent | 13 | 1,008 | 39 | 54 | 1,114 |
| missing | 15 | 32 | 896 | 256 | 1,199 |
| U | 393 | 349 | 1,797 | 1,756 | 4,295 |
| total | 2,723 | 1,392 | 2,775 | 2,174 | 9,064 |

Of the 2,890 elements in mm2 breakpoint windows, AnchorWave's read-out calls 1,192 O, 826 D, 321 E, 188 T, 114 P,
23 S and 226 U. So 70% sit in sequence that TIL18 lacks or has replaced (D/O). Where both routes resolve an
element they rarely disagree on presence (3 + 13 present/absent contradictions). The loss is almost entirely U.

**TIL18 -> B73v5** shows the same pattern. Of the top-level elements, 1,316 are breakpoint and 448 span_cap
under mm2 but ok under awpaf. The calls are 3,307 U under mm2 (1,352 of them D/O/G under awpaf), and 4 + 21
present/absent contradictions.

**Window status, every chr10 mm2 direction, awpaf, and the finished sim mm2 runs (R1_s1, R1_s2, R2_s1).**

| source | pair | windows | breakpoint | span_cap | elements in breakpoint / span_cap windows | U calls |
|---|---|---|---|---|---|---|
| chr10 mm2 | B73v5 -> TIL18 | 5,671 | 2,054 (36.2%) | 604 (10.7%) | 31.9% / 9.4% | 47.4% |
| chr10 mm2 | B73v5 -> TIL01 | 5,651 | 1,759 (31.1%) | 592 (10.5%) | 27.3% / 9.4% | 41.9% |
| chr10 mm2 | TIL18 -> B73v5 | 5,039 | 1,462 (29.0%) | 488 (9.7%) | 24.4% / 8.0% | 39.8% |
| chr10 mm2 | TIL18 -> TIL01 | 5,087 | 1,564 (30.8%) | 519 (10.2%) | 25.8% / 8.5% | 41.4% |
| chr10 mm2 | TIL01 -> B73v5 | 5,574 | 1,627 (29.2%) | 459 (8.2%) | 24.4% / 6.9% | 37.2% |
| chr10 mm2 | TIL01 -> TIL18 | 5,823 | 2,108 (36.2%) | 723 (12.4%) | 32.1% / 10.9% | 49.3% |
| chr10 awpaf | B73v5 -> TIL18 | 3,771 | 42 (1.1%) | 140 (3.7%) | 0.7% / 2.2% | 24.0% |
| chr10 awpaf | TIL18 -> B73v5 | 3,584 | 40 (1.1%) | 111 (3.1%) | 0.6% / 1.8% | 23.2% |
| sim R1_s1 mm2 | A -> B / B -> A | 263 / 250 | 6 / 0 | 0 / 0 | 2.3% / 0% | 4.6% / 4.7% |
| sim R1_s2 mm2 | A -> B / B -> A | 300 / 276 | 2 / 1 | 3 / 0 | 1.0% / 0.4% (bp) | 6.1% / 2.6% |
| sim R2_s1 mm2 | A -> B / B -> A | 270 / 257 | 5 / 4 | 0 / 0 | 1.7% / 0.7% (bp) | 3.7% / 2.7% |

Every chr10 mm2 direction has 29-36% breakpoint and 8-12% span_cap windows. The sims do **not** reproduce the
problem: they have 0-2.3% breakpoint and 0-1% span_cap. Their breakpoint windows come from the same kind of
blocks (nonsyn/inv_out fills, 9 of the 12 sim windows checked), plus 3 windows beside the simulated inversion
(inv_in), which are real. The reason is in Q4: the sims share almost all their sequence, so paralogous fills make up only 2.5-3.5%
of a sim net's A bp, against 26-34% on chr10.

## Q2. Breakpoint causes

`q2_causes.py --pair A,B` reruns the engine's own candidate search (`window._left_cands/_right_cands` logic
and the pairing loop, asserted to reproduce every window status) on the cached net. It writes
`q2_candidates_<A>__<B>.tsv` (one row per candidate block: chain extent, kept pieces, raw chain blocks, score, net
class, parent, AW path, margin, AW-aligned fraction) and `q2_windows_<A>__<B>.tsv`.

**B73v5 -> TIL18: 1,949 windows breakpoint under mm2 and ok under awpaf; 11,694 candidate blocks.**

| candidate class | AW path on | off | break/edge | median chain A bp aligned | median pieces | median margin | margin < 0.5 |
|---|---|---|---|---|---|---|---|
| top | 2,092 | 669 | 21 | 21.7 Mb | 2,961 | 1.00 | 2% |
| syn | 33 | 46 | 0 | 3.2 kb | 3 | 1.00 | 3% |
| inv_in | 0 | 29 | 0 | 49 kb | 9 | 1.00 | 3% |
| nonsyn | 28 | 3,982 | 1 | 10.1 kb | 3 | 0.55 | 48% |
| inv_out | 56 | 4,736 | 1 | 9.7 kb | 3 | 0.50 | 50% |

| cause | windows | counterfactual: off-path candidates removed, search continued -> ok | span_cap | breakpoint | no anchor |
|---|---|---|---|---|---|
| (i) off-path fill among the candidates | **1,931 (99.1%)** | 1,595 | 133 | 53 | 150 |
| (ii) off-path top chains only | 17 | 5 | 0 | 12 | 0 |
| (iii) other | 1 | 0 | 0 | 1 | 0 |

TIL18 -> B73v5: 1,316 windows. Cause (i) 1,315 and (ii) 1. Counterfactual: 1,076 ok, 108 span_cap, 74
breakpoint, 58 no anchor. The candidate classes have the same shape: nonsyn 2,566, inv_out 3,176, top 2,099.

What the off-path fills are (B73v5 -> TIL18):
- **Short paralogous chains.** There are 1,889 distinct chains. Each holds a median of 10 kb aligned (q90 23 kb)
  in 3 kept pieces from 3 raw blocks, about one LTR-RT's worth. 96.5% of the distinct fill blocks map more than
  1 Mb away from AnchorWave's bracket in B, and their A spans are on average only 7% AnchorWave-aligned.
- **They fill A-only gaps.** The AW bracket around a fill is a median 2 bp wide in B. AnchorWave aligns the
  sequence on either side of the fill to adjacent TIL18 bases, so the fill sits in B73-only sequence (an
  insertion in A). Any B placement of such a block is a paralog, or a transposition.
- **Their parents are the main orthologous chains** (median parent score 4.69 M; chains 0-2 span 0-52.6,
  52.6-122.6 and 130.2-152.3 Mb of B73). The fill's B target is B-only sequence elsewhere, which no better chain
  claims. A B73-only TE copy and a TIL18-only TE copy of the same family make a pairing that the flat net accepts
  once it carries >= 1 kb of matches.
- The nearest candidate pair fails on strand in 1,270 windows and on order in 679. Paralog orientation is random,
  so inv_out and nonsyn fills are about equally common.
- **The net loses no orthologous alignment.** `raw_vs_net.py` measured how many of AnchorWave's 58.0 Mb of
  aligned B73 bases on-path mm2 blocks cover: 82.1% before chaining/netting, 81.8% after. The net never drops an
  ortholog in favor of a paralog (268 raw on-path blocks, 218 kb, are lost in total). Where mm2 has no on-path
  anchor, minimap2 never reported one. 10.4 Mb of AnchorWave-aligned bases have none: 4.2 Mb of those are
  covered only by off-path raw alignments, and 6.2 Mb by no raw block at all. The 4.2 Mb fits a paralog taking
  minimap2's primary while the ortholog falls below `-p 0.8` or beyond `-N 5` per 120-kb chunk (not tested here;
  PARAMS.md section 1).
- **Cause (ii)**, 17 windows, lies entirely at B73 122.8-126.0 and 131.5 Mb, the edges of AnchorWave's two
  inversions (B73 123.1-124.4 and 126.3-131.9 Mb). There, mm2's top chains go to TIL18 25.6, 119.7 and 137.5 Mb.
  These are candidate real rearrangements or a complex region; AnchorWave itself calls those elements D/O/U.
- **Cause (iii)**, 1 window at 132.02 Mb, sits right after the 5.6-Mb inversion's end. Its left anchors are
  pieces of the inversion chain, on AnchorWave's path. Its right anchors are nonsyn fills that also lie on the
  path. The nearest pair fails on strand: a real breakpoint next to the element.

**Dotplots** (`dotplots/ex01-ex14_*.png`, `dotplots/all.pdf`, `dotplots/examples.tsv`; working plots). The
examples are random with seed 1: 8 cause (i), 2 cause (ii), the one cause (iii) and 3 span_cap. Left panel: the
whole TIL18 chr10. Right panel: the local B region. Candidates are drawn thick.
- ex01 (17.56 Mb, AW/read-out D). Left anchors: an on-path top block plus inverted fills to 83 Mb. Right anchors:
  nonsyn fills to 137 Mb. AnchorWave aligns almost nothing around the element; it is a B73-only region.
- ex02 (95.91 Mb, E). AnchorWave runs a dense collinear path through the region, but mm2 has one top block there.
  Fills to 17, 35, 60 and 77 Mb occupy the A positions AnchorWave aligns (mm2 never mapped them on path).
- ex03 (138.04 Mb, E). The nearest left anchor is a nonsyn fill (40 Mb) and the next two are on-path top
  blocks. Right: fills to 119 and 1.5 Mb.
- ex04 (133.13 Mb, E). AnchorWave's path continues on the left, where mm2 has only inverted fills (135.7 Mb).
  Right anchors are on-path top blocks.
- ex05 (128.10 Mb, inside the 5.6-Mb inversion; awpaf O, read-out D). All six candidates are fills to 98.7, 66.7
  and 75.1 Mb.
- ex06 (10.33 Mb, read-out P). AnchorWave aligns the element and both flanks collinearly. mm2's left anchors are
  fills (132 and 104 Mb); the on-path top blocks start 40 kb to the right.
- ex07 (37.49 Mb, E/O). Left: three nonsyn fills to 28.2 Mb. Right: inverted fills to 32.8 and 114 Mb.
- ex08 (15.65 Mb, O). Left: an on-path top block plus fills to 48 and 16.6 Mb. Right: inverted fills to 100 Mb.
  AnchorWave aligns nothing right of the element.
- ex09 and ex10 (126.0 Mb, cause ii, D). In this inversion-edge region mm2's top chains go to 25.6 and 137.5 Mb,
  while AnchorWave aligns a few segments to 119.7 Mb.
- ex11 (132.02 Mb, cause iii, D). The element sits at the inversion's right end. The inverted chain lies on the
  left, the forward AnchorWave path on the right.
- ex12 (129.81 Mb, span_cap, read-out O). This is inside the inversion: AnchorWave's path descends, and on-path
  inverted top blocks lie on the right. The left anchors are fills to 131.9 and 121.5 Mb: same strand, in
  order, but 9 Mb from the right anchors.
- ex13 and ex14 (112.90 and 69.94 Mb, span_cap). Every candidate is a fill (3.5, 11.2, 77.4 Mb and 67.5, 11.0,
  109.8 Mb). One left/right pair is consistent but megabases apart.

## Q3. span_cap

B73v5 -> TIL18 has 573 elements span_cap under mm2 and ok under awpaf (`q3_spancap_B73v5__TIL18.tsv`). Every
one fails on the **B** span: the nearest pair is a median 43.5 Mb apart in B (q10 8.0 Mb). None fails on A: the
A span is a median 40 kb and at most 240 kb. The nearest pair always holds an off-path block (off/off 378,
off/on 98, on/off 97). AnchorWave's windows for the same elements are a median 82 kb in A (q90 245 kb), and
only 13 exceed 400 kb. So span_cap is **not** a large unshared region with a wide AnchorWave window. It is the
breakpoint problem in another form: two paralogous anchors happen to share strand and order but sit megabases
apart. Removing the off-path candidates leaves 467 of 573 ok, 52 span_cap and 51 without an anchor. Only 20
elements are span_cap under both routes. TIL18 -> B73v5 is the same (448 elements; B span median 40.8 Mb; A
span at most 173 kb; 384 ok after removal).

## Q4. Net composition

`q4_net_composition.py` -> `q4_net_composition.tsv`, `q4_class_x_path.tsv`, `q4_margins.tsv`. Shares are of the
netted A bp.

| net | pair | blocks | A bp | top | syn | inv_in | nonsyn | inv_out | nonsyn + inv_out blocks |
|---|---|---|---|---|---|---|---|---|---|
| chr10 mm2 | B73v5 -> TIL18 | 14,847 | 75.5 Mb | 68.9% | 0.1% | 0.2% | 14.6% | 16.3% | 6,037 (41%) |
| chr10 mm2 | B73v5 -> TIL01 | 14,422 | 83.6 Mb | 73.5% | 0.2% | 0.4% | 12.3% | 13.7% | 5,540 (38%) |
| chr10 mm2 | TIL18 -> B73v5 | 14,845 | 75.5 Mb | 68.7% | 0.1% | 0.1% | 14.4% | 16.6% | 6,063 (41%) |
| chr10 mm2 | TIL18 -> TIL01 | 16,143 | 74.8 Mb | 65.1% | 0.1% | 0.4% | 16.9% | 17.5% | 6,907 (43%) |
| chr10 mm2 | TIL01 -> B73v5 | 14,424 | 83.6 Mb | 73.8% | 0.2% | 0.4% | 12.2% | 13.4% | 5,480 (38%) |
| chr10 mm2 | TIL01 -> TIL18 | 16,142 | 74.8 Mb | 65.2% | 0.1% | 0.4% | 17.8% | 16.6% | 6,870 (43%) |
| chr10 awpaf | B73v5 -> TIL18 | 12,875 | 58.1 Mb | 99.4% | 0.7% | 0 | 0 | 0 | 0 |
| sim R1_s1 mm2 | A -> B | 489 | 5.6 Mb | 92.8% | 0 | 4.6% | 1.4% | 1.2% | 34 (7%) |
| sim R1_s2 mm2 | A -> B | 502 | 5.9 Mb | 93.5% | 0 | 2.9% | 1.2% | 2.3% | 49 (10%) |
| sim R2_s1 mm2 | A -> B | 464 | 5.8 Mb | 93.1% | 0 | 4.4% | 1.2% | 1.4% | 38 (8%) |

- **Non-collinear fills dominate the off-path net.** In every chr10 direction, 26-34% of the net's A bp (38-43%
  of its blocks) are fills whose B span lies outside their parent's B gap. On B73v5 -> TIL18, that is 23.3 Mb in
  6,037 blocks, and 22.7 Mb of it is off AnchorWave's path.
- **Collinear fills are rare.** syn and inv_in fills cover only 0.3% of the chr10 net. In the sims, inv_in
  covers 2.9-4.6%: that is the simulated inversion.
- **Top-level blocks off the path.** The B73v5 -> TIL18 net also holds 1,308 top-level blocks (4.3 Mb, 5.7%)
  off AnchorWave's path. Most belong to the three main chains: locally collinear paralogs the chain absorbed
  across an A-only insertion, a median 48 kb off AnchorWave's bracket. They cannot create a breakpoint (two
  anchors of one chain are always consistent), but they can shift a window's B placement. Nothing proposed here
  touches them.
- **The margin does not mark the fills.** nonsyn and inv_out blocks have a median margin of 0.59-0.60, and only
  46% are below MARGIN_HIGH = 0.5 (top blocks: 0.4%). Among the candidates of breakpoint windows, 48-50% are
  below 0.5. The margin needs a reported rival, and the rival of a paralog is another paralog, which minimap2
  mostly never reports (`-N 5` per 120-kb chunk, `-p 0.8`). `make_windows` does not read the margin anyway; it
  only sets the tier.
- **A real inversion is out of place in A's frame.** The 5.6-Mb inversion (chain 3, strand -1, B73
  126.13-131.93 Mb, 344 pieces, 287 on AnchorWave's path) has 127 pieces (458 kb) classed inv_out. The better
  forward chain 2 (score 4.69 M) starts at 130.22 Mb with 12 forward pieces (47.6 kb, margin ~1) inside the
  inversion, so its A extent covers chain 3's last 1.6 Mb. In B's frame those 127 pieces lie inside no better
  chain's B extent (checked), so B's frame sees them as top level. This case shapes the proposal.

## Q5. Fix

### Proposal (written before any measurement of it)

**Rule: a syntenic net with a two-frame fill test.** It changes `chain.net_blocks` (in `_net_chain`) only.
1. Chains are still visited best first, and each block is still credited and trimmed exactly as now.
2. Before a chain claims anything, each of its trimmed pieces x is tested against the chains already kept (all
   of them better). Its A-parent is the kept chain with the smallest A extent (first to last kept piece) that
   contains x's A span on x's A sequence.
   - x is **A-syntenic** if it has no A-parent (top level in A).
   - x is also A-syntenic if its B span lies inside the B gap between the A-parent's two pieces flanking x on A,
     on the same B sequence: syn on the same strand, an inversion on the opposite strand.
3. The same test runs in B's frame. The B-parent is the kept chain with the smallest B extent containing x's B
   span on x's B sequence. x is **B-syntenic** if it has none, or if its A span lies inside the A gap between
   the B-parent's two pieces flanking x on B, on the same A sequence.
4. A piece that is syntenic in **neither** frame is dropped: a fill out of place in both genomes. It claims
   nothing, so later chains may still fill its positions. Its competition credit stands, because it is a rival
   alignment. The chain keeps its other pieces if they still carry >= MIN_CHAIN_SCORE matches, as now.

**Parameters: none new.**
- The chain order, MIN_CHAIN_SCORE and CHAIN_OVERLAP (competition) are unchanged.
- Containment is exact, with no slop. `_trim` already removes every claimed A and B position from a piece, so a
  piece lies wholly inside or wholly outside its parent's gap; it cannot straddle a parent piece.
- No distance limit (UCSC's maxFar) and no size escape (UCSC's minSynScore/minSynSize/minSynAli) is needed.

**Why two frames.** Synteny belongs to the pair of genomes, not to one coordinate system.
- A paralogous fill pairs an A-only gap in one place with a B-only gap elsewhere, so it is out of place in both
  frames.
- A real rearrangement block is the best explanation of its sequence in at least one genome, so it is top level
  or in place in at least one frame.
- The deciding case is the 5.6-Mb inversion: in A's frame, 127 of its pieces fall in the gaps of a better chain
  that crept into it, but in B's frame they are top level.
- An A-frame-only rule would delete those pieces. It would also make the A -> B and B -> A nets disagree;
  checking both frames treats the two directions alike.
- These reasons come from the chain structure. The agreement scores played no part.

**Literature.**
- **UCSC chains and nets** (Kent et al. 2003, PNAS 100:11484, doi:10.1073/pnas.1932072100) fill each chain's
  gaps with lower-scoring chains. `netSyntenic` (kent source, read for this report) classes a fill against its
  parent fill:
  - top: no parent;
  - nonSyn: another query chromosome;
  - otherwise syn (same strand) or inv (opposite strand), with qFar, the query distance to the parent's span.
- **`netFilter -syn`** (defaults "tuned for human/mouse") drops nonSyn fills and fills with qFar > maxFar
  (200 kb), keeps top fills with score >= 300,000, and keeps any fill above minSynScore 200,000, minSynSize 20 kb
  and minSynAli 10 kb. The rule here makes three substitutions:
  - "outside the parent's gap" replaces "on another chromosome, or farther than maxFar" (chr10 vs chr10 has one
    sequence, so UCSC's nonSyn would be empty);
  - the second frame replaces the size escape;
  - top-level chains are kept whatever their score.
- **AnchorWave `genoAli`** (Song et al. 2022, PNAS 119:e2113075119) keeps one longest path of strictly collinear
  anchors (strand-aware with `-IV`). Non-collinear pieces ("local duplications or translocations without enough
  anchors") are aligned as indels. This is the strict end of the same idea; the rule is looser and keeps
  rearranged top-level chains.
- **SyRI** (Goel et al. 2019, Genome Biol 20:277) takes the highest-scoring syntenic path and calls every
  off-path alignment a rearrangement. Inversions are found by reverse-complementing one genome.
- **DESIGN 5.1** already defines an anchor as "aligned 1:1 to B in an orthologous (collinear, uniquely best)
  chain". The flat net enforces 1:1 and best, but not collinear; this rule adds the collinear part.

**Treatment of real events.**
- **Inversions.**
  - A small inversion bridged by its forward chain is an in-gap opposite-strand fill: kept.
  - An inversion over CHAIN_MAX_GAP (1 Mb) forms its own top-level chain: kept.
  - An inversion partly covered by a better chain's spurious extension (as above) is top level in B's frame: kept.
- **Transpositions.** A segment moved within or between chromosomes sits in a gap of better chains in both
  genomes (an A-only gap where it left, a B-only gap where it landed), so it is dropped like a paralog. Elements
  in it lose their own anchors and are windowed by the parent's flanks. B lacks the segment there, so they come
  out D/O/U (missing), never E, unless the segment is the element plus its TSD (then E is right for that site).
  A real transposition larger than a TE cannot be told from a paralog without a size threshold. That cost is
  named here, and nothing is added for it.
- **Unplaced or scaffold-rich assemblies.**
  - Top-level chains on A scaffolds are untouched.
  - A fill on a B scaffold other than its A-parent's is out of place in A's frame (UCSC's nonSyn). It survives
    when B's frame keeps it, which is the usual case for an ortholog on an unplaced B scaffold that no better
    chain covers.
  - Residual risk: paralogs landing on scaffold regions that no better chain covers survive too.
- **Expected limits.**
  - Top-level paralogs (in A gaps between separate top chains) and paralogs absorbed into a main chain are
    untouched.
  - Mapping-level losses (orthologs that minimap2 never reported, Q2) are not recovered. Elements there get the
    orthologous chain's farther anchors, so some windows widen into span_cap or lose an anchor.

**Runtime.** One parent lookup per piece in each frame, before claiming. The prototype scans the kept chains'
extents (O(kept chains) per piece). An interval index makes it O(log n). Today's chr10 net takes 0.3 s
(`chain_blocks` 0.2 s) against 72-88 s of mapping per unordered pair, so the cost is expected to be negligible
and is measured below.

**Measurement plan (once, no sweeps).**
- **chr10 B73v5 -> TIL18.** Re-net the cached raw blocks with a monkeypatched `ltrpav.chain._net_chain`, and
  rebuild the windows. Then run `ltrpav-genotype --pair B73v5,TIL18` through the same in-process patch, in a
  copied workdir (elements and raw blocks copied, the net recomputed; 4 threads).
- **What to report.** Status and call counts; P/E and missing-state agreement with the AnchorWave read-out; for
  windows ok under both nets, whether the B placement changed.
- **Sims.** Run the patched mm2 route on R1_s1 and R2_s1, and score with `ltrpav-sim score` against `truth.tsv`.
  The "before" values are the batch's own mm2 runs, scored the same way.

### Measurement (run once, after the proposal was frozen)

The proposal section above was frozen at 2026-11-11T06:15:11-05:00, before the prototype existed
(`diag_breakpoints/proposal_frozen.txt` + `.log`: sha256 of that text and of this report at that moment). The
prototype is `synnet.py`. It is a copy of `_net_chain` with the test added; `synnet_run.py` runs ltrpav in
process with it installed.
- **Harness checks.** With the drop disabled, the patched path reproduces the stock net exactly (both
  directions). A control run of the stock net through the same copied-workdir harness (`stock_run.py`)
  reproduces the batch's mm2 windows and calls byte for byte.
- **Inputs.** Raw blocks and elements are copied from the batch runs, so the net is the only difference.

**chr10 B73v5 -> TIL18: net** (`measure_chr10_windows.py` -> `m1_net_stats.tsv`, `m1_window_status.tsv`).
- **Size.** The net shrinks from 14,847 blocks, 75.5 Mb of A and 2,645 chains to 9,118 blocks, 53.3 Mb and
  161 chains.
- **Test outcomes per tested piece.**
  - Kept: top in both frames 8,515; syn in both 235; inversion in both 54. Two outcomes are kept by one frame
    only: top in A but out of place in B, 240; out of place in A but top in B, 216.
  - Dropped: 12,218 pieces out of place in both frames (54.6 Mb, counting the later paralogs that tried the
    freed space). The rule left 5,395 chains below MIN_CHAIN_SCORE.
- **Divergence** d of the net falls from 0.0375 to 0.0259; the window preset stays asm20.
- **Net time** rises from 0.40 to 0.67 s.

**Window status, every chr10 direction.** The rule was applied to every direction's cached raw blocks; the
calls were genotyped for B73v5 -> TIL18 only. Elements are top-level elements in ok windows; the top-level
totals are B73v5 6,516, TIL18 6,040 and TIL01 6,685.

| pair | stock: breakpoint / span_cap / ok windows (elements) | syntenic: breakpoint / span_cap / no left or right anchor / ok windows (elements) |
|---|---|---|
| B73v5 -> TIL18 | 2,054 / 604 / 3,013 (3,858) | **175 / 117 / 61 / 3,091 (6,163)** |
| B73v5 -> TIL01 | 1,759 / 592 / 3,300 (4,165) | 192 / 97 / 31 / 3,394 (6,196) |
| TIL18 -> B73v5 | 1,462 / 488 / 3,088 (4,089) | 200 / 106 / 23 / 3,091 (5,711) |
| TIL18 -> TIL01 | 1,564 / 519 / 3,001 (3,954) | 170 / 60 / 9 / 3,050 (5,801) |
| TIL01 -> B73v5 | 1,627 / 459 / 3,488 (4,599) | 173 / 95 / 37 / 3,532 (6,380) |
| TIL01 -> TIL18 | 2,108 / 723 / 2,992 (3,854) | 159 / 96 / 41 / 3,058 (6,389) |

For comparison, awpaf on B73v5 -> TIL18 has 42 breakpoint and 140 span_cap windows, and 6,305 elements in ok
windows.

**Calls, B73v5 -> TIL18** (`ltrpav-genotype --pair` through the patch, 4 threads; `run_syn_chr10/`,
`measure_chr10_calls.py` -> `m2_*.tsv`, `measure_chr10_detail.py` -> `m3_detail.tsv`).

| calls | P | S | T | E | D | O | G | U |
|---|---|---|---|---|---|---|---|---|
| mm2, stock net | 2,027 | 66 | 363 | 1,114 | 575 | 621 | 3 | 4,295 (47.4%) |
| mm2, syntenic net | 2,106 | 93 | 655 | 1,438 | 1,369 | 1,985 | 6 | **1,412 (15.6%)** |
| awpaf (AnchorWave anchors) | 2,057 | 86 | 580 | 1,392 | 1,410 | 1,362 | 3 | 2,174 (24.0%) |
| AnchorWave read-out | 2,217 | 106 | 622 | 1,621 | 1,914 | 2,132 | 3 | 449 |

**Agreement with the AnchorWave read-out.** "Both resolved" means both calls are P/S/T/E. Class agreement
compares present with absent; P/E agreement counts elements both call P or E.

| calls | resolved | both resolved | class agreement | exact state | both P/E | P/E agreement | present-vs-absent contradictions (high tier) |
|---|---|---|---|---|---|---|---|
| mm2 stock | 3,570 | 3,272 | 98.96% | 96.33% | 2,880 | 99.48% | 34 (24) |
| mm2 syntenic | 4,292 | 3,743 | 98.45% | 94.84% | 3,161 | 99.27% | 58 (37) |
| awpaf | 4,115 | 3,727 | 99.20% | 96.19% | 3,201 | 99.56% | 30 |

- **Elements resolved under both nets (3,502).** The rule changed 3 calls' class and 9 calls' state.
- **Newly resolved elements (790).** They agree with the read-out less. Of the 476 the read-out resolves, 452
  (95.0%) agree on class and 398 (83.6%) on state. The other 314 face read-out D/O/U, mostly T against O (114,
  all medium tier) and E against O (83, of which 82 high tier).
- **Those disputes are shared with awpaf.** awpaf uses the same window aligner on AnchorWave's anchors, and it
  makes the same call for 63 of the 83 E/O cases, 73 of the 114 T/O and 15 of the 25 P/O. They are therefore
  disagreements between mappy's window alignment and AnchorWave's MAF, not anchoring errors. Directly, the
  syntenic calls agree with awpaf on class for 99.51% of the 3,877 elements both resolve, the same rate as the
  stock calls (99.52% of 3,326).
- **Window width.** Newly resolved elements sit in wider windows: B-window median 101 kb (agreeing calls) and
  171 kb (T/O), against 18 kb for elements resolved under both nets.
- 68 elements went from resolved to missing or U.

**Missing states.** The read-out calls 4,049 elements D/O/G. The stock net calls 941 of them missing and 2,866 U;
the syntenic net calls 2,807 missing and 780 U. On the other hand, the syntenic net calls missing where the
read-out is resolved more often: 159 against read-out present and 296 against read-out absent (stock: 60 and
161).

| read-out -> | present | absent | missing | U |
|---|---|---|---|---|
| stock: present / absent / missing / U | 2,295 / 24 / 60 / 566 | 10 / 943 / 161 / 507 | 120 / 122 / 941 / 2,866 | 31 / 25 / 37 / 356 |
| syntenic: present / absent / missing / U | 2,524 / 35 / 159 / 227 | 23 / 1,161 / 296 / 141 | 259 / 203 / 2,807 / 780 | 48 / 39 / 98 / 264 |

**B placement of windows ok under both nets** (3,832 top-level elements).
- 3,468 (90.5%) keep an identical B window. 106 widened around the old one (merged with neighbors, or anchored
  farther), and 32 changed while still overlapping.
- 120 moved to a non-overlapping B interval and 106 flipped strand. Only 2 of the flips lie inside the inversions.
- Every one of these 226 stock windows was off AnchorWave's path (225 off, 1 at a path break). This is a
  yardstick check, window interval against AnchorWave's bracket with 1-kb slop. With the rule, 142 are on the
  path and 83 still off. In other words, the stock net placed them on consistent pairs of paralogous anchors.

**Sims** (`run_syn_R1_s1/`, `run_syn_R2_s1/` on the batch's own raw blocks; `ltrpav-sim score` -> `score/`,
`m4_sims.tsv`). "Before" is the batch's mm2 run.

| sim | pair | net | correct_resolved_frac all / high | unresolved_frac | P precision, high (tp/fp) | E precision, high (tp/fp) |
|---|---|---|---|---|---|---|
| R1_s1 | A -> B | before | 0.8978 / 0.8629 | 0.0461 | 1.0000 (198/0) | 1.0000 (104/0) |
| R1_s1 | A -> B | after | **0.9005** / 0.8629 | **0.0377** | 1.0000 (198/0) | 1.0000 (104/0) |
| R1_s1 | B -> A | before = after | 0.8717 / 0.8220 | 0.0472 | 0.9950 (200/1) | 1.0000 (91/0) |
| R2_s1 | A -> B | before = after | 0.9024 / 0.8758 | 0.0371 | 0.9963 (270/1) | 1.0000 (105/0) |
| R2_s1 | B -> A | before = after | 0.8937 / 0.8503 | 0.0272 | 1.0000 (279/0) | 1.0000 (98/0) |

- **Windows.** Breakpoint windows go from 6 to 1 (R1_s1 A -> B) and from 5 to 3 (R2_s1 A -> B); the other
  directions are unchanged.
- **Inversion kept.** In both sims the simulated inversion's 21 in-gap inverted pieces are kept.
- **Calls.** Only R1_s1 A -> B changes (4 calls). High-tier P/E precision is unchanged; the sims cannot show
  more, because they never had the problem (Q1).

**Runtime.**
- The net adds 0.27 s per chr10 direction (0.40 -> 0.67 s), against 72-88 s of mapping per unordered pair.
- Genotyping B73v5 -> TIL18 at 4 threads takes 29.3 s instead of 15.4 s, because the windows are wider. Peak
  RSS of the largest process goes from 386 to 551 MB.
- Whole-genome cost: genotyping was about 4 s of a 77.5-s chr10 direction at 32 threads, so doubling it stays
  small next to mapping.

**What is left** (`measure_residual.py` -> `m5_residual.tsv`). The off-path candidates of the 175 breakpoint and
117 span_cap windows come from four sources:
- **In-gap fills (syn, inv_in) off AnchorWave's path:** about 130 windows, 64 of them breakpoints from inverted
  in-gap fills. They pass the containment test by design. In the syntenic net they cover 164 blocks (323 kb) at
  pooled d 6.6%, as divergent as the dropped fills (6.5%) and nearly three times the on-path top blocks (2.3%).
  They are local paralogs inside large parent B gaps (B-specific insertions).
- **Main-chain blocks off the path:** 62 span_cap and some breakpoints. These are the paralogs a main chain
  absorbs across an A-only insertion (Q4, d 4.8%).
- **Small top-level paralog chains:** about 29 windows.
- **Paralogs that leaked through B's top-level escape:** 29 windows (see next).
- 33 windows hold no off-path candidate. 18 sit at AnchorWave path breaks (inversion edges), and 15 are
  span_cap with on-path anchors beyond WINDOW_CAP (large unshared regions). 69 of all 292 residual
  windows lie at or inside the inversions (B73 122.8-132.2 Mb).

**Is the rule wrong somewhere, for a reason independent of the scores? Yes, in one place: the top-level escape
in the second frame.** 75 kept pieces (355 kb, 35 chains) are out of place in A's frame and kept only because
B's frame sees them as top level.
- None of those 35 chains is top level anywhere in A. Each is a pure fill inside the main chains' A gaps.
- Their B targets all lie in TIL18 sequence that no better chain covers: 51.2-52.8 Mb (the gap between the two
  largest chains, around the chr10 centromere) and 116.6-118.2 Mb (gaps beside the inversions).
- In such uncovered sequence, "top in B" means there is no context at all, not that the placement is syntenic.
  The inversion pieces the escape was designed for differ in a structural way: their chain (chain 3) is top level
  in A over 217 pieces.

**Correction (proposed, not measured).** Count "top level" as support only at the chain level. Keep a piece if,
in **each** frame, one of these holds:
- it is top level;
- it lies in place in its parent's gap (syn or inversion);
- its chain holds a top-level piece in that frame.

Drop it otherwise. Checking this against the cases above:
- A paralog fill is out of place in A, and its chain is never top level in A: dropped, whatever B shows.
- The inversion's A-out pieces pass in A's frame through their chain's 217 top pieces, and in B's frame as top
  level.
- Its A-top pieces whose B falls inside chain 2's spurious B extent pass in B's frame through the chain's B-top
  pieces.
- A top-level paralog chain in an A root gap would now also need support in B. That also addresses the "small
  top-level paralog" residuals, at the same cost for transpositions as before.
- There is still no new parameter.

Expected effect: small. The leaked pieces are candidates in 29 residual windows. The in-gap local paralogs are a
separate limit: a containment test cannot separate them without a size or identity criterion, so no correction
is proposed for them here.

## What would make me doubt the conclusion

1. **AnchorWave is the yardstick for "off path", and genoAli is strictly collinear.** It aligns real
   transpositions as indels, so off path does not by itself mean paralog. The case for paralogs rests on two
   independent facts:
   - the dropped fills are about one TE long (median 10 kb aligned, 3 pieces);
   - they are three times as divergent as orthologous blocks (pooled d 6.5% vs 2.3%).

   But 10% of fills are as close as orthologs (per-block d < 2.6%). Young TE copies look like that, and so would
   real transpositions. If a fair share of the dropped fills proved to be moved orthologous segments (for example,
   long-read support for a transposed B73 segment), the rule would be discarding real orthology. The rule cannot
   tell the two apart; that cost was named up front.
2. **One genome pair, one chromosome.** Calls were measured on chr10 B73v5 -> TIL18 only, window status in all six
   chr10 directions. Whole genomes add inter-chromosomal paralogs (the "otherseq" case of the A-frame test),
   scaffolds and more rearrangements. The two-frame test was shaped by a single structural case, the 5.6-Mb
   inversion overlapped by chain 2's extension. Another pair could show conflict patterns it handles badly.
3. **The new calls are of lower quality, and no truth exists for them.**
   - The newly resolved calls agree with the read-out less (95.0% class agreement, against 98.96% for calls
     resolved before), and present-vs-absent contradictions rise from 34 to 58.
   - They sit in wide windows (B-window median 101-171 kb), where mappy finds partial matches (T against read-out
     O) or reads empty sites (E against O).
   - awpaf shares most of these disputes, so they belong to the window aligner and classifier, not the anchors.
     But the rule exposes many more such windows, and the sims, which lack the problem, cannot check them. The 82
     newly resolved high-tier E calls that face read-out O deserve hand inspection before anyone trusts the gain.
4. **The greedy premise.** The net still assumes the better-scoring chain is the reference frame. A high-scoring
   paralog chain netted before a weak orthologous chain would make the ortholog the fill. That is rare where
   orthologous chains reach megabases, as on chr10, but not in rearranged or poorly assembled regions.
5. **What is left is not anchoring-only.**
   - The 175 + 117 remaining unresolved windows are mostly in-gap local paralogs and main-chain detours, which
     the rule does not address.
   - minimap2 never reported an on-path alignment for 10.4 Mb of AnchorWave-aligned bases. The mm2_N50 variant can
     show whether more secondaries recover them; this report did not test it.
