# Task 19 — controller rulings (bind as much as the brief; override it where they conflict)

1. Input calls: the pair files written by genotype_pair (gzip TSV, header = classify.CALL_COLUMNS, "." = None). Parse
   only the columns needed (eid, state, tier, flags, reason, b_seqid, b_start, b_end, b_strand); stream line by line.
   `call_paths` maps (A label, B label) -> path for every ordered pair with annotated A.
2. Linking (union-find over (genome, eid), path compression): a call A->B with state P, S or T links A's element to every
   annotated B element on b_seqid whose span has reciprocal overlap >= COV_PRESENT with the call's B interval
   [b_start, b_end] (1-based inclusive). B elements of all levels are candidates. Use per-seqid sorted intervals + bisect
   (never all-pairs).
3. Members: Locus.members maps genome -> the eid of its first member (by start). If a locus holds more than one element of
   one genome, the others go to a new field `extra: dict[str, list[str]]`, the locus gets flag "multi_member", and QC
   counts it (n_multi_member). Locus gains `flags: list[str]`.
4. States per genome:
   - Member genome: GenomeState(state "P", tier "annot", coordinates/strand from its member element, k from the element,
     flags []). If any call from another member of this locus into this genome has state E, D or O, add flag
     "annot_conflict".
   - Other genome: candidates = the calls from each member element into this genome. Pick the highest tier
     (high > medium > low > "."); if the top tier holds different states -> state "U", tier = that tier, flag
     "conflict"; same state -> that state (coordinates from the first candidate in sheet-genome then start order).
     No candidate at all -> "U" with flag "no_call".
5. Locus attributes: discovery = genomes with a member, in sheet order; family/superfamily/clade = majority over members
   (ties -> first in sheet order); length = median member span length (int); ltr_len = median of members' mean LTR
   length (int); tsd = first member's (sheet order) tsd.
6. lid: sort loci by (index in the sheet of the first genome that has coordinates for the locus, that genome's fai seqid
   index (from its FASTA lengths, passed in via a `seq_order: dict[str, dict[str, int]]` argument or derived from the
   Samples' FASTAs), start); assign "L0000001", ... in that order. Input order must not change lids.
7. QC rows from this task: ("all", "n_loci", n), ("all", "n_conflict", loci with any "conflict" state),
   ("all", "n_multi_member", ...), ("all", "n_annot_conflict", ...). Task 21 adds more metrics later; keep the code
   structured so it can (a small function per metric).
8. Signature may gain the explicit `seq_order` argument named in ruling 6:
   `build_loci(samples, elements, call_paths, seq_order) -> tuple[list[Locus], list[QcRow]]`.
