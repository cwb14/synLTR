### Task 17: FastGA route

**Files:** Create `src/ltrpav/anchor/fastga.py`; Modify `tests/test_routes.py`

**Interfaces:**
- Produces: `FastgaRoute` (`name = "fastga"`), registered in `get_route`.

- [ ] **Step 1: Write the failing test** (`@pytest.mark.skipif(shutil.which("FastGA") is None, ...)`):

```python
def test_fastga_route(tmp_path):     # toy pair: blocks non-empty; every PAF col-1 name is an A seqid (orientation check)
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - Symlink both FASTAs into `workdir/fastga/` as `<label>.fa` (or `.fa.gz`), so the `.1gdb`/`.gix` files land there
    and never next to user data.
  - Run `FastGA -paf -T<threads> -P<workdir/tmp> -k <A> <B>` with `cwd` set to that dir, streaming stdout through
    gzip into `<A>__<B>.fastga.paf.gz`. `-k` keeps the indexes for other pairs.
  - Raw blocks come from `read_paf`, cached per unordered pair as in Task 15.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add FastGA anchoring route"`.

---

