### Task 5: Inversions (DESIGN 7.7)

**Files:**
- Create: `src/ltrpav/analysis/inversions.py`, `tests/test_inversions.py`

**Interfaces:**
- Consumes: `Catalog` (merged states: any discovery); `INV_MIN_LOCI`.
- Produces:

```python
INV_COLUMNS = ("genome_x", "seqid_x", "start_x", "end_x", "bp_left_x", "bp_right_x",
               "genome_y", "seqid_y", "start_y", "end_y", "bp_left_y", "bp_right_y", "n_loci", "n_strand",
               "n_discordant")
@dataclass(frozen=True)
class InvBlock:
    x: str; y: str; seq_x: int; seq_y: int                                 # genomes and fai indexes: the keys
    start_x: int; end_x: int; start_y: int; end_y: int                     # extent of the block's loci, 1-based
    bp_left_x: tuple[int, int] | None; bp_right_x: tuple[int, int] | None  # breakpoint intervals; None at a sequence end
    bp_left_y: tuple[int, int] | None; bp_right_y: tuple[int, int] | None
    n_loci: int; n_strand: int; n_discordant: int  # block loci; of them, those whose strands also say inverted; rows merged over
def inverted_blocks(cat: Catalog) -> list[InvBlock]
def reversed_blocks(y: np.ndarray) -> list[tuple[np.ndarray, int]]
    # one (seq_x, seq_y) group's mid_y in x order -> (row indexes, n_discordant) of each kept block (the rule below)
def write_inversions(blocks: list[InvBlock], cat: Catalog, path: Path) -> None
    # names from cat.seqids for output only; intervals "lo-hi"; "." for None
def inside(blocks: list[InvBlock], label: str, partners: set[str], seq: np.ndarray, pos: np.ndarray) -> np.ndarray
    # bool per position: inside a block of label against a partner; seq = label's fai indexes, pos = 1-based positions
def inversion_rows(blocks: list[InvBlock], cat: Catalog) -> tuple[list[StatRow], Findings]
```

Blocks are keyed by (genome, fai index), never by name, so two genomes that both name a sequence "chr2" never collide
(Review Focus 1).

The algorithm is not fixed by the signatures:

```
for each pair (x, y), x before y in sheet order (outgroups included: they polarize arrangements):
  rows = loci resolved (P/S/T/E) in x and in y, with coordinates in both
  for each (seq_x, seq_y) group (fai indexes) holding >= INV_MIN_LOCI rows:
    sort by mid_x (ties: mid_y); step_i = sign(mid_y[i+1] - mid_y[i]) (0 for equal y, e.g. host_empty E sites)
    dominant = +1 if sum(step) >= 0 else -1                 # a whole reversed seqid is not an inversion
    run = maximal stretch of rows joined by steps equal to -dominant (0-steps join without breaking it)
    candidates = runs of >= 2 rows (a single row is collinear or isolated)
    merge consecutive candidates A and B (x order, left to right; a merged block is the next A): find the fewest rows
      u trimmed from A's end and v from B's start such that A's last remaining row and B's first remaining row are in
      reversed order (dominant +1: y(B) < y(A); -1: y(B) > y(A)), with u + v + (rows between A and B) < min(|A|, |B|);
      merge when found. The trimmed rows and the rows between are the block's n_discordant
    keep merged blocks with >= INV_MIN_LOCI rows of distinct mid_y outside n_discordant   (reversed_blocks: these steps)
    bp_left_x = (end_x of the row before the block, start_x of its first row); bp_right_x = (end_x of its last row,
      start_x of the row after); y intervals from the same rows' y coordinates, low-high; None at a group end
    n_strand = block rows with strand_x * strand_y == -dominant
```

Rows `inversions` (scope `x~y`):
- `n_blocks`;
- `n_blocks_1Mb` (blocks spanning >= 1 Mb on x);
- `bp_inverted_x`.

The findings name each pair's three largest blocks, and name `INV_MIN_LOCI` as a heuristic. They also note that short
inversions, and breakpoints inside unresolved stretches, show up as U `inv_site` (counted in missingness, Task 8).

- [ ] **Step 1: Write the failing tests**

```python
X = 1001 + np.arange(1500) * 998_000 // 1500 + 250        # the review probe rr_inv_fix.py's row midpoints on 1 Mb

def _inv(y, a, b):
    y = y.copy(); m = (X >= a) & (X <= b); y[m] = a + b - X[m]; return y

def make_case(case: str) -> np.ndarray:
    y0 = _inv(X.astype(float), 300_001, 700_000)
    mid = np.flatnonzero((X >= 300_001) & (X <= 700_000))
    if case == "clean inversion":
        return y0
    if case.startswith("one locus moved"):
        y = y0.copy(); y[mid[len(mid) // 2]] += 50_000 if "+" in case else -50_000; return y
    if case == "two adjacent loci moved":
        y = y0.copy(); y[mid[300]] += 50_000; y[mid[301]] += 60_000; return y
    if case == "two separate inversions on one seqid":
        return _inv(_inv(X.astype(float), 100_001, 200_000), 600_001, 800_000)
    if case == "30-locus nested re-inversion":
        y = y0.copy(); s = (X >= 480_001) & (X <= 500_000); y[s] = 500_001 + (X[s] - 480_001); return y
    if case == "collinear":
        return X.astype(float)
    if case == "wholly reversed seqid":
        return (2_000_000 - X).astype(float)
    y = X.astype(float); y[700:704] = y[700:704][::-1]; return y          # "4 reversed loci"

@pytest.mark.parametrize("case, expected", [         # expected = n_discordant of each block, in x order
    ("clean inversion", [0]), ("one locus moved +50 kb", [1]), ("one locus moved -50 kb", [1]),
    ("two adjacent loci moved", [2]), ("two separate inversions on one seqid", [0, 0]),
    ("30-locus nested re-inversion", [29]), ("collinear", []), ("wholly reversed seqid", []), ("4 reversed loci", [])])
def test_reversed_blocks_cases(case, expected):
    blocks = reversed_blocks(make_case(case))
    assert [d for _, d in blocks] == expected
    if case == "clean inversion":
        assert len(blocks[0][0]) == 601
    if case == "two separate inversions on one seqid":
        assert [len(b) for b, _ in blocks] == [150, 301]

def test_block_found(tmp_path, toy_fastas):
    cat = simulate_run(tmp_path, seed=2, inversion=("S", "chr2", 300_001, 700_000), fasta_dir=toy_fastas).load()
    blocks, spacing = inverted_blocks(cat), 998_000 // 1500
    pair = lambda a, b: [blk for blk in blocks if {blk.x, blk.y} == {a, b}]
    for other in ("R", "D", "O"):                    # every genome against S carries the inversion, S~O included
        (blk,) = pair("S", other)
        on_other = blk.x == other
        seq = blk.seq_x if on_other else blk.seq_y
        lo, hi = (blk.start_x, blk.end_x) if on_other else (blk.start_y, blk.end_y)
        left, right = (blk.bp_left_x, blk.bp_right_x) if on_other else (blk.bp_left_y, blk.bp_right_y)
        assert cat.seqids[other][seq] == "chr2" and 300_001 <= lo and hi <= 700_000 + 150
        assert abs(left[1] - 300_001) <= spacing and abs(right[0] - 700_000) <= spacing
        assert blk.n_strand == blk.n_loci and blk.n_discordant == 0
    assert not pair("R", "D") and not pair("R", "O") and not pair("D", "O")

def test_inside(tmp_path, toy_fastas):
    cat = simulate_run(tmp_path, seed=2, inversion=("S", "chr2", 300_001, 700_000), fasta_dir=toy_fastas).load()
    blocks = inverted_blocks(cat)
    chr2 = cat.seqids["R"].index("chr2")
    got = inside(blocks, "R", {"S"}, np.array([chr2, chr2, chr2, 0]), np.array([500_000, 200_000, 800_000, 500_000]))
    assert got.tolist() == [True, False, False, False]
    assert inside(blocks, "R", {"D"}, np.array([chr2]), np.array([500_000])).tolist() == [False]

def test_write_inversions(tmp_path):
    blk = InvBlock("R", "S", 1, 1, 300_001, 699_850, 300_150, 700_000, (299_400, 300_001), (699_850, 700_400),
                   None, (700_000, 700_600), 601, 601, 0)
    cat = SimpleNamespace(seqids={"R": ("chr1", "chr2"), "S": ("chr1", "chr2")})
    write_inversions([blk], cat, tmp_path / "inv.tsv")
    head, row = (tmp_path / "inv.tsv").read_text().splitlines()
    assert head.split("\t") == list(INV_COLUMNS)
    assert row.split("\t") == ["R", "chr2", "300001", "699850", "299400-300001", "699850-700400",
                               "S", "chr2", "300150", "700000", ".", "700000-700600", "601", "601", "0"]
```

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_inversions.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** the tests. Expected: PASS.
- [ ] **Step 5: Commit.** `"Add inverted blocks from chains of resolved loci"`
---

