# Task 14 — controller rulings (bind as much as the brief; they override it where they conflict)

Notation as in the brief: element e in window coordinates s = e.start - 1 - win.a_start, t = e.end - win.a_start;
L = len(e.tsd) or TSD_DEFAULT; w = SLOP_TSD_MULT * L; "children" = e's direct annotated children (their spans are
excluded from every coverage/aligned-bp computation of e); ident = aln.identity(s - 1000, t + 1000) (nan -> treated as
"not >= IDENT_MIN" for tiers and as d = 0 in the TSD allowance).

`classify_window` always receives `b_seq` in A's orientation (the caller reverse-complements strand -1 windows);
`win.strand` only drives B-coordinate conversion and the `inv` flag. Elements are visited outermost-first
(parents before children).

Order of rules for each element (first match wins):
0. Inheritance: parent's call E -> E + flag host_empty; parent D/O/G/U -> same state + flag inherit. Inherited calls copy
   the parent's tier and B coordinates (the host's site is the child's site). Parent P/S/T -> continue.
1. `win.status != "ok"` or `aln is None` -> U, reason = win.status (or "no_alignment").
2. Flanks (R3b): `aln.aligned_bp(0, s) < MIN_SEG` or `aln.aligned_bp(t, len(a_seq)) < MIN_SEG` -> U, reason
   "flank_unaligned".
3. G check (R10, binding; must run before any refinement): b_lo = a2b of the last aligned A position < s; b_hi = a2b of
   the first aligned A position >= t; region = [min - REFINE_PAD, max + REFINE_PAD] clipped to b_seq; any "N"/"n" in
   b_seq[region] -> G. (mappy aligns N runs through as mismatches; this rule is what finds them.)
4. aligned element bp (aligned_bp over [s, t) minus children spans) < MIN_SEG -> ABSENT branch:
   a. An inverted hit in `aln.inv` with A length >= MIN_SEG overlapping [s, t) -> U, reason "inv_site".
   b. g = aln.gap_around(midpoint of e). None -> U "flank_unaligned"; zero-length gap -> U "ambiguous".
   c. g = refine_gap(a_seq, b_seq, g). refined = (g is not the input object). (refine_gap returns the input unchanged
      when its B window contains N or the B insertion exceeds 2*REFINE_PAD.)
   d. b_ins = g.b1 - g.b0; dl = s - g.a0; dr = g.a1 - t.
   e. Balanced placement within the slide range: x = clamp(floor((dl - dr)/2 + 0.5), 0, g.slide); dl' = dl - x;
      dr' = dr + x. (Every placement a0..a0+slide is an equally scoring alignment; the rule must not depend on which one
      an aligner reports.)
   f. Overhang explanation: if dl' > w, the left overhang [g.a0 + x, s) is "explained" when other annotated elements
      (not e, not an ancestor of e, lying inside the gap), each widened by its own L on both sides, cover all but <= w
      of it -> treat dl' as <= w and add flag adjacent. Same on the right with [t, g.a1 + x).
   g. b_ins >= MIN_SEG -> O. elif dl' <= w and dr' <= w -> (E if b_ins <= w else O + flag small_ins).
      else -> D (+ flag filler if b_ins > w).
   h. TSD read for E (exact image of an A TSD copy wholly outside the refined, leftmost gap g):
      if g.a1 <= t: Bcopy = b_seq[g.b1 + (t - g.a1) : g.b1 + (t - g.a1) + L]  (image of T2 = A[t, t+L));
      elif g.a0 >= s: Bcopy = b_seq[g.b0 - (g.a0 - s) - L : g.b0 - (g.a0 - s)]  (image of T1 = A[s-L, s));
      else unknown. tsd_mm = min(Hamming(Bcopy, A[s-L:s]), Hamming(Bcopy, A[t:t+L])) when lengths are L, else None.
      allowance = max(1, floor(L * ((e.k or 0) + d) + 0.5)), d = 1 - ident (0 if nan). Flag tsd_match if tsd_mm is not
      None and tsd_mm <= allowance.
5. Otherwise PRESENT branch (coverages exclude children spans; LTR intervals from ltr_left/ltr_right converted to window
   coordinates):
   P if cov_left >= COV_PRESENT and cov_right >= COV_PRESENT and cov_elem >= COV_PRESENT (+ flag nestB if any
     aln.b_gaps_within(s, t) has b1 - b0 >= MIN_SEG);
   elif internal aligned bp < max(MIN_SEG, (1 - COV_PRESENT) * len(internal)) and
     SOLO_LEN[0]*mean_ltr <= (left+right LTR aligned bp) <= SOLO_LEN[1]*mean_ltr -> S (+ flag solo_tsd if
     aln.aligned_bp(s-L, s) >= L-1 and aln.aligned_bp(t, t+L) >= L-1);
   else T.
Tier: placement = (win.margin >= MARGIN_HIGH) and (ident >= IDENT_MIN); evidence = P: True | S: solo_tsd |
  E: tsd_match | D: refined | T, O: False. high if both, medium if one, low if neither; G and U get ".".
Flag inv on every call from a strand -1 window.
B coordinates (genome, 1-based inclusive; strand -1: genome = win.b_end - 1 - local, intervals flipped):
  P/S/T: [min, max] of a2b over aligned positions in [s, t); E: the B TSD copy; D: the last aligned B base before the gap
  and the first after (g.b0 - 1 and g.b1, as a 2-base interval); O: the B insertion [g.b0, g.b1); G/U: None.
  b_strand = "+" for strand 1, "-" for strand -1, None for U/G without a site.
Evidence (`ev`): cov_left, cov_right, cov_int, cov_elem, dl (dl'), dr (dr'), b_ins, tsd_a (A's TSD string),
  tsd_b (B copy or None), tsd_mm, ident, anchor_left, anchor_right, margin (from the window), reason.
`call_row(call, e, win)` returns a dict keyed by CALL_COLUMNS with raw Python values (None where absent; flags as a
  comma-joined string or None); formatting to TSV happens in a later task.
DESIGN.md 5.4: add (1) the TSD allowance max(1, floor(L*(K + d) + 0.5)) with d = local A-B divergence, (2) "E/D is
  evaluated on the balanced placement within the deletion's equivalent-placement range", (3) the exact TSD-copy read.
