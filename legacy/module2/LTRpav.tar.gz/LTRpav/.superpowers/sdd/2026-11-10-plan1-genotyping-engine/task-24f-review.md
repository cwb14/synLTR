# Task 24F review: syntenic anchor net and adaptive chunking

- Range: `bfeeb55..8dfc012`, one commit: "Make the anchor net syntenic and chunk windows adaptively".
- Inputs: the review diff, plus one focused check per named risk.
- Probes: `/data2/chris/maize_introgression/benchmark_pav/bakeoff/review24f/` (`probe_minus.py`, `probe_perf.py`,
  `probe_dense.py`). They ran with Python bytecode writing off and numba's cache sent to that directory.
- The review changed nothing in the checkout: `git status` was empty after the probes and the ruff run.
- **Another writer is editing the checkout.** At 07:39:38-07:39:42, uncommitted edits appeared in
  `src/ltrpav/classify.py` and `docs/DESIGN.md`: a new present-call rule 5a, "U unanchored". They did not come
  from this review and are not part of `bfeeb55..8dfc012`. HEAD is still `8dfc012`. They are left untouched and
  were not reviewed.

## Spec Compliance

**Verdict: ✅ compliant.** Nothing is missing or misunderstood. The two extras are small and justified.

### `src/ltrpav/chain.py`
- ✅ **Unchanged parts.** The chain order (lexsort at chain.py:301), `_credit`, `_trim` and `_Claims` appear in
  the diff only as context lines.
- ✅ **Parents.** `_Extents.innermost` (chain.py:582) returns the shortest kept extent that contains the span.
  On a tie it returns the extent filed first, which belongs to the better chain.
  - Extents come from kept pieces only: `kept.add` (chain.py:370) runs after the test, on the survivors.
  - The tested chain's own pieces are never their own parents: the chain is filed only after its test.
- ✅ **(a), (b) and (c) in each frame.**
  - `_place` (chain.py:535-558) applies (a) and (b). Test (b) checks the parent's sequence in the other genome,
    then the gap between the parent's two pieces that flank the piece. The strand decides syn or inv.
  - Test (c) is applied at chain.py:347. It runs over every trimmed piece, against the same kept set.
- ✅ **Keep and drop.**
  - A piece is kept only with support in both frames.
  - A dropped piece claims nothing.
  - Its credit was recorded during trimming, before the test, so it stands.
  - MIN_CHAIN_SCORE is applied again to the survivors.
- ✅ **No new parameter, threshold, slop or size escape.** `_BUCKET_BITS` is reused as the index's bucket size.
  It does not change the rule.
- ✅ **Docstring and logging.**
  - The docstring states the rule, both named costs and the complexity (chain.py:276-295).
  - One INFO line is logged per net, with the requested fields. The (A place, B place) cross-tab goes to DEBUG.
- **Extra 1: fail-fast `ValueError` for a chain over several sequences or strands** (chain.py:302-306).
  Acceptable:
  - the index needs the check;
  - `chain_blocks` never produces such a chain;
  - both callers, `anchor/__init__.py:139` and `anchor/flanks.py:274`, pass `chain_blocks` output.
- **Extra 2: chains below MIN_CHAIN_SCORE before the test are dropped untested.** Acceptable: matches are
  non-negative, so drops cannot raise the sum, and the outcome is identical.

### `src/ltrpav/anchor/__init__.py`
- ✅ `"net": "syntenic"` is in `_CHAIN_PARAMS`.
- ✅ The anchor stage key includes `_CHAIN_PARAMS` (anchor/__init__.py:126-127).

### `src/ltrpav/genotype.py` and `src/ltrpav/constants.py`
- ✅ `_chunk_size` is the brief's formula. It is the only place in the package that chunks windows (grep of
  `src/`).
- ✅ CHUNK_MIN and CHUNK_TARGET each carry a one-line reason, and CHUNK_WINDOWS is now described as the cap.
- ✅ The MAPPY_BEST_N comment says what the brief asked: 5 is minimap2's generic -N, the asm presets use 50, and
  mm2_N50 tests the choice.

### `docs/DESIGN.md`
- ✅ 5.1 now describes the syntenic net, with the three citations and the two named costs.
- ✅ 5.3's "long join" wording is fixed.
- ✅ 5.4 no longer lists `boundary_offset`. The new `dl`/`dr` sentence is accurate: classify.py:182-187 defines
  them as the junction overhangs.

### Tests
- ✅ Every case in the brief is present:

  | Brief's case | Test |
  |---|---|
  | paralog fill | `drops_paralog_fill_out_of_place_in_both_genomes` (both strands) |
  | in-gap syn and inverted fills | `keeps_fill_in_its_parents_gap` |
  | top level in both genomes | `keeps_chain_top_level_in_both_genomes` |
  | crept-in inversion | `keeps_crept_in_inversion_by_chain_support` |
  | leak | `drops_leak_into_uncovered_b` |
  | short transposition | `drops_short_transposition` |
  | dropped credit | `dropped_piece_still_lowers_margin` |
  | margins unchanged without drops | `net_without_drops_equals_the_flat_net` |
  | performance | `net_50k_blocks_in_seconds` |
  | old-cache recompute | `test_anchors_from_the_flat_net_are_recomputed` |
  | 1 and 3 threads byte for byte | `test_calls_do_not_depend_on_threads_or_chunks` |
  | chunk sizes | `test_chunk_size`: n = 0, 1, 100, 5,600, 60,000, plus 10^6 |

- I traced the expected spans and INFO tuples of the crept-in, paralog, transposition and margin cases by hand.
  All of them match the rule.
- One existing assertion was loosened, with a sound reason: the random paralogs are now dropped. The old
  invariants moved into `_check_net`, so nothing was lost.

### Named risks (one focused check each)
1. **Parent lookup.**
   - The lookup runs on the piece's own sequence in each frame (`self.a.get(pc[0])`, `self.b.get(pc[3])`).
   - Extents that overlap without nesting are handled: `innermost` takes the smallest of all containing extents.
   - The minus-strand gap (chain.py:555) is `[right.end, left.start)` in the other genome, which is correct in
     both frames.
   - `probe_minus.py` used a minus-strand parent:
     - a same-strand fill in its gaps is kept as syn;
     - an opposite-strand fill is kept as inv;
     - a fill whose B lies past the parent is dropped;
     - a fill whose B is top level but whose A is out of place is dropped.

     All four outcomes are as derived by hand.
   - The indexing `pieces[i - 1]`, `pieces[i]` is always in range: `_trim` cuts the A span from free A and the B
     span from free B. So a trimmed piece never overlaps a kept piece, and a contained piece always sits strictly
     between two parent pieces.
2. **Chain-level support.** `top_a` and `top_b` are computed from all trimmed pieces, before any drop and before
   the chain is filed (chain.py:346-347).
3. **MIN_CHAIN_SCORE and credit.**
   - The threshold is applied to the kept pieces.
   - `_credit` runs for every block before the test.
   - `dropped_piece_still_lowers_margin` pins the margins at 1 - 9000/149000.
4. **Cache keys.**
   - **Hybrid route.** It sets `whole_genome = False`, so its raw blocks are never cached. Its provisional net
     (flanks.py:274) runs inside `raw_blocks`, and only the final anchors are cached, under the new key. The
     primary route's "raw" cache does not depend on the net.
   - **Stage keys.** The package's stage keys are elements, raw, anchor, genotype_pair, genotype_chunk, blastdb
     and mm2_index. Only anchor and the two genotype keys come after the net, and the genotype keys include the
     anchors checksum.
   - **Chunks.** A chunk key holds the chunk index, its first and last wid, and the windows checksum, so a
     matching key means identical windows. `_merge` reads only the current chunk list (genotype.py:111). Stale
     chunk files from another chunk size never enter a calls file.
5. **Index complexity.**
   - A containing extent [s, e) satisfies s <= start <= e - 1, so it is filed in the bucket of `start`.
   - Buckets are append-only, in filing order. Adding chains between queries therefore needs no re-sort, and
     ties keep going to the better chain.
   - The cost per query is O(extents in that bucket), as the docstring says.
   - Measured: the perf-test fixture nets in 1.05 s, with at most 5 extents per bucket (1.55 on average).

### ⚠️ Not verifiable from the diff
- **The gate:** both `batch.exit` files and an empty `pgrep` before the repo was touched.
- **Full suite under `-W error`** (726 passed): not re-run, as instructed. `ruff check --no-cache` on the seven
  changed Python files passes.
- **Real-data numbers.** I checked two things only:
  - The report's window table is identical to `task24f_scratch/probe/realcheck_windows.tsv`.
  - On B73v5 -> TIL18 it agrees with the prototype's `m1_net_stats.tsv`:
    - the new net's syn 120 and inv 44 equal the prototype's post-hoc syn 120 and inv_in 44;
    - the 167-piece shortfall matches the 170 one-frame pieces that the report names.
- **The probes' thread caps.**

**Note for the controller** (literal to the spec; no action needed):
- Rule (c) counts any trimmed piece with no parent, including one that is itself dropped for lack of support in
  the other frame.
- That follows the brief ("at least one trimmed piece with no A-parent").
- A stricter reading, "a kept top-level piece", would differ in rare chains.

## Strengths
- **The corrected rule is implemented exactly and compactly.**
  - `_place` transcribes (a) and (b) directly, with the strand-aware gap.
  - The chain-level step is two lines.
  - The docstring states the rationale, the costs and the complexity without hedging.
- **The exactness argument is correct and load-bearing.** A trimmed piece never overlaps a kept piece, so
  containment is all or nothing. That keeps the rule free of slop and makes the neighbor lookup safe.
- **The extent index fits the existing design.** It reuses `_Claims`' bucket scheme and is append-only, which
  suits a net that grows chain by chain. Its tie-breaking matches the oracle.
- **The tests go beyond the brief.**
  - A brute-force oracle matches the net byte for byte on seven fixtures. These cover all four kinds of support
    and more than 100 drops.
  - Each named case asserts exact spans and the INFO tuple.
  - The crept-in inversion test reproduces the diagnosis's structure piece by piece.
  - The implementer ran a mutation check against four mutant nets.
- **The real-data check is careful.**
  - It has a control: the flat net reproduces the batch's cached anchors byte for byte.
  - The numbers agree with the prototype's own statistics.
  - The "Unknown" section is candid.
- **Chunking is handled with care.**
  - The chunk size depends on constants only, never on the thread count.
  - A test resumes at another thread count.
  - The report notes the bake-off harness's `--chunk-windows` semantics.
- **The commit is clean.**
  - It is one commit with the requested subject and the user's identity.
  - It has no trailers or attribution.
  - The branch has no remote, so nothing was pushed.

## Issues

### Critical
None.

### Important
None.

### Minor
1. **The A-scaffold mirror of the second named cost is not documented.**
   - Where: chain.py:286-289 and docs/DESIGN.md:172-174.
   - What: the rule is symmetric. A chain on an unplaced A scaffold is top level in A. If its B side lies in the
     gap of a B chromosome chain, it is out of place in B and has no top-level B piece, so it is dropped.
     `test_net_drops_chain_top_level_in_a_only` (tests/test_chain.py:663) has exactly this structure, and the
     report's concern 2 says so. The docstring and DESIGN name only the B-scaffold side.
   - Why it matters: unplaced scaffolds are usually chromosome sequence that the assembler left unplaced. On a
     scaffold-rich A assembly, this cost falls on real orthologs.
   - Fix: state the cost for both genomes in both places, for example "an ortholog on an unplaced scaffold of
     either genome whose other side lies in a chromosome chain's gap". Task 25 should count these losses.
2. **DESIGN 5.1 and the module docstring state test (b) loosely.**
   - Where: docs/DESIGN.md:168 ("inside its parent chain's gap there") and chain.py:5-6 (the same phrase,
     without "there").
   - What: read with "there" as the same genome, every piece with a parent passes, because a trimmed piece
     always sits in one of its parent's gaps in that genome. The real test is that the piece's span in the other
     genome lies in the parent's matching gap. Readers who know UCSC nets will take "gap" as the paired gap, but
     DESIGN is the spec of record.
   - Fix: write "or its span in the other genome lies inside the parent's matching gap (collinear or inverted)".
     The `net_blocks` docstring (chain.py:276-280) is already precise.
3. **No test pins the gap orientation for a minus-strand parent.**
   - Where: tests/test_chain.py:612-620.
   - What: the in-gap cases use a plus-strand parent only. Minus-strand parents appear only in
     `_genome_blocks`, which is checked against `_brute_place`. That oracle copies the `g0, g1` formula of
     chain.py:555, so a formula wrong in both places would pass.
   - Why it is minor: `probe_minus.py` shows the implementation is right, so this is regression protection only.
   - Fix: add a minus-strand parent to `test_net_keeps_fill_in_its_parents_gap`:
     - parent pieces L = A[0,50k) -> B[100k,150k) and R = A[100k,150k) -> B[0,50k), both on the minus strand;
     - the fill A[52k,55k) -> B[53k,56k) on the minus strand is kept as syn;
     - the same fill on the plus strand is kept as inv.
4. **The fast performance test does not load the index.**
   - Where: tests/test_chain.py:709-716.
   - What:
     - 60k blocks spread over 5,000 sequence pairs leave about 1.5 kept extents per bucket (at most 5).
     - With few sequences, the syntenic net keeps only about 13 chains of `_random_blocks` (`probe_perf.py`), so
       the slow 1e6 test does not load the index either.
     - So a regression to a scan of a sequence's kept chains would pass both tests. A whole genome has about
       10^3 kept chains per chromosome, so that regression would break the brief's "well under a minute". Only
       the FastGA timing, run outside the suite, covers it.
   - Fix: time a fixture with thousands of kept chains on one sequence, for example a long collinear run with
     thousands of in-place fills nested in its gaps.
5. **Two logging nits.**
   - The DEBUG line (chain.py:390) prints the number of cut chains as "%d lost pieces". That reads as a piece
     count. Write "%d cut" or "%d chains lost pieces".
   - The INFO line (chain.py:384) carries no pair label. The hybrid route nets twice per direction: once for its
     provisional windows (flanks.py:274), then again in `anchor_pair`. So its log shows two indistinguishable
     "syntenic net:" lines. Pass a label, or log the provisional net at DEBUG.

**Pre-existing, not counted:** `test_fail_fast_on_missing_binary[flank-blast-makeblastdb]` needs blastn on PATH
(see the report's Tests section). It fails at bfeeb55 too.

## Assessment
**Task quality: Approved.**
- **Rule:** the corrected rule is implemented exactly, with no new parameter. The parent and gap lookups are safe
  by construction and indexed.
- **Tests:** every case in the brief is covered, and an independent oracle checks the net.
- **Caches:** the cache-key change reaches every cache after the net. The chunking cannot change the calls.
- **The five Minor items** are documentation and test hardening. None of them affects the anchors or the calls.
