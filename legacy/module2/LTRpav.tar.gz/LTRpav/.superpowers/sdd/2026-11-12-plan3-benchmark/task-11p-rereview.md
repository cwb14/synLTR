# Task 11P minors re-review
### Findings
- m2: ADDRESSED. eval_run.py:579-600 and eval_ltrmix.py:394-408 (both inside the `if not truth` / empty-truth branch only, so no field of a positive-truth run changes). Both set bp_called (merged bp, same formula as accuracy() at eval_run.py:557), bp_true_positive 0, bp_precision 0 (NA "no called tract" if nothing is called), precision_by_length with 0 or NA per bin; recall, AUROC, recall_by_length stay NA. Tests assert exact values in both tools.
- m4: ADDRESSED. summarize.py:933-934: `not nc.n_required` gives NA "no C>A power run in the grid". n_required = values+na+missing, so it is 0 only with no power run at all; a decided FAIL needs at least one run, so it cannot be masked. Test test_summarize.py:561-571.
- m5: ADDRESSED. rescore_all.sh need_value (exit 2 via usage) used for all four value options, empty value too. Tests (test_rescore_all.py) cover each option and empty --names.
- m6: ADDRESSED. rescore_all.sh: --names with summarize on sets SUMMARIZE=0 and one note (dry run and log). Tests check no tables command, one note, tables dir not created, full rescore still runs it.
- m7: ADDRESSED. (a) test_eval_ltrmix.py:237-253 no elements file; (b) test_eval_run.py sheet-order recipient with empty truth; (c) test_summarize.py:553-558 present-but-NA run.
- m8: ADDRESSED. test_summarize.py:571-573 has two blank lines before def (checked with cat -A; flake8/pycodestyle not installed).
Run: pytest -W error on test_eval_run, test_eval_ltrmix, test_summarize, test_rescore_all: 49 passed. The new tests assert values the old code produced as NA, or exit 1 / ran tables, so they fail without the fixes (read, not re-run against old code).
### New Issues in the Fix Diff
None Critical or Important. Minor: none found.
### Out-of-Scope Observations
- eval_ltrmix inlines the precision_by_length wrapper where eval_run uses bins_out (same result).
- memo.md says 75 tests pass across the full list; I ran only four files (49).
### Verdict: Approved
