"""Analysis stages of a finished run: stats and paint, their checkpoints, their parts under
work/analysis/, the assembly of stats.tsv and findings.txt, and the plot stage that draws the overview figure.

Stages (STAGES, in order), each on the run's catalog (`catalog.load_catalog`, loaded once for both):
  stats  `run_stats`: the run summary and relationships; the trios (roles), then each trio's tests; the
         inverted blocks (inversions.tsv) and their rows; direction; mechanisms (mechanisms.tsv); with
         --identity, the sequence-identity layer of each trio (identity.tsv). Without --identity a stale
         identity.tsv is deleted.
  paint  `run_paint`: the trios again (from the PAV distances: their rows and findings are the stats part's),
         the inverted blocks, identity.tsv's self rows when that file exists, then each trio's painting
         (tracts.<R>.bed, posterior.<R>.tsv, decoy_tracts.<S>.bed, decoy_posterior.<S>.tsv).
Each stage writes its part: work/analysis/<stage>.rows.tsv (STATS_COLUMNS, `stats.write_stats`) and
<stage>.findings.tsv (section, line). The plot stage (PLOT, after the assembly; `run_plot`) draws the overview
from the assembled files and the catalog (ltrpav.plot.overview: overview.png, overview.pdf,
overview_numbers.tsv) and has no part; it refuses to draw (`plot_refusals`) unless the stats part is finished,
current and in stats.tsv itself, and the paint part too once it has finished: a stale part's rows may still be in
stats.tsv, made before the run or the code changed (LASTZ's version is not compared there: the figure never runs
it), and a part missing from it would make the figure misstate the run. stats.tsv says which parts it holds in one
sentinel row per part (`assemble`), so the check reads no other file.

Checkpoints (checkpoint.py's protocol, run by `run_stage`). A stage's key is
stage_key(stage, inputs, params, fingerprint=analysis_fingerprint(stage)):
  inputs  `stage_inputs`: the checksums of the engine outputs the stage reads, cached in work/checksums.json:
          the samples sheet (Catalog.sheet_sha), loci.tsv, qc.tsv ("absent" without one), every element table
          and pair file, and a digest of each genome's sequence names and lengths in fai order (what the
          analyses read from the FASTA indexes; where an index lies and its offsets do not matter); the stats
          stage adds the FASTAs with --identity, the paint stage identity.tsv when it exists, the plot stage
          identity.tsv, the result files it draws and every FASTA.
  params  `stage_params`: --trio, and whether the identity layer is used (stats: --identity; paint: identity.tsv
          exists; plot: --trio only). With --identity, the aligner and its version (`localign.backend_version`):
          LASTZ is a program outside every fingerprint. Then the stage's own options (OPTIONS): stats
          block_size (--block-size; null: the rule of `stats.block_size`, which the fai digests already key).
          Each is in its key at every value, the default included.
  code    `analysis_fingerprint`: the analysis package (the plot stage adds ltrpav.plot) and ENGINE_MODULES, the
          engine modules the analyses run: the static import closure of the engine modules the analysis and
          plot packages import (tests/test_cli_analysis.py keeps it so). Two engine files are outside it:
          ltrpav/__init__.py (the version, in every key anyway) and ltrpav/cli.py, the engine's command layer,
          which analysis/cli.py takes its parsers, logging and exit status from; no analysis output depends on
          it, and the engine leaves its own CLI out of every stage set alike. Never an engine stage's
          fingerprint: an analysis edit changes no engine stage key, and an engine edit reruns an analysis only
          through a module it runs or an output it reads.
A stage whose marker, work/analysis/<stage>.done.json, holds the current key is skipped ("<stage>: done, skip",
logger ltrpav.analysis). The marker lists exactly the files the stage writes (`run_stats`, `run_paint`,
`run_plot`), so a skip is checked against them; its meta records the options the stage ran with (--trio, --identity
and the stage's OPTIONS). A stage run with other options reruns and overwrites its part and files: a run directory
holds one painting, the one its paint marker names. No engine-fingerprint check is ever made: a run finished by an
older engine is read as it stands.

Assembly (`assemble`). stats.tsv and findings.txt are rebuilt from the parts of the finished stages whose key is
still current. A part without a marker (its stage is being rewritten, or failed) is left out; so is one whose
marker no longer holds the key the stage would have now (`stale_parts`: the key recomputed from the options its
marker recorded, --trio, --identity and the stage's OPTIONS, an option the marker lacks read as its default),
because the samples sheet, an engine output it read (identity.tsv
included, which the stats stage writes or deletes), the analysis code, LASTZ's version or the files it wrote
changed since: one WARNING names it and why, in the log and in findings.txt, until its stage reruns. Every
stage reassembles both files and no marker lists them, so a later stage never breaks an earlier one's skip.
Parts made with different --trio options are joined, with a WARNING.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import time
from pathlib import Path

from .. import __version__
from ..checkpoint import (
    CHECKSUM_CACHE,
    atomic_path,
    atomic_write,
    clear_done,
    done_meta,
    file_checksum,
    is_done,
    mark_done,
    marker,
    package_fingerprint,
    stage_key,
)
from ..constants import DEFAULT_BACKEND
from ..localign import backend_version
from ..samples import PAIR_SEP
from .catalog import AnalysisError, Catalog
from .direction import direction
from .identity import IDENTITY_COLUMNS, write_identity
from .identity import SECTION as IDENTITY_SECTION
from .identity import identity as identity_layer
from .inversions import inversion_rows, inverted_blocks, write_inversions
from .mechanisms import mechanisms, write_mechanisms
from .paint import PAINTING_FILES, paint, paint_rows, write_paintings
from .relations import pav_distances, relations, run_summary
from .stats import (
    PART,
    SECTIONS,
    STATS_COLUMNS,
    Findings,
    StatRow,
    block_size,
    format_row,
    read_stats,
    write_stats,
)
from .trio import trio_tests, trios

log = logging.getLogger("ltrpav.analysis")

STAGES = ("stats", "paint")
# the engine modules the analyses run: the static import closure of the engine modules imported by the analysis
# and plot packages, less ltrpav/__init__.py and ltrpav/cli.py (module docstring); tests keep it so
ENGINE_MODULES = ("ltrpav.anchor", "ltrpav.blocks", "ltrpav.chain", "ltrpav.checkpoint", "ltrpav.classify",
                  "ltrpav.constants", "ltrpav.elements", "ltrpav.genotype", "ltrpav.junction", "ltrpav.localign",
                  "ltrpav.samples", "ltrpav.seqio", "ltrpav.window")
PLOT = "plot"  # the figure's stage (ltrpav.plot.overview): no part; its fingerprint adds the ltrpav.plot package
# each stage's options beyond --trio and --identity, with their defaults: stats --block-size (None: the
# block-size rule); paint and plot have none
OPTIONS = {"stats": {"block_size": None}, "paint": {}, PLOT: {}}
_RESULTS = ("stats.tsv", "findings.txt", "inversions.tsv", "mechanisms.tsv")  # the run files the figure reads
_SIDE_FILES = ("inversions.tsv", "mechanisms.tsv", "identity.tsv")  # what the stats stage writes beside its part
WORK = Path("work") / "analysis"  # the parts and markers, under the run directory
_FINDINGS_HEADER = "section\tline"
# assemble's line for a part it leaves out (findings.txt, Run and Warnings); stats.tsv says it in a sentinel row
_LEFT_OUT = "WARNING: the {stage} part is left out of this file and stats.tsv: {why}; rerun {advice}"
_IDENTITY_LINE = ("Counts of shared insertions younger than the split need the sequence-identity "
                  "layer: rerun ltrpav-stats with --identity")


# ---------------------------------------------------------------- keys


def analysis_fingerprint(stage: str) -> str:
    """package_fingerprint of the analysis package and ENGINE_MODULES; the plot stage adds ltrpav.plot. Not the
    engine's checkpoint.stage_fingerprint, which covers engine stages only."""
    if stage not in (*STAGES, PLOT):
        raise ValueError(f"no analysis stage {stage!r}: {', '.join((*STAGES, PLOT))}")
    extra = ("ltrpav.plot",) if stage == PLOT else ()
    return package_fingerprint("ltrpav.analysis", *ENGINE_MODULES, *extra)


def stage_inputs(cat: Catalog, stage: str, identity: bool) -> dict[str, str]:
    """Input name -> sha256 of what the stage reads (module docstring): "samples" (the sheet), the run's files
    by their path relative to the run directory ("loci.tsv", "qc.tsv", "work/elements/<A>.tsv",
    "pairs/<A>__<B>.calls.tsv.gz", and for paint and plot "identity.tsv" when it exists), "fai:<label>"
    (sequence names and lengths) and, for stats with --identity, "fasta:<label>". The plot stage adds the
    result files it draws (stats.tsv, findings.txt, inversions.tsv, mechanisms.tsv, each genome's painting
    files that exist) and every FASTA (its base-pair panel reads them)."""
    if stage not in (*STAGES, PLOT):
        raise ValueError(f"no analysis stage {stage!r}: {', '.join((*STAGES, PLOT))}")
    out, cache = cat.outdir, cat.outdir / "work" / CHECKSUM_CACHE
    annotated = [a for a in cat.labels if cat.annotated[a]]
    files = [out / "loci.tsv", out / "qc.tsv", *(out / "work" / "elements" / f"{a}.tsv" for a in annotated),
             *(out / "pairs" / f"{a}{PAIR_SEP}{b}.calls.tsv.gz" for a in annotated for b in cat.labels if b != a)]
    if stage in ("paint", PLOT) and (out / "identity.tsv").is_file():
        files.append(out / "identity.tsv")
    if stage == PLOT:
        files += [out / f for f in _RESULTS]
        files += [p for x in cat.labels for f in PAINTING_FILES if (p := out / f.format(x)).is_file()]
    inputs = {"samples": cat.sheet_sha}
    for p in files:
        inputs[p.relative_to(out).as_posix()] = file_checksum(p, cache) if p.is_file() else "absent"
    for x in cat.labels:
        lines = "".join(f"{name}\t{n}\n" for name, n in zip(cat.seqids[x], cat.lengths[x].tolist(), strict=True))
        inputs[f"fai:{x}"] = hashlib.sha256(lines.encode()).hexdigest()
    if stage == "stats" and identity:
        for s in cat.samples:
            inputs[f"fasta:{s.label}"] = file_checksum(s.fasta, cache)
    elif stage == PLOT:  # a FASTA that cannot be read only omits the base-pair panel
        for s in cat.samples:
            inputs[f"fasta:{s.label}"] = _plot_checksum(Path(s.fasta), cache)
    return inputs


def _plot_checksum(path: Path, cache: Path) -> str:
    """A FASTA's checksum for the plot key: "absent" when it is gone, "unreadable" when it cannot be read (the
    figure then omits its base-pair panel), else its sha256."""
    if not path.is_file():
        return "absent"
    try:
        return file_checksum(path, cache)
    except OSError:
        return "unreadable"


def stage_options(stage: str, given: dict | None = None) -> dict:
    """The stage's OPTIONS: each name's value in `given` (the command's options, or a marker's meta), read with
    .get(name, default), so an option not given is its default; names of other stages are dropped."""
    if stage not in OPTIONS:
        raise ValueError(f"no analysis stage {stage!r}: {', '.join((*STAGES, PLOT))}")
    given = given or {}
    return {name: given.get(name, default) for name, default in OPTIONS[stage].items()}


def stage_params(cat: Catalog, stage: str, trio: tuple[str, str, str] | None, identity: bool,
                 tools: dict | None = None, options: dict | None = None) -> dict:
    """The stage's parameters (module docstring): trio (null: roles from the data) and identity; with
    --identity, the stats stage adds the aligner and its version, probed (`localign.backend_version`) unless
    `tools` gives it: a marker's recorded params, whose "backend_version" is then taken as it stands. Then the
    stage's options (`stage_options(stage, options)`): stats block_size."""
    params: dict = {"trio": None if trio is None else list(trio)}
    if stage == "stats":
        params["identity"] = bool(identity)
        if identity:
            params["backend"] = DEFAULT_BACKEND
            params["backend_version"] = (backend_version(DEFAULT_BACKEND) if tools is None
                                         else tools.get("backend_version"))
    elif stage == "paint":
        params["identity"] = identity_usable(cat)[0]   # the painting reads identity.tsv only when it is current
    elif stage != PLOT:
        raise ValueError(f"no analysis stage {stage!r}: {', '.join((*STAGES, PLOT))}")
    params.update(stage_options(stage, options))
    return params


def _check_options(cat: Catalog, stage: str, options: dict) -> None:
    """A ValueError for an option the stage cannot run with (the commands' parsers refuse them first), before its
    marker is cleared."""
    if stage == "stats":
        block_size(cat, options["block_size"])


def run_stage(cat: Catalog, stage: str, trio: tuple[str, str, str] | None, identity: bool, threads: int,
              options: dict | None = None) -> bool:
    """Run one stage (run_stats, run_paint or run_plot) unless its marker holds the current key; True when it
    ran. options: the stage's OPTIONS (`stage_options`; None, or a name left out: its default), so one dict can
    serve every stage. The marker is cleared first and written last, listing the files the stage wrote; its meta
    records the options (trio, identity and the stage's OPTIONS) and what the key was made of (inputs, params,
    code), so `stale_parts` can recompute the key and say what changed."""
    done = marker(cat.outdir / WORK / stage)
    opts = stage_options(stage, options)
    _check_options(cat, stage, opts)
    inputs = stage_inputs(cat, stage, identity)
    params = stage_params(cat, stage, trio, identity, options=opts)
    code = analysis_fingerprint(stage)
    key = stage_key(stage, inputs, params, fingerprint=code)
    if is_done(done, key):
        log.info("%s: done, skip", stage)
        return False
    previous = _listed(done)   # what the stage's last run wrote (the paint stage removes its own)
    clear_done(done)
    t0 = time.perf_counter()
    log.info("%s: running", stage)
    if stage == "stats":
        written = run_stats(cat, trio, identity, threads, opts["block_size"])
    elif stage == "paint":
        written = run_paint(cat, trio, previous)
    else:
        written = run_plot(cat, trio)
    meta = {"trio": params["trio"], "identity": bool(identity), **opts, "inputs": inputs, "params": params,
            "code": code}
    mark_done(done, key, written, meta=meta)
    log.info("%s: done in %.1f s", stage, time.perf_counter() - t0)
    return True


def stale_parts(cat: Catalog, warn: bool = True, probe_tools: bool = True) -> dict[str, str]:
    """Stage -> why its part must stay out of stats.tsv and findings.txt: its marker no longer holds the key the
    stage would have now, recomputed from the options the marker recorded (--trio, --identity and the stage's
    OPTIONS, each read with .get(name, default): module docstring). Stages without a marker have no part and are
    absent. warn: log each stale part (WARNING; the assembly's message); the plot stage, which refuses instead,
    passes False. probe_tools: take the external tools' versions as installed now (LASTZ's, for an --identity
    stats part), so a new or missing LASTZ makes the part stale, as the stats and paint commands' assembly does;
    False takes the versions the marker recorded and probes no tool, so only the run's files, the options and the
    analysis code are compared: the plot stage's check, which draws without LASTZ and guards against analyses
    drawn on a changed run or code."""
    out = {}
    for stage in STAGES:
        why = _stale(cat, stage, probe_tools)
        if why is None:
            continue
        out[stage] = why
        if warn:
            log.warning("%s: its part is left out of stats.tsv and findings.txt until the %s stage reruns, with "
                        "%s: %s%s", stage, stage, _rerun_advice(cat.outdir, stage), why, _side_note(cat.outdir, stage))
    return out


def _stale(cat: Catalog, stage: str, probe_tools: bool) -> str | None:
    """Why the stage's finished part is stale (`stale_parts`); None when it is current or has no marker."""
    done = marker(cat.outdir / WORK / stage)
    meta = done_meta(done)
    if meta is None:
        return None
    trio, identity = meta.get("trio"), bool(meta.get("identity"))
    trio = tuple(trio) if isinstance(trio, list) and len(trio) == 3 else None
    recorded = meta.get("params") if isinstance(meta.get("params"), dict) else {}
    inputs = stage_inputs(cat, stage, identity)
    params = stage_params(cat, stage, trio, identity, None if probe_tools else recorded,
                          stage_options(stage, meta))
    code = analysis_fingerprint(stage)
    if is_done(done, stage_key(stage, inputs, params, fingerprint=code)):
        return None
    return _changed(stage, meta, inputs, params, code)


def _rerun_advice(outdir: Path, stage: str) -> str:
    """The command that remakes a stale part, naming the options its marker recorded when they are not the
    defaults, so that following it makes the same variant (`ltrpav-stats --block-size N`). `ltrpav run` takes no
    stage options and remakes the part at the defaults, which the advice then says."""
    meta = done_meta(marker(Path(outdir) / WORK / stage))
    given = stage_options(stage, meta)
    flags = "".join(f" --{name.replace('_', '-')} {given[name]}" for name, default in OPTIONS[stage].items()
                    if given[name] != default)
    if not flags:
        return f"ltrpav-{stage} (or ltrpav run)"
    return f"ltrpav-{stage}{flags} (ltrpav run remakes it at the defaults)"


def _side_note(outdir: Path, stage: str) -> str:
    """For a stale stats part, the side files written with it, stale too; "" otherwise."""
    side = [n for n in _SIDE_FILES if (Path(outdir) / n).is_file()] if stage == "stats" else []
    if not side:
        return ""
    names = side[0] if len(side) == 1 else ", ".join(side[:-1]) + " and " + side[-1]
    return f"; {names}, written with that part, {'is' if len(side) == 1 else 'are'} stale too"


def identity_usable(cat: Catalog) -> tuple[bool, str | None]:
    """Whether the paint stage may read identity.tsv: the file exists and the stats part that
    wrote it is finished and current by the run's files, options and code (`stale_parts` without probing tools:
    LASTZ's version renumbers no locus). Lids follow loci.tsv's order, so an identity.tsv from before the run
    changed would give other loci's counts. (False, why) when the file exists but is not usable; (False, None)
    without the file."""
    if not (cat.outdir / "identity.tsv").is_file():
        return False, None
    if done_meta(marker(cat.outdir / WORK / "stats")) is None:
        return False, "the stats stage that writes it has not finished"
    why = _stale(cat, "stats", probe_tools=False)
    return (True, None) if why is None else (False, f"the stats part that wrote it is stale ({why})")


def assembled_parts(path: Path) -> dict[str, tuple[str, str]]:
    """Stage -> (statistic, value) of stats.tsv's sentinel row for that stage's part (`assemble`): ("key", the
    stage key the part was made under; its rows follow) or ("left_out", why the part is not there). A stage without
    a sentinel is absent: its part was not assembled (its stage had not finished)."""
    return {r.scope: (r.statistic, str(r.value)) for r in read_stats(path) if r.test == PART}


def plot_refusals(cat: Catalog) -> dict[str, str]:
    """Stage -> why the plot stage must not draw from stats.tsv, from the markers and
    stats.tsv's own sentinel rows, never from findings.txt:
      stats  must be finished (a marker), current by `stale_parts` with the tool versions its marker recorded
             (drawing runs no tool), and in stats.tsv under its marker's key: without its rows the figure would
             show no trio;
      paint  likewise whenever its stage has finished, or stats.tsv holds a painting: a painting is drawn only
             from current rows. A run never painted draws no painting, and says so.
    {} when the figure may be drawn."""
    stale = stale_parts(cat, warn=False, probe_tools=False)
    parts = assembled_parts(cat.outdir / "stats.tsv")
    out: dict[str, str] = {}
    for stage in STAGES:
        done = marker(cat.outdir / WORK / stage)
        got = parts.get(stage)
        if stage in stale:
            out[stage] = stale[stage]
        elif done_meta(done) is None:
            if stage == "stats" or (got is not None and got[0] == "key"):
                out[stage] = "its stage has not finished (it never ran, failed or was interrupted)"
        elif got is None:
            out[stage] = ("stats.tsv does not hold it (assembled before that stage finished, or its "
                          "sentinel row is missing)")
        elif got[0] == "left_out":
            out[stage] = f"left out when stats.tsv was last assembled: {got[1]}"
        elif got[1] != _marker_key(done):
            out[stage] = "stats.tsv holds an earlier run of it (assembled before that stage last finished)"
    return out


def _listed(marker: Path) -> list[Path]:
    """The files a done marker lists (each relative to the marker's directory); [] without a readable marker."""
    try:
        with open(marker, encoding="utf-8") as fh:
            outputs = json.load(fh).get("outputs", [])
        return [marker.parent / o["path"] for o in outputs]
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return []


def _marker_key(marker: Path) -> str | None:
    """The stage key a done marker records; None without a readable one."""
    try:
        with open(marker, encoding="utf-8") as fh:
            key = json.load(fh).get("key")
        return key if isinstance(key, str) else None
    except (OSError, ValueError, AttributeError):
        return None


def _changed(stage: str, meta: dict, inputs: dict[str, str], params: dict, code: str) -> str:
    """What differs between a stage's marker meta and the run now (stale_parts). An option the marker's params
    lack reads as its default here too (`stage_options`), so only a value that differs is named."""
    why = []
    old = meta.get("inputs")
    if isinstance(old, dict):
        names = sorted(k for k in old.keys() | inputs.keys() if old.get(k) != inputs.get(k))
        if names:
            shown = ", ".join("the samples sheet" if k == "samples" else k for k in names[:5])
            why.append(f"its inputs changed ({shown}{f' and {len(names) - 5} more' if len(names) > 5 else ''})")
    else:
        why.append("its marker records no inputs")
    if meta.get("code") != code:
        why.append("the analysis code changed")
    old_params = meta.get("params") if isinstance(meta.get("params"), dict) else {}
    was = {**stage_options(stage, old_params), **old_params} if old_params else {}
    keys = sorted(k for k in was.keys() | params.keys() if was.get(k) != params.get(k))
    if keys == ["backend_version"] and "backend_version" in params:   # .get: a marker may be hand-edited
        now = params.get("backend_version")
        why.append("LASTZ's version differs" + (" (lastz is not on PATH, so it cannot be compared)" if now is None
                                                 else f" (now {now})"))
    elif keys and old_params:
        why.append(f"its parameters differ ({', '.join(keys)})")
    return "; ".join(why) or "its files changed since, or another ltrpav version made them"


# ---------------------------------------------------------------- the stages


class _Clock:
    """Debug lines with each step's time."""

    def __init__(self, stage: str) -> None:
        self.stage, self.t = stage, time.perf_counter()

    def __call__(self, step: str) -> None:
        now = time.perf_counter()
        log.debug("%s: %s (%.1f s)", self.stage, step, now - self.t)
        self.t = now


def run_stats(cat: Catalog, trio: tuple[str, str, str] | None, identity: bool, threads: int,
              block: int | None = None) -> list[Path]:
    """The stats stage (module docstring), in order: run_summary and the jackknife's block_bp row; relations;
    trios, then trio_tests per trio; inverted_blocks, inversions.tsv and inversion_rows; direction; mechanisms and
    mechanisms.tsv; with --identity the identity layer per trio and identity.tsv (without it a stale identity.tsv
    is deleted and one findings line says what needs it); then the stats part. block: --block-size, the block
    length of every jackknife here (None: the rule of `stats.block_size`). Returns the files written."""
    out, tick = cat.outdir, _Clock("stats")
    size = block_size(cat, block)
    rows, f = run_summary(cat)
    rows.append(StatRow("pav", "jackknife", "all", "all", "block_bp", size, loci="none",
                        note="rule" if block is None else "--block-size"))
    r, g, tree, dist = relations(cat)
    rows += r
    f.extend(g)
    tick("relations")
    found, r, g = trios(cat, trio, size, dist)
    rows += r
    f.extend(g)
    for t in found:
        r, g = trio_tests(cat, t, size, dist)
        rows += r
        f.extend(g)
    tick(f"trio tests ({len(found)} trio(s))")
    blocks = inverted_blocks(cat)
    write_inversions(blocks, cat, out / "inversions.tsv")
    r, g = inversion_rows(blocks, cat)
    rows += r
    f.extend(g)
    tick(f"inversions ({len(blocks)} block(s))")
    r, g = direction(cat, size, dist)
    rows += r
    f.extend(g)
    tick("direction")
    table, r, g = mechanisms(cat, tree)
    write_mechanisms(table, out / "mechanisms.tsv")
    rows += r
    f.extend(g)
    tick("mechanisms")
    written = [out / "inversions.tsv", out / "mechanisms.tsv"]
    ident = out / "identity.tsv"
    if identity:
        id_rows: list[tuple] = []
        if not found:
            f.add(IDENTITY_SECTION, "Sequence-identity layer skipped: no trio (fewer than three ingroup genomes)")
        for t in found:
            r, g, mine = identity_layer(cat, t, size, threads, dist)
            rows += r
            f.extend(g)
            id_rows += mine
        write_identity(id_rows, ident)
        written.append(ident)
        tick("identity layer")
    else:
        if ident.is_file():   # say what a resume without --identity throws away
            log.warning("stats: deleting identity.tsv, the sequence-identity layer of an earlier run with --identity: "
                        "this run is without it (rerun ltrpav-stats, or ltrpav run, with --identity to keep it)")
            ident.unlink()
        f.add("Dating", _IDENTITY_LINE)
    return [*written, *write_part(out, "stats", rows, f)]


def run_paint(cat: Catalog, trio: tuple[str, str, str] | None, previous=()) -> list[Path]:
    """The paint stage (module docstring): the trios from the PAV distances (relations' own; their rows and
    findings are the stats part's), the inverted blocks, identity.tsv's self rows as self_counts when the file is
    usable (`identity_usable`; else ignored, with a WARNING), then paint per trio, the painting files and the paint
    part. previous: the files the stage's last marker listed (`write_paintings` removes those that are painting
    files). Returns the files written."""
    out, tick = cat.outdir, _Clock("paint")
    dist = pav_distances(cat)[0]
    # the roles come from D_pav's estimate, which no block length changes (only its se), so the rule's blocks
    # serve and --block-size stays out of the paint key
    found, _, _ = trios(cat, trio, block_size(cat), dist)
    blocks = inverted_blocks(cat)
    path = out / "identity.tsv"
    usable, why = identity_usable(cat)
    counts = read_self_counts(path) if usable else None
    ignored = (f"identity.tsv is ignored: {why}; the painting has no youngest_u95 (identity.tsv's self rows) until "
               "ltrpav-stats reruns" if why else None)
    if ignored:
        log.warning("paint: %s", ignored)
    tick("trios and inverted blocks")
    paintings = []
    for t in found:
        paintings.append(paint(cat, t, blocks, self_counts=counts))
        tick(f"painting of {t.R} ({t.scope})")
    rows: list[StatRow] = []
    f = Findings()
    if ignored:
        f.warn("Painting", ignored)
    if not found:
        f.add("Painting", "Painting skipped: no trio (fewer than three ingroup genomes)")
    for p in paintings:
        r, g = paint_rows(p, cat)
        rows += r
        f.extend(g)
    return [*write_paintings(paintings, cat, out, previous), *write_part(out, "paint", rows, f)]


def run_plot(cat: Catalog, trio: tuple[str, str, str] | None) -> list[Path]:
    """The plot stage: the overview figure of the finished stages (ltrpav.plot.overview, imported here: it needs
    matplotlib); [overview.png, overview.pdf, overview_numbers.tsv]. First an AnalysisError naming every part that
    must not be drawn (`plot_refusals`): a stats part that is unfinished, stale or not in stats.tsv itself, and a
    paint part likewise once it has finished. A stale part's rows may still be in stats.tsv (only the stats and
    paint stages reassemble it), and drawing them against the catalog as it is now would show old results as
    current; a part missing from stats.tsv would make the figure misstate the run (no trio, or no painting).
    Tools are not probed: drawing never runs LASTZ, and its version cannot make the rows disagree with the
    catalog. The check reads the markers and stats.tsv's sentinel rows only, never findings.txt.

    The previous figure's files are deleted first, and any written are deleted again if drawing fails, so a refusal
    or a failure leaves no figure beside results it may not show (inside `ltrpav run` a figure
    error is only a WARNING)."""
    from ..plot.overview import STEM, overview

    figure = [cat.outdir / f"{STEM}{x}" for x in (".png", ".pdf", "_numbers.tsv")]
    for path in figure:
        path.unlink(missing_ok=True)
    if not (cat.outdir / "stats.tsv").is_file():
        raise AnalysisError(f"no stats.tsv in {cat.outdir}: run ltrpav-stats and ltrpav-paint first")
    refused = plot_refusals(cat)
    if refused:
        what = "; ".join(f"the {stage} part: {refused[stage]}" for stage in STAGES if stage in refused)
        raise AnalysisError(f"stats.tsv in {cat.outdir} is not current ({what}): rerun the analyses "
                            "(ltrpav-stats and ltrpav-paint, or ltrpav run), then ltrpav-plot")
    try:
        return overview(cat.outdir, cat.samples, cat.sheet, trio, cat=cat)
    except BaseException:
        for path in figure:
            path.unlink(missing_ok=True)
        raise


def read_self_counts(path: Path) -> dict[tuple[str, str], tuple[int, int]]:
    """identity.tsv's self rows as paint's self_counts: (lid, genome) -> (sites, diffs). A copy's self row is the
    same in every trio that reads it; the first is kept."""
    out: dict[tuple[str, str], tuple[int, int]] = {}
    with open(path, encoding="utf-8", newline="") as fh:
        header = fh.readline().rstrip("\r\n").split("\t")
        if header != list(IDENTITY_COLUMNS):
            raise AnalysisError(f"{path}: not an identity.tsv of ltrpav-stats (header not IDENTITY_COLUMNS): "
                                "rerun ltrpav-stats")
        kind, lid, genome, sites, diffs = (IDENTITY_COLUMNS.index(c)
                                           for c in ("kind", "lid", "genome", "sites", "diffs"))
        for n, line in enumerate(fh, 2):
            f = line.rstrip("\r\n").split("\t")
            if len(f) != len(IDENTITY_COLUMNS):
                raise AnalysisError(f"{path}: line {n} has {len(f)} column(s); the header has "
                                    f"{len(IDENTITY_COLUMNS)}: rerun ltrpav-stats")
            if f[kind] == "self":
                try:
                    out.setdefault((f[lid], f[genome]), (int(f[sites]), int(f[diffs])))
                except ValueError:
                    raise AnalysisError(f"{path}: line {n}: sites or diffs is not an integer: rerun "
                                        "ltrpav-stats") from None
    return out


# ---------------------------------------------------------------- parts and assembly


def write_part(outdir: Path, stage: str, rows: list[StatRow], findings: Findings) -> list[Path]:
    """The stage's part: work/analysis/<stage>.rows.tsv (STATS_COLUMNS) and <stage>.findings.tsv (header
    "section", "line"; one finding per line, a newline inside one written as a space). A section outside
    SECTIONS is a ValueError. Returns both paths."""
    work = Path(outdir) / WORK
    work.mkdir(parents=True, exist_ok=True)
    rows_path, find_path = work / f"{stage}.rows.tsv", work / f"{stage}.findings.tsv"
    lines = [_FINDINGS_HEADER]
    for section, text in findings.items():
        if section not in SECTIONS:
            raise ValueError(f"{section!r} is not a findings section ({', '.join(SECTIONS)})")
        lines.append(f"{section}\t{' '.join(text.splitlines())}")
    with atomic_path(rows_path) as tmp:
        write_stats(rows, tmp)
    atomic_write(find_path, "\n".join(lines) + "\n")
    return [rows_path, find_path]


def assemble(outdir: Path, stale: dict[str, str] | None = None) -> tuple[Path, Path]:
    """Rebuild stats.tsv and findings.txt from the finished stages' parts (module docstring), each file written
    atomically; returns their paths. stale: `stale_parts`, the stages whose part is left out and why (one
    WARNING each in the Run section); None checks no key (every part with a marker is taken).

    stats.tsv: the header row STATS_COLUMNS, then for each stage in STAGES order one sentinel row (layer "run",
    test PART, scope the stage, stratum "all"; read back by `assembled_parts`): a finished part's is statistic
    "key", value the stage key its marker records, n its row count, and its rows follow as their bytes; a stale
    part's is statistic "left_out", value why; an unfinished stage has none. No other header line.
    findings.txt (UTF-8): "ltrpav <version> findings for the run in <outdir, absolute>"; then each section with
    findings, in SECTIONS order, under its name, one "- " line per finding (parts in STAGES order); then
    "Warnings", repeating every WARNING line after its section's name ("- none" without one)."""
    outdir = Path(outdir)
    work = outdir / WORK
    header = ("\t".join(STATS_COLUMNS) + "\n").encode()
    stats = [header]
    found: list[tuple[str, str]] = []
    options: dict[str, list[str] | None] = {}
    stale = stale or {}
    for stage in STAGES:
        done = marker(work / stage)
        rows_path, find_path = work / f"{stage}.rows.tsv", work / f"{stage}.findings.tsv"
        meta = done_meta(done)
        if stage in stale:
            line = _LEFT_OUT.format(stage=stage, why=stale[stage] + _side_note(outdir, stage),
                                    advice=_rerun_advice(outdir, stage))
            found.append(("Run", line))
            stats.append(_sentinel(stage, "left_out", stale[stage], None))
            continue
        if meta is None or not (rows_path.is_file() and find_path.is_file()):
            continue  # not finished: its part is left out
        with open(rows_path, "rb") as fh:
            if fh.readline().rstrip(b"\r\n") != header.rstrip(b"\n"):
                raise AnalysisError(f"{rows_path}: not a stats part (header not STATS_COLUMNS): rerun the "
                                    f"{stage} stage")
            part = fh.readlines()
        stats.append(_sentinel(stage, "key", _marker_key(done) or "none", len(part)))
        stats.extend(part)
        with open(find_path, encoding="utf-8", newline="") as fh:
            if fh.readline().rstrip("\r\n") != _FINDINGS_HEADER:
                raise AnalysisError(f"{find_path}: not a findings part: rerun the {stage} stage")
            for n, line in enumerate(fh, 2):
                section, tab, text = line.rstrip("\r\n").partition("\t")
                if not tab or section not in SECTIONS:
                    raise AnalysisError(f"{find_path}: line {n} is not a findings section and a line: rerun the "
                                        f"{stage} stage")
                found.append((section, text))
        if "trio" in meta:
            options[stage] = meta["trio"]
    if len({_trio_key(t) for t in options.values()}) > 1:
        which = ", the ".join(f"{s} stage with {_trio_text(t)}" for s, t in options.items())
        line = (f"WARNING: stats.tsv and findings.txt join parts made with different trios: the {which}; rerun "
                "both with the same --trio")
        found.insert(0, ("Run", line))
    text = [f"ltrpav {__version__} findings for the run in {os.path.abspath(outdir)}", ""]
    for section in SECTIONS:
        mine = [line for sec, line in found if sec == section]
        if mine:
            text += [section, *(f"- {line}" for line in mine), ""]
    warnings = [f"- {sec}: {line}" for sec, line in found if line.startswith("WARNING: ")]
    text += ["Warnings", *(warnings or ["- none"])]
    stats_path, findings_path = outdir / "stats.tsv", outdir / "findings.txt"
    atomic_write(stats_path, b"".join(stats))
    atomic_write(findings_path, "\n".join(text) + "\n")
    return stats_path, findings_path


def _sentinel(stage: str, statistic: str, value: str, n: int | None) -> bytes:
    """stats.tsv's sentinel row of a stage's part (`assemble`), as bytes."""
    note = (f"the {stage} stage's part: its {n} row(s) follow, made under this stage key ({WORK.as_posix()}/{stage}"
            ".done.json)" if statistic == "key" else
            f"the {stage} stage's part is left out of this file (findings.txt says why too)")
    return format_row(StatRow("run", PART, stage, "all", statistic, value, n=n, loci="none", note=note)).encode()


def _trio_key(trio: list[str] | None) -> str:
    """A trio option as a comparable text."""
    return "data" if trio is None else ",".join(trio)


def _trio_text(trio: list[str] | None) -> str:
    return "the roles from the data" if trio is None else f"--trio {','.join(trio)}"

