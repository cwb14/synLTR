# Task 7 report: --discovery, --emission, --block-size and their stage keys

Status: **committed; full suite running**. BASE c7ccacd; branch plan3-benchmark; nothing pushed.
Scratch `$S` = `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t7/`.

## Commits

| sha | subject |
|---|---|
| 3da735c | Paint review minors: decoy discovery test, collapsed e1, one fallback warning |
| 4f3973e | Expose the painting variants and the jackknife block size on the command line |

Both use the global identity (cwb14). No trailers, no AI attribution, nothing set. **4f3973e is the head Task 8
snapshots.**

## Files

- 3da735c: `src/ltrpav/analysis/paint.py`, `tests/test_paint.py`.
- 4f3973e:
  - `src/ltrpav/analysis/cli.py`, `report.py` and `stats.py`;
  - `constants.py`: DISCOVERY moves here;
  - `paint.py`: imports DISCOVERY from the constants;
  - `tests/test_cli_analysis.py`;
  - `docs/DESIGN.md`.
  No engine file is touched: `git diff 12d3e6c HEAD -- src/ltrpav/{constants,checkpoint,cli}.py` is empty.

## Commit 1 (3da735c): Task 6 review minors

- **m1.** `test_decoy_e0_fixed` paints under both DISCOVERY rules with `emission="decoy"`.
  - It pins e0 exactly from `classes(cat, "S", "R", "D", discovery)`.
  - It asserts that the toy's decoy counts differ between the rules: recipient 176 RD / 448 RS, any 248 / 613.
  - The mutant `classes(cat, Y, X, D)` at paint.py:450 fails it (`$S/tdd_m1_mutant.log`: e0 [0.2824, 0.7176]
    against 0.2883).
- **m2.** One docstring line in `test_decoy_null_no_tract`.
  - It is a smoke test, not null evidence: it cannot fail at toy scale.
  - Under the +1 correction a tract needs at least 20 target tracts above every decoy tract; the toy gives 0-2.
  - The test is kept.
- **m3.** On a collapsed decoy fit, the findings line keeps n_D, n_X and e0.
  - It ends "e1 NA: the fit collapsed, so state 1 holds no data and e1 would come from the pseudocounts".
  - Pinned in `test_emission_rows`: seed 1's null painted under decoy is collapsed, its e* rows are NA, and the line
    holds "e1 NA" and no "EM fitted e1".
- **m4.**
  - `classes()` takes its default from `PAINT_DISCOVERY`.
  - The module docstring cites `classes(cat, Y, X, D, discovery)`, the target's rule.
  - A fallback painting writes one WARNING: the no-decoy WARNING gains the clause "the emission model decoy was asked
    for and needs a decoy, so the emission model em fitted both states' emissions by EM".
  - Pinned in `test_decoy_without_decoy_falls_back`: the WARNINGs naming the reason are exactly the one emission
    WARNING.
- **TDD evidence.**
  - Against BASE's paint.py, `test_emission_rows` (m3) and `test_decoy_without_decoy_falls_back` (m4) fail
    (`$S/tdd_minors_base.log`). m1 is shown by the mutant above.
  - After the fix, test_paint and test_cli_analysis pass (exit 0), and ruff is clean.

## Commit 2 (4f3973e): the options, keys and rows

### Options (cli.py)

- `ltrpav-stats --block-size BP`.
  - `block_arg`: an integer of at least BLOCK_MIN (10,000). Anything else is an argparse usage error: exit 2, one
    error line naming --block-size.
  - Default None: DESIGN 7.3's rule.
- `ltrpav-paint --discovery {recipient,any}` (default `PAINT_DISCOVERY`) and `--emission {em,decoy}` (default
  `PAINT_EMISSION`).
  - The choices are `constants.DISCOVERY` and `constants.EMISSIONS`.
  - DISCOVERY moved to the constants so the CLI imports no analysis module: test_cli_imports_without_scipy still
    passes. `paint.DISCOVERY` remains.
- The start log line names any non-default option.
- `ltrpav run` gains no option, and `run_analyses` keeps its signature (defaults). `ltrpav run --emission`,
  `--discovery` or `--block-size` gives exit 2 (tested).
- `--help`: stats 28 lines, paint 31 (< 40).

### Rows (stats.py, report.run_stats)

- `stats.block_size(cat, override=None) -> int`: an override must be an integer of at least BLOCK_MIN (ValueError
  otherwise); without one, the rule.
- The stats part gets `StatRow("pav", "jackknife", "all", "all", "block_bp", size, loci="none", note="rule" |
  "--block-size")` right after the run summary rows.

### Stage keys and markers (report.py)

- `OPTIONS = {"stats": {"block_size": None}, "paint": {"discovery": PAINT_DISCOVERY, "emission": PAINT_EMISSION},
  "plot": {}}`.
- `stage_options(stage, given)` returns `{name: given.get(name, default)}`.

| stage | key params (`stage_params`) | marker meta (top level) |
|---|---|---|
| stats | trio, identity, (backend, backend_version with --identity), **block_size** (null = rule) | trio, identity, **block_size**, inputs, params, code |
| paint | trio, identity (identity_usable), **discovery**, **emission** | trio, identity, **discovery**, **emission**, inputs, params, code |
| plot | trio | trio, identity, inputs, params, code |

- Each option is in its key at every value, the default included.
- The paint key holds no block_size. The painting's trio roles use D_pav's estimate only, and no block length changes
  it, only its se (`jackknife`: est = stat(all rows)).
- `run_stage(..., options)`:
  - validates the options before clearing the marker (`_check_options`);
  - passes them to `run_stats(block)` and `run_paint(discovery, emission)`;
  - records them in the meta.
- **How a marker reads.**
  - `_stale` recomputes the key from `stage_options(stage, meta)`, so the stale-part check, `identity_usable` and the
    plot's `plot_refusals` all use the options the marker recorded.
  - An old marker without the keys reads as the defaults, with no KeyError.
  - `_changed` also reads an option missing from the marker's params as its default, so only a real difference is
    named. An old marker is stale anyway, because the analysis fingerprint changed.
- The plot stage's sentinel checks are unchanged.

### Tests (tests/test_cli_analysis.py) and what each pins

- `test_paint_discovery_any_cli`:
  - default painting rows declare disc=R or disc=S;
  - after `--discovery any`, every paint, paint_resolution and paint_seqid row declares `disc=any;`;
  - tracts.R.bed (with tracts), posterior.R.tsv and both decoy files are written;
  - the marker records discovery "any" in its meta and its params.
- `test_paint_emission_rerun`:
  - defaults, then `--emission decoy`: running;
  - the same again: done, skip;
  - ltrpav-stats in between keeps the decoy part (nothing left out);
  - the defaults again: running, emission row "em";
  - after another decoy painting, `run_analyses` (ltrpav run) repaints at the defaults;
  - `ltrpav run` with any of the three options exits 2.
- `test_old_marker_reads_defaults`:
  - stats and paint markers stripped of the new keys (meta and params): stale_parts {} and plot_refusals {};
  - both stages skip with nothing left out, and stats.tsv holds D_pav and paint;
  - markers made with `--block-size 1000000` and `--emission decoy`, then stripped, read as stale.
- `test_block_size_option`:
  - the default block_bp row is (40,000, "none", "rule"), the toy's 4 Mb / 100;
  - `--block-size 1000000` gives the row (1,000,000, "--block-size"), the note "4 jackknife blocks of 1,000,000 bp",
    D_pav's se finite and different, and the same estimate;
  - 5, 9,999, "1e6" and "x" each exit 2 naming --block-size;
  - BLOCK_MIN itself is accepted;
  - the marker records block_size.
- `test_plot_accepts_default_options`:
  - the markers record the defaults (paint params hold no block_size; stats params no discovery or emission);
  - the plot draws;
  - after `--emission decoy` the plot reruns and draws: the decoy part is current under its own options;
  - a paint marker whose meta says em under a decoy key is refused ("the paint part: its parameters differ
    (emission)"), and no figure is left.

### TDD evidence

- **The five brief tests written first** (`$S/tdd_step2.log`), all failing:
  - SystemExit 2 for the unknown `--discovery` and `--emission`;
  - KeyError for the marker lacking `block_size`, in two tests;
  - the block_bp row missing.
- **After the implementation, all pass** (`$S/tdd_step4.log`, exit 0). Two of my own expectations were corrected:
  - a stripped, non-default marker's reason reads "its files changed since, or another ltrpav version made them",
    because its options read as the defaults;
  - the plot test removes plot.done.json before the refusal check. The plot stage checks its own key before its
    refusals (Plan 2 behavior), and only a hand-edited marker reaches that case.
- `test_paint_emission_rerun`, extended after that run, was rerun with help_is_short and
  cli_imports_without_scipy: 3 passed (`$S/emission_rerun.log`).

### DESIGN.md

- **7.1**: `--discovery {recipient,any}`, default `PAINT_DISCOVERY`; the decoy follows the same rule; the rows declare
  it.
- **7.3**:
  - the rule written in full (5 Mb, or 1/100 of the smallest genome, at least 10 kb);
  - `--block-size` (>= BLOCK_MIN) for the stability check, and the `jackknife`/`block_bp` row;
  - the painting's roles do not depend on the block length.
- **7.4**:
  - `--emission em|decoy` and their roles, the fallback, and the emission rows;
  - the default for each variant is decided by Plan 3's grid (decision 17).
- **8**:
  - the analysis keys hold each stage's options at every value;
  - another option reruns and overwrites, so a run directory holds one painting, and the same options skip;
  - the markers record the options, and an option a marker lacks reads as its default;
  - `ltrpav run` runs at the defaults.
- **10.4**: "block size (`ltrpav-stats --block-size`) varied and reported".

## Engine fingerprints

`$S/fp/fp.py` was run on git-archive snapshots of 12d3e6c and 4f3973e, with PYTHONPATH and `ltrpav.__file__`
asserted inside each snapshot (`$S/fp/12d3e6c.tsv`, `$S/fp/4f3973e.tsv`). All 7 STAGE_MODULES fingerprints are
equal:
- anchor, blastdb and raw: ebbfd97f;
- elements: a78af75d;
- genotype_chunk and genotype_pair: 52071c27;
- mm2_index: 28f6fc79.

## Suite (running at the time of writing)

- Launched detached after 4f3973e: bash PID 750143, PPID 1, SID 750143.
- Log `$S/suite/suite.log`; exit code in `$S/suite/suite.done`.
- ruff check: All checks passed (after the last edit, before the commit).
- Focused run (`$S/focused.log`, `$S/focused.done`): test_cli_analysis, test_paint, test_overview, test_stats_core and
  test_direction, on the tree before the last help-text and test edits. **Exit 0, 167 passed**, no F, E, s or x mark.

## main3 scratch-copy probes (running at the time of writing)

- `$S/m3/probe.sh`, then `$S/m3/probe_b.sh`, each under `timeout 15m`. Logs `$S/m3/probe.log` and `probe_b.log`;
  exits in `$S/m3/probes.exit`, done marker `$S/m3/probes.done`.
- They run on `cp -a` copies of main3_analyses (symlinks copied as links) in `$S/m3/{base,head}`, from snapshots
  c7ccacd and 4f3973e.
- probe.sh:
  - BASE and HEAD default paintings compared;
  - HEAD reading the Plan 2 markers;
  - emission and discovery reruns and skips.
- probe_b.sh: `--block-size 1000000` stats, a decoy painting, then the plot.
- Guards: `inputs/*.fai` size, mtime and sha256 before and after; `find -newer` under main3 and main3_analyses.

Results so far (probe.sh, `$S/m3/probe.log`):
- **The Plan 2 markers read with no KeyError.**
  - They hold no discovery, emission or block_size.
  - HEAD's `stale_parts(probe_tools=False)` gives stats "the analysis code changed".
  - It gives paint "the analysis code changed; its parameters differ (identity)". That is a real difference:
    identity.tsv is no longer usable because the stats part is stale.
  - Discovery and emission are not named: they read as the defaults. plot_refusals gives the same reasons.
- **The default painting is byte-identical at BASE c7ccacd and HEAD 4f3973e**, with the same inputs (identity.tsv
  ignored in both). Identical files:
  - tracts.B73.bed and posterior.B73.tsv;
  - decoy_tracts.TIL01.bed and decoy_posterior.TIL01.tsv;
  - work/analysis/paint.rows.tsv and paint.findings.tsv.
- **The stage keys behave as designed on real data:**
  - the defaults again: done, skip;
  - `--emission decoy`: running;
  - the same again: done, skip; the emission row of B73,TIL01;TIL18 is "decoy";
  - `--discovery any --emission decoy`: running; its emission row declares `disc=any;present=B73;...`.
- Each paint ran in about 20-35 s.
- **After the any+decoy painting**, the HEAD paint marker records discovery "any" and emission "decoy" in its meta and
  params. `stale_parts` and `plot_refusals` name only the stats part ("the analysis code changed"): the variant
  painting is current under its own options.
- **Guards:** inputs/*.fai unchanged (size, mtime, sha256); 0 files newer under main3 and main3_analyses. probe.sh
  exit 0.
- probe_b.sh (`--block-size 1000000` stats without --identity, a decoy paint, the plot) was still running at
  handback: `$S/m3/probe_b.log`, exit in `$S/m3/probes.exit` (b=).

## Concerns

None beyond those already noted for Task 8.
