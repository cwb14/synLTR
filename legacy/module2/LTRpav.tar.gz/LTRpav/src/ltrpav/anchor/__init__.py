"""Anchoring: raw blocks of genome A vs genome B from a route, chained and netted to syntenic 1:1 blocks.

A route maps one ordered genome pair to raw, unchained blocks (BLOCK_DTYPE, 0-based half-open). `anchor_pair`
chains and nets them (`chain_blocks`, `net_blocks`) into the orthologous block set that windows are built
from, cached per ordered pair and route under <workdir>/anchors.
"""
from __future__ import annotations

import logging
import math
import shutil
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Protocol

import numpy as np

from ..blocks import load_blocks, save_blocks, swap_blocks
from ..chain import chain_blocks, net_blocks
from ..checkpoint import (
    CHECKSUM_CACHE,
    atomic_path,
    clear_done,
    file_checksum,
    is_done,
    mark_done,
    marker,
    stage_key,
)
from ..constants import (
    ANCHOR_MIN,
    CHAIN_INDEL_COST,
    CHAIN_LOOKBACK,
    CHAIN_MAX_GAP,
    CHAIN_OVERLAP,
    MIN_CHAIN_SCORE,
)
from ..elements import Element, elements_digest
from ..seqio import Fasta
from .fastga import FastgaRoute
from .flanks import FlankBlastRoute, FlankMm2Route, HybridRoute
from .mm2 import Mm2Route
from .paf import PafRoute

if TYPE_CHECKING:
    from ..samples import Sample

__all__ = ["FastgaRoute", "FlankBlastRoute", "FlankMm2Route", "HybridRoute", "Mm2Route", "PafRoute", "PairContext", "Route", "anchor_pair", "anchors_path", "divergence",
           "get_route"]

log = logging.getLogger("ltrpav.anchor")

KNOWN_ROUTES = "mm2, fastga, flank-mm2, flank-blast, hybrid, paf:<dir>"
# the netted blocks depend on these besides the raw blocks; "net" names the net's rule, so anchors netted
# under another rule are recomputed, never reused
_CHAIN_PARAMS = {"anchor_min": ANCHOR_MIN, "max_gap": CHAIN_MAX_GAP, "indel_cost": CHAIN_INDEL_COST,
                 "overlap": CHAIN_OVERLAP, "lookback": CHAIN_LOOKBACK, "min_score": MIN_CHAIN_SCORE,
                 "net": "syntenic"}


@dataclass
class PairContext:
    """One ordered genome pair: A (whose elements are genotyped) against B."""

    a: Sample
    b: Sample
    a_fa: Fasta
    b_fa: Fasta
    a_elements: list[Element]
    b_elements: list[Element] | None
    outdir: Path
    threads: int

    @property
    def workdir(self) -> Path:
        """Intermediate files and caches: <outdir>/work."""
        return Path(self.outdir) / "work"


class Route(Protocol):
    """An anchoring route: raw (unchained) alignment blocks of A against B. Every member is required (anchor_pair
    reads them directly).

    name: short id, used in cache file names.
    whole_genome: True if the blocks of B vs A are those of A vs B swapped (a W route); `anchor_pair` then
        computes them once per unordered pair, in label order, and caches them.
    reads_elements: True if the blocks depend on ctx.a_elements / ctx.b_elements (then part of the cache key).
    params(ctx): JSON values the blocks depend on besides the two FASTAs (settings, tool versions, checksums of
        external inputs); part of the cache key.
    raw_blocks(ctx): BLOCK_DTYPE array; A indices follow ctx.a_fa's fai order, B indices ctx.b_fa's.
    """

    name: str
    whole_genome: bool
    reads_elements: bool

    def params(self, ctx: PairContext) -> dict: ...

    def raw_blocks(self, ctx: PairContext) -> np.ndarray: ...


def get_route(spec: str) -> Route:
    """The route named by `spec`: "mm2", "fastga", "flank-mm2", "flank-blast", "hybrid" or "paf:<dir>".

    "hybrid" takes FastGA as its primary if installed, else mm2."""
    if spec == "mm2":
        return Mm2Route()
    if spec == "fastga":
        return FastgaRoute()
    if spec == "flank-mm2":
        return FlankMm2Route()
    if spec == "flank-blast":
        return FlankBlastRoute()
    if spec == "hybrid":
        return HybridRoute(FastgaRoute() if shutil.which("FastGA") else Mm2Route())
    if spec.startswith("paf:") and len(spec) > len("paf:"):
        return PafRoute(Path(spec[len("paf:"):]))
    raise ValueError(f"unknown route {spec!r}; known routes: {KNOWN_ROUTES}")


def anchor_pair(ctx: PairContext, route: Route) -> tuple[np.ndarray, list[str], list[str], float]:
    """Netted syntenic 1:1 blocks of A vs B by `route`, the A and B seqids (fai order) and the divergence d.

    d = 1 - sum(matches) / sum(alen) over the netted blocks (nan if there are none). The result is cached at
    <workdir>/anchors/<A>__<B>.<route>.npz, keyed by both FASTA checksums, the elements (routes that read
    them), the route's params and the chaining constants with the net's rule (_CHAIN_PARAMS). W routes' raw
    blocks come from `_raw_blocks`: they do not depend on the net, so their cache stays valid.
    """
    out = anchors_path(ctx, route)
    anchors = out.parent
    done = marker(out)
    sums = ctx.workdir / CHECKSUM_CACHE
    inputs = {"A": file_checksum(ctx.a_fa.path, sums), "B": file_checksum(ctx.b_fa.path, sums)}
    if route.reads_elements:
        inputs["A_elements"] = elements_digest(ctx.a_elements)
        inputs["B_elements"] = elements_digest(ctx.b_elements)
    key = stage_key("anchor", inputs, {"route": route.name, "route_params": route.params(ctx),
                                       "chain": _CHAIN_PARAMS})
    pair = f"{ctx.a.label} vs {ctx.b.label} ({route.name})"
    if is_done(done, key):
        cached = _load(out, pair)
        if cached is not None:
            blocks, a_names, b_names = cached
            d = divergence(blocks)
            log.info("%s: anchors done, skip (%d netted blocks, d = %.4f)", pair, len(blocks), d)
            return blocks, a_names, b_names, d

    clear_done(done)
    anchors.mkdir(parents=True, exist_ok=True)
    log.debug("%s: anchoring", pair)
    raw = _raw_blocks(ctx, route, sums)
    blocks = net_blocks(chain_blocks(raw), label=pair)
    a_names, b_names = list(ctx.a_fa.lengths()), list(ctx.b_fa.lengths())
    _save(out, blocks, a_names, b_names)
    mark_done(done, key, [out])
    d = divergence(blocks)
    anchored = int((blocks["a_end"] - blocks["a_start"]).sum(dtype=np.int64))
    log.debug("%s: %d raw blocks -> %d netted, %.1f Mb of A anchored, d = %.4f",
             pair, len(raw), len(blocks), anchored / 1e6, d)
    return blocks, a_names, b_names, d


def anchors_path(ctx: PairContext, route: Route) -> Path:
    """Where `anchor_pair` caches the netted blocks: <workdir>/anchors/<A>__<B>.<route>.npz."""
    return ctx.workdir / "anchors" / f"{ctx.a.label}__{ctx.b.label}.{route.name}.npz"


def divergence(blocks: np.ndarray) -> float:
    """1 - sum(matches) / sum(alen); nan if the blocks hold no aligned column."""
    alen = int(blocks["alen"].sum(dtype=np.int64))
    return 1 - int(blocks["matches"].sum(dtype=np.int64)) / alen if alen > 0 else math.nan


def _raw_blocks(ctx: PairContext, route: Route, sums: Path) -> np.ndarray:
    """Raw blocks of A vs B. A W route computes them once per unordered pair, with A the label that sorts
    first, cached at <workdir>/anchors/<X>__<Y>.<route>.raw.npz (X < Y); the other direction swaps them."""
    if not route.whole_genome:
        return route.raw_blocks(ctx)
    fwd = ctx.a.label <= ctx.b.label
    cctx = ctx if fwd else _swapped(ctx)
    path = ctx.workdir / "anchors" / f"{cctx.a.label}__{cctx.b.label}.{route.name}.raw.npz"
    done = marker(path)
    inputs = {"A": file_checksum(cctx.a_fa.path, sums), "B": file_checksum(cctx.b_fa.path, sums)}
    key = stage_key("raw", inputs, {"route": route.name, "route_params": route.params(cctx)})
    cached = _load(path, f"{cctx.a.label} vs {cctx.b.label} ({route.name})") if is_done(done, key) else None
    if cached is not None:
        raw = cached[0]
        log.debug("%s vs %s (%s): reusing %d raw blocks", cctx.a.label, cctx.b.label, route.name, len(raw))
    else:
        clear_done(done)
        raw = route.raw_blocks(cctx)
        _save(path, raw, list(cctx.a_fa.lengths()), list(cctx.b_fa.lengths()))
        mark_done(done, key, [path])
    return raw if fwd else swap_blocks(raw)


def _swapped(ctx: PairContext) -> PairContext:
    """The pair with A and B exchanged (B's missing elements become an empty list)."""
    return PairContext(a=ctx.b, b=ctx.a, a_fa=ctx.b_fa, b_fa=ctx.a_fa,
                       a_elements=ctx.b_elements if ctx.b_elements is not None else [],
                       b_elements=ctx.a_elements, outdir=ctx.outdir, threads=ctx.threads)


def _load(path: Path, what: str) -> tuple[np.ndarray, list[str], list[str]] | None:
    """load_blocks(path), or None with a warning when the cached file cannot be read (a damaged file of the
    recorded size passes is_done): the caller recomputes it."""
    try:
        return load_blocks(path)
    except (OSError, ValueError, KeyError, EOFError, zipfile.BadZipFile) as exc:
        log.warning("%s: cached blocks %s are unreadable (%s: %s); recomputing", what, path, type(exc).__name__, exc)
        return None


def _save(path: Path, blocks: np.ndarray, a_names: list[str], b_names: list[str]) -> None:
    """save_blocks to a temp file, then rename: a reader never sees a partial file."""
    with atomic_path(path) as tmp:
        save_blocks(tmp, blocks, a_names, b_names)
