"""ltrkin source: likely source (master) copy of each new insertion, with the evidence to judge it.

Status (from ltrkin genotype calls with GQ >= GQ_STATUS): new = an empty-site allele in some sample; fixed = all
called samples F/F (full on every haplotype); other = anything else. For each new copy with an internal region
>= MIN_INTERNAL bp, the nearest fixed copies (internal-region divergence, minimap2 asm5) are its candidate sources;
ties share weight. See docs/DESIGN.md.
"""
import hashlib
import math
import os
import shutil
import subprocess
import sys
import time
from collections import Counter
from multiprocessing import Pool

import mappy
import parasail
import numpy as np
import pandas as pd
import pysam

from . import __version__
from .annot import read_gff3, infer_tsd
from .constants import (GQ_STATUS, MIN_INTERNAL, MIN_ALN, MIN_COV, MIN_COV_LONG, TIE_DIFFS, TOP_K, N_NEAREST, CONS_MIN,
                        FLANK, FLANK_DUP_ID, OLDER_DIFFS, MOSAIC_ALPHA, MOSAIC_COV,
                        MOSAIC_GAIN)
from .reads import sw_identity

DIV_LIMITS = (0.001, 0.002, 0.005, 0.01, 1.0)   # cumulative source-divergence limits reported in locality
PERM = 5000                                      # null replicates for the locality tests

_SC = parasail.matrix_create("ACGT", 2, -3)

COMP = str.maketrans("ACGTN", "TGCAN")
TS = {("A", "G"), ("G", "A"), ("C", "T"), ("T", "C")}


def log(msg, v=True):
    if v:
        print(f"[ltrkin {time.strftime('%H:%M:%S')}] {msg}", file=sys.stderr, flush=True)


def rc(s):
    return s.translate(COMP)[::-1]


def status_table(paths):
    """Element status from one or more genotype TSVs."""
    cols = {"element_id", "chrom", "start", "end", "sample", "genotype", "gq", "flags"}
    g = pd.concat([pd.read_csv(p, sep="\t", usecols=lambda c: c in cols, dtype={"element_id": str, "chrom": str})
                   for p in paths], ignore_index=True)
    conf = g[g.gq >= GQ_STATUS].copy()
    conf["has_E"] = conf.genotype.str.contains("E")
    conf["all_F"] = conf.genotype.str.split("/").apply(lambda a: all(x == "F" for x in a))
    conf["bad"] = conf["flags"].str.contains("high_depth|unexplained_clips", regex=True)
    agg = conf.groupby("element_id").agg(n_called=("sample", "size"), any_E=("has_E", "any"),
                                         all_F=("all_F", "all"), bad=("bad", "any"))
    st = np.where(agg.any_E & ~agg.bad, "new", np.where(agg.all_F & ~agg.bad, "fixed", "other"))
    out = pd.Series(st, index=agg.index, name="status")
    coords = (g.drop_duplicates("element_id").set_index("element_id")[["chrom", "start", "end"]]
              if {"chrom", "start", "end"} <= set(g.columns) else None)
    return out.reindex(g.element_id.unique()).fillna("other"), agg.n_called, coords


def own_internal(fa, el):
    """Internal region of an element with the elements nested inside it excised (its own sequence)."""
    s, e = el.internal
    keep, cur = [], s
    for a, b in sorted(el.inner):
        if b <= s or a >= e:
            continue
        if a > cur:
            keep.append((cur, a))
        cur = max(cur, b)
    if cur < e:
        keep.append((cur, e))
    return "".join(fa.fetch(el.chrom, a, b) for a, b in keep).upper()


def nested_pair(a, b):
    """True if one element contains or overlaps the other (a host cannot be its own insertion's source)."""
    return a.chrom == b.chrom and a.start < b.end and b.start < a.end


def ltr_diffs(fa, el):
    """Differences between the two LTRs of one element by global alignment:
    (substitutions, transitions, indel events, aligned columns without gaps)."""
    a = fa.fetch(el.chrom, *el.lltr).upper()
    b = fa.fetch(el.chrom, *el.rltr).upper()
    if not a or not b:
        return (np.nan, np.nan, np.nan, 0)
    tb = parasail.nw_trace_scan_16(a, b, 5, 2, _SC).traceback
    sub = ts = indel = n = 0
    prev_gap = False
    for x, y in zip(tb.query, tb.ref):
        if x == "-" or y == "-":
            if not prev_gap:
                indel += 1
            prev_gap = True
            continue
        prev_gap = False
        n += 1
        if x != y:
            sub += 1
            ts += (x, y) in TS
    return (sub, ts, indel, n)


SRC_COLS = ['new_id', 'new_chrom', 'new_start', 'new_end', 'family', 'clade', 'source_id', 'source_chrom', 'source_start', 'source_end', 'divergence', 'aln_len', 'est_diffs', 'n_tied', 'weight', 'same_chrom', 'distance', 'nearest_any_id', 'nearest_any_status', 'nearest_any_div', 'new_ltr_diffs', 'source_ltr_diffs', 'source_older', 'same_tsd', 'flank_identity', 'shared_derived', 'source_private', 'new_private', 'consensus_sites', 'mosaic_left', 'mosaic_right', 'mosaic_breakpoint', 'mosaic_support', 'mosaic_conflicts', 'mosaic_p_adj', 'flags']
COPY_COLS = ['element_id', 'chrom', 'start', 'end', 'family', 'clade', 'status', 'n_called', 'internal_len', 'ltr_diffs', 'ltr_k2p', 'nearest_any_id', 'nearest_any_div', 'nearest_fixed_id', 'nearest_fixed_div']
LOC_COLS = ['max_divergence', 'level', 'group', 'n_new', 'same', 'expected', 'obs_exp', 'p', 'perm_expected', 'perm_obs_exp', 'perm_p', 'median_distance_mb']


def k2p(sub, ts, n):
    if not n or sub != sub:
        return np.nan
    p, q = ts / n, (sub - ts) / n
    try:
        return -0.5 * math.log((1 - 2 * p - q) * math.sqrt(1 - 2 * q)) + 0.0     # + 0.0: no -0.0
    except ValueError:
        return np.nan


def _cs_ops(cs):
    """Parse a minimap2 short cs string into (op, value) pairs."""
    i, n = 0, len(cs)
    while i < n:
        op = cs[i]
        j = i + 1
        if op == ":":
            while j < n and cs[j].isdigit():
                j += 1
            yield ":", int(cs[i + 1:j])
        elif op == "*":
            yield "*", (cs[i + 1], cs[i + 2])
            j = i + 3
        else:  # + or -
            while j < n and cs[j].isalpha():
                j += 1
            yield op, cs[i + 1:j]
        i = j


def bases_on_target(hit, qseq):
    """Map target positions -> query base ('-' deletion) for one mappy hit (forward-strand coordinates)."""
    out = {}
    t = hit.r_st
    for op, val in _cs_ops(hit.cs):
        if op == ":":
            t += val
        elif op == "*":
            out[t] = val[1].upper()
            t += 1
        elif op == "-":
            for k in range(len(val)):
                out[t + k] = "-"
            t += len(val)
    return out   # positions absent from 'out' but inside [r_st, r_en) carry the target base


def shared_mutations(m_seq, n_seq, others):
    """Shared derived substitutions between source M and new copy N, polarized by the consensus of other relatives.
    Returns (shared, source_private, new_private, informative_sites)."""
    al = mappy.Aligner(seq=m_seq, preset="asm5", best_n=1)

    def one(q):
        h = next(iter(al.map(q, cs=True)), None)
        if h is None:
            return None
        return h, bases_on_target(h, q)
    n = one(n_seq)
    if n is None:
        return (np.nan,) * 4
    hn, bn = n
    obs = [o for o in (one(s) for s in others) if o is not None]
    if len(obs) < CONS_MIN:
        return (np.nan,) * 4
    shared = sprivate = nprivate = informative = 0
    var_sites = set(bn)
    for h, b in obs:
        var_sites |= set(b)
    for t in sorted(var_sites):
        mb = m_seq[t].upper()
        calls = [b.get(t, mb) for h, b in obs if h.r_st <= t < h.r_en]
        if len(calls) < CONS_MIN:
            continue
        cons, k = Counter(calls).most_common(1)[0]
        if k < max(CONS_MIN, 0.5 * len(calls)) or cons == "-":
            continue
        if not (hn.r_st <= t < hn.r_en):
            continue
        nb = bn.get(t, mb)
        if nb == "-" or mb == "-":
            continue
        informative += 1
        if mb != cons:                         # derived in the source lineage
            if nb == mb:
                shared += 1
            elif nb == cons:
                sprivate += 1
        elif nb != mb:
            nprivate += 1
    return shared, sprivate, nprivate, informative


def scan_p(labels):
    """Exact one-breakpoint scan test (MaxChi-like). labels: +1 where the new copy follows c1, -1 where it follows c2,
    ordered along the sequence. Under no recombination the labels are randomly ordered; the statistic is the maximum
    h of the running sum, with P(max >= h) = C(n, n1 - h) / C(n, n1) (reflection principle). Returns (p, h, k)."""
    n, n1 = len(labels), labels.count(1)
    w = h = k = 0
    for i, x in enumerate(labels, 1):
        w += x
        if w > h:
            h, k = w, i
    if n1 - h < 0:
        return 0.0, h, k
    return math.comb(n, n1 - h) / math.comb(n, n1), h, k


def mosaic_test(n_seq, cands):
    """Two-parent (template-switch) test. cands: dict id -> internal sequence of candidate parents (nearest relatives
    of any status and the tied sources). Each candidate is aligned to the new copy N (positions where it differs).
    For every ordered pair (c1, c2), the diagnostic sites (exactly one of c1, c2 differs from N) are labeled by the
    parent N follows there; scan_p tests for one breakpoint with c1 left and c2 right. Bonferroni over pairs. Called
    recombinant if adjusted P <= MOSAIC_ALPHA and the mosaic explains >= MOSAIC_GAIN more differences than the best
    single candidate. Returns (c1, c2, breakpoint, support_left, support_right, conflicts, p_adj) or None."""
    al = mappy.Aligner(seq=n_seq, preset="asm5", best_n=1)
    L = len(n_seq)
    diff = {}
    for cid, q in cands.items():
        h = next(iter(al.map(q, cs=True)), None)
        if h is None or (h.r_en - h.r_st) < MOSAIC_COV * L:
            continue
        diff[cid] = (h.r_st, h.r_en, set(bases_on_target(h, q)))
    if len(diff) < 2:
        return None
    ids = list(diff)
    m_tests = len(ids) * (len(ids) - 1)
    best = None
    for c1 in ids:
        for c2 in ids:
            if c2 == c1:
                continue
            s1, e1, d1 = diff[c1]
            s2, e2, d2 = diff[c2]
            lo, hi = max(s1, s2), min(e1, e2)
            sites = sorted([(x, 1) for x in d2 - d1 if lo <= x < hi] + [(x, -1) for x in d1 - d2 if lo <= x < hi])
            if len(sites) < 2:
                continue
            lab = [v for _, v in sites]
            p, h, k = scan_p(lab)
            if k == 0 or k == len(lab):
                continue
            b = (sites[k - 1][0] + sites[k][0]) // 2 + 1
            single = min(len([x for x in d if lo <= x < hi]) for (s_, e_, d) in diff.values() if s_ <= lo and e_ >= hi)
            mos = sum(1 for x in d1 if lo <= x < b) + sum(1 for x in d2 if b <= x < hi)
            if single - mos < MOSAIC_GAIN:
                continue
            sl, cl = lab[:k].count(1), lab[:k].count(-1)
            sr, cr = lab[k:].count(-1), lab[k:].count(1)
            padj = min(1.0, p * m_tests)
            if best is None or padj < best[6]:
                best = (c1, c2, b, sl, sr, cl + cr, padj)
    return best if best is not None and best[6] <= MOSAIC_ALPHA else None


_X = {}


def _init_exact(seqs):
    _X["seqs"] = seqs
    _X["al"] = {}


def exact_div(tseq, qseq, al):
    """Exact divergence of qseq against tseq: (substitutions + indel events) / aligned columns, with the coverage
    rules of a relative; None if they fail."""
    h = next(iter(al.map(qseq, cs=True)), None)
    if h is None:
        return None
    span = min(h.q_en - h.q_st, h.r_en - h.r_st)
    if h.blen < MIN_ALN or span / min(len(qseq), len(tseq)) < MIN_COV or span / max(len(qseq), len(tseq)) < MIN_COV_LONG:
        return None
    d = sum(1 for op, _ in _cs_ops(h.cs) if op in "*+-")
    return d / h.blen, h.blen


def _exact_job(job):
    q, ts = job
    seqs, cache = _X["seqs"], _X["al"]
    out = []
    for t in ts:
        if t == q:
            continue
        if t not in cache:
            if len(cache) > 256:          # bounded per-worker cache of aligner indexes (memory, not results)
                cache.clear()
            cache[t] = mappy.Aligner(seq=seqs[t], preset="asm5", best_n=1)
        r = exact_div(seqs[t], seqs[q], cache[t])
        if r is not None:
            out.append((q, t, round(r[0], 6), r[1]))
    return out


def screen_paf(path):
    """Approximate hits (no base alignment): (query, target, approximate divergence dv)."""
    with open(path) as fh:
        for line in fh:
            x = line.rstrip("\n").split("\t")
            if x[0] == x[5]:
                continue
            dv = next((float(f[5:]) for f in x[12:] if f.startswith("dv:f:")), 1.0)
            yield x[0], x[5], dv


def read_exact(path):
    df = pd.read_csv(path, sep="\t", dtype={"q": str, "t": str})
    return df.sort_values(["q", "de"]).drop_duplicates(["q", "t"])


def parse_paf(path, self_ok=False):
    rows = []
    with open(path) as fh:
        for line in fh:
            x = line.rstrip("\n").split("\t")
            q, ql, qs, qe, t, tl, ts, te, blen = x[0], int(x[1]), int(x[2]), int(x[3]), x[5], int(x[6]), int(x[7]), int(x[8]), int(x[10])
            if q == t and not self_ok:
                continue
            if (blen < MIN_ALN or min(qe - qs, te - ts) / min(ql, tl) < MIN_COV
                    or min(qe - qs, te - ts) / max(ql, tl) < MIN_COV_LONG):
                continue
            de = next((float(f[5:]) for f in x[12:] if f.startswith("de:f:")), np.nan)
            rows.append((q, t, de, blen))
    df = pd.DataFrame(rows, columns=["q", "t", "de", "blen"])
    return df.sort_values(["q", "de"]).drop_duplicates(["q", "t"])


def run(args):
    v = args.verbose
    if shutil.which("minimap2") is None:
        sys.exit("ltrkin: minimap2 not found on PATH (needed by ltrkin source)")
    try:
        fa = pysam.FastaFile(args.reference)          # builds the .fai if needed
    except (OSError, ValueError) as err:
        sys.exit(f"ltrkin: cannot index {args.reference} ({err}): plain or bgzip-compressed FASTA in a writable "
                 f"directory, or run samtools faidx on it first")
    try:
        els = {e.id: e for e in read_gff3(args.annotation)}
    except ValueError as err:
        sys.exit(f"ltrkin: {err}")
    missing = {e.chrom for e in els.values()} - set(fa.references)
    if missing:
        log(f"warning: {len(missing)} annotation sequence(s) not in the reference, skipped: {sorted(missing)[:5]}")
        els = {k: e for k, e in els.items() if e.chrom not in missing}
    status, ncalled, coords = status_table(args.genotypes)
    shared = [k for k in status.index if k in els]
    if not shared:
        sys.exit(f"ltrkin: no element ID of the genotype table(s) is in {args.annotation}: give the annotation "
                 "used for genotyping")
    moved = [] if coords is None else [k for k in shared
                                       if (els[k].chrom, els[k].start + 1, els[k].end) != tuple(coords.loc[k])]
    if moved:
        sys.exit(f"ltrkin: {len(moved)} element(s) have other coordinates in {args.annotation} than in the genotype "
                 f"table(s), e.g. {moved[0]}: give the annotation used for genotyping")
    status = status.reindex(list(els)).fillna("other")
    for e in els.values():
        e.tsd = infer_tsd(fa, e)
    seqs = {e.id: own_internal(fa, e) for e in els.values()}
    cand = [e for e in els.values() if len(seqs[e.id]) >= MIN_INTERNAL]
    log(f"{len(els)} elements; status {status.value_counts().to_dict()}; candidates (internal >= {MIN_INTERNAL} bp) "
        f"{len(cand)}", v)
    work = args.output + ".work"
    os.makedirs(work, exist_ok=True)
    # cached alignments are valid only for the same candidates, statuses, sequences and search scheme
    key = hashlib.sha1(("search=two-stage-v1;" + __version__ + ";" + ";".join(
        f"{e.id}:{status[e.id]}:{e.family}:{hashlib.sha1(seqs[e.id].encode()).hexdigest()}"
        for e in sorted(cand, key=lambda x: x.id))).encode()).hexdigest()
    kf = f"{work}/cache.key"
    if not os.path.exists(kf) or open(kf).read() != key:
        for f in os.listdir(work):
            if f.endswith(".done"):
                os.remove(os.path.join(work, f))
        open(kf, "w").write(key)
    groups = {"new": [e for e in cand if status[e.id] == "new"], "fixed": [e for e in cand if status[e.id] == "fixed"]}
    if not groups["new"] or not groups["fixed"]:
        log(f"no source to assign: {len(groups['new'])} new and {len(groups['fixed'])} fixed copies with an internal "
            f"region >= {MIN_INTERNAL} bp (status from calls with GQ >= {GQ_STATUS}); tables left empty", True)
        for suf, c in ((".sources.tsv", SRC_COLS), (".copies.tsv", COPY_COLS), (".locality.tsv", LOC_COLS)):
            pd.DataFrame(columns=c).to_csv(args.output + suf, sep="\t", index=False)
        return
    # two-stage search per family (unlabeled copies form one group): (1) approximate mapping of new copies against
    # every target of the group (minimap2 without base alignment, -N = group size, so no target is crowded out);
    # (2) exact alignment (mappy, cs) of the TOP_K targets with the lowest approximate divergence
    fams = {}
    for e in cand:
        fams.setdefault(e.family if e.family != "." else "_unlabeled", []).append(e)
    for tgt in ("fixed", "all"):
        out = f"{work}/new_vs_{tgt}.tsv"
        if os.path.exists(out + ".done"):
            continue
        pairs = {}
        for fam, lst in sorted(fams.items()):
            new = [e for e in lst if status[e.id] == "new"]
            tg = [e for e in lst if status[e.id] == "fixed"] if tgt == "fixed" else lst
            if not new or not tg or (tgt == "all" and len(tg) < 2):
                continue
            qf, tf, pf = f"{work}/q.fa", f"{work}/t.fa", f"{work}/part.paf"
            for path, ss in ((qf, new), (tf, tg)):
                with open(path, "w") as fh:
                    for e in ss:
                        fh.write(f">{e.id}\n{seqs[e.id]}\n")
            with open(pf, "w") as fo, open(pf + ".log", "w") as fe:
                r = subprocess.run(["minimap2", "-x", "asm5", "-p", "0", "-t", str(args.threads), "-N", str(len(tg)),
                                    tf, qf], stdout=fo, stderr=fe)
            if r.returncode:
                sys.exit(f"ltrkin: minimap2 failed (exit {r.returncode}); see {pf}.log")
            for q, t, dv in screen_paf(pf):
                pairs.setdefault(q, []).append((dv, t))
        jobs = [(q, [t for _, t in sorted(v)[:TOP_K]]) for q, v in pairs.items()]
        with Pool(args.threads, initializer=_init_exact, initargs=(seqs,)) as pool, open(out, "w") as fo:
            fo.write("q\tt\tde\tblen\n")
            for res in pool.imap_unordered(_exact_job, jobs, chunksize=8):
                for q, t, de, blen in res:
                    fo.write(f"{q}\t{t}\t{de}\t{blen}\n")
        open(out + ".done", "w").close()
        log(f"search new vs {tgt}: {len(jobs)} new copies, {sum(len(t) for _, t in jobs)} exact alignments", v)
    fx = read_exact(f"{work}/new_vs_fixed.tsv")
    al = read_exact(f"{work}/new_vs_all.tsv")
    fx = fx[np.array([not nested_pair(els[q], els[t]) for q, t in zip(fx.q, fx.t)], dtype=bool)]   # a list [] would
    al = al[np.array([not nested_pair(els[q], els[t]) for q, t in zip(al.q, al.t)], dtype=bool)]   # select columns
    al["t_status"] = status.reindex(al.t).values
    # copies table: age, nearest relatives
    ages = {}
    need = {e.id for e in groups["new"]} | set(fx.t)
    for eid in need:
        sub, ts, ind, n = ltr_diffs(fa, els[eid])
        ages[eid] = (sub, ind, k2p(sub, ts, n))
    near_any = al.groupby("q").head(1).set_index("q")
    fx_q = {k: d for k, d in fx.groupby("q")}
    al_q = {k: d for k, d in al.groupby("q")}
    rows = []
    for e in groups["new"]:
        h = fx_q.get(e.id)
        if h is None or h.empty:
            continue
        best = h.de.min()
        tied = h[(h.de - best) * h.blen <= TIE_DIFFS]
        na = near_any.loc[e.id] if e.id in near_any.index else None
        oth = al_q.get(e.id, al.iloc[:0]).head(N_NEAREST + 5)
        mcand = {t: seqs[t] for t in list(oth.t)[:N_NEAREST] + list(tied.t) if t != e.id}
        mos = mosaic_test(seqs[e.id], mcand)
        for r in tied.itertuples():
            m = els[r.t]
            others = [seqs[t] for t in oth.t if t not in (e.id, m.id)][:N_NEAREST]
            sh = shared_mutations(seqs[m.id], seqs[e.id], others)
            fid = flank_identity(fa, e, m)
            same_tsd = bool(e.tsd) and e.tsd == m.tsd
            closer = na is not None and na.t != m.id and (r.de - na.de) * r.blen >= 1 and na.t_status != "fixed"
            flags = []
            if same_tsd or fid >= FLANK_DUP_ID:
                flags.append("segdup")
            if closer:
                flags.append("closer_nonfixed_relative")
            if len(tied) > 1:
                flags.append("tied")
            if mos is not None:
                flags.append("recombinant")
            older = ages[m.id][0] - ages[e.id][0] >= OLDER_DIFFS if ages[m.id][0] == ages[m.id][0] else False
            rows.append(dict(
                new_id=e.id, new_chrom=e.chrom, new_start=e.start + 1, new_end=e.end, family=e.family, clade=e.clade,
                source_id=m.id, source_chrom=m.chrom, source_start=m.start + 1, source_end=m.end,
                divergence=round(r.de, 5), aln_len=r.blen, est_diffs=round(r.de * r.blen, 1), n_tied=len(tied),
                weight=round(1 / len(tied), 4), same_chrom=e.chrom == m.chrom,
                distance=abs((e.start + e.end) / 2 - (m.start + m.end) / 2) if e.chrom == m.chrom else np.nan,
                nearest_any_id=na.t if na is not None else ".", nearest_any_status=na.t_status if na is not None else ".",
                nearest_any_div=round(na.de, 5) if na is not None else np.nan,
                new_ltr_diffs=ages[e.id][0], source_ltr_diffs=ages[m.id][0], source_older=older,
                same_tsd=same_tsd, flank_identity=round(fid, 3), shared_derived=sh[0], source_private=sh[1],
                new_private=sh[2], consensus_sites=sh[3],
                mosaic_left=mos[0] if mos else ".", mosaic_right=mos[1] if mos else ".",
                mosaic_breakpoint=mos[2] if mos else np.nan, mosaic_support=f"{mos[3]},{mos[4]}" if mos else ".",
                mosaic_conflicts=mos[5] if mos else np.nan, mosaic_p_adj=mos[6] if mos else np.nan,
                flags=",".join(flags) or "PASS"))
    src = pd.DataFrame(rows, columns=SRC_COLS)
    src.to_csv(args.output + ".sources.tsv", sep="\t", index=False)
    cp = []
    for e in cand:
        na = near_any.loc[e.id] if e.id in near_any.index else None
        h = fx_q.get(e.id, fx.iloc[:0])
        cp.append(dict(element_id=e.id, chrom=e.chrom, start=e.start + 1, end=e.end, family=e.family, clade=e.clade,
                       status=status[e.id], n_called=int(ncalled.get(e.id, 0)), internal_len=e.internal[1] - e.internal[0],
                       ltr_diffs=ages.get(e.id, (np.nan,))[0], ltr_k2p=ages.get(e.id, (np.nan,) * 3)[2],
                       nearest_any_id=na.t if na is not None else ".", nearest_any_div=na.de if na is not None else np.nan,
                       nearest_fixed_id=h.t.iloc[0] if len(h) else ".", nearest_fixed_div=h.de.iloc[0] if len(h) else np.nan))
    pd.DataFrame(cp, columns=COPY_COLS).to_csv(args.output + ".copies.tsv", sep="\t", index=False)
    loc = locality(src, fa, cand)
    loc.to_csv(args.output + ".locality.tsv", sep="\t", index=False)
    log(f"new copies with a fixed relative: {src.new_id.nunique() if len(src) else 0}; pairs {len(src)}", v)
    if v and len(loc):
        print(loc.to_string(index=False), file=sys.stderr)
    log("done", True)


def flank_identity(fa, a, b):
    """Best SW identity between the FLANK-bp flanks of two copies (both orientations)."""
    def fl(e):
        L = fa.get_reference_length(e.chrom)
        t = len(e.tsd) if e.tsd else 0
        return (fa.fetch(e.chrom, max(0, e.start - t - FLANK), max(0, e.start - t)).upper(),
                fa.fetch(e.chrom, min(L, e.end + t), min(L, e.end + t + FLANK)).upper())
    a1, b1 = fl(a)
    a2, b2 = fl(b)
    best = 0.0
    for x, y in ((a1, a2), (b1, b2), (a1, rc(b2)), (b1, rc(a2))):
        best = max(best, sw_identity(x, y))
    return best


def _same_stat(new_chrom, src_chrom, w):
    return float(np.sum(w * (new_chrom == src_chrom)))


def locality_test(d, share, rng, n_perm=PERM):
    """Same-chromosome test for one set of (new copy, source) pairs with tie weights.
    bp null: each new copy shares its source's chromosome with probability = its own chromosome's bp share
             (Poisson-binomial; assumes independent new copies).
    permutation null: the new copies' chromosome labels are shuffled among new copies, sources and their offspring
             clusters kept; controls for shared sources and for chromosomes rich in both sources and new copies."""
    f = d.assign(s=d.same_chrom * d.weight).groupby("new_id").agg(same=("s", "sum"), c=("new_chrom", "first"))
    obs = float(f.same.sum())
    nul = share.reindex(f.c).fillna(0).values
    p_bp = float(np.mean((rng.random((n_perm, len(f))) < nul).sum(1) >= obs - 1e-9))
    ids = f.index.values
    lab = f.c.values
    idx = pd.Index(ids).get_indexer(d.new_id.values)
    sc, w = d.source_chrom.values, d.weight.values
    null = np.empty(n_perm)
    for k in range(n_perm):
        perm = lab[rng.permutation(len(lab))]
        null[k] = _same_stat(perm[idx], sc, w)
    p_perm = float(np.mean(null >= obs - 1e-9))
    return dict(n_new=len(f), same=round(obs, 2), expected=round(nul.sum(), 2),
                obs_exp=round(obs / nul.sum(), 2) if nul.sum() else np.nan, p=p_bp,
                perm_expected=round(float(null.mean()), 2),
                perm_obs_exp=round(obs / null.mean(), 2) if null.mean() else np.nan, perm_p=p_perm)


def locality(src, fa, cand, seed=11):
    """Same-chromosome locality per clade (and per family with >= 5 new copies) for cumulative source-divergence
    limits (a distant nearest fixed copy is not a plausible source). Two nulls: see locality_test."""
    if src.empty:
        return pd.DataFrame(columns=LOC_COLS)
    chroms = sorted({e.chrom for e in cand})
    lens = pd.Series({c: fa.get_reference_length(c) for c in chroms}, dtype=float)
    share = lens / lens.sum()
    ok = src[~src["flags"].str.contains("segdup")].copy()
    ok["weight"] = 1.0 / ok.groupby("new_id").new_id.transform("size")
    rng = np.random.default_rng(seed)
    out = []
    for maxd in DIV_LIMITS:
        sel = ok[ok.divergence <= maxd]
        for level in ("clade", "family"):
            for g, d in sel.groupby(level):
                r = locality_test(d, share, rng)
                dd = d[d.same_chrom].distance
                out.append(dict(max_divergence=maxd, level=level, group=g, **r,
                                median_distance_mb=round(dd.median() / 1e6, 2) if len(dd) else np.nan))
    o = pd.DataFrame(out, columns=LOC_COLS)
    if o.empty:                                    # e.g. every pair flagged segdup
        return o
    return o[(o.level == "clade") | (o.n_new >= 5)].sort_values(["level", "group", "max_divergence"])
