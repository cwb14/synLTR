# Plan 3 final fix wave: report

Status: DONE_WITH_CONCERNS (all five items done, one commit, suite launched; the concerns are scope calls, listed last).
Commit: 256a914 "Document the simulator's assumptions and defaults; mark a lastz test; DESIGN 12 grid size" on
plan3-benchmark (parent a44f532). 41 files, +359/-255.

## Items

### I1: the simulator's assumptions, visible to users

- `src/ltrpav/sim/pop.py:85-103`: SIMPLIFICATIONS grows from 4 to 12 entries, one line each, in pipeline order
  (genealogy, events, builder, truth). params.json writes it unchanged (`pop.py:404`).
  - The five items the brief lists are there. Truth's G and O limits are two separate approximations, so they take two
    lines. That makes 6 new entries.
  - I also added the two approximations the docstrings call "named heuristics": the per-region recombination rule
    (`popmodel.py:11-12`) and the exponential replacement length (`popevents.py:20-21`). The brief asks for every
    approximation. See concern 2.
  - Each line was checked against its docstring:

    | entry | docstring |
    |---|---|
    | 5 | `popevents.py:63` |
    | 8 | `popbuild.py:19-24` |
    | 9 | `popbuild.py:57-62` |
    | 10 and 11 | `poptruth.py:28-31` |
    | 12 | `poptruth.py:38-46` |

  - The K-at-root size is 2 x mu x t_o = 2 x 3e-8 x 900,000 = 0.054. It is a lower bound, because every tree's root lies
    above t_o.
  - The tract-end size is the bp share measured on lossy toy landscapes. That is the share Task 4's re-review called
    the transferable figure.
  - `popbuild.py:61-62` now calls K-at-root "a named approximation", like the others.
- `src/ltrpav/sim/cli.py`: an epilog on `pop --help`.
  - `cli.py:36-46`, `_Lines`: a help formatter that keeps the epilog's line breaks and fills each line to the terminal
    width, with continuation lines under their text. The description wraps as before.
  - `cli.py:49-57`, `_show`: prints a field with its default.
  - `cli.py:60-85`, `_POP_EPILOG`: the epilog text.
  - `cli.py:114`: the `pop` subparser uses the formatter and the epilog.
  - Every default in the epilog is read from `Demog()` and `Rates()`, so the text cannot drift from the code.
  - Sources follow DESIGN 12 and the plan:
    - LTRmix's demography and rates;
    - small indels at mu/10 (item 6);
    - t_o, loss_split and replace_mean calibrated on real genomes (items 2, 5 and 34).

    No maize names appear.

### M1: the lastz test

`tests/test_cli_analysis.py:794`: `@needs_lastz` on `test_block_size_reaches_every_jackknife`.

### M2: DESIGN 12 item 1

`docs/DESIGN.md:794-798`, added text:

> The pre-registered budget gate's fallback, the first five windows (50 Mb) for every run, was taken: the pilot
> projected 111.6 h with 30 bottleneck nulls and 98.4 h with 10 at 100 Mb, both above 96 h, so the grid ran on 50 Mb
> (70.1 h projected with 30 nulls).

The numbers come from the ledger (progress.md:134 and :143). The rule is the plan's decision rule 3.

### M3: the convention of insertions.tsv's pos

The convention is 0-based, as in BED. The copy goes before base pos of the chromosome's backbone (0 at the region's
START), or of its host's donor body when host is an iid. So pos is no output genome's coordinate. It is now stated in
three places:

- `pop.py:476-478`, write_pop's docstring. It also names the truth TSVs' start/end as 1-based inclusive in X.
- `poptruth.py:50-53`, the insertion-table docstring, which documents the columns. It also gives time in generations
  ago and node as the tree node below the event.
- The `--help` epilog.

DESIGN 10.2 does not list the columns, so it is unchanged.

### M4 (partial): process vocabulary outside analysis/

- sim/ source files:

  | file | lines | change |
  |---|---|---|
  | `popbuild.py` | 6, 61, 64, 66 | rewritten |
  | `popbuild.py` | 377-379 | the user-visible ValueError now reads "(popevents rule 4, existence: thin_events would discard them)"; test_popbuild's `match="existence"` still holds |
  | `poptruth.py` | 17 | "R1:" becomes "there is no site_lost state:" |
  | `poptruth.py` | 41 | "(ruling C3)" removed |
  | `poptruth.py` | 45 | "Measured (Task 4 review)" becomes "Measured on lossy test landscapes (tracts of 1-20 kb)" |
  | `donors.py` | 35 | "(final review M6)" removed |

- Test files: 225 edits across 35 files, applied by a script. Every edit had to match its file exactly once before
  anything was written.
  - Covered phrases include "final review Xn", "Task N review mN", "controller ruling", "the brief's",
    "beyond the brief", "fix round N", "T7 deferred minor", "24H review minor", "Review Focus N", "replica rr_toy.py",
    "Pre-flight A30-A32", "The Global Constraint" and bare finding IDs such as "M5:", "(I2, N1)" and "(24F)".
  - Each was rewritten to say what the code does or why. Example: "the old panel H asked for a negative width" became
    "a panel H of fixed size would need a negative width".
  - About 18 of these lines came from this branch; the rest are older (see concern 1).
- Proof that only text changed: for all 43 test files, the AST before and after is identical once docstrings are blanked
  (`ast_same.py`: 43 of 43).
- The same check against a44f532 passes for `donors.py` and `poptruth.py`. In `cli.py`, `pop.py` and `popbuild.py`, the
  only code changes are the ones described above.
- Not touched:
  - "Plan N" design references, such as "Plan 1's rules" and "DESIGN 12, Plan 3 calibration". These point into
    DESIGN.md's own section names.
  - Commit messages.
  - Test identifiers such as `_probe_run`. "probe" there names a test scenario.

## New SIMPLIFICATIONS (params.json "simplifications")

1. "each region recombines at r_low between its fractions low[0] and low[1] (by default its middle 40%) and at r
   elsewhere: LTRmix's per-chromosome rule applied to every region"
2. "replacement lengths are exponential with mean replace_mean (an assumed shape; the mean is measured)"
3. "replacing sequence and the solo LTR of a simulated insertion receive no insertions"
4. "an event is discarded when the lineage of any one of its carriers lacks its sequence (any-carrier thinning)"
5. "a backbone element can take later losses until older losses have removed its whole span"
6. "replacing sequence and inserted indel bases take no substitutions"
7. "a primary insertion's TSD bases at insertion time assume one mutation per SNP site"
8. "a small deletion that overlaps a removal with the same carriers is taken as younger than the removal and is not
   made (indel times are not kept; a few bp per event)"
9. "a backbone element's annotated K is read as its K at the root, so each sample's copy exceeds it by about
   2 x mu x T_root (T_root, the root's age, is at least t_o: 0.054 or more at the defaults)"
10. "truth: a copy Y holds without an image (deleted), or an absent one whose empty-site window is broken, has no site
    in Y, so it is never G"
11. "truth: O (another insertion at the target in Y) does not ask whether X carries that insertion too"
12. "truth: a tract end inside a stretch the sample deleted lifts to the next kept base, so a payload anchored there
    falls on the wrong side of the end (0.05% of tract bp on test landscapes)"

Entries 3, 4, 6 and 7 are the old four, with their text unchanged.

## The `pop --help` epilog (COLUMNS=100)

```
defaults: LTRmix's demography and rates, small indels at mu/10, and three values calibrated on
real genomes (docs/DESIGN.md, section 12): t_o from their outgroup conflict, loss_split and
replace_mean from their element losses. A --demography JSON object sets any of these fields by
name (a list as a JSON array, none as null).
  Ne          diploid effective sizes: ne_a 30000, ne_b 100000, ne_c 70000, ne_bc 150000 (the
              ancestor of B and C), ne_o 150000, ne_root 150000 (the ancestor of BC and O)
  splits      generations ago: t_ab 9000 (A from B), t_bc 60000 (B from C), t_o 900000 (O from BC)
  pulse       f 0 (the share of the recipient's lineages it moves), ta 5000 generations ago, pulse
              C>A (donor>recipient); per_taxon 2 genomes per taxon
  lineages    sub_a none, sub_c none, else [split generations, Ne] of A1's or C1's own population:
              pulse C>A1 needs sub_a, C1>A1 and A1>C1 need sub_a and sub_c, and ta must lie below
              their splits when f > 0
  bottleneck  bottleneck none, else [Ne, generations] of A right after its split from B
  rates       per generation: mu 3e-08 substitutions per bp; r 1e-08 and r_low 1e-09 crossovers
              per bp, r_low between the fractions low [0.3, 0.7] of each region; lam 1.2e-10
              insertions per bp; delta 1.11111e-06 (1/900000) losses per element; indel 3e-09
              small indels per bp; copy_noise 0.005 substitutions per base of a new copy
  losses      loss_split [0.123, 0.164, 0.511, 0.202], the shares of solo, del_flank, del_partial
              and replace; replace_mean 13538, the mean replacement length in bp

truth/insertions.tsv: pos is 0-based, as in BED: the copy goes before base pos of its chromosome's
backbone (0 at its region's START) when host is ".", else of its host insertion's donor body, so
pos is a coordinate of no output genome; time is in generations ago.
params.json lists the simplifications the simulation makes.
```

The lineage requirements match `popmodel.py:109-116`:

- C>A1 is ("C", "A1p"), so it needs sub_a.
- C1>A1 and A1>C1 involve both A1p and C1p, so they need sub_a and sub_c.
- When f > 0, ta must lie below the lineage splits.

## TDD evidence

The tests were written first, in `tests/test_pop_cli.py`.

- `NAMED` (`:45-47`): one key phrase per approximation.
- `test_pop_writes_outputs` (`:175-177`): params.json's list equals `SIMPLIFICATIONS`, has `len(NAMED)` entries, and each
  key phrase is in exactly one entry. This replaced the old `SIMPLIFICATIONS = 4  # R1's ...` count.
- `test_pop_help_epilog` (`:226-245`), new:
  - every Demog and Rates field appears in the help text, as "name default";
  - the sources, the sub_a/sub_c sentence, the pos convention and the params.json pointer appear;
  - no help line is longer than 80 columns.

Results, in order:

| step | result |
|---|---|
| before the change | `test_pop_writes_outputs` fails on `4 == 12` (len(simple) against len(NAMED)) |
| before the change | `test_pop_help_epilog` fails on `assert 'ne_a 30000' in 'tracebacks on errors'` (no epilog) |
| after the change | both pass; the five pop test files give 107 passed |
| final focused run | test_pop_cli, popbuild, poptruth, popevents, popmodel, sim and the M1 test: 178 passed, 1 deselected (slow); exit 0 |
| M1 with lastz on PATH | 1 passed |
| M1 with lastz removed from PATH | `SKIPPED [1] tests/test_cli_analysis.py:794: lastz (the window aligner) not on PATH`; before the decorator, the review saw it fail |
| ruff check . | All checks passed (ruff 0.17.4) |
| pytest --collect-only | 1,284 tests in 40 files, no errors |

## Fingerprints and the protected diff

- `git diff a44f532 HEAD -- src/ltrpav/analysis src/ltrpav/constants.py src/ltrpav/checkpoint.py` is empty (0 bytes).
  Package code changed only in `src/ltrpav/sim/` (cli, donors, pop, popbuild, poptruth).
- STAGE_MODULES fingerprints: computed from a `git archive` of 12d3e6c (and of a44f532) imported through PYTHONPATH,
  and from the working tree at 256a914. The `ltrpav.__file__` paths printed show which copy was imported. All 7
  fingerprints equal 12d3e6c's, and so do their module sets:

  | stage | fingerprint |
  |---|---|
  | anchor | ebbfd97f3b749402 |
  | raw | ebbfd97f3b749402 |
  | blastdb | ebbfd97f3b749402 |
  | elements | a78af75d7a7cc6c5 |
  | genotype_pair | 52071c27df67dee4 |
  | genotype_chunk | 52071c27df67dee4 |
  | mm2_index | 28f6fc7945c99c18 |

- Analysis fingerprints equal a44f532's (stats and paint b30e708915f64240, plot 27d66a28b6becaaa). So no finished
  real-genome view goes stale.

## Remaining process traces under src/ltrpav/analysis/ (left for Plan 4; editing them re-keys the views)

- `analysis/cli.py:228` "(M3)"
- `analysis/common.py:1` "(final review M16: once private to relations.py and trio.py, now one ..."
- `analysis/constants.py:20` "(final review C1, N1)"
- `analysis/direction.py:14` "(plan review I11)"
- `analysis/direction.py:200` "(final review M7)"
- `analysis/identity.py:31-32` "controller ruling M1, Task 9 review"
- `analysis/identity.py:35` "(controller ruling M2, which supersedes plan 2's orientation ..."
- `analysis/identity.py:60` "(controller ruling M5)"
- `analysis/inversions.py:14` "(plan 2 final review C1: ..."
- `analysis/inversions.py:36` "final review N1: ..."
- `analysis/inversions.py:224` "(final review N1)"
- `analysis/paint.py:4` "plan review C1"
- `analysis/paint.py:36` "(pre-flight A24)"
- `analysis/paint.py:543` "(final review M4)"
- `analysis/paint.py:870` "(Task 6 review m4)", the one this branch added
- `analysis/relations.py:652-653` "plan review C1's principle; controller ruling, Task 3 fix round 1"
- `analysis/report.py:328` "(final review M2)"
- `analysis/report.py:337` "(final review M2)"
- `analysis/report.py:359` "(plan 2 final review I2)"
- `analysis/report.py:425` "(M14)"
- `analysis/report.py:503` "final review M8:"
- `analysis/report.py:560` "(final review M3; ..."
- `analysis/stats.py:75` "(final review M15, documented)"
- `analysis/stats.py:97` "(final review M15)"
- `analysis/stats.py:171` "(final review M15: ..."
- `analysis/trio.py:9` "(plan review C1)"
- `analysis/trio.py:25` "review I2:"
- `analysis/trio.py:36` "(controller ruling, Task 4 fix round 1)"
- `analysis/trio.py:53` "(controller ruling, Task 4 fix round 1)"
- `analysis/trio.py:399` "(plan 2 final review I1)"

Two pattern hits are not traces: `identity.py:214` ("(m0)", a variable) and `paint.py:933` ("lit_review.md").

The brief did not ask for these, but the same kind of text also remains outside analysis/, in code I must not touch.

- `src/ltrpav/plot/overview.py`: 11 lines (:42, :204, :535, :2284, :2330, :2373, :2385, :2500, :2806, :2822, :2994).
  The plot stage's analysis fingerprint covers this file.
- Engine modules, 11 lines:
  - `annotation/records.py:2`
  - `checkpoint.py:10`
  - `constants.py:35, :38, :46, :48, :49`
  - `genotype.py:136`
  - `localign.py:6, :329`
  - `outputs/vcf.py:5`
- `classify.py:159` "(R3b)" and `:168` "(R10)" look like rule labels, not traces.

Plan 4's scrub list should name all three groups.

## Commit

- 256a914, one commit on plan3-benchmark.
- Author and committer: cwb14 <cwbenson1993@gmail.com>, the global identity.
- No trailer and no attribution. The message names no review step (checked by grep).
- The working tree is clean after the commit. Nothing was pushed and no branch was created.

## Suite launch

- Started 2026-11-14 20:40:34, after the commit. The command is the brief's, verbatim, with SUITE_DIR filled in.
- SUITE_DIR: `/tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3-final-fix/suite`
- Outputs: `suite.log` and `suite.exit` in that directory.
- Processes: bash PID 1492814 (PPID 1, SID = PID, session leader) and pytest PID 1492815.
- At the last look the log was at 28%. I did not wait for it.
- Threads: the session exports OMP/OPENBLAS/MKL/NUMBA_NUM_THREADS=8, and the job inherits them, so it stays within the
  8-thread limit. Load average was about 52 at launch.

## Concerns

1. **The test scrub covers all test files, not only this branch's lines.**
   - I read the brief's "test files" literally. That gives 35 files and 225 edits; about 18 lines were this branch's,
     and most of the rest come from Plan 1 and 2 tests.
   - My reasons: tests carry no stage key, the user's rule bars process comments anywhere in the repo, and the brief's
     own example phrases ("controller ruling", "the brief's") occur only in older test files.
   - The AST check shows no test changed behavior.
   - If only the narrow scope was wanted, the extra edits are harmless, but they make a larger diff to review.
2. **Two entries go beyond the review's list.** SIMPLIFICATIONS also names the per-region recombination rule and the
   exponential replacement shape, because the docstrings call them named heuristics and the brief asks for every
   approximation. Drop entries 1 and 2 if the list should hold only the review's items.
3. **The formatter relies on a private argparse method.** `_Lines` overrides `_fill_text`, the same hook that
   RawDescriptionHelpFormatter overrides. A future Python could change it, and `test_pop_help_epilog` would then fail
   (not pass silently).
4. **`pop --help` is now 88 lines at 80 columns.** No short-help test covers `pop`.
5. **Remaining traces.** The traces listed above remain, and so do the 8 commit messages the review names. The brief
   asked me to leave commit messages alone.
