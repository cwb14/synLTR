### Task 4: Samples sheet (`samples.py`)

**Files:** Create `src/ltrpav/samples.py`, `tests/test_samples.py`

**Interfaces:**
- Produces: `@dataclass(frozen=True) class Sample: label: str; fasta: Path; annotation: str | None; group: str | None; role: str | None`;
  `read_samples(path: Path) -> list[Sample]`; `class SampleSheetError(ValueError)`.

- [ ] **Step 1: Write the failing tests.** Sheet = TSV with header `label fasta annotation group role` (`group`,
  `role` optional columns; `.` = none; `#` lines skipped; relative paths resolved against the sheet's directory).

```python
def test_read_valid_sheet(tmp_path): ...       # 3 rows; annotation "." -> None; role "outgroup" kept; paths absolute
def test_errors(tmp_path):
    # each must raise SampleSheetError whose message names the problem:
    # duplicate label; label not matching ^[A-Za-z0-9_.-]+$ ("B 73", "a|b"); missing fasta file;
    # fewer than 2 rows; no row with an annotation; unknown role (only "outgroup" allowed)
```

- [ ] **Step 2: Run** the tests. Expected: FAIL.
- [ ] **Step 3: Implement** `read_samples` (csv module, tab-delimited). Report every missing file in one error.
  Annotation paths are resolved but not checked here (an LTRquest prefix is not a file; Task 8 checks them).
- [ ] **Step 4: Run** the tests. Expected: PASS.
- [ ] **Step 5: Commit** `"Add samples sheet parser"`.

---

