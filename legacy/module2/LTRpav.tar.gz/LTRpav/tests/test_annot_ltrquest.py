import logging

import pytest

from ltrpav.annotation.ltrquest import load_ltrquest
from ltrpav.constants import RECORD_WARNINGS
from ltrpav.elements import ELEMENT_COLUMNS, Element, make_eid, read_elements, write_elements

HEADER = '#seq_id\tseq_len\tstatus\tltr5_start\tltr5_end\tltr3_start\tltr3_end\tltr5_len\tltr3_len\tflank5_len\tflank3_len\taln_len\tn_sites\tn_ts\tn_tv\tn_gapcols\tidentity\tp_dist\tk2p\tk2p_se\tbitscore\tflank_margin_bits\tcigar\tmotif\tk2p_time\torientation\ttsd\ttsd_offset\ttsd_input\tstrand\tfamily\tconfidence\tdomains\tnest_status'
ROW_INNER = 'B73v5_chr1:60664-70130#LTR/Copia/SIRE\t9467\tpass\t1\t1322\t8163\t9467\t1322\t1305\t0\t0\t1324\t1303\t0\t0\t21\t1\t0\t0\t0\t1253\tNA\t23=2D861=19I419=\ttg...ca\t0\t-\tCACTC\t0,0\tCACTC\t-\tmerged_fam00001\thigh\tRT|SIRE@63557-64321;RH|SIRE@62912-63289;INT|SIRE@65048-65650;PROT|SIRE@65837-66046;GAG|SIRE@67917-68198\tnest-inner:B73v5_chr1:51712-70182'
ROW_FAIL = 'B73v5_chr1:100-9566#LTR/Copia/SIRE\t9467\tfail\t1\t1322\t8163\t9467\t1322\t1305\t0\t0\t1324\t1303\t0\t0\t21\t1\t0\t0\t0\t1253\tNA\t23=2D861=19I419=\ttg...ca\t0\t-\tCACTC\t0,0\tCACTC\t-\tmerged_fam00001\thigh\tRT|SIRE@63557-64321;RH|SIRE@62912-63289;INT|SIRE@65048-65650;PROT|SIRE@65837-66046;GAG|SIRE@67917-68198\tnest-inner:B73v5_chr1:51712-70182'
ROW_HOST = 'B73v5_chr1:51712-70182#LTR/Copia/SIRE\t18471\tpass\t1\t1294\t7751\t18471\t1294\t1254\t0\t0\t1263\t1180\t4\t0\t83\t0.99661\t0.00338983\t0.00340137\t0.00170359\t987\tNA\t21=1I442=1X120=1I82=19D95=40I89=1X1=1X126=22I17=1X183=\ttg...ca\t56690\t-\tCACCT\t0,0\tCACCT\t-\tmerged_fam00001\thigh\tRT|SIRE@54531-55295;RH|SIRE@53886-54263;INT|SIRE@55974-56576;PROT|SIRE@56769-56978;GAG|SIRE@58654-58935\tnest-outer:B73v5_chr1:60664-70130'


@pytest.fixture(autouse=True)
def _files(tmp_path):
    (tmp_path / "X_depth0_clean_ltr.tsv").write_text(HEADER + "\n" + ROW_INNER + "\n" + ROW_FAIL + "\n")
    (tmp_path / "X_depth1_clean_ltr.tsv").write_text(HEADER + "\n" + ROW_HOST + "\n")


def test_load_ltrquest(tmp_path):
    els, skipped = load_ltrquest(str(tmp_path / "X"), "B73")
    inner = next(e for e in els if e.start == 60664)
    assert (inner.seqid, inner.end, inner.strand) == ("B73v5_chr1", 70130, "-")
    assert inner.ltr_left == (60664, 61985) and inner.ltr_right == (68826, 70130)
    assert inner.tsd == "CACTC" and inner.k == 0.0 and inner.family == "merged_fam00001"
    assert (inner.superfamily, inner.clade, inner.confidence) == ("Copia", "SIRE", "high")
    assert inner.eid == "B73|B73v5_chr1:60664-70130" and inner.name == "B73v5_chr1:60664-70130#LTR/Copia/SIRE"
    host = next(e for e in els if e.start == 51712)
    assert host.ltr_left == (51712, 53005) and host.ltr_right == (59462, 70182)
    assert skipped["status_not_pass"] == 1
    assert len(els) == 2


def test_missing_files(tmp_path):
    with pytest.raises(FileNotFoundError, match="_depth"):
        load_ltrquest(str(tmp_path / "nope"), "B73")


def test_bad_seq_id_and_na(tmp_path):
    c = ROW_INNER.split("\t")
    c[0] = "garbage#LTR/unknown"
    bad = "\t".join(c)
    c = ROW_INNER.split("\t")
    c[0] = "chrZ:5-99#LTR"
    c[HEADER.lstrip("#").split("\t").index("tsd")] = "NA"
    c[HEADER.lstrip("#").split("\t").index("k2p")] = "NA"
    c[HEADER.lstrip("#").split("\t").index("strand")] = "?"
    c[HEADER.lstrip("#").split("\t").index("family")] = "NA"
    na = "\t".join(c)
    (tmp_path / "X_depth0_clean_ltr.tsv").write_text(HEADER + "\n" + bad + "\n" + na + "\n")
    (tmp_path / "X_depth1_clean_ltr.tsv").unlink()
    els, skipped = load_ltrquest(str(tmp_path / "X"), "G")
    assert skipped["bad_seq_id"] == 1 and len(els) == 1
    e = els[0]
    assert (e.tsd, e.k, e.strand, e.family) == (None, None, ".", None)
    assert (e.superfamily, e.clade) == (None, None)


def test_elements_tsv_round_trip(tmp_path):
    els, _ = load_ltrquest(str(tmp_path / "X"), "B73")
    extra = Element("g", make_eid("g", "c", 1, 10), "c:1-10#LTR", "c", 1, 10, ".", (1, 2), (9, 10),
                    None, 0.0123456789012345, None, None, None, None, parent="g|c:0-99", level=2)
    els = els + [extra]
    p = tmp_path / "e.tsv"
    write_elements(els, p)
    assert p.read_text().splitlines()[0] == "\t".join(ELEMENT_COLUMNS)
    assert read_elements(p) == els
    assert ELEMENT_COLUMNS[:4] == ("genome", "eid", "name", "seqid")


# ---------------------------------------------------------------- malformed records

COLS = HEADER.lstrip("#").split("\t")


def _row(**fields):
    c = ROW_INNER.split("\t")
    for k, v in fields.items():
        c[COLS.index(k)] = v
    return "\t".join(c)


def test_missing_required_column_fails_with_its_name(tmp_path):
    cut = COLS.index("ltr3_end")
    drop = lambda line: "\t".join(x for i, x in enumerate(line.split("\t")) if i != cut)
    (tmp_path / "X_depth0_clean_ltr.tsv").write_text(drop(HEADER) + "\n" + drop(ROW_INNER) + "\n")
    with pytest.raises(ValueError, match=r"X_depth0_clean_ltr\.tsv: .*lacks required column\(s\) ltr3_end"):
        load_ltrquest(str(tmp_path / "X"), "G")


def test_malformed_rows_warn_and_skip(tmp_path, caplog):
    """A short row, LTR bounds or k2p that are not numbers, a seq_id with start > end or of another form are
    skipped with a warning naming the file and line; NA and nan k2p are unknown; CRLF line ends are read."""
    rows = [ROW_INNER,  # line 2
            "B73v5_chr1:1-2#LTR\tpass",  # line 3: short
            _row(ltr5_end="1,322"),  # line 4
            _row(k2p="0.0O1"),  # line 5
            _row(seq_id="B73v5_chr1:9000-100#LTR/Copia/SIRE"),  # line 6: start > end
            _row(seq_id="B73v5_chr1#LTR"),  # line 7
            _row(seq_id="B73v5_chr2:60664-70130#LTR/Copia/SIRE", k2p="nan")]  # line 8: good
    p = tmp_path / "X_depth0_clean_ltr.tsv"
    p.write_text(HEADER + "\r\n" + "\r\n".join(rows) + "\r\n")
    (tmp_path / "X_depth1_clean_ltr.tsv").unlink()
    with caplog.at_level(logging.WARNING, logger="ltrpav.annotation"):
        els, skipped = load_ltrquest(str(tmp_path / "X"), "G")
    assert [(e.seqid, e.k, e.confidence) for e in els] == [("B73v5_chr1", 0.0, "high"), ("B73v5_chr2", None, "high")]
    assert skipped == {"malformed_columns": 1, "malformed_ltr_bounds": 1, "malformed_k2p": 1,
                       "malformed_coordinates": 1, "bad_seq_id": 1}
    warned = [r.getMessage() for r in caplog.records]
    assert [w.split(": ")[0] for w in warned][:RECORD_WARNINGS] == [f"{p}:{n}" for n in (3, 4, 5, 6, 7)]


def test_depths_sort_as_numbers_and_prefix_is_literal(tmp_path):
    """depth10 comes after depth2 (integer order), and a prefix with glob characters is matched literally."""
    d = tmp_path / "run[1]"
    d.mkdir()
    for depth, seqid in ((10, "B73v5_chr3:60664-70130#LTR/Copia/SIRE"), (2, "B73v5_chr2:60664-70130#LTR/Copia/SIRE")):
        (d / f"X_depth{depth}_clean_ltr.tsv").write_text(HEADER + "\n" + _row(seq_id=seqid) + "\n")
    els, _ = load_ltrquest(str(d / "X"), "G")
    assert [e.seqid for e in els] == ["B73v5_chr2", "B73v5_chr3"]
