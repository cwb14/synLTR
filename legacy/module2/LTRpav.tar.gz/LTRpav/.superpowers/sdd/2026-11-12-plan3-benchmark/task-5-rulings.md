# Task 5: controller rulings (Task 4 approved at 239eb8f)

These bind as much as task-5-brief.md, and override it where the two conflict.

## R1. Contracts from Tasks 2-4 (their reports and reviews; ledger)
- **Chromosome index.** `Copy.chrom` indexes `PopGenome.seqs` and `seqids` (Task 3 review M5). The seqids are
  `c01`..`c10`, and chromosome c is index c - 1. Assert this contract once, where the genomes are joined.
- **Counters in params.json.** These go under `events.dropped`, summed over chromosomes with per-chromosome detail:
  - Task 2's `dropped` (`ins_n`, `ins_end`, `snp_n`, `ins_after_loss`, `nested_after_loss`, `loss_after_loss`);
  - `add_gaps`' off-chromosome gap count (Task 3 M5).
- **Named simplifications, listed under `meta.simplifications`** (from the popevents and popbuild docstrings), each in
  one line:
  - replacing sequence and simulated solo LTRs receive no insertions;
  - replacing sequence and indel bases take no substitutions;
  - "any carrier" thinning;
  - TSD bases assume one mutation per site.

## R2. Memory and processes
- `build_chrom` returns every sample's sequence for one chromosome at once. Workers return per-chromosome results.
- The parent process joins each sample's chromosomes and writes `<label>.fa` one genome at a time. It never holds a
  second copy of a genome's sequence.
- Report the peak RSS of a 20-Mb, 7-genome run in the report. Run it under `timeout 15m`, with at most 16 threads.
- **Determinism.** `threads` 1 and 2 give byte-identical outputs (brief test). Each worker builds its own rng from
  `[seed, c]`; no rng state crosses a process.

## R3. Env and running jobs
- Never install, update or remove packages in env `ltrpav`. If msprime or tskit is missing, the command must fail
  with `MSPRIME_HELP`.
- **The slow end-to-end test** runs `ltrpav-genotype` on toy genomes at most 16 threads.
- Hands off `benchmark_pav/plan3/real/`.

## R4. Contracts from Task 4 (report concern 5; ledger)
- **The two `chrom` arguments differ.**
  - `build_chrom`'s `chrom` is the 0-based index into `seqs`.
  - `draw_events`' `chrom` only numbers iids, `"i<chrom:02d><n:06d>"`. Pass c (1..10) there and c - 1 to
    `build_chrom`.
- **Backbone eids are unique across chromosomes.** `ltrpav-sim score` needs a unique name per genome X. Assert it.
- **Truth files.** One truth file per ordered pair (X annotated, Y any other).
- **`insertion_rows`** takes the genomes in sample (sheet) order. Its columns are set; `insertions.tsv` writes them
  as they are.
- **Off-chromosome gaps.** `add_gaps` returns per-genome counts of near gaps that fell off a chromosome. Record them
  in params.json (R1).
