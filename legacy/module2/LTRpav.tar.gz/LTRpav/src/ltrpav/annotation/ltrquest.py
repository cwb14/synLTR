"""Load LTRquest `{prefix}_depth*_clean_ltr.tsv` tables into Elements."""
from __future__ import annotations

import glob
import math
import re
from collections import Counter

from ltrpav.annotation.records import RecordSkips
from ltrpav.elements import Element, make_eid

_SEQ_ID = re.compile(r"^(?P<seqid>.+):(?P<start>\d+)-(?P<end>\d+)#(?P<cls>.+)$")
_DEPTH = re.compile(r"_depth(\d+)_clean_ltr\.tsv$")
_NULL = {"", "NA", "."}
REQUIRED = ("seq_id", "status", "ltr5_start", "ltr5_end", "ltr3_start", "ltr3_end")  # the rest is optional
_BOUNDS = REQUIRED[2:]


def _opt(v: str | None) -> str | None:
    return None if v is None or v in _NULL else v


def load_ltrquest(prefix: str, genome: str) -> tuple[list[Element], Counter]:
    """Return (elements, skip counts) of the tables {prefix}_depth<N>_clean_ltr.tsv, in depth order.

    Each table's header must hold the REQUIRED columns (ValueError naming the file and the missing ones). A
    row that cannot be read is skipped with a warning naming the file and line: fewer fields than its
    required columns need (malformed_columns), a seq_id not <seqid>:<start>-<end>#<class> (bad_seq_id) or
    with start > end (malformed_coordinates), LTR bounds that are not integers (malformed_ltr_bounds), a k2p
    that is not a number or NA (malformed_k2p). Rows with status other than pass are counted (status_not_pass).
    A k2p that is not finite is unknown.
    """
    pattern = f"{glob.escape(prefix)}_depth*_clean_ltr.tsv"
    files = sorted((f for f in glob.glob(pattern) if _DEPTH.search(f)), key=lambda f: int(_DEPTH.search(f).group(1)))
    if not files:
        raise FileNotFoundError(f"no LTRquest files match {prefix}_depth*_clean_ltr.tsv")
    elements: list[Element] = []
    skips = RecordSkips()
    for path in files:
        with open(path) as fh:
            header = fh.readline().rstrip("\r\n").lstrip("#").split("\t")
            col = {name: i for i, name in enumerate(header)}
            missing = [c for c in REQUIRED if c not in col]
            if missing:
                raise ValueError(f"{path}: LTRquest table header lacks required column(s) {', '.join(missing)}")
            need = max(col[c] for c in REQUIRED) + 1
            for n, line in enumerate(fh, 2):
                if not line.strip():
                    continue
                r = line.rstrip("\r\n").split("\t")
                if len(r) < need:
                    skips.malformed(path, n, "malformed_columns", f"{len(r)} fields, the required columns need "
                                    f"{need}")
                    continue
                rec = {name: r[i] for name, i in col.items() if i < len(r)}
                get = rec.get
                m = _SEQ_ID.match(rec["seq_id"])
                if not m:
                    skips.malformed(path, n, "bad_seq_id", f"seq_id {rec['seq_id'][:80]!r} is not "
                                    "<seqid>:<start>-<end>#<class>")
                    continue
                if rec["status"] != "pass":
                    skips.filtered("status_not_pass")
                    continue
                seqid, start, end = m["seqid"], int(m["start"]), int(m["end"])
                if not 1 <= start <= end:
                    skips.malformed(path, n, "malformed_coordinates", f"seq_id start {start} > end {end} or < 1")
                    continue
                try:
                    l5s, l5e, l3s, l3e = (int(rec[c]) for c in _BOUNDS)
                except ValueError:
                    skips.malformed(path, n, "malformed_ltr_bounds", "LTR bounds " + ", ".join(
                        f"{c} {rec[c]!r}" for c in _BOUNDS) + " are not all integers")
                    continue
                k = _opt(get("k2p"))
                try:
                    k = float(k) if k is not None else None
                except ValueError:
                    skips.malformed(path, n, "malformed_k2p", f"k2p {k[:40]!r} is not a number or NA")
                    continue
                parts = m["cls"].split("/")
                sf = parts[1] if len(parts) > 1 and parts[1] != "unknown" else None
                clade = parts[2] if len(parts) > 2 and parts[2] != "unknown" else None
                strand = get("strand")
                tsd = _opt(get("tsd"))
                elements.append(Element(
                    genome=genome,
                    eid=make_eid(genome, seqid, start, end),
                    name=rec["seq_id"],
                    seqid=seqid, start=start, end=end,
                    strand=strand if strand in ("+", "-") else ".",
                    ltr_left=(start + l5s - 1, start + l5e - 1),
                    ltr_right=(start + l3s - 1, start + l3e - 1),
                    tsd=tsd.upper() if tsd else None,
                    k=k if k is not None and math.isfinite(k) else None,
                    family=_opt(get("family")), superfamily=sf, clade=clade,
                    confidence=_opt(get("confidence")),
                ))
    return elements, skips.counts
