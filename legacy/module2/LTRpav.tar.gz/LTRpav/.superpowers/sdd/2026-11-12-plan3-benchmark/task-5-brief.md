### Task 5: `ltrpav-sim pop`: orchestration, outputs, command line

**Files:**
- Create: `src/ltrpav/sim/donors.py`, `src/ltrpav/sim/pop.py`, `tests/test_pop_cli.py`.
- Modify:
  - `src/ltrpav/sim/cli.py` (the `pop` subcommand; `pair` imports from `donors.py`);
  - `src/ltrpav/sim/__init__.py`;
  - `docs/DESIGN.md` 10.2: one paragraph on the built simulator.

**Interfaces:**
- Produces:

```python
# donors.py (moved from cli.py; `ltrpav-sim pair` byte-identical on its tests)
def pick_donors(elements: list[Element], fa: Fasta, seed: int) -> list[Donor]          # MAX_DONORS = 2000
def shift_element(e: Element, off: int) -> Element                    # was cli._shift; moved here, pair's CLI imports it
def backbone_elements(elements: list[Element], seqid: str, start: int, end: int) -> list[SimElement]
# pop.py
@dataclass(frozen=True)
class PopParams:
    demog: Demog; rates: Rates
    dropout: float = 0.1; jitter: float = 0.05     # Plan 1 PairParams defaults
    dropout_genome: tuple[tuple[str, float], ...] = (); gap_per_mb: float = 2.5
@dataclass
class PopResult:
    params: PopParams; seed: int; regions: list[tuple[str, int, int]]
    genomes: list[PopGenome]                       # sheet order
    tracts: dict[str, list[tuple[str, int, int]]]  # label -> lifted tracts (recipient-taxon samples)
    truth: dict[tuple[str, str], list[dict]]       # (X, Y) -> rows
    annotations: dict[str, list[Element]]          # ingroup labels
    insertions: list[dict]; meta: dict             # versions, tree counts, events requested/realized/dropped
def simulate_pop(regions: list[tuple[str, int, int]], fasta: Path, annotation: str, params: PopParams, seed: int,
                 threads: int) -> PopResult        # one process per chromosome (pool of `threads`)
def write_pop(outdir: Path, result: PopResult) -> None
```

- **Assembly.** `simulate_pop` runs `ancestry`, `draw_events` and `build_chrom` per chromosome. It joins each sample's
  chromosomes into one `PopGenome`, then calls `add_gaps`, `pair_truth`, `annotate` and `tract_bed`.
- **Seeds.** Chromosomes are numbered from 1 (seqids `c01`-`c10`). The streams are stated in `pop.py`'s docstring:
  - donors: `[seed, 0]` (Plan 1's, unchanged);
  - chromosome c: `[seed, c]`, from which msprime's `random_seed`s are drawn;
  - gaps of genome g (its sheet index): `[seed, 100, g]`;
  - annotation of genome g: `[seed, 200, g]`.

  Results do not depend on `threads`.
- **Outputs** in `outdir`:
  - `<label>.fa`;
  - `<label>.gff3` for A*, B* and C*;
  - `samples.tsv`, with columns `label fasta annotation group role` and paths relative to the sheet; O1 has annotation
    `.` and role `outgroup`;
  - `truth/<X>__<Y>.tsv` for every annotated X and every other Y;
  - `truth/insertions.tsv`: iid, chrom, host, pos, time, node, depth, family, carriers, survivors, fate per sample;
  - `truth/tracts.<label>.bed`;
  - `truth/fractions.tsv`;
  - `params.json`: seed, PopParams, regions, FASTA and annotation (path, sha256), msprime and tskit versions, trees per
    chromosome, events requested, realized and dropped, truth state counts.
- **CLI:**

```
ltrpav-sim pop --fasta FA --region SEQ:START-END [--region ...] --annotation ANNOT --outdir DIR
               [--demography FILE.json] [--seed N] [--f F] [--ta GEN] [--pulse CODE] [--per-taxon N]
               [--bottleneck NE,GEN] [--dropout X] [--dropout-genome LABEL=X ...] [--jitter X] [--threads N] [-v]
```

  - `--demography` sets any `Demog` or `Rates` field (`demog_from_json`). The flags given on the command line override
    it.
  - Exit codes follow Plan 1: 1 with one `error:` line, 2 for usage.
  - The command fails fast on:
    - overlapping regions;
    - a region shorter than 2 x `WINDOW_PAD` plus the longest donor;
    - `--dropout-genome` naming the outgroup or an unknown label, or a value of 1 or more;
    - a missing msprime (`MSPRIME_HELP`).

- [ ] **Step 1: Move** `_donors` and `_shift` into `donors.py` (`pick_donors`, `shift_element`) and add
  `backbone_elements`. Run `tests/test_sim.py`. Expected: PASS, unchanged.
- [ ] **Step 2: Write the failing tests.** The toy FASTA is 3 x 300 kb and the toy GFF3 has 40 elements; the module
  starts with `pytest.importorskip("msprime")`.

```python
def test_pop_writes_outputs(tmp_path):   # all files; read_samples loads samples.tsv; groups A,B,C,O; O1 outgroup
def test_pop_deterministic(tmp_path):    # same seed twice; threads 1 vs 2: byte-identical FASTA, GFF3, truth
def test_pop_demography_json(tmp_path):  # JSON t_o=300000 recorded in params.json; --f overrides the JSON's f
def test_pop_regions_overlap_fails(tmp_path):    # exit 1, one "error:" line
def test_pop_two_regions_one_sequence(tmp_path): # disjoint windows on one seqid: chromosomes c01, c02
def test_pop_edge_element_excluded(tmp_path):    # element crossing a region end is not a backbone element
def test_pop_dropout_guards(tmp_path):   # A1=1 -> exit 2 (argparse value check); O1=0.2, Z9=0.2 -> exit 1 (labels
                                         # checked after parsing); one error line each
def test_pop_region_too_short(tmp_path): # shorter than 2 x WINDOW_PAD plus the longest donor -> exit 1, one line
@pytest.mark.slow
def test_pop_end_to_end(tmp_path):       # pop (per-taxon 1) -> ltrpav-genotype -> ltrpav-merge -> ltrpav-stats
                                         # --trio A1,B1,C1: exit 0, D_pav rows; ltrpav-sim score on pairs/C1__A1 against
                                         # truth/C1__A1.tsv gives P and E rows
```

- [ ] **Step 3: Run.** Expected: FAIL.
- [ ] **Step 4: Implement** `pop.py` and the subcommand.
- [ ] **Step 5: Run** the file, then the slow test once (`python -m pytest -W error tests/test_pop_cli.py`), then the
  suite and ruff.
- [ ] **Step 6: Engine-key check** (every `STAGE_MODULES` fingerprint equals the branch base's). Commit:
  `"Add ltrpav-sim pop: population simulation on a real backbone"`.

---

