#!/usr/bin/env bash
# LTRpav quick start: a toy genome, four genomes simulated on it with known truth, and every command run on them.
#
# Run with the ltrpav environment active (mamba activate ltrpav):
#   bash examples/quickstart.sh [WORKDIR]     (default ./ltrpav_quickstart; WORKDIR must not exist yet)
# Needs lastz (genotyping) and msprime (ltrpav-sim pop), both in environment.yml (with pip: pip install -e ".[sim]" and lastz from bioconda). Nothing is downloaded.
# Uses at most 4 threads and takes about a minute. The toy is a smoke test: it is far too small to show gene flow.
set -euo pipefail

W=${1:-ltrpav_quickstart}
T=4
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1   # numpy's math libraries stay single-threaded

for exe in python ltrpav ltrpav-sim lastz; do
  command -v "$exe" > /dev/null || { echo "error: $exe not on PATH; activate the environment (mamba activate ltrpav) or, with pip, run pip install -e \".[sim]\" from the repo root and install lastz from bioconda" >&2; exit 1; }
done
if [ -e "$W" ]; then
  echo "error: $W exists; give a new WORKDIR" >&2
  exit 1
fi

mkdir "$W"
cd "$W"
SECONDS=0
step() { printf '\n== [%4ds] %s\n' "$SECONDS" "$*"; }

# ---------------------------------------------------------------- 1. a backbone to simulate on
# ltrpav-sim evolves genomes from a real FASTA and its LTR-RT annotation. This makes a toy one: 3 random 300-kb
# sequences with 40 planted LTR-RTs (5-bp TSDs; one element nested in another), annotated in GFF3 (1-based,
# closed): an LTR_retrotransposon feature with two long_terminal_repeat children per element. With real data,
# give your own genome and its annotation instead.
step "1. toy backbone: toy.fa, toy.gff3"
python - <<'EOF'
import random
rng = random.Random(7)
starts = [10_000 + 22_000 * k for k in range(13)]
n = 0
with open("toy.fa", "w") as fa, open("toy.gff3", "w") as gff:
    gff.write("##gff-version 3\n")
    for j, seqid in enumerate(("s1", "s2", "s3")):
        r = random.Random(j)
        seq = bytearray("".join(r.choices("ACGT", k=300_000)).encode())
        spans = [(s, rng.randint(200, 600), rng.randint(2_000, 6_000)) for s in starts]
        if seqid == "s1":                                  # nested in the first element's internal region
            spans.append((starts[0] + spans[0][1] + 500, 150, 800))
        for i, (s, ltr, internal) in enumerate(sorted(spans)):   # s: 0-based start
            e = s + 2 * ltr + internal                     # 0-based, half-open end
            lt = "".join(r.choices("ACGT", k=ltr)).encode()
            seq[s:e] = lt + "".join(r.choices("ACGT", k=internal)).encode() + lt
            seq[e:e + 5] = seq[s - 5:s]                    # target-site duplication
            n += 1
            eid, strand = f"{seqid}e{i}", "-" if i % 3 == 2 else "+"
            col = f"{seqid}\ttoy\t{{}}\t{{}}\t{{}}\t.\t{strand}\t.\t{{}}\n"
            gff.write(col.format("LTR_retrotransposon", s + 1, e,
                                 f"ID={eid};tsd={seq[s - 5:s].decode()};K2P_d=0.01;family=fam{i % 4};"
                                 "superfamily=Gypsy;confidence=high"))
            gff.write(col.format("long_terminal_repeat", s + 1, s + ltr, f"Parent={eid}"))
            gff.write(col.format("long_terminal_repeat", e - ltr + 1, e, f"Parent={eid}"))
        fa.write(f">{seqid}\n" + "\n".join(seq[k:k + 80].decode() for k in range(0, len(seq), 80)) + "\n")
print(f"toy.fa: 3 x 300 kb; toy.gff3: {n} LTR-RTs")
EOF

# ---------------------------------------------------------------- 2. simulate genomes with known truth
# A1, B1, C1 (annotated, with 10% annotation dropout) and the outgroup O1 (unannotated); a pulse moves 20% of
# A's lineages from C 2,000 generations ago. --f defaults to 0 (no gene flow), so it is set here.
step "2. ltrpav-sim pop -> sim/"
ltrpav-sim pop --fasta toy.fa --annotation toy.gff3 \
  --region s1:1-300000 --region s2:1-300000 --region s3:1-300000 \
  --per-taxon 1 --f 0.2 --ta 2000 --seed 2 --threads 3 --outdir sim
cat sim/samples.tsv            # the samples sheet: label fasta annotation group role ('.' = none)

# ---------------------------------------------------------------- 3. everything in one command
# Genotypes every annotated genome's elements in every other genome, merges the calls into loci, writes the
# tables, VCF and tracks, then runs the analyses and draws the overview figure. Trio roles come from the data.
step "3. ltrpav run -> run/"
ltrpav run --samples sim/samples.tsv --outdir run --threads "$T"

# ---------------------------------------------------------------- 4. the analyses again, for a chosen trio
# Recipient A1, sister B1, donor C1 (the simulated pulse). The genotypes are reused; each analysis stage reruns
# because its options changed.
step "4. ltrpav-stats, ltrpav-paint, ltrpav-plot --trio A1,B1,C1"
ltrpav-stats --samples sim/samples.tsv --outdir run --trio A1,B1,C1
ltrpav-paint --samples sim/samples.tsv --outdir run --trio A1,B1,C1
ltrpav-plot  --samples sim/samples.tsv --outdir run --trio A1,B1,C1

# ---------------------------------------------------------------- 5. score calls against the truth
step "5. ltrpav-sim score (C1's elements in A1) -> score/"
ltrpav-sim score --calls run/pairs/C1__A1.calls.tsv.gz --elements run/work/elements/C1.tsv \
  --truth sim/truth/C1__A1.tsv --out score/C1__A1

# ---------------------------------------------------------------- 6. the same, one stage at a time
# What ltrpav run does, split into its single-stage commands (to spread pairs over jobs, give each --pair A,B).
step "6. ltrpav-anchor, ltrpav-genotype, ltrpav-merge -> staged/"
ltrpav-anchor   --samples sim/samples.tsv --outdir staged --threads "$T"
ltrpav-genotype --samples sim/samples.tsv --outdir staged --threads "$T"
ltrpav-merge    --samples sim/samples.tsv --outdir staged
step "   ltrpav run on staged/: the finished stages are skipped, the analyses run"
ltrpav run --samples sim/samples.tsv --outdir staged --threads "$T" --trio A1,B1,C1
cmp run/loci.tsv staged/loci.tsv
echo "loci.tsv identical in run/ and staged/"

step "done in ${SECONDS} s; outputs in $PWD"
ls run
grep 'D_pav(A1,B1;C1) = ' run/findings.txt | cut -c1-160 || true
