# LTRmix benchmark (record)

How LTRmix was validated (November 2026): maize B73 against *Zea mays* ssp. *mexicana* and *parviglumis*
(Yang et al. 2023; Barnes et al. 2022), six maize/teosinte genomes, a wild *Zea* exchange, sweet orange, simulations,
an independent annotator (EDTA) and raw-assembly checks. **Start with `REPORT.md`.**

This folder is a record, not a pipeline. Genomes, LTR-RT libraries, ortholog tables, simulated libraries, ELAI calls
and alignments were not kept, so the scripts cannot be rerun from here; they also carry the absolute paths of the
original analysis directory (`/data2/chris/maize_introgression/...`). Paths in `REPORT.md` are relative to this
folder and point to files here wherever these were kept.

## Contents

| Path | Content |
|---|---|
| `REPORT.md` | Results, scorecard against the published claims, limits, headline, references |
| `dead_ends.md` | What failed or was dropped, and why |
| `memo_ltrmix.md` | Commands, environments and gotchas of every run |
| `figures/fig1`–`fig5`, `figures/ltrmix_plot/` | Final figures (PDF with legends, PNG); `*_numbers.tsv` lists every legend number and its source; `*.py` drew them; `SPEC.md` the figure plan |
| `scripts/` | Every benchmark analysis (truth liftover, evaluation, simulations, comparators, checks) |
| `results/main3/` | The maize trio's LTRmix outputs (findings, stats, tracts, inversions, overview; per-element table gzipped) |
| `results/six/`, `results/forced/` | Six-genome trios (findings, stats) and summary tables |
| `lineage2/` | Sweet orange: download, annotation and evaluation scripts, published truth, evaluation, trio summaries |
| `sim/` | Simulation grid and summaries |
| `absence/` | Library presence/absence calls checked on the raw assemblies (summaries) |
| `analysis/` | Later checks: inversion effect, rate-free split (maize, citrus) |
| `wgk/`, `gene_snp/`, `genus/`, `edta/`, `spike/` | Whole-genome k-mer and gene-space SNP comparators, wild *Zea*, EDTA reruns, spike-in (summaries) |
| `ltrquest_pipeline/` | How the input LTR-RT libraries were made: LTRquest commit 5042a1e (github.com/cwb14/LTRquest), download and launch scripts, run memo, environment lock |

## Data sources (to rebuild)

- Maize and *Zea* assemblies: MaizeGDB (download.maizegdb.org): Zm-B73-REFERENCE-NAM-5.0; PanAnd-1.0 TIL01, TIL18,
  TIL25, TIL11, Zh-RIMHU001, Zn-PI615697, Zd-Gigi; Zm-PT-REFERENCE-HiLo-1.0 (`ltrquest_pipeline/01_download.sh`,
  `scripts/04_download_extra.sh`). EDTA annotations: the PanAnd releases.
- Citrus assemblies: NCBI GenBank (accessions in `lineage2/01_download.sh`); truth from Wu B. et al. 2023, *Hortic
  Res* 10:uhac247, Supplementary Table 4.
- ELAI local ancestry: Yang et al. 2023, figshare 21579528 (https://doi.org/10.6084/m9.figshare.21579528), lifted
  to B73 v5 with `scripts/01_extract_elai.py` and `scripts/03_lift_truth.sh`.

## Data use

The PT assembly (Zm-PT-REFERENCE-HiLo-1.0) is released under the Toronto Agreement: results involving PT (REPORT
section 6, Fig. 4, `results/six`, `results/forced`) are pre-publication data; ask its producers before publishing them.

## Reusable pieces not yet in the tool

`scripts/rate_free_split.py` (split in LTR-divergence units, per-element 'younger than the split' test),
`scripts/edta_to_lib.py` (EDTA GFF3 + genome to an LTRmix library), `scripts/forced_trio.py` (trio with a chosen
donor), `scripts/absence_check.py` (library absence calls checked on a raw assembly) and `scripts/sim_ltr_admix.py`
(msprime simulator of LTR-RT insertion, loss and sequence evolution under admixture). Each would need its absolute
paths replaced and tests added before use outside this record.
