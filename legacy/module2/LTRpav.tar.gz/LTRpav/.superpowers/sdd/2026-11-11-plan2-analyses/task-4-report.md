# Task 4 report: trio roles and tests (DESIGN 7.1, 7.3, 7.5)

Status: DONE_WITH_CONCERNS (the concerns are judgment calls listed under "Decisions to check"; nothing is blocked)
Commit: aa89e7b "Add trio roles, D_pav with age strata, nested collapse and f4-ratio" (on 74c9fd8; global git
identity, no trailers, not pushed). Files: src/ltrpav/analysis/trio.py (new, 470 lines), tests/test_trio.py (new,
271 lines). No other file touched; no engine module edited.

## Tests
- TDD: tests written first; `pytest -W error tests/test_trio.py` failed on the import (ModuleNotFoundError), then
  passed.
- tests/test_trio.py: 18 passed (the brief's 12 tests, plus 6 of mine), about 19 s.
- Full suite `NUMPY_MADVISE_HUGEPAGE=0 python -m pytest -W error -m "not slow"`: 942 passed, 1 deselected (93 s).
- `ruff check .`: clean.
- The brief's tests are AST-identical to the brief, except one lint-only edit (below).

## What was built (the brief's interfaces, names and signatures unchanged)
- `Trio` (frozen; R, S, D, fixed; `scope` = "R,S;D").
- `d_pav(cat, R, S, D, c, size, keep=None) -> (Jk, n_RD, n_SD)`:
  - rows = `c.rows & keep`;
  - a = `pcls_by(gstar, R) == 1 & pcls_by(gstar, S) == 0`, b the mirror;
  - blocks = `block_ids(*cat.proj_site(gstar, D), size)` on the rows;
  - `jackknife(d_ratio(a, b), blocks)`.
  - `keep` must be a boolean mask over the n loci (a ValueError otherwise, as `cluster_keys` does). A counted row
    with no D site raises a ValueError; it cannot happen with engine outputs, since D is present at every counted
    row and a present call has a site.
- `trios(cat, fixed, size, dist)`:
  - Fixed: three distinct ingroup genomes, else AnalysisError (relations' `_check_trio`), taken as given; row
    `roles`/`source` = `--trio`, loci `none`.
  - Otherwise, per 3-combination of ingroup genomes in sheet order: `sister_pair` gives (x, y) and D; D_pav(x, y; D)
    on `discover(..., "E")`; R = x if D >= 0, y if D < 0; nan keeps x.
  - Row `roles`/`source` = `data`, with loci = the D_pav count that decided R and n = its informative loci.
  - Fewer than three ingroup genomes: `([], [], f)` with "Trio tests skipped: fewer than three ingroup genomes".
- `trio_tests(cat, trio, size, dist)`:
  - `discover` None: no rows, one WARNING "D_pav(...) skipped, ...", naming the excluded genomes and why (from
    `eligible_fallback(...)[1]`, as relations does for KKSC).
  - Rows, in order:
    - `resolution` (R, S over `cand`, from gstar's calls; loci `disc=..;present=D;outgroup=E`);
    - `outgroup_filter`/`removed_frac`;
    - `D_pav` per stratum (D with se, z, n = n_RD + n_SD; `n_RD`, `n_SD` with n = the stratum's counted loci): all,
      K=0, 0<K<0.01, K>=0.01, high_tier, nested_collapsed, no_outgroup_filter;
    - `D_pav_gradient` (stratum "K=0 minus K>=0.01", statistic dD);
    - `f4_ratio` per second donor.
  - Every row is layer `pav` with its `loci`; the no_outgroup_filter rows declare `outgroup=none`.
- Strata, as specified:
  - ages by the K of each row's gstar copy (`cat.k[i, gstar[i]]`, `age_bin`);
  - high_tier from `ptier_by(gstar, R)` and `ptier_by(gstar, S)` == high;
  - nested_collapsed: the informative counted rows sorted by the gstar genome's (seq, start, -end) (stable
    `np.lexsort`), the first per `cluster_keys` key;
  - no_outgroup_filter: `discover(..., "none")`.
- Gradient: one statistic over the union of the two bins' rows, `d_ratio(young) - d_ratio(old)` on the same keep
  mask, so each delete-one pseudovalue drops a block from both bins at once. Findings in "Dating".
- `second_donors`: ingroup g outside the trio with `dist[D, g] < min(dist[x, y] for x in (D, g) for y in (R, S))`,
  sheet order. A nan among the five distances never qualifies.
- `f4_ratio` (and the private `_f4` used by `trio_tests`), on the D_pav rows with D2 resolved, from the same calls:
  - num = [R pres, S E] - [S pres, R E]; den = [D2 pres, S E] - [S pres, D2 E];
  - f = Σnum/Σden, jackknifed on D's blocks;
  - rows `f4_ratio`, scope `R,S;D;D2`: `f` (se, z), `num`, `den`, plus `resolution` rows (below).
- Findings ("Trio tests"): roles; the primary D_pav line (counted loci, discoverer, fallback and exclusions when
  used, blocks, |Z| against Z_SIG); resolution WARNING via `stats.resolution`; the outgroup filter (always, to two
  decimals); the check strata; the age-strata line when K is partly or wholly missing; f4 lines.

## Decisions to check (not fixed by the brief; most defensible choice taken)
1. **f4 resolution rows cover S and D2, not D2 alone.** `resolution("f4_ratio", "R,S;D;D2", {S, D2}, ...)` runs
   over the D_pav candidates, the same base as the trio's resolution rows.
   - The den compares D2 with S, and `resolution` can only warn with two or more genomes.
   - Over the D_pav rows instead, S is resolved by construction (1.0).
   - `resolved_D2` is what the brief's test reads (1.0). `resolved_S` repeats the trio's value under the f4 scope.
2. **A stratum with counted loci but none informative writes rows**: D nan (n 0), n_RD 0, n_SD 0. I read "a stratum
   with no loci writes no rows" as no counted locus.
   - Example: K=0 in every null toy run, where young insertions are D-private.
   - n_RD = n_SD = 0 is itself the information there; dropping the rows would make it look like a missing bin.
3. **No-K handling.**
   - "No finite K at all" is judged over the counted rows: the K of each row's discovering copy, which is what
     the strata use. With D's annotation lacking K but R's having it, the age strata are skipped with the line,
     rather than silently empty.
   - The no-K case writes two lines, read as Review Focus 2's "one findings line each" for the age strata and
     the gradient:
     - "Trio tests": "D_pav(...) age strata skipped: no K2P ...";
     - "Dating": "Age gradient of D_pav(...) skipped: no K2P ...".
     The test's count of lines with "age strata skipped" is 1.
   - Partial K gives one line counting the loci without K.
4. **The gradient is skipped**, with a "Dating" line, when either bin has no informative locus: dD is undefined.
   Under the null toy that is the common case (no RD/SD at K=0).
5. **n conventions.**
   - D rows: n = n_RD + n_SD (spec).
   - Count rows (n_RD, n_SD): n = the stratum's counted loci.
   - dD: n = the informative loci of both bins.
   - f, num, den: n = the D_pav rows with D2 resolved.
   - outgroup_filter: n = the candidates without the outgroup rule.
6. **high_tier requires only the calls into R and S to be high (spec).** Under fallback, X's call into D is not
   required high. D's presence decides whether a locus is counted; it does not decide whether it is RD or SD.
7. **The outgroup filter's row note and findings line split the removals**: an outgroup present (older than the
   ingroup split) against an outgroup missing (D/O/G/U or no call).
   - With no outgroup the fraction is 0.00, and a line says nothing is set aside.
   - no_outgroup_filter is still written, equal to `all`.
8. **Roles.**
   - A nan D_pav keeps pair[0] (spec) and also writes a WARNING ("the recipient is not identified"), since the
     recipient then drives painting.
   - D_pav exactly 0 keeps pair[0] and is noted as a tie in the line, with no WARNING.
   - With data roles, the primary line says D_pav >= 0 by construction and that |Z| is the test.
9. **f4.**
   - A WARNING when Σden <= 0: D2 shares no more insertions with D than S does, so f is not an admixture fraction.
   - "f4-ratio skipped: no second donor" when none qualifies; this is the case on main3.
   - f, num and den rows are written even when f is nan.
10. **Private helpers from relations** (`_check_trio`, `_fallback_reasons`) are imported rather than duplicated
    (the brief: reuse). Making them public would touch Task 3's module, which I left alone.

## Deviation from the verbatim tests
`test_roles_from_sign` unpacks `found, rows, _ = trios(...)` instead of `found, rows, f = ...`: ruff RUF059,
unused `f`. Every assertion and expected value is verbatim (AST comparison against the brief's block:
the other 13 functions are identical).

## Extra tests (mine)
- `test_gradient_is_one_joint_jackknife`: dD's est, se and z equal a hand delete-one-block jackknife of
  D(K=0) - D(K>=0.01) over 4 shared blocks (est 0.6 + 1/3); a 0<K<0.01 locus stays out of the gradient.
- `test_strata_tiers_and_loci`:
  - a T call (tier medium) into R counts in `all` but not in `high_tier`;
  - an O:U locus is dropped by the filter (1/6, quoted as "0.17" with "missing") and kept in `no_outgroup_filter`;
  - the n conventions; every row has `loci` and layer `pav`.
- `test_trios_skip_and_undefined_sign`: fewer than three ingroup genomes; a nan D_pav keeps pair[0] with the
  WARNING.
- `test_fallback_counts_from_the_fallback_calls`: D unannotated, X eligible:
  - counts from X's calls, loci `disc=X;...`;
  - ages from X's copy;
  - a locus where X calls D U is not counted;
  - the line names the four-point condition.
- `test_f4_skips_and_warns`: den < 0 gives a WARNING; no second donor gives no rows and one line; a nan distance
  never qualifies.
- `test_d_pav_keep_must_be_a_mask`: a keep mask gives the expected counts; an index array raises.

## Bug found in self-review (fixed before the commit)
`second_donors` first used `min(others)`. Python's `min` with a nan is order-dependent: `min([0.3, nan])` is
0.3. A genome with an unresolved distance to S could therefore qualify. The fix is an explicit finiteness check
on all five distances; the new assertion in `test_f4_skips_and_warns` failed before the fix and passes after it.
Also polished before the final amend: `_resolved` returns Python floats rather than np.float64.

## Simulated runs (catalog_toy.simulate_run)
- **Null, default toy:**
  - seeds 1-5: trios R+S/D every time; |Z| 0.61-2.74. Seed 5 is the highest, D +0.131, Z +2.74; Task 1
    predicted a binomial Z of about 2.55.
  - seeds 6-25: |Z| >= 3 in 0 of 20 (max 2.50). This meets DESIGN 10.2's bar (at most 1 of 20).
  - With data roles every D >= 0, by construction.
- **Unequal annotation** (p_member R 0.95, S 0.5, p_missing 0.3, 3000 per seqid), from D's own calls: Z -0.66,
  +0.93, -0.56 (seeds 1-3). The brief's test also checks that the merged-state leak is above 0.05; Task 1
  measured +0.127.
- **Admixed** (seed 1, TRACTS, 3000 per seqid):
  - trio R,S;D; D_pav +0.2875 ± 0.0613, Z 4.69 (replica median Z 5.0);
  - K=0 +1.000 (92/0); 0<K<0.01 +0.269; K>=0.01 +0.129;
  - dD +0.871 ± 0.064, Z 13.7. The se equals K>=0.01's se, because D(K=0) is 1 in every pseudovalue.
- **Resolution** (seed 1, p_missing S 0.6): resolved_R 0.847, resolved_S 0.410 over 2,141 candidates, with the
  WARNING.
- **Outgroup mostly missing** (seed 1, p_missing O 0.8): removed_frac 0.848 of 3,387; with an outgroup present
  183, with it missing 2,689.

## main3, read-only probe (informative, not a test)
- **Setup:**
  - A view of benchmark_pav/main3 at
    /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t4/view:
    symlinks to loci.tsv, manifest.json, qc.tsv, pairs/ and work/elements, with its own work/ for the checksum
    cache.
  - Script: /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t4/probe_main3.py.
    Output: probe_main3_final.out in the same directory.
  - main3's work/checksums.json and loci.tsv mtimes are unchanged, and no file in main3 is newer than before;
    checked after both runs.
  - The committed code reproduced the first run's rows exactly.
- **Cost:** load 10.3 s; trios 0.07 s; trio_tests 0.28 s; peak RSS 480 MB.
- **Roles:** sisters B73 + TIL01, donor TIL18, recipient B73 (D_pav(B73,TIL01;TIL18) = +0.291 > 0). These are the
  expected roles.
- **Primary:** D_pav(B73,TIL01;TIL18) = +0.2905 ± 0.0392, Z 7.42.
  - n_RD 1,317, n_SD 724, on 14,067 loci TIL18 discovers with TIL18 present, B73 and TIL01 resolved and Zd E,
    from TIL18's own calls;
  - 425 blocks of 5 Mb.
- **Strata, D (Z; n_RD/n_SD):**

  | stratum | D | Z | n_RD/n_SD |
  |---|---|---|---|
  | K=0 | +0.600 | 4.82 | 32/8 |
  | 0<K<0.01 | +0.612 | 11.78 | 320/77 |
  | K>=0.01 | +0.203 | 5.08 | 965/639 |
  | high_tier | +0.305 | 7.21 | 1,162/619 |
  | nested_collapsed | +0.279 | 7.30 | 1,136/640 |
  | no_outgroup_filter | +0.296 | 8.96 | 2,840/1,543 |

- **Gradient:** dD = +0.397 ± 0.127, Z 3.13 (421 blocks).
- **Outgroup filter:** 0.81 of 123,019 candidates removed: 9,957 with Zd present, 89,592 with Zd missing.
- **Resolution:** B73 0.728, TIL01 0.710 over 23,470 candidates; no warning.
- **f4:** skipped, no second donor (three ingroup genomes).
- **Context only:**
  - The same rule on merged loci.tsv states gives +0.276 (1,335/757 on 14,233 loci). On main3 the leak is small,
    since B73 and TIL01 are annotated to similar depth.
  - LTRmix: D_ins +0.1949 (Z 7.2); by age (right-closed bins) +0.506 / +0.404 / +0.153; dD +0.354.

## Concerns
1. Decisions 1-10 above are the controller's to confirm. 1 (f4 resolution of S and D2) and 2 (nan-D rows for
   uninformative strata) are the ones that change row sets.
2. On main3 the gradient rests on a small K=0 bin: 40 informative loci (32/8), Z 3.13. The large, strongly
   positive 0<K<0.01 bin (+0.612, Z 11.8) is outside dD's definition (K=0 minus K>=0.01) by the spec; Task 12
   re-bins for the LTRmix comparison anyway.
3. Data roles fold the null: D_pav >= 0 by construction, so |Z| >= 3 is the bar (stated in the primary line). The
   calibration (0 of 20) is on these folded values.
4. The f4-ratio is exercised only on toys. main3 has no second donor.
5. Zd being missing removes most candidates on main3 (89,592 of 123,019). no_outgroup_filter (+0.296, Z 8.96)
   agrees with the primary count, so the filter does not drive the result.

## Fix round 1 (review task-4-review.md: Spec ✅, 2 Important, 6 Minor; controller rulings I1, I2)
Commit: f655060 "Withhold Z where the block jackknife sees no variance; skip a second donor that discovers" (on
aa89e7b; global git identity, no trailers, not pushed). It touches trio.py, test_trio.py, constants.py (one
constant) and stats.py (that constant used).

Tests:
- tests/test_trio.py: 22 passed (4 added).
- Full suite under -W error -m "not slow": 946 passed, 1 deselected.
- ruff: clean.
- The brief's tests are AST-identical except `test_roles_from_sign` (the earlier lint edit) and
  `test_null_and_admixed` (the ruled replacement).

### Before and after
- Against the pre-fix code (aa89e7b's trio, stats and constants copied into a scratch package), 7 tests fail:
  `test_null_and_admixed`, the sparse-young-bin regression, `test_gradient_balanced_bins`,
  `test_gradient_is_one_joint_jackknife`, `test_trios_skip_and_undefined_sign`, `test_f4_skips_and_warns` and
  `test_f4_second_donor_that_discovers`. The last two gradient tests fail only on the new "not significant"
  wording.
- `test_blocks_on_d_sites` passes on the old code; it pins correct behavior. A mutant that blocks on R's
  sites instead of D's fails it (3 blocks against 4).

### Findings
**I1, fixed per the ruling, for every jackknifed ratio in trio.py.**
- **Rule.** Two helpers decide whether a jackknifed ratio is testable:
  - `_why(classes, blocks)`: an empty class the statistic compares, or its informative loci in fewer than
    JK_MIN_BLOCKS distinct blocks;
  - `_guard(jk, why)`: also an undefined estimate, or pseudovalues that do not vary (se 0), the same
    principle.
  When either finds a reason, se and z are nan and the estimate is kept.
- **Where it applies:**
  - D_pav: `d_pav` itself, so every stratum, and `trios`' sign, pass through it. The classes are n_RD and
    n_SD.
  - dD: per bin, each with its n_RD/n_SD and its own informative blocks.
  - f4: its four classes, [R pres, S E], [S pres, R E], [D2 pres, S E] and [S pres, D2 E], since num and den
    each compare two.
- **Findings.** The line says "not testable by the block jackknife: <reason>" (constant NOT_TESTABLE), and
  the row note repeats it.
  - The Dating line reads gene flow only for a finite Z >= Z_SIG.
  - Z <= -Z_SIG is "toward older insertions: not the age signature of gene flow".
  - Otherwise "not significant".
  - A nan z never carries the gene-flow sentence.
- **JK_MIN_BLOCKS = 3** is now a named constant in constants.py, with its reason. `stats.jackknife` uses it in
  place of its literal 3, so the floor has one source and behavior is unchanged.
- **Tests:**
  - `test_null_and_admixed` (ruled replacement): on the 92/0 toy, dD +0.8712 with se and z nan; the Dating line
    names "K=0: no S+D locus" and does not say gene flow.
  - `test_gradient_is_one_joint_jackknife` is the testable toy the ruling asks for: both bins hold both
    classes over 4 blocks, a young-biased excess with dD +0.933, se sqrt(0.2175), Z +2.0013.
  - `test_gradient_sparse_young_bin_not_testable` is the reviewer's probe: one young R+D locus beside 60 old
    loci split 30/30. Z was 13.81; now dD +1.0 with se and z nan. The K=0 stratum row is nan, the old bin
    stays testable (Z 0), and the strata line names the reason.

**I2, fixed per the ruling.**
- `_f4`, used by both `trio_tests` and `f4_ratio`, skips a D2 in `c.disc` with the line "f4-ratio of R,S;D
  with second donor X skipped: X discovers the counted loci (D has no annotation), so X is present at every one
  by construction".
- `test_f4_second_donor_that_discovers` is the reviewer's probe. With the same true insertions, D annotated
  gives num 2, den 5, f 0.4; the fallback case (X discovers) writes no f4 rows and the skip line;
  `f4_ratio(...)` returns [].

**Minors:**
- **M1, fixed.** `test_blocks_on_d_sites` mirrors D's chr1 sites over [1, 420,000]. D's 40-kb blocks then group
  the six loci (10, 9, 9, 8, 8, 7) unlike any other genome's (0, 0, 1, 1, 2, 2).
  - It asserts nblocks 4 and se sqrt(0.0675), the hand jackknife on D's mirrored mids. Anyone else's blocks
    give 3 blocks and se 1/3.
  - It checks this with D discovering and under fallback (X's call into D).
- **M2, fixed.** `test_gradient_balanced_bins`: 3/3 in each bin over the same 3 blocks gives dD 0, se
  sqrt(4/3) and Z 0, testable, "not significant", with no gene-flow wording.
- **M3, fixed.** The `f4_ratio` docstring says that it returns rows only and discards its findings, which
  `trio_tests` writes, and that it returns [] for a discovering D2.
- **M4, fixed and extended.** The roles row's source is "sheet order" when D_pav is nan, and also for a tie
  at exactly 0, where sheet order decides as well. Both write the "recipient is not identified" WARNING. The
  test covers both.
- **M5, fixed.** The nested_collapsed count rows' note reads "n: the informative loci kept, one per nested
  cluster"; the other strata keep "n: the counted loci".
- **M6, not fixed.** The review itself says to make `_check_trio` and `_fallback_reasons` public "when
  relations.py is next touched". This round does not touch relations.py, and the controller accepted the
  import.

Also in this round:
- trio.py is rewrapped to the codebase's 110-character lines (relations.py and catalog.py keep it; ruff does
  not enforce E501), with identical logic.
- My own test lines are within 110 as well. The brief's verbatim lines are left as written.

### main3, read-only probe after the fix
- Every row's value, se, z and n is identical to the pre-fix run: main3's bins are not degenerate.
- Primary: D_pav(B73,TIL01;TIL18) = +0.2905 ± 0.0392, Z 7.42 (1,317/724, 425 blocks).
- Strata (D, Z, n_RD/n_SD), unchanged:

  | stratum | D | Z | n_RD/n_SD |
  |---|---|---|---|
  | K=0 | +0.600 | 4.82 | 32/8 |
  | 0<K<0.01 | +0.612 | 11.78 | 320/77 |
  | K>=0.01 | +0.203 | 5.08 | 965/639 |
  | high_tier | +0.305 | 7.21 | 1,162/619 |
  | nested_collapsed | +0.279 | 7.30 | 1,136/640 |
  | no_outgroup_filter | +0.296 | 8.96 | 2,840/1,543 |

- Gradient: dD = +0.397 ± 0.127, Z 3.13 (421 blocks). It is testable: K=0 holds both classes (32/8) over
  more than 3 blocks. Its Dating line now reads "significant at |Z| >= 3: an excess concentrated in young
  insertions, which DESIGN 7.3 reads as gene flow rather than lineage sorting".
- f4: skipped, no second donor.
- main3's mtimes are unchanged and no file there is new.
- Cost: trio_tests 0.30 s after a 10.4 s load; peak RSS 480 MB.

## Re-review N1 (follow-up commit)
Commit: on f655060, "Treat identical jackknife pseudovalues as no variance".
- **Fix.** `stats.jackknife` sets se = 0 when the finite pseudovalues are all equal (`p.min() == p.max()`).
  Their float mean can be off by an ulp, which gave se 3.9e-17 and Z 5.1e15. Equal ratios of counts are the
  same double, so the test is exact and needs no tolerance. trio.py's `_guard` then makes se and z nan, with
  "not testable by the block jackknife: the block pseudovalues do not vary".
- **Tests:**
  - `test_identical_pseudovalues_are_not_testable` (tests/test_trio.py) is the reviewer's toy:
    - D_pav on 3 blocks x (3 R+D, 2 S+D): +0.2, se and z nan;
    - the gradient with uniform bins (3/2 young, 2/3 old): dD +0.4, se and z nan, no gene-flow wording.
  - `test_jackknife_identical_pseudovalues_have_no_se` (tests/test_stats_core.py): se == 0.0, z nan.
  - Both failed before the fix, with se 3.9e-17.
- **Results.** Full suite under -W error -m "not slow": 948 passed, 1 deselected. ruff clean.
- **main3, read-only recheck.** Every row is identical, and main3 is untouched.
