"""Small synthetic-sequence helpers shared by tests (seeded via the caller's Random).

Also the toy genotype cases: one window pair (A with the annotated element(s), B the other
assembly) per expected state. Element records are 1-based inclusive
on seqid "a"; `build_pair` lays the cases end to end on seqid "chr1".
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import NamedTuple

from ltrpav.annotation import assign_nesting
from ltrpav.elements import Element, make_eid
from ltrpav.seqio import revcomp


def write_fasta(path: Path, records: dict[str, str]) -> Path:
    """A FASTA of `records` (name -> sequence) in 80-column lines, with the parent directory made; returns
    the path."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as fh:
        for name, seq in records.items():
            fh.write(f">{name}\n")
            fh.writelines(seq[i:i + 80] + "\n" for i in range(0, len(seq), 80))
    return path


def rand_seq(n: int, rng: random.Random) -> str:
    """Uniform random ACGT of length n."""
    return "".join(rng.choice("ACGT") for _ in range(n))


def mutate(seq: str, rate: float, rng: random.Random) -> str:
    """Substitute each base independently with probability `rate` by one of the other three bases."""
    return "".join(rng.choice([c for c in "ACGT" if c != b]) if rng.random() < rate else b for b in seq)


def make_element(rng: random.Random, ltr_len: int, int_len: int) -> tuple[str, int, int]:
    """LTR + INT + LTR with identical LTRs: (sequence, left LTR length, right LTR length)."""
    ltr = rand_seq(ltr_len, rng)
    return ltr + rand_seq(int_len, rng) + ltr, ltr_len, ltr_len


FLANK = 3000  # length of the flanks L and R
SPACER = 20_000  # build_pair spacer length
T = "CTCTC"  # TSD of the top-level elements
T2 = "GAGAG"  # TSD of the host's child and of adjacent_E's second element
T_MM1 = "CTGTC"  # T with 1 substitution (E_mm1)
T_MM2 = "CACAC"  # T with 2 substitutions (E_mm2)
INT_SPLIT = 2000  # the host's internal region holds its child (or its empty site) after this many bp


class _Label(NamedTuple):
    state: str
    flags: tuple[str, ...] = ()  # must be present
    noflags: tuple[str, ...] = ()  # must be absent
    tier: str | None = None
    reason: str | None = None  # U reason


# case -> element name -> expected call
_LABELS: dict[str, dict[str, _Label]] = {
    "P": {"e": _Label("P")},
    "P_nestB": {"e": _Label("P", flags=("nestB",))},
    "S": {"e": _Label("S", flags=("solo_tsd",))},
    "S_notsd": {"e": _Label("S", noflags=("solo_tsd",))},
    "T": {"e": _Label("T")},
    "E": {"e": _Label("E", flags=("tsd_match",), tier="high")},
    "E_mm1": {"e": _Label("E", flags=("tsd_match",))},
    "E_mm2": {"e": _Label("E", noflags=("tsd_match",), tier="medium")},
    "D_left": {"e": _Label("D")},
    "D_both": {"e": _Label("D")},
    "O": {"e": _Label("O")},
    "G": {"e": _Label("G")},
    "G_near": {"e": _Label("G")},
    "G_far": {"e": _Label("E")},
    "U_flank": {"e": _Label("U", reason="flank_unaligned")},
    "inv_site": {"e": _Label("U", reason="inv_site")},
    "nested_E": {"h": _Label("P"), "c": _Label("E")},
    "host_E": {"h": _Label("E"), "c": _Label("E", flags=("host_empty",))},
    "host_S": {"h": _Label("S"), "c": _Label("D")},
    "host_G": {"h": _Label("G"), "c": _Label("G", flags=("inherit",))},
    "adjacent_E": {"e1": _Label("E", flags=("adjacent",)), "e2": _Label("E", flags=("adjacent",))},
}
CASES: list[str] = list(_LABELS)
_HOST = ("nested_E", "host_E", "host_S", "host_G")


@dataclass
class ToyCase:
    """One A/B window pair; the dicts are keyed by element eid."""

    a: str
    b: str
    elements: list[Element]
    expect: dict[str, str]  # expected state
    flags: dict[str, set[str]] = field(default_factory=dict)  # flags that must be present
    noflags: dict[str, set[str]] = field(default_factory=dict)  # flags that must be absent
    tiers: dict[str, str] = field(default_factory=dict)  # expected tier
    reasons: dict[str, str] = field(default_factory=dict)  # expected U reason


@dataclass
class ToyPair(ToyCase):
    """Toy cases laid end to end on seqid chr1 (same fields as ToyCase)."""


def _el(name: str, off: int, length: int, ltr: int, tsd: str) -> Element:
    """Toy element at 0-based offset `off` of A (the record is 1-based inclusive)."""
    s, e = off + 1, off + length
    return Element(genome="toy", eid=make_eid("toy", "a", s, e), name=name, seqid="a", start=s, end=e,
                   strand="+", ltr_left=(s, s + ltr - 1), ltr_right=(e - ltr + 1, e), tsd=tsd, k=0.0,
                   family=None, superfamily=None, clade=None, confidence=None)


def _finish(name: str, a: str, b: str, elements: list[Element]) -> ToyCase:
    out = ToyCase(a, b, assign_nesting(elements), {})
    for e in out.elements:
        lab = _LABELS[name][e.name]
        out.expect[e.eid] = lab.state
        if lab.flags:
            out.flags[e.eid] = set(lab.flags)
        if lab.noflags:
            out.noflags[e.eid] = set(lab.noflags)
        if lab.tier:
            out.tiers[e.eid] = lab.tier
        if lab.reason:
            out.reasons[e.eid] = lab.reason
    return out


def _single(name: str, L: str, R: str, rng: random.Random) -> ToyCase:
    """A = L T e T R with e = LTR(400) + INT(4000) + LTR."""
    e, n, _ = make_element(rng, 400, 4000)
    ltr, inner = e[:n], e[n:-n]
    b = {  # lambdas: only the chosen case draws filler from rng
        "P": lambda: mutate(L + T + e + T + R, 0.01, rng),
        "P_nestB": lambda: L + T + e[:2400] + rand_seq(3000, rng) + e[2400:] + T + R,
        "S": lambda: L + T + ltr + T + R,
        "S_notsd": lambda: L + T + ltr + R,
        "T": lambda: L + T + ltr + inner[:1600] + ltr + T + R,
        "E": lambda: L + T + R,
        "E_mm1": lambda: L + T_MM1 + R,
        "E_mm2": lambda: L + T_MM2 + R,
        "D_left": lambda: L[:-500] + R,
        "D_both": lambda: L[:-300] + R[400:],
        "O": lambda: L + T + rand_seq(2000, rng) + T + R,
        "G": lambda: L + T + "N" * 100 + R,
        "G_near": lambda: L[:-70] + "N" * 50 + L[-20:] + T + R,
        "G_far": lambda: L[:-550] + "N" * 50 + L[-500:] + T + R,
        "U_flank": lambda: L + T + rand_seq(3000, rng),
        "inv_site": lambda: L + T + revcomp(e) + T + R,
    }[name]()
    return _finish(name, L + T + e + T + R, b, [_el("e", len(L) + len(T), len(e), n, T)])


def _host(name: str, L: str, R: str, rng: random.Random) -> ToyCase:
    """A = L T h T R with h = LTRh(400) + INTh[:INT_SPLIT] + T2 + c + T2 + INTh[INT_SPLIT:] + LTRh, INTh 4 kb,
    c = LTRc(300) + INTc(2400) + LTRc."""
    hseq, n, _ = make_element(rng, 400, 4000)
    c, m, _ = make_element(rng, 300, 2400)
    ltr, inner = hseq[:n], hseq[n:-n]
    h = ltr + inner[:INT_SPLIT] + T2 + c + T2 + inner[INT_SPLIT:] + ltr
    b = {
        "nested_E": L + T + ltr + inner[:INT_SPLIT] + T2 + inner[INT_SPLIT:] + ltr + T + R,
        "host_E": L + T + R,
        "host_S": L + T + ltr + T + R,
        "host_G": L + T + "N" * 100 + R,
    }[name]
    off = len(L) + len(T)
    els = [_el("h", off, len(h), n, T), _el("c", off + n + INT_SPLIT + len(T2), len(c), m, T2)]
    return _finish(name, L + T + h + T + R, b, els)


def _adjacent(L: str, R: str, rng: random.Random) -> ToyCase:
    """A = L T e1 T T2 e2 T2 R with two distinct elements; B = L T T2 R."""
    e1, n1, _ = make_element(rng, 400, 4000)
    e2, n2, _ = make_element(rng, 400, 4000)
    o1 = len(L) + len(T)
    o2 = o1 + len(e1) + len(T) + len(T2)
    els = [_el("e1", o1, len(e1), n1, T), _el("e2", o2, len(e2), n2, T2)]
    return _finish("adjacent_E", L + T + e1 + T + T2 + e2 + T2 + R, L + T + T2 + R, els)


def case(name: str, rng: random.Random) -> ToyCase:
    """Toy case `name` (one of CASES); draws L and R, then the element(s), then any filler."""
    if name not in _LABELS:
        raise ValueError(f"unknown toy case {name!r}")
    L, R = rand_seq(FLANK, rng), rand_seq(FLANK, rng)
    if name in _HOST:
        return _host(name, L, R, rng)
    if name == "adjacent_E":
        return _adjacent(L, R, rng)
    return _single(name, L, R, rng)


def build_pair(rng: random.Random, cases: list[str] | None = None) -> ToyPair:
    """Toy cases end to end on seqid chr1: spacer, case, spacer, ..., case, spacer.

    Each spacer is a fresh 20-kb random sequence, the same in A and B. The default cases are CASES
    without U_flank (its U only arises when a window ends inside the case). Draw order: the cases,
    in order, then the spacers.
    """
    names = [n for n in CASES if n != "U_flank"] if cases is None else list(cases)
    built = [case(n, rng) for n in names]
    spacers = [rand_seq(SPACER, rng) for _ in range(len(built) + 1)]
    out = ToyPair("", "", [], {})
    a_parts, b_parts, els = [spacers[0]], [spacers[0]], []
    off = SPACER  # A offset of the current case
    for n, c, sp in zip(names, built, spacers[1:]):
        eid = {}
        for e in c.elements:
            s, t = e.start + off, e.end + off
            eid[e.eid] = make_eid("toy", "chr1", s, t)
            els.append(replace(e, eid=eid[e.eid], name=f"{n}.{e.name}", seqid="chr1", start=s, end=t,
                               ltr_left=(e.ltr_left[0] + off, e.ltr_left[1] + off),
                               ltr_right=(e.ltr_right[0] + off, e.ltr_right[1] + off)))
        for src, dst in ((c.expect, out.expect), (c.flags, out.flags), (c.noflags, out.noflags),
                         (c.tiers, out.tiers), (c.reasons, out.reasons)):
            dst.update((eid[k], v) for k, v in src.items())
        a_parts += [c.a, sp]
        b_parts += [c.b, sp]
        off += len(c.a) + SPACER
    out.a, out.b, out.elements = "".join(a_parts), "".join(b_parts), assign_nesting(els)
    return out
