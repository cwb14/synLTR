### Task 2: Launch the AnchorWave yardstick on chr10 (runs while the engine is built)

**Files:** Create (outside repo): `benchmark_pav/bakeoff/env_bench.yml`, `benchmark_pav/bakeoff/anchorwave/run.sh`,
`benchmark_pav/bakeoff/anchorwave/README.md`

- [ ] **Step 1: Create the bench env.** Write `env_bench.yml`: name `ltrpav_bench`, the Task 1 dependencies plus
  `anchorwave=1.3.1`, `samtools`, `pywfa=0.6.0`, and pip `-e /data2/chris/maize_introgression/LTRpav`. Then run
  `mamba env create -f env_bench.yml`.
- [ ] **Step 2: Write `run.sh`** (`set -euo pipefail`, `cd` to its own dir). Steps:
  - `samtools faidx inputs/B73v5.fa B73v5_chr10 | sed '1s/.*/>chr10/' > B73_chr10.fa`, and the same for
    `TIL18_chr10`. genoAli pairs chromosomes by name.
  - `zcat benchmark_data/annot/Zm-B73-REFERENCE-NAM-5.0_Zm00001eb.1.gff3.gz | awk '/^#/ || $1=="chr10"' > genes_chr10.gff3`
    (2,705 genes).
  - `anchorwave gff2seq -i genes_chr10.gff3 -r B73_chr10.fa -o cds.fa`
  - `minimap2 -x splice -t 8 -k 12 -a -p 0.4 -N 20 TIL18_chr10.fa cds.fa > cds.sam`, and the same against
    `B73_chr10.fa` into `ref.sam`.
  - `/usr/bin/time -v anchorwave genoAli -i genes_chr10.gff3 -as cds.fa -r B73_chr10.fa -a cds.sam -ar ref.sam -s TIL18_chr10.fa -n anchors -o anchorwave.maf -f anchorwave.f.maf -IV -t 8`
  - Write `done.flag` at the end.
- [ ] **Step 3: Launch detached.** From the anchorwave dir:
  `setsid -f nohup mamba run -n ltrpav_bench bash run.sh > run.log 2>&1 < /dev/null`. Then check `pgrep -af genoAli`
  (or `pgrep -af run.sh`) and `ps -o pid,ppid,sid,cmd -p <pid>`. Expected: SID = PID and PPID = 1.
- [ ] **Step 4: Record.** In `README.md` write memo-style lines: date, purpose, env, commands, PID, expected outputs
  (`anchorwave.maf`, `done.flag`). Not committed; it lives outside the repo.

---

