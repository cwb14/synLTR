# Task 2, fix round 1 of 5 (review: task-2-review.md; 0 Critical, 2 Important, 5 Minor; plus ruling C4a)

Read task-2-review.md in full first. These rulings bind.

## C4a. Existence reads presence, not host status (controller ruling, ledger)
- A nested element exists at q when all of these hold:
  - q is below its origin;
  - no kept ending loss of its own lies above q;
  - its anchor in its host's coordinates is present at q, recursively up the host chain.
- A host's ending loss no longer ends what sits in sequence that the loss leaves. A nested insertion in a host's
  surviving solo LTR keeps its own younger losses and nested insertions.
- **B_X still stops at X's ending losses.** No insertions are drawn into a simulated solo LTR. Name this in the module
  docstring as a simplification; the review estimates its cost at about 8 insertions at 5 Mb.
- **Update everything the review's C4a section lists:**
  - test_thin_nested_in_solo_ltr's expected values;
  - test_nested_carriers_and_offsets, narrowed to the direct host;
  - the docstring (popevents.py:28-33, 58-60);
  - the report's audit line.
- **A nested del_flank is measured in its host's original coordinates,** like the del_partial union. For y in x's
  surviving solo LTR, the flank ends at x's already-removed region. State this as the convention in removed()'s
  docstring.

## Important 1. Stale nested-target test
Make test_nested_target_not_on_n assert the window the code checks, `[pos - TSD_DEFAULT, pos)` in host coordinates.
Add a one-sided check that holds for any seed. Fix the comment at :338.

## Important 2. Replacing sequence receives no insertions (plan-mandated)
- **Ruling:** name it; do not model it.
- Why:
  - DESIGN 12 items 4 and 7 draw the replacing sequence as random bases standing in for whatever occupies the site.
  - The hard class it would add, insertions into lineage-specific sequence that other genomes lack, is already
    exercised by nested insertions in simulated insertions (902 kept at 5 Mb).
  - Modeling it would add a new host type to the interfaces and truth rules of Tasks 2-4.
- **Do:**
  - Correct the docstring's "exactly lam per present bp per generation". The rate is exact on present sequence
    except replacing sequence and simulated solo LTRs, and both are named as simplifications.
  - Add one line to DESIGN 12 item 7 saying the same.
  - Report the 5-Mb probe's expected count of missing insertions, sum(lam x a x B_R) over kept replaces, in
    task-2-report.md. Task 6/7's density readout will cite it.

## Minors
- **M1.** Add the nested-rate test the review proposes: TREE16, delta = 0, the depth-1 count against
  sum(lam x len(body) x B_X) at 3 SD.
- **M2.** One docstring sentence naming C2's "any carrier" rule as the approximation of reading an element on one
  tree, with both of its effects:
  - discarded primaries;
  - a discarded ending loss still truncates the draw below it on the carriers that keep the element.
- **M3. Junction rule.** Use one rule for whether an existing element survives a removal.
  - An element anchored before base s of its host (or of the backbone) is removed on a lineage when both bases s - 1
    and s are removed above that point, by the union of kept removed intervals in that coordinate system. Its host
    being gone also removes it.
  - So X's del_flank (a > 0, b > TSD_DEFAULT) removes an insertion W at the same host position. X's replace does not:
    it removes only X's body.
  - **Nested offsets** are drawn uniform in `[TSD_DEFAULT, len(body))`, so every nested target lies inside its host's
    own sequence. The primary target rule already works this way; the cost is 5 bp of about 8 kb.
  - State both rules in removed()'s docstring, because Task 3's builder reads the same rule.
  - Test W at the same position as X under X's del_flank, one-sided (a = 0) and two-sided, with expected outcomes.
- **M4.** Fix test_popevents.py:214's comment: the elements are kept by the whole-span rule (C4b), not by distance.
- **M5.** Make nested `Ins.time` a Python float.

## Process
- Commit or commits on plan3-benchmark with plain subjects. Use the existing identity, set nothing, add no trailers,
  and never push.
- Run the suite detached with the env bin on PATH, and `ruff check .`. Engine fingerprints must stay identical to
  12d3e6c.
- Rerun the 5-Mb probe, and the reviewer's oracle if it still applies:
  `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t2review/`.
  Copy it to your scratch first, and update it for C4a and M3 if needed. Report the kept and dropped counts.
- Append "Fix round 1" to task-2-report.md.
- Return only:
  - status;
  - commits;
  - the test line;
  - one line per finding (fixed or not);
  - the new counts;
  - concerns.
