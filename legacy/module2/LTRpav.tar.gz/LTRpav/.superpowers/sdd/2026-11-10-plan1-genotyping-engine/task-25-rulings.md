# Task 25: controller rulings
These bind as much as `task-25-brief.md`, and override it where the two conflict.

## Context the brief cannot know
- **Defaults after the bake-off:**
  - anchoring route flank-mm2 with a 2-kb cap (568f90d);
  - local backend LASTZ (Task 24H);
  - syntenic anchor net (24F);
  - anchored present calls, rule 5a (24G), tightened in 24H;
  - adaptive chunking.

  The bake-off report is `/data2/chris/maize_introgression/benchmark_pav/bakeoff/REPORT.md`; read sections 0, 4 and
  8.
- **Taxa:** B73v5 = maize; TIL18 = *Z. mays* ssp. *mexicana*; TIL01 = *Z. mays* ssp. *parviglumis*; Zd =
  *Z. diploperennis*, the outgroup, which has no annotation. The brief's sheet groups are right.
- **Whole-genome inputs:**
  - FASTAs in `/data2/chris/maize_introgression/inputs/`. Zd.fa has no .fai; the tool indexes it into `work/`.
  - Annotations: the LTRquest prefixes `/data2/chris/maize_introgression/run/<G>_LTRs`. The chr10 element sets
    matched these prefixes' chr10 subsets exactly in the bake-off.
  - Read-only: `run/`, `inputs/`, `benchmark/`, LTRmix.

## Rulings
1. **Phasing (ledger R12).**
   - Phase A: brief Steps 1-2. Write the sheet, write a memory sampler, launch detached and verify the PID. Return
     at once with the PID, log, expected outputs and an ETA. Never wait on the run.
   - Phase B: Steps 3-5, a later dispatch made after the controller has seen the run finish.
2. **Run directory:** `/data2/chris/maize_introgression/benchmark_pav/main3/`. Use env `ltrpav`, which imports the
   repo's working tree; check `which lastz` there first.
   - The run uses `--threads 32`. Task 25 confirms the cost bar, and the bar is defined at 32 threads (DESIGN 9 (3);
     rule 13).
   - Launch: `setsid -f nohup env NUMPY_MADVISE_HUGEPAGE=0 /usr/bin/time -v -o main3/time.txt <ltrpav run ...> >
     main3/run.log 2>&1 < /dev/null`.
   - Verify with `pgrep -af`, then `ps -o pid,ppid,sid,cmd`: SID = PID, PPID 1.
   - Write a done or exit marker (a wrapper script that writes `main3/run.exit` with the exit status is fine).
3. **Memory.** Write a sampler of the run's process-tree PSS: the sum of `Pss:` from `/proc/<pid>/smaps_rollup` over
   the tree, every 5 s, into `main3/mem.tsv`. Launch it detached the same way, and have it stop when the run ends.
   The 250-GB bar is judged on max(time.txt max RSS, peak tree PSS), as in the bake-off.
4. **Phase B QC (`qc_report.py` -> `QC.md`).** One row per DESIGN 10.1 bar, with a plain pass or miss, plus the
   brief's reported rows.
   - **Per-pair cost from run.log stage times.** The cost bar is about 2 h per maize-sized pair at 32 threads,
     with rule 13's 2.5 h and 250 GB.
   - **Real-data bars** (reciprocity, annot_agree, e_in_annot): chr10 already showed misses (reciprocity
     0.84-0.91, annot_agree about 0.80, e_in_annot about 0.18). Report the whole-genome values plainly as misses,
     each with its investigated reason.
     - e_in_annot is decomposed by inspection Q4: about 85% correct nested E. QC carries 24H's ancestor-link fix.
     - Never tune a bar or a rule to pass. A rule changes only for a reason independent of the miss, and then is
       rechecked.
   - **Segmental-duplicate audit** (bake-off caveat 1). For 200 seeded random high-tier E calls per ingroup pair
     direction:
     - test whether A's 1-kb flanks are unique in B, as the bake-off inspections did (blastn, one copy beating
       every other by >= 10 bits);
     - for the non-unique ones, check whether the other copy carries the element.

     Report the rate with a binomial 95% interval. This is the only whole-genome check of the 2-kb cap's known
     failure mode.
   - **Scaffold cost** (24F's named cost). Report the U fraction of elements on unplaced scaffolds against those on
     chromosomes, per genome.
   - **Independent annotator, outgroup patterns and LTRmix comparison:** as the brief says. The outgroup
     "impossible" patterns are an upper bound on the error rate: deep lineage sorting in Zea also makes them (Plan 2
     review I-3).
5. **Write-ups.** `QC.md`, dead_ends.md entries (one per miss, with an investigation note) and
   `/data2/chris/maize_introgression/memo_ltrpav.md` in CLAUDE.md memo format. The memo includes `claude --resume
   a7cbe20d-95be-480c-b88f-18a5132aaf2e`.
6. **Compute.** The run uses 32 threads. QC probes use at most 16 more, each under `timeout 15m` in the foreground.
   Anything longer runs detached, PID verified.
7. **No repo change in Task 25.** If QC finds an engine defect, report it with evidence; the controller rules.

## Addendum for phase B (after the final review)
8. **Recompute the QC with the fixed code.** The final review found that qc.tsv's reciprocity and annot_agree do
   not compute DESIGN 10.1's quantities (final-review.md, I1). The fix wave corrects them on branch
   `plan1-final-fixes`, which the controller fast-forwards into plan1-engine once main3 has ended.
   - Phase B computes loci and QC with the fixed `ltrpav.loci` through the API, on main3's existing pair files and
     element TSVs.
   - Write the results to `main3/qc_fixed/`. Never modify main3's own outputs.
   - Never resume `ltrpav run` in main3: the fix wave adds an engine fingerprint to every stage key (I2), so a
     resume would recompute all 9 pairs.
   - QC.md gives both qc.tsv's values (engine 7d71073) and the fixed ones, and judges the bars on the fixed ones.
9. **What the fix wave does not change.** It pins LASTZ to asm20 scoring (C1). main3 already ran at asm20
   (d ~ 0.033), so its calls stand.
