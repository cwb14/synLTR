# Task 8 Part A review (Steps 1-8): simulation harness

Reviewed 2026-11-13 against task-8-brief.md (Steps 1-8), task-8-rulings.md (R1-R3, R6-R8), the progress.md rulings
for Part A, and plan lines 111-281. All paths below are under `$P/benchmark_pav/plan3/` unless they are absolute.
The checks were run in env ltrpav after sourcing `common/env.sh`, on copies or new outputs in
`/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t8review/`.
Nothing in plan3/, main3/, inputs/, run/, LTRmix/ or benchmark/ was written, and nothing was installed.

## Spec Compliance

| Requirement | Verdict | Evidence |
|---|---|---|
| R1 snapshot `snap/4f3973e` = `git archive 4f3973e src`, plus SHA | ✅ | Running `diff -r` against a fresh `git archive 4f3973e src` reports no difference. `snap/4f3973e/SHA` = 4f3973e39ad6…. There is no `__pycache__` in the snapshot. |
| env.sh: PYTHONPATH on the snapshot, NUMPY_MADVISE_HUGEPAGE=0, PYTHONDONTWRITEBYTECODE=1 | ✅ | common/env.sh:15-17. After sourcing, `ltrpav.__file__` = `snap/4f3973e/src/ltrpav/__init__.py`. |
| env.sh: env ltrpav's bin on PATH (R7), and the assertion | ⚠️ | The bin is added at env.sh:20-23 and the assertion is at :24-35. The bin is not always first on PATH, and the assertion checks a different interpreter than the scripts run (Minor m1). |
| view.sh: absolute paths resolved against the sheet's resolved directory | ✅ | view.sh:70-71 and :92-96 mirror `read_samples` and `_resolve` (snap samples.py:28-41). |
| view.sh PAIRS_FILTER: pair links with their `.done.json` markers; the label's annotation set to `.`; no loci, manifest or qc links | ✅ | view.sh:100-101 and :132-152 (links at :127-131 only when there is no filter). On a copy of the toy run: 30 pair files and 30 markers, no `C1__*`, C1's annotation is `.`, and only `pairs/`, `work/elements`, `samples.tsv` and `.view` exist. `ltrpav-merge` in the view then ran (rc 0, "elements done, skip", 1,798 loci). The RUN's `work/elements` sha256 values did not change. |
| view.sh refuses an existing non-view directory | ✅ | view.sh:111-122. A plain directory was refused (rc 1). So was the same view asked for with another filter, or with no filter (rc 1). A filter naming an unannotated label was refused before any directory was made (:106-107). |
| Step 2 backbone.tsv: ten windows, element counts, draw | ✅ | backbone.py:33-58 redraws the draw with `default_rng(20261112)` and checks it. backbone.tsv matches the brief's ten regions and counts (582 … 612), with N fractions ≤ 0.0053. |
| Step 3 loss mix: level-0 B73 elements that B73__Zd calls P/S/T, joined by eid, S/D/T/O pooled, written in the order S, D, T, O | ✅ | calibrate.sh:65, :69-79, :86. An independent awk recount from the main3 call files gives 9,219 kept eids, none duplicated, all joined. TIL18 has S 334, D 468, T 1,405, O 583. TIL01 has S 312, D 393, T 1,280, O 480. Pooled 646/861/2,685/1,063 gives 0.12293054234062797, 0.1638439581351094, 0.510941960038059, 0.20228353948620362: exactly the values in demography.json. |
| replace_mean = mean `b_ins` of those O calls, pooled over calls | ✅ | calibrate.sh:80-84 and :93. The recount gives (7,529,401 + 6,861,657) / 1,063 = 13,538.154280338664, equal to demography.json. |
| t_o rule: the smallest candidate whose conflict is ≤ main3's max frac_E in A1, B1 and C1 | ✅ | calibrate.sh:102-105 (bound 0.0323232, TIL18; stats.tsv has exactly three such rows) and :112-128 (candidates in ascending order; the first with max(conf) ≤ bound). The computation is probe_outgroup.py's (same denominator and seeds). `sample_labels` order is A1 A2 B1 B2 C1 C2 O1, as calibrate.sh:118 assumes. The result is 900,000. |
| demography.json holds exactly the calibrated values | ✅ | calibrate.sh:142-153 writes `{t_o, loss_split, replace_mean}` at full precision. It reads the file back through `demog_from_json` and asserts the values. |
| Step 4: imports the pattern pairs and DFOIL_ALT_SIGNS; reads demography.json | ✅ | probe_direction.py:38 (`DFOIL_ALT, DFOIL_ALT_SIGNS, STATS`) and :37 (`Z_SIG` = 3.0); demography.json is merged at :46-51. |
| Step 4: every direction scenario, 4 x 10 Mb (posctl 30), detached, ≤ 16 processes, done marker | ✅ | 29 scenarios and 194 jobs (26 x 4 + 3 x 30); probe_direction.py:128. Exit 0 in 13:18 wall; `direction_predictions.tsv.done` and `probe_direction.exit` were both written. The script's sha256 prefix 639bbba66873a582 matches the report. |
| Labels follow the code-to-label rule | ✅ | probe_direction.py:96 and :100 compute `DFOIL_ALT_SIGNS.get(code, "none")` with `±Z_SIG`, the same as `signature()` (snap analysis/direction.py:106-110). |
| Step 5 grid: kinds, names, values, seeds, design, counts | ✅ | make_grid.py:51-89. grid.tsv reproduces byte for byte from `--bneck-nulls 30`. By kind: null 30, power 36, reverse 8, ptlike 3, bneck 33, posctl 8 (that is 88 + 30 on 7 genomes) and dropout 26 trios. Seed ranges match the brief. `ne` is 1000 only for posctl. `dropout_A1` is set only for dropout rows, `bottleneck` only for bneck rows, and `pulse` is empty wherever f = 0. ptlike has `sub_a:6000,30000` (ne_a). |
| `--bneck-nulls 10` regeneration | ✅ | 124 rows, bn_null seeds 4001-4010. With the bn_null rows removed it is identical to the 30-null grid, and gene-flow seeds stay 4031-4033 (make_grid.py:68-70). |
| Step 6 commands: sim, geno, views, ltrmix, eval | ✅ | `--dry-run` was run for all 144 rows and each printed command was parsed against its grid row. All 144 matched: seed, f, ta, pulse, per-taxon, bottleneck, `--dropout-genome`, `--dropout 0.1 --jitter 0.05 --threads 16`, 10 regions, identity only for null, nodonor only for null and power, rate_free_split only for null, 4 libraries for 7g and 3 for trio, and all five views. |
| Markers, `--from`, `--until`; `set -euo pipefail`; `/usr/bin/time -v` per step | ✅ | run_one.sh:22, :179-185, :195-212, :203-204. `--from geno --until views` runs only those two steps. `--from` after `--until` gives rc 1, an unknown step rc 2, `--windows 0` and `--windows 11` rc 1. |
| row.json merges sub and ne (ruling: the move is accepted) | ✅ | run_one.sh:97-99 and make_grid.py:105-114, :129-131. A real (non-dry) run of the pt, bn and pc rows on toy windows put the merged fields in `sim/row.json`. params.json then shows sub_a [6000, 30000] for pt; bottleneck [5000, 2000] for bn; and all six Ne at 1000 with sub_a/sub_c for pc. |
| sim/ cleared before a rerun (R3) | ✅ | run_one.sh:96 also removes every derived output. |
| View table; each painting variant in its own view (R7) | ✅ | run_one.sh:105-127: main, roles, any, decoy and anydecoy are each a separate `view.sh` directory; nodonor runs merge then stats. |
| LTRmix outputs for 3 vs 4 libraries | ✅ | run_one.sh:82 and :131-135 pass `--outdir ltrmix` only. ltrmix.py:1615 picks the subdirectory itself, and the toy runs show both layouts. |
| rate_free_split for null rows only, exit recorded | ✅ | run_one.sh:136-150. The toy run printed the s line and recorded exit 1. |
| The \x1f row-splitting fix | ✅ | run_one.sh:63-67. \x1f is not IFS whitespace, so empty cells survive. `read` drops only a trailing empty field, and the last column (`kind`) is never empty; a field-count check backs this up. All 144 dry-run rows parsed correctly. The real path (`declare -p R`, then eval at :191 and :203) carried `C>A1`, `C1>A1` and `sub_a:2000,1000;sub_c:30000,1000` through to params.json. |
| run_grid.sh: xargs -P 2, .done/.failed/.exit, `--until` passthrough, new options | ✅ | run_grid.sh:42-46, :53-70. A 3-row toy grid (`--until sim --windows 2`) wrote `.done` and exit 0, and its rerun skipped by marker. With one row's seed changed, the grid wrote `.failed` = `bn_null_s1	1` and `.exit` 1. `--windows 1` against a 2-window run was refused. |
| gff3_to_ltrmix.py follows edta_to_lib.py's conventions; reads through .fai/pysam | ✅ | gff3_to_ltrmix.py:50 (header), :54-57 (fetch, then reverse-complement on minus), :58-62. ltr_left is in genome orientation (snap elements.py:18), so ltr5 is the genome-left LTR as in edta_to_lib.py:63-64. The test's expected minus sequence was checked independently by hand. Copied tests: 4 passed. In the toy run, A1/B1/C1/C2 libraries have the same element counts as the GFF3s and as ltrpav's element tables. |
| R6: env ltrmix untouched; LTRmix/ untouched | ✅ | LTRmix/__pycache__ still holds 130 files, nothing in LTRmix/, run/ or benchmark/scripts/ is newer than the snapshot, `inputs/B73v5.fa.fai` mtime is 2026-11-06, and the repo is clean. |
| memo.md in CLAUDE.md format | ✅ | sim/memo.md: key:value lines, commands, calibration, gotchas and the resume id. |

## Strengths
- **Each run is tied to what made it.** The signature (row text, backbone path, window count and regions) is stored
  in `sim.done` (run_one.sh:76, :186-188, :209). A forgotten `--windows 5`, a changed row, or a pilot directory not
  moved aside therefore fails loudly instead of being skipped. I confirmed this for a changed seed and a changed
  window count.
- **Calibration is exact and traceable.**
  - It records counts per sister, sha256 prefixes of the sources, and every candidate's line (calibration.tsv).
  - The JSON is checked by reading it back (calibrate.sh:146-148).
  - The values reproduce the drafting probe to the third decimal.
- **The probe reuses the method's own definitions.** It imports `DFOIL_ALT`, `DFOIL_ALT_SIGNS`, `STATS` and `Z_SIG`
  rather than copying them. Its jobs can be resumed, and a job's JSON is reused only when its fields match. Its
  scenario fields are built the way `ltrpav-sim pop` builds them, and the rows of one scenario are checked for
  agreement (probe_direction.py:44-56).
- **Writes are safe.** Writes are atomic throughout (make_grid, gff3_to_ltrmix, view.sh, calibrate). xargs's exit
  code 255 is mapped to 1 (run_one.sh:177), so one failed run cannot stop the grid. LTRmix's numba cache is moved
  out of the read-only LTRmix/ (env.sh:19).
- **view.sh copies the sheet parser closely.** It parses the sheet as `read_samples` does (comments, BOM, field
  count, resolved base), and it validates the filter before it creates anything.

## Issues

### Critical
None.

### Important
None.

### Minor
- **m1. env.sh can leave the wrong `python` first on PATH, and the assertion checks a different interpreter.**
  - **Cause.** env.sh:20-23 prepends env ltrpav's bin only when it is absent from PATH. The assertion at :24 runs
    `$LTRPAV_ENV/bin/python`, not the `python` that the harness calls (run_one.sh:97, :132, :159; view.sh:27;
    Task 9's eval_run.py).
  - **Reproduced.** I set `PATH=envs/ltrmix/bin:envs/ltrpav/bin:…` and sourced env.sh. It returned 0, but `python`
    was ltrmix's 3.11. That interpreter still imports the snapshot through PYTHONPATH.
  - **Impact.** Frozen code holds either way. The `ltrpav-*` commands have fixed shebangs. The controller's launch
    shell has no conda bin on PATH. But the "env ltrpav" contract for the helper scripts and the scorer is not
    enforced.
  - **Fix.** Always prepend the bin (drop the `case`). Or run the assertion with `python` and also check
    `sys.prefix == $LTRPAV_ENV`.
- **m2. Nothing stops two launches from using the same run directory at once.**
  - **Where.** run_one.sh:174-177 and run_grid.sh:52-56 take no lock.
  - **Risk.** An accidental second launch, for example the grid started before the pilot ends or a relaunch after a
    misread PID, would run two `run_one.sh` in the same directory: `rm -rf sim` racing a live simulation or
    genotyping.
  - **Fix.** One `flock -n` per run directory (and one on `<TSV>.lock`) would cost little and protect 65 h of compute.
- **m3. The "peak RSS" in `<step>.time` and run.log understates total memory.**
  - **Why.** `/usr/bin/time -v`'s maximum RSS (run_one.sh:203, :210) is the largest single descendant process, not
    the sum. ltrpav-genotype and the identity layer use fork process pools (snap genotype.py:317,
    analysis/identity.py:361).
  - **For Part B.** Step 9's peak-RSS record and the 250-GB check need a note or a sampler (as `real/mem_sampler.sh`
    does).
- **m4. `--dry-run` can report a skip that the real run would refuse.** It exits (run_one.sh:163-172) before the
  signature check (:186). So it can print "[sim] marker exists: skip" for a directory the real run would refuse.
  Cosmetic.
- **m5. The predictions file stores two chance codes in its `code` column.**
  - **What.** direction_predictions.tsv has the realized codes `00+0` (f0.18_Ta50) and `0-0-` (f0.18_Ta500) where the
    expected code is 0000.
  - **Why it is only cosmetic.** The ruling makes the label what scoring reads, and both labels are "none" as
    predicted.
  - **Fix.** Task 9's RULES.md should state that the code expected for every population-level scenario is 0000 by
    symmetry (see the assessment below), and that only the label is a prediction. Otherwise a code-level comparison
    could treat these chance codes as targets.
- **m6. A missing s line does not fail the ltrmix step.**
  - **What.** run_one.sh:146-148 records the exit and logs the s-line count. But the ltrmix step succeeds even when
    rate_free_split.py fails before printing the s line (count 0).
  - **Fix.** Task 9's eval_ltrmix.py must treat a missing s line in `RUN/rate_free_split.txt` as a failed
    measurement, not a value.
- **m7. Disk use is not yet recorded.**
  - **Measured.** The toy null run took 494 MB for 7 × ~15-Mb genomes; `geno/work/anchors` held 302 MB of it.
  - **Projected.** Scaled to ~180-Mb genomes that is about 6 GB per 7-genome run, about 0.8-0.9 TB for the grid.
    /data2 has 129 TB free, so this is fine.
  - **Fix.** Record the pilot's `du` in memo.md. Note that `/` (and so /tmp scratch) is at 96%, 164 GB free.

## Assessment of the two deviating direction codes

The report's explanation is right, and it can be made exact.

- **Symmetry.** Each statistic flips sign when one pair of genomes is swapped:
  - DFO and DIL when C1 and C2 are swapped (for example, the pattern pairs 1010↔1001 and 0110↔0101);
  - DFI and DOL when A1 and A2 are swapped (1010↔0110, 1011↔0111).
- **Expected code.** In every population-level scenario, A1 and A2 are exchangeable, and so are C1 and C2. These
  scenarios are null, every C>A and A>C pulse, and the bottleneck runs. So every expected D is exactly 0, and the
  expected code is 0000.
- **What the two codes are.** The DFI of f0.18_Ta50 and the DIL/DOL of f0.18_Ta500 are sampling noise.
  - The binomial Z treats insertions as independent, but insertions carried on the same introgressed tract are
    linked, so the Z is overdispersed.
  - I confirmed the sign flips the report cites from direction_jobs/. For f0.18_Ta500, the 1011:0111 counts are 12:28,
    22:40, 11:21 and 46:20.
  - I also confirmed that f0.02_Ta50 and f0.05_Ta50 are identical on every chromosome (common random numbers). The
    c01 counts of f0.18_Ta50 also equal f0.02's (no lineage moved there).
- **One caveat to the report.** Its "3 of 104 statistics vs ~0.3 expected" treats the 104 statistics as independent
  tests. They are not: every scenario reuses the seeds 100+c and 900+c, so the count is only indicative.
- **ptlike.** Only ptlike (C>A1) breaks A1/A2 exchangeability among the non-posctl scenarios. Its DFI (+2.21) and
  DOL (+1.15) lean in the A1-C direction, below Z_SIG. Its 0000 is therefore an empirical result, not one guaranteed
  by symmetry, and its label "none" is the prediction.
- **posctl.** The posctl counts equal the drafting probe's tb2k rows exactly.

## Observations for Part B (not defects of Part A)
- **The real-genome queue is running again.** The controller relaunched it at 01:14 (PID 2932602; progress.md).
  Part B must stop it (`kill -TERM -- -2932602`) before the pilot.
- **Simulation setup is slow under load.** In my toy grid, two `ltrpav-sim pop` runs at once spent about 216 s
  before their first progress line (annotation load and FASTA hash) at load average about 236, against 20 s in the
  implementer's toy. The pilot's `sim` time will include this contention. Record the load average beside it.
- **Calibration briefly went one thread over the cap.** It ran as one process while the queue used 32 threads: 33
  in total, within R2's allowance of at most 4 threads or processes.

## Assessment
**Approved.** Spec compliance passes (one ⚠️, Minor). There are no Critical or Important issues. The seven Minor
items can be done before or during Part B; m1 and m2 are each a one-line fix and are worth making before the
65-h grid.
