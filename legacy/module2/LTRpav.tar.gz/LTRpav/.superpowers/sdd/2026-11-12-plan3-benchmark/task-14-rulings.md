# Task 14: controller rulings (binding; they override task-14-brief.md where the two differ)

## R1. Code, inputs, order
- **Snapshot 2** for every analysis: `SNAP_SHA=6282541` (`benchmark_pav/plan3/snap/6282541`), via `common/env.sh` or
  `common/view.sh` (Task 11 Part C; `real/memo.md`). Check that `ltrpav.__file__` resolves inside it first.
- **Genotypes:** `real/genus/geno` (TIL01 TIL18 TIL25 Zh Zn Zd), `real/citrus/geno` (CsA CsB Cr Cm CaM CaP) and
  `real/edta/geno` (B73 TIL18 TIL01 Zd). Each block has `block.done`. Never write in a `geno/`; views link to it
  (`common/view.sh RUN VIEW SHEET`). The sheets are each block's `samples.tsv`.
- **Citrus truth:** `$P/benchmark/lineage2/truth/CsB.M.bed` and `CsA.P.bed` (read-only).
- **Order.** Steps 1 (genus) and 2 (citrus) first. Step 3 (EDTA portability) compares with `six/views/main`, which
  Task 13 is making in parallel. Start Step 3 only when that view's stats and paint parts are done (its
  `work/analysis/{stats,paint}.done.json` exist, and `findings.txt` lists no left-out part). If it is not ready when
  Steps 1-2 are done, report DONE_WITH_CONCERNS with Step 3 pending; the controller resumes you.
- Two queue workers (w4, w5) are genotyping `real/stability/*` from `snap/12d3e6c`. Do not touch `real/stability/`,
  `real/genotype_all.sh` or `snap/12d3e6c`. Never kill a process.

## R2. Shared files: stage, do not edit
Task 13 is editing `real/memo.md` and `benchmark_pav/dead_ends.md` now. Write your entries to staging files instead:
`real/genus/memo_entry_task14.md` and `real/genus/dead_ends_entry_task14.md`. The controller appends them after
Task 13 finishes. Use the same formats as the target files.

## R3. Simulation results to cite (sim/SIM_RESULTS.md, reviewed)
- **Decision 11 (`zd`).** Put the genus `zd` case beside SIM_RESULTS section 11: `nodonor`'s null count and power,
  with the note that 2 of its 7 power hits used A2 for discovery. The rule is unchanged; the user decides after
  Plan 3.
- **D_pav's null.** Rule 1 passed, but the null Z is not calibrated (rule 2 reading). Where you report a D_pav Z, also
  give its empirical null quantile against the default nulls (max |Z| 1.97) and the bottleneck nulls (max |Z| 3.14).
  Verdicts rest on the bottleneck null (controller ruling (I4), 2026-11-14). The DESIGN 10.4 bars stay as written.
- **Simulated power is optimistic for real data** (SIM_RESULTS section 10).
- **Painting:** the default model (`main`); no variant was adopted.

## R4. Science and reporting
- Bars as DESIGN 10.4 states them, each PASS or MISS. Each MISS is investigated (in your staging dead_ends file);
  never change a bar. Reported items get no verdict.
- The Zn annotation is an input limitation: 28,883 of 89,579 structural LTR-RTs sit on contigs the chromosome-only
  rule dropped (Task 12 ruling C1, in real/memo.md). It is LTRmix's genus input too. Name it where it bears on a
  result.
- Name LTRmix's comparison values with their source files under `$P/benchmark/` (read-only).
- No figures: Plan 4 draws them.
- Threads: at most 8 per command, and every command under 15 minutes. Snapshot `inputs/*.fai` (size, mtime, sha256)
  before and after your real jobs.
