# fig3_benchmark memo

date: 2026-11-07 | host: asc-oulab
purpose: Fig. 3, calibration, power and resolution of LTR-RT-only admixture inference (LTRmix benchmark)
env: conda env ltrmix (python 3.11.18, numpy 2.4.6, pandas 3.1.1, matplotlib 3.11.2, scipy 1.17.1, edlib, samtools 1.25)
font: Liberation Sans / Liberation Mono (registered from /usr/share/fonts/truetype/liberation2), pdf.fonttype 42
inputs (read-only, under /data2/chris/maize_introgression/benchmark):
- sim/eval/*.json (86 runs), sim/sim_summary.tsv, sim/runs/<run>/{truth_B.bed,params.json}, sim/out/<run>/{elements.B.tsv,ancestry.B.bed,stats.tsv}
- results/main3/{benchmark_real.tsv,stats.tsv,elements.B73v5.tsv}; edta/out/{benchmark_real.tsv,elements.B73v5.tsv}
- wgk/wgk_{all,noLTR}.*.tsv (via scripts/eval_wgk.py); truth/elai_summary.v5.tsv (via scripts/eval_real.py functions)
- absence/*.summary.tsv (4 pairs present at build time: B73v5.TIL01, B73v5.TIL18, TIL18.B73v5, TIL18.TIL01; TIL01.* still running), absence/B73v5.TIL01.tsv.gz
- ../inputs/{B73v5,TIL01}.fa (samtools faidx), ../run/B73v5_LTRs_depth*_clean_ltr.tsv
outputs: fig3_benchmark.{pdf (3 pages),png (300 dpi)}, fig3_benchmark_numbers.tsv (86 rows), data/ (cached helpers)

```bash
source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix
cd /data2/chris/maize_introgression/benchmark/figures/fig3_benchmark
python fig3_benchmark.py            # ~6 s with caches; --rebuild recomputes data/ (~2 min)
# what --rebuild runs:
python ../../scripts/eval_wgk.py ../../wgk/wgk_all   > data/eval_wgk_all.txt     # whole-genome k-mer window r (47 s both)
python ../../scripts/eval_wgk.py ../../wgk/wgk_noLTR > data/eval_wgk_noLTR.txt
python fig3_example.py              # picks + verifies the panel I element -> data/example_absence.json (~20 s)
# window_null(): 1,000 circular shifts per window size (eval_real.shift_test procedure, seed 1) -> data/window_null.tsv
```

checks:
- eval_wgk output equals the brief's numbers (0.246/0.294/0.333/0.348/0.370/0.430; masked 0.236/0.297/0.340/0.352/0.375/0.430)
- window_null r_obs reproduces benchmark_real.tsv (assert |diff| < 0.0015); null max < observed at every size (assert)
- null mean/SD of Z (sign flipped to true recipient B) equal sim_summary.tsv table=null (assert)

## Layouts considered
1. Genome browser lead (chosen): A = one simulated chromosome, null and gene-flow runs stacked at one bp scale (truth,
   class ticks two-sided, two posteriors, tracts) -> B = 2-Mb zoom, every element to size -> quantification grid
   (C AUROC, D calibration+power as 4 small multiples sharing axes, E fraction vs truth, F window r, G dropout,
   H completeness check) -> I base-pair absence example + J absence check.
2. Vertical ideograms like Fig. 1A for all 10 simulated chromosomes (null vs gene flow side by side), quantification
   below. Rejected: 20 ideograms at 180 mm leave ~4 mm per chromosome; short donor segments invisible; duplicates Fig. 1's form.
3. Quantification-first dashboard (null strip, power curves, ROC curves, r vs window) with a small painted chromosome
   inset. Rejected: fails "panel A shows biology in genome coordinates"; null not a full partner.
Chose 1: shows the claim (painting follows truth), its control (same chromosome, no gene flow) and raw evidence
(every element; one real absence at bp) most directly. Null on top so the gene-flow run sits next to its zoom
(connectors do not cross the null run); shared x-axis on top. Calibration and power merged (null at x = 0) so the
null is drawn in the same axes as the power runs.

## Examples (rules + structural checks)
- A: among f = 0.18, Ta = 5,000 runs (r1, r2) the chromosome whose true donor fraction is closest to its run's genome
  fraction: f0.18_Ta5000_r1 B_chr6 (0.1958 vs 0.1952; next r2 chr5 0.1864 vs 0.1853). Null partner: chromosome 6 of
  the first null replicate (lowest seed) in which the tool called B the recipient = null_s102 (typical: ancestry
  tracts 1,108 vs 1,125 decoys, median over nulls 1,247/1,234; Z all < 1.2). Caveat stated: r2 has 0 confident tracts.
- B: 2-Mb window (0.5-Mb steps) whose true fraction is closest to the chromosome's: 12.5-14.5 Mb (0.190). No confident
  tract in it (shown as is).
- I: absent-in-TIL01 calls confirmed 'empty' (absence table) with tg...ca, 5-bp TSD, confidence high, not nested,
  length within family IQR; ranked by |log| distance to median K2P (0.0147) and length (10,320 bp) of ALL absent calls;
  first that passes raw-assembly checks: B73v5_chr4:30969963-30981128 Gypsy/Tekay, 11,166 bp, K2P 0.0153.
  Verified on inputs/B73v5.fa: TSD GATAA identical both sides; TG at 5' LTR start, CA at 5' LTR end (2,794 bp),
  TG at 3' LTR start, CA at 3' LTR end (2,798 bp). Empty site found in TIL01_chr4:56,203,866-56,204,165 between the
  TIL01 orthologs of flanking B73 elements (edlib HW, 3 edits / 300 bp, one TSD copy). 24 higher-ranked candidates
  skipped: 18 TIL01 search interval > 600 kb (search limit, not structure), 4 empty site not in interval, 2 structure.

## Figure check (maker's answers)
1. Panel A in genome coordinates, every element drawn: yes (A every element of chr6 as a tick; B every element to size).
2. Raw evidence for a typical, verified real example: yes (I: base-pair junctions vs TIL01 empty site; checks above).
3. Control as a full partner at the same scale: yes (A null chromosome, same tracks and bp scale; D null runs in the
   same axes; C real vs simulated; F whole-genome comparators).
4. Every null drawn: yes (D N(0,1) band + Z = 3; C AUROC 0.5; E 1:1; F circular-shift band; G N(0,1) band; H ratio 1;
   J uncalled elements as the no-information reference).
5. On-figure text only letters, labels, ticks, direct labels, keys, n: yes (A header gives f, time, chromosome
   fraction; I gives k-mer counts n/20).
6. Crops at 300 dpi: nothing clipped or colliding after round 5; panels on a grid (left edges 13 mm D/F, 24 mm A/B;
   right column 140-178 mm C/E/H/J; middle blocks end at 128 mm except B, which ends at 118 mm so the zoom connector
   clears letter C); letters in reading order.
7. Each panel a different question; legend pages: short (headline + 1-2 sentences per panel), long (definitions,
   one paragraph per panel with rules and stats, exceptions, example choice, Analysis line). yes.

## Gotchas
- pandas reads the literal 'null' in sim_summary.tsv as NaN: keep_default_na=False.
- pandas Series.empty is a property: use x["empty"] for the absence column.
- recipient_called='P' runs: Z sign flipped to the true recipient B (as sim_summary does).
- sisters_ok=False runs paint against the wrong donor: excluded from recall/precision and AUROC (eval gives NaN AUROC).
- Legend layout: measure text widths at 1,200 dpi (100-dpi hinted widths drift over long runs in the PDF).
- Spec says LTR-only recovers "~85-93%" of whole-genome r; the tables give 83-87% for the pre-registered posterior
  (75-93% for the model-free class share, not drawn). Legend uses 83-87%.
- Spec says flipped runs |Z| 9-13 (k-mer test); across all four tests 7.6-13.2 (legend uses this).
- REPORT 7.3 quotes the completeness check as 1.06 +- 0.02; main3/stats.tsv (used here) gives 1.081 +- 0.018.
