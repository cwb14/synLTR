### Task 4: Trio roles and tests — D_pav, age strata and gradient, nested collapse, f4-ratio (DESIGN 7.1, 7.3, 7.5)

**Files:**
- Create: `src/ltrpav/analysis/trio.py`, `tests/test_trio.py`

**Interfaces:**
- Consumes:
  - `Catalog` (`pcls_by`, `ptier_by`, `proj_site`), `age_bin`, `cluster_keys`;
  - `jackknife`, `d_ratio`, `block_ids`, `block_size`, `resolution`;
  - `discover`, `Counted`, `sister_pair`, `pav_distances`, and the distances from `relations`.
- Produces:

```python
@dataclass(frozen=True)
class Trio:
    R: str; S: str; D: str; fixed: bool
    @property
    def scope(self) -> str                     # f"{R},{S};{D}"
def d_pav(cat: Catalog, R: str, S: str, D: str, c: Counted, size: int, keep: np.ndarray | None = None
          ) -> tuple[Jk, int, int]                                  # (jk, n_RD, n_SD) on c.rows & keep
def trios(cat: Catalog, fixed: tuple[str, str, str] | None, size: int, dist: np.ndarray
          ) -> tuple[list[Trio], list[StatRow], Findings]
def trio_tests(cat: Catalog, trio: Trio, size: int, dist: np.ndarray) -> tuple[list[StatRow], Findings]
def second_donors(cat: Catalog, trio: Trio, dist: np.ndarray) -> list[str]
def f4_ratio(cat: Catalog, trio: Trio, d2: str, size: int, dist: np.ndarray) -> list[StatRow]
```

Rules. The counted loci are `discover(cat, R, S, D, dist, "E")` (Task 3), so every state comes from each row's
discovering genome's own calls.

- **`d_pav`:**
  - `a` = `pcls_by(gstar, R) == 1` and `pcls_by(gstar, S) == 0`; `b` the mirror;
  - blocks = `block_ids(*cat.proj_site(gstar, D), size)` on the rows: D's coordinates as each row's discoverer reads
    them (D's own when D discovers);
  - `jackknife(d_ratio(a, b), blocks)`.
- **`trios`:**
  - **Fixed trio:** the three labels must be distinct ingroup genomes, else AnalysisError. It yields
    `[Trio(*fixed, fixed=True)]` with no inference.
  - **Otherwise,** for each 3-combination of ingroup genomes in sheet order:
    - `sister_pair` gives the pair and D;
    - D_pav of (pair[0], pair[1]; D);
    - R = pair[0] if that D >= 0, pair[1] if D < 0. A nan D keeps pair[0] (sheet order); LTRmix sends nan to pair[1].
  - Rows `roles`, statistic `source` (`data` or `--trio`).
  - With fewer than three ingroup genomes: no trios, and the line "Trio tests skipped: fewer than three ingroup genomes".
- **`trio_tests`** writes rows `D_pav` for each stratum: statistic `D` (se, z, n = n_RD + n_SD), plus counts `n_RD` and
  `n_SD`. A stratum with no loci writes no rows. With `discover` returning `None`, the test is skipped with its
  WARNING.
  - **Resolution:** `resolution("resolution", scope, {"R": ..., "S": ...}, ...)` over `cand`, from
    `pcls_by(gstar, ·)`.
  - **Outgroup filter** (row `outgroup_filter`, statistic `removed_frac`): the fraction of `discover(..., "none")`
    candidates that the outgroup rule drops. Always one findings line quoting it to two decimals.
  - **Strata:**
    - `all`;
    - the `AGE_LABELS` bins, by K of each row's gstar copy (`cat.k[i, gstar[i]]`);
    - `high_tier`: `ptier_by(gstar, R)` and `ptier_by(gstar, S)` are `high` (call tiers; a member's "annot" never
      enters);
    - `nested_collapsed`: the informative counted rows (a | b), sorted by the gstar genome's (seq, start, -end),
      keeping the first row per `cluster_keys(cat, gstar, ·)` key;
    - `no_outgroup_filter`.

    No finite K at all gives one findings line "age strata skipped: no K2P" and no age rows.
  - **Gradient:**
    - `dD = D(K=0) - D(K>=0.01)`, one statistic jackknifed over the union of blocks;
    - row `D_pav_gradient`, stratum `K=0 minus K>=0.01`, statistic `dD`;
    - findings in section "Dating".
  - **f4-ratio**, for each `second_donors` genome D2 (DESIGN 7.3, LTRmix `fratio`); `f4_ratio`:
    - on the D_pav rows with `pcls_by(gstar, D2) >= 0`, from the same calls: `num = [R pres, S E] - [S pres, R E]`
      and `den = [D2 pres, S E] - [S pres, D2 E]`;
    - `f = Σnum / Σden`, jackknifed on D's blocks;
    - rows `f4_ratio`, scope `R,S;D;D2`: statistics `f`, `num`, `den`, plus `resolution(...)` rows for D2.
- **`second_donors`:** genomes g of the ingroup outside the trio with `dist[D, g] < min(dist[x, y] for x in (D, g) for
  y in (R, S))`.

- [ ] **Step 1: Write the failing tests**

```python
def _trio_tests(cat, trio):
    return trio_tests(cat, trio, block_size(cat), pav_distances(cat)[0])

def _row(rows, test, stratum, statistic):
    return next(r for r in rows if (r.test, r.stratum, r.statistic) == (test, stratum, statistic))

def test_counted_rule_and_d(tmp_path, toy_fastas):
    loci = ([loc(10_000 * i, "R:P S:E D:P* O:E") for i in range(1, 5)]
            + [loc(10_000 * i, "R:E S:P D:P* O:E") for i in range(5, 7)]
            + [loc(70_000, "R:P S:E D:P* O:P"), loc(80_000, "R:P S:E D:P* O:U"),
               loc(90_000, "R:P* S:E D:P O:E"), loc(100_000, "R:P S:U D:P* O:E")])
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    c = discover(cat, "R", "S", "D", pav_distances(cat)[0], "E")
    jk, n_rd, n_sd = d_pav(cat, "R", "S", "D", c, block_size(cat))
    assert (n_rd, n_sd) == (4, 2) and jk.est == pytest.approx(2 / 6) and c.cand.sum() == 7
    assert c.loci == "disc=D;present=D;res=R,S;outgroup=E"

def test_counted_reads_discoverer_calls(tmp_path, toy_fastas):
    loci = ([loc(10_000 * i, "R:P S:E D:P* O:E") for i in range(1, 5)]                               # counted
            + [loc(10_000 * i, "R:P* S:E D:P* O:E", calls={("D", "R"): "U"}) for i in range(5, 8)]  # R P/annot merged
            + [loc(10_000 * i, "R:P* S:E D:P* O:E", calls={("D", "S"): "U"}) for i in range(8, 10)] # S E merged (R's call)
            + [loc(10_000 * i, "R:E S:P D:P* O:E") for i in range(10, 14)])                         # counted
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    c = discover(cat, "R", "S", "D", pav_distances(cat)[0], "E")
    _, n_rd, n_sd = d_pav(cat, "R", "S", "D", c, block_size(cat))
    assert (n_rd, n_sd) == (4, 4)
    assert (cat.ptier_by(c.gstar, "R")[c.rows] == TIER_CODE["high"]).all()        # call tiers; never "annot"

def test_null_with_unequal_annotation(tmp_path, toy_fastas):
    # the review's depth-leak probe, scaled down: no tracts, R annotated more completely than S
    for seed in (1, 2, 3):
        cat = simulate_run(tmp_path / str(seed), seed=seed, n_per_seq=3000, p_member={"R": 0.95, "S": 0.5},
                           p_missing=0.3, fasta_dir=toy_fastas).load()
        c = discover(cat, "R", "S", "D", pav_distances(cat)[0], "E")
        jk, _, _ = d_pav(cat, "R", "S", "D", c, block_size(cat))
        assert abs(jk.z) < 3                         # replica rr_toy.py: |Z| <= 0.15 at seeds 1-3
        if seed == 1:                                # the same rule on merged loci.tsv states: the leak it avoids
            m = (cat.member[:, cat.g("D")] & (cat.cls("D") == 1) & (cat.cls("O") == 0)
                 & (cat.cls("R") >= 0) & (cat.cls("S") >= 0))
            a = (m & (cat.cls("R") == 1) & (cat.cls("S") == 0)).sum()
            b = (m & (cat.cls("S") == 1) & (cat.cls("R") == 0)).sum()
            assert (a - b) / (a + b) > 0.05          # expected about +0.13 (+0.127 with the engine-faithful toy, Task 1 fix round 1)

def test_roles_from_sign(tmp_path, toy_fastas):
    loci = ([loc(1000 * i, "R:P* S:P D:E O:E") for i in range(1, 13)]           # sisters R, S
            + [loc(20_000 + 1000 * i, "R:E S:P D:P* O:E") for i in range(4)]   # S+D x4
            + [loc(30_000, "R:P S:E D:P* O:E")])                               # R+D x1: D(R,S;D) = -0.6
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    found, rows, f = trios(cat, None, block_size(cat), pav_distances(cat)[0])
    assert found == [Trio("S", "R", "D", False)] and _row(rows, "roles", "all", "source").value == "data"

def test_fixed_trio(tmp_path, toy_fastas):
    cat = write_run(tmp_path, [loc(1000, "R:P* S:E D:P* O:E")], fasta_dir=toy_fastas).load()
    size, dist = block_size(cat), pav_distances(cat)[0]
    found, rows, _ = trios(cat, ("S", "R", "D"), size, dist)
    assert found == [Trio("S", "R", "D", True)] and _row(rows, "roles", "all", "source").value == "--trio"
    for bad in (("R", "R", "D"), ("R", "S", "O")):
        with pytest.raises(AnalysisError):
            trios(cat, bad, size, dist)

def test_null_and_admixed(tmp_path, toy_fastas):
    for seed in range(1, 6):                         # replica rr_toy.py: |Z| < 3 in 200 of 200 seeds
        cat = simulate_run(tmp_path / f"n{seed}", seed=seed, fasta_dir=toy_fastas).load()
        dist = pav_distances(cat)[0]
        (trio,), _, _ = trios(cat, None, block_size(cat), dist)
        jk, _, _ = d_pav(cat, trio.R, trio.S, trio.D, discover(cat, trio.R, trio.S, trio.D, dist, "E"), block_size(cat))
        assert {trio.R, trio.S} == {"R", "S"} and trio.D == "D" and abs(jk.z) < 3
    cat = simulate_run(tmp_path / "adm", seed=1, tracts=TRACTS, n_per_seq=3000, fasta_dir=toy_fastas).load()
    dist = pav_distances(cat)[0]
    (trio,), _, _ = trios(cat, None, block_size(cat), dist)
    rows, _ = trio_tests(cat, trio, block_size(cat), dist)
    assert trio == Trio("R", "S", "D", False)
    assert _row(rows, "D_pav", "all", "D").value > 0 and _row(rows, "D_pav", "all", "D").z > 3   # replica: median Z 5.0
    assert _row(rows, "D_pav", "K=0", "D").value > _row(rows, "D_pav", "K>=0.01", "D").value
    assert _row(rows, "D_pav_gradient", "K=0 minus K>=0.01", "dD").z > 0

def test_fallback_discovery(tmp_path, toy_fastas):
    genomes = [("R", "taxR", None, True), ("S", "taxS", None, True), ("D", "taxD", None, False),
               ("X", "taxD", None, True), ("O", "taxO", "outgroup", False)]
    cat = write_run(tmp_path, [loc(1000, "R:P S:E D:P X:P* O:E")], genomes=genomes, fasta_dir=toy_fastas).load()
    near_d = dmat({("R", "S"): 0.2, ("D", "X"): 0.1}, 0.5, cat.labels)
    near_r = dmat({("R", "S"): 0.2, ("R", "X"): 0.1, ("S", "X"): 0.25}, 0.5, cat.labels)
    assert discover(cat, "R", "S", "D", near_d, "E").disc == ("X",)
    assert discover(cat, "R", "S", "D", near_r, "E") is None
    _, f = trio_tests(cat, Trio("R", "S", "D", True), block_size(cat), near_r)
    assert any(t.startswith("WARNING:") and "skipped" in t and "X" in t for _, t in f.items())

def test_resolution_warning(tmp_path, toy_fastas):
    cat = simulate_run(tmp_path, seed=1, p_missing={"S": 0.6}, fasta_dir=toy_fastas).load()
    rows, f = _trio_tests(cat, Trio("R", "S", "D", True))
    assert _row(rows, "resolution", "all", "resolved_R").value == pytest.approx(0.85, abs=0.03)   # replica 0.838
    assert _row(rows, "resolution", "all", "resolved_S").value == pytest.approx(0.40, abs=0.03)   # replica 0.408
    assert any(t.startswith("WARNING:") and "resolved" in t for _, t in f.items())

def test_nested_collapse(tmp_path, toy_fastas):
    loci = []
    for h in range(10):                              # 10 RD hosts in D, each with 3 nested RD children
        host = len(loci)
        loci += [loc(50_000 * (h + 1), "R:P S:E D:P* O:E", length=6000)]
        loci += [loc(50_000 * (h + 1) + 1000 * (j + 1), "R:P S:E D:P* O:E", parent=host) for j in range(3)]
    host = len(loci)                                 # a host present in R, S and D with 3 RD children
    loci += [loc(100_000, "R:P S:P D:P* O:E", seqid="chr2", length=6000)]
    loci += [loc(101_000 + 1000 * j, "R:P S:E D:P* O:E", seqid="chr2", parent=host) for j in range(3)]
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    rows, _ = _trio_tests(cat, Trio("R", "S", "D", True))
    assert _row(rows, "D_pav", "all", "n_RD").value == 43
    assert _row(rows, "D_pav", "nested_collapsed", "n_RD").value == 11      # 10 + 1; the old outermost-row rule gave 10

def test_age_strata_without_k(tmp_path, toy_fastas):   # Review Focus 2
    cat = simulate_run(tmp_path, seed=1, k_known=False, fasta_dir=toy_fastas).load()
    rows, f = _trio_tests(cat, Trio("R", "S", "D", True))
    assert not [r for r in rows if r.stratum in AGE_LABELS or r.test == "D_pav_gradient"]
    assert sum("age strata skipped" in t for _, t in f.items()) == 1

def test_outgroup_mostly_missing(tmp_path, toy_fastas):   # Review Focus 3
    cat = simulate_run(tmp_path, seed=1, p_missing={"O": 0.8}, fasta_dir=toy_fastas).load()
    rows, f = _trio_tests(cat, Trio("R", "S", "D", True))
    removed = _row(rows, "outgroup_filter", "all", "removed_frac").value
    assert removed == pytest.approx(0.85, abs=0.03)                                # replica 0.856
    assert any(r.test == "D_pav" and r.stratum == "no_outgroup_filter" for r in rows)
    assert any(f"{removed:.2f}" in t for _, t in f.items())

def test_second_donors_and_f4(tmp_path, toy_fastas):
    genomes = [GENOMES[0], GENOMES[1], GENOMES[2], ("D2", "taxD", None, True), GENOMES[3]]
    loci = ([loc(1000 * i, "R:P S:E D:P* D2:P O:E") for i in range(1, 4)]
            + [loc(5000, "R:E S:P D:P* D2:E O:E")]
            + [loc(6000 + 1000 * i, "R:E S:E D:P* D2:P O:E") for i in range(2)])
    cat = write_run(tmp_path, loci, genomes=genomes, fasta_dir=toy_fastas).load()
    trio, dist = Trio("R", "S", "D", True), dmat({("D", "D2"): 0.1}, 0.3, cat.labels)
    assert second_donors(cat, trio, dist) == ["D2"]
    assert second_donors(cat, trio, dmat({("D", "D2"): 0.1, ("D2", "S"): 0.05}, 0.3, cat.labels)) == []
    got = {r.statistic: r.value for r in f4_ratio(cat, trio, "D2", block_size(cat), dist)}
    assert (got["num"], got["den"], got["f"], got["resolved_D2"]) == (2, 4, 0.5, 1.0)
```

`_row` reads stratum `all` for the rows that carry no stratum of their own (`roles`, `resolution`,
`outgroup_filter`): those rows are written with stratum `all`.

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_trio.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** the tests. Expected: PASS. A seeded test that fails follows the Test conventions (investigate, never
  tune).
- [ ] **Step 5: Commit.** `"Add trio roles, D_pav with age strata, nested collapse and f4-ratio"`
---

