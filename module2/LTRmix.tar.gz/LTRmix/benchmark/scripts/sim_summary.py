#!/usr/bin/env python3
"""Summarize the simulation grid (eval/*.json): null calibration (signed toward the true recipient B, so a test's
null Z should be ~N(0,1)), power by admixture fraction and time, fraction estimates vs truth, painting accuracy,
and the effect of one-sided annotation dropout. Writes sim_summary.tsv tables."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import glob
import json
import sys

import numpy as np
import pandas as pd

TESTS = ["D_kmer", "D_ins", "D3_triples", "D_self_outgroup"]


def load(d):
    rows = []
    for f in glob.glob(f"{d}/eval/*.json"):
        s = open(f).read().strip()
        if s:
            rows.append(json.loads(s))
    x = pd.DataFrame(rows)
    for t in TESTS:
        if f"{t}_Z" in x:
            # the tool orients D toward the sister it calls recipient; re-sign toward the true recipient B
            x[f"{t}_ZB"] = np.where(x.recipient_called == "B", x[f"{t}_Z"], -x[f"{t}_Z"])
    x["kind"] = np.where(x.sim.str.startswith("null"), "null", np.where(x.sim.str.startswith("fn"), "dropout", "power"))
    return x


def main():
    d = sys.argv[1] if len(sys.argv) > 1 else "."
    x = load(d)
    out = []
    for c in ("Dins_young", "Dins_old"):
        if c in x:
            x[c + "B"] = np.where(x.recipient_called == "B", x[c], -x[c])
    n = x[x.kind == "null"]
    print(f"== null (f = 0): {len(n)} independent replicates")
    if "Dins_youngB" in n:
        print(f"null D_ins young {n.Dins_youngB.mean():+.3f} (sd {n.Dins_youngB.std():.3f}), old {n.Dins_oldB.mean():+.3f}")
    for t in TESTS:
        z = n[f"{t}_ZB"].dropna()
        r = dict(table="null", test=t, n=len(z), mean_Z=z.mean(), sd_Z=z.std(), frac_absZ_gt3=(z.abs() > 3).mean(),
                 frac_absZ_gt2=(z.abs() > 2).mean())
        out.append(r)
        print(f"{t:16s} mean Z {r['mean_Z']:+.2f}  sd {r['sd_Z']:.2f}  |Z|>2 {r['frac_absZ_gt2']:.2f}  |Z|>3 {r['frac_absZ_gt3']:.2f}")
    for mode in ("ancestry", "recent"):
        c = f"{mode}_n_q05"
        if c in n:
            print(f"null: {mode} tracts at q<=0.05 per genome: mean {n[c].mean():.2f}, runs with any {(n[c] > 0).mean():.2f}; "
                  f"excess over decoy {n[f'{mode}_excess'].mean():+.3f}")
            out.append(dict(table="null_tracts", test=mode, n=len(n), mean_tracts_q05=n[c].mean(),
                            frac_runs_any=(n[c] > 0).mean(), mean_excess=n[f"{mode}_excess"].mean()))
    p = x[(x.kind == "power")]
    flips = p[~p.sisters_ok.astype(bool)]
    print(f"\n== power grid: {len(p)} runs; {len(flips)} recast the recipient as the donor's sister (realized "
          f"fractions {sorted(flips.true_frac.round(2).tolist())}); D |Z| in those runs "
          f"{sorted(flips.D_kmer_Z.abs().round(1).tolist())}")
    out.append(dict(table="flips", n=len(flips), realized=";".join(map(str, flips.true_frac.round(3))),
                    absZ=";".join(map(str, flips.D_kmer_Z.abs().round(1)))))
    p = p[p.sisters_ok.astype(bool)]
    cols = ["f", "Ta", "true_frac"] + [f"{t}_ZB" for t in TESTS] + ["Dins_youngB", "Dins_oldB", "f_low", "ancestry_excess", "recent_excess",
                                                                      "auc_ancestry", "auc_recent",
                                                                      "recent_bp_precision_q05", "recent_bp_recall_q05",
                                                                      "recent_n_called_q05", "ancestry_bp_precision_all",
                                                                      "ancestry_bp_recall_all"]
    cols = [c for c in cols if c in p]
    g = p[cols].groupby(["Ta", "f"]).mean().round(3)
    with pd.option_context("display.width", 250, "display.max_columns", 40):
        print(g.to_string())
    for (ta, f), r in g.iterrows():
        out.append(dict(table="power", Ta=ta, f=f, **r.to_dict()))
    for t in TESTS:
        pw = p.groupby(["Ta", "f"])[f"{t}_ZB"].apply(lambda z: (z > 3).mean()).rename(f"power_{t}")
        print(pw.unstack(0).round(2).to_string())
    dr = x[x.kind == "dropout"]
    if len(dr):
        print(f"\n== one-sided annotation dropout in B: {len(dr)} runs")
        dr = dr.assign(fnB=dr.fn.map(lambda v: v[0]), sisters=dr.sisters_ok.astype(bool))
        gg = dr.groupby(["fnB", "f"]).agg(**{f"{t}_ZB": (f"{t}_ZB", "mean") for t in TESTS},
                                           f_low=("f_low", "mean"), sisters_ok=("sisters", "mean")).round(2)
        print(gg.to_string())
        for (fb, f), r in gg.iterrows():
            out.append(dict(table="dropout", fnB=fb, f=f, **r.to_dict()))
    pd.DataFrame(out).to_csv(f"{d}/sim_summary.tsv", sep="\t", index=False)


if __name__ == "__main__":
    main()
