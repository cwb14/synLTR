### Task 8: Mechanisms and missingness (DESIGN 7.8)

**Files:**
- Create: `src/ltrpav/analysis/mechanisms.py`, `tests/test_mechanisms.py`

**Interfaces:**
- Consumes:
  - `Catalog`, `Node`, `age_bin`, `read_elements`, `CALL_COLUMNS`;
  - `MIN_SEG`, `SLOP_TSD_MULT`, `TSD_DEFAULT` (engine constants, read only), `samples.PAIR_SEP`.
- Produces:

```python
MECH_COLUMNS = ("table", "scope", "superfamily", "family", "age_bin", "metric", "value")
def pair_calls(path: Path) -> Iterator[dict[str, str]]     # streamed; fails on a header that is not CALL_COLUMNS
def o_kind(dl: int, dr: int, tsd: str | None) -> str       # "O_site" if |dl| <= w and |dr| <= w, else "O_complex"
def d_kind(dl: int, dr: int, tsd: str | None) -> str       # "D_inside" if dl < -w or dr < -w, else "D_beyond"
                                                           # w = SLOP_TSD_MULT * L (L = len(tsd) or TSD_DEFAULT)
def pair_mechanisms(cat: Catalog, a: str, b: str) -> tuple[list[tuple], list[StatRow]]
def dollo(cat: Catalog, tree: Node) -> tuple[list[tuple], list[StatRow]]
def mechanisms(cat: Catalog, tree: Node | None) -> tuple[list[tuple], list[StatRow], Findings]
def write_mechanisms(rows: list[tuple], path: Path) -> None   # sorted by (table, scope, superfamily, family, age_bin, metric)
```

Rules. Each ordered pair file `pairs/<A>__<B>.calls.tsv.gz` is read once. A call's age bin and family come from A's element
(`work/elements/<A>.tsv`). Age bins are labeled with `AGE_LABELS`, plus `all`.

- **`d_kind`:** a gap end lying more than w inside the element means B keeps fewer than `MIN_SEG` aligned bases of it
  but still some of its sequence, so B carried the element: `D_inside`, a derived absence. Otherwise `D_beyond`.
- **table `states`:**
  - metrics `n_P n_S n_T n_E n_D_inside n_D_beyond n_O_site n_O_complex n_G n_U`;
  - per (superfamily, family, age_bin), with rollups `all` for family, superfamily and age.
  - O is split with `o_kind` (the brief: O includes complex events; `dl`, `dr`, `b_ins` separate them); D with `d_kind`.
- **table `absence`** (per age bin and `all`; superfamily and family `all`): `n_absent` (E + D + O), then `frac_E`,
  `frac_D_inside`, `frac_D_beyond`, `frac_O_site`, `frac_O_complex`.
  - `frac_E` is ancestral, shown: an empty site, with no precise excision.
  - `frac_D_inside` is derived, shown.
  - The other three are not determined (DESIGN 5.4: D and O say nothing about whether the insertion happened): a deletion
    in B, an A-only insertion of an unannotated unit, an independent insertion at the site, or a replacement.
- **table `events`** (scope `A>B`, superfamily, family and age `all`; absence events from `parent` links and flags):
  - an E event is an E call without `host_empty`, together with its descendants that are E with `host_empty`;
  - a D event is a D call without `inherit`, together with its descendants that are D with `inherit`;
  - E calls flagged `adjacent` within one `wid` form one event, and D calls likewise.

  An event with more than one element, or an `adjacent` one, is multi-element:
  - E: a nested cluster inserted as a unit;
  - D: a multi-element deletion, whose own origin stays open as for any D.

  Metrics: `n_E_single n_E_cluster n_E_cluster_elements n_D_single n_D_multi n_D_multi_elements`.
- **table `missingness`:** `U_<reason>` and `G`, as fractions of the pair's calls.
- **`dollo`** (needs an outgroup and the rooted tree; otherwise one "skipped" line), over merged states:
  - present = genomes with `cls == 1`; the clade is their MRCA.
  - An E genome under the clade makes the locus incongruent: counted, not placed.
  - Otherwise the insertion goes on the branch above the clade (`before_root` at the root).
  - For each of S, T and D: one event per maximal subclade of the clade whose genomes are all that state or missing,
    with at least one of the state. "Missing" is D/O/G/U for S and T events, and O/G/U for D events. A D genome outside
    the clade is not placed: it is missing.
  - Branch label = its leaves joined by `+` in sheet order.
  - Table `branches`: per (branch, superfamily) and `all`, `n_insertion n_solo n_truncation n_deletion`. Scope
    `incongruent` (superfamily `all`): `n_loci`.
- **Stats rows** mirror the absence, event and branch tables: tests `mechanisms`, `absence_events`, `branches`,
  `missingness`.
- **Findings:**
  - per pair and by age: "absences not shown ancestral = 1 - frac_E (an upper bound on derived absences); shown
    derived = frac_D_inside (a lower bound)";
  - the multi-element split (clusters against deletions);
  - insertions and losses per branch.

- [ ] **Step 1: Write the failing tests**

```python
def _table(rows, table, scope):
    """{(superfamily, family, age_bin, metric): value} of one table and scope."""
    return {(sf, fam, age, m): v for t, sc, sf, fam, age, m, v in rows if (t, sc) == (table, scope)}

def test_o_kind_and_d_kind():
    assert o_kind(3, -2, "ACGTA") == "O_site" and o_kind(400, 0, "ACGTA") == "O_complex"
    assert o_kind(10, 10, None) == "O_site" and o_kind(11, 0, None) == "O_complex"    # TSD_DEFAULT 5 -> w 10
    assert d_kind(-12, 0, "ACGTA") == "D_inside" and d_kind(300, 0, "ACGTA") == "D_beyond"

def test_state_counts_by_family_age(tmp_path, toy_fastas):
    loci = [loc(1000, "R:P* S:E D:E O:E", k=0.0), loc(2000, "R:P* S:E D:E O:E", k=0.02),
            loc(3000, "R:P* S:D D:E O:E", k=0.02, family="famB", superfamily="Copia", evidence={"S": (300, 0, 0)}),
            loc(4000, "R:P* S:O D:E O:E", k=0.004, family="famB", superfamily="Copia", evidence={"S": (2, -1, 500)}),
            loc(5000, "R:P* S:P D:E O:E", k=0.0)]
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    st = _table(mechanisms(cat, None)[0], "states", "R>S")
    assert st[("Gypsy", "famA", "K=0", "n_E")] == 1 and st[("Gypsy", "famA", "K>=0.01", "n_E")] == 1
    assert st[("Copia", "famB", "K>=0.01", "n_D_beyond")] == 1 and st[("Copia", "famB", "0<K<0.01", "n_O_site")] == 1
    assert st[("all", "all", "all", "n_E")] == 2 and st[("all", "all", "all", "n_P")] == 1
    assert st[("Gypsy", "all", "K=0", "n_P")] == 1

def test_absence_fractions(tmp_path, toy_fastas):
    specs = ([("E", (0, 0, 0))] * 4 + [("D", (-12, 0, 0))] + [("D", (300, 0, 0))] * 2
             + [("O", (2, -1, 500))] + [("O", (400, 0, 900))] * 2)
    loci = [loc(1000 * (i + 1), f"R:P* S:{s} D:E O:E", evidence={"S": ev}) for i, (s, ev) in enumerate(specs)]
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    ab = _table(mechanisms(cat, None)[0], "absence", "R>S")
    got = [ab[("all", "all", "all", m)] for m in ("n_absent", "frac_E", "frac_D_inside", "frac_D_beyond",
                                                  "frac_O_site", "frac_O_complex")]
    assert got == [10, 0.4, 0.1, 0.2, 0.1, 0.2]

def test_absence_events(tmp_path, toy_fastas):
    loci = [loc(10_000, "R:P* S:E D:E O:E", length=6000),
            loc(11_000, "R:P* S:E D:E O:E", parent=0, flags={"S": ["host_empty"]}),
            loc(12_000, "R:P* S:E D:E O:E", parent=0, flags={"S": ["host_empty"]}),
            loc(30_000, "R:P* S:D D:E O:E", length=6000),
            loc(31_000, "R:P* S:D D:E O:E", parent=3, flags={"S": ["inherit"]}),
            loc(50_000, "R:P* S:E D:E O:E"),
            loc(60_000, "R:P* S:E D:E O:E", flags={"S": ["adjacent"]}, wid=7),
            loc(60_400, "R:P* S:E D:E O:E", flags={"S": ["adjacent"]}, wid=7)]
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    ev = {m: v for (sf, fam, age, m), v in _table(mechanisms(cat, None)[0], "events", "R>S").items()}
    assert (ev["n_E_single"], ev["n_E_cluster"], ev["n_E_cluster_elements"]) == (1, 2, 5)
    assert (ev["n_D_single"], ev["n_D_multi"], ev["n_D_multi_elements"]) == (0, 1, 2)

def test_dollo_branches(tmp_path, toy_fastas):
    loci = [loc(1000, "R:P* S:P D:E O:E"),      # insertion on R+S
            loc(2000, "R:S S:P* D:E O:E"),      # insertion on R+S, solo on R
            loc(3000, "R:D S:P* D:P O:E"),      # insertion on R+S+D, deletion on R
            loc(4000, "R:D S:P* D:E O:E"),      # insertion on S; R outside the clade: missing, no deletion
            loc(5000, "R:P* S:E D:P O:E")]      # incongruent: S E inside the R+S+D clade
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    tree = Node(None, (Node("O"), Node(None, (Node(None, (Node("R"), Node("S"))), Node("D")))))
    rows, _ = dollo(cat, tree)
    br = lambda scope, m: _table(rows, "branches", scope).get(("all", "all", "all", m), 0)
    assert (br("R+S", "n_insertion"), br("R+S+D", "n_insertion"), br("S", "n_insertion")) == (2, 1, 1)
    assert (br("R", "n_solo"), br("R", "n_deletion"), br("incongruent", "n_loci")) == (1, 1, 1)

def test_missingness(tmp_path, toy_fastas):
    loci = ([loc(1000 * (i + 1), "R:P* S:U D:E O:E") for i in range(3)]
            + [loc(5000, "R:P* S:G D:E O:E"), loc(6000, "R:P* S:E D:E O:E")])
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    mi = _table(mechanisms(cat, None)[0], "missingness", "R>S")
    assert mi[("all", "all", "all", "U_no_anchor")] == pytest.approx(3 / 5) and mi[("all", "all", "all", "G")] == pytest.approx(1 / 5)

def test_write_mechanisms(tmp_path):
    rows = [("states", "R>S", "all", "all", "all", "n_E", 2), ("absence", "R>S", "all", "all", "K=0", "frac_E", 0.5)]
    write_mechanisms(rows, tmp_path / "m.tsv")
    lines = (tmp_path / "m.tsv").read_text().splitlines()
    assert lines[0].split("\t") == list(MECH_COLUMNS)
    assert lines[1:] == ["absence\tR>S\tall\tall\tK=0\tfrac_E\t0.5", "states\tR>S\tall\tall\tall\tn_E\t2"]
```

Missingness, event and branch rows carry superfamily, family and age `all`.

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_mechanisms.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** the tests. Expected: PASS.
- [ ] **Step 5: Commit.** `"Add mechanisms: states by family and age, absence events, Dollo placement"`
---

