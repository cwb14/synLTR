#!/usr/bin/env python3
"""Coalescent + LTR-RT simulation for benchmarking ltrmix: haploid genomes with known local ancestry.

Demography (generations = years): ancestral A splits at T2 into P (parviglumis) and M (mexicana); maize B derives
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
from P at T1. Optional pulse M -> B at Ta with proportion f (msprime mass migration, recorded for truth).
Samples: one haploid genome each of B, P, M, plus M2 (a second mexicana) when --m2.

LTR-RT process on the real local trees: insertions arise on branches at rate lam per bp per generation (infinite
sites: one 'mutation' per insertion), so carriers are the samples below its branch; each lineage loses the element at
rate delta per generation (solo-LTR formation, deletion). Sequences evolve on the same tree: the insertion copy
(family master + copy noise; identical LTRs at insertion) mutates at mu along every branch from the insertion
point to each sample, so LTR-LTR and ortholog divergences come from one genealogy. Annotation dropout: each element
is missed with probability fn[genome].

Output in OUTDIR: <G>.fa, <G>.tsv (ltrmix generic input), truth_B.bed (B segments of M ancestry), params.json.
"""
import argparse
import json
import os

import msprime
import numpy as np

ACGT = np.frombuffer(b"ACGT", np.uint8)


def mutate(s, d, rng):
    n = rng.poisson(len(s) * d)
    if n:
        p = rng.integers(0, len(s), n)
        s = s.copy()
        s[p] = (s[p] + rng.integers(1, 4, n).astype(np.uint8)) % 4
    return s


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--out", required=True)
    ap.add_argument("--f", type=float, default=0.18, help="M -> B admixture proportion")
    ap.add_argument("--Ta", type=float, default=5000, help="admixture time (generations)")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--nchrom", type=int, default=10)
    ap.add_argument("--chrom-len", type=float, default=20e6)
    ap.add_argument("--fn", default="0,0,0", help="annotation dropout for B,P,M (comma)")
    ap.add_argument("--m2", action="store_true", help="also output a second mexicana genome M2")
    ap.add_argument("--lam", type=float, default=None, help="insertion rate per bp per generation")
    a = ap.parse_args()
    P = dict(NeA=150_000, NeP=100_000, NeM=70_000, NeB=30_000, T1=9_000, T2=60_000, mu=3e-8, r=1e-8,
             r_peri=1e-9, peri=(0.3, 0.7), delta=1.0 / 900_000, elen=2400, ltr=300, nfam=40, copy_noise=0.005, T_MAX=2_000_000,
             lam=a.lam if a.lam else 1.2e-10, f=a.f, Ta=a.Ta, seed=a.seed, nchrom=a.nchrom, chrom_len=a.chrom_len,
             fn=[float(x) for x in a.fn.split(",")], m2=a.m2)
    os.makedirs(a.out, exist_ok=True)
    rng = np.random.default_rng(a.seed)
    dem = msprime.Demography()
    for nm, ne in (("B", P["NeB"]), ("P", P["NeP"]), ("M", P["NeM"]), ("A", P["NeA"])):
        # P is extant: msprime would otherwise treat the ancestral population of the B split as inactive until T1
        # and sample it 9,000 generations in the past (a shorter terminal branch: biased nulls)
        dem.add_population(name=nm, initial_size=ne, initially_active=(nm == "P") or None)
    if a.f > 0:
        dem.add_mass_migration(time=a.Ta, source="B", dest="M", proportion=a.f)
    dem.add_population_split(time=P["T1"], derived=["B"], ancestral="P")
    dem.add_population_split(time=P["T2"], derived=["P", "M"], ancestral="A")
    dem.sort_events()
    # one haploid genome (assembly) per taxon, sampled from diploid populations (coalescent time scale 2N)
    samples = [msprime.SampleSet(1, population="B", ploidy=1), msprime.SampleSet(1, population="P", ploidy=1),
               msprime.SampleSet(2 if a.m2 else 1, population="M", ploidy=1)]
    names = ["B", "P", "M"] + (["M2"] if a.m2 else [])
    fams = [rng.integers(0, 4, P["elen"]).astype(np.uint8) for _ in range(P["nfam"])]
    recs = {g: [] for g in names}
    truth = []
    L = int(a.chrom_len)
    rmap = msprime.RateMap(position=[0, int(P["peri"][0] * L), int(P["peri"][1] * L), L],
                           rate=[P["r"], P["r_peri"], P["r"]])
    fn = dict(zip(["B", "P", "M"], P["fn"]))
    fn["M2"] = fn["M"]
    for c in range(1, a.nchrom + 1):
        ts = msprime.sim_ancestry(samples=samples, demography=dem, ploidy=2, recombination_rate=rmap,
                                  record_migrations=True, random_seed=int(rng.integers(1, 2**31)))
        assert all(ts.node(s_).time == 0 for s_ in ts.samples()), "all genomes must be sampled at time 0"
        # sample node -> genome name
        node_name = {}
        for s in ts.samples():
            pop = ts.population(ts.node(s).population).metadata["name"]
            node_name[s] = pop if pop != "M" or "M" not in node_name.values() else "M2"
        bnode = [s for s, g in node_name.items() if g == "B"][0]
        # truth: B segments that migrated to M at Ta (backward); only B's lineages are in B before T1
        mig = ts.tables.migrations
        popB = [p.id for p in ts.populations() if p.metadata["name"] == "B"][0]
        popM = [p.id for p in ts.populations() if p.metadata["name"] == "M"][0]
        segs = sorted((m.left, m.right) for m in mig if m.source == popB and m.dest == popM)
        for l0, r0 in segs:
            truth.append((c, int(l0), int(r0)))
        # insertions: Poisson along the tree sequence (rate lam per bp per generation)
        mts = msprime.sim_mutations(ts, rate=P["lam"], model=msprime.BinaryMutationModel(), discrete_genome=False,
                                    random_seed=int(rng.integers(1, 2**31)))
        for tree in mts.trees():
            # insertions above the local root (older than the samples' common ancestor: carried by all, minus
            # losses): Poisson on a root stem from the root to T_MAX at the same rate lam
            evs = [(site.mutations[0].node, site.mutations[0].time, int(site.position)) for site in tree.sites()]
            root = tree.root
            span = tree.interval.right - tree.interval.left
            stem = max(P["T_MAX"] - tree.time(root), 0)
            for _ in range(rng.poisson(P["lam"] * span * stem)):
                evs.append((root, float(tree.time(root) + rng.uniform(0, stem)),
                            int(rng.uniform(tree.interval.left, tree.interval.right))))
            for node, tm, pos in evs:
                fam = int(rng.integers(P["nfam"]))
                base = mutate(fams[fam], P["copy_noise"], rng)
                base[-P["ltr"]:] = base[:P["ltr"]]          # identical LTRs at insertion
                # stem from insertion time down to 'node', then recurse; losses at rate delta per lineage
                out = {}
                stack = [(node, base, tm - tree.time(node))]
                while stack:
                    nd, seq, blen = stack.pop()
                    if rng.random() < 1 - np.exp(-P["delta"] * blen):
                        continue
                    seq = mutate(seq, P["mu"] * blen, rng)
                    if tree.is_sample(nd):
                        out[node_name[nd]] = seq
                        continue
                    for ch in tree.children(nd):
                        stack.append((ch, seq, tree.time(nd) - tree.time(ch)))
                if not out:
                    continue
                tsd = "".join("ACGT"[x] for x in rng.integers(0, 4, 5))
                for g, seq in out.items():
                    if rng.random() < fn[g]:
                        continue
                    l5, l3 = seq[:P["ltr"]], seq[-P["ltr"]:]
                    pdist = float((l5 != l3).mean())
                    k2p = -0.75 * np.log(1 - 4 * pdist / 3) if pdist < 0.7 else np.nan
                    recs[g].append((c, pos, seq, tsd, k2p, fam, tm))
        print(f"chr{c}: {ts.num_trees} trees, {mts.num_sites} insertions, B introgressed "
              f"{sum(r - l for l, r in segs) / L:.3f}", flush=True)
    # write libraries (M coordinates: +50 kb offset and an inversion on chr3 to exercise the chain caller)
    inv = (3, int(0.1 * L), int(0.25 * L))
    for g in names:
        with open(os.path.join(a.out, f"{g}.fa"), "w") as f1, open(os.path.join(a.out, f"{g}.tsv"), "w") as f2:
            f2.write("seq_id\tk2p\ttsd\tstrand\tltr5_len\tltr3_len\tins_time\n")
            for (c, pos, seq, tsd, k2p, fam, tm) in sorted(recs[g], key=lambda r: (r[0], r[1])):
                p2 = pos
                if g in ("M", "M2"):
                    if c == inv[0] and inv[1] <= pos <= inv[2]:
                        p2 = inv[1] + inv[2] - pos
                    p2 += 50_000
                name = f"{g}_chr{c}:{p2 + 1}-{p2 + len(seq)}#LTR/Gypsy/fam{fam}"
                f1.write(f">{name}\n{bytes(ACGT[seq]).decode()}\n")
                f2.write(f"{name}\t{k2p:.6f}\t{tsd}\t+\t{P['ltr']}\t{P['ltr']}\t{tm:.0f}\n")
    with open(os.path.join(a.out, "truth_B.bed"), "w") as f:
        for c, l0, r0 in truth:
            f.write(f"B_chr{c}\t{l0}\t{r0}\n")
    P["peri"] = list(P["peri"])
    P["n_elements"] = {g: len(v) for g, v in recs.items()}
    P["true_frac_B"] = sum(r - l for _, l, r in truth) / (a.nchrom * L)
    json.dump(P, open(os.path.join(a.out, "params.json"), "w"), indent=1)
    print(json.dumps({"n_elements": P["n_elements"], "true_frac_B": P["true_frac_B"]}))


if __name__ == "__main__":
    main()
