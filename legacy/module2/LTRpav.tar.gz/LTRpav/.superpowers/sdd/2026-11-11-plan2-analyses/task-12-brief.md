### Task 12: Preliminary run on B73, TIL18, TIL01 + Zd and comparison with the papers

**Files** (outside the repo): `benchmark_pav/main3/{run_analyses.sh, analyses.log, analyses.done, compare_papers.py,
prelim_papers.tsv, PRELIM.md}`, `benchmark_pav/dead_ends.md`, `/data2/chris/maize_introgression/memo_ltrpav.md`.
**Repo:** `docs/DESIGN.md` (section 12: Plan 2 outcome, 3-5 lines).

The genomes, by their main3 sheet labels (the labels used everywhere in this task; `B73v5` is only the LTRmix/LTRquest
element-name and FASTA prefix):
- B73, maize;
- TIL18, *Z. mays* ssp. *mexicana*;
- TIL01, ssp. *parviglumis*;
- Zd, the *Z. diploperennis* outgroup: genotype-only, with no annotation.

This follows DESIGN and Plan 1's sheet. Roles are inferred, never set, and checking them against the sheet's groups is the
first result. Every verdict here is **preliminary**: DESIGN 10.3's bars, the simulated null of D_pav and the controls
belong to Plan 3. Verdicts read "PASS (prelim)" or "MISS (prelim)".

main3 was genotyped by engine 7d71073. The analysis commands read it as data and run no engine-fingerprint check, so
nothing is re-genotyped. Do not run `ltrpav run` or `ltrpav-merge` there.

- [ ] **Step 1: Preconditions.**
  - `main3/manifest.json` exists.
  - `main3/samples.tsv` has labels B73, TIL18, TIL01 and Zd, with groups `maize`, `mexicana` (TIL18), `parviglumis`
    (TIL01) and `diploperennis` (Zd, role `outgroup`).
  - `pgrep -af ltrpav` shows no job.
  - `python -m pytest -W error -m "not slow"` passes on `plan2-analyses`.

- [ ] **Step 2: Launch detached.** Identity alignments may pass 15 min.
  - `run_analyses.sh` (`set -euo pipefail`, `export NUMPY_MADVISE_HUGEPAGE=0`) runs, in order:
    `ltrpav-stats --samples samples.tsv --outdir . --identity --threads 32`, then `ltrpav-paint --samples samples.tsv
    --outdir .`, then `ltrpav-plot --samples samples.tsv --outdir .`, then `touch analyses.done`.
  - Launch from `main3/`: `setsid -f nohup mamba run -n ltrpav bash run_analyses.sh > analyses.log 2>&1 < /dev/null`.
  - Verify with `pgrep -af run_analyses.sh`, which lists the `mamba run` leader and its bash child. Check the leader with
    `ps -o pid,ppid,sid,cmd -p <pid>`. Expected: SID = PID and PPID 1. The child shares the SID, with the leader as
    PPID.

- [ ] **Step 3: Check outputs.**
  - `analyses.done` exists.
  - `findings.txt`'s Run, Relationships and Trio tests sections.
  - `stats.tsv` holds the rows the comparison reads.

- [ ] **Step 4: Write `compare_papers.py`.**
  - Constraints:
    - numpy, scipy and csv only (no new environment), plus `ltrpav.analysis` (`load_catalog`, `discover`) for per-locus
      recounts;
    - `NUMPY_MADVISE_HUGEPAGE=0`;
    - reads the run's files and the truth files in `/data2/chris/maize_introgression/benchmark/truth/`
      (`elai_summary.v5.tsv` column `B73.amp`, -999 = missing, dosage 0-2; `hf.v5.bed`; `loci.v5.tsv`);
    - B73's seqids map to ELAI chromosomes by their trailing `chr<N>`;
    - modeled on LTRmix `eval_real.py`.
  - **One scoring code for both tools.** LTRmix's files from
    `/data2/chris/maize_introgression/LTRmix/benchmark/results/main3/` go through the same window, AUROC, tract-recall,
    named-locus and high-frequency functions as LTRpav's, with the same weights, 1000 shifts and seeds:
    - `elements.B73v5.tsv.gz`: class, `post_ancestry_TIL18`, span;
    - `tracts.B73v5.bed` (recent mode) and `ancestry.B73v5.bed` (ancestry mode).

    LTRmix's `benchmark_real.tsv` is a cross-check only. Every row names LTRmix's HMM mode: ancestry for posteriors,
    windows and AUROC; both modes for tracts. Every window, chromosome and high-frequency mean is computed both
    unweighted and length-weighted, for both tools.
  - It writes `prelim_papers.tsv` with columns `section item ltrpav ltrmix bar verdict note`, one row per item:
    1. **Roles:** sister pair, donor and recipient against the sheet's groups. Expected: sisters B73 + TIL01
       (*parviglumis*), donor TIL18 (*mexicana*), recipient B73.
    2. **Admixture in B73** (Yang): D_pav `all`, bar D > 0 and Z > 3. Beside it:
       - the checks `high_tier`, `nested_collapsed` and `no_outgroup_filter`;
       - LTRmix `D_ins` (+0.1949, Z 7.2), placed beside the `no_outgroup_filter` stratum since LTRmix uses no
         outgroup. A note says that LTRmix's `D_ins` needs the sisters' own annotation (ABBA on R's elements, BABA on
         S's), so it is not blind to the 1.08 completeness ratio.
    3. **Gene flow, not lineage sorting** (Yang): D_pav by age bin and `dD` with its Z, reported against "excess
       concentrated in young insertions".
       - For the side-by-side, LTRpav's counts are re-binned into LTRmix's right-closed bins (K = 0, 0 < K <= 0.01,
         K > 0.01). A K = 0.01 locus cannot be moved out of LTRmix's middle bin, so the comparison goes that way.
       - `compare_papers.py` recounts LTRpav's D_pav rows per locus (`load_catalog`, `discover(..., "E")`, the K of each
         row's discovering copy) into those bins.
       - LTRmix's own counts per bin, from its `stats.tsv` `D_ins_by_age` rows (`nA`, `nB`), summed over its finer bins:

       | bin | LTRmix D | counts |
       |---|---|---|
       | K = 0 | +0.506 | 122 vs 40 |
       | 0 < K <= 0.01 | +0.404 | 2,001 vs 850 |
       | K > 0.01 | +0.153 | 8,795 vs 6,467 |
       | gradient | dD +0.354 | — |

    4. **Amount:** painting `posterior_mean` (unweighted and length-weighted), `decoy_posterior_mean` and `excess`,
       reported beside the B73 ELAI mean dosage/2 (0.1695) and Yang's 15-25%. Not an estimate (no second donor in
       main3).
    5. **Chromosomes 5, 8, 9 depleted** (Yang): over B73 seqids ending `chr1`..`chr10` only (`paint_seqid` also holds
       scaffolds), the three lowest by `posterior_mean` and by `class_share`, against {chr5, chr8, chr9}. An exact match
       has p = 1/120. Also the Spearman correlation with per-chromosome ELAI means.
    6. **Ancestry along the genome** (Yang): windows of 0.1, 0.5, 1, 2, 5 and 10 Mb.
       - Window means of the B73 posterior (rows with donor TIL18), and of the class share, against window ELAI means
         (>= 5 SNPs).
       - Spearman r; p from 1000 per-chromosome circular shifts (seed 1).
       - Bar: p < 0.01 at >= 1 Mb.
    7. **Tract scale** (Yang: 80% of tracts < 9.1 kb):
       - element AUROC of the posterior: ELAI dosage within ±20 kb (>= 3 SNPs), >= 1.0 and >= 1.5 against <= 0.2;
       - tract recall by ELAI-run length (dosage > 1: < 10 kb, 10-100 kb, 100-500 kb, >= 500 kb), for all tracts and
         q <= 0.05;
       - the ELAI dosage inside called tracts against the whole genome;
       - the resolution: `spacing_median`, `spacing_mean`, both shortest-callable bounds (LTRmix: 25 kb median
         spacing);
       - like with like: LTRpav's `mean_tract_bp` (its L, the switch scale) beside LTRmix's `mean_tract_bp` (197 kb,
         its L under the same name). LTRpav's `mean_donor_run_bp` (L/(1 - pi)) is reported on its own line.
    8. **Named loci** (`loci.v5.tsv`, ±50 kb and ±200 kb): classes, max posterior, tracts and q. Hit or miss against
       the expectations: ZmPRR37a *mexicana*; HPC1 not; ZmLPCAT1 not called; cob-weight locus intermediate.
    9. **52 high-frequency regions** (Yang): mean posterior of loci within 50 kb against outside; 1000 circular shifts of
       the regions per chromosome (seed 2); bar p < 0.01.
    10. **Inversions:**
        - Inv4m (B73 chr4:172,883,881-188,131,462, v5) in B73~TIL18;
        - Inv1n (chr1 ~65-115 Mb, approximate v2 coordinates as in LTRmix) in B73~TIL01;
        - the blocks found, with their `n_discordant` and the distances of their breakpoint intervals to the published
          ends.
    11. **Outgroup error-rate upper bound**, per ingroup genome. `compare_papers.py` computes it from the catalog itself
        (ingroup E at loci Zd carries, counted from the discoverers' own calls as Task 3 does, decision 18) and checks that it equals `stats.tsv`'s
        `outgroup_conflict`. It does not quote `QC.md`.
    12. **Mechanisms:** `frac_E`, `frac_D_inside`, `frac_O_inside`, `frac_D_inside_unshown`, `frac_O_inside_unshown`,
        `frac_D_beyond`, `frac_O_site` and `frac_O_complex` by age (Task 8 as built: an inside gap end is shown derived only
        when its remnant is shorter than MIN_SEG and holds no annotated child), with the bounds:
        - absences not shown ancestral, 1 - frac_E, an upper bound on derived absences;
        - shown derived, frac_D_inside + frac_O_inside, a lower bound (main3 B73->TIL18: 0.0129; K>=0.01: 0.0155).

        The literature reports absences of old elements as mostly deletions. Also the multi-element split (nested
        clusters against deletions; Munasinghe's 85.9% lead).
    13. **Identity layer:**
        - `s` (isolation fit, >= 200 sites) against LTRmix's isolation fit, 0.048% (block bootstrap 0.034-0.063%);
        - `s_mix` against LTRmix's mixture fit, 0.070%;
        - the younger-than-split counts and `sites_needed`;
        - `frac_RD_below` and `frac_SD_below` (LTRmix: 7.6% against 3.5%).
    14. **Direction:** skipped (one genome per taxon); say so.

  Rows with a DESIGN 10.3 bar get "PASS (prelim)" or "MISS (prelim)"; the others `reported`.

- [ ] **Step 5: Run** `export NUMPY_MADVISE_HUGEPAGE=0 && mamba run -n ltrpav python compare_papers.py`. Expected:
  `prelim_papers.tsv` with the 14 sections.

- [ ] **Step 6: Write `PRELIM.md`.**
  1. Open with the direct answer to the user's question: could LTR-RT PAVs have discovered the *mexicana* introgression
     into maize described by Yang et al. 2023 and Barnes et al. 2022? Answer genome-wide, then for gene flow against
     lineage sorting, then locally (with the resolution), in 3-5 lines.
  2. The table.
  3. What LTRpav adds over LTRmix: resolution, outgroup polarization, mechanisms.
  4. Caveats:
     - preliminary: no simulated null yet;
     - one genome per taxon;
     - B73 is a CLR assembly against PanAnd HiFi.
  5. The figure check: a reviewer who did not make the figure answers the seven lines from `overview.png` and the legend
     pages.
  6. End with, labeled "hypothesis: one trio, no simulated null" (CLAUDE.md):
     - the headline sentence about what genome-verified PAVs add over library-only inference;
     - the mechanism;
     - generality, tested or assumed;
     - predictions for other species.

  Each MISS gets a one-line entry in `benchmark_pav/dead_ends.md` plus an investigation note. A rule changes only for a
  reason independent of the papers, and is then rechecked.

- [ ] **Step 7: Memo and record.**
  - Append a Plan 2 section to `memo_ltrpav.md` (CLAUDE.md format): date, purpose, env versions, inputs, exact commands,
    outputs, gotchas, and the `claude --resume` name.
  - Add the outcome to DESIGN.md section 12.
  - Run `python -m pytest -W error -m "not slow"`.
  - Commit: `"Record Plan 2 analyses outcome"`.

- [ ] **Step 8: Hand off.** Report to the user:
  - the direct answer;
  - `prelim_papers.tsv`'s verdicts;
  - the figure path;
  - the misses;
  - what Plan 3 must settle:
    - the simulated null and power of D_pav and painting;
    - direction: Plan 3's simulations must include unequal Ne between taxa (the maize bottleneck), in both the null and
      the gene-flow runs;
    - the painting discovery variant;
    - the six-genome controls;
  - the user's confirmation of builder call 11 (the fallback-discovery ruling).

---

## Spec coverage

| DESIGN | Task |
|---|---|
| 7.1 discovery rules (discoverer's own calls), fallback (four-point), skip; outgroup E | 1 (`proj`, `pcls`), 3 (`discover`), 4; 6 (painting rule) |
| 7.1 resolution symmetry, annotation sensitivity | 2 (`resolution`); 4, 6, 7 (rows, WARNING); 3 (`run_summary` quotes qc.tsv) |
| 7.1 painting variant "any discovery" | 6 (`discovery="any"`; evaluated in Plan 3) |
| 7.2 sharing, shared-derived counts, distances, NJ tree, sister pair, outgroup set-aside, error bound | 3; roles in 4 |
| 7.3 D_pav with 5-Mb / 1/100 block jackknife; age split; nested collapse; f4-ratio | 2, 4 |
| 7.4 RD/RS HMM, EM, fitted tract length, posterior, tract rule, target-decoy q, spacing, shortest tract | 6 |
| 7.5 age gradient; youngest insertion per tract; identity layer, rate-free split, younger-than-split counts | 4, 6, 9 |
| 7.6 n(X->Y), age strata, jackknife, DFOIL-style, KKSC/4-LIST, exploratory | 7 (KKSC symmetry in 3) |
| 7.7 inverted blocks, breakpoint intervals, locus counts; painting loci flagged | 5, 6 |
| 7.8 counts by pair/family/age; O and D split by junctions; Dollo placement; multi-element split | 8 |
| 6 outputs: stats.tsv, findings.txt, tracts, posterior, inversions, mechanisms, overview + numbers | 2, 5, 6, 8, 10, 11 |
| 8 commands ltrpav-stats, -paint, -plot; run = everything; checkpoints (own fingerprint); warn-and-skip counts in findings | 3, 10, 11 |
| 10.1 outgroup impossible patterns as an error bound | 3, 12 |
| 11 item 3; brief's final real-data task | 12 |
