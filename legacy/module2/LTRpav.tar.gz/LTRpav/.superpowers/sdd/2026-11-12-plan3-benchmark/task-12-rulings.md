# Task 12: controller rulings
These bind as much as task-12-brief.md, and override it where the two conflict.

## R1. Launch now, not after the grid
- The genotyping queue starts while the simulator code (Tasks 2-9) is being written. The 32-thread budget is idle in
  that phase, and the queue (about 20 h) would otherwise come after the grid on the critical path.
- **Why it is safe:**
  - genotyping reads engine modules only, and their fingerprints at Plan 3's head are identical to 12d3e6c;
  - blocks are skipped by markers, and pairs by their own checkpoints, so a stopped queue resumes.
- **Cost if wrong:** contention with Task 8's pilot. R3 handles that.

## R2. Frozen code: snapshot 12d3e6c
- The repo's working tree is being edited by another implementer, so the queue never imports it.
- **Build the snapshot.** Create `$P/benchmark_pav/plan3/snap/12d3e6c/` with
  `git -C $P/LTRpav archive 12d3e6c | tar -x -C <that dir>`. 12d3e6c is Plan 2's reviewed head and the merged
  `plan1-engine`.
- **genotype_all.sh** exports `PYTHONPATH=$P/benchmark_pav/plan3/snap/12d3e6c/src`. Before the first block, it asserts
  that `python -c 'import ltrpav, sys; print(ltrpav.__file__)'` lies inside the snapshot.
  - It also asserts the same for the console scripts: run `ltrpav-genotype --help` under the same environment, and
    check where the module came from, for example through `python -c` with `ltrpav.cli`.
- **cap_variant.py** imports the snapshot as well.
- Task 8 later makes its own snapshot under `snap/<sha>/`. The layout is shared.

## R3. A pause point
- Before each block, genotype_all.sh checks for `queue.pause` in its directory. If the file exists, the script writes
  `paused before <block>` to the log and exits 0 without writing `queue.done`.
- Relaunching the same command resumes from the first block without a marker.
- The controller uses this if Task 8's pilot needs the threads.
- Test it on a dry stub: a `--dry-run` flag that prints each block's command, or a toy block. Do not test it by running
  real genotyping.

## R4. Where your work ends
- **Before launch:**
  - Steps 1-3 are done and their tests pass.
  - The annotations are prepared, with every expected count checked; give each mismatch with its reason.
  - The sheets are checked: every path exists, labels are unique, and groups and roles are as the brief gives them.
  - genotype_all.sh is written.
- **Launch (Step 4).**
  - Pre-flight:
    - `pgrep -af 'ltrpav|lastz|run_variant'` shows no job of this project;
    - record `uptime` and `free -g` in the memo;
    - snapshot `inputs/*.fai` (size, mtime, sha256).
  - Launch detached: `setsid -f nohup bash genotype_all.sh > queue.log 2>&1 < /dev/null`, from
    `$P/benchmark_pav/plan3/real/`.
  - Verify the PID: SID = PID and PPID 1.
- **Healthy-start check.** Watch for up to 15 minutes, with a Monitor until-loop and never a foreground sleep, until:
  - the six block's first directed pair has started;
  - its log shows anchor or alignment progress;
  - no error lines have appeared.

  Then return. The controller watches the rest of the queue.
- **memo.md:** in the CLAUDE.md memo format, with the exact commands, the snapshot and the launch.
- Leave a placeholder section, "Outcome (controller)", for the controller to fill in.

## R5. Limits
- **Read-only:** `$P/inputs`, `$P/run`, `$P/benchmark`, `$P/benchmark_pav/main3`, `$P/LTRmix`, and the LTRpav repo
  working tree. Write nothing inside `$P/LTRpav`, and make no commits. Task 12's files all live in
  `$P/benchmark_pav/plan3/real/`.
- **Probes:** at most 16 threads, each under `timeout 15m` in the foreground. Scratch goes under
  `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t12/`.
- **Environment:**
  - env `ltrpav`, at `/home/chris/bin/mambaforge/envs/ltrpav/bin`. Put it on PATH: lastz lives there.
  - `NUMPY_MADVISE_HUGEPAGE=0`.
- **The server is shared.** Other jobs keep the load at about 200 on 256 cores. The queue uses 32 threads; nothing
  else of yours runs heavy.
- **mem_sampler.sh** is main3's, at `$P/benchmark_pav/main3/`. Read it, then copy it into `real/`.
- No subagents. The user is the sole author: no AI attribution anywhere. American English.
