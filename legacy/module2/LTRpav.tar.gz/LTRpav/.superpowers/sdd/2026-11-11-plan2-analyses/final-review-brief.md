# Plan 2: final whole-branch review (one dispatch; most capable model)

You are a senior reviewer of a scientific software package. Review Plan 2 of LTRpav as one unit, before it is
integrated: the analyses and the overview figure, built over 12 tasks on branch `plan2-analyses`.

## What was built
- LTRpav genotypes LTR-retrotransposon insertions as presence/absence (PAV) across genomes, verified against the
  reference genomes. That engine is Plan 1, already reviewed. On those genotypes it now runs admixture analyses:
  - the catalog reader, relationships, sister pair and outgroup bound;
  - D_pav with a block jackknife and age strata;
  - inverted blocks;
  - painting: a two-state HMM with target-decoy q;
  - direction (n(X->Y), DFOIL-style);
  - mechanisms of absence;
  - the identity layer (LASTZ realignment and the rate-free split);
  - report assembly, stage keys and markers;
  - the commands `ltrpav-stats`, `ltrpav-paint` and `ltrpav-plot`, and the `ltrpav run` hook;
  - the overview figure with legend pages.
- It complements LTRmix, a separate library-only tool.

## Requirements
- **Spec:** `/data2/chris/maize_introgression/LTRpav/docs/DESIGN.md`, approved by the user. Sections 6-8, 10 and 12
  bear on Plan 2.
- **Plan:** `/data2/chris/maize_introgression/LTRpav/docs/plans/2026-11-11-plan2-analyses.md`. Read its Global
  Constraints and Review Focus.
- **Ledger:** `/data2/chris/maize_introgression/LTRpav/.superpowers/sdd/2026-11-11-plan2-analyses/progress.md`.
  - Every controller ruling is a line beginning "Ruling:".
  - A ruling departs from the plan on purpose. Judge whether it is sound, but do not report the departure itself as
    a defect.
- **Figure rules:** `/home/chris/.claude/skills/making-figures/SKILL.md`.
- **Science rules:** the user's `/home/chris/.claude/CLAUDE.md`, sections "Biological Analyses" and "Design
  Philosophy" (thresholds by principle, never tuned to known answers).

## Git range
- Base: 12279a1, Plan 1's reviewed head.
- Head: 4b73977.
- Inspect with `git -C /data2/chris/maize_introgression/LTRpav diff --stat 12279a1..4b73977` and `git diff`.

## Real data to check claims against (read-only)
- `/data2/chris/maize_introgression/benchmark_pav/main3_analyses/`, Task 12's run on B73, TIL18, TIL01 and Zd. It
  holds stats.tsv, findings.txt, posterior and tract files, mechanisms, identity, the overview, prelim_papers.tsv and
  PRELIM.md.
- It is a symlinked view of `/data2/chris/maize_introgression/benchmark_pav/main3/`, Plan 1's frozen run. Never
  write into either. Scratch goes only under
  `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p2final/`.
- Env: `/home/chris/bin/mambaforge/envs/ltrpav/bin/python`, with `NUMPY_MADVISE_HUGEPAGE=0`. Run probes under
  `timeout 15m`, with at most 16 threads.

## Focus (beyond the template's general checks)
1. **Statistical correctness on real inputs.** Check each statistic against its DESIGN definition. Check that
   discovery rules read the discoverer's own calls, never merged states, except where the plan declares
   `disc=any`. Check that missing states are never counted as absent or imputed.
2. **Honesty of every reported verdict.** findings.txt, the figure legends and PRELIM.md must claim nothing their
   statistic does not support. That means significance from Z_SIG, degenerate variances guarded, and nothing in
   PRELIM.md stronger than "preliminary".
3. **Engine isolation.**
   - No engine stage key changes: `checkpoint.STAGE_MODULES`.
   - Analysis keys use `analysis_fingerprint(stage)`, never the engine fingerprint.
   - Analysis commands never run engine-fingerprint checks.
   - The analysis package imports cleanly without scipy or matplotlib where the plan requires that.
4. **Resumability and staleness.** Check stage keys, markers, `stale_parts`, `left_out_parts` and the plot's
   refusal. Ask whether any path can draw or report results that are stale against the catalog.
5. **Generality.** Nothing in `src/` may assume maize, chromosome names, three ingroups, an outgroup's presence, an
   annotated donor or a painting's existence. Name every crash or wrong text on such paths.
6. **Deferred items: re-check each one.** Say whether it still applies, and give a severity.
   - Task 2: read_stats coerces numeric-looking text ("12" becomes an int, 5.0 becomes 5) and reads "." back as NaN.
     block_size raises a bare ValueError when there are no genomes. jackknife re-evaluates on NaN estimates.
     Untested: the rule for fewer than 2 finite pseudovalues, the dropping of non-finite pseudovalues, and u95 with
     an array n.
   - Tasks 4 M6 and 7: analysis modules import each other's private helpers: trio's `_why`/`_guard`/`_fmt`,
     relations' `_first_member`, `_check_trio` and `_fallback_reasons`.
   - Task 10 N1: `stale_parts` raises KeyError on a hand-edited marker of a shape the code never writes.
   - Task 11:
     - The inversion caller (Task 5) reports sparse blocks: on main3's TIL01 side, 49 blocks of 5-19 loci spanning
       up to 278 Mb, many between non-syntenic sequences, which flag 31,473 decoy loci.
     - The PNG output is nondeterministic because two Liberation font versions are registered in random order.
     - The left-out-parts guard reads findings.txt and fails open.
   - Task 12's independent figure check: line 7 fails.
     - The short legend gives thresholds and test statistics ("none of B73's reach q ≤ 0.05"; "D +0.60 at K = 0
       against +0.20 at K ≥ 0.01").
     - Its headline says "gene flow ..., not incomplete lineage sorting" while D_pav's null is not yet simulated
       (Plan 3). Proposed: "consistent with gene flow ... rather than incomplete lineage sorting alone".
     - The legend's last line names a module, not a script path.
7. **Tests.** Do they verify behavior with expected values, using small synthetic fixtures? Are slow tests marked?
   Does the suite pass under `-W error`? Do not run the whole suite; rely on the ledger's runs, unless a doubt
   needs one focused test.

## Rules
- Read-only on the checkout. Never move HEAD.
- No subagents.
- The user is the sole author. Never suggest or add AI attribution.

## Output
- Write the full review to
  `/data2/chris/maize_introgression/LTRpav/.superpowers/sdd/2026-11-11-plan2-analyses/final-review.md`, in the
  template's format. Include a "Declined to judge" list and a table re-checking the deferred items.
- Return only:
  - the verdict (Ready to merge: Yes / No / With fixes);
  - the counts by severity;
  - one line per Critical or Important finding.
