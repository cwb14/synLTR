# Task 2 report
Done: created env ltrpav_bench (all pins available), wrote run.sh/README.md in /data2/chris/maize_introgression/benchmark_pav/bakeoff/anchorwave/, launched detached once.
Versions: anchorwave 1.3.1, minimap2 2.31, samtools 1.25, pywfa 0.6.0, python 3.12.16; ltrpav editable import OK.
Launch: cd anchorwave; setsid -f nohup mamba run -n ltrpav_bench bash run.sh > run.log 2>&1 < /dev/null
PID check:
  PID PPID SID CMD
  79046 1 79046 mamba run -n ltrpav_bench bash run.sh
  79094 79046 79046 bash run.sh
  genoAli: 384857 (anchorwave genoAli ... -t 8)
Progress: gff2seq, both minimap2 steps, anchors done within ~1 min (cds.fa 2.5 MB, cds.sam, ref.sam, anchors); genoAli running, empty anchorwave.maf/.f.maf; run.log shows scheduler "anchors generate done!".
Files: bakeoff/env_bench.yml, anchorwave/{run.sh,README.md,B73_chr10.fa,TIL18_chr10.fa,genes_chr10.gff3 (2705 genes),cds.fa,cds.sam,ref.sam,anchors,run.log}. Nothing written to inputs/ or benchmark_data/.
Concerns: none.
