"""The overview figure: not part of the engine; fingerprinted with the analysis package."""
