# Task 20 — controller rulings (bind as much as the brief; override it where they conflict)

Common: all text outputs deterministic (sorted, no timestamps); 1-based inclusive coordinates except BED; "." for
None; floats format(x, ".6g"); genomes always in sheet order.

1. loci.tsv: columns lid, family, superfamily, clade, length, ltr_len, tsd, discovery (comma-joined), flags
   (comma-joined or "."), then for each genome G in sheet order: G_eid (member eid or "."), G_state, G_tier,
   G_seqid, G_start, G_end, G_strand, G_k, G_flags. Rows in lid order.
2. pav_matrix.tsv: lid + one column per genome (state letter). write_qc: columns scope, metric, value.
3. VCF (write_vcf(loci, samples, ref_label, fasta, path) -> (vcf_gz_path, unplaced_tsv_path)):
   - Header via pysam VariantHeader: fileformat VCFv4.2; contigs = the reference genome's FASTA (fai order, lengths);
     ALT <INS:ME:LTR> ("LTR retrotransposon insertion"); INFO SVTYPE (String), SVLEN (Integer), END (Integer),
     FAM (String), SF (String), K (Float, median of members' K), DISC (String, discovery genomes comma-joined),
     NE (Integer, genomes with state E), AA (String); FORMAT GT, ST (String: state letter), TR (String: tier);
     samples = every genome label in sheet order.
   - One record per locus whose reference-genome state is P, S, T or E with coordinates. POS: present (P/S/T) ->
     start - 1 (the last base before the element); E -> end of the E site (the last base of the target-site copy).
     REF = the reference base at POS (fetched); ALT <INS:ME:LTR>; ID = lid; END = POS; SVLEN = locus length.
     AA = REF when NE > 0, else absent. GT haploid: 1 for P/S/T, 0 for E, missing for D/O/G/U.
   - Loci not representable (reference state D/O/G/U, no coordinates, or a present element starting at base 1) go to
     pav.unplaced.tsv (lid, ref_state, reason).
   - Records sorted by (contig fai index, POS, lid); write plain VCF then pysam.tabix_index(..., preset="vcf",
     force=True) -> .vcf.gz + .tbi.
4. Tracks (write_tracks(loci, samples, outdir, seq_order)): for each genome G, rows = loci where G has coordinates
   and state in P, S, T, E, D. GFF3 `<G>.pav.gff3`: "##gff-version 3", "##sequence-region" lines for the seqids used
   (fai order, lengths from seq lengths passed in), then features sorted by (fai index, start, lid): source LTRpav,
   type P/S/T -> LTR_retrotransposon, E -> insertion_site, D -> deletion_junction; strand from the state ("." if
   None); attributes ID=<lid>;state=;tier=;family= (if any);states=A:P,B:E,... (every genome, sheet order), escaped
   per GFF3. BED6+3 `<G>.pav.bed`: chrom, start-1, end, lid, 0, strand ("." if None), state, tier, family (".").
   The extra argument(s) needed for sequence lengths/order may be added (e.g., seq_lengths: dict[genome,
   dict[seqid, int]]).
5. write_manifest(path, argv, params, samples, checksums, started, finished): JSON with tool "ltrpav", version,
   command (argv list), params, samples (label, fasta, annotation, group, role, and their checksums from
   `checksums`), dependencies (python, numpy, numba, pysam, mappy via importlib.metadata; minimap2, FastGA, blastn,
   bcftools via a best-effort `--version`/usage call with a 10-s timeout, null when absent), started, finished
   (ISO 8601), host (socket.gethostname()). Sorted keys, 2-space indent.
6. Tests as the brief (bcftools test skipif absent); plus determinism (writing twice gives identical bytes for
   every text output) and the GFF3 attribute escaping of a family name containing ";" or ",".
