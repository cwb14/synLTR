"""Anchoring routes (mm2, PAF), the route registry and `anchor_pair` with its caches."""
from __future__ import annotations

import contextlib
import gzip
import logging
import random
import shutil
import subprocess
from itertools import pairwise

import numpy as np
import pytest

import ltrpav.anchor as anchor_mod
from ltrpav.anchor import PairContext, anchor_pair, get_route
from ltrpav.anchor import fastga as fastga_mod
from ltrpav.anchor import mm2 as mm2_mod
from ltrpav.anchor.mm2 import Mm2Route
from ltrpav.anchor.paf import PafRoute
from ltrpav.blocks import BLOCK_DTYPE, load_blocks
from ltrpav.checkpoint import CHECKSUM_CACHE, file_checksum
from ltrpav.constants import ANCHOR_MIN, SPLIT_INDEL
from ltrpav.elements import Element
from ltrpav.samples import Sample
from ltrpav.seqio import Fasta, revcomp
from toy import make_element, mutate, rand_seq, write_fasta


def covered_fraction(bl, names, shared):
    """Fraction of the `shared` A intervals ({seqid: [(start, end)]}) covered by the blocks' A spans."""
    cov = tot = 0
    for ci, name in enumerate(names):
        ivs = shared.get(name, [])
        if not ivs:
            continue
        mask = np.zeros(max(e for _, e in ivs), bool)
        for r in bl[bl["a_chrom"] == ci]:
            mask[r["a_start"]:r["a_end"]] = True
        for s, e in ivs:
            cov += int(mask[s:e].sum())
            tot += e - s
    return cov / tot


@pytest.fixture(scope="module")
def toy(tmp_path_factory):
    """300 kb of shared backbone (chr1 200 kb, chr2 100 kb). A carries 10 A-only elements (6 + 4, 4.8 kb
    each); B holds the backbones mutated 1%, in the other order, chr2's copy reverse-complemented.

    Returns the A and B FASTA paths and the shared (backbone) A intervals per A seqid.
    """
    rng = random.Random(15)
    a_recs, b_seqs, shared = {}, [], {}
    for name, size, n_el in (("chr1", 200_000, 6), ("chr2", 100_000, 4)):
        bb = rand_seq(size, rng)
        cuts = sorted(rng.sample(range(5_000, size - 5_000, 1000), n_el))
        parts, ivs, prev, pos = [], [], 0, 0
        for c in cuts:
            el, _, _ = make_element(rng, 400, 4000)
            parts += [bb[prev:c], el]
            ivs.append((pos, pos + c - prev))
            pos += c - prev + len(el)
            prev = c
        parts.append(bb[prev:])
        ivs.append((pos, pos + size - prev))
        a_recs[name] = "".join(parts)
        shared[name] = ivs
        b_seqs.append(mutate(bb, 0.01, rng))
    d = tmp_path_factory.mktemp("toy")
    a = write_fasta(d / "A.fa", a_recs)
    b = write_fasta(d / "B.fa", {"ctgX": revcomp(b_seqs[1]), "ctgY": b_seqs[0]})
    return a, b, shared


@pytest.fixture
def open_ctx(tmp_path):
    """make(a_label, a_fasta, b_label, b_fasta, outdir=None, elements=()) -> PairContext (handles closed at
    teardown; outdir defaults to tmp_path / "out")."""
    with contextlib.ExitStack() as stack:
        def make(a, a_path, b, b_path, outdir=None, elements=()):
            return PairContext(
                a=Sample(a, a_path, None, None, None), b=Sample(b, b_path, None, None, None),
                a_fa=stack.enter_context(Fasta(a_path)), b_fa=stack.enter_context(Fasta(b_path)),
                a_elements=list(elements), b_elements=None, outdir=outdir or tmp_path / "out", threads=2)
        yield make


# --- mm2 route --------------------------------------------------------------------------------------------


def test_mm2_route_covers_shared_sequence(toy, open_ctx):
    a, b, shared = toy
    ctx = open_ctx("A", a, "B", b)
    bl, an, bn, d = anchor_pair(ctx, get_route("mm2"))
    assert an == ["chr1", "chr2"] and bn == ["ctgX", "ctgY"]
    assert covered_fraction(bl, an, shared) >= 0.95 and 0.005 < d < 0.02
    # minimap2 aligns through each 4.8-kb insertion; split there, no block spans one (20 bp of edge slop)
    assert all(any(s - 20 <= r["a_start"] and r["a_end"] <= e + 20 for s, e in shared[an[r["a_chrom"]]])
               for r in bl)
    # chr1 lies forward on ctgY, chr2 reverse-complemented on ctgX; nothing competes (no repeats, and no
    # chunk-edge copy of an alignment survives to compete with it)
    assert set(zip(bl["a_chrom"].tolist(), bl["b_chrom"].tolist(), bl["strand"].tolist())) == {(0, 1, 1),
                                                                                           (1, 0, -1)}
    assert (bl["margin"] == 1.0).all()
    assert (ctx.workdir / "anchors" / "A__B.mm2.npz").is_file()


# =100 X2 =50 I5 =300 | I4800 | =1000 | D90 | =500 from A[10,6767) to B[1000,3042): the 5-bp insertion stays
# inside a piece, the long indels split
_CIGAR = [[100, 7], [2, 8], [50, 7], [5, 1], [300, 7], [4800, 1], [1000, 7], [90, 2], [500, 7]]
_PIECES = {  # (a0, a1, b0, b1, matches, alen) in A order; on '-' the CIGAR runs along B with A descending
    1: [(10, 467, 1000, 1452, 450, 457), (5267, 6267, 1452, 2452, 1000, 1000),
        (6267, 6767, 2542, 3042, 500, 500)],
    -1: [(10, 510, 2542, 3042, 500, 500), (510, 1510, 1452, 2452, 1000, 1000),
         (6310, 6767, 1000, 1452, 450, 457)],
}


@pytest.mark.parametrize("strand", [1, -1])
def test_mm2_pieces_split_at_long_indels(strand):
    assert 5 < SPLIT_INDEL <= 90
    assert mm2_mod._pieces(_CIGAR, 10, 1000, 3042, strand, 0, 10**9) == _PIECES[strand]
    assert mm2_mod._pieces([[700, 7], [3, 8]], 0, 0, 703, strand, 0, 10**9) == [(0, 703, 0, 703, 700, 703)]
    with pytest.raises(ValueError, match="CIGAR"):
        mm2_mod._pieces([[700, 0]], 0, 0, 700, strand, 0, 10**9)  # M: matches cannot be counted


@pytest.mark.parametrize("strand, stop, want", [
    (1, 5667, [(10, 467, 1000, 1452, 450, 457), (5267, 5667, 1452, 1852, 400, 400)]),  # inside the =1000
    (1, 567, [(10, 467, 1000, 1452, 450, 457)]),  # inside the I4800
    (1, 10, []),  # the hit starts at the stop: nothing
    (1, 164, [(10, 164, 1000, 1152, 150, 154)]),  # inside the I5 (A[162,167)): 3 columns past the stop
    (-1, 1000, [(10, 510, 2542, 3042, 500, 500), (510, 1000, 1962, 2452, 490, 490)]),
])
def test_mm2_pieces_cut_at_stop(strand, stop, want):
    # A positions at or past `stop` (the chunk's core end) are left to the next chunk
    assert mm2_mod._pieces(_CIGAR, 10, 1000, 3042, strand, 0, stop) == want


@pytest.mark.parametrize("strand, begin, stop, want", [
    (1, 60, 10**9, [(60, 467, 1050, 1452, 400, 407)] + _PIECES[1][1:]),  # inside the first =100
    (1, 164, 10**9, [(164, 467, 1152, 1452, 300, 303)] + _PIECES[1][1:]),  # inside the I5: 3 columns kept
    (1, 1000, 10**9, _PIECES[1][1:]),  # inside the I4800: the piece after it
    (1, 6267, 10**9, _PIECES[1][2:]),  # at the D90, which this side keeps: the piece after it
    (1, 60, 5667, [(60, 467, 1050, 1452, 400, 407), (5267, 5667, 1452, 1852, 400, 400)]),
    (1, 7000, 10**9, []),  # the hit ends before `begin`
    (-1, 300, 10**9, [(300, 510, 2542, 2752, 210, 210)] + _PIECES[-1][1:]),
    (-1, 510, 10**9, _PIECES[-1][1:]),  # at the D90 (A descending): the piece after it
    (-1, 300, 1000, [(300, 510, 2542, 2752, 210, 210), (510, 1000, 1962, 2452, 490, 490)]),
])
def test_mm2_pieces_cut_at_begin(strand, begin, stop, want):
    # A positions before `begin` (the chunk's core start; the left context) belong to the previous chunk
    assert mm2_mod._pieces(_CIGAR, 10, 1000, 3042, strand, begin, stop) == want


@pytest.mark.parametrize("strand", [1, -1])
def test_mm2_pieces_tile_the_alignment(strand):
    # cores cutting through matches, the short insertion, the long one and at the long deletion: the pieces of
    # consecutive cores abut exactly on A and B and glue back into the uncut pieces
    cuts = [0, 61, 164, 300, 510, 1000, 6267, 6400, 10**9]
    parts = [p for lo, hi in pairwise(cuts) for p in mm2_mod._pieces(_CIGAR, 10, 1000, 3042, strand, lo, hi)]
    glued = []
    for p in parts:
        g = glued[-1] if glued else None
        if g and g[1] == p[0] and (g[3] == p[2] if strand > 0 else g[2] == p[3]):
            glued[-1] = (g[0], p[1], min(g[2], p[2]), max(g[3], p[3]), g[4] + p[4], g[5] + p[5])
        else:
            glued.append(p)
    assert glued == _PIECES[strand] and len(parts) > len(glued)


def test_mm2_index_built_once_with_or_without_minimap2(toy, open_ctx, tmp_path, monkeypatch):
    a, b, _ = toy
    route = Mm2Route()
    ctx = open_ctx("A", a, "B", b, outdir=tmp_path / "one")
    first = route.raw_blocks(ctx)
    mmi = ctx.workdir / "anchors" / "B.asm20.mmi"
    built = mmi.stat().st_mtime_ns
    assert route.raw_blocks(ctx).tobytes() == first.tobytes()
    assert mmi.stat().st_mtime_ns == built  # reused, not rebuilt
    monkeypatch.setattr(shutil, "which", lambda *args, **kw: None)  # no minimap2 binary: mappy indexes B
    ctx2 = open_ctx("A", a, "B", b, outdir=tmp_path / "two")
    assert route.raw_blocks(ctx2).tobytes() == first.tobytes()
    assert (ctx2.workdir / "anchors" / "B.asm20.mmi").read_bytes() == mmi.read_bytes()


def test_mm2_chunk_core_rule(tmp_path, open_ctx, monkeypatch):
    # cores A[0,20k), A[20k,40k), A[40k,65k), mapped in windows A[0,25k), A[15k,45k), A[35k,65k): s1 lies in
    # two windows, s2 starts in the second core and runs past its end into the third
    monkeypatch.setattr(mm2_mod, "MM2_CHUNK", 20_000)
    monkeypatch.setattr(mm2_mod, "MM2_OVERLAP", 5_000)
    rng = random.Random(7)
    s1, s2 = rand_seq(3000, rng), rand_seq(5000, rng)
    a = rand_seq(21_000, rng) + s1 + rand_seq(14_000, rng) + s2 + rand_seq(22_000, rng)  # s1: 21k, s2: 38k
    b = rand_seq(5000, rng) + s1 + rand_seq(5000, rng) + s2 + rand_seq(5000, rng)  # s1 at 5k, s2 at 13k
    ctx = open_ctx("A", write_fasta(tmp_path / "A.fa", {"a1": a}), "B",
                   write_fasta(tmp_path / "B.fa", {"b1": b}))
    raw = Mm2Route().raw_blocks(ctx)

    def n_near(a0, a1, b0, b1):
        return sum(abs(int(r["a_start"]) - a0) <= 10 and abs(int(r["a_end"]) - a1) <= 10
                   and abs(int(r["b_start"]) - b0) <= 10 and abs(int(r["b_end"]) - b1) <= 10 for r in raw)

    assert len(raw) == 3
    assert n_near(21_000, 24_000, 5000, 8000) == 1  # seen by two chunks, kept by the one whose core holds it
    assert n_near(38_000, 40_000, 13_000, 15_000) == 1  # cut at the core end ...
    assert n_near(40_000, 43_000, 15_000, 18_000) == 1  # ... where the next chunk takes over
    left, right = np.sort(raw, order="a_start")[1:]
    assert left["a_end"] == 40_000 == right["a_start"] and left["b_end"] == right["b_start"]  # exact abutment
    bl, an, _, _ = anchor_pair(ctx, Mm2Route())
    assert len(set(bl["chain"].tolist())) == 1 and (bl["margin"] == 1.0).all()  # one chain, no rival
    assert covered_fraction(bl, an, {"a1": [(21_000, 24_000), (38_000, 43_000)]}) > 0.99


def _past_core_end(tmp_path, open_ctx, monkeypatch, a, b):
    """Raw mm2 blocks of A (one 65-kb sequence) vs B, sorted by A start, with 20-kb cores and 5-kb overlaps:
    cores A[0,20k), A[20k,40k), A[40k,65k)."""
    monkeypatch.setattr(mm2_mod, "MM2_CHUNK", 20_000)
    monkeypatch.setattr(mm2_mod, "MM2_OVERLAP", 5_000)
    assert len(a) == 65_000
    ctx = open_ctx("A", write_fasta(tmp_path / "A.fa", {"a1": a}), "B",
                   write_fasta(tmp_path / "B.fa", {"b1": b}))
    return ctx, np.sort(Mm2Route().raw_blocks(ctx), order="a_start")


@pytest.mark.parametrize("past", [100, 150, 200])
def test_mm2_keeps_homology_ending_just_past_a_core_end(tmp_path, open_ctx, monkeypatch, past):
    # homology A[34000, 40000 + past) ends `past` bp into the third core: too short to seed alone, the
    # fragment is found by the third chunk through its left context and kept, abutting the second chunk's
    # piece exactly
    rng = random.Random(past)
    s = rand_seq(6000 + past, rng)
    a = rand_seq(34_000, rng) + s + rand_seq(25_000 - past, rng)
    b = rand_seq(3000, rng) + mutate(s, 0.01, rng) + rand_seq(3000, rng)
    ctx, raw = _past_core_end(tmp_path, open_ctx, monkeypatch, a, b)
    assert len(raw) == 2
    assert raw["a_end"][0] == 40_000 == raw["a_start"][1] and raw["b_end"][0] == raw["b_start"][1]
    assert abs(int(raw["a_start"][0]) - 34_000) <= 10 and abs(int(raw["a_end"][1]) - (40_000 + past)) <= 10
    bl, an, _, _ = anchor_pair(ctx, Mm2Route())
    assert covered_fraction(bl, an, {"a1": [(34_000, 40_000 + past)]}) > 0.99


@pytest.mark.parametrize("past", [800, 1000, 1100])
def test_mm2_keeps_fragment_before_insertion_just_past_a_core_end(tmp_path, open_ctx, monkeypatch, past):
    # an A-only 4.8-kb insertion starts `past` bp into the third core: the fragment A[40000, 40000 + past)
    # between the core end and the insertion is kept by the third chunk, abutting the second chunk's piece
    rng = random.Random(past)
    s1, s2 = rand_seq(10_000 + past, rng), rand_seq(17_200 - past, rng)
    a = rand_seq(30_000, rng) + s1 + rand_seq(4800, rng) + s2 + rand_seq(3000, rng)
    b = rand_seq(3000, rng) + mutate(s1, 0.01, rng) + mutate(s2, 0.01, rng) + rand_seq(3000, rng)
    ctx, raw = _past_core_end(tmp_path, open_ctx, monkeypatch, a, b)
    assert len(raw) == 3
    assert raw["a_end"][0] == 40_000 == raw["a_start"][1] and raw["b_end"][0] == raw["b_start"][1]
    assert abs(int(raw["a_end"][1]) - (40_000 + past)) <= 10
    assert abs(int(raw["a_start"][2]) - (40_000 + past + 4800)) <= 10
    bl, an, _, _ = anchor_pair(ctx, Mm2Route())
    assert covered_fraction(bl, an, {"a1": [(30_000, 40_000 + past)]}) > 0.99


def test_mm2_maps_gappy_chunks(tmp_path, open_ctx, caplog):
    # a1 is one chunk, 60% N, holding a 30-kb segment shared with B: it is mapped. a2 is one chunk with
    # ANCHOR_MIN - 1 non-N bases, too few for an anchor: skipped
    rng = random.Random(9)
    seg = rand_seq(30_000, rng)
    a = write_fasta(tmp_path / "A.fa", {"a1": "N" * 45_000 + seg,
                                         "a2": "N" * 3000 + rand_seq(ANCHOR_MIN - 1, rng)})
    b_seq = rand_seq(5000, rng) + mutate(seg, 0.01, rng) + rand_seq(5000, rng)
    b = write_fasta(tmp_path / "B.fa", {"b1": b_seq})
    with caplog.at_level(logging.INFO, logger="ltrpav.anchor"):
        raw = Mm2Route().raw_blocks(open_ctx("A", a, "B", b))
    assert covered_fraction(raw, ["a1", "a2"], {"a1": [(45_000, 75_000)]}) > 0.99
    assert "skipped 1 chunk" in caplog.text


def test_w_route_reused_both_directions(toy, open_ctx, monkeypatch):
    a, b, _ = toy
    calls = []
    real = Mm2Route.raw_blocks

    def spy(self, ctx):
        calls.append((ctx.a.label, ctx.b.label))
        return real(self, ctx)

    monkeypatch.setattr(Mm2Route, "raw_blocks", spy)
    ba = open_ctx("B", b, "A", a)
    bl_ba, an, bn, d_ba = anchor_pair(ba, get_route("mm2"))  # the reverse direction first
    assert calls == [("A", "B")]  # raw blocks are computed in label order: A mapped onto indexed B
    ab = open_ctx("A", a, "B", b)
    bl_ab, _, _, d_ab = anchor_pair(ab, get_route("mm2"))
    assert bl_ab.tobytes() == anchor_pair(ab, get_route("mm2"))[0].tobytes()  # cache hit: same blocks
    assert calls == [("A", "B")]  # the second direction loads the raw cache: no new mapping
    anchor_pair(ba, get_route("mm2"))
    assert calls == [("A", "B")]  # repeat calls reuse the netted cache

    anchors = ab.workdir / "anchors"
    assert sorted(p.name for p in anchors.glob("*.npz")) == ["A__B.mm2.npz", "A__B.mm2.raw.npz",
                                                            "B__A.mm2.npz"]
    _, xn, yn = load_blocks(anchors / "A__B.mm2.raw.npz")
    assert (xn, yn) == (["chr1", "chr2"], ["ctgX", "ctgY"])
    assert (an, bn) == (["ctgX", "ctgY"], ["chr1", "chr2"])
    assert covered_fraction(bl_ba, an, {"ctgX": [(0, 100_000)], "ctgY": [(0, 200_000)]}) >= 0.95
    assert abs(d_ab - d_ba) < 0.002


# --- FastGA route -----------------------------------------------------------------------------------------


@pytest.mark.skipif(shutil.which("FastGA") is None, reason="FastGA not on PATH")
def test_fastga_route(toy, open_ctx, monkeypatch):
    a, b, shared = toy
    runs = []
    real = subprocess.Popen

    def spy(cmd, *args, **kw):
        runs.append(cmd)
        return real(cmd, *args, **kw)

    monkeypatch.setattr(fastga_mod.subprocess, "Popen", spy)
    route = get_route("fastga")
    ba = open_ctx("B", b, "A", a)
    bl_ba, an, bn, _ = anchor_pair(ba, route)
    assert len(runs) == 1 and len(bl_ba) > 0
    ab = open_ctx("A", a, "B", b)
    an_ab = anchor_pair(ab, route)[1]
    assert len(runs) == 1  # the reverse direction reuses the unordered-pair cache
    assert (an, bn) == (["ctgX", "ctgY"], ["chr1", "chr2"]) and an_ab == ["chr1", "chr2"]

    fa = ab.workdir / "fastga"
    paf = fa / "A__B.fastga.paf.gz"
    assert paf.is_file() and len(list(fa.glob("A.*.fa"))) == 1 and len(list(fa.glob("B.*.fa"))) == 1
    assert all(p.is_symlink() for p in fa.glob("[AB].*.fa"))
    assert not list(a.parent.glob("*.1gdb")) and not list(a.parent.glob(".*.gix"))
    with gzip.open(paf, "rt") as fh:
        rows = [ln.split("\t") for ln in fh]
    assert rows and {r[0] for r in rows} <= {"chr1", "chr2"}  # query = A (sorted-first label)
    assert any("cg:Z:" in x for x in rows[0][12:])

    rawf = load_blocks(ab.workdir / "anchors" / "A__B.fastga.raw.npz")[0]
    assert len(rawf) > 0
    assert covered_fraction(rawf, ["chr1", "chr2"], shared) > 0.9
    # every A-only insertion (4.8 kb, far over SPLIT_INDEL) lies between blocks: none spans one whole
    for ci, name in enumerate(["chr1", "chr2"]):
        ivs = shared[name]
        for (_, e0), (s1, _) in pairwise(ivs):
            hit = rawf[(rawf["a_chrom"] == ci) & (rawf["a_start"] < e0) & (rawf["a_end"] > s1)]
            assert len(hit) == 0


def anchor_raw(ctx):
    return get_route("fastga").raw_blocks(ctx)


@pytest.mark.skipif(shutil.which("FastGA") is None, reason="FastGA not on PATH")
def test_fastga_splits_at_long_insertion(tmp_path, open_ctx):
    rng = random.Random(5)
    bb = rand_seq(300_000, rng)
    ins, small = rand_seq(SPLIT_INDEL + 10, rng), rand_seq(40, rng)
    a = write_fasta(tmp_path / "A.fa", {"a1": bb[:100_000] + ins + bb[100_000:200_000] + small + bb[200_000:]})
    b = write_fasta(tmp_path / "B.fa", {"b1": mutate(bb, 0.01, rng)})
    raw = anchor_raw(open_ctx("A", a, "B", b))
    assert len(raw) > 0 and raw["a_chrom"].max() == 0
    lo, hi = 100_000, 100_000 + len(ins)
    assert not ((raw["a_start"] < hi) & (raw["a_end"] > lo)).any()  # the long insertion lies between blocks
    assert ((raw["a_start"] < 200_000 + len(ins)) & (raw["a_end"] > 200_000 + len(ins) + len(small))).any()


@pytest.mark.skipif(shutil.which("FastGA") is None, reason="FastGA not on PATH")
def test_fastga_changed_fasta_gets_fresh_index(tmp_path, open_ctx):
    rng = random.Random(8)
    a = write_fasta(tmp_path / "A.fa", {"a1": rand_seq(60_000, rng)})
    b1 = write_fasta(tmp_path / "b1.fa", {"b1": rand_seq(60_000, rng)})  # unrelated to A
    route = get_route("fastga")
    assert len(route.raw_blocks(open_ctx("A", a, "B", b1))) == 0
    ctx = open_ctx("A", a, "B", b1)
    seq = ctx.a_fa.fetch("a1", 0, 60_000)
    b2 = write_fasta(tmp_path / "b2.fa", {"b1": seq})  # now identical to A, same label B
    shutil.copy(b2, b1)  # same path, new content
    raw = route.raw_blocks(open_ctx("A", a, "B", b1))
    assert int((raw["a_end"] - raw["a_start"]).sum()) > 55_000  # not the stale index of the old B
    assert len(list((tmp_path / "out" / "work" / "fastga").glob("B.*.fa"))) == 2


@pytest.mark.skipif(shutil.which("FastGA") is None, reason="FastGA not on PATH")
def test_fastga_concurrent_pairs_sharing_a_genome(tmp_path, open_ctx, monkeypatch):
    import threading
    import time
    rng = random.Random(9)
    bb = rand_seq(80_000, rng)
    a = write_fasta(tmp_path / "A.fa", {"a1": bb})
    b = write_fasta(tmp_path / "B.fa", {"b1": mutate(bb, 0.01, rng)})
    c = write_fasta(tmp_path / "C.fa", {"c1": mutate(bb, 0.02, rng)})
    route = get_route("fastga")
    want = {y: route.raw_blocks(open_ctx("A", a, y, p, outdir=tmp_path / f"seq{y}")).tobytes()
            for y, p in (("B", b), ("C", c))}
    spans, real = [], subprocess.Popen

    class Spy(real):
        def __init__(self, *a, **kw):
            self.t0 = time.monotonic()
            super().__init__(*a, **kw)

        def wait(self, *a, **kw):
            r = super().wait(*a, **kw)
            spans.append((self.t0, time.monotonic()))
            return r

    monkeypatch.setattr(fastga_mod.subprocess, "Popen", Spy)
    out, shared = {}, tmp_path / "shared"
    ctxs = {y: open_ctx("A", a, y, p, outdir=shared) for y, p in (("B", b), ("C", c))}

    (shared / "work").mkdir(parents=True)
    for p in (a, b, c):  # anchor_pair checksums the FASTAs before calling the route: warm the cache likewise
        file_checksum(p, shared / "work" / CHECKSUM_CACHE)

    def run(y):
        out[y] = route.raw_blocks(ctxs[y]).tobytes()

    ts = [threading.Thread(target=run, args=(y,)) for y in ("B", "C")]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    assert out == want
    first, second = sorted(spans)
    assert len(spans) == 2 and first[1] <= second[0] + 0.05  # FastGA runs do not overlap in time


def test_fastga_missing_binary(tmp_path, open_ctx, monkeypatch):
    a = write_fasta(tmp_path / "a.fa", {"a1": rand_seq(2000, random.Random(1))})
    monkeypatch.setenv("PATH", str(tmp_path))
    with pytest.raises(RuntimeError, match="FastGA"):
        get_route("fastga").raw_blocks(open_ctx("A", a, "B", a))


# --- PAF route --------------------------------------------------------------------------------------------

_PAF = [  # A (a1) is the query
    "a1\t20000\t1000\t9000\t+\tb1\t30000\t2000\t10000\t7900\t8000\t60",
    "a1\t20000\t10000\t19000\t-\tb2\t15000\t1000\t10000\t8900\t9000\t60",
]


def _swapped(line):
    """The same PAF record with query and target exchanged."""
    f = line.split("\t")
    return "\t".join(f[5:9] + [f[4]] + f[0:4] + f[9:])


def test_paf_route(tmp_path, open_ctx):
    rng = random.Random(3)
    a = write_fasta(tmp_path / "A.fa", {"a1": rand_seq(20_000, rng)})
    b = write_fasta(tmp_path / "B.fa", {"b1": rand_seq(30_000, rng), "b2": rand_seq(15_000, rng)})
    fwd, rev = tmp_path / "fwd", tmp_path / "rev"
    fwd.mkdir()
    rev.mkdir()
    (fwd / "A__B.paf").write_text("\n".join(_PAF) + "\n")
    with gzip.open(rev / "B__A.paf.gz", "wt") as fh:
        fh.write("\n".join(map(_swapped, _PAF)) + "\n")

    ctx = open_ctx("A", a, "B", b)
    got = PafRoute(fwd).raw_blocks(ctx)
    cols = ["a_chrom", "a_start", "a_end", "b_chrom", "b_start", "b_end", "strand", "matches", "alen"]
    assert got[cols].tolist() == [(0, 1000, 9000, 0, 2000, 10000, 1, 7900, 8000),
                                  (0, 10000, 19000, 1, 1000, 10000, -1, 8900, 9000)]
    assert PafRoute(rev).raw_blocks(ctx).tobytes() == got.tobytes()  # B__A.paf.gz read with swap

    ba = open_ctx("B", b, "A", a)  # B as A: A__B.paf read with swap
    bl, an, bn, d = anchor_pair(ba, get_route(f"paf:{fwd}"))
    assert (an, bn) == (["b1", "b2"], ["a1"])
    assert bl[cols[:7]].tolist() == [(0, 2000, 10000, 0, 1000, 9000, 1),
                                     (1, 1000, 10000, 0, 10000, 19000, -1)]
    assert d == pytest.approx(1 - (7900 + 8900) / (8000 + 9000))
    with open(fwd / "A__B.paf", "a") as fh:  # the PAF changes: the netted cache is rebuilt
        fh.write("a1\t20000\t19000\t20000\t+\tb1\t30000\t20000\t21000\t1000\t1000\t60\n")
    assert len(anchor_pair(ba, get_route(f"paf:{fwd}"))[0]) == 3

    with pytest.raises(FileNotFoundError, match=r"A__B\.paf\[\.gz\].*B__A\.paf\[\.gz\]"):
        PafRoute(tmp_path / "none").raw_blocks(ctx)


# --- anchor_pair and the registry -------------------------------------------------------------------------


class _FixedRoute:
    """Returns one fixed block (or none); counts its calls; reads elements."""

    name = "fixed"
    whole_genome = False
    reads_elements = True

    def __init__(self, empty=False):
        self.calls, self.version, self.empty = 0, 1, empty

    def params(self, ctx):
        return {"version": self.version}

    def raw_blocks(self, ctx):
        self.calls += 1
        out = np.zeros(0 if self.empty else 1, dtype=BLOCK_DTYPE)
        if not self.empty:
            out[0] = (0, 0, 5000, 0, 0, 5000, 1, 4950, 5000, -1, 0.0, np.nan)
        return out


def test_anchor_pair_cache_key(tmp_path, open_ctx):
    rng = random.Random(4)
    a = write_fasta(tmp_path / "A.fa", {"a1": rand_seq(6000, rng)})
    b = write_fasta(tmp_path / "B.fa", {"b1": rand_seq(6000, rng)})
    b2 = write_fasta(tmp_path / "B2.fa", {"b1": rand_seq(6000, rng)})
    route = _FixedRoute()
    ctx = open_ctx("A", a, "B", b)
    bl, an, bn, d = anchor_pair(ctx, route)
    assert route.calls == 1 and len(bl) == 1 and d == pytest.approx(0.01)
    ctx.threads = 8  # not part of the key
    again = anchor_pair(ctx, route)
    assert route.calls == 1 and again[0].tobytes() == bl.tobytes() and again[1:] == (an, bn, d)
    ctx.a_elements = [Element("A", "A|a1:101-600", "e", "a1", 101, 600, "+", (101, 150), (551, 600),
                              None, None, None, None, None, None)]
    anchor_pair(ctx, route)  # elements changed, and this route reads them
    assert route.calls == 2
    route.version = 2  # a route parameter changed
    anchor_pair(ctx, route)
    assert route.calls == 3
    anchor_pair(open_ctx("A", a, "B", b2), route)  # another B FASTA under the same label
    assert route.calls == 4

    bl, an, bn, d = anchor_pair(open_ctx("A", a, "B", b, outdir=tmp_path / "empty"), _FixedRoute(empty=True))
    assert len(bl) == 0 and (an, bn) == (["a1"], ["b1"]) and np.isnan(d)


def test_anchors_from_the_flat_net_are_recomputed(tmp_path, open_ctx, monkeypatch):
    # a checkpoint whose key's chain parameters lack "net" (a flat-net checkpoint) is never reused
    rng = random.Random(4)
    a = write_fasta(tmp_path / "A.fa", {"a1": rand_seq(6000, rng)})
    b = write_fasta(tmp_path / "B.fa", {"b1": rand_seq(6000, rng)})
    route, ctx = _FixedRoute(), open_ctx("A", a, "B", b)
    assert anchor_mod._CHAIN_PARAMS["net"] == "syntenic"
    with monkeypatch.context() as mp:
        mp.setattr(anchor_mod, "_CHAIN_PARAMS", {k: v for k, v in anchor_mod._CHAIN_PARAMS.items() if k != "net"})
        anchor_pair(ctx, route)  # the old checkpoint
    assert route.calls == 1
    anchor_pair(ctx, route)
    assert route.calls == 2  # recomputed
    anchor_pair(ctx, route)
    assert route.calls == 2  # the new checkpoint is reused


def test_get_route(tmp_path):
    r = get_route("mm2")
    assert isinstance(r, Mm2Route) and r.name == "mm2"
    assert get_route("fastga").name == "fastga"
    p = get_route(f"paf:{tmp_path}")
    assert isinstance(p, PafRoute) and p.name == "paf" and p.dirpath == tmp_path
    for bad in ("", "MM2", "minimap2", "paf", "paf:"):
        with pytest.raises(ValueError, match=r"known routes: mm2, fastga, flank-mm2, flank-blast, hybrid, paf:<dir>"):
            get_route(bad)
