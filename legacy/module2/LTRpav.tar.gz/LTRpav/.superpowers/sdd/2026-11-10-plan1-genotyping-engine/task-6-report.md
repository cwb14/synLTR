# Task 6 report: GFF3 reader/writer
Commit c570a24 "Add GFF3 reader/writer for LTRquest and EDTA conventions".
Files: src/ltrpav/annotation/gff3.py, tests/test_annot_gff3.py (annotation/__init__.py untouched).
Implemented per the brief and resolutions: load_gff3 (LTRs as children, else siblings within span; Counter no_ltr_pair; K2P_d else JC69 from ltr_identity, None if p>=0.75; classification split; %XX unescape; gz; ##FASTA stop), write_gff3 (escaped, deterministic gz via mtime=0, empty filename).
Tests (6): real LTRquest lines, EDTA + homology fragment, JC69/escape/FASTA-stop, round trip plain + .gz (k=0.1+0.2 exact), gz determinism + parent/level ignored.
RED: with gff3.py moved away -> ModuleNotFoundError at collection (impl was written before the RED run, then removed to show it). GREEN: 5 passed (new file) before; full suite 22 passed; ruff clean.
Self-review: ltrs sibling match requires containment within element span; elements without Parent or ID-children and not two LTRs are skipped. Name falls back to ID, then eid.
Concerns: none significant. LTRquest family "merged_famNNNNN" is read as family as the brief says.

## Fix round 1
Changes: _attrs now splits raw Parent on commas then unquotes each piece (key `_parents`); FASTA-stop test now has a parseable element+LTRs after ##FASTA and asserts exactly one element; new test_multi_parent_and_escaped_comma (two-parent LTRs; eid with commas round trip).
RED: with the old gff3.py the new test failed (stash of src). GREEN: `pytest tests/test_annot_gff3.py` 6 passed; full suite 23 passed; ruff clean.
Commit: see git log "Fix GFF3 Parent splitting and FASTA-stop test".
