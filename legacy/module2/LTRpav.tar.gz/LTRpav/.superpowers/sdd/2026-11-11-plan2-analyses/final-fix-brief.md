# Plan 2 final fix wave (one dispatch; review: final-review.md)

The final whole-branch review is `final-review.md`, in this directory. It covers 12279a1..4b73977 and its verdict is
"With fixes": 1 Critical, 4 Important, 16 Minor. Read the whole review first; its probe scripts are in
`/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p2final/probes/`.
Turn the relevant probes into pytest fixtures with small synthetic data.

## Where to work
- **The main working tree,** `/data2/chris/maize_introgression/LTRpav`, branch `plan2-analyses`. First,
  `pgrep -af 'ltrpav|run_variant|bakeoff|lastz'` must list no job. If one runs, stop and report.
- **Engine modules stay untouched.** Every fix belongs in `src/ltrpav/analysis/`, `src/ltrpav/plot/`, tests or docs.
  After the last commit, show that all engine stage keys are unchanged: compare `checkpoint.STAGE_MODULES`
  fingerprints at 4b73977 and HEAD.
- **Suite:** after each commit, run `python -m pytest -W error -m "not slow"` and `ruff check .` in the env
  `ltrpav`, with `NUMPY_MADVISE_HUGEPAGE=0`.

## Rulings (controller)

**C1. Inversion caller (inversions.py).**
- Inversions are defined between homologous sequences. Form groups only for syntenic partner pairs: (x, y) where y
  is x's dominant partner by shared loci, or x is y's. This is reciprocal dominance, the rule `overview._partners`
  already uses for "counterpart".
- Move that partner rule into one shared analysis function, so that the overview and the caller use the same
  definition.
- Keep `n_discordant` semantics within a block.
- Add another rule (for example, contiguity on both genomes) only if a toy shows reciprocal dominance leaves a sparse
  artifact. Base it on a reason, never on a density tuned to main3. Give its reason in one line in constants.py.
- Tests, each with expected blocks:
  - a toy with a translocated handful of loci (no block);
  - a real inversion within a homologous pair (found);
  - a reciprocal translocation (both partners kept).
- Update DESIGN 7.7's text if it describes the grouping.

**I1. Age-gradient sign.**
- Read the gradient in the direction of the overall excess: the sister with the excess, sign(D_pav) x dD. Do this in
  trio.py's findings verdict and in overview.py's panel F text, and name whose excess it is.
- Test: D < 0 with a testable gradient (the reviewer's probe_gradient.py as a toy).

**I2 and M13. Never draw from a stats.tsv that lacks a current part.**
- The plot must refuse unless:
  - the stats part is finished, current, and present in stats.tsv itself;
  - the paint part is too, whenever a painting is drawn.
- Do not depend on findings.txt. Replace `left_out_parts` with a check that reads stats.tsv itself, for example one
  sentinel row per assembled part (stage, key), within the existing column schema. read_stats must handle the
  sentinel.
- Refuse a stats.tsv with no sentinels (made by older code) with the same one-line error. The user reruns
  `ltrpav-stats`.
- Tests:
  - paint then plot with no stats stage: refused;
  - a failed stats rerun: refused;
  - a deleted findings.txt: no effect;
  - a current run: draws.

**I3. Panel H scales.**
- Draw every trio, with no selection, readable from 4 up to C(10,3) = 120 trios, with nothing clipped or colliding.
  Use a compact form: for example, one dot-and-interval row per trio, sorted by D, in as many columns as fit, or a
  donor x sister-pair matrix.
- Follow the making-figures skill: `/home/chris/.claude/skills/making-figures/SKILL.md`. Load it with the Skill tool
  before changing any figure code.
- Tests:
  - 6 ingroup genomes (20 trios): renders, no text overlap (check bounding boxes);
  - 9 ingroup genomes (84 trios): renders, exit 0.

**I4, M10 and M5. Headline and short legend.**
- **Wording.** Until Plan 3 calibrates D_pav's null, the significant-and-young wording reads "consistent with gene
  flow from D-like donors into R rather than incomplete lineage sorting alone". Apply the same register to the other
  gene-flow verdicts in the legends and findings.txt.
- **Short legend (skill).** No thresholds, q-values, Z or D values: "none of B73's reach q ≤ 0.05" and "D +0.60 at
  K = 0 against +0.20" become plain biology. The numbers stay on the long legend page.
- **M5.**
  - With several trios, the headline says the lead trio is the strongest of n.
  - An ambiguous sister pair (p_top >= the analysis constant's level) is stated in the headline, not only counted
    among the warnings.

**M1 and M6. Generality text.**
- Fix the genotype-only sister and recipient texts named in M1, including "panels A and A".
- "Chromosomes" becomes "sequences" unless every drawn sequence is a chromosome-scale sequence by the overview's own
  drawing rule. Never match the name "chr".

**M2.**
- The paint stage uses identity.tsv only when the stats part is current (stale_parts). Otherwise it ignores
  identity.tsv and writes a WARNING.
- The stats-part WARNING names its stale side files: identity.tsv, inversions.tsv and mechanisms.tsv.

**M3.** The plot stage deletes its previous overview files before drawing, and leaves none behind on a refusal or a
failure. Test it.

**M4.** `write_paintings` deletes only files named for the run's labels, or those its previous marker lists. Test
with a genome labeled `tracts`.

**M8.** Resuming without `--identity` that removes identity.tsv logs a WARNING naming the file and saying that
`--identity` keeps it.

**M7.** Direction-block fallback ids carry the genome label, so they cannot collide.

**M9.**
- `test_cli_imports_without_scipy`'s import half runs without lastz.
- The legend-honesty tests check the generator's text when pdftotext is absent, and keep the PDF check when it is
  present.
- Add the I1, I2 and I3 tests above.

**M11.** The last legend line gives the script's source path (`inspect.getsourcefile`), not the module name.

**M12.**
- Register font paths sorted, newest Liberation version first, so that the PNG is byte-deterministic on one host.
  Test: two renders give byte-identical PNGs.
- Check `mamba search -c conda-forge` for a Liberation font package.
  - If one exists, add it to environment.yml and refresh the lock by commit 84c8088's portable procedure, never a raw
    `mamba env export`.
  - If none exists, write one WARNING when the figure falls back to another font, and note it in DESIGN.

**M14.** `stale_parts` uses `.get` for marker params. A hand-edited marker reads as stale, never as a KeyError. Test
it.

**M15.**
- The jackknife short-circuits to NaN on a NaN estimate.
- Add tests for:
  - fewer than 2 finite pseudovalues;
  - non-finite pseudovalue dropping;
  - u95 with a multi-element n.
- read_stats' coercion and block_size's unreachable error stay as they are. Record that as documented, not fixed.

**M16.** Move the shared private helpers (`_check_trio`, `_fallback_reasons`, `_first_member`, `_fmt`, `_guard`,
`_why`, `_blocks`, `_patterns`) into one public analysis helper module, without leading underscores. Update the
imports, and keep the analysis fingerprint closure test green.

**Declined to judge (review section):** the controller accepts every line as out of Plan 2's scope. Do not act on
them.

## After all commits: refresh the real-data results
1. Rerun the analyses in the view `/data2/chris/maize_introgression/benchmark_pav/main3_analyses/` with its own
   `run_analyses.sh`, which includes `--identity` at 32 threads.
   - Launch detached from that directory, the same way as before:
     `setsid -f nohup mamba run -n ltrpav bash run_analyses.sh > analyses.log 2>&1 < /dev/null`.
   - Verify the PID: SID = PID, PPID 1.
   - First, keep a copy of the current stats.tsv, findings.txt, inversions.tsv, prelim_papers.tsv, PRELIM.md and
     overview files as `*.pre_wave` in `prelim_tables/`.
   - Wait with a Monitor until-loop, never a foreground sleep.
2. Then:
   - Run `mamba run -n ltrpav python compare_papers.py`.
   - Fold in Task 12's N5: TSV row 57's "3.9x" for LTRmix recent q <= 0.05 shows its counts, 2 of 10 runs, binomial
     p 0.089.
   - Diff prelim_papers.tsv against the pre-wave copy. Explain every changed row in the report: expected changes are
     item 10 (inversions) and the figure's legend wording.
   - Update PRELIM.md wherever a number or statement changed. Item 10 and the Inv4m/Inv1n blocks need a fresh
     account, and the caveat about ruling 7's flag goes, or changes if the flag is dropped.
   - Update the memo's Plan 2 section with the rerun.
3. Snapshot main3 and inputs/*.fai before and after (sizes and mtimes), and confirm nothing changed.
4. Answer the making-figures figure check for the new overview.png (full-resolution crops, legend pages) in
   PRELIM.md section 6.

## Constraints
- **Commits:** one per finding group, plain subjects. Use the existing identity, set nothing, add no trailers or AI
  attribution. The user is the sole author. Never push.
- **Thresholds:** no new CLI option, threshold or constant without a one-line reason and a link to the finding that
  needs it. Thresholds come from principle, never tuned to main3 or the papers.
- **Probes:** at most 16 threads, each under `timeout 15m` in the foreground. Scratch goes only under
  `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p2fix/`.
- **Read-only:** main3/, inputs/, run/, benchmark/ and LTRmix/.
- No subagents. American English.

## Report
- Write `final-fix-report.md` in this directory. If the harness refuses the write, return the text instead. Include:
  - per finding: fixed, partly fixed or skipped, with the commit and the test;
  - the engine-key check;
  - the real-data refresh: changed rows explained, and the new item 10;
  - the figure check;
  - the branch head.
- Return ONLY:
  - the branch head;
  - the commit list;
  - counts of fixed, partly fixed and skipped;
  - one line per Critical or Important finding that is not fully fixed (there should be none);
  - the item-10 summary;
  - the suite line;
  - concerns.
