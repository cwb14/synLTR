#!/usr/bin/env python3
"""Fig. 3 (fig3_benchmark): calibration, power and resolution of LTR-RT-only admixture inference (LTRmix benchmark).

Rebuilds fig3_benchmark.pdf (figure, short legend, long legend), fig3_benchmark.png (300 dpi, figure only) and
fig3_benchmark_numbers.tsv (every legend number with its source). All inputs are read-only.
Cached helpers in data/ (rebuilt when missing or with --rebuild):
  eval_wgk_{all,noLTR}.txt  output of benchmark/scripts/eval_wgk.py (whole-genome / LTR-masked k-mer window r)
  window_null.tsv           circular-shift null of the LTR-only window correlation (same procedure as eval_real.py)
  example_absence.json      base-pair example for panel I (fig3_example.py)
Usage: python fig3_benchmark.py [--rebuild]"""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import argparse
import glob
import json
import os
import re
import subprocess
import sys

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib import font_manager  # noqa: E402
from matplotlib.backends.backend_pdf import PdfPages  # noqa: E402
from matplotlib.collections import LineCollection, PatchCollection  # noqa: E402
from matplotlib.patches import Rectangle, ConnectionPatch, Polygon  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")
STEM = "fig3_benchmark"
R = "/data2/chris/maize_introgression"
BM = f"{R}/benchmark"
SIM = f"{BM}/sim"
MAIN = f"{BM}/results/main3"
EDTA = f"{BM}/edta/out"
EXAMPLE_RUN, NULL_RUN, EX_CHROM = "f0.18_Ta5000_r1", "null_s102", "B_chr6"   # chosen by the rules in pick_examples()

for f in glob.glob("/usr/share/fonts/truetype/liberation2/Liberation*.ttf"):
    font_manager.fontManager.addfont(f)
plt.rcParams.update({
    "font.family": "Liberation Sans", "font.size": 6.5, "pdf.fonttype": 42, "ps.fonttype": 42,
    "axes.linewidth": 0.5, "xtick.major.width": 0.5, "ytick.major.width": 0.5, "xtick.major.size": 2,
    "ytick.major.size": 2, "xtick.labelsize": 6, "ytick.labelsize": 6, "axes.labelsize": 6.5,
    "axes.spines.top": False, "axes.spines.right": False, "lines.linewidth": 0.8, "legend.frameon": False,
    "mathtext.fontset": "custom", "mathtext.rm": "Liberation Sans", "mathtext.it": "Liberation Sans:italic",
    "mathtext.bf": "Liberation Sans:bold"})
MONO = "Liberation Mono"

# colors (fixed across the paper)
MEX, PAR, MAIZE, CTX, ELAI = "#D55E00", "#0072B2", "#333333", "#BBBBBB", "#009E73"
MEX_L, PAR_L = "#F2B48A", "#9CC6E6"
TA_COL = {50.0: "#C6B7E2", 500.0: "#8C6BC0", 5000.0: "#3F1F78"}        # admixture time, light = recent
TESTS = ["D_kmer", "D_ins", "D3_triples", "D_self_outgroup"]
TNAME = {"D_kmer": "k-mers", "D_ins": "insertions", "D3_triples": "triples", "D_self_outgroup": "self-outgroup"}
TCOL = {"D_kmer": "#B0B0B0", "D_ins": "#808080", "D3_triples": "#454545", "D_self_outgroup": "#000000"}
TMARK = {"D_kmer": "o", "D_ins": "s", "D3_triples": "^", "D_self_outgroup": "D"}

NUM = []      # (panel, item, value, source)


def num(panel, item, value, source):
    NUM.append((panel, item, value, source))
    return value


# ----------------------------------------------------------------------------------------------------- data
def load_runs():
    rows = []
    for f in sorted(glob.glob(f"{SIM}/eval/*.json")):
        for line in open(f):
            if line.strip():
                rows.append(json.loads(line.replace("NaN", "null")))
    d = pd.DataFrame(rows)
    d["kind"] = np.select([d.sim.str.startswith("null_"), d.sim.str.startswith("fn"), d.sim.str.startswith("m2_")],
                          ["null", "dropout", "m2"], "power")
    rc = d.recipient_called.fillna(d.get("recipient"))
    sign = np.where(rc == "P", -1.0, 1.0)
    for t in TESTS:
        d[t + "_ZB"] = d[t + "_Z"] * sign          # Z oriented toward the true recipient B
    d["fnB"] = d.fn.apply(lambda x: x[0] if isinstance(x, list) else 0.0)
    d["sisters_ok"] = d.sisters_ok.fillna(True).astype(bool)
    # completeness ratio (called recipient / called sister on the donor's oldest quarter of insertions)
    comp, strat = [], []
    for s in d.sim:
        p = f"{SIM}/out/{s}/stats.tsv"
        if s.startswith("m2_"):
            p = f"{SIM}/out/{s}/B_P_M/stats.tsv"
        st = pd.read_csv(p, sep="\t")
        c = st[st.test == "completeness_ratio"]
        comp.append(float(c.ratio.iloc[0]) if len(c) else np.nan)
        strat.append(c.stratum.iloc[0] if len(c) else "")
    d["completeness"], d["comp_stratum"] = comp, strat
    return d


def truth_segments(run, chrom=None):
    t = pd.read_csv(f"{SIM}/runs/{run}/truth_B.bed", sep="\t", header=None, names=["c", "s", "e"])
    return t if chrom is None else t[t.c == chrom]


def merge(iv):
    out = []
    for s, e in sorted(iv):
        if out and s <= out[-1][1]:
            out[-1][1] = max(out[-1][1], e)
        else:
            out.append([s, e])
    return out


def read_bed(path):
    b = pd.read_csv(path, sep="\t")
    b.columns = [c.lstrip("#") for c in b.columns]
    return b


def pick_examples(runs):
    """Panel A: among f = 0.18, Ta = 5,000 runs, the chromosome whose true introgressed fraction is closest to its
    genome-wide true fraction. Null partner: the same chromosome of the first null replicate (lowest seed) in which
    the tool calls B the recipient, so the same genome is painted. Panel B: the 2-Mb window (0.5-Mb steps) of that
    chromosome whose true fraction is closest to the chromosome's."""
    best = None
    for run in ("f0.18_Ta5000_r1", "f0.18_Ta5000_r2"):
        P = json.load(open(f"{SIM}/runs/{run}/params.json"))
        tr = truth_segments(run)
        for c, g in tr.groupby("c"):
            fr = sum(e - s for s, e in merge(list(zip(g.s, g.e)))) / P["chrom_len"]
            dd = abs(fr - P["true_frac_B"])
            if best is None or dd < best[0]:
                best = (dd, run, c, fr, P["true_frac_B"])
    nulls = runs[(runs.kind == "null") & (runs.recipient_called == "B")].sort_values("seed")
    null_run = nulls.sim.iloc[0]
    _, run, c, fr, gfr = best
    iv = merge(list(zip(*[truth_segments(run, c)[k] for k in ("s", "e")])))
    wins = []
    for w0 in np.arange(0, 18.01e6, 0.5e6):
        w1 = w0 + 2e6
        cov = sum(max(0, min(e, w1) - max(s, w0)) for s, e in iv) / 2e6
        wins.append((abs(cov - fr), w0, w1, cov))
    wins.sort()
    return dict(run=run, chrom=c, frac=fr, genome_frac=gfr, null=null_run, zoom=(wins[0][1], wins[0][2]),
                zoom_frac=wins[0][3])


def window_null(rebuild=False, nperm=1000):
    """Circular-shift null of the window correlation between the LTR-only ancestry posterior and ELAI, exactly as
    eval_real.shift_test (seed 1, 1,000 shifts per chromosome) but keeping the null distribution."""
    path = os.path.join(DATA, "window_null.tsv")
    if os.path.exists(path) and not rebuild:
        return pd.read_csv(path, sep="\t")
    sys.path.insert(0, f"{BM}/scripts")
    from eval_real import load_truth, windows   # read-only import of the benchmark's own functions
    from scipy.stats import spearmanr
    t = load_truth()
    el = pd.read_csv(f"{MAIN}/elements.B73v5.tsv", sep="\t", usecols=["chrom", "start", "end", "post_ancestry_TIL18"])
    el["c"] = el.chrom.str.extract(r"_(chr\d+)$")[0]
    el["len"] = el.end - el.start + 1
    rows = []
    for win in (100_000, 500_000, 1_000_000, 2_000_000, 5_000_000, 10_000_000):
        w = windows(el[el.c.notna()], t, win, "post_ancestry_TIL18", "len")
        ok = w.score.notna() & w.truth.notna()
        r = spearmanr(w.score[ok], w.truth[ok]).correlation
        rng = np.random.default_rng(1)
        null = np.empty(nperm)
        for k in range(nperm):
            parts = [np.roll(g.score.values, rng.integers(1, len(g)) if len(g) > 1 else 0)
                     for _, g in w.groupby("c", sort=False)]
            s = np.concatenate(parts)
            m = ~np.isnan(s) & w.truth.notna().values
            null[k] = spearmanr(s[m], w.truth.values[m]).correlation
        rows.append(dict(win_mb=win / 1e6, r_obs=r, null_lo=np.quantile(null, 0.025), null_hi=np.quantile(null, 0.975),
                         null_max=null.max(), n=int(ok.sum())))
        print(f"window null {win / 1e6:g} Mb: r={r:.3f} null 95% [{rows[-1]['null_lo']:.3f}, "
              f"{rows[-1]['null_hi']:.3f}]", file=sys.stderr)
    out = pd.DataFrame(rows)
    out.to_csv(path, sep="\t", index=False)
    return out


def wgk_r(mode, rebuild=False):
    path = os.path.join(DATA, f"eval_wgk_{mode}.txt")
    if not os.path.exists(path) or rebuild:
        with open(path, "w") as fo:
            subprocess.run([sys.executable, f"{BM}/scripts/eval_wgk.py", f"{BM}/wgk/wgk_{mode}"], stdout=fo, check=True)
    r = {}
    for line in open(path):
        m = re.match(r"window ([\d.]+) Mb: share vs ELAI r=([+-][\d.]+)", line)
        if m:
            r[float(m.group(1))] = float(m.group(2))
    return r, path


def real_windows(path):
    b = pd.read_csv(path, sep="\t")
    out = {}
    for _, x in b[b.section == "windows"].iterrows():
        m = re.match(r"posterior vs ELAI, ([\d.]+) Mb", x["item"])
        if m:
            out[float(m.group(1))] = float(re.match(r"r=([+-][\d.]+)", x["value"]).group(1))
    auc = {}
    for _, x in b[b.section == "elements"].iterrows():
        m = re.match(r"AUROC (ancestry|recent) posterior, ELAI >= ([\d.]+)", x["item"])
        if m:
            auc[(m.group(1), float(m.group(2)))] = float(x["value"])
    return out, auc


def absence_tables():
    rows = []
    for f in sorted(glob.glob(f"{BM}/absence/*.summary.tsv")):
        a, b = os.path.basename(f).split(".")[:2]
        t = pd.read_csv(f, sep="\t").set_index(f"status_in_{b}")
        for st, x in t.iterrows():
            emp, occ = float(x["empty"]), float(x["occupied"])     # x.empty would be the pandas property
            dec = emp + occ
            rows.append(dict(pair=f"{a}>{b}", A=a, B=b, status=st, empty=emp, occupied=occ, both=float(x["both"]),
                             undetermined=float(x["undetermined"]), n=int(x["n"]), frac_decidable=dec,
                             pct_empty_decidable=100 * emp / dec, file=f))
    return pd.DataFrame(rows)


def example_absence(rebuild=False):
    path = os.path.join(DATA, "example_absence.json")
    if not os.path.exists(path) or rebuild:
        subprocess.run([sys.executable, os.path.join(HERE, "fig3_example.py")], check=True)
    return json.load(open(path))


# ----------------------------------------------------------------------------------------------------- layout
W, H = 180.0, 236.0
LETTER_DX, LETTER_DY = 11.5, 4.2      # letter offset from each quantification panel's axes corner (mm)


def ax_mm(fig, x, y, w, h, **kw):
    return fig.add_axes([x / W, 1 - (y + h) / H, w / W, h / H], **kw)


def letter(fig, x, y, s):
    fig.text(x / W, 1 - y / H, s, fontsize=9, fontweight="bold", va="top", ha="left")


def letter_for(fig, x_ax, y_ax, s):
    letter(fig, x_ax - LETTER_DX, y_ax - LETTER_DY, s)


def beeswarm(y, width, ystep):
    """Deterministic horizontal offsets so points with close y values sit side by side."""
    y = np.asarray(y, float)
    off = np.zeros(len(y))
    placed = []
    for i in np.argsort(y):
        k = 0
        while True:
            cands = [0.0] if k == 0 else [k * width, -k * width]
            hit = None
            for c in cands:
                if all(abs(y[i] - y[j]) >= ystep or abs(c - off[j]) >= width * 0.99 for j in placed):
                    hit = c
                    break
            if hit is not None:
                off[i] = hit
                break
            k += 1
        placed.append(i)
    return off


def mm_text_width(fig, s, size, **kw):
    r = fig.canvas.get_renderer()
    t = fig.text(0, 0, s, fontsize=size, **kw)
    w = t.get_window_extent(r).width / fig.dpi * 25.4
    t.remove()
    return w


def key_row(fig, x, y, items, size=6.0, gap=3.2):
    """Draw key items left to right at (x, y) mm; kinds: box, tick, line, fbox, obox, dot, odot, marker."""
    for it in items:
        kind, col, s = it[:3]
        X = lambda v: v / W  # noqa: E731
        Y = lambda v: 1 - v / H  # noqa: E731
        if kind == "box":
            fig.patches.append(Rectangle((X(x), Y(y + 0.75)), 3.0 / W, 1.5 / H, fc=col, ec="none",
                                         transform=fig.transFigure, figure=fig))
            w0 = 3.6
        elif kind == "tick":
            fig.lines.append(Line2D([X(x + 0.8)] * 2, [Y(y - 1.1), Y(y + 1.1)], color=col, lw=1.1,
                                    transform=fig.transFigure))
            w0 = 2.2
        elif kind == "line":
            fig.lines.append(Line2D([X(x), X(x + 3.2)], [Y(y)] * 2, color=col, lw=it[3] if len(it) > 3 else 0.9,
                                    transform=fig.transFigure))
            w0 = 3.8
        elif kind in ("fbox", "obox"):
            fig.patches.append(Rectangle((X(x), Y(y + 0.75)), 3.0 / W, 1.5 / H, fc=col if kind == "fbox" else "white",
                                         ec="black", lw=0.4, transform=fig.transFigure, figure=fig))
            w0 = 3.6
        else:  # marker: (kind='marker', facecolor, label, marker, edgecolor)
            mk, ec = it[3], it[4]
            fig.lines.append(Line2D([X(x + 0.9)], [Y(y)], marker=mk, ms=3.2, mfc=col, mec=ec, mew=0.6, ls="none",
                                    transform=fig.transFigure))
            w0 = 2.4
        fig.text(X(x + w0), Y(y), s, fontsize=size, va="center", ha="left")
        x += w0 + mm_text_width(fig, s, size) + gap
    return x


# ----------------------------------------------------------------------------------------------------- panel A/B
CLASS_Y = {"near_donor": (MEX, 1.0), "donor_only": (MEX_L, 0.6), "near_sister": (PAR, -1.0),
           "sister_only": (PAR_L, -0.6)}
Y_TRUTH, Y_EL, Y_PA, Y_PR, Y_TR = 7.45, 5.55, 2.85, 1.05, 0.35     # track baselines (data units)
H_POST = 1.45


def paint_run(ax, run, chrom, x0, x1, boxes=False):
    e = pd.read_csv(f"{SIM}/out/{run}/elements.B.tsv", sep="\t")
    e = e[(e.chrom == chrom) & (e.end >= x0) & (e.start <= x1)].sort_values("start")
    mid = ((e.start + e.end) / 2 / 1e6).values
    tr = truth_segments(run, chrom)
    ax.plot([x0 / 1e6, x1 / 1e6], [Y_TRUTH, Y_TRUTH], color=CTX, lw=0.4, zorder=0)
    for s, en in merge(list(zip(tr.s, tr.e))) if len(tr) else []:
        if en >= x0 and s <= x1:
            ax.add_patch(Rectangle((s / 1e6, Y_TRUTH - 0.38), (en - s) / 1e6, 0.76, fc=MEX, ec="none", lw=0))
    other = ~e["class"].isin(CLASS_Y).values
    if boxes:
        pats, cols = [], []
        for st_, en_, cl in zip(e.start.values, e.end.values, e["class"].values):
            col, h = CLASS_Y.get(cl, (CTX, 0.0))
            if h == 0:
                pats.append(Rectangle((st_ / 1e6, Y_EL - 0.2), (en_ - st_) / 1e6, 0.4))
            else:
                y0 = Y_EL + 0.1 if h > 0 else Y_EL - 0.1 - abs(h)
                pats.append(Rectangle((st_ / 1e6, y0), (en_ - st_) / 1e6, abs(h)))
            cols.append(col)
        ax.add_collection(PatchCollection(pats, facecolors=cols, edgecolors="none", linewidths=0))
    else:
        segs, cols = [], []
        for cl, (col, h) in CLASS_Y.items():
            m = (e["class"] == cl).values
            y0 = Y_EL + (0.1 if h > 0 else -0.1)
            segs += [[(x, y0), (x, Y_EL + h + (0.1 if h > 0 else -0.1))] for x in mid[m]]
            cols += [col] * int(m.sum())
        segs += [[(x, Y_EL - 0.2), (x, Y_EL + 0.2)] for x in mid[other]]
        cols += [CTX] * int(other.sum())
        ax.add_collection(LineCollection(segs, colors=cols, linewidths=0.22))
    for col_, y0, c in (("post_ancestry_M", Y_PA, "black"), ("post_recent_M", Y_PR, "#666666")):
        for yy in (y0, y0 + H_POST):
            ax.plot([x0 / 1e6, x1 / 1e6], [yy, yy], color="#E4E4E4", lw=0.3, zorder=0)
        ax.plot(mid, y0 + e[col_].values * H_POST, color=c, lw=0.42, solid_joinstyle="round", zorder=2)
    b = read_bed(f"{SIM}/out/{run}/ancestry.B.bed")
    b = b[(b.chrom == chrom) & (b.end >= x0) & (b.start0 <= x1)]
    for _, r in b.iterrows():
        conf = r.q <= 0.05
        ax.add_patch(Rectangle((r.start0 / 1e6, Y_TR - 0.3), (r.end - r.start0) / 1e6, 0.6,
                               fc="black" if conf else "white", ec="black", lw=0.3, zorder=3 if conf else 2))
    ax.set_xlim(x0 / 1e6, x1 / 1e6)
    ax.set_ylim(-0.05, Y_TRUTH + 1.75)
    ax.set_yticks([])
    for s in ("left", "top", "right"):
        ax.spines[s].set_visible(False)
    return e, b


def track_labels(ax, small=False):
    T = ax.get_yaxis_transform()
    kw = dict(transform=T, ha="right", va="center", fontsize=6)
    ax.text(-0.006, Y_TRUTH, "true donor DNA", **kw)
    ax.text(-0.006, Y_EL + 0.55, "to donor", color=MEX, **kw)
    ax.text(-0.006, Y_EL - 0.55, "to sister", color=PAR, **kw)
    ax.text(-0.006, Y_PA + 0.72, "ancestry", **kw)
    ax.text(-0.006, Y_PR + 0.72, "recent sharing", **kw)
    ax.text(-0.006, Y_TR, "tracts", **kw)
    if not small:
        ax.text(1.004, Y_PA + H_POST, "1", transform=T, ha="left", va="center", fontsize=5, color="#888888")
        ax.text(1.004, Y_PA, "0", transform=T, ha="left", va="center", fontsize=5, color="#888888")


# ----------------------------------------------------------------------------------------------------- figure
def build(rebuild=False):
    os.makedirs(DATA, exist_ok=True)
    runs = load_runs()
    ex = pick_examples(runs)
    assert (ex["run"], ex["null"], ex["chrom"]) == (EXAMPLE_RUN, NULL_RUN, EX_CHROM), ex
    ss = pd.read_csv(f"{SIM}/sim_summary.tsv", sep="\t", keep_default_na=False, na_values=[""])
    wnull = window_null(rebuild)
    r_wg, p_wg = wgk_r("all", rebuild)
    r_nl, p_nl = wgk_r("noLTR", rebuild)
    r_lib, auc_lib = real_windows(f"{MAIN}/benchmark_real.tsv")
    r_edta, auc_edta = real_windows(f"{EDTA}/benchmark_real.tsv")
    absn = absence_tables()
    exa = example_absence(rebuild)
    st_real = pd.read_csv(f"{MAIN}/stats.tsv", sep="\t")
    comp_real = st_real[st_real.test == "completeness_ratio"].iloc[0]
    V = {}                                   # values quoted in the legends
    rj = runs.set_index("sim")
    nul = runs[runs.kind == "null"]
    pw = runs[runs.kind == "power"]

    fig = plt.figure(figsize=(W / 25.4, H / 25.4))
    fig.canvas.draw()
    LX = 24.0
    TW = 178.0 - LX

    # ---------------- key for A and B
    key_row(fig, LX, 2.2, [("box", MEX, "true donor segment"), ("tick", MEX, "near-identical to donor"),
                           ("tick", MEX_L, "donor-only insertion"), ("tick", PAR, "near-identical to sister"),
                           ("tick", PAR_L, "sister-only insertion"), ("tick", CTX, "uninformative")])
    key_row(fig, LX, 5.8, [("line", "black", "donor-like posterior: ancestry model", 0.8),
                           ("line", "#666666", "recent-sharing model", 0.8),
                           ("fbox", "black", "tract, q ≤ 0.05"), ("obox", "black", "tract, q > 0.05")], gap=5.0)
    letter(fig, 0, 1.0, "A")

    # ---------------- A: null (top) and gene flow (bottom), same chromosome, same scale
    yA = 14.0
    hrun = 24.5
    gapA = 1.0
    axN = ax_mm(fig, LX, yA, TW, hrun)
    eN, bN = paint_run(axN, ex["null"], ex["chrom"], 0, 20e6)
    axG = ax_mm(fig, LX, yA + hrun + gapA, TW, hrun)
    eG, bG = paint_run(axG, ex["run"], ex["chrom"], 0, 20e6)
    for ax in (axN, axG):
        track_labels(ax)
    axN.xaxis.set_ticks_position("top")
    axN.spines["bottom"].set_visible(False)
    axN.spines["top"].set_visible(True)
    axN.set_xticks(range(0, 21, 2))
    axN.tick_params(axis="x", pad=1.2)
    axN.text(-0.006, 1.0, "Mb", transform=axN.transAxes, ha="right", va="bottom", fontsize=6)
    axG.set_xticks(range(0, 21, 2))
    axG.tick_params(axis="x", labelbottom=False, length=1.5)
    axN.text(10, Y_TRUTH, "none", ha="center", va="center", fontsize=6, color="#777777",
             bbox=dict(fc="white", ec="none", pad=0.5))
    axN.text(0.0, Y_TRUTH + 0.95, "no gene flow (null run)", ha="left", va="center", fontsize=6.5,
             fontweight="bold")
    axG.text(0.0, Y_TRUTH + 0.95, "gene flow", ha="left", va="center", fontsize=6.5, fontweight="bold")
    axG.text(1.62, Y_TRUTH + 0.95, f"f = 0.18, admixture 5,000 generations ago; true donor fraction of this "
             f"chromosome {ex['frac']:.3f}", ha="left", va="center", fontsize=6.2)
    z0, z1 = ex["zoom"]
    axG.add_patch(Rectangle((z0 / 1e6, -0.05), (z1 - z0) / 1e6, Y_TRUTH + 0.5, fc="none", ec="#555555", lw=0.6,
                            zorder=5, clip_on=False))

    # ---------------- B: zoom of the gene-flow chromosome, every element drawn to size
    yB = yA + 2 * hrun + gapA + 8.5
    hB = 21.0
    axB = ax_mm(fig, LX, yB, 118.0 - LX, hB)      # ends left of the zoom box so the connector clears letter C
    eB, bB = paint_run(axB, ex["run"], ex["chrom"], z0, z1, boxes=True)
    track_labels(axB, small=True)
    axB.set_xticks(np.arange(z0 / 1e6, z1 / 1e6 + 0.01, 0.25))
    axB.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, p: f"{v:.2f}".rstrip("0").rstrip(".")))
    axB.tick_params(axis="x", pad=1.2)
    axB.text(-0.022, -0.02, "Mb", transform=axB.transAxes, ha="right", va="top", fontsize=6)
    for xa, xb in ((z0 / 1e6, 0.0), (z1 / 1e6, 1.0)):
        fig.add_artist(ConnectionPatch(xyA=(xa, -0.05), coordsA=axG.transData, xyB=(xb, 1.0), coordsB=axB.transAxes,
                                       color="#888888", lw=0.4))
    letter(fig, 0, yB - LETTER_DY, "B")

    # numbers A/B
    num("A", "example run / chromosome", f"{ex['run']} {ex['chrom']}", "sim/runs/*/truth_B.bed, params.json")
    num("A", "true donor fraction of the chromosome / of the genome", f"{ex['frac']:.4f} / {ex['genome_frac']:.4f}",
        f"sim/runs/{ex['run']}/truth_B.bed, params.json")
    num("A", "null partner run", ex["null"], "sim/eval/null_s1*.json (first seed with recipient_called = B)")
    P_ = json.load(open(f"{SIM}/runs/{ex['run']}/params.json"))
    num("A", "simulated genome: chromosomes x length; elements in B / P / M", f"{P_['nchrom']} x {P_['chrom_len'] / 1e6:g} Mb; "
        f"{P_['n_elements']['B']} / {P_['n_elements']['P']} / {P_['n_elements']['M']}", f"sim/runs/{ex['run']}/params.json")
    n_b73 = sum(1 for _ in open(f"{MAIN}/elements.B73v5.tsv")) - 1
    num("A", "B73 library elements (simulated B / B73)", f"{n_b73} ({P_['n_elements']['B'] / n_b73:.2f})",
        "results/main3/elements.B73v5.tsv")
    for e_, b_, nm in ((eG, bG, "gene flow"), (eN, bN, "null")):
        num("A", f"{nm}: elements on chr6 (near_donor, donor_only, near_sister, sister_only)",
            f"{len(e_)} ({', '.join(str(int((e_['class'] == c).sum())) for c in CLASS_Y)})",
            "sim/out/*/elements.B.tsv")
        num("A", f"{nm}: ancestry tracts on chr6 (at q<=0.05)", f"{len(b_)} ({int((b_.q <= 0.05).sum())})",
            "sim/out/*/ancestry.B.bed")
    for s_, nm in ((ex["run"], "gene flow"), (ex["null"], "null")):
        stx = pd.read_csv(f"{SIM}/out/{s_}/stats.tsv", sep="\t")
        h_ = stx[stx.test == "hmm_ancestry"].iloc[0]
        hr_ = stx[stx.test == "hmm_recent"].iloc[0]
        V[f"tr_{nm}"] = (int(h_.n_tracts), int(h_.n_decoy_tracts), int(h_.n_tracts_q05))
        V[f"rec_{nm}"] = (float(hr_.posterior_mean), int(hr_.n_tracts))
        num("A", f"{nm}: genome-wide ancestry tracts / decoy tracts / at q<=0.05",
            "{} / {} / {}".format(*V[f"tr_{nm}"]), f"sim/out/{s_}/stats.tsv hmm_ancestry")
        num("A", f"{nm}: recent-sharing posterior mean / tracts", f"{V[f'rec_{nm}'][0]:.3f} / {V[f'rec_{nm}'][1]}",
            f"sim/out/{s_}/stats.tsv hmm_recent")
    V["auc_ex"] = num("A", "gene flow: element AUROC (ancestry posterior)", round(rj.loc[ex["run"], "auc_ancestry"], 3),
                      f"sim/eval/{ex['run']}.json")
    nq_ = int(rj.loc[ex["run"], "ancestry_n_called_q05"])
    nf_ = int(round(rj.loc[ex["run"], "ancestry_tract_fdr_q05"] * nq_))
    V["conf_ok"] = (nq_ - nf_, nq_, rj.loc[ex["run"], "ancestry_bp_precision_q05"])
    num("A", "gene flow: confident tracts overlapping a true segment / all; bp precision", "{} / {}; {:.2f}".format(*V["conf_ok"]),
        f"sim/eval/{ex['run']}.json ancestry_tract_fdr_q05, ancestry_bp_precision_q05")
    V["auc_r2"] = num("A", "other f0.18 Ta5000 replicate: AUROC / confident tracts",
                      f"{rj.loc['f0.18_Ta5000_r2', 'auc_ancestry']:.2f} / "
                      f"{int(rj.loc['f0.18_Ta5000_r2', 'ancestry_n_q05'])}", "sim/eval/f0.18_Ta5000_r2.json")
    iv = [(s, e) for s, e in merge(list(zip(*[truth_segments(ex["run"], ex["chrom"])[k] for k in ("s", "e")])))
          if e > z0 and s < z1]
    any_tr = [any((r.end > s) and (r.start0 < en) for _, r in bB.iterrows()) for s, en in iv]
    V["zoom"] = (len(iv), sum(any_tr), int((bB.q <= 0.05).sum()), sum(1 for s, e in iv if e - s < 50_000),
                 sum(1 for (s, e), h in zip(iv, any_tr) if e - s < 50_000 and h),
                 sum(1 for s, e in iv if e - s >= 50_000), sum(1 for (s, e), h in zip(iv, any_tr) if e - s >= 50_000 and h))
    num("B", "zoom window (Mb); true donor fraction", f"{z0 / 1e6:.1f}-{z1 / 1e6:.1f}; {ex['zoom_frac']:.3f}",
        f"sim/runs/{ex['run']}/truth_B.bed")
    num("B", "zoom: true segments / overlapped by any tract / confident tracts", "{} / {} / {}".format(*V["zoom"][:3]),
        "truth_B.bed, ancestry.B.bed")
    num("B", "zoom: segments <50 kb (overlapped); >=50 kb (overlapped)", "{} ({}); {} ({})".format(*V["zoom"][3:]),
        "truth_B.bed, ancestry.B.bed")
    g5 = pw[(pw.Ta == 5000.0) & (pw.ancestry_n_q05 > 0) & pw.sisters_ok]
    V["rec5"] = (g5["ancestry_recall_lt50k_q05"].min(), g5["ancestry_recall_lt50k_q05"].max(),
                 g5["ancestry_recall_200k-1M_q05"].min(), g5["ancestry_recall_200k-1M_q05"].max(),
                 g5.ancestry_bp_precision_q05.min(), g5.ancestry_bp_precision_q05.max(), len(g5),
                 int(((pw.Ta == 5000.0) & pw.sisters_ok).sum()))
    num("B", "Ta=5000 runs with confident tracts: recall <50 kb; 200 kb-1 Mb; bp precision (runs)",
        "{:.2f}-{:.2f}; {:.2f}-{:.2f}; {:.2f}-{:.2f} ({} of {})".format(*V["rec5"]),
        "sim/eval/f*_Ta5000_r*.json ancestry_recall_*_q05, ancestry_bp_precision_q05")
    lens = []
    for s_ in pw[pw.Ta == 5000.0].sim:
        t_ = truth_segments(s_)
        for c, g in t_.groupby("c"):
            lens += [e - s for s, e in merge(list(zip(g.s, g.e)))]
    V["seg_med"] = num("B", "median true segment length, Ta=5000 runs (kb)", round(np.median(lens) / 1e3, 1),
                       "sim/runs/f*_Ta5000_r*/truth_B.bed")

    # ---------------- C: element AUROC by admixture time, with the real B73-vs-ELAI value
    xC, wC = 140.0, 38.0
    axC = ax_mm(fig, xC, yB, wC, hB)
    p = pw[pw.auc_ancestry.notna()]
    V["auc"] = {}
    for i, ta in enumerate((50.0, 500.0, 5000.0)):
        g = p[p.Ta == ta]
        off = beeswarm(g.auc_ancestry.values, 0.11, 0.014)
        axC.scatter(i + off, g.auc_ancestry, s=6, color=TA_COL[ta], edgecolor="none", zorder=3)
        V["auc"][ta] = (g.auc_ancestry.min(), g.auc_ancestry.median(), g.auc_ancestry.max(), len(g))
        num("C", f"element AUROC, admixture {int(ta)} generations ago: min / median / max (n runs)",
            "{:.2f} / {:.2f} / {:.2f} ({})".format(*V["auc"][ta]), "sim/eval/f*_Ta*_r*.json auc_ancestry")
    for xx, aa, fc, nm in ((3.3, auc_lib, MAIZE, "library"), (3.8, auc_edta, "white", "EDTA")):
        lo_, hi_ = aa[("ancestry", 1.0)], aa[("ancestry", 1.5)]
        axC.plot([xx, xx], [lo_, hi_], color=MAIZE, lw=0.6, zorder=2)
        axC.scatter([xx, xx], [lo_, hi_], s=9, marker="o", facecolor=fc, edgecolor=MAIZE, lw=0.6, zorder=3)
        num("C", f"real B73 element AUROC vs ELAI ({nm}): ELAI>=1.0 / >=1.5 vs <=0.2", f"{lo_:.4f} / {hi_:.4f}",
            "results/main3/benchmark_real.tsv" if nm == "library" else "edta/out/benchmark_real.tsv")
    axC.axhline(0.5, color="#888888", lw=0.5, ls=(0, (2, 2)), zorder=0)
    axC.axvline(2.68, color="#DDDDDD", lw=0.5)
    axC.set_xlim(-0.5, 4.2)
    axC.set_ylim(0.45, 1.04)
    axC.set_xticks([0, 1, 2, 3.55])
    axC.set_xticklabels(["50", "500", "5,000", "B73 vs\nELAI"])
    axC.set_yticks([0.5, 0.75, 1.0])
    axC.set_ylabel("element AUROC", labelpad=1.5)
    axC.set_xlabel("admixture, generations ago", labelpad=1.5)
    axC.text(4.15, 0.508, "chance", ha="right", va="bottom", fontsize=5.5, color="#777777")
    axC.scatter([2.95], [0.985], s=9, facecolor=MAIZE, edgecolor=MAIZE, lw=0.6)
    axC.text(3.1, 0.985, "library", fontsize=5.5, va="center")
    axC.scatter([2.95], [0.925], s=9, facecolor="white", edgecolor=MAIZE, lw=0.6)
    axC.text(3.1, 0.925, "EDTA", fontsize=5.5, va="center")
    letter_for(fig, xC, yB, "C")

    # ---------------- D: calibration and power, every run a point
    yD = yB + hB + 13.5
    hD = 29.0
    gD = 2.8
    xD0 = 13.0
    wD = (128.0 - xD0 - 3 * gD) / 4
    axD = []
    for i, t in enumerate(TESTS):
        ax = ax_mm(fig, xD0 + i * (wD + gD), yD, wD, hD)
        axD.append(ax)
        ax.axhspan(-1.96, 1.96, color="#EBEBEB", lw=0, zorder=0)
        ax.axhline(3, color="#888888", lw=0.5, ls=(0, (2, 2)), zorder=1)
        ax.axhline(0, color="#CFCFCF", lw=0.4, zorder=1)
        off = beeswarm(nul[t + "_ZB"].values, 0.0105, 0.3)
        ax.scatter(off, nul[t + "_ZB"], s=4, facecolor="#8C8C8C", edgecolor="none", zorder=3)
        for ok in (True, False):
            g = pw[pw.sisters_ok == ok]
            cols = [TA_COL[x] for x in g.Ta]
            ax.scatter(g.true_frac, g[t + "_ZB"], s=7, facecolor=cols if ok else "white", edgecolor=cols,
                       lw=0 if ok else 0.6, zorder=4)
        ax.set_xlim(-0.04, 0.62)
        ax.set_ylim(-4.2, 14.5)
        ax.set_xticks([0, 0.2, 0.4, 0.6])
        ax.set_xticklabels(["0", "0.2", "0.4", "0.6"])
        ax.set_yticks([-3, 0, 3, 6, 9, 12])
        if i:
            ax.set_yticklabels([])
        ax.text(0.5, 1.0, TNAME[t], transform=ax.transAxes, ha="center", va="bottom", fontsize=6.5)
        srow = ss[(ss.table == "null") & (ss.test == t)].iloc[0]
        assert abs(srow.mean_Z - nul[t + "_ZB"].mean()) < 1e-6 and abs(srow.sd_Z - nul[t + "_ZB"].std()) < 1e-6
        num("D", f"null mean Z / SD / max|Z| ({TNAME[t]})",
            f"{nul[t + '_ZB'].mean():+.2f} / {nul[t + '_ZB'].std():.2f} / {nul[t + '_ZB'].abs().max():.2f}",
            "sim/sim_summary.tsv table=null; sim/eval/null_s1*.json")
    V["null_mean"] = [nul[t + "_ZB"].mean() for t in TESTS]
    V["null_sd"] = [nul[t + "_ZB"].std() for t in TESTS]
    V["null_max"] = max(nul[t + "_ZB"].abs().max() for t in TESTS)
    ok_ = pw[pw.sisters_ok]
    hi_ = ok_[ok_.true_frac >= 0.17]
    mid_ = ok_[(ok_.true_frac >= 0.09) & (ok_.true_frac < 0.17)]
    V["pow_hi"] = (int((hi_[[t + "_ZB" for t in TESTS]] > 3).all(axis=1).sum()), len(hi_))
    V["pow_mid"] = (int((mid_[[t + "_ZB" for t in TESTS]] > 3).all(axis=1).sum()),
                    int((mid_[[t + "_ZB" for t in TESTS]] > 3).any(axis=1).sum()), len(mid_))
    V["pow_lo"] = int((ok_[ok_.true_frac < 0.09][[t + "_ZB" for t in TESTS]] > 3).any(axis=1).sum())
    V["n_lo"] = int((ok_.true_frac < 0.09).sum())
    num("D", "runs with true fraction >=0.17 (sisters ok): Z>3 in all tests / n", "{} / {}".format(*V["pow_hi"]),
        "sim/eval/f*_Ta*_r*.json")
    num("D", "runs with true fraction 0.09-0.17: Z>3 in all / in any test / n", "{} / {} / {}".format(*V["pow_mid"]),
        "sim/eval/f*_Ta*_r*.json")
    num("D", "runs with true fraction <0.09: Z>3 in any test / n", f"{V['pow_lo']} / {V['n_lo']}",
        "sim/eval/f*_Ta*_r*.json")
    num("D", "null runs with |Z|>3 (any test)", int((nul[[t + "_ZB" for t in TESTS]].abs() > 3).any(axis=1).sum()),
        "sim/eval/null_s1*.json")
    num("D", "null runs with a confident tract (ancestry / recent)",
        f"{int((nul.ancestry_n_q05 > 0).sum())} / {int((nul.recent_n_q05 > 0).sum())}", "sim/eval/null_s1*.json")
    fl = pw[~pw.sisters_ok]
    V["flip"] = (len(fl), fl.true_frac.min(), fl.true_frac.max(),
                 fl[[t + "_ZB" for t in TESTS]].abs().min().min(), fl[[t + "_ZB" for t in TESTS]].abs().max().max())
    num("D", "runs recasting the recipient as the donor's sister: n, true fractions, |Z| range",
        f"{len(fl)}; {', '.join(f'{x:.2f}' for x in sorted(fl.true_frac))}; {V['flip'][3]:.1f}-{V['flip'][4]:.1f}",
        "sim/eval/*.json sisters_ok")
    fig.text(((xD0 + 128.0) / 2) / W, 1 - (yD + hD + 5.2) / H, "true donor-ancestry fraction of the recipient",
             ha="center", va="top", fontsize=6.5)
    axD[0].set_ylabel("Z, extra donor sharing\nof the recipient", labelpad=1.0)
    axD[0].text(0.6, 3.25, "Z = 3", ha="right", va="bottom", fontsize=5.5, color="#777777")
    axD[0].text(0.6, -1.8, "95% of chance", ha="right", va="bottom", fontsize=5.5, color="#777777")
    key_row(fig, xD0 + 4.0, yD + hD + 11.3, [("marker", "#8C8C8C", "null runs", "o", "none"),
                                       ("marker", TA_COL[50.0], "50", "o", "none"),
                                       ("marker", TA_COL[500.0], "500", "o", "none"),
                                       ("marker", TA_COL[5000.0], "5,000 generations ago", "o", "none"),
                                       ("marker", "white", "recipient recast as the donor's sister", "o", "#555555")],
            size=5.8, gap=2.4)
    letter_for(fig, xD0, yD, "D")

    # ---------------- E: admixture fraction, estimate vs truth
    xE, wE = 140.0, 38.0
    axE = ax_mm(fig, xE, yD, wE, hD)
    axE.plot([0, 0.62], [0, 0.62], color="#888888", lw=0.5, ls=(0, (2, 2)), zorder=0)
    three = runs[runs.kind.isin(["null", "power"])]
    for ok in (True, False):
        g = three[three.sisters_ok == ok]
        axE.scatter(g.true_frac, g.f_low, s=6, facecolor="#9A9A9A" if ok else "white", edgecolor="#9A9A9A",
                    lw=0 if ok else 0.6, zorder=2)
    m2 = runs[runs.kind == "m2"].sort_values("true_frac")
    axE.errorbar(m2.true_frac, m2.f_ratio_ins, yerr=2 * m2.f_ratio_ins_SE, fmt="none", ecolor=MAIZE, elinewidth=0.5,
                 capsize=0, zorder=3)
    axE.scatter(m2.true_frac, m2.f_ratio_ins, s=9, marker="s", facecolor="white", edgecolor=MAIZE, lw=0.6, zorder=4)
    axE.scatter(m2.true_frac, m2.f_ratio_identity, s=10, marker="o", facecolor=MAIZE, edgecolor="none", zorder=5)
    axE.set_xlim(-0.02, 0.62)
    axE.set_ylim(-0.02, 0.62)
    axE.set_xticks([0, 0.2, 0.4, 0.6])
    axE.set_yticks([0, 0.2, 0.4, 0.6])
    axE.set_xticklabels(["0", "0.2", "0.4", "0.6"])
    axE.set_yticklabels(["0", "0.2", "0.4", "0.6"])
    axE.set_xlabel("true donor-ancestry fraction", labelpad=1.5)
    axE.set_ylabel("estimated fraction", labelpad=1.5)
    axE.text(0.615, 0.6, "1:1", ha="right", va="top", fontsize=5.5, color="#777777")
    kk = [(0.585, "o", MAIZE, MAIZE, "f-ratio, 2 donor genomes"), (0.535, "s", "white", MAIZE, "same, insertions ± 2 SE"),
          (0.485, "o", "#9A9A9A", "#9A9A9A", "lower bound, 1 donor")]
    for yy, mk, fc, ec, s_ in kk:
        axE.scatter([0.01], [yy], s=9, marker=mk, facecolor=fc, edgecolor=ec, lw=0.6)
        axE.text(0.035, yy, s_, fontsize=5.5, va="center")
    letter_for(fig, xE, yD, "E")
    for _, x in m2.iterrows():
        num("E", f"{x.sim}: true fraction; f-ratio identity; f-ratio insertions +- SE",
            f"{x.true_frac:.3f}; {x.f_ratio_identity:.3f}; {x.f_ratio_ins:.3f} +- {x.f_ratio_ins_SE:.3f}",
            f"sim/eval/{x.sim}.json")
    g = three[(three.true_frac > 0.05) & three.sisters_ok]
    rat_ = g.f_low / g.true_frac
    V["flow"] = (rat_.median(), rat_.quantile(0.1), rat_.quantile(0.9), len(g))
    num("E", "identity bound / truth (3 genomes, true fraction > 0.05, sisters ok): median (10-90%), n",
        "{:.2f} ({:.2f}-{:.2f}), {}".format(*V["flow"]), "sim/eval/*.json f_low, true_frac")
    V["flow_null"] = num("E", "identity bound in null runs: max", round(three[three.kind == "null"].f_low.max(), 3),
                         "sim/eval/null_s1*.json f_low")

    # ---------------- F: window correlation with ELAI vs window size (real trio)
    yF = yD + hD + 20.5
    hF = 28.0
    xF, wF = 13.0, 42.0
    axF = ax_mm(fig, xF, yF, wF, hF)
    ws = [0.1, 0.5, 1.0, 2.0, 5.0, 10.0]
    axF.fill_between(wnull.win_mb, wnull.null_lo, wnull.null_hi, color="#E8E8E8", lw=0, zorder=0)
    axF.axhline(0, color="#BBBBBB", lw=0.4, zorder=0)
    series = [(r_wg, "#9A9A9A", "-", "o", "whole genome"), (r_nl, "#9A9A9A", (0, (2, 1.5)), "s", "LTR-RTs masked"),
              (r_lib, MAIZE, "-", "o", "LTR-RT library"), (r_edta, MAIZE, (0, (2, 1.5)), "o", "EDTA LTR-RTs")]
    for rr, col, ls, mk, nm in series:
        y = [rr[w] for w in ws]
        axF.plot(ws, y, color=col, ls=ls, lw=0.8, zorder=3)
        axF.scatter(ws, y, s=6, marker=mk, facecolor="white" if nm.startswith("EDTA") else col, edgecolor=col,
                    lw=0.6, zorder=4)
    axF.set_xscale("log")
    axF.set_xticks(ws)
    axF.set_xticklabels(["0.1", "0.5", "1", "2", "5", "10"])
    axF.xaxis.set_minor_locator(matplotlib.ticker.NullLocator())
    axF.set_xlim(0.08, 12.5)
    axF.set_ylim(-0.05, 0.62)
    axF.set_yticks([0, 0.2, 0.4])
    axF.set_xlabel("window (Mb)", labelpad=1.5)
    axF.set_ylabel("correlation with ELAI\nmexicana ancestry", labelpad=1.0)
    hl = [Line2D([], [], color=c, ls=ls, marker=mk, ms=2.4, mfc="white" if nm.startswith("EDTA") else c, mec=c, lw=0.8)
          for _, c, ls, mk, nm in series]
    axF.legend(hl, [s_[4] for s_ in series], loc="upper left", fontsize=5.5, handlelength=2.3, borderaxespad=0.0,
               labelspacing=0.2, ncol=2, columnspacing=0.8, handletextpad=0.4, bbox_to_anchor=(0.0, 1.04))
    axF.text(0.09, 0.075, "shuffled windows", ha="left", va="center", fontsize=5.5, color="#777777")
    letter_for(fig, xF, yF, "F")
    for w in ws:
        num("F", f"window r at {w:g} Mb: library / whole genome / LTR-masked / EDTA",
            f"{r_lib[w]:.3f} / {r_wg[w]:.3f} / {r_nl[w]:.3f} / {r_edta[w]:.3f}",
            f"results/main3/benchmark_real.tsv; {os.path.relpath(p_wg, BM)}; {os.path.relpath(p_nl, BM)}; "
            "edta/out/benchmark_real.tsv")
        nr = wnull[np.isclose(wnull.win_mb, w)].iloc[0]
        assert abs(nr.r_obs - r_lib[w]) < 0.0015, (w, nr.r_obs, r_lib[w])
        assert nr.null_max < nr.r_obs, (w, nr.null_max, nr.r_obs)
        num("F", f"circular-shift null 95% range at {w:g} Mb", f"{nr.null_lo:+.3f} to {nr.null_hi:+.3f}",
            "figures/fig3_benchmark/data/window_null.tsv")
    n_lib = sum(1 for _ in open(f"{MAIN}/elements.B73v5.tsv")) - 1
    n_edta = sum(1 for _ in open(f"{EDTA}/elements.B73v5.tsv")) - 1
    V["edta_frac"] = num("F", "B73 elements: EDTA / LTRquest library (ratio)", f"{n_edta} / {n_lib} ({n_edta / n_lib:.2f})",
                         "edta/out/elements.B73v5.tsv; results/main3/elements.B73v5.tsv")
    rat = np.array([r_lib[w] / r_wg[w] for w in ws])
    V["frac_wg"] = (rat.min(), rat.max())
    num("F", "library r / whole-genome r, range over window sizes", f"{rat.min():.2f}-{rat.max():.2f}",
        "computed from the rows above")
    V["mask_diff"] = num("F", "max |whole genome - LTR-masked| r", round(max(abs(r_wg[w] - r_nl[w]) for w in ws), 3),
                         "computed from the rows above")

    # ---------------- G: one-sided annotation dropout
    xG = 74.0
    wG = (128.0 - xG - 2.8) / 2
    axGs = []
    dr = runs[runs.kind == "dropout"]
    base18 = pw[(pw.f == 0.18) & (pw.Ta == 5000.0)]
    rng = np.random.default_rng(3)
    for i, (fval, base, ttl) in enumerate(((0.0, nul, "no gene flow"), (0.18, base18, "f = 0.18"))):
        ax = ax_mm(fig, xG + i * (wG + 2.8), yF, wG, hF)
        axGs.append(ax)
        ax.axhspan(-1.96, 1.96, color="#EBEBEB", lw=0, zorder=0)
        ax.axhline(0, color="#CFCFCF", lw=0.4, zorder=1)
        g = pd.concat([base.assign(fnB=0.0), dr[dr.f == fval]])
        for j, t in enumerate(TESTS):
            dx = (j - 1.5) * 0.19
            for xi, fn_ in enumerate((0.0, 0.2, 0.4)):
                gg = g[np.isclose(g.fnB, fn_)]
                yy = gg[t + "_ZB"].values
                xx = xi + dx + ((rng.random(len(yy)) - 0.5) * 0.12 if len(yy) > 3 else np.zeros(len(yy)))
                okk = gg.sisters_ok.values
                ax.scatter(xx[okk], yy[okk], s=5, marker=TMARK[t], facecolor=TCOL[t], edgecolor="none", zorder=3)
                ax.scatter(xx[~okk], yy[~okk], s=5, marker=TMARK[t], facecolor="white", edgecolor=TCOL[t], lw=0.5,
                           zorder=3)
        ax.set_xlim(-0.55, 2.55)
        ax.set_ylim(-30, 25)
        ax.set_xticks([0, 1, 2])
        ax.set_xticklabels(["0", "20", "40"])
        ax.set_yticks([-20, -10, 0, 10, 20])
        if i:
            ax.set_yticklabels([])
        ax.text(0.5, 1.0, ttl, transform=ax.transAxes, ha="center", va="bottom", fontsize=6.5)
    axGs[0].set_ylabel("Z toward the recipient", labelpad=1.0)
    fig.text(((xG + 128.0) / 2) / W, 1 - (yF + hF + 5.2) / H, "recipient elements removed (%)", ha="center",
             va="top", fontsize=6.5)
    key_row(fig, xG - 9.0, yF + hF + 11.3, [("marker", TCOL[t], TNAME[t], TMARK[t], "none") for t in TESTS] +
            [("marker", "white", "sisters misidentified", "o", "#555555")], size=5.8, gap=2.0)
    letter_for(fig, xG, yF, "G")
    V["drop"] = {}
    for fval in (0.0, 0.18):
        for fn_ in (0.2, 0.4):
            gg = dr[(dr.f == fval) & np.isclose(dr.fnB, fn_)]
            V["drop"][(fval, fn_)] = ([gg[t + "_ZB"].mean() for t in TESTS], int(gg.sisters_ok.sum()), len(gg))
            num("G", f"dropout {int(fn_ * 100)}%, f={fval}: mean Z (k-mers, insertions, triples, self); sisters ok",
                ", ".join(f"{gg[t + '_ZB'].mean():+.2f}" for t in TESTS) + f"; {int(gg.sisters_ok.sum())}/{len(gg)}",
                "sim/eval/fn*.json; sim/sim_summary.tsv table=dropout")

    # ---------------- H: annotation completeness check
    xH, wH = 140.0, 38.0
    axH = ax_mm(fig, xH, yF, wH, hF)
    cats = [("no gene\nflow", runs[runs.kind == "null"]), ("gene\nflow", pw[pw.sisters_ok]),
            ("20%\ndropout", dr[np.isclose(dr.fnB, 0.2) & dr.sisters_ok])]
    V["comp"] = {}
    for i, (nm, g) in enumerate(cats):
        y = g.completeness.values
        off = beeswarm(y, 0.085, 0.0065)
        axH.scatter(i + off, y, s=5, facecolor="#8C8C8C", edgecolor="none", zorder=3)
        V["comp"][i] = (y.min(), y.max(), len(y))
        num("H", f"completeness ratio, {nm.replace(chr(10), ' ')}: min-max (n)", "{:.3f}-{:.3f} ({})".format(*V["comp"][i]),
            "sim/out/*/stats.tsv completeness_ratio")
    cr, cse = float(comp_real.ratio), float(comp_real.SE)
    axH.errorbar([3.1], [cr], yerr=[2 * cse], fmt="D", ms=3, color=MAIZE, mfc=MAIZE, elinewidth=0.6, capsize=0)
    num("H", "completeness ratio, real B73/TIL01 (+-SE)", f"{cr:.3f} +- {cse:.3f}", "results/main3/stats.tsv")
    axH.axhline(1.0, color="#888888", lw=0.5, ls=(0, (2, 2)), zorder=0)
    axH.set_xlim(-0.6, 3.6)
    axH.set_ylim(0.95, 1.32)
    axH.set_xticks([0, 1, 2, 3.1])
    axH.set_xticklabels([c[0] for c in cats] + ["B73 /\nTIL01"])
    axH.set_yticks([1.0, 1.1, 1.2, 1.3])
    axH.set_ylabel("old donor insertions,\nrecipient ÷ sister", labelpad=1.0)
    axH.text(3.58, 1.004, "equal", ha="right", va="bottom", fontsize=5.5, color="#777777")
    letter_for(fig, xH, yF, "H")

    # ---------------- I: base-pair example of a library-only absence confirmed in the raw assembly
    yI = yF + hF + 20.0
    hI = 21.0
    axI = ax_mm(fig, 0, yI - 4.0, 126.0, hI + 4.0)
    draw_example(axI, exa)
    letter(fig, 0, yI - LETTER_DY, "I")
    num("I", "example element", exa["element"], "absence/B73v5.TIL01.tsv.gz; fig3_example.py")
    num("I", "example K2P (median of all absent calls); length (median)",
        f"{exa['k2p']:.4f} ({exa['k2p_median_absent']:.4f}); {exa['length']} ({exa['len_median_absent']:.0f})",
        "absence/B73v5.TIL01.tsv.gz")
    num("I", "TSD; LTR lengths", f"{exa['tsd']}; {exa['ltr5_len']} / {exa['ltr3_len']}",
        "run/B73v5_LTRs_depth*_clean_ltr.tsv, verified on inputs/B73v5.fa")
    num("I", "TIL01 empty site; differences over 300 bp of flanks",
        f"{exa['til01_chrom']}:{exa['til01_hit_start']}-{exa['til01_hit_end']}; {exa['edit_distance']}",
        "inputs/TIL01.fa (samtools faidx + edlib)")
    num("I", "junction 21-mers found in TIL01 (left/right); empty-site 21-mers found",
        f"{exa['junction_left']:.2f} / {exa['junction_right']:.2f}; {exa['empty_site_frac']:.2f}",
        "absence/B73v5.TIL01.tsv.gz")

    # ---------------- J: library-only presence/absence calls against the raw assemblies
    xJ, wJ = 140.0, 38.0
    axJ = ax_mm(fig, xJ, yI, wJ, hI)
    order = ["absent", "present", "unresolved"]
    pairs = list(dict.fromkeys(absn.pair))
    pm = {"B73v5>TIL01": ("o", PAR, "B73 in TIL01"), "B73v5>TIL18": ("s", MEX, "B73 in TIL18"),
          "TIL18>TIL01": ("^", PAR, "TIL18 in TIL01"), "TIL01>B73v5": ("v", MAIZE, "TIL01 in B73"),
          "TIL01>TIL18": ("<", MEX, "TIL01 in TIL18"), "TIL18>B73v5": ("D", MAIZE, "TIL18 in B73")}
    for k, pr in enumerate(pairs):
        g = absn[absn.pair == pr].set_index("status").loc[order]
        mk, col, lab = pm.get(pr, ("o", MAIZE, pr))
        xx = np.arange(3) + (k - (len(pairs) - 1) / 2) * 0.17
        axJ.plot(xx, g.pct_empty_decidable, color="#D0D0D0", lw=0.5, zorder=1)
        axJ.scatter(xx, g.pct_empty_decidable, s=9, marker=mk, facecolor=col, edgecolor="none", zorder=3)
        axJ.scatter([1.33], [99 - k * 9.0], s=8, marker=mk, facecolor=col, edgecolor="none", clip_on=False)
        axJ.text(1.43, 99 - k * 9.0, lab, fontsize=5.5, va="center")
        for st in order:
            num("J", f"{pr} {st}: % empty of decidable (decidable fraction, n)",
                f"{g.loc[st, 'pct_empty_decidable']:.1f} ({g.loc[st, 'frac_decidable']:.3f}, {g.loc[st, 'n']})",
                os.path.relpath(g.loc[st, "file"], BM))
    axJ.set_xlim(-0.45, 2.45)
    axJ.set_ylim(0, 102)
    axJ.set_xticks([0, 1, 2])
    axJ.set_xticklabels(["absent", "present", "not\ncalled"])
    axJ.set_yticks([0, 25, 50, 75, 100])
    axJ.set_ylabel("empty site in the raw\nassembly (% decidable)", labelpad=1.0)
    axJ.set_xlabel("library-only call", labelpad=1.5)
    letter_for(fig, xJ, yI, "J")
    V["pairs"] = pairs
    V["abs"] = absn
    V["comp_real"] = (cr, cse)
    V["exa"] = exa
    V["r"] = dict(lib=r_lib, wg=r_wg, nl=r_nl, edta=r_edta)
    V["auc_lib"], V["auc_edta"] = auc_lib, auc_edta
    V["wnull"] = wnull
    return fig, runs, ex, V


def draw_example(ax, x):
    """B73 insertion junctions vs the TIL01 empty site, base by base, under the element drawn to scale."""
    ax.set_xlim(0, 126)
    ax.set_ylim(26, 0)
    ax.axis("off")
    cw = 1.0                       # mm per base
    nfl, nel = 14, 9
    L, Rr, tsd = x["b73_left"], x["b73_right"], x["tsd"]
    left_fl, right_fl = L[-5 - nfl:-5], Rr[5:5 + nfl]
    b_start, b_end = x["b73_body_start"][:nel], x["b73_body_end"][-nel:]
    q, t = x["aln_query"], x["aln_target"]
    qi, til_left, til_right = 0, "", ""
    for a_, b_ in zip(q, t):
        if a_ != "-":
            qi += 1
        if qi <= 150 and not (a_ == "-" and qi == 150):
            til_left += b_
        else:
            til_right += b_
    til_left, til_right = til_left.replace("-", ""), til_right.replace("-", "")
    t_lfl, t_tsd, t_rfl = til_left[-5 - nfl:-5], til_left[-5:], til_right[:nfl]
    assert t_tsd == tsd, (t_tsd, tsd)
    x0 = 25.0
    yg, yb, yt = 6.0, 14.0, 21.0
    ax.text(x0 - 2.0, yb, "maize B73", ha="right", va="center", fontsize=6.5, color=MAIZE)
    ax.text(x0 - 2.0, yt, r"$\it{parviglumis}$ TIL01", ha="right", va="center", fontsize=6.5, color=PAR)

    def seq(s, xs, y, bg=None, fc="black"):
        if bg is not None:
            ax.add_patch(Rectangle((xs, y - 1.45), len(s) * cw, 2.9, fc=bg, ec="none"))
        for i, ch in enumerate(s):
            ax.text(xs + (i + 0.5) * cw, y, ch, ha="center", va="center", fontsize=5.7, family=MONO, color=fc)
        return xs + len(s) * cw

    def tsd_box(xs, y):
        ax.add_patch(Rectangle((xs, y - 1.55), 5 * cw, 3.1, fc="none", ec="black", lw=0.5))

    p1 = seq(left_fl, x0, yb)
    p2 = seq(tsd, p1, yb)
    tsd_box(p1, yb)
    p3 = seq(b_start, p2, yb, bg=MAIZE, fc="white")
    gap = 17.0
    ax.text(p3 + gap / 2, yb, f"… {x['length'] - 2 * nel:,} bp …", ha="center", va="center", fontsize=5.8)
    p4 = p3 + gap
    p5 = seq(b_end, p4, yb, bg=MAIZE, fc="white")
    p6 = seq(tsd, p5, yb)
    tsd_box(p5, yb)
    p7 = seq(right_fl, p6, yb)
    seq(t_lfl, x0, yt)
    seq(t_tsd, p1, yt)
    tsd_box(p1, yt)
    seq(t_rfl, p6, yt)
    ax.plot([p2 + 0.4, p6 - 0.4], [yt, yt], color="#9A9A9A", lw=0.5, ls=(0, (2, 2)))
    ax.text((p2 + p6) / 2, yt, "empty site", ha="center", va="center", fontsize=6, color=PAR,
            bbox=dict(fc="white", ec="none", pad=0.6))
    for s1, s2, xs in ((left_fl + tsd, t_lfl + t_tsd, x0), (right_fl, t_rfl, p6)):
        for i, (a_, b_) in enumerate(zip(s1, s2)):
            if a_ == b_:
                ax.plot([xs + (i + 0.5) * cw] * 2, [yb + 1.9, yt - 1.9], color="#B0B0B0", lw=0.35)
    ax.text(p1 + 2.5 * cw, yb - 1.9, "TSD", ha="center", va="bottom", fontsize=5.5)
    ax.text(p5 + 2.5 * cw, yb - 1.9, "TSD", ha="center", va="bottom", fontsize=5.5)
    # the element to scale above its two junctions (LTRs dark, internal region light)
    gx0, gx1 = p2, p5
    sc = (gx1 - gx0) / x["length"]
    l5, l3 = x["ltr5_len"] * sc, x["ltr3_len"] * sc
    ax.plot([x0, gx0], [yg, yg], color="#555555", lw=0.6)
    ax.plot([gx1, p7], [yg, yg], color="#555555", lw=0.6)
    ax.add_patch(Rectangle((gx0, yg - 1.2), gx1 - gx0, 2.4, fc="#D9D9D9", ec="none"))
    ax.add_patch(Rectangle((gx0, yg - 1.2), l5, 2.4, fc=MAIZE, ec="none"))
    ax.add_patch(Rectangle((gx1 - l3, yg - 1.2), l3, 2.4, fc=MAIZE, ec="none"))
    ax.text(gx0 + l5 / 2, yg - 1.6, "LTR", ha="center", va="bottom", fontsize=5.5)
    ax.text(gx1 - l3 / 2, yg - 1.6, "LTR", ha="center", va="bottom", fontsize=5.5)
    ax.text((gx0 + l5 + gx1 - l3) / 2, yg - 1.6, "Gypsy/Tekay", ha="center", va="bottom", fontsize=5.5)
    for xa, xb in ((gx0, p2), (gx1, p5)):
        ax.plot([xa, xb], [yg + 1.2, yb - 1.5], color="#9A9A9A", lw=0.4)
    kb = 1000 * sc
    cx = (gx0 + gx1) / 2
    ax.plot([cx - kb / 2, cx + kb / 2], [yg + 2.3, yg + 2.3], color="black", lw=0.6)
    ax.text(cx + kb / 2 + 1.0, yg + 2.3, "1 kb", ha="left", va="center", fontsize=5.5)
    ax.text(x0 - 2.0, yg, "B73 " + x["chrom"].split("_")[1], ha="right", va="center", fontsize=5.8, color="#555555")
    # k-mer evidence used by the absence check
    xr = p7 + 2.0
    ax.text(xr, yb - 2.6, "21-mers in TIL01", ha="left", va="center", fontsize=5.5, color="#555555")
    ax.text(xr, yb, f"junctions: {round(20 * x['junction_left'])}/20, {round(20 * x['junction_right'])}/20",
            ha="left", va="center", fontsize=5.8)
    ax.text(xr, yt, f"empty site: {round(20 * x['empty_site_frac'])}/20", ha="left", va="center", fontsize=5.8)


# ----------------------------------------------------------------------------------------------------- legends
def legend_text(runs, ex, V):
    exa, absn = V["exa"], V["abs"]
    ab = absn[absn.status == "absent"]
    pr = absn[absn.status == "present"]
    un = absn[absn.status == "unresolved"]
    dec_lo = min(ab.frac_decidable.min(), pr.frac_decidable.min())
    dec_hi = max(ab.frac_decidable.max(), pr.frac_decidable.max())
    m2 = runs[runs.kind == "m2"].sort_values("true_frac")
    d20 = V["drop"][(0.0, 0.2)][0]
    a50, a500, a5k = V["auc"][50.0], V["auc"][500.0], V["auc"][5000.0]
    trg, trn = V["tr_gene flow"], V["tr_null"]
    zl = V["zoom"]
    r5 = V["rec5"]
    short_head = ("**Transposon libraries alone give calibrated, well-powered tests for gene flow, and they fail in "
                  "predictable ways.** Without gene flow the tests stay at chance; with one genome per taxon they "
                  "detect admixture of a tenth to a fifth of a genome but resolve only long introgressed tracts.")
    short = [
        ("A", "A simulated maize-like chromosome without gene flow (top) and the same chromosome after donor DNA "
              "entered 5,000 generations ago (bottom). Elements nearly identical to the donor gather in the true "
              "donor segments, and confident tracts are called only there."),
        ("B", "Long donor segments carry several donor-like elements and are painted; short ones carry one or none "
              "and blend into the background left by incomplete lineage sorting."),
        ("C", "Element-level accuracy is near perfect for recent admixture and lower for old admixture; the real "
              "maize genome, scored against population-genetic ancestry calls, sits just below the old-admixture "
              "simulations."),
        ("D", "Without gene flow all four tests scatter as chance predicts; with a fifth of the genome admixed every "
              "test is significant in every run, and with a tenth in most runs."),
        ("E", "With one donor genome the excess of near-identical copies is a lower bound on the admixed fraction; a "
              "second donor genome recovers the fraction itself."),
        ("F", "Along the real maize genome, transposon libraries recover most of the ancestry signal that whole "
              "genomes give, with either of two annotation tools."),
        ("G", "When one genome's annotation misses elements, presence-based tests point to the other genome as the "
              "recipient; tests built on orthologous triples or on each element's own two LTRs are not fooled."),
        ("H", "A built-in check exposes such gaps; the real trio sits between the simulations with gene flow and "
              "those with missing annotation."),
        ("I", "A real insertion that the library calls absent from *parviglumis*: the raw *parviglumis* genome holds "
              "the empty site, with a single copy of the target-site duplication."),
        ("J", "Absences and presences read from libraries alone agree with the raw genomes in most cases that can be "
              "decided."),
    ]
    top = ("Simulations: msprime genealogies with LTR-RT insertion, loss and sequence evolution; three haploid 200-Mb "
           "genomes, recipient B (maize-like), sister P and donor M, demography fitted to *Zea*, ~19,000 elements each "
           "(about 1/7 of B73). f, admixture proportion; admixture time in generations. Z, 5-Mb block-jackknife Z "
           "oriented toward the true recipient B. Tests: k-mers, single-copy k-mers shared by exactly two genomes; "
           "insertions, presence shared with the donor and absent from the other sister; triples, divergence of "
           "ortholog triples; self-outgroup, ABBA/BABA on LTR sites polarized by the element's other LTR. Element "
           "classes: near-identical to the donor (closer than 95% of sister-donor orthologs) or donor-only insertion, "
           "their sister mirrors, and uninformative (shared, private). Confident tract: target-decoy q ≤ 0.05.")
    long_ = [
        ("A", f"Chromosome 6 of run {ex['run']}, the chromosome whose true donor fraction ({ex['frac']:.3f}) is "
              f"closest to its run's genome-wide fraction ({ex['genome_frac']:.3f}) among both f = 0.18, 5,000-"
              f"generation runs; null partner, chromosome 6 of {ex['null']}, the first null replicate in which the "
              "tool calls B the recipient. Every element is a tick; posteriors of the donor-like state from the "
              "ancestry model (all informative classes) and the recent-sharing model (near-identical classes only); "
              "boxes, ancestry tracts. Without gene flow the ancestry posterior still fluctuates, because lineage "
              f"sorting makes donor-like clusters: {trn[0]:,} tracts genome-wide against {trn[1]:,} in the decoy "
              f"sister painted by the same model, {trn[2]} confident; the recent-sharing posterior stays near 0 "
              f"(mean {V['rec_null'][0]:.3f}). With gene flow: {trg[0]} tracts against {trg[1]} decoys, {trg[2]} "
              f"confident ({V['conf_ok'][0]} of {V['conf_ok'][1]} overlap a true segment; base-pair precision "
              f"{V['conf_ok'][2]:.2f}); element AUROC {V['auc_ex']:.2f}. The second replicate with the same parameters reached no "
              f"confident tract (AUROC {V['auc_r2'].split(' / ')[0]})."),
        ("B", f"The 2-Mb window ({ex['zoom'][0] / 1e6:.1f}-{ex['zoom'][1] / 1e6:.1f} Mb, 0.5-Mb steps) whose true "
              f"donor fraction ({ex['zoom_frac']:.3f}) is closest to the chromosome's; every element drawn to size. "
              f"Of its {zl[0]} true segments, {zl[3]} are shorter than 50 kb ({zl[4]} overlapped by any tract) and "
              f"{zl[5]} longer ({zl[6]} overlapped); none of its tracts is confident. Across the {r5[6]} of {r5[7]} "
              "5,000-generation runs that reached confident tracts, these covered "
              f"{100 * r5[0]:.0f}-{100 * r5[1]:.0f}% of true segments < 50 kb and {100 * r5[2]:.0f}-"
              f"{100 * r5[3]:.0f}% of segments of 200 kb-1 Mb, at base-pair precision {r5[4]:.2f}-{r5[5]:.2f}. "
              f"True segments are short (median {V['seg_med']:.0f} kb at 5,000 generations), comparable to the "
              "spacing of informative elements."),
        ("C", "Element AUROC of the ancestry posterior against the simulated truth (element midpoint inside a true "
              "segment), every power run in which B was painted and held donor segments "
              f"(n = {a50[3]}, {a500[3]}, {a5k[3]}; medians {a50[1]:.2f}, {a500[1]:.2f}, {a5k[1]:.2f}; range at "
              f"5,000 generations {a5k[0]:.2f}-{a5k[2]:.2f}). Real B73 (right): elements whose ELAI *mexicana* "
              "dosage (mean of SNPs within ± 20 kb) is ≥ 1.0 (lower point) or ≥ 1.5 (upper point) against those "
              f"≤ 0.2; filled, LTRquest library ({V['auc_lib'][('ancestry', 1.0)]:.2f}, "
              f"{V['auc_lib'][('ancestry', 1.5)]:.2f}); open, the same tool on independent EDTA intact annotations "
              f"({V['auc_edta'][('ancestry', 1.0)]:.2f}, {V['auc_edta'][('ancestry', 1.5)]:.2f}). ELAI is a "
              "reference, not exact truth."),
        ("D", "Every run is a point. Null: 30 independent replicates (gray, x = 0): mean Z "
              f"{min(V['null_mean']):+.2f} to {max(V['null_mean']):+.2f}, SD {min(V['null_sd']):.2f}-"
              f"{max(V['null_sd']):.2f}, largest |Z| {V['null_max']:.1f}, so |Z| > 3 in none of 30 runs for any "
              "test; no confident tract in any null run. Power grid: f = 0.02-0.5 at three admixture times, two "
              "replicates each (36 runs), x = realized donor fraction. All "
              f"{V['pow_hi'][1]} runs with a realized fraction ≥ 0.17 have Z > 3 in every test; at 0.09-0.17, "
              f"{V['pow_mid'][0]} of {V['pow_mid'][2]} in every test and {V['pow_mid'][1]} in at least one; below "
              f"0.09, {V['pow_lo']} of {V['n_lo']}. Open: {V['flip'][0]} runs with realized fractions "
              f"{V['flip'][1]:.2f}-{V['flip'][2]:.2f}, in which the recipient, now mostly donor-like, was recast as "
              f"the donor's sister; still significant (|Z| {V['flip'][3]:.1f}-{V['flip'][4]:.1f} across the four tests)."),
        ("E", "Gray: identity-spectrum excess (near-identical recipient-donor orthologs beyond the mirror "
              "sister-donor count), a lower bound on the admixed fraction, in every three-genome run; median "
              f"{V['flow'][0]:.2f} of the truth (10-90%: {V['flow'][1]:.2f}-{V['flow'][2]:.2f}) when the true "
              f"fraction exceeds 0.05, at most {V['flow_null']:.3f} without gene flow. Black: f-ratio with a second "
              "donor genome (four-genome runs, 5,000 generations, two replicates per f); filled, identity version ("
              + "; ".join(f"{a:.3f}/{b:.3f} for {c:.3f}/{d:.3f}" for (a, b), (c, d) in
                          zip(zip(m2.f_ratio_identity.values[::2], m2.f_ratio_identity.values[1::2]),
                              zip(m2.true_frac.values[::2], m2.true_frac.values[1::2])))
              + "); open squares, insertion version ± 2 SE. Dashed, 1:1."),
        ("F", "Real trio (B73 recipient, TIL01 sister, TIL18 donor): Spearman correlation between B73 windows and "
              "ELAI *mexicana* dosage (Yang et al. 2023). Black solid, LTR-RT library, ancestry posterior "
              "(pre-registered statistic); black dashed, the same tool on independent EDTA intact annotations "
              f"({float(V['edta_frac'].split('(')[1].rstrip(')')):.0%} as many B73 elements as the library); gray, "
              "the same k-mer share on whole assemblies (solid) and with LTR-RTs masked (dashed), "
              f"which differ by ≤ {V['mask_diff']:.2f}. The library reaches {100 * V['frac_wg'][0]:.0f}-"
              f"{100 * V['frac_wg'][1]:.0f}% of the whole-genome correlation at every window size. Gray band, 95% "
              "of 1,000 circular shifts of the library windows within chromosomes; it lies above 0 because shifts "
              "keep chromosome-level differences. Every observed value exceeds all 1,000 shifts (p = 0.001)."),
        ("G", "One-sided annotation dropout: 20% or 40% of B's elements removed before the analysis (three "
              "replicates per setting, 5,000 generations); x = 0 repeats the null runs (left) and the two f = 0.18, "
              "5,000-generation runs (right). With 20% dropout and no gene flow the presence-based tests point to "
              f"the better-annotated sister (mean Z {d20[0]:.0f} for k-mers, {d20[1]:.0f} for insertions) while "
              f"triples ({d20[2]:+.2f}) and self-outgroup ({d20[3]:+.2f}) stay at chance. With gene flow, 20% "
              "dropout reversed the presence-based tests and misidentified the sisters in two of three runs; 40% "
              "dropout misidentified them in every run (open symbols)."),
        ("H", "Completeness check reported by the tool: the donor's oldest quarter of insertions present in the "
              "called recipient divided by those present in the called sister (runs with the correct sister pair). "
              f"No gene flow {V['comp'][0][0]:.2f}-{V['comp'][0][1]:.2f}; gene flow alone {V['comp'][1][0]:.2f}-"
              f"{V['comp'][1][1]:.2f}; 20% dropout {V['comp'][2][0]:.2f}-{V['comp'][2][1]:.2f}. Real B73 / TIL01: "
              f"{V['comp_real'][0]:.3f} ± {V['comp_real'][1]:.3f} (± 2 SE drawn), above the gene-flow range but "
              "well below the dropout range; triples and self-outgroup, immune to dropout, agree on the real trio."),
        ("I", "A typical library-only absence, chosen by rule: among absent calls confirmed empty in the raw TIL01 "
              "assembly (the usual decidable outcome), the element closest to the median K2P "
              f"({exa['k2p_median_absent']:.4f}) and length ({exa['len_median_absent'] / 1e3:.1f} kb) of all absent "
              "calls with a 5-bp TSD, TG…CA ends, high confidence, no nesting and a family-typical length, whose empty "
              "site could be located between the TIL01 orthologs of its neighbors. B73 "
              f"{exa['chrom'].split('_')[1]}:{exa['start']:,}-{exa['end']:,} (Gypsy/Tekay, {exa['length']:,} bp, "
              f"K2P {exa['k2p']:.4f}, LTRs {exa['ltr5_len']:,} and {exa['ltr3_len']:,} bp, TSD {exa['tsd']} on both "
              f"sides), verified on the B73 assembly; TIL01 {exa['til01_chrom'].split('_')[1]}:"
              f"{exa['til01_hit_start']:,} carries the empty allele ({exa['edit_distance']} differences in 300 bp "
              "of flank, one TSD copy). The check counts 21-mers spanning each junction (found only by chance "
              "overlap with flank sequence) and spanning the empty site."),
        ("J", "Library calls (absent; present; not called, i.e. outside a collinear block) for 20,000 random "
              "elements per call and genome pair, scored on the partner's raw assembly by junction and empty-site "
              f"21-mers; decidable, empty or occupied ({100 * dec_lo:.0f}-{100 * dec_hi:.0f}% of absent and present "
              f"calls). Absent calls were empty in {ab.pct_empty_decidable.min():.1f}-"
              f"{ab.pct_empty_decidable.max():.1f}% and present calls occupied in "
              f"{100 - pr.pct_empty_decidable.max():.1f}-{100 - pr.pct_empty_decidable.min():.1f}%; uncalled "
              f"elements were empty in {un.pct_empty_decidable.min():.0f}-{un.pct_empty_decidable.max():.0f}%. "
              f"{len(V['pairs'])} of 6 genome pairs were available when the figure was made."),
    ]
    na = runs[(runs.kind == "power") & runs.auc_ancestry.isna()]
    pc = na[na.sisters_ok & (na.recipient_called == "P")].sim.tolist()
    nz = na[na.sisters_ok & (na.recipient_called == "B")].sim.tolist()
    tail = (f"Exceptions: {len(na)} of 36 power runs have no AUROC (C): P was called the recipient in {len(pc)} "
            f"({', '.join(pc)}), no donor segment was realized in {len(nz)} ({', '.join(nz)}), and the recipient was "
            f"recast as the donor's sister in {int((~na.sisters_ok).sum())} (open in D). Simulated genomes carry about "
            "1/7 of B73's elements, so power on real genomes is expected to be higher.")
    return short_head, short, top, long_, tail


def rich_tokens(text, base="normal"):
    """Split text with **bold** and *italic* markup into (word, style, space_after) tokens."""
    out = []
    for part in re.split(r"(\*\*[^*]+\*\*|\*[^*]+\*)", text):
        if not part:
            continue
        if part.startswith("**"):
            sty, s = "bold", part[2:-2]
        elif part.startswith("*"):
            sty, s = "italic", part[1:-1]
        else:
            sty, s = base, part
        for m in re.finditer(r"\S+|\s+", s):
            if m.group().isspace():
                if out:
                    out[-1] = (out[-1][0], out[-1][1], True)
            else:
                out.append((m.group(), sty, False))
    return out


def legend_page(pdf, paras, fontsize=10.0, wmm=W):
    """One legend page as wide as the figure, height fitted to the text; paras = list of (letter, text)."""
    margin = 6.0
    avail = (wmm - 2 * margin) / 25.4 * 72      # points
    mfig = plt.figure(figsize=(wmm / 25.4, 10), dpi=1200)   # high dpi: hinting errors do not accumulate
    r = mfig.canvas.get_renderer()
    cache = {}

    def width(s, sty):
        k = (s, sty)
        if k not in cache:
            t = mfig.text(0, 0, s, fontsize=fontsize, fontweight="bold" if sty == "bold" else "normal",
                          fontstyle="italic" if sty == "italic" else "normal")
            cache[k] = t.get_window_extent(r).width * 72 / mfig.dpi
            t.remove()
        return cache[k]

    sp = width("a a", "normal") - width("aa", "normal")
    lines_all = []
    for head, text in paras:
        toks = ([(head, "bold", True)] if head else []) + rich_tokens(text)
        lines, cur, cw_ = [], [], 0.0
        for w, sty, space_after in toks:
            ww = width(w, sty) if w else 0.0
            add = ww + (sp if cur and cur[-1][2] else 0.0)
            if cur and cw_ + add > avail:
                lines.append(cur)
                cur, cw_ = [], 0.0
                add = ww
            cur.append((w, sty, space_after))
            cw_ += add
        if cur:
            lines.append(cur)
        lines_all.append(lines)
    lh = fontsize * 1.3 / 72                    # inches per line
    n = sum(len(x) for x in lines_all) + 0.55 * (len(lines_all) - 1)
    hin = n * lh + 2 * margin / 25.4
    fig = plt.figure(figsize=(wmm / 25.4, hin))
    y = margin / 25.4
    for lines in lines_all:
        for line in lines:
            x = margin / 25.4 * 72
            # merge runs of the same style
            runs_, cur_s, cur_t = [], None, ""
            for w, sty, space_after in line:
                piece = w + (" " if space_after else "")
                if sty == cur_s:
                    cur_t += piece
                else:
                    if cur_t:
                        runs_.append((cur_t, cur_s))
                    cur_s, cur_t = sty, piece
            if cur_t:
                runs_.append((cur_t.rstrip(" "), cur_s))
            for s, sty in runs_:
                fig.text(x / 72 / (wmm / 25.4), 1 - y / hin, s, fontsize=fontsize, va="top", ha="left",
                         fontweight="bold" if sty == "bold" else "normal",
                         fontstyle="italic" if sty == "italic" else "normal")
                x += width(s.rstrip(" "), sty) + (sp if s.endswith(" ") else 0.0)
            y += lh
        y += 0.55 * lh
    pdf.savefig(fig)
    plt.close(fig)
    plt.close(mfig)


def width_cache_fig():
    return None


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--rebuild", action="store_true", help="recompute cached helper files in data/")
    a = ap.parse_args()
    fig, runs, ex, V = build(a.rebuild)
    fig.savefig(os.path.join(HERE, f"{STEM}.png"), dpi=300)
    short_head, short, top, long_, tail = legend_text(runs, ex, V)
    analysis = (f"Analysis: asc-oulab:/data2/chris/maize_introgression/benchmark · Script: "
                f"{os.path.join(HERE, STEM + '.py')} · 2026-11-07")
    with PdfPages(os.path.join(HERE, f"{STEM}.pdf")) as pdf:
        pdf.savefig(fig)
        legend_page(pdf, [("", short_head)] + short)
        legend_page(pdf, [("", top)] + long_ + [("", tail), ("", analysis)])
    pd.DataFrame(NUM, columns=["panel", "item", "value", "source"]).to_csv(os.path.join(HERE, f"{STEM}_numbers.tsv"),
                                                                          sep="\t", index=False)
    print("done", file=sys.stderr)


if __name__ == "__main__":
    main()
