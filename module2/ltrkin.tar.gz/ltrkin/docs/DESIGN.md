# ltrkin design note

Date: 2026-11-10, updated 2026-11-13 (v0.2.1). Status: v0.2, benchmarked (docs/benchmark_v0.2.md; v0.1: docs/benchmark.md). This note is the spec written before the code, kept up to date
with decisions and their reasons.

## Purpose
Two reusable methods, first built ad hoc for an analysis of *Poa* genomes:
1. `ltrkin genotype`: genotype every annotated LTR retrotransposon (LTR-RT) of a reference assembly in one or more
   samples from long reads aligned to that reference. Per sample and element: full / solo-LTR / empty-site allele
   counts, a diploid (or `--ploidy k`) genotype with a quality, and flags. Covers both uses:
   zygosity inside the individual the assembly came from (heterozygous = one haplotype only = recent insertion), and
   presence/absence across other individuals.
2. `ltrkin source`: for each new (polymorphic) copy, the nearest fixed copy as its likely source ("master"), with the
   evidence needed to judge the assignment: divergence, ties, relative age, independent-insertion checks, shared
   derived mutations, and a same-chromosome locality summary.

Not in scope: non-reference insertions (needs de novo discovery; see `LTRpav` for assembly-vs-assembly PAV),
family annotation (input), phasing.

## In short (how it works)
- **Evidence comes only from reads anchored in unique flank,** because young copies are near-identical inside.
  A read spanning the site measures the allele length, which separates full, solo, empty and other; a spanning read
  that carries both element ends is full whatever its internal length. A read crossing a junction into the internal
  region supports full. A read split by the aligner at an empty site is recognized even when only one piece is in
  the BAM: the clipped sequence continues into the far flank.
- **Read phasing** compares the reads over the element's unique flanks: where the haplotypes differ, two distinct
  groups of reads that both carry the element show it is on both haplotypes. This is positive evidence for dosage,
  which depth alone gives poorly at moderate coverage.
- **Genotypes come from a likelihood** over allele mixtures with read-length-derived sampling rates, a depth term for
  the null allele and the phasing lower bound. Everything else is estimated from each sample's own reads: the
  read-error rate, the annotation's boundary error, the depth per haplotype (calibrated at the sample's sites with an
  empty or solo allele, whose number of full haplotypes is known) and a genotype prior (the sample's genotype
  frequencies, empirical Bayes). Sites whose reads map only ambiguously are no-calls.
- **Source:** divergence of internal regions (nested elements excised; minimap2 asm5) between each new copy and the
  fixed copies of its family (an approximate screen of all of them, then exact alignment of the 20 nearest); shared derived mutations, polarized by the consensus of the copy's 10
  nearest relatives; the two-parent test, an exact one-breakpoint scan over diagnostic sites with Bonferroni over
  candidate pairs; the locality test, against a bp-share null and a permutation null that keeps source clusters
  (calibrated in simulation).

## Biology that shapes the rules
- A reference insertion has four possible states on another haplotype: **full** (present), **empty site** (the
  pre-insertion allele: flanks joined, one copy of the target-site duplication, TSD), **solo LTR** (LTR-LTR
  recombination removed the internal region and one LTR; TSD kept), and **other** (truncation by illegitimate
  recombination, nested-insertion differences, rearrangements). Only the empty site shows the insertion is new;
  a solo LTR shows an old insertion that was later removed.
- Young copies of one family are near-identical, so reads inside an element cannot be placed. All evidence comes
  from reads anchored in the unique flank: reads crossing a junction, or spanning the whole site.
- At birth the two LTRs of a copy are identical, so LTR-pair divergence is an age proxy. LTR gene conversion can
  make copies look younger.
- Reverse transcription copies the template's internal region, so a new copy's internal region equals its source's
  at birth. Internal regions (5-14 kb) resolve divergence better than LTRs.

## Genotype: read evidence (per element, per sample)
Fetch alignments (MAPQ >= `--min-mapq`, default 20) around both junctions and group them by read name, keeping
supplementary pieces. Each read gets one label:
- **spanning** (one alignment, or two pieces of one read on the same strand joined): it covers 100 bp of flank on
  both sides. Then length change Δ = query span − reference span between the anchors. Nearest expected value:
  full 0, solo −(L − mean LTR), empty −L, each within τ = max(50 bp, 0.03 × expected allele span). Otherwise the read
  is `other`, with its Δ recorded.
- **split, one piece** (BAMs filtered to primary alignments): the piece ends at a junction (or at the inner LTR
  boundary, for solo) with a soft clip >= 500 bp. The clip's first 300 bp are aligned by Smith-Waterman to the far
  flank and to the element; a match >= 0.90 over >= 150 bp gives `empty` (or `solo`). Otherwise the read is
  `unexplained`.
- **junction**: it carries an element end: the junction base and the LTR end are aligned (not inside a deletion of
  >= 50 bp) and >= 100 aligned bp of internal region lie in the 300 bp next to the LTR. Then it is `full`. A read
  crossing only into the LTR is `present` (full or solo), and is not used in the likelihood. (v0.1 required an
  aligned base exactly 100 bp past the LTR, which dropped full reads with a small internal deletion there.)
- **spanning, other length but both ends carried** (v0.2): a spanning or joined split read whose length change fits
  no allele but which carries both element ends is `full` (counted as `F_other`, flag `full_other_length`). The
  element is present on that haplotype with another internal length (internal indel, nesting difference). In v0.1
  these reads were `other`, which removed that haplotype from the dosage and turned F/F into F/N.
- **low MAPQ** (v0.2): reads at the junctions with MAPQ < `--min-mapq` are counted (`lowq`) but not used. A site
  with no informative read but low-MAPQ reads is a no-call (`./.`, GQ 0): absence of evidence there is
  mappability, not an allele. Flag `low_mapq` when >= 30% of junction reads are low-MAPQ.
- **Annotation boundary error** (v0.2): the expected empty and solo lengths come from the annotated element ends.
  Ends confirmed by a TSD (annotated, or found as identical 4-6-mers in the sequence) are trusted. For the others the
  sample estimates the error: at each TSD-less element with >= 2 spanning empty-site or other-length reads within
  300 bp of the expected empty length, the median offset; tolerance = 3 x the median |offset| over such elements
  (>= 20 elements, else 0; 3 = the 95th/50th percentile ratio of |error| for normal or triangular errors). Other-
  length reads of TSD-less elements that fit the empty or solo length within that tolerance are relabeled. Exact
  LTRquest ends give +12-24 bp; ends jittered by +-20 / +-50 bp give +39 / +92 bp.
- Fixed constants (`constants.py`), one-line reason each: anchor 100 bp (beyond alignment end effects); τ 3% / 50 bp
  (ONT net indel error ~1%, x3; TSD jitter); clip 500 bp and probe 300 bp (unique enough to place); SW identity 0.90
  (well above chance for unrelated sequence, below the HiFi/ONT error floor).

## Genotype: model
- Alleles F (full), S (solo), E (empty) and N (null: the haplotype gives no F/S/E read, because the site and its
  flanks are missing or rearranged). A haplotype carrying allele a yields informative reads at relative rate r_a:
  a read must span the allele (E: 2A + TSD; S: 2A + LTR), or reach the internal region at either junction (F: the
  left and right windows, with reads spanning both counted once). Each r_a comes from the sample's read-length
  distribution, using the length-biased coverage formula r(x) = E[max(0, ℓ − x)] / E[ℓ]. Nothing is tuned.
- Genotype g (multiset of `ploidy` alleles from F/S/E/N). Total informative reads follow a negative binomial with
  mean d_hap · Σ count_g(a) · r_a (r_N = 0). d_hap and the size parameter are estimated twice (v0.2):
  1. genome-wide: depth at 3,000 random positions fitted as a mixture of 1..ploidy copies of one haplotype depth
     (copy number c ~ NB(c·d_hap, c·k); EM for the copy weights; a mild prior on the full-ploidy component breaks
     the single-peak tie). v0.1 took the mode near the median, which in a genome with ~40% hemizygous sequence and
     overdispersed ONT depth landed between the one- and two-copy peaks (M. falcata 20x: d_hap 9.1 instead of 13.5);
  2. at element sites: after a first pass, the full-read counts at sites called with an empty or solo allele (GQ >=
     20, >= 2 empty/solo reads) come from a known number of full haplotypes, fixed by the full:empty/solo read
     ratio rather than by depth. Their median full reads / (full copies x r_F) is d_hap at element sites, and their
     dispersion the NB size (>= 30 sites; otherwise the genome-wide fit is kept, e.g. inbred lines). This absorbs
     mappability around elements and any bias in r_F. The second pass uses it.
  The class mix is multinomial: P(read from allele a | g) ∝ count_g(a) · r_a. Misclassification
  P(observed c | true a) = 1 − ε if c = a, else ε/2. Multinomial log-likelihood over the F/S/E counts.
  GQ = phred(1 − posterior of best), capped at 99. No call (`./.`, GQ 0) when no read is informative but reads at
  the element ends have MAPQ below `--min-mapq` (mappability, not an allele); with no reads at all, the depth term
  favors N (the site is absent).
- Genotype prior (v0.2, empirical Bayes): the sample's genotype frequencies, estimated by EM over the per-site
  likelihoods of pass 2 (add-one smoothing), are the prior of a third pass. Near-ties then follow the genotypes
  common in that sample (F/N where much sequence is on one haplotype, F/F in an inbred line) rather than a flat
  prior. With fewer than 5 called sites per genotype class (50 for a diploid; Cochran's rule for multinomial counts)
  the frequencies cannot be estimated and the prior stays flat.
- ε comes from the data in two passes: pass 1 with ε = 0.02; then ε̂ = discordant / total reads at sites called
  homozygous with >= 10 informative reads (floor 0.001, cap 0.1); pass 2 uses ε̂.
- Flags: `low_depth` / `high_depth` (informative depth < 0.25x / > 2.5x the expected value, which comes from the
  sample's coverage: possible collapsed duplication); `other_allele` (`other` reads >= max(2, 20%));
  `unexplained_clips` (>= max(2, 20%)).

- **Read phasing** (v0.2, `phase.py`): reads at the element are compared over 3 kb of unique flank on each side,
  using bases of quality >= 20 only. Heterozygous sites: substitutions in >= 2 reads at a minor-allele fraction of at
  least max(0.15, 0.5 / ploidy) of covering reads, kept only if linked to another such site (four-gamete test;
  independent sequencing errors are not linked). The quality filter is needed for ONT: per-read accuracy varies, so a
  low-accuracy read carries errors at many sites at once and error sites look linked (spurious second haplotypes at
  13-44% of sites from identical haplotypes without it, <= 0.4% with it). Reads without base qualities whose median
  divergence from the reference exceeds 1% are not phased (checked per sample, logged). Reads that agree at shared sites form groups; two
  groups are distinct when a pair of their reads disagrees at >= 2 shared sites and at >= 70% of them. For each
  allele class, h_a = the largest number of pairwise distinct groups holding >= 2 reads of that class: a lower bound
  on the haplotypes carrying the allele (identical haplotypes give at most 1). Likelihood term: each missing copy
  (h_a > copies of a in the genotype) costs log(PH_ERR), PH_ERR = 0.05, the spurious rate measured at confirmed
  one-haplotype sites (paralog reads from sequence absent from the reference haplotype). The absence of a second
  haplotype is not used as evidence (identical-by-descent regions would be called hemizygous).
- Allele-presence posteriors p_F, p_E, p_S (summed over genotypes) and a presence/absence call `pav` (>= 0.99).
  GQ includes dosage, which is uncertain at moderate depth, so presence/absence is read from the posteriors instead.

## Genotype: I/O
- In: reference FASTA (+ .fai); LTR-RT GFF3 (LTRquest, EDTA, LTR_retriever, LTRharvest or DANTE_LTR conventions: an element feature with two
  `long_terminal_repeat` children; family/clade attributes used when present); one or more coordinate-sorted,
  indexed BAM/CRAM files (sample = read-group SM, else file stem).
- Out: `<prefix>.genotypes.tsv` (one row per element x sample: counts, rates, genotype, GQ, flags) and
  `<prefix>.vcf.gz`. VCF REF = the reference (full) allele, ALT1 `<DEL:ME:LTR>` = empty site, ALT2 `<DEL:ME:SOLO>`
  = solo LTR; FORMAT GT:GQ:AD:FT.
- Speed: `-t` workers over chunks of 200 elements; streaming pysam fetches; no genome loaded into memory.

## Source: status, candidates, assignment
- Status from genotypes (GQ >= 20):
  - **new** = an empty allele in at least one sample;
  - **fixed** = F/F in every called sample;
  - otherwise **other** (including solo-only copies, which are removed, not new).
- Candidates: elements with both LTRs and an internal region >= 1 kb (resolves 0.1% divergence).
- Internal regions with nested inner elements excised. A host is never paired with an element inside or
  overlapping it.
- Divergence, per family group (copies without a family label form one group), in two stages: (1) an approximate
  screen of new internal regions against (a) fixed internal regions and (b) all other internal regions, minimap2
  `-x asm5 -p 0` without base alignment and with `-N` = group size, so the nearest fixed copy cannot be crowded out
  by closer non-fixed relatives (approximate divergence = minimap2 `dv`); (2) exact alignment (mappy, `cs`) of the
  20 targets (`TOP_K`) with the lowest approximate divergence. Alignment >= 1 kb covering >= 80% of the shorter;
  divergence = (substitutions + indel events) / aligned columns. The search is complete in the young range; at
  older divergence some nearest copies are missed (12% overall; `benchmark/search_completeness.py`).
- Nearest fixed copy(ies): minimum divergence. Ties (within 0.5 differences) share weight 1/k.
- Per pair, the evidence:
  - divergence and aligned length;
  - nearest relative of any status, and whether it is closer than the nearest fixed one (a sibling);
  - LTR differences of both copies (source older?);
  - TSD identity and 500-bp flank identity (segmental duplication instead of an insertion);
  - shared derived mutations: sites where the source differs from the consensus of the 10 nearest other relatives,
    and whether the new copy shares them (lineage support).
- Two-parent test: an exact one-breakpoint scan of diagnostic sites (reflection principle), Bonferroni over
  candidate pairs, plus a gain of >= 3 differences over the best single candidate.
- Summary: per clade or family and per divergence limit, the share of new copies on the source's chromosome against
  two nulls:
  - the chromosome's bp share (Poisson-binomial);
  - a permutation of new copies' chromosome labels that keeps source clusters, which controls for shared sources
    and chromosome hotspots.

## Validation plan ("benchmark fully")
- Unit tests (pytest), on a synthetic genome with planted elements:
  - every allele state;
  - a near-identical decoy copy elsewhere;
  - a nested element;
  - a true negative;
  - both BAM modes (with and without supplementary records);
  - the likelihood model on known count vectors.
- Genotype benchmarks:
  1. **Simulation.** Real *P. supina* sequence with planted empty / solo / full states on a second haplotype; HiFi-
     and ONT-like reads (pbsim3 / badread) at 5-60x; both BAM modes. Report precision, recall and genotype
     concordance by depth, element length and age. Baselines: Sniffles2 force-genotyping of the same sites, and
     the ad hoc caller from the analysis (v2).
  2. **Zygosity, real.** *P. supina* HiFi at ~63x in two read-phased regions: at heterozygous calls, carrying and
     empty reads should fall on opposite haplotypes; at homozygous calls, carrying reads should come from both.
  3. **Presence/absence, real.** *P. annua* accessions C11 and P3 (ONT reads on the annua reference) against each
     accession's own assembly (orthologous-site state). Compare with the existing TIP caller (LTR_RT M4).
- Source benchmarks:
  1. **Forward simulation** of family genealogies with known parents: accuracy of parent assignment by divergence,
     sampling of parents and sibling structure; power of the shared-mutation and age checks.
  2. **Real data:** completeness of candidate search (minimap2 vs exhaustive pairwise on sampled families), and
     end-to-end reproduction of the *P. supina* Tekay result.

## Decisions log
- 2026-11-12 (v0.2, haplotype-resolved truth in *C. amara* HiFi and *M. falcata* ONT; `benchmark/assembly_truth/`):
  - read phasing (lower bound on haplotypes carrying each allele): F/F recall +10 points at 20x HiFi;
  - PH_ERR 0.05 from the measured spurious rate (4.9% of confirmed one-haplotype sites), not a tuned value;
  - an "absence of a second haplotype" term was tested and rejected (hurt: IBD regions);
  - full reads with another internal length counted as full (Fx alleles were called F/N);
  - junction rule: element end carried (v0.1 known issue);
  - low-MAPQ-only sites are no-calls (were confident N/N);
  - in-sample depth calibration from F/E sites was tested on C. amara and not adopted at first (<= 0.4 points; the
    count deficit is context-dependent, not global); adopted later, after M. falcata (below);
  - DANTE_LTR GFF3 (`transposable_element` with LTR children) parsed;
  - BAMs sharing a read-group SM get file-name sample names (v0.1 merged them: invalid VCF);
  - annotation boundary error learned per sample (a fixed +100 bp cost 0.3-0.4 points on exact annotations; the
    learned tolerance keeps them and recovers +-50 bp boundary errors, 88.1 -> 92.5% at 20x);
  - phasing on bases of quality >= 20 and minor fraction >= 0.5/ploidy: the v0.1 simulated-ONT regression showed
    spurious second haplotypes from per-read error heterogeneity; requiring >= 3 disagreeing sites instead cost 5
    points of detection on real HiFi and was not taken;
  - polyploid dosage tested on a synthetic autotetraploid (tests/test_polyploid.py);
  - phasing uses at most 80 reads per element (read-name hash): bounds time and memory in collapsed repeats;
  - depth: copy-number mixture genome-wide, then calibration at element sites with an empty/solo allele. The
    v0.1 mode estimator failed on M. falcata ONT (non-monotonic accuracy with depth: 74% at 20x vs 88% at 40x);
    the calibration had been tested on C. amara earlier and gained <= 0.4 points there, because the genome-wide
    mode happened to be right; it is adopted for its effect where the genome-wide estimate fails.
  - empirical-Bayes genotype prior: on the same likelihoods it gained 0.3-0.5 points at 20x on both species and
    4.2 points at 5x ONT (mostly F/N recall); flat below 5 called sites per genotype class, because on the 9-site
    synthetic test genome the learned prior (F/F 0.34 vs F/N 0.08) overturned a weak hemizygous call. Kept after
    the simulation regression showed its cost: where haplotypes are identical and hemizygous elements rare (3%),
    depth-only F/N calls become conservative (ONT 20x recall 0.76 -> 0.38) while F/N precision rises (0.34 -> 0.84)
    and accuracy over all elements rises at every depth (e.g. ONT 10x 87.2 -> 96.6%). The prior is right for the
    population; rare-class sensitivity is the documented price. Calls with GQ >= 20 stay 99.7-100% correct.
- 2026-11-10 (benchmark-driven changes):
  - null allele N with a depth term: hemizygous copies were called homozygous (haplotag benchmark);
  - allele posteriors and `pav`: GQ-based presence/absence recall was 0.21 (assembly benchmark);
  - nested hosts excluded and inner elements excised: 252 of 314 same-chromosome pairs were host-inner artifacts;
  - search per family with -N equal to the family size: a 200-hit cap missed the nearest fixed copy in 13% of cases;
  - two-parent exact scan test: rules without a null model gave 2-43% false positives;
  - permutation locality null: robust to shared sources and hotspots;
  - solo length range between the two LTRs, and anchors inside deletions rejected (simulated-reads benchmark);
  - Python set order removed from sampling: reproducibility.
- 2026-11-10: name `ltrkin` (the name `ltrpav` belongs to the assembly-based tool in maize_introgression).
- 2026-11-10: junction-based evidence with read-length-derived sampling rates instead of fixed count thresholds
  (the ad hoc caller's het/hom count rules); error rate estimated from the data.
- 2026-11-10: the single-piece split-read rescue is required. Real BAMs are often filtered to primary alignments,
  and missing it made 12% of homozygous calls wrong in *P. supina* (see analysis memo).

## Status after v0.2 and open items
- Genotyping is ready for use on HiFi and ONT: against haplotype-resolved truth it is 2-18 points more accurate than
  v0.1 at every depth (largest on ONT, where v0.1's depth estimate failed) and 37-57 points more accurate than
  Sniffles2 or kanpig at 20x, which have no null allele and miss most empty and solo alleles. GQ is a ranking:
  GQ >= 20 calls are 95-98% correct against assembly truth, not 99%.
- Source assignment is unchanged since v0.1: a calibrated proxy, not a parentage test.
- Toward publication: a third, inbred or polyploid species with assembled haplotypes (the prior and depth model were
  tested on inbred-like data only in simulation); a graph-aware mode to recover reads lost to reference bias; the
  LTR U3/U5 template test for parent-offspring pairs.

## Code map
| path | content |
|---|---|
| `src/ltrkin/` | `cli.py` (entry point), `annot.py` (GFF3 reader, nesting, TSDs), `reads.py` (per-read allele evidence), `phase.py` (read phasing), `model.py` (genotype likelihood, depth and read-span model, genotype prior), `genotype.py` (driver, boundary-error estimate, TSV/VCF), `source.py` (source assignment, two-parent and locality tests), `constants.py` (every fixed constant with its reason) |
| `tests/` | pytest on synthetic genomes with planted states (`synth.py`): diploid (identical and 1%-divergent haplotypes), autotetraploid, planted genealogy; input checks and caches (`test_inputs.py`) |
| `benchmark/` | truth builders, scorers and workflows (`benchmark/README.md`); `assembly_truth/` reruns the v0.2 benchmark |
| `docs/` | `outputs.md` (every output column), `DESIGN.md` (this note), `benchmark_v0.2.md` (+ `img/fig1_ltrkin`), `benchmark.md` and `benchmark_genotype_sim.md` (v0.1), `lit_review.md`, `img/workflow` (README figure) |
