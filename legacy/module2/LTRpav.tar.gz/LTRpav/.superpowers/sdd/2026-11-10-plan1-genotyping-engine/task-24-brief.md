### Task 24: Aligner bake-off and default route

**Files (outside repo):** `benchmark_pav/bakeoff/{PARAMS.md, 01_sim.sh, 02_run_sims.py, 03_score_sims.py, 04_chr10.sh, 05_chr10_metrics.py, 06_anchorwave_readout.py, backends.py, REPORT.md}`.
**Repo:** Modify `src/ltrpav/constants.py` (`DEFAULT_ROUTE`) and `docs/DESIGN.md` (section 9 outcome).

- [ ] **Step 1: Interrogate parameters before any run.** Write `PARAMS.md`. For each parameter: what it does, its
  default, the choice and why.
  - **minimap2/mappy:** `-x asm5/10/20`, `-U`, `-f`, `-z`, `-r`, `-N`/`best_n`, `-p`, `--secondary`.
  - **FastGA:** `-f`, `-c`, `-s`, `-l`, `-i`, soft masks `-M`, `-S`.
  - **BLAST:** `-task`, `word_size`, `-dust`, `-evalue`, `-max_target_seqs` (returns the first N hits, not the
    best N), `-max_hsps`.
  - **LASTZ:** `lastz_32`, `--step`, `--seed`, `--chain`, `--gapped`, `--hspthresh`, `--ydrop`, `--ambiguous=iupac`.
  - **AnchorWave:** `-IV`, `-t`.
- [ ] **Step 2: Add the alternative local backends.** `backends.py` registers `lastz`, `wfa` (pywfa, gap-affine-2p,
  whole window) and `maf` (AnchorWave alignment sliced per window) through `register_backend`. Unit-check each on
  three toy cases (P, E, D) in a scratch test. Expected: correct states.
- [ ] **Step 3: Simulate.** `01_sim.sh`: `ltrpav-sim pair` on three B73 chr10 backbones with seeds 1 and 2:
  - R1 `B73v5_chr10:2000001-8000000` (arm)
  - R2 `B73v5_chr10:48000001-54000000` (the CentC cluster at 49-52 Mb in `inputs/annot_B73v5/te.gff3.gz`)
  - R3 `B73v5_chr10:140000001-146000000` (arm)
- [ ] **Step 4: Run routes on the sims.** `02_run_sims.py`, both directions, 32 threads:
  - Routes: `mm2`, `fastga`, `flank-mm2` with caps 2/5/10/20 kb, `flank-blast` at 10 kb, `hybrid`. Local backend:
    mappy.
  - Then the best two routes with the `lastz` and `wfa` backends.
  - Record wall time and peak RSS with `/usr/bin/time -v`. Each batch over 15 min runs detached.
- [ ] **Step 5: Score.** `03_score_sims.py` writes per-state precision and recall (all tiers and high tier),
  `correct_resolved_frac`, `unresolved_frac`, time and RSS.
- [ ] **Step 6: Real chr10.** `04_chr10.sh` builds chr10-only FASTAs and annotations for B73, TIL18 and TIL01 (GFF3
  filtered from `run/*_all_depth_LTR_cleaned.gff3`), then runs every route detached. `05_chr10_metrics.py` reports
  `resolved_frac`, `annot_agree`, `e_in_annot`, `reciprocity`, time and RSS. Whole-genome cost is extrapolated by
  the genome/chr10 length ratio.
- [ ] **Step 7: AnchorWave read-out** (once `anchorwave/done.flag` exists). `06_anchorwave_readout.py` classifies
  B73->TIL18 chr10 with the `maf` backend and reports per-state agreement with every route. Inspect at least 20
  disagreements with window dotplots, using the making-figures skill's quick-plot rules, and write what each shows.
- [ ] **Step 8: Decide by the rule fixed in DESIGN section 9.** Winner = best `correct_resolved_frac` among routes
  that meet:
  - the cost bar: whole-genome pair about 2 h wall at 32 threads, <= 250 GB;
  - the precision bar: high tier >= 0.95 for P and E on the sims.

  The local backend is chosen the same way. Write `REPORT.md` with tables, the decision and misses (misses also go
  to `benchmark_pav/dead_ends.md`).
- [ ] **Step 9: Record the decision.** Set `DEFAULT_ROUTE` to the winner, add the outcome to DESIGN section 9, run
  `pytest -q`, then commit `"Set default anchoring route from bake-off"`. Send the user a two-line note. Stop and
  ask only if the result changes the design, for example no route meets the cost bar.

---

