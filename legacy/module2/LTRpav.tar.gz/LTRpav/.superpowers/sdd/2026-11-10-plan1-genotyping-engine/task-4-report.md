# Task 4 report
Implemented src/ltrpav/samples.py (Sample, SampleSheetError, read_samples) and tests/test_samples.py (4 tests).
TDD: RED = ModuleNotFoundError ltrpav.samples at collection; GREEN = full suite passes (`mamba run -n ltrpav pytest -q`), `ruff check .` clean.
Behavior: header order-free; unknown column, missing required column, wrong field count (line number), bad label, duplicate label, unknown role, all missing FASTAs in one message, <2 rows, no annotation, missing sheet.
Concerns: validation order is header, row length, then labels/roles/duplicates/missing FASTAs/count/annotation. Annotation `.` or empty -> None. Fasta paths are .resolve()d (symlinks followed).
