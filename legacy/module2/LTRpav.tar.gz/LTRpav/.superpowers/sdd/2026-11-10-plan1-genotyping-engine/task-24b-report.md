# Task 24 phase B report: scoring, real-data metrics, decision

D = /data2/chris/maize_introgression/benchmark_pav/bakeoff.

**Why REPORT.md is missing.** The harness's Write tool refuses `D/REPORT.md` for subagents ("Subagents should return
findings as text, not write report files"). Its full final text was therefore returned in the B2 hand-back, under a
heading that names its path, for the controller to write. This file and `benchmark_pav/dead_ends.md` were written
normally.

## Phase B1 (2026-11-11 09:23-10:20)

Status: DONE_WITH_CONCERNS. The scope was task-24b-rulings "B1": no decision and no repo change. Nothing was
written in chr10/runs/ and the batch was never signaled. Runs used <= 8 threads, and every probe ran under
`timeout 15m`.

**Files** (all in D):
- `03_score_sims.py` -> `scores/`.
  - `ltrpav-sim score` was run for all 78 rerun sims and all 78 stock-engine sims, both directions.
  - Pooling uses the integer confusion counts. Each score.tsv equals its confusion table, and the per-sim sums equal
    the pooled counts.
  - Outputs: `scores/{final,stock}/{pooled,per_sim,per_run,confusion_pooled}.tsv` and `scores/summary.tsv`.
- `05_chr10_metrics.py` -> `metrics/chr10_{runs,qc,windows,stages,cost,busy_check,pending}_{final,stock}.tsv`.
  - Only runs with status.json are read.
  - Quality comes from qc.tsv. Genotype-only runs get "single-file" QC from build_loci over their one pair file.
  - The window and U-reason mix is tabulated per direction.
  - Stage times come from the logs.
  - Genotype CPU uses the busy time of the genotype pool, read from the chunk markers: the sum over the last W
    finishes of (finish - t0). It matches GNU-time CPU within 2% (lastz 1.01, mappy 0.98, wfa 1.00-1.01).
  - The whole-genome extrapolation is done per stage and by rule 11.
  - Memory is estimated per stage, beside the linear bound.
- `07_readout_compare.py` -> `metrics/readout_{compare,crosstab,disputes}_{final,stock}.tsv`.
- `inspections/b1_insp.py` and `b1_plot.py` (env bench_tools) -> 37 working dotplots in `inspections/fig/`, plus
  `data/{cases,evidence,repro,verdicts}.tsv`.
  - Adapted from inspect_disputes; `awseg.py` is vendored from it.
  - The route and read-out windows were rebuilt and reclassified: 0 calls differ from the files.
- `inspections/b1_thin_anchor.py`: how present calls pass rule 5a.
- `scores/discordance.py`: per-element discordance inside the tie band.
- `09_report_tables.py` -> `metrics/report_tables.md`.
- `memo_bakeoff.md`: phase B1 section.

**Results** (full text in REPORT.md):
- **Sims:** all candidates pass the precision bar.
  - The routes in the 0.005 band are mm2 = mm2_N50 0.8992, flank-mm2_2k 0.8984, 10k 0.8978, 20k 0.8974 and 5k 0.8958,
    the same set at high tier.
  - Below the band: flank-blast_10k 0.8847 and fastga = hybrid 0.8075.
  - Backends with mm2: lastz 0.9325, mappy 0.8992, wfa 0.8510.
- **chr10:**
  - resolved_frac is 0.462-0.464 for the flank-mm2 routes against 0.448 for mm2.
  - annot_agree is 0.80-0.81 and e_in_annot about 0.18 everywhere.
  - mm2's reciprocity is 0.01-0.02 higher.
- **Read-out:**
  - P/E agreement is 99.7-99.9%.
  - High-tier contradictions: mm2 5+3; the flank routes 7-11 per direction.
- **Inspections:** 37 cases (26 contradictions, 8 sampled, 3 cross-checks).
  - The engine is right in 19 and likely right in 3. Wrong: flank-2k 3, flank-5k 1, lastz 2, mm2 2. Undecidable: 3.
    Same site with a D/E state detail: 2.
- **Ablation, sims:** the mappy routes change by at most +0.003 crf, while FastGA falls 0.875 -> 0.808.
- **Ablation, chr10 mm2:**
  - breakpoint/span_cap windows: 10,574/3,385 -> 756/545;
  - U fraction: 0.429 -> 0.203;
  - read-out contradictions: 34 (24 high) -> 6 (5 high).

## Phase B2 (2026-11-11 10:26-11:15)

Status: DONE_WITH_CONCERNS.

### Decision (rules 13-15, task-24b-rulings 12-13)

**Precision bar.** Every candidate passes.

**Tie band.** These routes lie within 0.005 of the best pooled crf (all tiers):

| route | crf | mean WG pair (h) |
|---|---|---|
| mm2 | 0.8992 | 0.390 |
| mm2_N50 | 0.8992 | 0.459 |
| flank-mm2_2k | 0.8984 | 0.194 |
| flank-mm2_10k | 0.8978 | 0.350 |
| flank-mm2_20k | 0.8974 | 0.428 |
| flank-mm2_5k | 0.8958 | 0.219 |

- The cost is the mean, over the three chr10 pairs, of the per-stage extrapolated whole-genome (WG) pair wall time.
- All six meet the cost bar: the worst pair takes 0.25-0.56 h, and memory per stage is <= 58 GB.

**Tie-break (ruling 12).**
- The cheapest route is flank-mm2_2k (0.194 h).
- flank-mm2_5k (0.219 h, +12.7%) is within the 20% noise, so the two are tied and the tie goes back to crf:
  0.8984 > 0.8958.
- mm2 costs 2.0x as much.
- **Route: flank-mm2 with a 2-kb cap.**

**Alternative readings:**

| reading | winner |
|---|---|
| worst pair, with noise tolerance (5k 0.254 h vs 2k 0.267 h are tied) | 2k |
| mean, no tolerance | 2k |
| worst pair, no tolerance | 5k |
| rule 11 linear: mean with tolerance (5k 0.42 and 20k 0.48 tie; 20k has the higher crf) | 20k |
| rule 11 linear: worst pair (20k 0.62 h) | 20k |

The linear readings are inflated for 2k by a single 423-s genotype chunk, an artifact of the window-merge defect.

**Backend (rule 15 with the winning route):**

| backend | crf | P high (tp/fp) | E high (tp/fp) | precision bar | WG pair cost |
|---|---|---|---|---|---|
| mappy | 0.8984 | | | pass | |
| lastz | **0.9300** | 0.9993 (2799/2) | 0.9940 (1320/8) | pass | about 0.45 h (B73~T18 estimate) |
| wfa | timed out on R1_s1 (failure) | | | | |

- **Backend: lastz.** Its lead over mappy is +0.032, outside the tie band.
- Per ruling 15 it is recorded, not ported. The engine's default backend stays mappy until the controller's port
  task.

### Backend follow-up runs (ruling 14)

The two variants were declared in PARAMS.md section 8 before they ran, and registered in bakeoff.py's VARIANTS.

**flank-mm2_2k_lastz, sims.** 6 of 6 ok, 9-21 s each, at 32 threads, from empty rundirs under runs/.

| crf all tiers (high) | unresolved | P high precision | E high precision |
|---|---|---|---|
| 0.9300 (0.8837) | 0.0268 | 0.9993 (per sim 0.996-1.000) | 0.9940 (per sim 0.976-1.000) |

**flank-mm2_2k_wfa, sims.**
- R1_s1 timed out at 1,800 s (exit 124, 13 guarded windows, load about 190), which is a failure.
- The other 5 sims were not run. A timeout fails the variant, and those runs could not change the decision, so the
  deviation saves up to 2.5 h of 32-thread runs.
- The other 5 can be run in B3 if completeness is wanted.

**flank-mm2_2k_lastz, chr10 B73v5 -> TIL18** (genotype-only, the flank-mm2_2k run's anchors seeded, "anchors done,
skip").

| wall | busy | WG pair estimate | resolved_frac | U | annot_agree (single-file) |
|---|---|---|---|---|---|
| 50.8 s | 1,443 s | 0.45 h (pass) | 0.495 (mappy 0.445) | 0.131 | 0.771 (mappy 0.779) |

- Read-out comparison: 16 contradictions, 15 with the route call high tier and 8 with both high.
- All 15 high-tier contradictions were already inspected: 10 engine right, 5 wrong. The wrong ones are 3 segmental
  duplicate cases and 2 lastz short-segment cases.

**wfa on chr10.** The batch's final-engine mm2_wfa run finished: 2,249 s wall and 61,138 CPU-s for one direction,
which is about 21 h per extrapolated pair. That fails the cost bar.

### Step 9 (ruling 15)

**Commit 568f90d** on plan1-engine: "Set default anchoring route from bake-off". It has a short body, uses the existing
identity (cwb14), has no trailers and is not pushed.
- `src/ltrpav/constants.py`:
  - `DEFAULT_ROUTE = "flank-mm2"`;
  - `FLANK_CAP = 2_000`, which is also the cap of flank-blast and of hybrid's fallback;
  - one-line reasons on both.
- `tests/test_smoke.py`: the default-route assertion.
- `docs/DESIGN.md`:
  - 5.1 gains one sentence pointing to section 9 (it still says "capped at ~10-20 kb");
  - section 9 gains the outcome paragraph, with the backend result and the real-data caveats.
- The two stale lines of ruling 16 (5.3 "long join" and 5.4 boundary_offset) were already fixed by 24F (checked).

**How FLANK_CAP and route.cap interact.** FlankMm2Route, FlankBlastRoute and HybridRoute bind `cap=FLANK_CAP` as a
default argument when the module is imported. So the constant is the default cap of every flank route, and the
route's `params()`, and therefore the anchor cache key, carry it.

**Checks.**
- After the edit, a plain `ltrpav run` on sim R1_s1 with no `--anchor` gives calls byte-identical to the bake-off's
  `runs/R1_s1/flank-mm2_2k` in both directions.
- `pytest -q -W error` with the env's bin first on PATH: 733 tests, exit 0. The project's config suppresses the
  summary line.
- `ruff check .`: clean.

### Harness changes made while the chr10 batch ran

Atomic swap of bakeoff.py at 10:27, validated first. The old copy is at `metrics/bakeoff.py.before_b2`.
- VARIANTS gained flank-mm2_2k_lastz and flank-mm2_2k_wfa.
- `VARIANTS["hybrid"]` now passes `--flank-cap 10000` explicitly.
  - Reason: the batch's chr10 hybrid run had not started, and FLANK_CAP becomes 2,000 with the commit. Without this
    change, that run would have measured a 2-kb fallback, unlike its sims runs.
  - Its anchor cache key is unchanged (cap 10,000). The runs table shows cap 10000 for that row. PARAMS.md records
    this.
- Nothing else in the batch is affected: its remaining runs (fastga, hybrid, mm2 at 64 threads) pass `--anchor`
  explicitly.

### Deviations and incidents

1. **wfa follow-up:** 1 of 6 sims run (see above).
2. **Outer timeout.** My first wfa call wrapped each measured run in `timeout 14m`. The R1_s1 run needed 30 min.
   - The outer timeout would have orphaned it without status.json, and my loop would then have started R1_s2
     beside it: 64 threads for me.
   - At 10:39 I killed my own loop shell and the outer timeout.
   - The measured run went on under the harness's own 30-min limit and wrote status.json.
   - No chr10 batch process was touched.
3. **`runs/runs.tsv` was regenerated by `bakeoff.py table`** (85 rows). The old copy is at
   `metrics/runs.tsv.before_b2`.

### What the rulings did not settle

- **Whether the 5 skipped wfa sims runs are wanted** for completeness (B3).
- **Ruling 12's tie set relative to the cheapest.** I formed the cost-tie set relative to the cheapest candidate,
  {2k, 5k}. Chaining ties pairwise would add nothing here, because 10k is 1.6x 5k.
- **The backend cost uses one direction.** It is estimated from the B73v5 -> TIL18 genotype run, with the reverse
  direction scaled by the route's own direction ratio, because chr10 has backends on that direction only.
- **FLANK_CAP = 2000 changes the default cap of flank-blast and of hybrid's fallback too.** Both were measured at 10
  kb in the bake-off. Making them 2 kb is a side effect of a single shared constant.
- **The route was chosen with the mappy backend, then the backend with that route** (rule 15's order).
  - With lastz, mm2_lastz (0.9325) and flank-mm2_2k_lastz (0.9300) would also tie.
  - Their B73~T18 costs are 0.62 h and 0.45 h, a 1.38x ratio that falls outside the 20% noise, so the flank route
    still wins.
  - The decision does not depend on this order.

### Real-data caveats beside the decision (ruling 16)

All of these are in REPORT.md section 8 and in dead_ends.md.
- **Segmental duplicates.** Short flanks (2-5 kb) call E on the wrong copy of a segmental duplicate: 4 chr10 cases,
  and the sims hold none. With lastz the same 3 cases recur, plus 2 lastz short-segment false E calls.
- **mm2's wide windows.** They can call high-tier P on a nearby same-family copy (2 cases).
- **Rule 5a's two loopholes.**
  - A thin or repetitive one-sided run: 6 of 4,141 mm2 high-tier own present calls are thin.
  - The TSD exception without flank continuity: 11 of 4,141.
  - The controller tightens both before Task 25.
- **The window-merge padding defect.**
- **FastGA's loss under the syntenic net.**
- **The sims' lack of segmental duplications.**

### Pending for B3 (when chr10/batch.exit exists)

- The chr10 rows of fastga and hybrid: metrics, read-out comparison, and 10 FastGA breakpoint-window dotplots.
- Thread scaling (mm2_t64): a section is ready in `09_report_tables.py`.
- The overview figure, under the making-figures skill: pooled crf against the WG pair wall, with both bars drawn
  and chr10 resolved_frac shown.
- Optionally, the 5 remaining flank-mm2_2k_wfa sims runs.

## Fix round 1 (2026-11-11, after task-24b-review.md)

Status: DONE. Review: Spec ✅, Quality "Changes needed" (0 Critical, 1 Important, 11 Minor). The decision is unchanged.

**Constraints kept.**
- ltrpav was imported only from the 568f90d snapshot (D/b3_snap/src; `ltrpav.__file__` checked).
- At most 8 threads; every probe under a timeout.
- REPORT.md was changed with the Edit tool only.
- No edit or commit in the LTRpav repo, because Task 24H holds it.

**Superseded B2 text in this report.**
- Line 69 ("Every candidate passes") now reads: 14 scored candidates pass.
- Lines 99-100: the linear readings are now four rows (see I1).
- Lines 205-208: the order check now holds only among the measured lastz combinations.

| finding | status | change |
|---|---|---|
| I1 linear readings | fixed | REPORT section 0: the single linear row is replaced by the review's four rows (linear: mean with tolerance 20k, mean without 5k, worst pair with tolerance **mm2_N50**, worst pair without 20k), plus "one reading picks a whole-genome route". New `D/10_decision_trace.py` computes the bars, band, ruling 12, all 8 readings, the backend step and the order check from the tables, and writes `metrics/decision_trace.txt`. REPORT section 7 item 8 quotes the result; section 12 reruns it. Its readings match the review's table exactly. |
| M1 order claim | fixed | Section 0 now says "among the measured lastz combinations", that the costs are one-pair, one-direction estimates, and which routes never ran with lastz. The ratio is now 1.37x (exact r). |
| M2 candidate count | fixed | Section 0 table and section 7.1: 14 scored (9 routes, 4 phase-A backends, flank-mm2_2k_lastz); flank-mm2_2k_wfa timed out unscored. |
| M3 stale count | fixed | Section 5: 135 high-tier contradictions, 130 without the yardstick; E>P 81, E>T 48, E>S 6 (recounted from `metrics/readout_disputes_final.tsv`). |
| M4 FastGA cause | fixed | One statement, in section 5a: the lookback explains the extra windows and the lost anchored bp, and its crf effect was not tested. Sections 6 and 8.5 point to it, and dead_ends.md matches. |
| M5 per-sim wording | fixed | Section 2 now reads "every mm2 and flank-mm2 route >= 0.974". The old ">= 0.975" was also off by rounding (flank-mm2_2k R1_s1: 193/198 = 0.9747). fastga and hybrid (mappy) go down to 0.918. |
| M6 dead_ends hybrid | fixed | "chr10: not run" (the batch stopped before hybrid started); its cost is unmeasured. |
| M7 figure, unmeasured costs | fixed | Figure 1C: cost axis 0.12-28 h, then an axis break and an off-axis column, "cost not measured", for FastGA/hybrid, FastGA + LASTZ and FastGA + WFA. The hatched numeric band is gone. Redone under the making-figures skill; memo.md has the figure check. |
| M8 figure headline | fixed | The headline claims "as accurately" on the sims only, and adds the real-data caveat (wrong-copy calls in duplicated segments). The legend gives back the 8 against 3 high-tier false E (Fisher's exact p = 0.226) and chr10's 18 against 8 read-out contradictions, 3 of them inspected wrong-copy errors. New typicality numbers for panel A: full agreement in 3 of the 7 tiles that meet the region rule; 83% (7,533/9,064) chromosome-wide. |
| M9 noise n = 1 | fixed | Sections 1 and 4: the 20% tolerance rests on one pair of measurements, taken at 32 against 8 threads, so thread count is confounded with load. The mean reading picks 2 kb either way. |
| M10 lastz scaling | fixed | Section 4: 65-75% kernel time (505 s user / 925 s sys; 213 / 635), likely the per-window subprocess and temp files. TIL18~TIL01 scaled by mappy's 3.2x busy ratio gives 1.33 h, under the bar. Task 25 confirms. |
| M11 rule 5a coverage | fixed | Measured on the default route: flank-mm2_2k has 4,118 high-tier own present calls, 4 thin and 9 TSD-only (17-20 s per direction; 0 reclassified calls differ from the calls files). Added to section 5a's table, section 8.3 and dead_ends.md. |
| M11 shared FLANK_CAP | fixed (documented) | Section 7.7: flank-blast's and hybrid's 2-kb default is unmeasured, and no CLI option overrides the cap. |
| M11 DESIGN 5.1 | **not fixed** | This is a repo edit, and Task 24H holds the repo. The gap is recorded in REPORT section 7.7. Proposed text is below. |
| M11 wfa timeout cause | fixed | REPORT section 7.5, dead_ends.md and memo_bakeoff.md now read: 504/512 windows done, 13 guarded at WFA's step cap, 5.4 busy cores of 32 on average, against mm2_wfa's 200-311 s sims. So the route's windows, not load, set the time. |

**Decision trace** (`python 10_decision_trace.py`; full text in `metrics/decision_trace.txt`):

```
route flank-mm2_2k: band of 6 within 0.005 of 0.899194; cheapest flank-mm2_2k 0.1941 h; cost-tied flank-mm2_5k 0.2187 h (x1.126); crf 0.898387 wins
backend lastz: 0.930040 against mappy 0.898387 (+0.0317, no tie); both bars met (about 0.45 h, one-pair estimate); wfa timed out
readings: per stage: mean+tol 2k, mean 2k, worst+tol 2k, worst 5k; rule 11 linear: mean+tol 20k, mean 5k, worst+tol mm2_N50, worst 20k
```

**Proposed DESIGN 5.1 edit,** for the controller or Task 24H. In the "Flank mapping (F)" bullet, replace "capped at ~10-20 kb
(published 0.5-2 kb flanks would mostly sit inside other TEs in maize). The bake-off (section 9) set the default cap at 2 kb."
with: "capped at ~10-20 kb in the pre-bake-off prior (published 0.5-2 kb flanks would mostly sit inside other TEs in maize). The
bake-off (section 9) measured caps of 2, 5, 10 and 20 kb and set the default at 2 kb. On the sims it matches the longer caps
on accuracy at about half the cost; on real chr10, 2-5-kb caps called E on the wrong copy of a segmental duplicate
(4 cases)."

**Files.**
- Bake-off directory, D = benchmark_pav/bakeoff:
  - D/10_decision_trace.py and D/metrics/decision_trace.txt (both new);
  - D/REPORT.md, D/memo_bakeoff.md and ../dead_ends.md;
  - D/inspections/data/thin_flank-mm2_2k_*.{tsv,log} (new).
- Figure, D/figures/: bakeoff_overview/{bakeoff_overview.py, bakeoff_overview_data.py, .png, .pdf, _numbers.tsv (108 numbers), memo.md}
  and SPEC.md.
