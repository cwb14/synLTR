#!/usr/bin/env bash
# Hourly status line in logs/heartbeat.log, independent of the interactive session. Stops one beat after the job exits.
set -u
HERE=$(dirname "$(readlink -f "$0")")
. "$HERE/run.env"
S=$PROJECT/state; R=$PROJECT/run; L=$PROJECT/logs; mkdir -p "$L"
while :; do
  lp=$(cat "$S/launcher.pid" 2>/dev/null || echo 0); alive=0; kill -0 "$lp" 2>/dev/null && alive=1
  if [[ -e $S/job.exit ]]; then st="EXITED rc=$(cat "$S/job.exit")"
  elif [[ -e $S/job.started ]]; then ((alive)) && st=RUNNING || st=DIED_WITHOUT_EXIT_RECORD
  else ((alive)) && st=WAITING || st=WATCHER_DEAD; fi
  rss=$(ps -s "$lp" -o rss= 2>/dev/null | awk '{s+=$1} END{printf "%.0f", s/1048576}')
  prog=""; [[ -f $R/ltrquest.log ]] && prog=$(grep -aE 'FP round|detecting |ROUND|Round [0-9]|=== ' "$R/ltrquest.log" | tail -1 | cut -c1-110)
  read -r b0 t0 < <(awk '/^cpu /{print $2+$3+$4+$7+$8+$9, $2+$3+$4+$5+$6+$7+$8+$9; exit}' /proc/stat); sleep 10
  read -r b1 t1 < <(awk '/^cpu /{print $2+$3+$4+$7+$8+$9, $2+$3+$4+$5+$6+$7+$8+$9; exit}' /proc/stat)
  busy=$(awk -v b=$((b1-b0)) -v t=$((t1-t0)) -v c="$(grep -c ^processor /proc/cpuinfo)" 'BEGIN{printf "%.0f", (t>0)?c*b/t:0}')
  echo "$(date '+%F %T') $st | busy_threads=$busy | load=$(cut -d' ' -f1 /proc/loadavg) | job_rss_GB=${rss:-0} | run_size=$(du -sh "$R" 2>/dev/null | cut -f1) | $prog" >> "$L/heartbeat.log"
  case $st in EXITED*|DIED*|WATCHER_DEAD) break;; esac
  sleep 3600
done
