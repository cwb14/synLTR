# fig5_generality — the same LTR-RT signal in two more admixture events (wild Zea, sweet orange)

date: 2026-11-07
purpose: Fig. 5 of the LTRmix benchmark (SPEC.md block "Fig. 5 `fig5_generality`")
env: `source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix` (python 3.11, matplotlib 3.11.2,
  pandas 3.1.1, numpy 2.4.6, scipy 1.17.1, edlib, samtools, mafft); Liberation Sans / Mono (fonttype 42)
inputs (read-only, /data2/chris/maize_introgression/benchmark):
  lineage2/out/CsB_Cr_Cm/{elements.CsB.tsv, tracts.CsB.bed (recent model), decoy_tracts.Cm.bed, stats.tsv};
  lineage2/out/{Cr_Cm_CaM, Cr_Cm_CaP, CsA_Cr_Cm}/stats.tsv; lineage2/out/{blocks.tsv, orthologs.*.tsv.gz};
  lineage2/eval/{trios,tracts,truth_tracts}.tsv; lineage2/truth/{CsB.M.bed, CsA.P.bed};
  lineage2/ltrquest_{a,b}/<G>_LTRs_depth*_clean_ltr.tsv; ../inputs/{CsB,Cr,Cm}.fa (+.fai; samtools faidx);
  genus/wgk/{wgk_trio.tsv, wgk_trio.<R>_TIL18_Zn.tsv, wgk_trio.Zh_TIL01_Zn.tsv}; genus/out/<trio>/stats.tsv;
  results/main3/stats.tsv; wgk/wgk_all.TIL18.tsv (maize whole-assembly comparator)

## Layout sketches (chosen: 1)
1. Fig. 1A-style vertical ideograms for sweet orange, then zoom, base pairs, and three quantification panels (chosen)
```
A  chr1 ... chr9 of sweet orange haplotype B (S), each between pummelo Cm (P, left) and mandarin Cr (M, right)
   P |dec| ribbons |blue ticks|[S box: posterior]|truth|call|vermillion ticks| ribbons | M     key lower right
   partner chromosomes flipped to S's orientation (marked), B window boxed on chr9, C element marked on chr1
B  3-Mb zoom across the chr9 tract: Cm lane / links (blue = near-identical) / S lane (classes) / posterior,
   published tract, called tract / links (vermillion = near-identical) / Cr lane; every element to size
C  one element: S copy and M copy to scale (LTRs, every difference), junctions at bp (shared TSD), P empty site
D  clock: every shared insertion on a K2P axis (S+M above, P+M below), D per age stratum +- 2 SE; controls
E  wild Zea: per-chromosome k-mer D, whole assemblies (diamonds) and EDTA LTR-RTs (open), 3 comparisons, joined
F  every event and control: D_kmer +- 2 SE (LTRquest filled, EDTA open, whole assembly diamond), Z beside each
```
2. SPEC's horizontal layout: nine rows (S chromosome with ticks above/below, posterior, tracts, truth bar;
   the P homolog beneath with decoys and gray ribbons). Reads like a karyoplot, but needs ~100 mm of height
   at 3 mm/Mb (chr3 = 50.5 Mb sets the width, leaving the other rows half empty), drops the donor genome as a
   partner, and breaks the visual grammar of Fig. 1A that readers have just learned.
3. Two-column page: left half the citrus genome as a circular plot (ideogram ring, posterior and truth rings,
   ortholog chords to P and M), right half B-F stacked. Striking, but position claims (tract edges vs published
   edges) are hard to read on a circle (skill: keep position claims linear), and B/C lose width.
Why 1: the same view as Fig. 1A (sister left in blue, recipient center, donor right in vermillion, posterior
inside the recipient), so maize and sweet orange read in one grammar; every informative element is a tick, both
partner genomes are drawn at the same bp scale with ribbons, and published vs called tracts sit side by side
next to the recipient, with the decoy calls on the sister (the control) at the homologous position.
Changes over 5 render-inspect rounds: B's bar labels became direct labels with more spacing; E/F markers
unified with Fig. 2F (filled circle LTRquest, open circle EDTA, diamond whole assemblies) after a first draft
used filled = whole in E and filled = library in F; D's y-label was clipped and its controls key overlapped
data (moved); F's Z values left the axes; C moved 2.5 mm down (its domain labels touched B's axis labels); the
A "B" label moved next to the S box (it sat beside the M box); mathtext italics given normal spaces.

## Example selection and checks
Panel B (rule from SPEC; implemented in `boundary_table()` / `select_boundary()`):
- 15 called tracts (recent-sharing model, tracts.CsB.bed) -> 25 internal boundaries (>= 5 informative elements
  beyond the boundary on the chromosome; chromosome-end edges excluded)
- flank posterior = mean posterior of the 10 elements nearest the boundary inside the tract and outside it;
  distance = sum of |percentile - 0.5| for the two flanks against all 25 boundaries
- candidates restricted to the 5 boundaries of tracts that overlap published segments (skill: an example never
  displays a miss; the median target is still all 25): chosen CsB_chr9:27,393,588 (start of tract
  27.39-28.59 Mb; flanks 0.85 / 0.18 vs median 0.85 / 0.05; percentile distance 0.40)
- robustness (flank size -> pick): 1 -> chr2 3.50; 3, 5 -> chr1 24.17; 10 -> chr9 27.39; 15, 20, 30 -> chr9 28.59
  (both chr9 boundaries are in the same window, so the window is the same for flanks >= 10)
- window = boundary +- 1.5 Mb = CsB_chr9:25.89-28.89 Mb; holds the whole published tract (27.09-28.83) and the
  called tract; P window Cm_chr9:8.33-11.33 Mb, M window Cr_chr9:3.13-6.13 Mb (inverted), equal length,
  offset/orientation from the median of the ortholog pairs inside the window
- 61 / 58 / 68 elements (S / P / M); near-identical links 17 to P (S 25.93-27.07 Mb), 5 to M (27.67-28.59);
  the 0.30 / 0.24 Mb of the published tract not covered hold 9 private elements, none informative
Panel C (SPEC rule + checks; `example_candidates()`, `check_element()`, `select_element()`; log in
work/example_screen.tsv):
- candidates: CsB elements inside published M segments, class near_donor or donor_only, Cm status absent: 433
  (medians K2P 0.0375, length 7,308 bp); ranked by |percentile - 0.5| of K2P + of length
- checks, in this order of rank until the first pass: re-extract S and M copies +-60 bp (samtools faidx),
  element orientation; TSD 5 bp identical at both ends in both copies, equal to the annotator's TSD (library
  `tsd` column, + strand) and not a mononucleotide run; TG..CA in both; same TSD in both; copies aligned with
  mafft (--globalpair): colinear (no indel > 50 bp); self-LTR K2P re-aligned within 2 SE of the annotation;
  Cm empty site: syntenic Cm interval from the 3 nearest S elements with Cm orthologs on each side (+-30 kb,
  <= 3 Mb), edlib infix search (both strands) of [S 5' flank incl. TSD + S 3' flank after the second TSD],
  pass if <= 10% edits and length within +-3 bp (one TSD copy, no element); near-identical (class near_donor:
  the panel shows a near-identical shared copy); family-typical length (family >= 10 copies in the CsB
  library, length within its 10-90th percentile); canonical domain order (Copia GAG PROT INT RT RH; Gypsy GAG
  PROT RT RH INT [CHD])
- chosen (rank 37): CsB_chr1:20,470,005-20,480,781 #LTR/Gypsy/Retand, + strand, 10,777 bp (60th percentile of
  104 family copies), GAG-PROT-RT-RH-INT; M copy Cr_chr1:21,763,985-21,774,761: 0 substitutions, 0 indel
  columns in 10,777 bp; TSD ATAGA at both ends of both copies = annotator TSD; TG..CA; self-LTR K2P 0.0372
  re-aligned = 0.0372 +- 0.0075 annotated; P empty site Cm_chr4:9,901,752-9,901,866 (- strand), 8 edits in
  115 bp, single ATAGA; inside the chr1 M segment (posterior 1.0); near_donor div_Cr = 0 (27% of near_donor
  candidates have div 0; median 0.0031)
- the 36 ranked higher: 16 failed TSD checks, 30 the empty site (7 of them: no syntenic Cm interval <= 3 Mb),
  9 TG..CA, 11 colinearity, 18 family/domain/K2P (several fail more than one); rank 22 (SIRE
  CsB_chr1:6,871,373-6,881,319, donor_only) failed only near-identity (copies 2.1% diverged)
- not on panel B's window: no chr9-tract candidate passes (6 candidates: TSD mismatches, no clean empty site,
  or the one clean donor_only copy differs by a 4.2-kb indel), so C is marked on chr1 in A instead of chained
  through B

## Commands
```bash
source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix; export NUMPY_MADVISE_HUGEPAGE=0
cd /data2/chris/maize_introgression/benchmark/figures/fig5_generality
python fig5_generality.py -v               # uses ./work caches (6 s, 0.9 GB RSS)
python fig5_generality.py --rebuild -v     # clears work/*.pkl and work/aln/*, recomputes everything:
                                           # 2 min 24 s wall, 3.7 GB RSS at server load ~150; numbers identical
python fig5_generality.py --figure-only    # PNG only (layout iterations)
```
Inside the script: `samtools faidx inputs/{CsB,Cr}.fa <element +-60 bp>`, `samtools faidx inputs/Cm.fa
<syntenic interval>`, `mafft --globalpair --maxiterate 100 --quiet --thread 2` (copy pair; LTR pair), edlib
infix (HW) search for the empty site. Per-chromosome whole-assembly D: per-window tallies of
genus/wgk/wgk_trio.<R>_<S>_Zn.tsv summed per Zn chromosome, 5-Mb delete-one-block jackknife exactly as
scripts/wg_kmer_trio.py `jack()` (genome-wide values reproduce wgk_trio.tsv to 1e-6; asserted).
Working scripts (not needed for the rebuild): work/run_screen.py, work/screen_example.py (candidate screens),
work/plain_check.py (honesty check, work/plain_check.png).

## Outputs
- fig5_generality.pdf: p1 figure (180 x 233.5 mm), p2 short legend (253 words), p3 long legend (~1,200 words);
  text as text (Liberation Sans / Sans-Bold / Sans-Italic / Mono embedded, CID TrueType)
- fig5_generality.png: 300 dpi, figure only (2125 x 2757 px)
- fig5_generality_numbers.tsv: 104 legend numbers with sources ("computed here" where derived from raw data)
- work/: caches (*.pkl), aln/ (mafft inputs/outputs), example_screen.tsv, working crops and plain_check.png

## Panels
A: 9 CsB chromosomes, each between its Cm (P) and Cr (M) homolog at one bp scale (1.55 mm/Mb); 3,714 S-P and
   1,737 S-M 1:1 ortholog lines; ticks near_donor 562 / donor_only 242 (right), near_sister 2,774 /
   sister_only 480 (left); recent-model posterior per element inside S; published M segments (green outline),
   15 called tracts (black outline), 4 decoy tracts on P; partners flipped to S's orientation where the main
   collinear orientation is opposite (P chr4, 3, 6, 8; M chr9), marked; B window and C element marked
B: chr9 25.89-28.89 Mb with P and M windows; every element of three genomes to size; links colored when
   near-identical (< 0.0143); published tract, called tract and posterior on S's axis
C: Retand copies to scale with LTRs and domains, difference band (empty: 0 differences), bp junctions with
   the shared TSD, Cm empty site with one TSD copy (P flank mismatches gray)
D: all 622 S+M and 225 P+M shared insertions on the donor-copy K2P axis (counts per stratum, all strata);
   D per stratum (>= 10 insertions, from stats.tsv) for CsB, both sour-orange controls; P-M ortholog divergence
   IQR band (0.027-0.049); zero line
E: per-chromosome D for Zh, TIL01, TIL25 vs TIL18 (donor Zn): whole assemblies (computed from per-window
   tallies) and EDTA libraries (stats.tsv D_kmer_by_chrom); lines join a chromosome's whole-assembly values
F: genome-wide D_kmer +- 2 SE for maize, Zea (3 comparisons) and citrus (CsB, CsA, 2 controls); whole-assembly
   comparators where they exist (maize recomputed from wgk_all.TIL18.tsv = REPORT +0.107, Z 8.9); Z beside each

## Gotchas / decisions
- SPEC says CsB D_kmer +0.316; trios.tsv and stats.tsv give 0.315476 (+0.315). findings.txt prints +0.3155,
  which rounds to +0.316 (double rounding). The figure uses the table value +0.315.
- SPEC mixes the two painting models (posterior 0.98 / 0.04 and AUROC are ancestry-model numbers; 15 tracts,
  4 decoys, 42.7 Mb, precision 0.84 / recall 0.95 are recent-model numbers). Decoy tracts are written only
  for the recent model (decoy_tracts.Cm.bed = 4 = recent n_decoy_tracts), so the figure uses the recent model
  throughout: posterior 0.98 inside / 0.03 outside, AUROC 0.995 (ancestry: 0.98 / 0.04, 0.995).
- 2 of the 4 decoy tracts on P lie opposite S's published M segments (chr1 16.98-19.05, chr2 0.47-2.45 Mb via
  P's orthologs in S): there S is not a pummelo-like sister of P, so the decoy is not a pure null in this
  design (stated in the long legend).
- Cm chromosome numbering differs from the DVS numbering (S chr1-9 -> Cm chr4, 2, 5, 7, 3, 6, 1, 8, 9); Cm chr8
  and chr9 arms are oriented differently from S (crossing lines; not interpreted).
- D_ins_by_age has no rows for K2P = 0 and (0, 0.002] (ltrmix skips strata with < 10 insertions: 6 vs 1, 3 vs 0);
  their insertions are drawn in the strip, no D point.
- No LTR clock rate is assumed for citrus: the age axis is K2P, anchored by the P-M ortholog divergence IQR.
- Controls' D_ins_by_age: |D| <= 0.30, |Z| <= 2.8 (Cm vs CaP, K2P 0.05-0.1, Z 2.83).
- Example C: the SPEC rule admits donor_only, the SPEC panel text asks for a near-identical copy; both kept by
  ranking all 433 candidates as the rule says and adding near-identity as a check (the first candidate passing
  all other checks, rank 22, is a donor_only SIRE 2.1% diverged from its M copy).
- Session-bound background jobs are blocked: the candidate screen was launched with setsid nohup.

## Honesty check (skill): plain plot vs showcase
work/plain_check.png: 1-Mb windows, mean posterior vs published M fraction (Spearman 0.55, n = 303 windows with
elements; mean posterior 0.93 in windows > 50% published M vs 0.04 elsewhere) and both along the genome. Panel A
shows the same: the large segments match, the chr5 end (1.1 Mb, 5 elements) is missed, and the false-positive
calls (chr3 x3, chr5 start, chr7, chr8, chr9 start and 20.2 Mb) are drawn as boxes without green beside them.
Panel A does not look stronger than the plain plot. Largest element-free gap 1.3 Mb (chr4; 2 mm at this scale),
so the per-element trace never bridges a large unmarked stretch.

## Figure check (answered by the figure agent)
1. Panel A in genome coordinates, every element drawn: yes. A: every informative S element is a tick, every 1:1
   ortholog pair a line, all three genomes at one bp scale; B: every element of three genomes drawn to size.
2. Raw evidence for a real, typical, verified example: yes. C: base-pair junctions re-extracted from the three
   assemblies (shared TSD, empty site with one TSD copy, flank mismatches) and the copy alignment (0 of 10,777
   differ); chosen by the SPEC rank rule, first of 37 to pass all structural checks (listed above).
3. Control as a full partner at the same scale: yes. A: P (the sister) drawn beside every S chromosome with its
   decoy tracts; B: P window of equal length with its elements; D/F: sour-orange control trios; E: TIL25.
4. Every null drawn: yes. A: decoy tracts on P; D: control trios per stratum and the zero line; E: control
   comparison and zero line; F: control rows and zero line. (B and C are zooms, no null.)
5. On-figure text only letters, axis labels, ticks, direct labels, keys, n: yes (counts in D; Z in F as the
   SPEC asks; "0 differences in 10,777 bp", "one TSD copy", "empty site", "control" are direct labels).
6. Full-resolution crops clean, one grid, reading order, no empty bands: yes (crops of A left/right/key, chr9
   zoom marks, B, C, D, E/F inspected at 300 dpi; smallest text 5.5 pt; A's right edge = B's axis end at
   176 mm; B's lanes and C's sequence blocks start at 24.5 mm).
7. Each panel answers a different question; legend pages follow the rules: yes. A where (genome), B how a tract
   edge looks element by element, C the mechanism at bp, D age (gene flow vs lineage sorting), E a second
   event in another annotator, F generality across events with controls. Short legend 253 words, long ~1,200
   (above the ~1,000 target because every selection rule is stated); last line as required.
