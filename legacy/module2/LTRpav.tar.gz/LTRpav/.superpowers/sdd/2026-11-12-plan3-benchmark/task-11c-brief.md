# Task 11 Part C: record the decisions (Task 11 Step 4) and take snapshot 2

Plan 3 Task 11 judged the simulation grid in `benchmark_pav/plan3/sim/SIM_RESULTS.md` (Part B, reviewed). This dispatch
records its decisions in the repo, commits, and takes the frozen code snapshot that the real-genome Tasks 13-16 will
use. Read the plan's Step 4 in `task-11-brief.md` (this directory) first; it is your requirements. This file adds
the decisions and the controller's rulings.

- Repo: `/data2/chris/maize_introgression/LTRpav`, branch `plan3-benchmark`, BASE 78a7c05. Commit on this branch;
  never push, never create branches or worktrees.
- Paths: `P=/data2/chris/maize_introgression`; `SIM=$P/benchmark_pav/plan3/sim`.

## The decisions (from SIM_RESULTS.md, reviewed)
Take every number from SIM_RESULTS.md and `$SIM/tables/`, citing the table. Change no decision.
1. **Painting variants: none adopted; the default stays `main` (rule 5).**
   - `any` and `decoy`: no q <= 0.05 tract in any of the 36 C>A power runs; realized FDR 0/0, Clopper-Pearson upper
     bound 1 > 0.10.
   - `anydecoy`: 21 tracts at q <= 0.05, none false; CP upper bound 0.161 > 0.10; bp recall sign test on 1 usable
     pair (p 0.5).
   - All four models hold the null (rule 4).
   - Default fits are degenerate (rule 6) in 7 of 36 C>A power runs.

   No constant changes.
2. **Direction (rule 7): not confirmed.** All 6 gene-flow posctl runs read "none". DESIGN 7.6 states the cause as
   SIM_RESULTS.md now gives it (after its review):
   - C1>A1: the posctl design leaves DFO, DIL and DFI each with an empty class, and direction.py names no direction
     when a jackknife Z is undefined, while the pre-registered prediction used a binomial Z;
   - A1>C1: too few loci at 50 Mb;
   - the posctl nulls are uninformative.

   The test is therefore neither validated nor refuted. Plan 4 leads: the handling of a saturated statistic, and a
   positive control with non-empty classes. Consequences:
   - the direction rows' note in `src/ltrpav/analysis/direction.py` becomes "not validated by simulation (Plan 3)",
     and the expected note in `tests/test_direction.py` changes with it;
   - whether to remove the test is a Plan 4 decision: say so in DESIGN 7.6, without removing anything.

## Do
1. **DESIGN.md edits.**
   - 7.1 and 7.4: each variant (`any`, `decoy`, `anydecoy`) reads "evaluated, not adopted", with its numbers, rule 4's
     outcome, and rule 6's count. Also rewrap the 7.4 line that the Task 11a commit left at about 145 characters (the
     file wraps near 115).
   - 7.6: rule 7's outcome (predictions, observed codes, posctl, false calls, ptlike) and its consequence (the note;
     removal is Plan 4's decision).

   Keep each edit short, in the document's style, and citing `benchmark_pav/plan3/sim/SIM_RESULTS.md`.
2. **The direction note.** Change it in direction.py. Write the test first: test_direction.py expects the new note,
   and fails before the change.
3. **Suite and ruff.**
   - Suite: `python -m pytest -W error -m "not slow"` and `ruff check .`, with env ltrpav's bin first on PATH and
     `NUMPY_MADVISE_HUGEPAGE=0`. Without the bin on PATH, tools are missing and tests skip or fail.
   - The full suite takes about 25 minutes, more than a tool call can wait. Run the focused tests yourself, commit,
     then launch the full suite detached and report its path. The controller reads the result:
     `setsid -f nohup bash -c 'cd /data2/chris/maize_introgression/LTRpav && export NUMPY_MADVISE_HUGEPAGE=0 PATH=/home/chris/bin/mambaforge/envs/ltrpav/bin:$PATH && python -m pytest -W error -m "not slow" -q -rfEs > SUITE_DIR/suite.log 2>&1; echo $? > SUITE_DIR/suite.exit' < /dev/null > /dev/null 2>&1`
     SUITE_DIR is given in your dispatch.
4. **Engine-key check and commit.**
   - Every `checkpoint.STAGE_MODULES` fingerprint equals 12d3e6c's: compare `PYTHONPATH` = the repo's src against
     `$P/benchmark_pav/plan3/snap/12d3e6c/src`.
   - Commit with the message "Record the simulated painting and direction outcomes (Plan 3)", using the global git
     identity and no AI attribution.
5. **Snapshot 2.** `src/` changed after snapshot 1 (78a7c05 and this commit), so take snapshot 2 of the new HEAD for
   Tasks 13-16.
   - Use the same procedure as snapshot 1, recorded in `$SIM/memo.md`: a `git archive` of src into
     `$P/benchmark_pav/plan3/snap/<short sha>/` with its SHA file.
   - Check that its STAGE_MODULES fingerprints equal snapshot 1's (`snap/4f3973e`) and 12d3e6c's.
   - Make it selectable without changing the simulation harness's default: `common/env.sh` takes `SNAP_SHA` from the
     environment when set (default stays 4f3973e) and keeps its checks (python is env ltrpav's; ltrpav.__file__ lies
     inside the chosen snapshot).
   - Show that `SNAP_SHA=<short sha> bash -c '. common/env.sh; python -c "import ltrpav; print(ltrpav.__file__)"'`
     resolves into snapshot 2, and that the default still resolves into snap/4f3973e.
   - Record snapshot 2 (sha, date, fingerprints, how to select it) in `$P/benchmark_pav/plan3/real/memo.md`.
6. Write nothing else outside the repo but `snap/<sha>/`, `common/env.sh` and `real/memo.md`.

## Constraints
- Engine modules stay untouched (`checkpoint.STAGE_MODULES`, `src/ltrpav/constants.py`). No maize-specific names in
  `src/`.
- Two real-genome queue workers (genotype_all.sh --tag w4/w5) are running from `snap/12d3e6c`. Never touch that
  snapshot, `real/genotype_all.sh` or anything under `real/stability/`. Never install packages in env ltrpav. Never
  kill a process.
- Probes: at most 8 threads and 15 minutes each.
- American English.
