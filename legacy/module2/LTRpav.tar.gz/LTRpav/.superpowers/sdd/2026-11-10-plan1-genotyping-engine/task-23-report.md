# Task 23 report
Commit bfeeb55 "Add simulation scoring". Files: src/ltrpav/sim/score.py (new), src/ltrpav/sim/cli.py (score subcommand), tests/test_score.py (12 tests).
Implemented per rulings 1-7: score(), confusion(), SCORE_COLUMNS, CONFUSION_COLUMNS, `ltrpav-sim score` -> PREFIX.score.tsv / .confusion.tsv.
Tests: 12 new pass; full suite passes with -W error; ruff clean on touched files (repo-wide ruff reports 10 pre-existing unsafe-fix-only findings elsewhere).
TDD: RED = ModuleNotFoundError ltrpav.sim.score at collection (score.py moved aside); GREEN = 11 dots then all pass (12 tests).
Smoke (seed 3, chr10:2-8Mb, run 9.7 s): out in scratchpad/score23/{A_in_B,B_in_A}.{score,confusion}.tsv
A in B: summary all n_scored 487, correct_resolved 0.8750, unresolved 0.0349, n_unannotated 47, missing 0; high 0.8529.
  P high tp223 fp1 fn25 prec 0.9955 rec 0.8992; E high tp100 fp0 fn19 prec 1.0000 rec 0.8403
B in A: summary all n_scored 486, correct_resolved 0.9052, unresolved 0.0329, n_unannotated 54, missing 0; high 0.8603.
  P high tp224 fp3 fn14 prec 0.9868 rec 0.9412; E high tp106 fp1 fn20 prec 0.9907 rec 0.8413
Self-review: no issues found.
Concerns/choices: (1) a missing call row counts as "not_high" in the high confusion table (its tier is "."), U in "all". (2) unresolved_frac is the same definition (call U / n_scored) for both tier sets, not tier-restricted. (3) Empty elements file -> ValueError. (4) score cells in summary/flag rows not applicable are None/NA.
