# Task 11 preparation (Part P): tooling for the rescore, a scoring smoke test, LTRmix's absent calls

Plan 3 Task 11 turns the simulation grid into `SIM_RESULTS.md` and DESIGN decisions. Its brief is
`task-11-brief.md` and the controller's rulings are `task-11-rulings.md` (both in this directory); read both. The
grid (144 runs) is still running: about 100 runs are finished (`sim/runs/<name>/run.done`), and two runners plus three
LTRquest-annotated runs (`sim/lq/<name>/`) are in progress. This dispatch builds and tests what Steps 1-2 need, so
they can start the moment the grid and the LTRquest runs end. It writes no `SIM_RESULTS.md`, no PASS/MISS verdict,
no `dead_ends.md` entry and no DESIGN edit.

Paths: `P=/data2/chris/maize_introgression`, `SIM=$P/benchmark_pav/plan3/sim`. Read first: `$SIM/memo.md` (the
scoring sections), the docstrings of `$SIM/eval_run.py`, `$SIM/eval_ltrmix.py`, `$SIM/summarize.py`, and `$SIM/RULES.md`
(pre-registered; read-only, never edit; sha256 must stay 4111826d...a293). `$SIM/run_one.sh`'s eval step shows how the
grid calls the two eval scripts.

## 1. `sim/rescore_all.sh` (Task 11 Step 1)
- Reruns `eval_run.py` then `eval_ltrmix.py` on every finished grid run (`sim/runs/<name>` for each row of `grid.tsv`;
  never the `*.100Mb` pilot copies) and every finished LTRquest run (`sim/lq/<name>` with `run.done`), with exactly the
  commands and environment run_one.sh's eval step uses (`common/env.sh`, snapshot PYTHONPATH). Then runs
  `summarize.py` into `sim/tables/`.
- Parallel over runs with `--jobs N` (default 8). Per-run log; a summary `rescore.log`; markers `rescore.done` and
  `rescore.exit`. `--dry-run` prints the commands; `--names a,b` restricts the set; `--no-summarize` skips summarize.
- After the evals it checks that every `eval.json` (and `eval_ltrmix.json`) records the same eval-script sha256s as
  the scripts on disk, and fails loudly listing any run that differs. Missing runs are listed, not fatal.
- Never edit `run_one.sh`, `run_grid.sh`, `lq/run_lq.sh` or `common/env.sh` (running jobs read them).
- Test it on two finished runs, one null and one power run, in place (`--names`, `--no-summarize`): rescoring in
  place is exactly what Step 1 does, and finished runs are never touched by the runners again. Show that the new
  eval.json files equal the old ones apart from timestamps (keep the old ones until compared).

## 2. Scoring smoke test on the finished runs
- Run `summarize.py` on the runs finished now, writing to a scratch directory (never `sim/tables/`), and time it.
- Report: wall time; any traceback; how many runs each set loaded; and any NA whose reason is not "run missing" or a
  documented NA (each such NA could be a scoring defect: give the run, field and reason). Do not report or interpret
  results (no Z values, no verdicts) beyond what a defect report needs.
- A defect in eval_run.py, eval_ltrmix.py or summarize.py: report it with a minimal reproduction; do not fix it
  (the controller rules first, since RULES.md is pre-registered and the scripts' sha256s are recorded).

## 3. `sim/ltrmix_absent.py`: why LTRmix calls truly present copies absent
The pilot found 62% of LTRmix's "absent" calls truth-present at 50 Mb (30,816 of 49,585 in null_s101; 30,409 of
48,959 in f0.18_Ta5000_r1); at toy scale the share was 30-35% and was traced to LTRmix orthology misses (review m9 in
`task-9-report.md`, around lines 600 and 701). Ruling R1 requires attributing them before the presence/absence
head-to-head is read. For every (element, genome) pair LTRmix calls absent while truth calls the element present,
assign exactly one cause, in this order:
  a. **truth state S or T** (solo LTR or truncated copy in that genome): LTRmix's libraries hold intact elements;
  b. **annotation dropout**: the copy is present (P) in that genome but absent from that genome's simulated annotation
     (the GFF3 the run gave LTRmix), so no library entry could match it;
  c. **orthology miss**: the copy is P and annotated in that genome, yet LTRmix did not pair it;
  d. **other**, with a reason.
- Use eval_ltrmix.py's own definition of an LTRmix absent call and its truth join (by eid), so the counts reconcile
  exactly with the absent-call totals eval_ltrmix reports; show the reconciliation.
- Output one row per run and a pooled row (counts and fractions per cause, plus the totals), as TSV.
- A pytest file `sim/test_ltrmix_absent.py` with a tiny synthetic fixture covering every cause (hand-worked
  expected counts).
- Run it on the finished null and power runs now (into a scratch directory) and report the breakdown for
  null_s101, f0.18_Ta5000_r1 and the pooled finished runs. rescore_all.sh calls it after summarize, writing
  `sim/tables/ltrmix_absent.tsv`.

## Constraints
- Python and tools from env `ltrpav` via `common/env.sh` (never install, update or remove packages in any env; never
  run python with `-I` or `-E`); `export NUMPY_MADVISE_HUGEPAGE=0 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1`.
- The server is busy with ~160 threads of detached jobs: your probes use at most 8 threads and 15 minutes each.
  Never kill any process; never touch `sim/runs/<name>` of a run without `run.done`.
- Write only: `sim/rescore_all.sh`, `sim/ltrmix_absent.py`, `sim/test_ltrmix_absent.py`, the two test runs' eval
  outputs, your scratch directory, and your report. No repo commits (the repo is another agent's this hour).
- American English. No AI attribution anywhere.
