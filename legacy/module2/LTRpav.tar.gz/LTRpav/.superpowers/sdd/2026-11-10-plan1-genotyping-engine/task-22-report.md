# Task 22 report: pair simulator on a real backbone (`ltrpav.sim`)

Status: DONE_WITH_CONCERNS. The concerns are deliberate refinements of the literal truth wording, listed under
"Deviations" for the controller to confirm. None blocks.
Commit (branch plan1-engine, existing git identity, no trailers):
- `37857f6` Add real-backbone pair simulator with provenance truth

## What I implemented

### `src/ltrpav/sim/genome.py`: provenance and lifted elements (0-based half-open)
- `IdCounter` (one per simulation, shared by its genomes). `SimElement` has the ruling's fields plus
  `tsd_ids`, the target-site ids its TSD copies carry, in genome order.
- `SimGenome(seq, prov=None, elements=None, ids=None, seqid="chr1")`:
  - backbone bases get ids 0..n-1;
  - `split()` returns two deep copies that share the counter and record `split_id`;
  - it also keeps `deleted` (one array of structural deletions per edit), `noise_born`/`noise_lost` (the
    ids mutate created and removed) and `inversions`.
- Edits:
  - **`insert(pos, payload, prov)`**: a start boundary moves with an insertion at its own position; an
    end boundary does not. So an insertion strictly inside an element grows it, one strictly inside an
    LTR grows that LTR (LTRquest semantics), and one at an element's edge lands outside it.
  - **`insert_element(site, body, ltr_left, ltr_right, *, eid, origin, k, strand, family, superfamily)`**:
    the target bases stay to the left; their copy follows the element with the same ids. The parent is
    the smallest alive element holding the insertion point.
  - **`delete(start, end)`**: an element wholly inside dies with event "deleted". One holding the
    deletion strictly inside gets "del_partial"; one losing an end gets "clipped". The element dies if
    either LTR keeps less than COV_PRESENT of its pre-edit length.
  - **`solo(eid, crossover)`**: produces the hybrid LTR `left[:x] + right[x:]`, keeps both TSDs, and
    deletes everything between, nested elements included. Event "solo"; the element is no longer alive.
  - **`invert(start, end)`**: boundaries move outward until they are REFINE_PAD clear of any element.
    Elements inside are mirrored, their LTRs swapped, strand, TSD string and `tsd_ids` reversed, event
    "inv". It returns the interval actually inverted.
  - **`gap(start, end)`**: replaces the bases with N; ids are kept.
  - **`mutate(sub_rate, indel_rate, rng)`**: one vectorized pass. Substitutions hit A/C/G/T only. Indel
    events occur at indel_rate per base, half insertions and half deletions, with geometric lengths
    (mean 3). Inserted bases take one fresh id block; element boundaries are lifted through the
    cumulative offsets with the same start/end rule.

### `src/ltrpav/sim/pair.py`
- `Donor`, `PairParams` (the brief's defaults), `event_counts`, `backbone_genome`, `young_copy`,
  `simulate_pair`, `compute_truth`, `write_pair`, `TRUTH_COLUMNS`.
- **Event order** (one `default_rng(seed)`; counts per 6 Mb times `scale`, rounded):
  1. ancestor = backbone with its elements (origin "backbone", eids bb0001.. in (start, -end) order);
  2. shared insertions (sh0001.., K from k_shared);
  3. split;
  4. for A, then B: insertions (A0001../B0001.., K from k_branch), solo-LTRs, flank deletions, partial
     deletions;
  5. mutate A, then B;
  6. gaps in A, then B;
  7. one inversion in B.
- **Young copy**: both LTRs are the donor's left LTR and the internal region is the donor's. Each LTR and
  the internal region is then substituted at K/2, and the copy goes in on a random strand.
- **Gaps**: 100-bp N runs. A third land within 20 bp of an alive element's end or of an empty site (where
  the genome holds the target of the other genome's lineage-only insertion); the rest are uniform.
- **Truth**, per alive element e of X read in Y, checked in this order:
  - **G**: an N in Y within REFINE_PAD of e's site (the Y positions of the first ids beyond each end of e
    that Y holds) or of e's image (the Y positions of e's ids). Site and image form one hull when they
    lie within 100 kb.
  - **e inserted in X's branch**:
    - if an alive ancestor from X's branch exists, e takes the outermost such ancestor's truth, plus
      host_empty when that is E;
    - otherwise the site test reads Lf and Rf (w = 10 ids beside e's TSD copies) and the TSD ids:
      - E if Y holds them in order and contiguous, forward or reversed (reversed adds "inv");
      - O if Lf and Rf are contiguous with Y-only sequence between them (ids X lacks, plus window ids);
      - D otherwise.
  - **e present before the split**:
    - S if Y's copy has a "solo" event and Y keeps at least COV_PRESENT of an LTR's worth of e's ids;
    - P if Y holds at least COV_PRESENT of e's own ids (ids inside nested elements and their remains
      excluded) and of each LTR's own ids;
    - T if Y holds at least MIN_SEG own ids;
    - D otherwise.
    - P, S and T carry "inv" when exactly one of the two copies was inverted.
- **Rows**: the ruling's fields, plus `events_x` and `events_y`, the events of e's copy in X and in Y,
  which explain the state.
- **`write_pair(outdir, A, B, truth, params, seed, meta=None)`**:
  - A.fa and B.fa (seqid chr1, 80 columns); a stale `.fai` from an earlier run is deleted first;
  - A.gff3 and B.gff3 via `write_gff3`, built from alive elements with a seeded rng `[seed, 1]`:
    - dropout and jitter (U{-3..3} on start and end, the LTRs' outer ends moving with them);
    - Name = the simulator's eid;
    - TSD read beside the reported ends, and only if both 5-bp flanks are equal and free of N;
  - truth.tsv (both directions);
  - samples.tsv (A and B annotated);
  - params.json (seed, params, the backbone `meta`, per-genome lengths, alive and annotated counts,
    inversions 1-based inclusive, truth state counts).

### `src/ltrpav/sim/cli.py`, `src/ltrpav/sim/__init__.py`
- `ltrpav-sim pair --fasta FA --region SEQ:START-END --annotation ANNOT --outdir DIR [--seed N] [--scale X]
  [-v]`. It reuses `ltrpav.cli._execute`, so exit codes, log format and the `error:` line match ltrpav.
- The FASTA is opened with `cache_dir=outdir/fai`, and the region is checked before anything is
  written. Fail-fast errors: bad format, unknown sequence, empty range, out of range.
- Backbone elements are those of `load_annotation` lying wholly in the region, shifted to its
  coordinates.
- Donors: up to 2000 level-0, childless, `confidence == "high"` elements of any seqid, sampled with
  `default_rng([seed, 0])` and fetched with `Fasta.fetch`. They are put in their own orientation ('-'
  strand reverse-complemented). Donors with an N or without an internal region are skipped and counted
  in a warning.
- Log: start; annotation, backbone and donor counts; per genome its length and elements by origin; truth
  states per direction; done.

## Deviations from the literal rulings (deliberate; please confirm)
1. **Site-test flanks** (ruling 6, E/O): Lf and Rf are the nearest w ids both genomes can share: born
   before the split, not point-mutation noise, each counted once, skipping e's TSD.
   - The literal "w ids left of e's left TSD copy" would include an adjacent lineage-only element's ids
     and call both members of an adjacent pair D, although the other genome never had either.
   - Tested by a8/a9 in `test_truth_engineered_events`. On the real run, A0030/A0145 are 54 bp apart and
     both come out E.
2. **Point mutations are noise, not events**: ids that `mutate` created or removed, in either genome,
   are transparent to the site test.
   - Without this, a 1-bp indel in the 25-bp window turns E into D or O. That would hit about 1.5-3% of
     empty sites (25 bp x 0.0006 per base, both genomes).
   - Tested in `test_point_indels_keep_empty_sites`: 3% indels, at least 2 sites hit, all stay E and
     every element stays P.
   - Consequence: an empty site whose TSD a point deletion removed stays E, while the classifier calls D
     there (B0038, below).
3. **S** requires Y to still hold at least COV_PRESENT of an LTR's worth of e's ids. A solo LTR that a
   later collateral deletion removed falls through to T or D (the real run has a "solo,deleted" D).
4. **inv flag is relative**: exactly one of the two copies was inverted.
   - Literally, "Y's copy has inv" would never flag a B row read in A, even when B's copy is inverted.
   - Also set on E and O when the site matches reversed, and on S and T.
5. **Own ids** exclude every nested element that still spans sequence, dead ones included. This was
   found on the real run, where bb0322's own ids included 9.3 kb of a clipped, dead B-only insertion;
   that gave T where the biology is P. A regression case, c inside p1, is in the engineered test.
6. **Element death**: a deletion that leaves an LTR below COV_PRESENT of its length kills the element.
   The ruling says only "partial overlap -> clipped". Without this rule, end-clipped elements with a lost
   LTR would be written to the GFF3 with empty LTRs.
7. **Targets of solo, flank deletion and partial deletion**: all three take alive pre-split elements
   (the ruling states this only for solo). Solo also skips elements with something nested inside an LTR
   span: the crossover is an LTR offset, and with LTRquest spans it would land inside the nested element.
8. **inv_len** scales per 6 Mb of backbone, not by `scale`, so the 400-kb test backbone gets a 20-kb
   inversion instead of 300 kb. The real run inverted exactly 300,000 bp.
9. **Gap targets** include empty sites as well as element ends (the brief's wording; the ruling names
   only element ends). Gaps are placed after both branches' structural events, so the other genome's
   empty sites are visible.
10. **API additions**: the `events_x`/`events_y` truth columns; `SimElement.tsd_ids`; the `SimGenome`
    extras listed above; `write_pair(..., meta=None)`; `invert` returns the actual interval.

## Tests and results
`tests/test_sim.py`, 17 tests, about 2.5 s:
- **`test_insert_delete_invert_lift`**:
  - insertion inside an LTR grows the element and the LTR, and sets the parent;
  - insertion at an element's start shifts it, and at its end leaves it alone;
  - TSD copies share `tsd_ids`;
  - an inside deletion gives del_partial, alive;
  - a clip keeping 95% of an LTR stays alive, a 75% one dies;
  - whole deletion gives deleted;
  - inversion mirrors, swaps LTRs, flips the strand and reverse-complements the sequence;
  - a boundary inside an element moves at least REFINE_PAD out.
- **`test_mutate_lifts_elements`**: after 5% indels, every element and LTR span holds exactly its kept
  ancestral ids in order, plus only point-mutation ids; the substitution rate comes out at about the
  expected rate.
- **`test_solo_keeps_one_ltr_and_tsds`**:
  - by hand: hybrid = `left[:150] + right[150:]`, both TSDs kept;
  - simulated (K = 0, no point mutations): every undamaged solo LTR in B equals its element's LTR on
    either strand and sits between equal TSDs.
- **`test_truth_engineered_events`** (ruling 10), built with SimGenome methods. Expected states, A in B:

  | Element | State | Event |
  |---|---|---|
  | a1 | E | |
  | a2, a3 | E, E + host_empty | a3 nested in a2 |
  | a4 | O | B inserts b1 at the same site |
  | a5 | D | B deletes the site |
  | a6 | G | N run 25 bp from the site |
  | a7 | E + inv | site inside B's inversion |
  | a8, a9 | E, E | adjacent pair |
  | p1 | P | holds the remains of dead c |
  | p2 | S | solo in B |
  | p3 | D | deleted with 500 bp of flank in B |
  | p4 | T | half the internal region deleted in B |
  | p5 | G | N run 10 bp past its end |
  | p6 | P + inv | in B's inversion |
  | p7 | P | B-only insertion b2 inside |

  B in A: p1, p4, p5, p7 P; p6 P + inv; b1 O; b2 E; b3 E + inv (B-only, inverted with its flanks). The
  test also checks the row fields and the events columns.
- **`test_point_indels_keep_empty_sites`**: deviation 2.
- **`test_provenance_invariants`**: every TSD pair shares ids (left copy == right copy == `tsd_ids`);
  only TSD copies repeat ids; a backbone id is missing only where it was deleted; A and B share every
  backbone id that neither deleted.
- **`test_inserted_element_and_tsds`**: with no point mutations and K = 0, at least 40 inserted elements
  in A.fa and B.fa hold the young copy exactly at truth's coordinates, with equal 5-bp TSDs; FASTA ==
  genome; all origins are present.
- **`test_simulated_truth_states`**: one row per alive element; lineage-specific elements are never
  P/S/T and pre-split elements never E; S, D, P and E all occur.
- **`test_seed_determinism`**: same seed gives byte-identical A/B.fa, gff3, truth, params and samples; a
  different seed gives different output.
- **`test_gff3_loads`**:
  - `load_annotation(A.gff3)` count is within 3 sd of alive x (1 - dropout), for both genomes;
  - names map to alive eids, coordinates are within ±3, inner LTR ends and K are exact;
  - the truth.tsv header is right, `read_samples` accepts samples.tsv, and params.json has the right
    inversions and truth counts.
- **`test_cli_pair`**: end to end on a toy FASTA + GFF3. The backbone holds all 4 elements; donors = 5
  (a low-confidence one and a host with a child are excluded); outputs written; "done" logged.
- **`test_cli_bad_region`** (6 cases): exit 1, a stderr line starting `error:`, nothing written.

Full suite: `640 passed in 70.00s` (`pytest -p no:cacheprovider -W error`, so no warnings);
`ruff check .`: all checks passed; every line is at most 110 columns.

## TDD evidence
- **RED**: `tests/test_sim.py:19: ModuleNotFoundError: No module named 'ltrpav.sim'` ... `1 error in 0.28s`.
- **GREEN**: after implementing, `17 passed in 2.35s`.
- Further red-green cycles during self-review:
  - `test_provenance_invariants` failed with `[208531, ...] == [208527, ...]`: `invert()` did not
    reverse `tsd_ids`. In the B-in-A truth, every B-only element inside the inversion would have been
    D instead of E. I fixed it and added b3 (E + inv) to the engineered test.
  - On real data the engineered test gave `{'p1': ('T', '')} != {'p1': ('P', '')}` before the own-ids
    fix (deviation 5); GREEN after.
  - The a8/a9 adjacency case passed at once: it confirms deviation 1 rather than driving it.
  - `test_solo_keeps_one_ltr_and_tsds` first required undamaged A copies (only 1 of 8 qualified). It now
    checks B's solo LTRs directly against the planted or donor LTR.
- **Final**: 17/17 and 640/640 green.

## Real-backbone run
```
mamba run -n ltrpav ltrpav-sim pair --fasta /data2/chris/maize_introgression/inputs/B73v5.fa \
  --region B73v5_chr10:2000001-8000000 --annotation /data2/chris/maize_introgression/run/B73v5_LTRs \
  --outdir /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/simcheck --seed 1
```
- **Runs**: the first run was cold and before the own-ids fix: 58.5 s wall, 939 MB peak RSS (annotation
  load 21 s). I reran once with the committed code: **40.6 s wall, 938.5 MB peak RSS** (`/usr/bin/time
  -v`; the annotation load took 4 s warm). A.fa is byte-identical between the two runs; only two truth
  rows differ (B in A: P 257 -> 259, T 19 -> 17).
- **Inputs**: 127,636 annotation elements, 323 wholly in the backbone, 1999 donors (1 skipped for no
  internal region).
- **Events per branch** at 6 Mb: shared 150, branch 200, solo 40, flank deletions 30, partial
  deletions 20, gaps 15, plus one inversion in B (2,940,993-3,240,992, 300 kb).

| Genome | Length (bp) | Alive: backbone / shared / own | Total alive | In GFF3 after dropout |
|---|---|---|---|---|
| A | 8,327,057 | 256 / 105 / 179 | 540 | 477 |
| B | 7,997,951 | 254 / 99 / 171 | 524 | 463 |

Truth state counts per direction:

| Direction | P | S | T | E | D | O | G |
|---|---|---|---|---|---|---|---|
| A in B | 257 | 31 | 16 | 142 | 80 | 0 | 14 |
| B in A | 259 | 30 | 17 | 155 | 48 | 0 | 15 |

The same counts by origin:

| Direction | Origin | States |
|---|---|---|
| A in B | backbone | P 189, S 18, T 14, D 25, G 10 |
| A in B | shared | P 68, S 13, T 2, D 19, G 3 |
| A in B | A | E 142, D 36, G 1 |
| B in A | backbone | P 194, S 17, T 11, D 23, G 9 |
| B in A | shared | P 65, S 13, T 6, D 12, G 3 |
| B in A | B | E 155, D 13, G 3 |

- **Flags**: A in B: host_empty 10, inv 17. B in A: host_empty 17, inv 17, "inv,host_empty" 1.
- **Lineage-specific D**, checked on provenance: every case has its site flanks deleted in the other
  genome. Mostly the host was solo'd there (12 and 4) or flank-deleted (8 and 3), plus inherited host D
  (5 and 4).
- **The A/B asymmetry** (36 vs 13) is stochastic: B lost 14.9% of the pre-split ids and A lost 12.0%.

### An independent check: the pipeline against the truth
`ltrpav run --samples simcheck/samples.tsv --outdir scratchpad/pipe --threads 16` (mm2 route, 9.7 s,
3.2 GB). It joins calls to the truth by element name.
- **High-tier agreement**: 364/369 = 0.986 (A in B) and 372/375 = 0.992 (B in A). P and E calls are
  above 0.99 correct.
- **Disagreements, all inspected on provenance**: every one traces to a classifier limitation, none to
  the truth:
  - GFF3 dropout of a nested child, which the classifier counts as the host's own bases: P called T or
    S, T called P;
  - adjacent lineage-only insertions (A0030/A0145): E called D;
  - two same-family young copies about 6 kb apart at different sites (A0067/B0022), aligned to each
    other: E called P with nestB;
  - a site lying in the surviving half of a solo LTR in the other genome (B0175): E called D;
  - a 12-bp point deletion that removed the TSD (B0038): E called D, see deviation 2;
  - host-G inheritance, where the host has an N far from the element's own site: E or P called G;
  - a solo LTR almost entirely from one LTR (bb0077): S called T.
- These are early bake-off observations from one seed, not results.

## Files changed
- New: `src/ltrpav/sim/__init__.py`, `src/ltrpav/sim/genome.py`, `src/ltrpav/sim/pair.py`,
  `src/ltrpav/sim/cli.py`, `tests/test_sim.py`. No other file changed: pyproject already declared
  `ltrpav-sim`.
- Outside the repo: `scratchpad/simcheck/` (run outputs plus memo.md), `scratchpad/pipe/` (the check
  run), `scratchpad/diag/` (diagnosis scripts).

## Self-review findings
- **Bugs found and fixed before commit**:
  - the inverted `tsd_ids` (above);
  - dead nested remains counted as a host's own bases (above);
  - an operator-precedence slip in `insert_element`'s LTR-length check;
  - an unclosed file in a test helper (a ResourceWarning under -W error).
- **Simulator constants** are simulation parameters with a one-line reason each, not method thresholds,
  and live in `sim/`: PER_BP, GAP_LEN, GAP_NEAR, FLANK_DEL, PARTIAL, PARTIAL_MIN, _SPAN = 100 kb,
  _INDEL_P, MAX_DONORS. The truth reuses COV_PRESENT, MIN_SEG, REFINE_PAD, SLOP_TSD_MULT and TSD_DEFAULT
  from constants.py.
- **Performance**: `simulate_pair` takes 36 s on the real backbone, 33 s of it in `insert` (550 calls)
  and `delete` (180 calls). Each edit reallocates the 64-MB id array and page-faults it in (system time
  30 s). The target is met (< 2 min, < 4 GB). Keeping the ids in a buffer with spare capacity would
  remove most of this.

## Concerns
1. The deviations above are refinements of the ruling's literal wording, made so the truth is
   biological. Each has a test. Please confirm, especially: point-mutation transparency (2), the
   relative inv flag (4), the LTR-keeps-80% death rule (6), and the extra `events_x`/`events_y` columns.
2. O never occurs in the default simulation (0 in both directions): it needs a same-site insertion, or a
   deletion beside a lineage-only element. If Task 24 must score O precision, it needs engineered O cases
   or a "same-site insertion" parameter.
3. The default events remove 12-15% of the ancestral sequence per branch, so 8-20% of lineage-only
   insertions are D: their site went with a deleted or solo'd host. That follows from the brief's counts
   (90 element events per 6 Mb per branch, in a dense maize region), not from tuning.

## Fix round 1 (FIX_BASE 37857f6)

Status: DONE_WITH_CONCERNS (one observation for the controller under Concerns; nothing blocks).
Commit: `5e51e2d` Fix simulator review findings and add same-site insertions (no trailers, existing identity).

### Changes, one per fix in task-22-fix1.md
1. **Own-base death rule** (Important 1).
   - `genome.py` now has the shared helpers `nested_spans(g)`, `own_mask(e, inner)` and
     `own_ltr_lengths(e, inner)`. A nested span is any element still spanning sequence and lying wholly
     inside, dead remains included.
   - `delete` measures each hit, alive element's own LTR bases before and after the edit, and the element
     dies when either falls below COV_PRESENT.
   - The truth's coverage uses the same `nested_spans` and `own_mask`, so the death rule and the coverage
     share one definition.
2. **Site test** (Minor 1a), per the ruling. W = Lf + TSD ids + Rf, each id once. Y is read between every
   Y-position pair of W's first and last id (within 100 kb), skipping point-mutation ids:
   - E when that segment equals W, forward or reversed (reversed adds "inv");
   - O when the segment's non-Y-only ids are all W ids, W is a subsequence of them, and some Y-only id
     (an id X lacks) sits in the segment;
   - D otherwise.

   The old Lf-and-Rf contiguity check and `read_y` are gone.
3. **Window ids counted once** (Minor 1b): Rf skips Lf's ids as well as e's TSD ids.
4. **Dead hosts** (Minor 1c): `outer_host` accepts X-only ancestors that are alive or still span sequence.
   A dead host's state (G check, then site test) is computed as for an alive one.
5. **Event counts** (Minor 2): each `SimGenome.counts` maps event type to (requested, realized).
   - Event types: shared_insert (on the ancestor, copied to both branches), insert, same_site, solo,
     del_flank, del_partial, gap; for B also inversion_bp (requested inv_len, realized inverted length).
   - The event functions return what they did. `simulate_pair` logs `"<label>: <event> short: n of m
     realized"` for any shortfall (shared reported once).
   - `params.json` gains `"events": {A: {event: {requested, realized}}, B: {...}}`.
6. **`--scale`** (Minor 3): `PairParams.__post_init__` raises `ValueError("scale must be finite and > 0,
   got ...")`. The CLI builds PairParams before opening anything, so 0, -1, inf and nan all give exit 1
   with one `error:` line and no traceback, and nothing is written. `_scale` now only parses the number
   (a non-number is still argparse's exit 2).
7. **`truth.py`** (Minor 4): new module `src/ltrpav/sim/truth.py` holding TRUTH_COLUMNS, W, `compute_truth`,
   `Truth` (formerly `_Truth`, now public because pair.py's same-site step uses its site test), `_in_order`
   and the site-test helpers. The truth section of the module doc moved there too. pair.py imports from
   it, and `ltrpav.sim` exports TRUTH_COLUMNS and `compute_truth`.
8. **GFF3 LTR bounds** (Minor 5): `_annotation` writes `ltr_left[0]` and `ltr_right[1]` shifted by the
   same jitter as the element ends. The clamps keep start >= 0, end <= len, and both LTRs non-empty.
9. **Same-site insertions** (addendum 11):
   - `PairParams.n_same_site = 10`, with its one-line reason comment, scaled like the other counts.
   - **Timing**: after both branches' structural events, `_same_site` runs for A, then for B, before
     `mutate`.
   - **Candidates**: alive lineage-only elements of the other genome with no lineage-only ancestor,
     pre-split TSD ids, and a site test of E in this genome. They are picked uniformly
     (`rng.permutation`) and kept more than two site windows (50 bp) apart.
   - **Placement**: each copy (donor, K from k_branch, strand as usual) gets a target starting
     U{0..L-1} bp into the other element's target, so the two targets overlap. Copies go in right to
     left so earlier positions stay valid.
   - **Identity**: eids continue the branch numbering (A0201..); the new element carries event
     `same_site`, which shows in `events_x`.
   - **Reading of the addendum**: it says "insertion point = target start + U{0..L-1}, so the two targets
     overlap". I took the offset as the new target's start, which makes the targets overlap for every
     offset; taking it as the body position would give no overlap at offset 0.
10. **Tests** (Minor 6): listed below.

### Tests
`tests/test_sim.py` has 40 tests, 23 of them new cases:
- **`test_host_keeps_own_ltr_when_nested_element_goes[solo|flank50|partial]`**: the reviewer's probe 1.
  H stays alive with events ["del_partial"], is P in A-in-B and in B-in-A, and appears in B.gff3.
- **`test_insertion_in_site_window`**: offsets 0, 1 and 3 bp give O both ways; 12 bp gives E both ways.
- **`test_window_ids_counted_once`**: e targets h's last 5 bp; e has no parent and its TSD ids are
  post-split; h and e are both E.
- **`test_child_of_dead_host`**: E + host_empty before and after h dies (h's span is kept).
- **`test_solo_ltr_destroyed_later[300-T|400-D]`**.
- **`test_truncated_copy_inverted`**: T + inv in A-in-B, P + inv in B-in-A.
- **`test_provenance_invariants`** now runs with point indels (default indel_rate):
  - TSD pairs match modulo point-mutation ids;
  - only TSD copies repeat an id;
  - missing backbone ids are a subset of the structural deletions plus `noise_lost`;
  - ids that neither genome lost are present in both.
- **`test_same_site_insertions_give_O`** (default PairParams, 400-kb backbone, 1 same-site insertion per
  branch): every same-site element is O; at least 2 x n_same_site O rows in each direction; the
  params.json events match `g.counts` and the requested counts.
- **`test_event_shortfall_warns`**: n_solo = 100,000 gives realized < requested and a "solo ... short"
  warning.
- **`test_scale_must_be_finite_positive[0|-1|inf|nan]`**.
- **`test_annotation_jitter_moves_ltr_outer_bounds`**: LTRs inset 10 bp; jittered GFF3 LTR outer bounds
  equal the own bounds plus the same shifts.
- **`test_cli_bad_region`** now asserts that the outdir is never created; **`test_cli_bad_scale[0|-1|inf|nan]`**
  checks exit 1, an `error:` line mentioning scale, no traceback, and no outdir.
- **`test_inserted_element_and_tsds`** now also skips elements with an N in their span or TSD flanks: a
  uniform 100-bp gap can land inside one, and gaps record no event.

Results:
- full suite `663 passed in 68.62s` (`pytest -p no:cacheprovider -W error`), before the commit;
- `ruff check .` clean; every line at most 110 columns.

### TDD evidence
- **Step 1**: pure move into truth.py (fix 7): 17/17 still green.
- **Step 2**: new tests, RED with 18 failures, each for the intended reason:
  - `h.alive` False in all three nested cases;
  - offsets 1 and 3: `('D', 'D') == ('O', 'O')` failed;
  - window dedup: `{'e': ('D', '')} != {'e': ('E', '')}`;
  - dead host: `{'e': ('D', '')} != {'e': ('E', 'host_empty')}`;
  - `KeyError: 'n_same_site'`;
  - `'SimGenome' object has no attribute 'counts'`;
  - `PairParams(scale=...)` did not raise;
  - LTR bound: `(1000, 1400) == (1010, 1400)` failed;
  - CLI scale 0 exited 0 (and ran), -1 and nan were argparse exit 2, inf raised `OverflowError`.
- **Step 3**: GREEN after the fixes, 40/40. One existing test, `test_inserted_element_and_tsds`, then
  failed because a gap landed inside an inserted element; its guard was adjusted as noted above.
- Full suite 663/663.

### Real run, rerun into scratchpad/simcheck (overwritten)
Same command as above, with `--seed 1`, at commit 5e51e2d: **44.9 s wall, 948 MB peak RSS**.
- A: 8,243,385 bp, 540 alive (backbone 250, shared 108, A 182), 477 in A.gff3.
- B: 8,087,798 bp, 529 alive (backbone 246, shared 103, B 180), 466 in B.gff3.

| Direction | P | S | T | E | D | O | G | Rows |
|---|---|---|---|---|---|---|---|---|
| A in B | 250 | 25 | 16 | 132 | 85 | 22 | 10 | 540 |
| B in A | 253 | 32 | 20 | 133 | 58 | 23 | 10 | 529 |

- **O rows**:
  - A in B: 9 same-site elements (the 10th is G, a gap), 10 partners of B's same-site insertions, and 2
    children inheriting O from a partner host. B in A: 10 same-site, 10 partners, 2 inheriting.
  - Plus one natural same-site pair, A0063/B0198: independent insertions whose targets overlap by 2 bp;
    O both ways.
- **Flags**: A in B: inv 19, host_empty 7, "inv,host_empty" 2. B in A: host_empty 18, inv 14.
- **Realized event counts equal the requested counts** in both branches: shared 150, insert 200,
  same_site 10, solo 40, del_flank 30, del_partial 20, gap 15. The inversion in B covers 306,340 bp
  (requested 300,000; its boundaries moved outward). No shortfall warnings.

### Hosts the own-base rule now keeps alive
- **Old code** (FIX_BASE, the reviewer's probe on the old seed-1 run): 10 hosts were killed with their own
  LTR bases intact (6 in A, 4 in B).
- **New code** (instrumented replay of this run, `scratchpad/diag/saved_hosts.py`): 14 elements were hit by
  a deletion that the span rule would have made fatal and the own-base rule survives (9 in A, 5 in B).
  - 11 are still alive at the end: P 9, G 1, D 1. The D is B bb0160, whose A copy was later
    flank-deleted.
  - 3 died to later, unrelated events (del_flank, deleted, clipped).
- **Reviewer's real-run probe on the new run**:
  - (1) hosts killed with own LTR bases >= 80%: **0**;
  - (2) the independent own-id route agrees on all 691 non-G pre-split rows;
  - (3) lineage-specific rows: E always has an intact ancestral window, while D and O never do. The only
    two listed "mismatches" are G rows with an intact window: G takes precedence.

The output probe finds A.fa, B.fa, the GFF3s, truth.tsv and params.json mutually consistent (TSD
attributes match the FASTA, LTR layout correct, maximum jitter 3).

### Pipeline check, rerun into scratchpad/pipe
`ltrpav run --samples simcheck/samples.tsv --outdir pipe --threads 16`: mm2 route, 10.7 s, 3.26 GB. Calls
joined to the truth on element name (`scratchpad/diag/compare2.py`):

| Direction | High-tier agreement | High-tier precision P / S / E / D | O truths called O |
|---|---|---|---|
| A in B | 356/358 = 0.994 | 195/195, 17/17, 103/103, 41/43 | 20/20 |
| B in A | 348/351 = 0.991 | 201/202, 25/25, 94/94, 28/30 | 20/22 (one T, one U) |

### Concerns
1. **Offsets 5-10 bp come out E, not O.** For a Y-only insertion 5-10 bp from e's target (inside a flank),
   the truth is E. That insertion's TSD copy recreates the 5 ids left of its insertion point, so Y holds W
   contiguously through the copy, and the ruling checks E first. Offsets 0-4 give O and 11 or more give E.
   The tests cover offsets 0, 1, 3 and 12, as the fix list asked; probe 2's offset 6 prints E. If the
   ruling's "inside a flank included" should win here, the E test would have to exclude contiguous
   occurrences that pass through a Y-only insertion's TSD copy. Please rule.
2. **Same-site offset**: I read the addendum's offset as the new target's start (always overlapping), as
   explained under fix 9.

## Fix round 2 (FIX_BASE 5e51e2d)

Status: DONE. Commit: `972fcf4` Base the simulator's O on overlapping targets; E tolerates ids X lacks (no
trailers, existing identity).

A correction to my fix-1 report: its "offsets 0-4 give O" counted the insertion-point gap, not the target
offset. In target offsets, fix 1 gave O for |off| <= 9.

### Changes (`truth.py`, plus one line in `pair.py`)
- **The final site rule.**
  - **O**: an element of Y's branch whose `tsd_ids` share an id with e's still spans sequence in Y,
    alive or dead.
    - `Truth.__init__` now takes `label_y` and indexes those elements' target ids (`Truth.targets`).
    - O takes "inv" from the orientation of the first Y-position pair of W's first and last id, and gets
      no flag when there is no such pair.
  - **E**: Y holds W's ids in order, forward or reversed (reversed adds inv). Every id Y holds between
    W's first and last id is one of:
    - point noise;
    - an id X lacks (Y-specific insertions at other sites, or ancestral bases X deleted later);
    - one of W's own ids repeated by a TSD copy.
  - **D**: otherwise (an id of W missing, out of order, or an id X holds from outside W in between).
- **W's TSD part** now keeps only ids X still holds, so every id of W is held by X.
- **Docstring**: the module docstring states the final rule; truth.py:14 no longer says "inside a flank
  included".
- **`pair._same_site`** builds `Truth(other, g, other_label, label)`. Its candidate test is still "the
  site test says E", now under the final rule.

### Tests
- **Removed**: `test_insertion_in_site_window`.
- **`test_target_offset[-12..+12]`** (25 cases; the cases of probe_offsets): e in B and y in A are both O
  at |off| <= 4 and both E otherwise.
- **`test_x_deletion_in_window`** (the cases of probe_xdel): X deletes 2 bp ([-8, -6)) or 24 bp
  ([-30, -6)) inside e's left flank window, or 2 bp inside its right one; each gives E.
- **`test_overlapping_dead_insertion_is_O`**: y overlaps e's target and is then clipped dead with its
  remains spanning sequence; e is still O.
- **`test_site_rearranged_is_D[dup|inv]`**: 50 bp of ancestral sequence from elsewhere inserted in Y
  between W's ids, or a 9-bp inversion inside W in Y; each gives D.
- **Unchanged and green**: every other engineered expectation (a4/b1 O both ways, a5 D, a7 E + inv,
  a8/a9 E, b2 E, b3 E + inv, p1..p7) and the default-simulation O test.

Results:
- **TDD**: RED with 13 failures, exactly the probe cases: target offsets -9..-5 and +5..+9 gave O, and
  the three X-side deletions gave O. The dead-overlap and rearrangement tests already passed and now
  guard the rule. GREEN after the change: test_sim.py 67/67.
- **Full suite**: `690 passed in 72.76s` under `-W error`; ruff clean; no line over 110 columns.
- **Reviewer probes**:
  - probe_offsets: "offsets breaking the revised ruling: []";
  - probe_xdel: E in all three cases;
  - probe_engineered probe 2 (insertion-point gaps 0, 1, 3, 6, 12, which are non-overlapping targets
    -5..-17): E both ways;
  - probe 3, and the dead-host probe: unchanged (E; E + host_empty).

### Real run: seed 1, rerun into scratchpad/simcheck
Same command, at commit 972fcf4: **48.3 s wall, 948 MB peak RSS**. Every event type realized its
requested count. The inversion in B covers 2,917,636-3,221,853 (304,218 bp).

| Direction | P | S | T | E | D | O | G | Rows |
|---|---|---|---|---|---|---|---|---|
| A in B | 246 | 25 | 16 | 132 | 85 | 23 | 13 | 540 |
| B in A | 253 | 32 | 20 | 134 | 58 | 22 | 10 | 529 |

The pipeline check on this pair (`ltrpav run`, mm2, 8 threads, 11.5 s) gives high-tier agreement of
351/354 = 0.992 (A in B) and 342/345 = 0.991 (B in A). High-tier precision:
- A in B: P 198/198, S 19/19, E 104/104.
- B in A: P 200/201, S 23/23, E 91/91.
- O truths called O: 20/22 and 18/22; the misses were U and T.

### What changed compared with the fix-1 run, and why
- **23 rows changed state or flags, and 887 rows changed other columns (coordinates)**. Genome lengths
  are identical, but the sequences differ.
- **The rule alone changes nothing on the same genomes.** Applying the final rule to the fix-1 genomes
  (pickled from that run) changes 0 of 1069 rows. In the fix-1 run every O already had an overlapping
  target and no E had one, as the reviewer's probe (4) also found.
- **The trajectory changed because `_same_site` picks its targets with the site test.**
  - In A's step, B0142 was not a candidate under the fix-1 rule. Its site window in A spans 24,240 ids,
    24,215 of them ancestral bases that B had deleted beside B0142's site, which fix 1 read as O. Under
    the final rule that window is E (ids X lacks are allowed).
  - So B0142 took the 4th of A's 10 slots and B0126 dropped out. A's same-site insertions A0204..A0210
    then went to other partners and positions.
  - That reorders the position-sorted candidate list for B's step, so 8 of B's 10 partners changed.
    Gap targets and B's inversion boundaries, which depend on element positions, moved as well.
- **The 23 state changes all follow from that:**
  - **E -> O** for the new partners: A0025, A0028, A0053, A0069, A0151, A0153.
  - **O -> E** for elements no longer anyone's partner: A0004, A0085, A0091, A0147, A0182, A0194, B0126.
  - **G -> O**: A0203, whose gap moved.
  - **G changes from moved gaps**:
    - P -> G: bb0033, bb0212, bb0246, sh0030, sh0099 (A in B) and sh0014 (B in A);
    - G -> P: bb0056 (A in B) and sh0010 (B in A).
  - **S + inv -> S**: bb0113. Its solo LTR in B lies outside the moved inversion: fix 1 inverted
    2,921,680-3,228,019, now 2,917,636-3,221,853.

### Note from the checks (no code change)
A diagnostic replay script of mine imported numpy before ltrpav, which bypasses the package's
`NUMPY_MADVISE_HUGEPAGE=0` guard. On the current host (load ~86, heavy memory fragmentation) it spent over
95% of its time in kernel page compaction (user 5 s, system 230 s, stalled). With the variable set it ran
in 47 s. The CLI and the package are unaffected, since ltrpav sets the guard before numpy loads. The
reviewer's probe scripts also import numpy first, so they may stall the same way on this host now.
