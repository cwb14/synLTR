# ltrkin v0.2 benchmark: haplotype-resolved assemblies as truth

Date: 2026-11-13 (release v0.2.0). To rerun: `benchmark/assembly_truth/` (workflow, configuration and data
download; commands in order in `benchmark/README.md`). Scripts: `benchmark/hap_truth.py`, `benchmark/eval_hap_truth.py`,
`benchmark/elements_to_sv_vcf.py`, `benchmark/whatif_phase.py`, `benchmark/jitter_gff.py`,
`benchmark/truth_to_genotypes.py`, `benchmark/compare_sources.py`.

![Fig. 1](img/fig1_ltrkin.png)
*Fig. 1.* A *C. amara* region on both haplotypes, one new insertion at read and base-pair level, read
phasing at an element on both haplotypes, and the benchmark numbers. Legends: `img/fig1_ltrkin.pdf` (pages 2-3).

## Data
| species | assemblies (truth) | reads | annotation |
|---|---|---|---|
| *Cardamine amara* subsp. *amara* C087_203 (2x, outcrossing) | hap1 GCA_056512385.1, hap2 GCA_056512305.1 (hifiasm + Hi-C), 212 Mb each | PacBio Revio HiFi SRR40190226 (mean 15.6 kb, median Q33); 27% subset, ~120x total | LTRquest 1.0.1 per haplotype: 5,839 / 5,757 intact elements |
| *Medicago sativa* subsp. *falcata* Kubanskaya Zheltaya | principal GCA_062053299.1 (778 Mb), alternate GCA_062053298.1 (749 Mb), hifiasm ONT | ONT PromethION SRR39462928 (mean 23.6 kb, N50 26 kb, median Q20); 30% subset | LTRquest 1.0.1: 24,203 / 23,079 |

Reads were aligned with minimap2 2.31 (`-ax map-hifi` / `-ax map-ont`, `--secondary=no`, supplementary kept) to
each haplotype separately. Depth series: BAM subsampling (`samtools view -s`) to a genome-mean MAPQ >= 20 depth of
5-60x; three replicate seeds at 5x and 10x.

## Truth (read-independent): `benchmark/hap_truth.py`
For every element annotated on the reference haplotype R, its state on the other haplotype O:
1. **Whole-genome alignment** (minimap2 `-cx asm20`; asm5 left 57% of *C. amara* elements unplaced because the
   haplotypes differ by 1-7% around TEs): the last base before each TSD copy is lifted from R to O, and the
   allele-length change between them (the quantity a spanning read measures) gives F (full), S (solo LTR), E (empty
   site), Fx (present, other internal length), Fn (present, flank differs), Nd (element and flank deleted), Nr
   (replaced by unrelated sequence), O (other) or U (unresolved).
2. **Flank remapping** of unplaced elements to the whole of O (few changes: their flanks are mostly repeats).
3. **Allele-junction search**: the empty-site junction (flank + one TSD + flank) and the two flank-element
   junctions (1 kb per side, then 300 bp) are searched in O; a hit must be unique and contiguous across the junction
   (>= 200 / 100 aligned bp on each side, no indel >= 30 bp within 100 bp).

The final state is **confirmed** when the alignment and the junctions agree; rescued (junctions only), wga_only
(junction test inconclusive) and conflicts are kept apart, and conflicts are not scored. Headline numbers use
confirmed sites. Expected genotype at a reference element: F/<state> (F, Fx, Fn -> F/F; E -> F/E; S -> F/S;
Nd, Nr -> F/N).

**Checks of the truth:**
- the other haplotype's LTRquest annotation (*C. amara* hap1): 0% of empty sites but 82% of full sites carry an
  element there; reciprocal: 881/888 elements full on both haplotypes are full in both directions;
- reads of the other haplotype only (HipHap partition, below), at the flank 200 bp outside each element end (>= 5
  reads present, 0 absent; `benchmark/assembly_truth/truth_check.sh`), confirmed truth, hap1 / hap2 reference:

  | | full (F) present | other length (Fx) present | empty (E) present | solo (S) present | replaced (Nr) absent |
  |---|---|---|---|---|---|
  | *C. amara* | 99.6 / 99.4% | 94.4 / 94.7% | 87.0 / 87.7% | 89 / 86% | 91.1 / 91.9% |
  | *M. falcata* | 98.9 / 97.5% | 95.4 / 94.9% | 86.1 / 87.4% | 91 / 91% | 75.2 / 73.7% |

  Junction-rescued empty sites fail this check (*C. amara*: 74% without reads) and are not headline. Element-and-
  flank deletions (Nd) are not diagnostic at 200 bp (the deletion may end closer to the element).

## Scoring and baselines
- Concordance = correct genotype / scored sites (no-calls are wrong). Recall per truth genotype. Empty-allele
  precision = calls carrying E at truth F/E / all calls carrying E.
- **Sniffles2 2.8.1** `--genotype-vcf` and **kanpig 2.0.2** on two deletion records per element (empty: element + one
  TSD; solo: internal region + one LTR), combined into one genotype; kanpig genotypes deletions <= 10 kb by design.
- **Presence/absence in another individual**: the reads of the other haplotype only, assigned by **HipHap 0.2.0**
  (best summed alignment score to hap1 vs hap2; ties by read-name hash), genotyped on the reference with
  `--ploidy 1` and 2 and scored on `pav` (present / absent / solo).

## Results: *C. amara*, PacBio HiFi
Confirmed truth: 2,425 sites (hap1 reference; 1,060 F/F, 586 F/E, 28 F/S, 751 F/N) and 2,443 (hap2 reference,
1,052 / 636 / 28 / 727; the held-out direction: no development used it). Concordance, %, mean of 3 seeds at 5x and
10x (sd <= 2.3 points for v0.1, <= 1.6 for v0.2):

| depth | hap1: v0.1 | **v0.2** | Sniffles2 | kanpig | hap2: v0.1 | **v0.2** | Sniffles2 | kanpig |
|---|---|---|---|---|---|---|---|---|
| 5x | 76.6 | **82.0** | 52.1 | 37.1 | 77.5 | **82.7** | 51.0 | 38.6 |
| 10x | 85.0 | **89.2** | 54.4 | 42.8 | 85.8 | **91.3** | 53.5 | 44.3 |
| 15x | 85.9 | **90.9** | 55.0 | 45.1 | 87.2 | **92.5** | 54.1 | 46.0 |
| 20x | 87.4 | **92.7** | 55.3 | 45.8 | 89.6 | **94.1** | 54.1 | 47.4 |
| 30x | 89.8 | **93.7** | 55.3 | 46.4 | 90.7 | **95.2** | 54.5 | 48.4 |
| 40x | 89.3 | **94.0** | 55.6 | 47.2 | 93.0 | **95.6** | 54.3 | 49.2 |
| 60x | 91.3 | **94.5** | 55.5 | 47.7 | 94.0 | **95.8** | 54.3 | 49.6 |

Per class at 20x (hap1 / hap2):

| | F/F recall | F/E recall | empty precision | F/S recall | F/N recall | GQ >= 20: correct / called |
|---|---|---|---|---|---|---|
| v0.1 | 0.789 / 0.829 | 0.964 / 0.970 | 0.969 / 0.981 | 0.929 / 0.821 | 0.923 / 0.931 | 0.937 / 0.59; 0.960 / 0.58 |
| **v0.2** | **0.934 / 0.939** | 0.964 / 0.970 | 0.966 / 0.981 | 0.929 / 0.786 | 0.887 / 0.924 | **0.969 / 0.70; 0.983 / 0.65** |
| Sniffles2 | 0.992 / 0.989 | 0.483 / 0.431 | 0.894 / 0.913 | 0.250 / 0.250 | 0 / 0 | 0.481 / 0.22; 0.429 / 0.23 |
| kanpig | 0.720 / 0.746 | 0.568 / 0.566 | 0.935 / 0.958 | 0.536 / 0.464 | 0 / 0 | 0.905 / 0.07; 0.922 / 0.07 |

- The v0.2 gain is in F/F (an element on both haplotypes), from read phasing and from counting full alleles of
  another internal length. Empty and solo calls are as good as in v0.1 (F/S: 28 sites, one call apart on hap2).
  F/N recall is 3.6 / 0.7 points lower than in v0.1: some two-copy-or-one decisions rest on depth alone (below).
- The depth model and the genotype prior (p11-p12) add most at low depth: 5x 79.6% (p9) -> 82.0% (hap1).
- Sniffles2 calls nearly everything F/F (its default for an absent deletion); neither baseline has a null allele,
  so all hemizygous sites (31% of the confirmed set) are wrong for them. kanpig does not genotype deletions > 10 kb.
- On all scored truth (including junction-rescued and alignment-only sites, harder regions with a less reliable
  truth): v0.2 80.2 / 81.8% at 20x vs v0.1 77.1 / 79.5%, Sniffles2 43%, kanpig 34-36%.
- Development used odd chromosomes of hap1; on even chromosomes the v0.2 - v0.1 gain is the same (all scored
  truth, range over depths: odd +2.5 to +5.5 points, even +2.2 to +5.8).

Strata (confirmed, 20x, v0.1 -> v0.2; hap1 / hap2): elements < 5 kb 87.7 -> 93.8 / 89.0 -> 95.6; 5-10 kb
90.2 -> 92.7 / 91.1 -> 94.3; 10-17 kb 83.3 -> 92.1 / 88.4 -> 92.3; > 17 kb 81.3 -> 89.2 / 87.7 -> 91.1 (kanpig: 0-7%
above 10 kb); inner (nested) elements 83.5 -> 91.9 / 87.0 -> 91.8; LTR K2P > 0.02 85.1 -> 93.8 / 88.0 -> 94.8; young
(0 < K2P <= 0.005) 87.8 -> 87.4 / 88.9 -> 91.2 and identical LTRs 92.4 -> 91.6 / 91.1 -> 91.6; haplotype divergence
around the site < 0.1% (identical by descent: nothing to phase) 79.1 -> 86.7 / 84.7 -> 88.5, > 1% 88.5 -> 94.1 /
90.0 -> 94.9.

**Presence/absence in another individual** (reads of the other haplotype only; confirmed truth: n 1,314 on hap1,
1,375 on hap2). `pav` calls that are made are 99.3-99.9% correct at every depth; absent precision is 1.000 in every
set.

| depth per haplotype | ploidy 1: concordance / absent recall / present recall | ploidy 2: concordance / absent recall / present recall |
|---|---|---|
| 5x | 0.915 / 0.867 / 0.966 (hap2 0.906 / 0.874 / 0.954) | 0.917 / 0.865 / 0.970 (hap2 0.907 / 0.871 / 0.958) |
| 10x | 0.970 / 0.945 / 0.994 (hap2 0.969 / 0.958 / 0.989) | 0.967 / 0.942 / 0.996 (hap2 0.968 / 0.951 / 0.992) |
| 20x | 0.981 / 0.963 / 0.999 (hap2 0.980 / 0.975 / 0.994) | 0.977 / 0.959 / 0.999 (hap2 0.977 / 0.969 / 0.996) |

Phasing is silent on single-haplotype reads; the difference from v0.1 is the depth model and the prior. With
ploidy 2 at 5x, v0.1 recalled 0.672 / 0.665 of absent sites; v0.2 0.865 / 0.871, as good as ploidy 1 here (not in
*M. falcata*, below).

## Results: *M. sativa* subsp. *falcata*, ONT
The second species and platform. It was held out until the release candidate (p8); its hap1 results then
exposed the depth-model failure that p11 fixes and were used to test the genotype prior (p12). The hap2 reference
was never used in development. Its haplotypes are a hifiasm ONT principal/alternate pair without Hi-C phasing:
the alternate is a pseudohaplotype, ~44% of elements lie where the haplotypes do not align colinearly, and its
one-haplotype truth is less certain than in *C. amara* (see the errors below). Concordance, % (one seed per
depth):

<!-- BEGIN Mfalcata tables (benchmark/assembly_truth/doc_tables.py Mfalcata v02) -->

Confirmed truth: 9,869 sites on the hap1 reference (3,012 F/F, 2,889 F/E, 128 F/S, 3,840 F/N); 9,687 sites on the hap2 reference (3,024 F/F, 2,819 F/E, 125 F/S, 3,719 F/N).

| depth | hap1: v0.1 | **v0.2** | Sniffles2 | kanpig | hap2: v0.1 | **v0.2** | Sniffles2 | kanpig |
|---|---|---|---|---|---|---|---|---|
| 5x | 73.4 | **83.1** | 45.6 | 29.5 | 73.8 | **83.4** | 46.2 | 30.1 |
| 10x | 77.0 | **87.8** | 48.7 | 32.6 | 79.0 | **88.9** | 49.4 | 33.4 |
| 15x | 80.0 | **90.2** | 49.4 | 33.6 | 84.0 | **91.4** | 50.1 | 34.7 |
| 20x | 73.7 | **91.4** | 49.6 | 34.0 | 82.5 | **92.2** | 50.7 | 35.1 |
| 30x | 74.6 | **92.2** | 50.0 | 34.3 | 87.1 | **92.9** | 51.0 | 35.4 |
| 40x | 86.8 | **92.7** | 50.1 | 34.4 | 88.7 | **93.5** | 51.1 | 35.5 |

Per class at 20x (hap1 / hap2):

| | F/F recall | F/E recall | empty precision | F/S recall | F/N recall | GQ >= 20: correct / called |
|---|---|---|---|---|---|---|
| v0.1 | 0.942 / 0.913 | 0.942 / 0.950 | 0.932 / 0.943 | 0.898 / 0.832 | 0.416 / 0.658 | 0.899 / 0.60; 0.953 / 0.49 |
| **v0.2** | 0.940 / 0.947 | 0.942 / 0.950 | 0.926 / 0.939 | 0.898 / 0.832 | 0.874 / 0.885 | 0.948 / 0.62; 0.954 / 0.64 |
| Sniffles2 | 0.982 / 0.983 | 0.665 / 0.683 | 0.874 / 0.876 | 0.172 / 0.144 | 0.000 / 0.000 | 0.675 / 0.27; 0.683 / 0.27 |
| kanpig | 0.672 / 0.681 | 0.440 / 0.457 | 0.863 / 0.863 | 0.508 / 0.392 | 0.000 / 0.000 | 0.785 / 0.14; 0.807 / 0.14 |

On all scored truth at 20x (including junction-rescued and alignment-only sites): v0.2 80.3 / 80.8% vs v0.1 63.0 /
71.0%, Sniffles2 40-42%, kanpig 27-28%.
<!-- END Mfalcata tables -->

- **Depth model.** v0.1 was not monotonic in depth (73.7% at 20x, 86.8% at 40x). Its depth estimate, the
  genome-wide mode, fell between the one- and two-copy peaks: much of the sequence is on one haplotype, and ONT
  depth is overdispersed (NB size ~10), so from 15x up the two peaks merge. v0.2 fits a copy-number mixture and then
  calibrates the per-haplotype depth at the sample's 3,400-5,000 sites with an empty or solo allele: 3.5 / 6.6 /
  10.1 / 13.5 / 20.3 / 27.1 reads per haplotype at 5 / 10 / 15 / 20 / 30 / 40x, against 3.3 / 6.4 / 8.5 / 11.0 /
  16.2 / 21.7 from the genome-wide fit alone (hap1). F/N recall at 20x: 0.416 / 0.658 -> 0.874 / 0.885. In *C. amara* both estimates agree
  (12.3 genome-wide, 12.1 at element sites, 20x), which is why the HiFi benchmark never exposed the problem.
- **Genotype prior** learned at 20x: F/N 0.47, F/F 0.31, F/E 0.21, F/S 0.01 (*C. amara*: F/N 0.45, F/F 0.36, F/E
  0.16, F/S 0.02).
- **Confidence.** Calls with GQ >= 20 are 94.8 / 95.4% correct (62 / 64% of sites; HiFi 96.9-98.3%).
- **Strata** (confirmed, 20x, v0.1 -> v0.2; hap1 / hap2): haplotype divergence around the site > 1% (82% of
  sites) 75.8 -> 91.4 / 83.3 -> 92.5%; identical-by-descent stretches (< 0.1%; n 173 / 172, mostly F/F) 97.7 -> 94.8
  / 97.7 -> 94.2% (F/F called F/N on depth alone; v0.1's low depth estimate favored F/F there); elements > 17 kb
  68.6 -> 92.2 / 79.2 -> 91.9% (kanpig 0-0.2%); inner (nested) elements 69.6 -> 91.6 / 79.1 -> 91.5%.
- **Errors and the truth.** At 20x (hap1 reference) 846 of 9,869 calls differ from the truth: F/N called F/F (278)
  or F/E (195; 154 at GQ >= 20), F/F called F/N (151), F/E called F/N (145). The other haplotype's own reads
  (HipHap partition; `benchmark/assembly_truth/truth_sensitivity.py`) contradict 9.8 / 10.1% of the confirmed truth (*C. amara* 8.0 /
  7.0%), mostly one-haplotype sites whose flanks they cover (13.5% of them; *C. amara* 5-7%), where the
  pseudohaplotype assembly lacks sequence the reads show. 35% of the errors fall at such sites (*C. amara* 22%). Where
  the reads agree with the truth, concordance is 93.8 / 94.4% (*C. amara* 93.8 / 95.1%): the two platforms converge.
  The reads are part of the genotyped set, so this bounds truth error; it does not replace the truth. The largest
  remaining groups: one-haplotype sites called F/F although the other haplotype's reads are absent (166; paralogous
  reads), empty sites called F/N where they are absent (99; reads of a divergent haplotype that do not align), and
  elements of another internal length called F/N although the other haplotype's reads are present (91).
- **Runtime**: 24,203 elements x 40x ONT in 16.5 min with 8 threads on a busy server, 0.33 GB.

**Presence/absence in another individual** (reads of the other haplotype only, HipHap: 51.4% of reads to hap1,
48.2% to hap2, 0.3% ties; confirmed truth: n 4,602 on hap1, 4,574 on hap2). `pav` calls that are made are
97.8-99.5% correct; absent precision >= 0.999.

| depth per haplotype | ploidy 1: concordance / absent recall / present recall | ploidy 2: concordance / absent recall / present recall |
|---|---|---|
| 5x | 0.892 / 0.863 / 0.966 (hap2 0.894 / 0.865 / 0.971) | 0.847 / 0.796 / 0.970 (hap2 0.847 / 0.792 / 0.972) |
| 10x | 0.942 / 0.920 / 0.987 (hap2 0.944 / 0.929 / 0.985) | 0.909 / 0.875 / 0.990 (hap2 0.911 / 0.883 / 0.985) |
| 20x | 0.952 / 0.935 / 0.991 (hap2 0.955 / 0.945 / 0.988) | 0.936 / 0.914 / 0.993 (hap2 0.934 / 0.915 / 0.988) |

Ploidy 1 is as in v0.1; ploidy 2 at 5x rose from 0.763 / 0.702 (v0.1) to 0.847. Unlike *C. amara*, ploidy 2 still
trails ploidy 1 (present precision 0.95 vs 0.98-0.99, in both versions): for reads of one haplotype, `--ploidy 1`
is the model to use.


## Development ladder (hap1 reference, confirmed truth, concordance %)
Each step is one development snapshot (not kept in the repository), compared on the same BAMs.

| version | change | *C. amara* 20x | *C. amara* 60x | *M. falcata* 20x |
|---|---|---|---|---|
| v0.1 | | 87.4 | 91.3 | 73.7 |
| p1 | read phasing (PH_ERR 0.01) | 91.8 | 93.6 | |
| p2 | + junction rule (element end carried) | 91.8 | 93.6 | |
| p3 | + PH_ERR 0.05 (measured spurious rate) | 91.5 | 93.3 | |
| p4 | + full reads of another internal length count as full | 92.5 | 94.3 | |
| p5/p6 | + low-MAPQ no-calls; unique sample names | 92.5 | 94.3 | |
| p7 | + fixed +100 bp tolerance at TSD-less ends | 92.2 | 93.9 | |
| p8 | adaptive boundary tolerance instead | 92.4 | 94.2 | |
| p9 | + base quality >= 20 in phasing (ONT), faster phasing | 92.5 | 94.3 | |
| p10 | + at most 80 reads per element in phasing | | 94.3 | 74.0 |
| p11 | + depth: copy-number mixture, calibrated at the sample's empty/solo sites | 92.5 | 94.6 | 90.9 |
| **p12 = v0.2** | + empirical-Bayes genotype prior | **92.7** | **94.5** | **91.4** |

*M. falcata* was held out until p8 (the release candidate). Its first run (p10) showed the depth-model failure that
p11 fixes; p12 was tested on both species at once, on the p11 likelihoods, before it was adopted.

p5 changed no confirmed call but made GQ honest where reads are ambiguous (GQ >= 20 correct: 93.7 -> 96.9% at 20x).

## Robustness (*C. amara* hap1, v0.2, confirmed truth)
| condition | 20x | 60x |
|---|---|---|
| reference run | 92.7 | 94.5 |
| annotation ends shifted +-5 / +-20 / +-50 bp, TSDs dropped | 92.7 / 92.6 / 92.6 | 94.5 / 94.5 / 94.4 |
| primary-only BAM (supplementary records removed) | 91.8 | 93.2 |
| two samples in one run (diploid 20x + other haplotype 10x) | genotypes and GQ identical to the single-sample runs at all 5,839 elements (each sample learns its own depth, error and prior) | |

- Boundary error: with v0.1's fixed windows (measured on snapshot p6, which kept them) +-50 bp cost 4.4 points:
  empty-allele reads fell outside the 50-bp window. v0.2 learns
  the error from the sample's own reads at TSD-less elements and widens only those windows: +12-14 bp for the exact
  LTRquest annotation, +15 bp at +-5, +39 bp at +-20, +92-93 bp at +-50.
- Primary-only BAMs lose about one point (0.8 / 1.2): some empty-allele reads exist only as supplementary records (their
  primary alignment lies elsewhere, often near another structural difference). Keep supplementary alignments.

## Regression on the v0.1 benchmarks (same inputs and scripts as v0.1)
| benchmark | v0.1 | v0.2 |
|---|---|---|
| simulated reads, identical haplotypes, 430 planted sites in *P. supina* sequence: concordance HiFi 10 / 20 / 40x | 92.8 / 95.3 / 99.5 | 93.7 / 96.0 / 98.6 |
| same, ONT 10 / 20 / 40x | 90.2 / 95.8 / 98.4 | 90.0 / 94.0 / 97.9 |
| same region, all 1,320 elements with a clear truth: HiFi 10 / 20 / 40x | 89.4 / 93.6 / 99.2 | **96.3 / 98.3 / 99.3** |
| same, ONT 10 / 20 / 40x | 87.2 / 94.6 / 98.6 | **96.6 / 97.8 / 99.2** |
| same, hemizygous (F/N) precision / recall at 20x: HiFi; ONT | 0.33 / 1.00; 0.34 / 0.76 | 0.76 / 0.67; 0.84 / 0.38 |
| same, calls with GQ >= 20: correct (share of elements) | 99.9-100% (30-85%) | 99.7-100% (62-95%) |
| *P. supina* HiFi 63x vs read-phasing haplotags (1,195 elements): all calls correct | 85.4% | **94.0%** |
| same, calls with GQ >= 20: correct (share called) | 93.3% (65%) | 97.4% (74%) |
| same, all calls: F/F recall / one-haplotype recall | 0.793 / 0.959 | 0.956 / 0.912 |
| same, GQ >= 20 only (the v0.1 metric): F/F precision / recall; one-haplotype precision / recall | 0.986 / 0.479; 0.884 / 0.810 | 0.982 / 0.811; 0.954 / 0.559 |
| *P. annua* ONT ~18x, C11 / P3 vs their assemblies, `pav` absent precision / recall | 1.000 / 0.872; 0.999 / 0.873 | 1.000 / 0.875; 0.999 / 0.881 |
| same, present precision / recall | 0.998 / 0.998; 0.997 / 0.996 | 0.998 / 0.998; 0.997 / 0.997 |
| same, `--ploidy 1` absent precision / recall | 0.984 / 0.912; 0.982 / 0.916 | 0.985 / 0.909; 0.983 / 0.920 |

- **Simulation.** The 430 planted sites over-represent hemizygous elements (10%, against 3.2% of all elements in
  the region, the rest being unplanted F/F). Where the two haplotypes are identical nothing can be phased and F/F
  vs F/N rests on depth alone. v0.1 then called many F/F elements F/N (F/N precision 0.18-0.34 at 10-20x). v0.2's
  learned prior (F/N 2.9-5.1%, true 3.2%) makes such calls conservative: far fewer false F/N, at the cost of F/N
  recall. Over all elements of the region v0.2 is better at every depth; on the planted set alone it is equal
  (HiFi) or 0.2-1.8 points lower (ONT).
- ***P. supina*.** All calls are more accurate, and confident calls more often right. The v0.1 metric counts
  GQ >= 20 calls only, and there one-haplotype recall falls (0.810 -> 0.559): depth-only F/N calls now carry less
  confidence (median GQ 28 -> 14) because the depth spread is measured at element sites and the prior (F/F 0.66,
  F/N 0.22) favors F/F. The earlier confidence was overstated (v0.1's GQ >= 20 one-haplotype calls were 88% correct).

## Read phasing: error control
- Spurious second haplotypes, measured where the answer is one by construction:
  - simulated reads from identical haplotypes (badread, v0.1 benchmark): HiFi 0.4%; ONT 44% (40x) and 13% (20x)
    before the base-quality filter, 0-0.4% after it. Per-read accuracy varies in ONT, so a low-accuracy read
    carries errors at many sites at once and error sites look linked; bases below Q20 are now ignored.
  - *C. amara* confirmed one-haplotype sites: 4.0-4.9% (paralog reads from sequence that the reference
    haplotype lacks); this sets PH_ERR = 0.05.
- Detection: two haplotypes are seen at 65-70% of *C. amara* sites truly carried by both (the rest lie in
  identical-by-descent stretches or lack heterozygous sites near the element).
- BAMs without base qualities and with reads diverging > 1% from the reference run without phasing (logged).

## `source`: propagation of genotype errors (*C. amara* hap1)
`ltrkin source` run on assembly-truth genotypes and on v0.2 calls restricted to the same confirmed sites:

| genotypes | truth new copies with a source recovered | extra new copies | tied source sets overlap | overlap where the truth source is <= 1% diverged |
|---|---|---|---|---|
| 20x | 0.858 (169/197) | 2 | 0.799 | 0.94 (n 16) |
| 60x | 0.919 (181/197) | 2 | 0.851 | 0.89 (n 18) |

`source` itself is unchanged from v0.1 (its simulation benchmarks stand). Runtime: 1.7 min, 2.2 GB, 5,839 elements.

## Limits found
- **Reference bias.** Reads from a haplotype that is highly divergent around a site may not align to the
  reference there, and paralogous reads from sequence the reference haplotype lacks may align instead. Both
  mimic dosage changes; depth and phasing are fooled alike. These are most of the remaining F/F <-> F/N errors.
- **Identical-by-descent regions** offer no heterozygous sites, so F/F vs F/N rests on depth alone (*C. amara*
  87-89% at 20x; *M. falcata* 95%, with 7 of 154 F/F called F/N). The learned prior then follows the sample's
  common genotype: in an outcrosser it favors F/N, in a sample where hemizygous elements are rare it makes them
  conservative (simulated identical haplotypes, ONT 20x: F/N precision 0.84, recall 0.38).
- **GQ is a ranking more than an exact probability.** Calls with GQ >= 20 are 99.7-100% correct in simulation but
  95-98% against assembly truth (*C. amara* 96.9-98.3%, *M. falcata* 94.8%, *P. supina* haplotags 97.4%): truth
  errors and reference bias lie outside the model.
- **Truth limits.** About 40% of elements in both species lie in sequence one haplotype lacks; alignment-only
  and junction-rescued truth there is less reliable (rescued empty sites fail an independent read check) and is
  reported separately, never in the headline.
