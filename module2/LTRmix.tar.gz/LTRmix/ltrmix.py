#!/usr/bin/env python3
"""ltrmix.py - admixture and introgression between genomes from their LTR-retrotransposon libraries alone.

Input: one LTR-RT library per genome (LTRquest output prefix, or FASTA + table). No genome sequence, genes, SNPs or
outgroup. Three properties of LTR-RTs carry the method:
  - an insertion is a derived state (absence is ancestral), so shared insertions are polarized without an outgroup;
  - the TSD is a 5-bp certificate of one insertion event, so orthology can be checked inside the library;
  - an element's two LTRs were identical at insertion, so each LTR is an outgroup for the other (self-outgroup) and
    their divergence is a clock.

Stages: (1) k-mer index of each library; (2) library-only orthology: rare shared k-mers -> collinear chains (both
orientations; chromosome correspondence and inversions learned from the data) -> 1:1 orthologs, and per element the
status 'present', 'absent' (inside a syntenic interval, no ortholog) or 'unresolved'; (3) trio statistics with a
5-Mb block jackknife: the sister pair is the pair sharing most single-copy k-mers; D from single-copy k-mers,
D from insertion presence/absence, D from ortholog triples polarized by the sister LTR, the identity spectrum of
recipient-donor vs sister-donor orthologs (mirror control), age strata from the LTR clock, and an admixture-fraction
lower bound; (4) local ancestry: per-element likelihood ratios calibrated by the mirror, a two-state HMM along each
chromosome (tract length fitted), tract FDR by within-chromosome permutation; (5) inversions from chain orientation.

Output (in --outdir): stats.tsv, elements.<genome>.tsv, tracts.<genome>.bed, blocks.tsv, inversions.tsv,
findings.txt, overview.png/pdf. See README.md.

usage: ltrmix.py --genome A=PREFIX --genome B=PREFIX --genome C=PREFIX --outdir OUT [-t 16] [-v]
"""
from __future__ import annotations

import argparse
import glob
import gzip
import math
import os
import re
import sys
import time
from dataclasses import dataclass, field
from multiprocessing import get_context

# NumPy's transparent-huge-page advice on large arrays can stall allocations for minutes in direct memory compaction
# on a busy, fragmented server; results do not depend on it
os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")

import numpy as np  # noqa: E402

# ---------------------------------------------------------------------------------------------------------------------
# Fixed internal constants (one place; each with its reason)
# ---------------------------------------------------------------------------------------------------------------------
K = 21              # canonical k-mer size: 4^21 >> library size (chance matches rare), still tolerant of 1-2% divergence
RBITS = 64 - 2 * K  # record-index bits packed under the k-mer in one uint64 sort key (4.2 M records per library)
CMAX_PAIR = 4       # orthology candidates use k-mers with <= 4 copies per library: orthologs in young families share
#                     only low-copy k-mers; bounds candidate pairs per k-mer to 16
CHAIN_GAP = 20      # collinear chaining tolerates up to 20 anchors of local disorder (rank space; scale-free)
CHAIN_MIN = 5       # floor on syntenic block size; the actual minimum per chromosome pair is one more than the
#                     longest chain among the same anchors with shuffled partner positions (20 shuffles)
BLOCK_BP = 5_000_000  # jackknife block: >> LD in outcrossing grasses, and gives hundreds of blocks per genome;
#                       capped at 1/100 of the genome's span so small genomes still get ~100 blocks (set in main)
MIN_ALN_FRAC = 0.5  # an ortholog alignment must cover >= half of the shorter record (else orientation/record error)
SELF_Z = 1.96       # record-end LTRs are used when their own K2P reproduces the annotated K2P within sampling error
#                     (same rule as ltrharvest_phasing10 v10.1) or within one substitution
PI_MAX = 0.5        # donor-like fraction of the recipient <= 1/2: a genome with more donor than sister ancestry
#                     would have been inferred as the donor's sister
BF_TRACT = 3.0      # tract elements need posterior odds >= 3x prior odds ('positive' evidence, Kass & Raftery 1995)
HMM_L_GRID = np.exp(np.linspace(np.log(1e4), np.log(5e7), 41))  # candidate mean tract lengths (bp) for the HMM fit

_G = {}             # globals shared with forked workers (copy-on-write)
ARGS_THREADS = [8]  # worker count, set in main


def log(msg, verbose_only=False):
    if verbose_only and not ARGS.verbose:
        return
    print(f"[ltrmix {time.strftime('%H:%M:%S')}] {msg}", file=sys.stderr, flush=True)


ARGS = argparse.Namespace(verbose=False)


# ---------------------------------------------------------------------------------------------------------------------
# Library input
# ---------------------------------------------------------------------------------------------------------------------
_ID = re.compile(r"^(?:.*::)?(?P<chrom>.+):(?P<s>\d+)(?:-|\.\.)(?P<e>\d+)(?:\([+-.]\))?(?:#(?P<cls>.*))?$")
_RC = bytes.maketrans(b"ACGTacgt", b"TGCAtgca")


@dataclass
class Lib:
    label: str
    names: list
    chrom: np.ndarray        # object array of chromosome names
    start: np.ndarray
    end: np.ndarray
    strand: np.ndarray       # '+', '-', '.'
    k2p: np.ndarray          # annotated LTR-LTR divergence (nan if unknown)
    tsd: np.ndarray          # canonical TSD string or ''
    l5: np.ndarray           # annotated ltr5_len (genome-left LTR), 0 if unknown
    l3: np.ndarray
    seq: np.ndarray          # uint8, concatenated records (masked letters kept)
    offs: np.ndarray         # record boundaries in seq
    cls: np.ndarray = field(default=None)

    @property
    def n(self):
        return len(self.names)

    def record(self, i, strip=True):
        s = self.seq[self.offs[i]:self.offs[i + 1]].tobytes()
        if strip:
            s = re.sub(rb"[^ACGTacgt]", b"", s).upper()
        return s

    @property
    def mid(self):
        return (self.start + self.end) // 2


def _canon_tsd(t):
    if not isinstance(t, str) or not t or t in (".", "NA") or not re.fullmatch(r"[ACGTacgt]+", t):
        return ""
    t = t.upper()
    r = t[::-1].translate(_RC.decode("latin1").maketrans("ACGT", "TGCA")) if False else t[::-1].translate(
        str.maketrans("ACGT", "TGCA"))
    return min(t, r)


def _read_fasta(paths):
    names, chunks, offs, tot = [], [], [0], 0
    for p in paths:
        op = gzip.open if p.endswith(".gz") else open
        cur = []
        with op(p, "rb") as f:
            for line in f:
                if line.startswith(b">"):
                    if names and (cur or len(names) > len(offs) - 1):
                        s = b"".join(cur)
                        chunks.append(s)
                        tot += len(s)
                        offs.append(tot)
                    names.append(line[1:].split()[0].decode())
                    cur = []
                else:
                    cur.append(line.strip())
            if names and len(names) > len(offs) - 1:
                s = b"".join(cur)
                chunks.append(s)
                tot += len(s)
                offs.append(tot)
    seq = np.frombuffer(b"".join(chunks), dtype=np.uint8)
    return names, seq, np.asarray(offs, np.int64)


def _read_table(paths):
    """Rows keyed by seq_id from LTRquest-style TSVs (first column seq_id; '#' allowed in the header)."""
    rows = {}
    for p in paths:
        op = gzip.open if p.endswith(".gz") else open
        with op(p, "rt") as f:
            hdr = f.readline().rstrip("\n").lstrip("#").split("\t")
            for line in f:
                v = line.rstrip("\n").split("\t")
                rows[v[0]] = dict(zip(hdr, v))
    return rows


def _num(x, default=np.nan):
    try:
        v = float(x)
        return v if math.isfinite(v) else default
    except (TypeError, ValueError):
        return default


def load_library(label, spec):
    """spec = LTRquest prefix (path/to/X_LTRs: reads X_LTRs_depth*_clean_ltr.{fa,tsv}) or 'FASTA[,TABLE]'."""
    if "," in spec or spec.endswith((".fa", ".fasta", ".fa.gz", ".fasta.gz", ".fna")):
        fa, *tb = spec.split(",")
        fas, tabs = [fa], tb
    else:
        fas = sorted(glob.glob(spec + "_depth[0-9]*_clean_ltr.fa"), key=lambda p: int(re.search(r"_depth(\d+)_", p)[1]))
        tabs = [p[:-3] + ".tsv" for p in fas]
        if not fas:
            sys.exit(f"ERROR: no LTRquest libraries '{spec}_depth*_clean_ltr.fa' for genome {label}")
    for p in fas + tabs:
        if not os.path.exists(p):
            sys.exit(f"ERROR: missing input {p}")
    names, seq, offs = _read_fasta(fas)
    if not names:
        sys.exit(f"ERROR: genome {label}: no records in {fas}")
    tab = _read_table(tabs) if tabs else {}
    n = len(names)
    chrom = np.empty(n, object)
    start = np.zeros(n, np.int64)
    end = np.zeros(n, np.int64)
    strand = np.full(n, ".", object)
    cls = np.full(n, "", object)
    k2p = np.full(n, np.nan)
    tsd = np.full(n, "", object)
    l5 = np.zeros(n, np.int64)
    l3 = np.zeros(n, np.int64)
    bad = 0
    for i, nm in enumerate(names):
        m = _ID.match(nm)
        if not m:
            bad += 1
            chrom[i], start[i], end[i] = nm, 0, offs[i + 1] - offs[i]
        else:
            chrom[i], start[i], end[i] = m["chrom"], int(m["s"]), int(m["e"])
            cls[i] = m["cls"] or ""
        r = tab.get(nm)
        if r:
            k2p[i] = _num(r.get("k2p", r.get("K2P_d")))
            tsd[i] = _canon_tsd(r.get("tsd", ""))
            st = r.get("strand", ".")
            strand[i] = st if st in ("+", "-") else "."
            l5[i] = int(_num(r.get("ltr5_len"), 0))
            l3[i] = int(_num(r.get("ltr3_len"), 0))
    if bad > n * 0.5:
        sys.exit(f"ERROR: genome {label}: {bad}/{n} record names lack chrom:start-end coordinates")
    if bad:
        log(f"WARNING {label}: {bad} records without coordinates (kept, unplaced)")
    if tab and np.isnan(k2p).all():
        log(f"WARNING {label}: no K2P values: age strata disabled for this genome")
    return Lib(label, names, chrom, start, end, strand, k2p, tsd, l5, l3, seq, offs, cls)


# ---------------------------------------------------------------------------------------------------------------------
# k-mer index (numba kernels)
# ---------------------------------------------------------------------------------------------------------------------
def _numba():
    from numba import njit, prange
    return njit, prange


njit, prange = _numba()


@njit(cache=True, nogil=True)
def _keys_of(seq, offs, k, rbits):
    code = np.full(256, 4, dtype=np.int64)
    for i, c in enumerate(b"ACGT"):
        code[c] = i
    for i, c in enumerate(b"acgt"):
        code[c] = i
    out = np.empty(len(seq), dtype=np.uint64)
    m = 0
    mask = (np.uint64(1) << np.uint64(2 * k)) - np.uint64(1)
    shift = np.uint64(2 * (k - 1))
    rb = np.uint64(rbits)
    for r in range(len(offs) - 1):
        f = np.uint64(0)
        rv = np.uint64(0)
        ln = 0
        for i in range(offs[r], offs[r + 1]):
            c = code[seq[i]]
            if c > 3:
                ln = 0
                f = np.uint64(0)
                rv = np.uint64(0)
                continue
            f = ((f << np.uint64(2)) | np.uint64(c)) & mask
            rv = (rv >> np.uint64(2)) | (np.uint64(3 - c) << shift)
            ln += 1
            if ln >= k:
                km = f if f < rv else rv
                out[m] = (km << rb) | np.uint64(r)
                m += 1
    return out[:m]


@njit(cache=True, nogil=True)
def _runs(keys, rbits):
    n = len(keys)
    u = np.empty(n, dtype=np.uint64)
    st = np.empty(n + 1, dtype=np.int64)
    m = 0
    prev = np.uint64(0xFFFFFFFFFFFFFFFF)
    rb = np.uint64(rbits)
    for i in range(n):
        km = keys[i] >> rb
        if km != prev:
            u[m] = km
            st[m] = i
            m += 1
            prev = km
    st[m] = n
    return u[:m].copy(), st[:m + 1].copy()


@njit(cache=True, nogil=True)
def _merge_idx(ua, ub):
    """Index into ub of every ua element, -1 if absent (both sorted)."""
    idx = np.full(len(ua), -1, dtype=np.int64)
    j = 0
    nb = len(ub)
    for i in range(len(ua)):
        while j < nb and ub[j] < ua[i]:
            j += 1
        if j < nb and ub[j] == ua[i]:
            idx[i] = j
    return idx


@njit(cache=True, nogil=True)
def _pair_emit(keys_a, st_a, idx, keys_b, st_b, cmax, rbits):
    """Candidate record pairs from k-mers with <= cmax copies in both libraries; weight 1/(ca*cb)."""
    rmask = (np.uint64(1) << np.uint64(rbits)) - np.uint64(1)
    tot = 0
    for r in range(len(idx)):
        j = idx[r]
        if j < 0:
            continue
        ca = st_a[r + 1] - st_a[r]
        cb = st_b[j + 1] - st_b[j]
        if ca <= cmax and cb <= cmax:
            tot += ca * cb
    pk = np.empty(tot, dtype=np.uint64)
    w = np.empty(tot, dtype=np.float32)
    m = 0
    for r in range(len(idx)):
        j = idx[r]
        if j < 0:
            continue
        ca = st_a[r + 1] - st_a[r]
        cb = st_b[j + 1] - st_b[j]
        if ca <= cmax and cb <= cmax:
            ww = 1.0 / (ca * cb)
            for x in range(st_a[r], st_a[r + 1]):
                ra = keys_a[x] & rmask
                for y in range(st_b[j], st_b[j + 1]):
                    rbx = keys_b[y] & rmask
                    pk[m] = (ra << np.uint64(32)) | rbx
                    w[m] = ww
                    m += 1
    return pk, w


@njit(cache=True, nogil=True)
def _reduce_pairs(pk, w):
    n = len(pk)
    up = np.empty(n, dtype=np.uint64)
    sw = np.empty(n, dtype=np.float64)
    cnt = np.empty(n, dtype=np.int64)
    m = -1
    prev = np.uint64(0xFFFFFFFFFFFFFFFF)
    for i in range(n):
        if pk[i] != prev:
            m += 1
            up[m] = pk[i]
            sw[m] = 0.0
            cnt[m] = 0
            prev = pk[i]
        sw[m] += w[i]
        cnt[m] += 1
    return up[:m + 1].copy(), sw[:m + 1].copy(), cnt[:m + 1].copy()


@njit(cache=True, nogil=True)
def _tally_single(keys, st, i1, st1, i2, st2, nrec, rbits):
    """Per record: counts of k-mers single-copy in every library that carries them, by carrier pattern:
    [self only, self+o1, self+o2, self+o1+o2]."""
    rmask = (np.uint64(1) << np.uint64(rbits)) - np.uint64(1)
    out = np.zeros((nrec, 4), dtype=np.int64)
    for r in range(len(st) - 1):
        if st[r + 1] - st[r] != 1:
            continue
        a = 0
        b = 0
        j = i1[r]
        if j >= 0:
            a = st1[j + 1] - st1[j]
        j = i2[r]
        if j >= 0:
            b = st2[j + 1] - st2[j]
        if a > 1 or b > 1:
            continue
        rec = int(keys[st[r]] & rmask)
        out[rec, a + 2 * b] += 1
    return out


class Index:
    """Sorted (k-mer << RBITS | record) keys of one library, with runs (distinct k-mers) and their starts.
    Not cached: rebuilding takes ~1.5 min per 1.7-Gb library, faster than reading a 13-GB index back from disk."""

    def __init__(self, lib: Lib):
        if lib.n >= (1 << RBITS):
            sys.exit(f"ERROR: {lib.label}: {lib.n} records exceed {1 << RBITS} (k={K}); split the library")
        t0 = time.time()
        self.keys = _keys_of(lib.seq, lib.offs, K, RBITS)
        self.keys.sort()
        self.u, self.st = _runs(self.keys, RBITS)
        log(f"{lib.label}: {len(self.keys):,} k-mers, {len(self.u):,} distinct ({time.time() - t0:.0f}s)")


def candidate_pairs(ia: Index, ib: Index):
    """Record pairs sharing low-copy k-mers: arrays (a, b, weight, n_kmers)."""
    idx = _merge_idx(ia.u, ib.u)
    pk, w = _pair_emit(ia.keys, ia.st, idx, ib.keys, ib.st, CMAX_PAIR, RBITS)
    o = np.argsort(pk, kind="stable")
    up, sw, cnt = _reduce_pairs(pk[o], w[o])
    return (up >> np.uint64(32)).astype(np.int64), (up & np.uint64(0xFFFFFFFF)).astype(np.int64), sw, cnt


# ---------------------------------------------------------------------------------------------------------------------
# Orthology: anchors -> collinear chains -> 1:1 orthologs and per-element status
# ---------------------------------------------------------------------------------------------------------------------
@njit(cache=True)
def _chain_dp(rx, ry, sign, gap):
    """Longest-chain DP in rank space for one orientation. rx sorted ascending. Returns score and predecessor."""
    n = len(rx)
    sc = np.ones(n, dtype=np.int64)
    pr = np.full(n, -1, dtype=np.int64)
    for i in range(n):
        lo = i - 4 * gap if i - 4 * gap > 0 else 0
        for j in range(i - 1, lo - 1, -1):
            dx = rx[i] - rx[j]
            if dx <= 0:
                continue
            if dx > gap:
                break
            dy = (ry[i] - ry[j]) * sign
            if 0 < dy <= gap and sc[j] + 1 > sc[i]:
                sc[i] = sc[j] + 1
                pr[i] = j
    return sc, pr


def chain_blocks(px, py, minlen=CHAIN_MIN):
    """Greedy extraction of collinear chains (both orientations) from anchors at positions px (x genome) and py,
    down to chains of minlen anchors. Returns a list of (indices into px, sign)."""
    n = len(px)
    if n < minlen:
        return []
    ox = np.argsort(px, kind="stable")
    rx = np.empty(n, np.int64)
    rx[ox] = np.arange(n)
    ry = np.empty(n, np.int64)
    ry[np.argsort(py, kind="stable")] = np.arange(n)
    alive = np.ones(n, bool)
    out = []
    while alive.sum() >= minlen:
        ids = ox[alive[ox]]
        best = None
        for sign in (1, -1):
            sc, pr = _chain_dp(rx[ids], ry[ids], sign, CHAIN_GAP)
            i = int(np.argmax(sc))
            if best is None or sc[i] > best[0]:
                best = (int(sc[i]), sign, sc, pr, i)
        s, sign, sc, pr, i = best
        if s < minlen:
            break
        ch = []
        while i >= 0:
            ch.append(ids[i])
            i = pr[i]
        ch = np.array(ch[::-1])
        alive[ch] = False
        out.append((ch, sign))
    return out


@dataclass
class PairOrtho:
    a: str
    b: str
    orth_b: np.ndarray       # for each record of a: ortholog index in b or -1
    orth_a: np.ndarray       # for each record of b: ortholog index in a or -1
    status_a: np.ndarray     # for each record of a: 2 present, 1 absent (syntenic, no ortholog), 0 unresolved
    status_b: np.ndarray
    blocks: list             # dicts: chrom_a, chrom_b, sign, a_start, a_end, b_start, b_end, n_anchor
    weight: np.ndarray       # candidate weight of the assigned ortholog (per record of a)
    tsd_rate: float = np.nan
    tsd_chance: float = np.nan


def _status_and_window(lib_x, lib_y, blocks_xy, which):
    """For each record of x: (block id, lo, hi) = interval of y positions between its flanking anchors."""
    n = lib_x.n
    bid = np.full(n, -1, np.int64)
    lo = np.full(n, -1, np.int64)
    hi = np.full(n, -1, np.int64)
    room = np.full(n, -1, np.int64)
    mx = lib_x.mid
    for k, blk in enumerate(blocks_xy):
        ax = blk["ax"] if which == "a" else blk["bx"]
        ay = blk["bx"] if which == "a" else blk["ax"]
        cx = blk["chrom_a"] if which == "a" else blk["chrom_b"]
        o = np.argsort(ax)
        ax, ay = ax[o], ay[o]
        sel = np.where((lib_x.chrom == cx) & (mx >= ax[0]) & (mx <= ax[-1]))[0]
        if len(sel) == 0:
            continue
        j = np.searchsorted(ax, mx[sel], side="right")
        j0 = np.clip(j - 2, 0, len(ax) - 1)   # one anchor of slack on each side
        j1 = np.clip(j + 1, 0, len(ax) - 1)
        y0, y1 = np.minimum(ay[j0], ay[j1]), np.maximum(ay[j0], ay[j1])
        # tight interval (immediate flanking anchors) for the 'no room' test
        t0 = np.clip(j - 1, 0, len(ax) - 1)
        t1 = np.clip(j, 0, len(ax) - 1)
        tr = np.abs(ay[t1] - ay[t0])
        upd = bid[sel] < 0
        s2 = sel[upd]
        bid[s2] = k
        lo[s2] = y0[upd]
        hi[s2] = y1[upd]
        room[s2] = tr[upd]
    return bid, lo, hi, room


def clock_filter(la, lb, ai, bi):
    """Align pairs; keep those whose divergence does not exceed the element's own LTR-LTR divergence beyond sampling
    error (orthologous copies coalesced after the insertion; paralogs have no such bound). The test compares LTRs with
    LTRs (whole records when LTR bounds are unknown). Returns keep, whole-record divergence."""
    c = align_pairs(la, lb, ai, bi, ARGS_THREADS[0])
    sites, mism = c[:, 0].astype(float), c[:, 1].astype(float)
    lsites, lmism = c[:, 3].astype(float), c[:, 4].astype(float)
    d = np.where(sites > 0, mism / np.maximum(sites, 1), np.nan)
    use_ltr = lsites >= 100
    dt = np.where(use_ltr, lmism / np.maximum(lsites, 1), d)
    nt = np.where(use_ltr, lsites, sites)
    mt = np.where(use_ltr, lmism, mism)
    kk = np.fmax(la.k2p[ai], lb.k2p[bi])
    lt = np.fmax(np.minimum(la.l5[ai], la.l3[ai]), 100).astype(float)
    se = np.sqrt(np.nan_to_num(dt) / np.maximum(nt, 1) + np.nan_to_num(kk) / lt)
    ok = (sites > 0) & (~np.isfinite(kk) | (dt - kk <= SELF_Z * se) | (mt <= 1))
    return ok, d


def _null_chain(px, py, rng, nperm=20):
    """Longest collinear chain among anchors with shuffled partner positions (max over nperm shuffles)."""
    n = len(px)
    rx = np.empty(n, np.int64)
    rx[np.argsort(px, kind="stable")] = np.arange(n)
    o = np.argsort(rx)
    best = 0
    for _ in range(nperm):
        ry = rng.permutation(n)
        for sign in (1, -1):
            sc, _ = _chain_dp(rx[o], ry[o], sign, CHAIN_GAP)
            best = max(best, int(sc.max()))
    return best


def orthology(la: Lib, lb: Lib, ia: Index, ib: Index):
    from scipy.stats import poisson
    t0 = time.time()
    a, b, w, cnt = candidate_pairs(ia, ib)
    log(f"{la.label}-{lb.label}: {len(a):,} candidate record pairs ({time.time() - t0:.0f}s)", True)
    # reciprocal best by weight -> anchors, which must pass the clock test
    o = np.lexsort((-w, a))
    first_a = np.ones(len(o), bool)
    first_a[1:] = a[o][1:] != a[o][:-1]
    best_a = o[first_a]
    o2 = np.lexsort((-w, b))
    first_b = np.ones(len(o2), bool)
    first_b[1:] = b[o2][1:] != b[o2][:-1]
    best_b = o2[first_b]
    bb = np.full(lb.n, -1, np.int64)
    bb[b[best_b]] = a[best_b]
    recip = best_a[bb[b[best_a]] == a[best_a]]
    kclock, dr = clock_filter(la, lb, a[recip], b[recip])
    # two independent orthology certificates: the clock, or an identical TSD (one insertion event; chance ~1/1000)
    tsd_eq_r = (la.tsd[a[recip]] != "") & (la.tsd[a[recip]] == lb.tsd[b[recip]])
    keep = kclock | tsd_eq_r
    div_pair = {}
    for k_, d_ in zip(recip, dr):
        div_pair[int(k_)] = d_
    clock_ok = {int(k_): bool(x) for k_, x in zip(recip, kclock)}
    anc = recip[keep]
    # chromosome correspondence from the data: pairs with more anchors than independence predicts
    ca, cb = la.chrom[a[anc]], lb.chrom[b[anc]]
    pairs = {}
    for i, (x, y) in enumerate(zip(ca, cb)):
        pairs.setdefault((x, y), []).append(anc[i])
    na, nb = {}, {}
    for (x, y), ids in pairs.items():
        na[x] = na.get(x, 0) + len(ids)
        nb[y] = nb.get(y, 0) + len(ids)
    N = max(len(anc), 1)
    alpha = 1e-6 / max(len(pairs), 1)
    rng = np.random.default_rng(0)
    blocks = []
    anchor_in_block = np.zeros(len(a), bool)
    n_pairs_kept = 0
    for (x, y), ids in pairs.items():
        ids = np.array(ids)
        exp = na[x] * nb[y] / N
        if len(ids) < CHAIN_MIN or poisson.sf(len(ids) - 1, exp) > alpha:
            continue
        n_pairs_kept += 1
        px, py = la.mid[a[ids]], lb.mid[b[ids]]
        minlen = max(CHAIN_MIN, _null_chain(px, py, rng) + 1)
        for ch, sign in chain_blocks(px, py, minlen):
            sel = ids[ch]
            anchor_in_block[sel] = True
            blocks.append(dict(chrom_a=x, chrom_b=y, sign=sign, ax=la.mid[a[sel]], bx=lb.mid[b[sel]],
                               a_start=int(la.mid[a[sel]].min()), a_end=int(la.mid[a[sel]].max()),
                               b_start=int(lb.mid[b[sel]].min()), b_end=int(lb.mid[b[sel]].max()),
                               n_anchor=len(sel), min_chain=minlen))
    log(f"{la.label}-{lb.label}: {len(recip):,} reciprocal best pairs, {len(anc):,} pass the clock test; "
        f"{n_pairs_kept} enriched chromosome pairs; {anchor_in_block.sum():,} anchors in {len(blocks)} collinear "
        f"blocks (longer than shuffled anchors)", True)
    # candidate pairs inside the syntenic window of their flanking anchors
    bid_a, lo_a, hi_a, room_a = _status_and_window(la, lb, blocks, "a")
    bid_b, lo_b, hi_b, room_b = _status_and_window(lb, la, blocks, "b")
    blk_chrom_b = np.array([blk["chrom_b"] for blk in blocks] + [None], object)
    ok = (bid_a[a] >= 0) & (lb.chrom[b] == blk_chrom_b[bid_a[a]]) & (lb.mid[b] >= lo_a[a]) & (lb.mid[b] <= hi_a[a])
    ok |= anchor_in_block
    # dominance: an ortholog must share more low-copy k-mers with its partner than either shares with any copy
    # outside the syntenic window (a same-family copy that merely sits in the window when the ortholog is absent
    # does not beat the element's out-of-window paralogs)
    off = ~ok
    w_off_a = np.zeros(la.n)
    w_off_b = np.zeros(lb.n)
    np.maximum.at(w_off_a, a[off], w[off])
    np.maximum.at(w_off_b, b[off], w[off])
    ok &= ((w > w_off_a[a]) & (w > w_off_b[b])) | anchor_in_block
    ci = np.where(ok)[0]
    o = ci[np.lexsort((-w[ci], a[ci]))]
    fa = np.ones(len(o), bool)
    fa[1:] = a[o][1:] != a[o][:-1]
    ba = o[fa]
    o2 = ci[np.lexsort((-w[ci], b[ci]))]
    fb = np.ones(len(o2), bool)
    fb[1:] = b[o2][1:] != b[o2][:-1]
    bbest = np.full(lb.n, -1, np.int64)
    bbest[b[o2[fb]]] = a[o2[fb]]
    mut = ba[bbest[b[ba]] == a[ba]]
    # clock test for in-window pairs not already tested as anchors
    new_ = np.array([k_ for k_ in mut if int(k_) not in clock_ok], np.int64)
    if len(new_):
        kp, dn = clock_filter(la, lb, a[new_], b[new_])
        for k_, x, d_ in zip(new_, kp, dn):
            clock_ok[int(k_)] = bool(x)
            div_pair[int(k_)] = d_
    clock_pass = np.array([clock_ok[int(k_)] for k_ in mut], bool) if len(mut) else np.zeros(0, bool)
    tsd_eq_m = (la.tsd[a[mut]] != "") & (la.tsd[a[mut]] == lb.tsd[b[mut]])
    tested = clock_pass | tsd_eq_m
    # validation on clock-accepted pairs only (the TSD is then an independent check)
    hv = clock_pass & (la.tsd[a[mut]] != "") & (lb.tsd[b[mut]] != "")
    val_rate = float(np.mean(la.tsd[a[mut]][hv] == lb.tsd[b[mut]][hv])) if hv.any() else np.nan
    n_rescued = int((~clock_pass & tsd_eq_m).sum())
    rej = mut[~tested]
    has_r = (la.tsd[a[rej]] != "") & (lb.tsd[b[rej]] != "")
    rej_tsd = float(np.mean(la.tsd[a[rej]][has_r] == lb.tsd[b[rej]][has_r])) if has_r.any() else np.nan
    mut = mut[tested]
    orth_b = np.full(la.n, -1, np.int64)
    orth_a = np.full(lb.n, -1, np.int64)
    weight = np.zeros(la.n)
    div_a = np.full(la.n, np.nan)
    orth_b[a[mut]] = b[mut]
    orth_a[b[mut]] = a[mut]
    weight[a[mut]] = w[mut]
    div_a[a[mut]] = np.array([div_pair[int(k_)] for k_ in mut]) if len(mut) else []
    st_a = np.where(orth_b >= 0, 2, np.where(bid_a >= 0, 1, 0)).astype(np.int8)
    st_b = np.where(orth_a >= 0, 2, np.where(bid_b >= 0, 1, 0)).astype(np.int8)
    # TSD certificate: chance agreement between random pairs with TSDs (the observed rate is val_rate, above)
    rng = np.random.default_rng(0)
    ta = la.tsd[la.tsd != ""]
    tb = lb.tsd[lb.tsd != ""]
    chance = float(np.mean(rng.choice(ta, 20000) == rng.choice(tb, 20000))) if len(ta) and len(tb) else np.nan
    for blk in blocks:
        blk.pop("ax"), blk.pop("bx")
    log(f"{la.label}-{lb.label}: {len(mut):,} 1:1 orthologs ({n_rescued:,} rescued by identical TSD after failing the "
        f"clock); TSD identical in {val_rate:.3f} of clock-accepted pairs (chance {chance:.4f}); {len(rej):,} "
        f"rejected; {la.label} present/absent/unresolved {np.bincount(st_a, minlength=3)[::-1].tolist()}")
    po = PairOrtho(la.label, lb.label, orth_b, orth_a, st_a, st_b, blocks, weight, val_rate, chance)
    po.room_a, po.room_b = room_a, room_b
    po.div_a = div_a
    po.n_clock_removed, po.tsd_removed = len(rej), rej_tsd
    return po


# ---------------------------------------------------------------------------------------------------------------------
# Alignment of ortholog pairs (edlib): divergence, site projection, self-outgroup ABBA/BABA
# ---------------------------------------------------------------------------------------------------------------------
_RCT = bytes.maketrans(b"ACGT", b"TGCA")


def _rc(s):
    return s.translate(_RCT)[::-1]


def _cigar_map(cig, la):
    """Map x position -> y position (or -1) from an edlib extended CIGAR (query=x, target=y)."""
    m = np.full(la, -1, np.int64)
    xi = yi = 0
    for n, op in re.findall(r"(\d+)([=XIDM])", cig):
        n = int(n)
        if op in "=XM":
            m[xi:xi + n] = np.arange(yi, yi + n)
            xi += n
            yi += n
        elif op == "I":      # insertion in query (x) relative to target
            xi += n
        else:                # 'D': deletion from query = extra target bases
            yi += n
    return m


def _align(x, y, path=False):
    import edlib
    r = edlib.align(x, y, mode="NW", task="path" if path else "distance")
    return r


def _orient(x, y, sx, sy):
    """y in x's orientation: stranded records share element orientation; else the better of the two."""
    if sx != "." and sy != ".":
        return y
    import edlib
    k = min(len(x), len(y), 3000)
    d1 = edlib.align(x[:k], y[:k + 200], mode="HW")["editDistance"]
    yr = _rc(y)
    d2 = edlib.align(x[:k], yr[:k + 200], mode="HW")["editDistance"]
    return yr if d2 < d1 else y


def _pair_job(chunk):
    """Per pair: whole-record aligned sites, mismatches, gap columns, and the same over x's LTRs (like-for-like with
    the LTR-LTR K2P clock; 0 sites when x has no LTR bounds)."""
    la, lb = _G["la"], _G["lb"]
    out = np.zeros((len(chunk), 5), np.int64)
    for n, (i, j) in enumerate(chunk):
        x = la.record(int(i))
        y = _orient(x, lb.record(int(j)), la.strand[i], lb.strand[j])
        if not x or not y or min(len(x), len(y)) / max(len(x), len(y)) < MIN_ALN_FRAC:
            continue
        cig = _align(x, y, path=True)["cigar"] or ""
        m = _cigar_map(cig, len(x))
        X = np.frombuffer(x, np.uint8)
        Y = np.frombuffer(y, np.uint8)
        ok = m >= 0
        diff = np.zeros(len(x), bool)
        diff[ok] = X[ok] != Y[m[ok]]
        gp = sum(int(v) for v in re.findall(r"(\d+)[ID]", cig))
        out[n, :3] = (int(ok.sum()), int(diff.sum()), gp)
        bnd = _ltr_bounds(la, int(i), len(x))
        if bnd is not None:
            lt = np.zeros(len(x), bool)
            lt[bnd[0][0]:bnd[0][1]] = True
            lt[bnd[1][0]:bnd[1][1]] = True
            out[n, 3] = int((ok & lt).sum())
            out[n, 4] = int((diff & lt).sum())
    return out


def pool_map(fn, chunks, threads):
    if threads <= 1 or len(chunks) <= 1:
        return [fn(c) for c in chunks]
    with get_context("fork").Pool(threads) as p:
        return p.map(fn, chunks)


def align_pairs(la, lb, ia, ib, threads):
    """(sites, mismatches, gaps) for record pairs ia[k] of la with ib[k] of lb."""
    if len(ia) == 0:
        return np.zeros((0, 5), np.int64)
    _G["la"], _G["lb"] = la, lb
    pairs = np.stack([ia, ib], 1)
    chunks = np.array_split(pairs, max(1, min(len(pairs) // 200, 32 * max(threads, 1))))
    first = _pair_job(chunks[0])
    rest = pool_map(_pair_job, chunks[1:], threads) if len(chunks) > 1 else []
    return np.concatenate([first] + rest)


def _ltr_bounds(lib, i, L):
    """Record-end LTRs (stripped coordinates): ltr5_len = genome-left LTR on both strands; minus-strand records are
    reverse complements and start with the genome-right LTR (ltrharvest_phasing10 v10.1 rule)."""
    n5, n3 = int(lib.l5[i]), int(lib.l3[i])
    if n5 <= 0 or n3 <= 0:
        return None
    first, last = (n3, n5) if lib.strand[i] == "-" else (n5, n3)
    if first + last > L:
        return None
    return (0, first), (L - last, L)


def _k2p(sites, ts, tv):
    if sites <= 0:
        return np.nan, np.nan
    P, Q = ts / sites, tv / sites
    a, b = 1 - 2 * P - Q, 1 - 2 * Q
    if a <= 0 or b <= 0:
        return np.nan, np.nan
    d = -0.5 * math.log(a) - 0.25 * math.log(b)
    c1, c2 = 1 / a, 0.5 * (1 / a + 1 / b)
    var = max((c1 * c1 * P + c2 * c2 * Q - (c1 * P + c2 * Q) ** 2) / sites, 0)
    return d, math.sqrt(var)


_TS = {(65, 71), (71, 65), (67, 84), (84, 67)}


def _triple_job(chunk):
    """Per ortholog triple (donor d, recipient r, sister s): both sisters are projected onto the DONOR's record, so
    alignment noise affects r and s alike (projecting onto one sister would make it look closer to the donor).
    Columns: sites aligned in all three, r-d mismatches, s-d mismatches, r-s mismatches, then ABBA, BABA, BBAA at
    LTR sites polarized by the donor element's other LTR (outgroup allele = the other-LTR base, equal in all three)."""
    ld, lr, ls = _G["ld"], _G["lr"], _G["ls"]
    out = np.zeros((len(chunk), 7), np.int64)
    for n, (k, i, j) in enumerate(chunk):
        x = ld.record(int(k))
        if not x:
            continue
        y = _orient(x, lr.record(int(i)), ld.strand[k], lr.strand[i])
        z = _orient(x, ls.record(int(j)), ld.strand[k], ls.strand[j])
        if not y or not z:
            continue
        if min(len(x), len(y), len(z)) / max(len(x), len(y), len(z)) < MIN_ALN_FRAC:
            continue
        my = _cigar_map(_align(x, y, True)["cigar"] or "", len(x))
        mz = _cigar_map(_align(x, z, True)["cigar"] or "", len(x))
        X = np.frombuffer(x, np.uint8)
        Y = np.frombuffer(y, np.uint8)
        Z = np.frombuffer(z, np.uint8)
        ok = (my >= 0) & (mz >= 0)
        if ok.sum() == 0:
            continue
        xs, ys, zs = X[ok], Y[my[ok]], Z[mz[ok]]
        out[n, 0] = ok.sum()
        out[n, 1] = int((ys != xs).sum())
        out[n, 2] = int((zs != xs).sum())
        out[n, 3] = int((ys != zs).sum())
        if not _G["self_ok"][k]:
            continue
        bnd = _ltr_bounds(ld, int(k), len(x))
        if bnd is None:
            continue
        (a0, a1), (b0, b1) = bnd
        la_, lb_ = x[a0:a1], x[b0:b1]
        fwd = _cigar_map(_align(la_, lb_, True)["cigar"] or "", len(la_))
        rev = _cigar_map(_align(lb_, la_, True)["cigar"] or "", len(lb_))
        for p0, p1, q0, mp in ((a0, a1, b0, fwd), (b0, b1, a0, rev)):
            pos = np.arange(p0, p1)
            q = mp[pos - p0]
            g = q >= 0
            pos, q = pos[g], q[g] + q0
            if len(pos) == 0:
                continue
            v = (my[pos] >= 0) & (mz[pos] >= 0) & (my[q] >= 0) & (mz[q] >= 0)
            pos, q = pos[v], q[v]
            d_, r_, s_ = X[pos], Y[my[pos]], Z[mz[pos]]
            o1, o2, o3 = X[q], Y[my[q]], Z[mz[q]]
            og = (o1 == o2) & (o2 == o3)
            d_, r_, s_, o = d_[og], r_[og], s_[og], o1[og]
            out[n, 4] += int(((r_ == d_) & (s_ != d_) & (s_ == o)).sum())
            out[n, 5] += int(((s_ == d_) & (r_ != d_) & (r_ == o)).sum())
            out[n, 6] += int(((r_ == s_) & (d_ != r_) & (d_ == o)).sum())
    return out


def _self_job(chunk):
    lib = _G["lself"]
    out = np.zeros(len(chunk), np.int8)
    for n, i in enumerate(chunk):
        x = lib.record(int(i))
        bnd = _ltr_bounds(lib, int(i), len(x))
        if bnd is None or not np.isfinite(lib.k2p[i]):
            continue
        (a0, a1), (b0, b1) = bnd
        r = _align(x[a0:a1], x[b0:b1], True)
        cig = r["cigar"] or ""
        mp = _cigar_map(cig, a1 - a0)
        X = np.frombuffer(x, np.uint8)
        ok = mp >= 0
        p, q = X[a0:a1][ok], X[b0:b1][mp[ok]]
        diff = p != q
        ts = sum((int(u), int(v)) in _TS for u, v in zip(p[diff], q[diff]))
        tv = int(diff.sum()) - ts
        d, se = _k2p(int(ok.sum()), ts, tv)
        if not np.isfinite(d):
            continue
        if abs(d - lib.k2p[i]) <= max(SELF_Z * se, 1.0 / max(ok.sum(), 1)):
            out[n] = 1
    return out


def self_ltr_ok(lib, idx, threads):
    """1 where the record-end LTRs reproduce the annotated K2P (usable as self-outgroup)."""
    ok = np.zeros(lib.n, np.int8)
    if len(idx) == 0:
        return ok
    _G["lself"] = lib
    chunks = np.array_split(np.asarray(idx), max(1, min(len(idx) // 200, 32 * max(threads, 1))))
    first = _self_job(chunks[0])
    res = np.concatenate([first] + (pool_map(_self_job, chunks[1:], threads) if len(chunks) > 1 else []))
    ok[np.asarray(idx)] = res
    return ok


# ---------------------------------------------------------------------------------------------------------------------
# Statistics
# ---------------------------------------------------------------------------------------------------------------------
def jackknife(num_a, num_b, blocks):
    """D = (sum a - sum b)/(sum a + sum b) with delete-one-block jackknife SE."""
    num_a = np.asarray(num_a, float)
    num_b = np.asarray(num_b, float)
    ub, inv = np.unique(blocks, return_inverse=True)
    A = np.bincount(inv, num_a, len(ub))
    B = np.bincount(inv, num_b, len(ub))
    sa, sb = A.sum(), B.sum()
    if sa + sb == 0:
        return dict(D=np.nan, SE=np.nan, Z=np.nan, nA=0, nB=0, nblocks=len(ub))
    D = (sa - sb) / (sa + sb)
    m = len(ub)
    if m < 3:
        return dict(D=D, SE=np.nan, Z=np.nan, nA=sa, nB=sb, nblocks=m)
    den = (sa + sb) - (A + B)
    with np.errstate(invalid="ignore", divide="ignore"):
        jk = ((sa - A) - (sb - B)) / den
    jk = jk[np.isfinite(jk)]
    se = math.sqrt((len(jk) - 1) / len(jk) * ((jk - jk.mean()) ** 2).sum())
    return dict(D=D, SE=se, Z=D / se if se > 0 else np.nan, nA=sa, nB=sb, nblocks=m)


def block_ids(lib, idx):
    return np.array([f"{c}:{p // BLOCK_BP}" for c, p in zip(lib.chrom[idx], lib.mid[idx])], object)


def set_block_size(libs):
    """5 Mb, or 1/100 of the smallest genome's placed span (sum over sequences of the last element end)."""
    global BLOCK_BP
    spans = []
    for l in libs.values():
        ends = {}
        for c, e in zip(l.chrom, l.end):
            ends[c] = max(ends.get(c, 0), int(e))
        spans.append(sum(ends.values()))
    BLOCK_BP = int(min(5_000_000, max(min(spans) // 100, 10_000)))
    return BLOCK_BP


# ---------------------------------------------------------------------------------------------------------------------
# HMM along chromosomes (2 states: 0 = sister-like, 1 = donor-like)
# ---------------------------------------------------------------------------------------------------------------------
@njit(cache=True)
def _fb_cat(pos, cat, starts, pi, lam, e0, e1):
    """Forward-backward with categorical emissions (cat < 0: missing, emission 1). Returns posterior P(state1),
    log-likelihood, and expected category counts under state 1 and state 0."""
    n = len(pos)
    K = len(e0)
    post = np.zeros(n)
    c1 = np.zeros(K)
    c0 = np.zeros(K)
    ll = 0.0
    for c in range(len(starts) - 1):
        s0, s1 = starts[c], starts[c + 1]
        m = s1 - s0
        if m == 0:
            continue
        fa = np.zeros((m, 2))
        sc = np.zeros(m)
        for t in range(m):
            k = cat[s0 + t]
            em0 = e0[k] if k >= 0 else 1.0
            em1 = e1[k] if k >= 0 else 1.0
            if t == 0:
                a0 = 1 - pi
                a1 = pi
            else:
                dist = max(pos[s0 + t] - pos[s0 + t - 1], 0)
                q = math.exp(-lam * dist)
                p01 = pi * (1 - q)
                p10 = (1 - pi) * (1 - q)
                a0 = fa[t - 1, 0] * (1 - p01) + fa[t - 1, 1] * p10
                a1 = fa[t - 1, 0] * p01 + fa[t - 1, 1] * (1 - p10)
            fa[t, 0] = a0 * em0
            fa[t, 1] = a1 * em1
            sc[t] = fa[t, 0] + fa[t, 1]
            fa[t, 0] /= sc[t]
            fa[t, 1] /= sc[t]
            ll += math.log(sc[t])
        b0 = 1.0
        b1 = 1.0
        for t in range(m - 1, -1, -1):
            if t < m - 1:
                dist = max(pos[s0 + t + 1] - pos[s0 + t], 0)
                q = math.exp(-lam * dist)
                p01 = pi * (1 - q)
                p10 = (1 - pi) * (1 - q)
                k = cat[s0 + t + 1]
                em0 = e0[k] if k >= 0 else 1.0
                em1 = e1[k] if k >= 0 else 1.0
                nb0 = (1 - p01) * em0 * b0 + p01 * em1 * b1
                nb1 = p10 * em0 * b0 + (1 - p10) * em1 * b1
                ss = nb0 + nb1
                b0 = nb0 / ss
                b1 = nb1 / ss
            g0 = fa[t, 0] * b0
            g1 = fa[t, 1] * b1
            g = g1 / (g0 + g1)
            post[s0 + t] = g
            k = cat[s0 + t]
            if k >= 0:
                c1[k] += g
                c0[k] += 1 - g
    return post, ll, c1, c0


def fit_hmm_cat(pos, cat, starts, e0, e1, iters=100):
    """Baum-Welch for a two-state HMM with categorical emissions (both states free) along chromosomes; distance-
    dependent switching with a fitted mean tract length (grid) and donor-like fraction pi <= PI_MAX.
    Returns pi, L, e0, e1, posterior, loglik."""
    pi, L, ll_old = 0.1, 1e5, -np.inf
    for it in range(iters):
        best = None
        for Lc in HMM_L_GRID:
            post, ll, c1, c0 = _fb_cat(pos, cat, starts, pi, 1.0 / Lc, e0, e1)
            if best is None or ll > best[1]:
                best = (Lc, ll, post, c1, c0)
        L, ll, post, c1, c0 = best
        e1 = (c1 + 0.5) / (c1 + 0.5).sum()
        e0 = (c0 + 0.5) / (c0 + 0.5).sum()
        pi = float(np.clip(post[cat >= 0].mean(), 1e-4, PI_MAX))
        if abs(ll - ll_old) < 1e-7 * abs(ll):
            break
        ll_old = ll
    post, ll, c1, c0 = _fb_cat(pos, cat, starts, pi, 1.0 / L, e0, e1)
    return pi, L, e0, e1, post, ll


CATS = ["near_donor", "near_sister", "near_both", "donor_only", "sister_only", "shared", "private"]
# Painting HMMs use only classes that are exchangeable between sisters without gene flow (shared, private and
# near_both are missing data: private insertions reflect each lineage's own TE activity and annotation).
#   ancestry: toward the donor (near_donor, donor_only) or the sister (near_sister, sister_only)
#   recent:   near-identity only (coalescence younger than 95% of sister-donor pairs; lineage sorting creates it
#             equally for both sisters, so only the difference between them is evidence of gene flow)
HMM_MODES = {
    "ancestry": (np.array([0, 2, -1, 1, 3, -1, -1], np.int64), ["near_donor", "donor_only", "near_sister", "sister_only"]),
    "recent": (np.array([0, 1, -1, -1, -1, -1, -1], np.int64), ["near_donor", "near_sister"]),
}


def tracts_from_post(chrom, start, end, post, pi=None, thr=0.5):
    """Runs of elements with posterior > 0.5 and (given the prior pi) posterior odds >= BF_TRACT x prior odds."""
    out = []
    n = len(post)
    if pi is not None:
        prior_odds = pi / (1 - pi)
        po = post / np.maximum(1 - post, 1e-12)
        on = (post > thr) & (po >= BF_TRACT * prior_odds)
    else:
        on = post > thr
    i = 0
    while i < n:
        if on[i]:
            j = i
            while j + 1 < n and on[j + 1] and chrom[j + 1] == chrom[i]:
                j += 1
            out.append((chrom[i], int(start[i]), int(end[j]), j - i + 1, float(post[i:j + 1].mean()),
                        float(post[i:j + 1].sum())))
            i = j + 1
        else:
            i += 1
    return out


# ---------------------------------------------------------------------------------------------------------------------
# Trio analysis
# ---------------------------------------------------------------------------------------------------------------------
def kmer_tallies(libs, idx, trio):
    """Per-record single-copy k-mer pattern tallies for each genome of the trio, and the pair-sharing matrix."""
    T = {}
    for x in trio:
        o1, o2 = [y for y in trio if y != x]
        i1 = _merge_idx(idx[x].u, idx[o1].u)
        i2 = _merge_idx(idx[x].u, idx[o2].u)
        T[x] = (o1, o2, _tally_single(idx[x].keys, idx[x].st, i1, idx[o1].st, i2, idx[o2].st, libs[x].n, RBITS))
    share = {}
    for x in trio:
        o1, o2, t = T[x]
        share[frozenset((x, o1))] = int(t[:, 1].sum())
        share[frozenset((x, o2))] = int(t[:, 2].sum())
    return T, share


class Trio:
    def __init__(self, libs, idx, orth, trio, threads, outdir):
        self.libs, self.idx, self.orth, self.threads = libs, idx, orth, threads
        self.out = outdir
        os.makedirs(outdir, exist_ok=True)
        self.rows = []      # stats rows
        self.find = []      # findings lines
        T, share = kmer_tallies(libs, idx, trio)
        pairs = sorted(share.items(), key=lambda kv: -kv[1])
        sis = tuple(sorted(pairs[0][0], key=trio.index))
        don = [x for x in trio if x not in sis][0]
        # D (single-copy k-mers) on donor coordinates: + means the first sister shares more with the donor
        o1, o2, td = T[don]
        a_, b_ = (1, 2) if o1 == sis[0] else (2, 1)
        blk = block_ids(libs[don], np.arange(libs[don].n))
        d = jackknife(td[:, a_], td[:, b_], blk)
        R, S = (sis[0], sis[1]) if d["D"] >= 0 else (sis[1], sis[0])
        if d["D"] < 0:
            a_, b_ = b_, a_
            d = jackknife(td[:, a_], td[:, b_], blk)
        self.R, self.S, self.D = R, S, don
        self.share, self.T = share, T
        self.td_ab = (td[:, a_], td[:, b_])
        self.add("sharing", "single_copy_kmers", **{f"{'+'.join(sorted(k))}": v for k, v in share.items()})
        self.add("D_kmer", "all", **d)
        self.find.append(f"Sister pair (most single-copy k-mers shared): {R} + {S}; third genome: {don}.")
        self.find.append(f"D(single-copy k-mers; {R},{S};{don}) = {d['D']:+.4f} +- {d['SE']:.4f} (Z = {d['Z']:.1f}, "
                         f"{d['nblocks']} blocks of {BLOCK_BP / 1e6:.0f} Mb on {don}).")

    def add(self, test, stratum, **kw):
        self.rows.append(dict(test=test, stratum=stratum, **kw))

    def po(self, a, b):
        """PairOrtho oriented as (a, b)."""
        if (a, b) in self.orth:
            p = self.orth[(a, b)]
            return p.orth_b, p.status_a, p.orth_a, p.status_b, p
        p = self.orth[(b, a)]
        return p.orth_a, p.status_b, p.orth_b, p.status_a, p

    # ---- insertion patterns -----------------------------------------------------------------------------------------
    def patterns(self):
        L, R, S, D = self.libs, self.R, self.S, self.D
        rd, st_rd, dr, st_dr, _ = self.po(R, D)
        sd, st_sd, ds, st_ds, _ = self.po(S, D)
        rs, st_rs, sr, st_sr, _ = self.po(R, S)
        # ABBA: R & D share an insertion, S has the syntenic interval but not the element; BABA mirror.
        # Symmetric resolution: the donor copy must also be absent from the other sister through donor-sister
        # synteny. Otherwise, where one sister's synteny with the donor is incomplete (a distant donor, few
        # anchors), only the other sister's pattern could be counted, biasing D toward it.
        _, st_dr_, _, _, _ = self.po(D, R)
        _, st_ds_, _, _, _ = self.po(D, S)
        abba = np.where((rd >= 0) & (st_rs == 1))[0]
        baba = np.where((sd >= 0) & (st_sr == 1))[0]
        abba = abba[st_ds_[rd[abba]] == 1]
        baba = baba[st_dr_[sd[baba]] == 1]
        # how much of the donor lies inside synteny with each sister: insertion and ortholog tests use only the part
        # resolved in both (heuristic warning levels: < 0.8 jointly resolved, or sisters > 0.1 apart)
        cr, cs = float((st_dr_ > 0).mean()), float((st_ds_ > 0).mean())
        cb = float(((st_dr_ > 0) & (st_ds_ > 0)).mean())
        self.add("donor_resolved", f"{D} elements inside synteny", resolved_R=cr, resolved_S=cs, resolved_both=cb,
                 n=int(L[D].n))
        msg = (f"{D} elements inside synteny with {R}: {cr:.2f}, with {S}: {cs:.2f}, with both: {cb:.2f}.")
        if cb < 0.8 or abs(cr - cs) > 0.1:
            msg += (" WARNING: little or uneven shared synteny (a distant donor or sparse annotation): insertion and "
                    "ortholog tests cover only the jointly resolved part and can be unreliable; rely on D_kmer.")
        self.find.append(msg)
        dA, dB = rd[abba], sd[baba]          # donor copies (common clock and coordinates)
        lD = L[D]
        blk = np.concatenate([block_ids(lD, dA), block_ids(lD, dB)])
        x = np.concatenate([np.ones(len(dA)), np.zeros(len(dB))])
        res = jackknife(x, 1 - x, blk)
        self.add("D_ins", "all", **res)
        self.find.append(f"D(insertions; {R},{S};{D}) = {res['D']:+.4f} +- {res['SE']:.4f} (Z = {res['Z']:.1f}; "
                         f"{int(res['nA'])} {R}+{D} vs {int(res['nB'])} {S}+{D} insertions absent from the third).")
        # strict: absence certain because the syntenic interval is too short to hold the element
        _, _, _, _, p_rs = self.po(R, S)
        room_r = p_rs.room_a if p_rs.a == R else p_rs.room_b
        room_s = p_rs.room_b if p_rs.a == R else p_rs.room_a
        lenR = L[R].end - L[R].start + 1
        lenS = L[S].end - L[S].start + 1
        okA = (room_r[abba] >= 0) & (room_r[abba] < 0.5 * lenR[abba])
        okB = (room_s[baba] >= 0) & (room_s[baba] < 0.5 * lenS[baba])
        bl2 = np.concatenate([block_ids(lD, dA[okA]), block_ids(lD, dB[okB])])
        x2 = np.concatenate([np.ones(okA.sum()), np.zeros(okB.sum())])
        self.add("D_ins", "absence_certain", **jackknife(x2, 1 - x2, bl2))
        # age strata (donor copy's LTR-LTR K2P: one clock for both patterns)
        kA, kB = lD.k2p[dA], lD.k2p[dB]
        edges = [0, 1e-9, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1]
        labs = ["0", "(0,0.002]", "(0.002,0.005]", "(0.005,0.01]", "(0.01,0.02]", "(0.02,0.05]", "(0.05,0.1]", ">0.1"]
        cA = np.digitize(kA, edges[1:], right=True)
        cB = np.digitize(kB, edges[1:], right=True)
        for c, lab in enumerate(labs):
            m1, m2 = cA == c, cB == c
            if m1.sum() + m2.sum() < 10:
                continue
            bl = np.concatenate([block_ids(lD, dA[m1]), block_ids(lD, dB[m2])])
            xx = np.concatenate([np.ones(m1.sum()), np.zeros(m2.sum())])
            self.add("D_ins_by_age", f"K2P {lab}", **jackknife(xx, 1 - xx, bl))
        # per chromosome of the donor
        for c in sorted(set(lD.chrom[dA]) | set(lD.chrom[dB]), key=_chrom_key):
            m1, m2 = lD.chrom[dA] == c, lD.chrom[dB] == c
            if m1.sum() + m2.sum() < 20:
                continue
            bl = np.concatenate([block_ids(lD, dA[m1]), block_ids(lD, dB[m2])])
            xx = np.concatenate([np.ones(m1.sum()), np.zeros(m2.sum())])
            self.add("D_ins_by_chrom", c, **jackknife(xx, 1 - xx, bl))
        # annotation-completeness diagnostic: the donor's old insertions (K2P above its 75th percentile, long before
        # any plausible split) were inherited by both sisters and lost symmetrically since, so the share present in
        # each sister estimates relative completeness. One-sided dropout biases D_kmer and D_ins toward the more
        # complete sister; D3 and D_self are robust to moderate dropout (simulations).
        k_old = np.nanquantile(lD.k2p, 0.75) if np.isfinite(lD.k2p).any() else np.inf
        mo = (lD.k2p > k_old) & (st_dr_ > 0) & (st_ds_ > 0)
        if mo.sum() > 100:
            bl = block_ids(lD, np.where(mo)[0])
            ub, inv = np.unique(bl, return_inverse=True)
            nr = np.bincount(inv, (st_dr_[mo] == 2).astype(float), len(ub))
            ns = np.bincount(inv, (st_ds_[mo] == 2).astype(float), len(ub))
            ratio = nr.sum() / max(ns.sum(), 1)
            jk = np.array([(nr.sum() - nr[i]) / max(ns.sum() - ns[i], 1) for i in range(len(ub))])
            se = math.sqrt((len(jk) - 1) / len(jk) * ((jk - jk.mean()) ** 2).sum())
            self.add("completeness_ratio", f"{R}/{S} on {D} K2P>{k_old:.3g}", ratio=ratio, SE=se, n=int(mo.sum()))
            flag = abs(ratio - 1) > 2 * se
            self.find.append(f"Annotation completeness check: {D}'s old insertions (K2P > {k_old:.3g}) present in {R} "
                             f"vs {S}: ratio {ratio:.3f} +- {se:.3f}" + (
                                 ". Differs from 1: one-sided annotation dropout (or old polymorphisms carried by "
                                 "gene flow) can bias D_kmer and D_ins; D3 and D_self are robust to moderate dropout."
                                 if flag else "."))
        # recipient-centric, model-free shares per recipient chromosome: of R's k-mers / insertions shared with exactly
        # one other genome, the fraction shared with the donor rather than the sister
        o1, o2, tr_ = self.T[R]
        ci, cs = (1, 2) if o1 == D else (2, 1)
        lR = L[R]
        rd_only = (rd >= 0) & (st_rs == 1)
        rs_only = (rs >= 0) & (st_rd == 1)
        for c in sorted(set(lR.chrom), key=_chrom_key):
            m = lR.chrom == c
            kd, ks = tr_[m, ci].sum(), tr_[m, cs].sum()
            nd, ns = int(rd_only[m].sum()), int(rs_only[m].sum())
            if kd + ks < 1000:
                continue
            self.add("R_share_D_by_chrom", c, kmer_share=kd / (kd + ks), kmers_D=int(kd), kmers_S=int(ks),
                     ins_share=nd / max(nd + ns, 1), ins_D=nd, ins_S=ns)
        # D_kmer per donor chromosome
        a_, b_ = self.td_ab
        blk_d = block_ids(lD, np.arange(lD.n))
        for c in sorted(set(lD.chrom), key=_chrom_key):
            m = lD.chrom == c
            if a_[m].sum() + b_[m].sum() < 1000:
                continue
            self.add("D_kmer_by_chrom", c, **jackknife(a_[m], b_[m], blk_d[m]))
        self.pat = dict(abba=abba, baba=baba)

    # ---- divergence of orthologs, identity spectrum, triples -------------------------------------------------------
    def divergences(self):
        L, R, S, D = self.libs, self.R, self.S, self.D
        self.div = {}
        for a, b in ((R, D), (S, D), (R, S)):
            if (a, b) in self.orth:
                self.div[(a, b)] = self.orth[(a, b)].div_a
            else:                                   # stored on (b, a): re-index by records of a
                p = self.orth[(b, a)]
                d = np.full(L[a].n, np.nan)
                m = p.orth_b >= 0
                d[p.orth_b[m]] = p.div_a[m]
                self.div[(a, b)] = d
        # D-side views: divergence indexed by donor/other records
        dRD, dSD = self.div[(R, D)], self.div[(S, D)]
        # identity spectrum: target R-D vs mirror S-D, on donor copies resolved in both sisters (symmetric
        # coverage, as for D_ins)
        bins = np.array([0, 1e-9, 2.5e-4, 5e-4, 1e-3, 2e-3, 4e-3, 8e-3, 1.6e-2, 3.2e-2, 6.4e-2, 1.0])
        rd_, _, _, _, _ = self.po(R, D)
        sd_, _, _, _, _ = self.po(S, D)
        _, st_dr_, _, _, _ = self.po(D, R)
        _, st_ds_, _, _, _ = self.po(D, S)
        okt = np.isfinite(dRD) & (rd_ >= 0)
        okt[okt] = st_ds_[rd_[okt]] > 0
        okm = np.isfinite(dSD) & (sd_ >= 0)
        okm[okm] = st_dr_[sd_[okm]] > 0
        t, m = dRD[okt], dSD[okm]
        med = np.median(np.concatenate([t, m]))
        cal = (m > med).sum() / max((t > med).sum(), 1)
        ht, _ = np.histogram(t, bins)
        hm, _ = np.histogram(m, bins)
        for i in range(len(bins) - 1):
            r = ht[i] * cal / hm[i] if hm[i] else np.nan
            self.add("identity_spectrum", f"d in [{bins[i]:.2g},{bins[i + 1]:.2g})", n_target=int(ht[i]),
                     n_mirror=int(hm[i]), ratio_calibrated=r)
        excess = np.clip(ht - hm / cal, 0, None).sum()
        f_low = excess / max(len(t), 1)
        self.f_low = f_low
        self.add("f_lower_bound", "identity_spectrum", f=f_low, n_target=len(t), n_mirror=len(m), calibration=cal)
        lo = (t < 2e-3).sum(), (m < 2e-3).sum() / cal
        self.find.append(f"Identity spectrum: {R}-{D} vs mirror {S}-{D} orthologs (equal totals in the deep half): "
                         f"ratio at d >= {med:.3g} = 1 by calibration; at d < 0.002: {lo[0]} vs {lo[1]:.0f} "
                         f"({lo[0] / max(lo[1], 1):.2f}x). Excess = admixture-fraction lower bound {f_low:.3f} "
                         f"(fraction of {R}'s {D}-orthologs).")
        # triples (consistent orthology across the three pairs)
        rd, _, _, _, _ = self.po(R, D)
        rs, _, _, _, _ = self.po(R, S)
        sd, _, _, _, _ = self.po(S, D)
        tri = np.where((rd >= 0) & (rs >= 0))[0]
        tri = tri[sd[rs[tri]] == rd[tri]]
        self.tri = tri
        lr = L[R]
        _G["self_ok"] = self_ltr_ok(L[D], rd[tri], self.threads)
        _G["lr"], _G["ls"], _G["ld"] = L[R], L[S], L[D]
        trip = np.stack([rd[tri], tri, rs[tri]], 1)       # (donor, recipient, sister): donor record is the frame
        t0 = time.time()
        chunks = np.array_split(trip, max(1, min(len(trip) // 100, 32 * max(self.threads, 1))))
        first = _triple_job(chunks[0]) if len(trip) else np.zeros((0, 7), np.int64)
        res = np.concatenate([first] + (pool_map(_triple_job, chunks[1:], self.threads) if len(chunks) > 1 else []))
        log(f"{len(tri):,} ortholog triples aligned ({time.time() - t0:.0f}s); self-outgroup usable for "
            f"{int(_G['self_ok'][rd[tri]].sum()):,}", True)
        self.trires = res
        blk = block_ids(lr, tri)
        d3 = jackknife(res[:, 1], res[:, 2], blk)       # (d_RD - d_SD)/(d_RD + d_SD) -> negative = R closer to D
        self.add("D3_triples", "all", D=-d3["D"], SE=d3["SE"], Z=-d3["Z"] if np.isfinite(d3["Z"]) else np.nan,
                 nA=d3["nB"], nB=d3["nA"], nblocks=d3["nblocks"])
        ds = jackknife(res[:, 4], res[:, 5], blk)
        self.add("D_self_outgroup", "LTR sites", **ds)
        self.find.append(f"D3 (ortholog triples, divergence; sign as D): {-d3['D']:+.4f} (Z = "
                         f"{-d3['Z'] if np.isfinite(d3['Z']) else float('nan'):.1f}; {len(tri):,} triples). "
                         f"D(self-outgroup: sister LTR polarizes) = {ds['D']:+.4f} (Z = {ds['Z']:.1f}; "
                         f"ABBA {int(ds['nA'])}, BABA {int(ds['nB'])}, BBAA {int(res[:, 6].sum())}).")

    # ---- local ancestry ----------------------------------------------------------------------------------------------
    def categories(self, X, Y, D, thr):
        """Per-element evidence class of focal X (sister Y, donor D); -1 = orthology unresolved in Y or D.
        'near' = closer than thr = the 5th percentile of the less-admixed sister's divergence to the donor (one
        threshold for target and decoy, so both genomes' classes mean the same thing)."""
        L = self.libs
        dXD = _flip(self, X, D)
        dXY = _flip(self, X, Y)
        _, st_xd, _, _, _ = self.po(X, D)
        _, st_xy, _, _, _ = self.po(X, Y)
        t1 = t2 = thr
        nD = np.isfinite(dXD) & (dXD < t1)
        nY = np.isfinite(dXY) & (dXY < t2)
        pD, pY = st_xd == 2, st_xy == 2
        cat = np.full(L[X].n, -1, np.int64)
        res = (st_xd > 0) & (st_xy > 0)
        cat[res & nD & ~nY] = 0
        cat[res & nY & ~nD] = 1
        cat[res & nY & nD] = 2
        rest = res & ~nD & ~nY
        cat[rest & pD & ~pY] = 3
        cat[rest & pY & ~pD] = 4
        cat[rest & pY & pD] = 5
        cat[rest & ~pY & ~pD] = 6
        return cat

    def _hmm(self, X, Y, mode, thr):
        """One painting HMM. mode 'ancestry': informative classes toward donor or sister (genealogical closeness;
        includes lineage sorting, so useful in aggregate); mode 'recent': near-identity classes only (shared ancestry
        younger than 95% of sister-donor pairs; lineage sorting creates it equally for both sisters, which the decoy
        measures). Tract FDR by target-decoy: the
        fitted model applied unchanged to the sister's own classes calls the tracts expected by chance."""
        L, D = self.libs, self.D
        cmap, names = HMM_MODES[mode]
        lib, ly = L[X], L[Y]
        o = np.lexsort((lib.mid, lib.chrom.astype(str)))
        chrom, pos = lib.chrom[o], lib.mid[o].astype(np.float64)
        starts = np.r_[0, np.where(chrom[1:] != chrom[:-1])[0] + 1, len(o)].astype(np.int64)
        cat = self.categories(X, Y, D, thr)
        catY = self.categories(Y, X, D, thr)
        K = len(names)
        c = np.where(cat[o] >= 0, cmap[np.maximum(cat[o], 0)], -1)
        cy_all = np.where(catY >= 0, cmap[np.maximum(catY, 0)], -1)
        e0 = np.bincount(cy_all[cy_all >= 0], minlength=K).astype(float) + 1
        e0 /= e0.sum()
        e1 = e0 * np.array([5.0 if "donor" in nm else 0.2 for nm in names])
        e1 /= e1.sum()
        pi, Lh, e0, e1, post, ll = fit_hmm_cat(pos, c, starts, e0, e1)
        idn = [i for i, nm in enumerate(names) if "near_donor" in nm]
        isi = [i for i, nm in enumerate(names) if "near_sister" in nm]
        donor_state = bool(all(e1[i] > e0[i] for i in idn) and all(e1[i] < e0[i] for i in isi))
        tr = tracts_from_post(chrom, lib.start[o], lib.end[o], post, pi) if donor_state else []
        oy = np.lexsort((ly.mid, ly.chrom.astype(str)))
        chy, posy = ly.chrom[oy], ly.mid[oy].astype(np.float64)
        sty = np.r_[0, np.where(chy[1:] != chy[:-1])[0] + 1, len(oy)].astype(np.int64)
        py, _, _, _ = _fb_cat(posy, cy_all[oy], sty, pi, 1.0 / Lh, e0, e1)
        dec = tracts_from_post(chy, ly.start[oy], ly.end[oy], py, pi) if donor_state else []
        scale = lib.n / max(ly.n, 1)
        null_scores = np.sort(np.array([t[5] for t in dec]))
        scores = np.array([t[5] for t in tr])
        obs = np.sort(scores)
        q = np.ones(len(tr))
        if len(tr):
            # finite-sample target-decoy estimate with the +1 correction (as in knockoff+ / target-decoy
            # competition): a lone target above every decoy is not significant
            raw = np.array([((len(null_scores) - np.searchsorted(null_scores, x)) * scale + 1) /
                            max(len(obs) - np.searchsorted(obs, x), 1) for x in scores])
            order = np.argsort(-scores)
            q[order] = np.minimum(1.0, np.minimum.accumulate(raw[order][::-1])[::-1])
        # per-tract empirical p-value against the decoy tract scores (useful when there are too few tracts for any
        # set-level FDR to fall below 1/n, e.g. a handful of Mb-scale tracts after very recent admixture)
        pv = np.array([(1 + len(null_scores) - np.searchsorted(null_scores, x)) / (1 + len(null_scores))
                       for x in scores]) if len(tr) else np.array([])
        frac_post = float(np.average(post, weights=(lib.end[o] - lib.start[o] + 1)))
        frac_dec = float(np.average(py, weights=(ly.end[oy] - ly.start[oy] + 1)))
        nq = int((q <= 0.05).sum())
        self.add(f"hmm_{mode}", X, sister=Y, donor=D, pi=pi, mean_tract_bp=Lh, loglik=ll, n_tracts=len(tr),
                 n_decoy_tracts=len(dec), n_tracts_q05=nq, posterior_mean=frac_post, decoy_posterior_mean=frac_dec,
                 excess_over_decoy=frac_post - frac_dec, near_threshold=f"{thr:.4g}", classes=",".join(names),
                 e1=",".join(f"{x:.3g}" for x in e1), e0=",".join(f"{x:.3g}" for x in e0), donor_state=donor_state)
        label = {"ancestry": "Ancestry painting", "recent": "Recent shared ancestry"}[mode]
        if not donor_state:
            self.find.append(f"{label} of {X}: no {D}-like state (second HMM state not enriched for near-identical "
                             f"{D} orthologs): no tracts.")
        self.find.append(f"{label} of {X} (sister {Y}, donor {D}): {D}-like posterior mean {frac_post:.3f} vs "
                         f"{frac_dec:.3f} in the decoy {Y} (excess {frac_post - frac_dec:+.3f}); mean tract "
                         f"{Lh / 1e3:,.0f} kb; {len(tr)} tracts ({len(dec)} decoy tracts), {nq} at FDR <= 0.05.")
        return dict(o=o, post=post, cat=cat, tr=tr, q=q, p=pv, dec=dec, pi=pi, L=Lh)

    def paint(self, X, Y):
        L, D = self.libs, self.D
        lib = L[X]
        dSD = _flip(self, self.S, D)
        thr = float(np.nanquantile(dSD, 0.05)) if np.isfinite(dSD).any() else 0.0
        res = {m: self._hmm(X, Y, m, thr) for m in ("ancestry", "recent")}
        o = res["ancestry"]["o"]
        cat = res["ancestry"]["cat"]
        dXD, dXY = _flip(self, X, D), _flip(self, X, Y)
        xd, st_xd, _, _, _ = self.po(X, D)
        xy, st_xy, _, _, _ = self.po(X, Y)
        SN = {2: "present", 1: "absent", 0: "unresolved"}
        with open(os.path.join(self.out, f"elements.{X}.tsv"), "w") as fo:
            fo.write(f"chrom\tstart\tend\tname\tk2p\tin_{D}\tortholog_{D}\tdiv_{D}\tin_{Y}\tortholog_{Y}\tdiv_{Y}\t"
                     f"class\tpost_ancestry_{D}\tpost_recent_{D}\n")
            pa, pr = res["ancestry"]["post"], res["recent"]["post"]
            for k, i in enumerate(o):
                oD = L[D].names[xd[i]] if xd[i] >= 0 else "."
                oY = L[Y].names[xy[i]] if xy[i] >= 0 else "."
                fo.write(f"{lib.chrom[i]}\t{lib.start[i]}\t{lib.end[i]}\t{lib.names[i]}\t{lib.k2p[i]:.5g}\t"
                         f"{SN[int(st_xd[i])]}\t{oD}\t{dXD[i]:.5g}\t{SN[int(st_xy[i])]}\t{oY}\t{dXY[i]:.5g}\t"
                         f"{CATS[cat[i]] if cat[i] >= 0 else 'unresolved'}\t{pa[k]:.4f}\t{pr[k]:.4f}\n")
        for mode, fn in (("recent", f"tracts.{X}.bed"), ("ancestry", f"ancestry.{X}.bed")):
            r = res[mode]
            with open(os.path.join(self.out, fn), "w") as fo:
                fo.write("#chrom\tstart0\tend\tname\tscore\tn_elements\tmean_post\tsum_post\tq\tp_decoy\n")
                for t, qq, pp in zip(r["tr"], r["q"], r["p"]):
                    conf = "high" if qq <= 0.05 else ("medium" if qq <= 0.2 else "low")
                    fo.write(f"{t[0]}\t{t[1] - 1}\t{t[2]}\t{D}-{mode}:{conf}\t{min(1000, int(1000 * t[4]))}\t"
                             f"{t[3]}\t{t[4]:.3f}\t{t[5]:.2f}\t{qq:.3g}\t{pp:.3g}\n")
        with open(os.path.join(self.out, f"decoy_tracts.{Y}.bed"), "w") as fo:
            fo.write("#chrom\tstart0\tend\tname\tscore\tn_elements\tmean_post\tsum_post\n")
            for t in res["recent"]["dec"]:
                fo.write(f"{t[0]}\t{t[1] - 1}\t{t[2]}\tdecoy\t{min(1000, int(1000 * t[4]))}\t{t[3]}\t{t[4]:.3f}\t"
                         f"{t[5]:.2f}\n")
        self.post = getattr(self, "post", {})
        self.post[X] = res

    # ---- admixture fraction with a second donor genome (f4-ratio analogue) ---------------------------------------
    def fratio(self, D2):
        """alpha = [R+D, not S] - [S+D, not R]  /  [D2+D, not S] - [S+D, not D2], counted on the donor's elements whose
        status is resolved in R, S and D2 (insertion patterns; lineage sorting cancels in both). Also the ratio of
        identity-spectrum excesses (R vs S) / (D2 vs S) over the donor's elements. Delete-one-block jackknife."""
        L, R, S, D = self.libs, self.R, self.S, self.D
        _, st_dr, _, _, _ = self.po(D, R)
        _, st_ds, _, _, _ = self.po(D, S)
        _, st_d2, _, _, _ = self.po(D, D2)
        ok = (st_dr > 0) & (st_ds > 0) & (st_d2 > 0)
        xr, xs, x2 = (st_dr == 2), (st_ds == 2), (st_d2 == 2)
        num = (xr & ~xs).astype(float) - (xs & ~xr).astype(float)
        den = (x2 & ~xs).astype(float) - (xs & ~x2).astype(float)
        blk = block_ids(L[D], np.arange(L[D].n))[ok]
        num, den = num[ok], den[ok]
        ub, inv = np.unique(blk, return_inverse=True)
        Nb = np.bincount(inv, num, len(ub))
        Db = np.bincount(inv, den, len(ub))
        a = Nb.sum() / Db.sum() if Db.sum() else np.nan
        jk = np.array([(Nb.sum() - Nb[i]) / (Db.sum() - Db[i]) for i in range(len(ub))])
        se = math.sqrt((len(jk) - 1) / len(jk) * ((jk - jk.mean()) ** 2).sum()) if len(jk) > 2 else np.nan
        self.add("f_ratio_ins", f"second donor {D2}", alpha=a, SE=se, num=Nb.sum(), den=Db.sum(), nblocks=len(ub))
        # identity spectrum ratio on the donor's elements
        dR, dS, d2 = _flip(self, D, R), _flip(self, D, S), _flip(self, D, D2)
        bins = np.array([0, 1e-9, 2.5e-4, 5e-4, 1e-3, 2e-3, 4e-3, 8e-3, 1.6e-2, 3.2e-2, 6.4e-2, 1.0])
        n = L[D].n
        hR = np.histogram(dR[np.isfinite(dR)], bins)[0] / n
        hS = np.histogram(dS[np.isfinite(dS)], bins)[0] / n
        h2 = np.histogram(d2[np.isfinite(d2)], bins)[0] / n
        eR, e2 = np.clip(hR - hS, 0, None).sum(), np.clip(h2 - hS, 0, None).sum()
        self.add("f_ratio_identity", f"second donor {D2}", alpha=eR / e2 if e2 > 0 else np.nan, excess_R=eR,
                 excess_D2=e2)
        self.find.append(f"Admixture fraction of {R} from {D}'s population, with {D2} as a second donor genome: "
                         f"{a:.3f} +- {se:.3f} (insertion patterns), {eR / e2 if e2 > 0 else float('nan'):.3f} "
                         f"(identity-spectrum excess ratio).")

    # ---- inversions --------------------------------------------------------------------------------------------------
    def inversions(self):
        out = []
        for (a, b), p in self.orth.items():
            if a not in (self.R, self.S, self.D) or b not in (self.R, self.S, self.D):
                continue
            by = {}
            for blk in p.blocks:
                by.setdefault((blk["chrom_a"], blk["chrom_b"]), []).append(blk)
            for (ca, cb), bl in by.items():
                w = {1: 0, -1: 0}
                for x in bl:
                    w[x["sign"]] += x["n_anchor"]
                dom = 1 if w[1] >= w[-1] else -1
                tot = w[1] + w[-1]
                if tot < 50:
                    continue
                for x in bl:
                    if x["sign"] != dom:
                        out.append(dict(a=a, b=b, chrom_a=ca, a_start=x["a_start"], a_end=x["a_end"], chrom_b=cb,
                                        b_start=x["b_start"], b_end=x["b_end"], n_anchor=x["n_anchor"],
                                        span_a=x["a_end"] - x["a_start"]))
        out.sort(key=lambda r: -r["n_anchor"])
        with open(os.path.join(self.out, "inversions.tsv"), "w") as fo:
            fo.write("genome_a\tchrom_a\tstart_a\tend_a\tgenome_b\tchrom_b\tstart_b\tend_b\tn_anchor\tspan_a_bp\n")
            for r in out:
                fo.write(f"{r['a']}\t{r['chrom_a']}\t{r['a_start']}\t{r['a_end']}\t{r['b']}\t{r['chrom_b']}\t"
                         f"{r['b_start']}\t{r['b_end']}\t{r['n_anchor']}\t{r['span_a']}\n")
        big = [r for r in out if r["span_a"] >= 1_000_000]
        self.find.append(f"Inverted collinear blocks (>= {CHAIN_MIN} anchors, opposite to the chromosome pair's "
                         f"main orientation): {len(out)}; {len(big)} span >= 1 Mb.")
        return out

    def write(self):
        import csv
        keys = []
        for r in self.rows:
            for k in r:
                if k not in keys:
                    keys.append(k)
        with open(os.path.join(self.out, "stats.tsv"), "w", newline="") as fo:
            w = csv.DictWriter(fo, keys, delimiter="\t", extrasaction="ignore")
            w.writeheader()
            for r in self.rows:
                w.writerow({k: (f"{v:.6g}" if isinstance(v, float) else v) for k, v in r.items()})
        with open(os.path.join(self.out, "findings.txt"), "w") as fo:
            fo.write("\n".join(self.find) + "\n")


def _flip(trio, a, b):
    """Divergence array indexed by records of a (to their orthologs in b), from the trio's alignments or, for a
    genome outside the trio, from the pairwise orthology results."""
    div = getattr(trio, "div", {})
    if (a, b) in div:
        return div[(a, b)]
    if (b, a) in div:
        d_ba = div[(b, a)]
        o_ba, _, _, _, _ = trio.po(b, a)
        out = np.full(trio.libs[a].n, np.nan)
        m = o_ba >= 0
        out[o_ba[m]] = d_ba[m]
        return out
    if (a, b) in trio.orth:
        return trio.orth[(a, b)].div_a
    p = trio.orth[(b, a)]
    out = np.full(trio.libs[a].n, np.nan)
    m = p.orth_b >= 0
    out[p.orth_b[m]] = p.div_a[m]
    return out


def _chrom_key(c):
    m = re.search(r"(\d+)$", str(c))
    return (0, int(m.group(1)), str(c)) if m else (1, 0, str(c))


def write_blocks(orth, outdir):
    with open(os.path.join(outdir, "blocks.tsv"), "w") as fo:
        fo.write("genome_a\tchrom_a\tstart_a\tend_a\tgenome_b\tchrom_b\tstart_b\tend_b\tsign\tn_anchor\n")
        for (a, b), p in orth.items():
            for x in p.blocks:
                fo.write(f"{a}\t{x['chrom_a']}\t{x['a_start']}\t{x['a_end']}\t{b}\t{x['chrom_b']}\t{x['b_start']}\t"
                         f"{x['b_end']}\t{x['sign']}\t{x['n_anchor']}\n")


def write_orthologs(orth, libs, outdir):
    """Per genome pair, both directions, per record: status in the other genome, ortholog name, divergence, TSD match."""
    SN = {2: "present", 1: "absent", 0: "unresolved"}
    for (a, b), p in orth.items():
        div_b = np.full(libs[b].n, np.nan)
        m = p.orth_b >= 0
        div_b[p.orth_b[m]] = p.div_a[m]
        for x, y, ox, sx, dx in ((a, b, p.orth_b, p.status_a, p.div_a), (b, a, p.orth_a, p.status_b, div_b)):
            lx, ly = libs[x], libs[y]
            with gzip.open(os.path.join(outdir, f"orthologs.{x}.{y}.tsv.gz"), "wt") as fo:
                fo.write(f"{x}\tchrom\tstart\tend\tk2p\tstatus_in_{y}\t{y}\tdivergence\tsame_tsd\n")
                for i in range(lx.n):
                    j = int(ox[i])
                    tsd = "." if j < 0 or not lx.tsd[i] or not ly.tsd[j] else ("yes" if lx.tsd[i] == ly.tsd[j] else "no")
                    fo.write(f"{lx.names[i]}\t{lx.chrom[i]}\t{lx.start[i]}\t{lx.end[i]}\t{lx.k2p[i]:.5g}\t"
                             f"{SN[int(sx[i])]}\t{ly.names[j] if j >= 0 else '.'}\t{dx[i]:.5g}\t{tsd}\n")


def main(argv=None):
    global ARGS
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0], formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("--genome", action="append", required=True, metavar="LABEL=LIB",
                    help="one per genome (>= 3): LTRquest output prefix (e.g. run/B73v5_LTRs), or FASTA[,TABLE]\n"
                         "(headers chrom:start-end[#class]; TABLE: seq_id plus any of k2p, tsd, strand, ltr5_len, "
                         "ltr3_len)")
    ap.add_argument("--outdir", required=True, help="output directory")
    ap.add_argument("-t", "--threads", type=int, default=8, help="worker processes for alignment [8]")
    ap.add_argument("--no-figure", action="store_true", help="skip the overview figure of each trio")
    ap.add_argument("-v", "--verbose", action="store_true", help="per-step progress and sanity checks")
    ARGS = ap.parse_args(argv)
    specs = []
    for g in ARGS.genome:
        if "=" not in g:
            sys.exit(f"ERROR: --genome needs LABEL=LIB, got '{g}'")
        lab, sp = g.split("=", 1)
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", lab):
            sys.exit(f"ERROR: genome label '{lab}': use letters, digits, _ . -")
        specs.append((lab, sp))
    if len(specs) < 3 or len({l for l, _ in specs}) != len(specs):
        sys.exit("ERROR: give >= 3 genomes with distinct labels")
    try:
        import edlib  # noqa: F401
        import scipy  # noqa: F401
    except ImportError as e:
        sys.exit(f"ERROR: missing dependency ({e}); see environment.yml")
    os.makedirs(ARGS.outdir, exist_ok=True)
    ARGS_THREADS[0] = ARGS.threads
    t0 = time.time()
    log(f"start: {len(specs)} genomes")
    libs = {lab: load_library(lab, sp) for lab, sp in specs}
    for l in libs.values():
        log(f"{l.label}: {l.n:,} elements, {len(l.seq) / 1e6:,.0f} Mb library, "
            f"K2P known {np.isfinite(l.k2p).mean():.2f}, TSD known {(l.tsd != '').mean():.2f}")
    idx = {lab: Index(l) for lab, l in libs.items()}
    log(f"jackknife block size {set_block_size(libs):,} bp", True)
    labels = [l for l, _ in specs]
    orth = {}
    for i in range(len(labels)):
        for j in range(i + 1, len(labels)):
            a, b = labels[i], labels[j]
            orth[(a, b)] = orthology(libs[a], libs[b], idx[a], idx[b])
    write_blocks(orth, ARGS.outdir)
    write_orthologs(orth, libs, ARGS.outdir)
    from itertools import combinations
    for trio in combinations(labels, 3):
        sub = ARGS.outdir if len(labels) == 3 else os.path.join(ARGS.outdir, "_".join(trio))
        tr = Trio(libs, idx, orth, list(trio), ARGS.threads, sub)
        log(f"trio {trio}: sisters {tr.R},{tr.S}; donor {tr.D}")
        tr.patterns()
        tr.divergences()
        tr.paint(tr.R, tr.S)    # only the recipient: the sister's own classes anchor the sister-like state, which
        #                         is valid only for the less-admixed sister (painting it against R would label any
        #                         difference from an admixed genome as donor-like)
        tr.inversions()
        # a second donor genome must sit on the donor's side of the tree: the donor and it are each other's closest
        # relative among {donor, it, R, S} (most 1:1 orthologs). Requiring only that it share more with the donor
        # than the sisters do picked an admixed member of the sisters' own lineage (maize PT for donor TIL18).
        n_or = {frozenset(k): int((v.orth_b >= 0).sum()) for k, v in orth.items()}
        for g in labels:
            if g in trio:
                continue
            nd = n_or[frozenset((tr.D, g))]
            if all(nd > n_or[frozenset((x, y))] for x in (tr.D, g) for y in (tr.R, tr.S)):
                tr.fratio(g)
        tr.write()
        if ARGS.no_figure:
            continue
        try:
            overview_figure(tr)
        except Exception as e:  # figure failure must not lose the results
            log(f"WARNING: figure failed: {e}")
    log(f"done ({(time.time() - t0) / 60:.1f} min)")


def overview_figure(tr):
    """One overview figure per trio (ltrmix_plot.py, next to this script): overview.png, overview.pdf, and
    overview_numbers.tsv in the trio's output directory."""
    here = os.path.dirname(os.path.abspath(__file__))
    if here not in sys.path:
        sys.path.insert(0, here)
    try:
        import ltrmix_plot
    except ImportError as e:
        log(f"WARNING: no overview figure ({e})")
        return
    ltrmix_plot.overview(tr.out, verbose=ARGS.verbose)


if __name__ == "__main__":
    main()
