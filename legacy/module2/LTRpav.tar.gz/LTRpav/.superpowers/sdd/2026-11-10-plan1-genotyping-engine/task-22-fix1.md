# Task 22 — fix round 1 (FIX_BASE 37857f6)

The task review (opus) re-derived your truth rows independently on the seed-1 run: every existing row is correct,
outputs are consistent and byte-reproducible. Fix the following, then append a "Fix round 1" section to
task-22-report.md and commit (plain subject, no trailers, existing git identity).

## Controller rulings for this round
- Accepted as built: `invert` moves each boundary REFINE_PAD clear of every element that still spans sequence
  (stricter than "nearest free position"; keeps inversion edges off element ends).
- Site test, ruling on review Minor 1(a): the site is the window W = [Lf, TSD ids, Rf] of shareable ids (w each
  side). E if Y holds W's ids in order (forward or reversed) with nothing but point-noise between consecutive ids;
  O if they are in order but Y-only (non-noise) sequence sits anywhere between the first and the last id of W (a
  Y-specific insertion at the site, inside a flank included); D otherwise (an id of W missing, out of order, or
  separated by sequence X also holds). Reason: W is the site by definition (w = 2L), and the brief's O is
  "a Y-specific insertion there". An insertion 1-3 bp from the target is therefore O, not D.

## Fixes
1. (Important 1) Death rule on own LTR bases. In `delete`, an element dies when either LTR's own-base length (the
   LTR span minus the spans of nested elements wholly inside it that still span sequence, dead remains included:
   the same own-base definition the truth's coverage uses; share one helper) falls below COV_PRESENT of its
   pre-edit own-base length. Test with the reviewer's three cases (N nested in H's left LTR; in B: `solo("N")`;
   N deleted with a 50-bp flank; a 40% partial deletion inside N): H stays alive, appears in B's truth and B.gff3,
   and H is P in both directions. Probe: scratchpad/review22/probe_engineered.py (probe 1).
2. (Minor 1a) Implement the site-test ruling above.
3. (Minor 1b) Each window id counted once: Rf skips Lf's ids (e targeting the last 5 bp of an A-only element is E).
4. (Minor 1c) `outer_host` also accepts dead X-only ancestors that still span sequence; their site test runs as for
   alive ones (a child of a dead A-only host is E + host_empty). Probe: scratchpad/review22/probe_deadhost.py.
5. (Minor 2) params.json records requested and realized event counts per branch; log a warning when an event type
   falls short.
6. (Minor 3) `--scale` must be finite and > 0 (error line, exit 1, no traceback).
7. (Minor 4) Move TRUTH_COLUMNS, `_Truth`, `compute_truth`, `_inner_spans` (and the site-test helpers) to
   `src/ltrpav/sim/truth.py`; pair.py imports them. Task 23 will import TRUTH_COLUMNS from there.
8. (Minor 5) `_annotation` writes each LTR's own outer bound (`e.ltr_left[0]`, `e.ltr_right[1]`) shifted by the
   jitter, not the element ends.
9. (Addendum 11, task-22-rulings-addendum.md) `PairParams.n_same_site = 10`: after both branches' structural events
   and before `mutate`, each branch X gets n_same_site (per 6 Mb, times scale) extra insertions (origin X, K from
   k_branch), each at the empty site of a distinct, randomly chosen alive lineage-only element of the other genome
   whose site X still holds empty; insertion point = X's position of that element's target start + U{0..L-1}.
   One-line reason comment (parallel hotspot insertions; over-represented relative to nature so O recall is
   measurable). Realized count goes to params.json with the others.
10. (Minor 6) Tests: item 1's three cases; 1a at offsets 1 and 3 bp (O both ways) and 12 bp (E); 1b; 1c; an S
    whose solo LTR a later deletion destroys (T or D); T with inv; `test_provenance_invariants` with
    indel_rate > 0 (missing ids = structural deletions plus noise_lost); `test_cli_bad_region` asserts that no
    output file at all was written; O occurs in both directions of a default simulation (item 9).

## After the fixes
Rerun the real seed-1 simulation into scratchpad/simcheck (overwrite) and the pipeline check into scratchpad/pipe,
and report: truth state counts per direction (O included), how many hosts that died under the old rule now live,
realized event counts, and high-tier agreement with the truth. Full suite under `-W error`, ruff clean.
