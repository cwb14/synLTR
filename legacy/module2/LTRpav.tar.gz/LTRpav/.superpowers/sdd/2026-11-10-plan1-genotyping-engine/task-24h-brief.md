# Task 24H: engine fixes before the whole-genome run (Task 25)

The controller inserted this task. Bake-off phase B1 (`task-24b-rulings.md`; ledger lines for Task 24 B1) and the
dispute inspection (`inspect-disputes-report.md` Q4) found three small engine defects, items 1-3. Phase B2 chose
LASTZ as the local backend, which item 0 ports into the engine. Do all four before Task 25 runs the engine on whole
genomes. Work through the items in order and commit each separately.

## 0. Port the LASTZ window backend into the engine and make it the default (first; its own commit)
The bake-off chose LASTZ as the local window aligner, with the winning route flank-mm2 at a 2-kb cap. See
`D/REPORT.md` section 7, the ledger's B2 line, and commit 568f90d, which set DEFAULT_ROUTE and FLANK_CAP.

The backend lives outside the repo, in `D/backends.py`. It is registered through
`ltrpav.localign.register_backend`. Its parameters and their reasons are in `D/PARAMS.md` section 4: the pair
preset's scoring, ydrop, gappedthresh 80, step 1, the 12of19 transition seed, plus-strand-only chaining and
`--ambiguous=iupac`.

**The port.**
- Move it into `src/ltrpav/`, as a module or inside `localign.py`, whichever matches the existing structure.
- Register it as a built-in backend named `lastz`.
- Set DEFAULT_BACKEND (or the engine's equivalent of `cli.BACKEND`) to `lastz` in `constants.py`, with a one-line
  reason that cites the bake-off. mappy stays available through the API.
- **No new CLI option.** DESIGN 5.3 keeps one fixed local aligner, now LASTZ.
- **Fail fast.** If `lastz` is not on PATH, give a clear one-line error, exit 1, the same way the engine handles a
  missing minimap2, FastGA or BLAST. Extend `tests/test_cli.py`'s missing-binary test, and make it set PATH itself
  instead of depending on the caller's PATH. That fixes the deferred minor from Task 24G.
- Add `lastz` to `environment.yml` at the version `ltrpav_bench` uses. Install it into the `ltrpav` env with
  `mamba install -n ltrpav -c bioconda lastz=<that version>`, never into base.
- **Port exactly.** On all 6 sims (`D/sims/`), a default `ltrpav run` must reproduce the bake-off's
  `flank-mm2_2k_lastz` calls files byte for byte, in both directions. Those files are in
  `D/runs/<sim>/flank-mm2_2k_lastz/`. Use 16 threads, write to your scratch directory, and run each command under
  `timeout 15m`.
  - Also genotype chr10 B73v5->TIL18 with the flank-mm2_2k anchors (copy the anchors into a scratch workdir). The
    calls must match `D/chr10/runs/flank-mm2_2k_lastz/`.
  - If they differ, find out why before going on.
- **Tests:**
  - the toy P, E and D cases, and the 21 toy cases over the classifier's seeds, as `D/backend_check.py` does,
    adapted into `tests/` for the built-in backend;
  - the default backend is lastz;
  - the missing-binary test.
- **DESIGN 5.3:** the local aligner is now LASTZ, with its key settings and a pointer to the bake-off.
- **Commit:** "Use LASTZ for window alignment, as the bake-off chose".

## 1. Tighten rule 5a's two loopholes (`classify.py`)
Rule 5a (commit 1cb1b34) requires a present call to be anchored at its site: an alignment run crosses the element's
start or end with >= MIN_SEG aligned flank bases, or else B's bases on both sides of the element's image match an A
TSD copy. Inspection of real chr10 found two ways a paralogous copy still passes.

- **(a) Thin crossing.** In case 34, the run crossing the junction carried >= MIN_SEG flank bases but reached a
  single base into the element. A run that barely enters the element does not join the element to its flank.
  - New requirement: the crossing run holds >= MIN_SEG aligned A bases on each side of the junction, inside the
    element as well as in the flank.
- **(b) TSD exception without position.** In read-out case 12, a present call with no flank continuity at all
  passed through the TSD exception.
  - New requirement: the exception holds only if the element's B image lies between the B images of its flanks.
    Use rule 3's lo/hi: the image of the last aligned A base before the element and of the first from its end.
- **No new constant.** The reason is the same positional orthology that rule 5a states.
- **Check outside the suite.** Reclassify from one alignment, as `D/inspect_disputes/measure_5a.py` and
  `D/inspections/b1_thin_anchor.py` do (D = `/data2/chris/maize_introgression/benchmark_pav/bakeoff`), with the
  tightening off and on. Use the default configuration (flank-mm2, 2-kb cap, lastz). For chr10, genotype B73v5->TIL18 and TIL18->B73v5 with the flank-mm2_2k anchors from `D/chr10/runs/flank-mm2_2k/`. For the sims, use two of them. Report:
  - how many calls change;
  - their states and tiers;
  - in the sims, against truth: right to U, and wrong to U.

  Measure once and do not adjust anything afterwards. B1's scan with mappy found about 17 of 4,141 high-tier present calls on chr10 mm2 that would change. Report the count with lastz.
- **Tests:**
  - a crossing run that enters the element by fewer than MIN_SEG bases gives U `unanchored`;
  - one that enters by MIN_SEG or more passes;
  - a TSD-exception copy outside its flank images gives U;
  - a TSD-exception copy inside them passes.
- Update the `classify.py` docstring (rule 5a) and the DESIGN 5.4 text.

## 2. Window merge on the padded cap (`window.py`)
`make_windows` caps the unpadded anchor span at WINDOW_CAP. `_try_merge` caps the padded merged span, which can be
up to 2 x WINDOW_PAD larger. As a result, two identical windows whose anchor span is just under WINDOW_CAP never
merge, and the same alignment runs once per element: 33 redundant windows on chr10 mm2, and one 423-s chunk.

- Compare the merged padded span with WINDOW_CAP + 2 x WINDOW_PAD, or compare the merged unpadded span with
  WINDOW_CAP. Choose whichever matches `make_windows`, and say which.
- **Calls must not change except through the merge itself.** Check by rebuilding chr10 mm2's windows:
  - count the merged groups;
  - genotype B73v5->TIL18, or the TIL18<->TIL01 directions where the groups are, before and after;
  - compare the calls.
- **Test:** two identical windows with an anchor span of WINDOW_CAP - 100 merge into one.

## 3. QC ancestor link for e_in_annot (`loci.py`, `_annotation_agreement`)
`e_in_annot` counts E calls of element a whose B site lies inside an annotated B element h. h is exempt if it is
in the locus of an ancestor of a.

The inspection found that 30% of sampled cases are correct nested E calls: a's host is annotated in A and called
P in B inside h, but h and the host's B image fail the locus's reciprocal-overlap test because their boundaries
differ.

- **The fix.** h is also exempt when it overlaps the B image (`b_start..b_end`) of an ancestor of a that is called
  P/S/T in B. The host's present call is direct evidence that h holds the host's ortholog.
- **Documentation.**
  - Update the QC docstring.
  - Add a note to DESIGN 10.1's `e_in_annot` bar: on real maize data the metric is an upper bound on E error,
    dominated by hosts annotated only in B (inspection Q4: 55% of sampled cases). The bar stays as it is; Task 25
    reports the miss and its decomposition.
- **Test:** a nested E inside h, whose host is P in B with an image overlapping h but under the locus's
  reciprocal-overlap threshold, is not counted. An unrelated h is still counted.
- **Recompute** e_in_annot on the chr10 mm2 run with the fix and report it, without changing the run's files:
  write the new qc.tsv to your scratch directory.

## Constraints
- **The repo has one writer: you.** Bake-off runs import this working tree. The controller dispatches this task
  only after the chr10 batch has ended and bake-off phase B2 has committed.
  - Still, before the first edit, check that `pgrep -af 'run_variant.py|bakeoff.py measure'` prints nothing.
  - If a run is live, report BLOCKED with its PIDs, and do not edit.
- **Commits:** four, item 0 first, with these subjects (item 0's is given above):
  - "Require present calls to cross into the element at their site";
  - "Merge windows on the padded cap";
  - "Exempt hosts' present images in e_in_annot".

  Use the existing identity and add no trailers or AI attribution. The user is the sole author. Do not push.
- **Verification:** the full suite under `-W error` with the ltrpav_bench bin first on PATH, and `ruff check .`.
  Both must be clean after each commit.
- **Probes:** at most 16 threads, each under `timeout 15m` in the foreground. Export `NUMPY_MADVISE_HUGEPAGE=0`.
  Scratch goes only under `D/task24h_scratch/`.
- No subagents. American English.

## Report
Write `task-24h-report.md` in this directory: per item, what changed, its tests and the real-data check numbers.

Return ONLY:
- status;
- the three commits;
- a one-line test summary;
- per item, its real-data numbers in one line;
- concerns.
