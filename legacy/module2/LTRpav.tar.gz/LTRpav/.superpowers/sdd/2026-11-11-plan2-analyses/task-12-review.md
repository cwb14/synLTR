# Task 12 review: preliminary main3 analyses and the comparison with the papers (2c2e639..88e07b2 + main3_analyses)

What I read: the brief, the rulings, the report, the diff (DESIGN.md section 12), compare_papers.py (all 1,316 lines),
investigate_misses.py/.txt, prelim_papers.tsv (all 103 rows), ltrmix_crosscheck.tsv, PRELIM.md, run_analyses.sh,
analyses.log, compare_papers.log, snapshots/, the dead_ends.md section, the memo's Plan 2 section, LTRmix's
eval_real.py and its D_ins code (ltrmix.py:1117-1210), both papers' PDFs (pdftotext), lit_review.md, and the overview's
PNG and legend pages.

What I ran: probes only, all under `timeout 15m`, single-threaded, writing only to scratch
(`/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t12review/`):
- `check_windows.py` runs eval_real's own pandas functions, imported from a scratch copy whose `main` never runs, on
  LTRpav's posterior.B73.tsv. It checks the windows and the chromosome ranking.
- `check_hf_np.py` is an independent numpy port of eval_real's section G, with the same draw order.
- `check_dpav.py` and `check_dpav2.py` recount D_pav from the pair files with my own jackknife. They also recount the
  outgroup bound.
- `check_split.py` refits s with my own likelihood, checked against numerical integration, using L-BFGS-B.
- `check_auc.py` checks the AUROC, tract recall and spacing through eval_real's code paths.
- `check_mech.py` computes a library-style D on D_pav's own loci (Issue I2).
- `check_resol_age.py` gives the resolution symmetry by age bin.

Nothing was rerun into the run directory, and nothing wrote into LTRmix. main3 is unchanged by my probes: my own depth-3
snapshot taken today equals `snapshots/main3.before.tsv`.

### Spec Compliance
- ✅ **Step 1 / ruling 1 (view, preconditions).**
  - The symlinks are as ruled: `loci.tsv`, `manifest.json`, `pairs`, `qc.tsv -> qc_fixed/qc.tsv`, and
    `work/elements`.
  - `work/` is a real directory, and `samples.tsv` is a copy with the four expected groups (Zd role outgroup).
- ✅ **Step 2 / ruling 2 (launch).**
  - run_analyses.sh has `set -euo pipefail`, the `trap ... analyses.exit` and the export, and runs the three commands in
    order.
  - analyses.log covers 06:59:41-07:21:06; analyses.exit holds 0 and analyses.done exists.
- ⚠️ **Cannot verify:**
  - The PID/SID check (2607351 leader, PPID 1). The process has ended.
  - The pytest line (1121 passed). Not rerun: the commit touches only docs/DESIGN.md.
- ✅ **Step 3.** findings.txt and stats.tsv hold every row compare_papers.py reads, and the script fails fast
  otherwise.
- ✅ **Step 4, one scoring code (focus 1).**
  - `windows`, `shift_test`, `element_truth`/`auc`, `elai_runs`/`tract_recall`, `named_locus` and `hf_test` are
    faithful ports.
  - Running eval_real's *own* functions on LTRpav's file reproduces every window, AUROC and recall row I checked,
    to the printed digit.
  - My numpy port of section G reproduces LTRmix's own `p=0.413` at 200 shifts (0.4129) and the table's 0.3686 at
    1,000. So the seed, the draw order (one offset per region, wrapped regions skipped) and the floor are eval_real's.
    The single "different" cross-check row is only 200 against 1,000 shifts, as reported.
  - "Length-weighted" is the span `end - start + 1` for both tools (ruling 3). The two files share coordinates; the
    same element sits at chr1:51712-70182 in both.
  - Weightings go to the right cross-checks: eval_real's posterior windows and chromosome means are span-weighted,
    and its class shares are unweighted.
  - Seeds: 1 for every window test (reseeded per call, as eval_real) and 2 for the HF test.
- ✅ **Step 4 constraints.**
  - numpy, scipy, csv and gzip, plus ltrpav. The extra ltrpav imports (`pav_distances`, `stats.*`, `read_samples`,
    two constants) are disclosed (report concern 8).
- ✅ **Items 1-14 present (103 rows).**
  - Disclosed deviation: the cob-weight "intermediate" expectation gets no hit/miss (brief item 8 asks for one).
    Reporting it is the conservative choice for a one-haplotype painting; the controller rules.
- ✅ **Verdicts (focus 2).**
  - Every PASS/MISS sits on a DESIGN 10.3 bar and carries "(prelim)": D_pav, chromosomes (painting and class share),
    windows at >= 1 Mb, ZmPRR37a ±50 kb and the 52 HF regions. All other rows read "reported", and direction reads
    "skipped".
  - The named-locus verdict column is consistent with DESIGN 10.3:
    - ZmPRR37a has the only hit/miss bar (MISS at ±50 kb; ±200 kb reported);
    - HPC1 and ZmLPCAT1 are "reported" per 10.3;
    - cob weight is not in 10.3.
  - The problem is the prose label "hit" in PRELIM.md, not the column (I1).
- ✅ **Step 5.** compare_papers.log shows 103 rows; a rerun is deterministic (report).
- ✅ **Step 6 structure.**
  - PRELIM.md has the direct answer, the table, what LTRpav adds, the misses, the caveats, the figure check and the
    labeled hypothesis.
  - Honesty problems in two places: I1, and I2 (the hypothesis section).
- ✅ **Step 7.**
  - Memo section appended, with the view construction, versions, commands and `claude --resume` (minor gaps, M5).
  - DESIGN section 12: 5 lines of text under a heading (8 diff lines). Commit 88e07b2 has subject "Record Plan 2
    analyses outcome", author cwb14, no trailers, and only docs/DESIGN.md.
- ✅ **Rulings 4, 5, 7, 9, 12.**
  - Cross-check: 58 of 59 equal.
  - s_mix carries the ruling's note verbatim plus "not a gene-flow estimate".
  - Sparse flag applied as ruled and disclosed (below).
  - Repo change limited to section 12; memo resume line present.
- ✅ **Ruling 7's sparse flag: the disclosure is adequate.**
  - PRELIM.md section 5 states 303 of 523 (58%), "more than half ... by construction", and that Inv4m's dense block is
    flagged. Every row's note gives the medians.
  - I confirm 303/523 and the medians.
  - Only 71 blocks fall below 1 locus/Mb on either side, the defect's signature (5-19 loci over up to 278 Mb). So the
    flag over-calls about 4x, as the disclosure implies.
  - One residue: each block's ltrpav cell still reads "(known caller defect, ...)", which is wrong for Inv4m's block
    when read alone. The final-wave refresh covers it.
- ✅ **main3 unchanged (focus 6).**
  - `main3.before/after/final.tsv` are identical (226 entries), as are the fai sizes, mtimes and sha256.
  - My own snapshot taken at review time also equals `before`. The evidence is real.

### Strengths
- **The comparison is exactly reproducible from independent code.** Every number I recomputed matched to the printed
  digit:
  - D_pav and its jackknife;
  - all three age bins and dD;
  - the 1- and 10-Mb windows for both tools;
  - the chromosome rankings;
  - all HF means and p-values (both tools, both weightings);
  - AUROC, recall, spacing and tract counts;
  - the named-locus counts;
  - the outgroup bound;
  - the identity split s.

  The cross-check against LTRmix's own benchmark_real.tsv (58/59 equal, the one difference explained and confirmed by
  my 200-shift run) is the right way to prove "one scoring code".
- **The D_pav recount is more than a self-check.** My count straight from the pair files gives 1,330/733 before I
  restricted it to loci.tsv members.
  - The 22 extra loci are secondary TIL18 members of multi-element loci. loci.py (docstring line 13; `_locus`)
    writes each genome's first member eid to loci.tsv and keeps the rest in `extra`; 1,622 TIL18 elements are such
    extras.
  - Restricted, it is 1,317/724, D +0.2905, se 0.0392, Z 7.42, 425 blocks. The tool counts each insertion event
    once, as it should.
- **Resolution is reported without spin.**
  - Section 3 opens with "Resolution: nothing yet; it is coarser". It gives the 5.9% informative fraction, 84 vs
    24 kb, LTRmix's PAV-only classes at 3:1, the degenerate emissions, and "a single insertion can make a tract".
  - That is the honest headline for this trio.
- **The misses are investigated, not explained away.**
  - The investigations are concrete: the 5-Mb block bootstrap (15.1% exact match), the density arithmetic for
    ZmPRR37a (0.15 informative loci per 42 kb), and the 17 HF regions without an informative locus.
  - The post hoc HF reading is labeled post hoc and also misses. No rule changed. LTRmix's shared misses are stated.
- **Literature numbers mostly check out against the PDFs and lit_review.md** (details in M4):
  - Yang: 15-25%, mean 18%, 845 genomes, chromosomes 5/8/9, 11 regions, >80% of lines with ELAI > 1.8.
  - Barnes: the HPC1 B73 lowland allele and the PT allele introgressed.
  - Anderson ~5% and Munasinghe 85.9% match lit_review.md. The 52-vs-11 region caveat is disclosed.
- **Caveats are mostly complete and correct.**
  - My per-age check shows B73 and TIL01 resolved alike in every bin: 0.748/0.730 at K = 0, 0.691/0.681 at
    0 < K < 0.01, and 0.746/0.724 at K >= 0.01.
  - So the CLR concern does not show up as asymmetric resolution where the young-excess evidence sits.
- **Figure check** (focus 5): independent, with full-resolution crops and a base-level re-extraction of panel C.

### Issues

#### Critical
None.

#### Important

**I1. PRELIM.md calls HPC1 and ZmLPCAT1 "hits" although the q rule is met by construction, and ZmLPCAT1's painting
contradicts the truth.**
- Where: PRELIM.md section 2, table rows "HPC1 ..." ("reported: hit, weakly") and "ZmLPCAT1 ..." ("reported: hit by
  the q rule"). PRELIM.md says nowhere that the hits are trivial.
- What:
  - No B73 tract anywhere reaches q <= 0.05 (smallest q 0.20), so "not called" holds at every locus of the genome.
    prelim_papers.tsv's notes say this ("'not called' holds genome-wide"), and so does the report's concern 4
    ("vacuously"). PRELIM.md, the document the user reads, does not.
  - Worse, at ZmLPCAT1 the painting points the other way. A tract (chr5:203,235,770-203,581,542; built from 2 R+D
    loci; q 0.855) covers the gene, and the max posterior is 0.905 (mean 0.854 over ±50 kb). Yang's B73 ELAI there is
    0.08 (truth file). LTRmix also leans the wrong way: 0.50 at ±50 kb and 0.995 at ±200 kb.
- Why it matters: the dispatcher's focus 2 and CLAUDE.md ("never present a null or trivial result as a finding"). A
  reader counts two "hits" beside one MISS, when the q-rule rows carry no evidence and one posterior disagrees with
  the truth.
- Fix (text only):
  - HPC1: "met by construction (no tract passes q <= 0.05 anywhere); the interpolated posterior (0.21, nearest
    informative loci sister-like 303 and 668 kb away) agrees weakly".
  - ZmLPCAT1: "met by construction; the posterior disagrees with ELAI (0.905 vs 0.08; a tract of 2 R+D loci, the
    nearest 70 kb away; LTRmix 0.50/0.995)".
  - Add one line to section 4 or 5 saying so.

**I2. The hypothesis's mechanism and its third prediction fail a test the run's own data allow; PRELIM calls them
"untested".**
- Where: PRELIM.md section 7. The mechanism reads: "A test that assumes absence is ancestral adds derived absences to
  both pattern counts alike, so its D shrinks toward 0. That may explain why D_pav (+0.29) exceeds library-only D_ins
  (+0.19) here, but the two count different loci, so this is untested." Prediction 3 reads: "Library-only
  presence/absence tests give smaller |D| than verified ones, in proportion to the derived share." Section 3 has the
  related bullet "Mechanisms of absence".
- What: the claim can be tested on the same loci. Take D_pav's loci (loci.tsv TIL18 members, TIL18's own calls, Zd E)
  and read the third genome's absence the library way. `check_mech.py`:

  | reading | R+D / S+D | D | K=0 | 0<K<0.01 | K>=0.01 |
  |---|---|---|---|---|---|
  | verified (E only), the tool's | 1,317 / 724 | +0.291 | +0.600 | +0.612 | +0.203 |
  | D or O also absent | 1,869 / 1,035 | +0.287 | +0.644 | +0.586 | +0.209 |
  | presence = P only; E/D/O/S/T absent | 1,896 / 1,065 | +0.281 | | | |
  | the added D/O patterns alone | 552 / 311 | +0.279 | | | |

  - The added patterns are not "alike" in the two counts (552 vs 311). They carry the same asymmetry as the empty-site
    patterns.
  - So on this trio, reading absences in the assembly changes neither D nor its age gradient. The D_pav vs D_ins gap
    (+0.29 vs +0.19) has to come from elsewhere. Candidates: different discovering genomes and loci (D_ins counts B73's
    and TIL01's elements, D_pav TIL18's); LTRmix's orthology errors (its raw-assembly check found 11-12% of its
    "absent" calls occupied, DESIGN 10.1); LTRmix's symmetric-synteny filter.
  - This also tempers the headline's implication. Most non-E absences behave like ancestral absences in this test, or
    ride the same introgressed haplotypes, so "only a third to a half of absences are empty sites" is a statement
    about strict E calls, not evidence that the rest are derived. Section 3 already says the derived share is only
    bounded (1.3-65.1%).
- Why it matters: brief Step 6.6 makes this the scientific core ("what genome-verified PAVs add"), and CLAUDE.md asks
  to earn the claim and to look for a perturbation that tests the mechanism. Here the test was at hand, and it
  contradicts the stated mechanism and prediction.
- Fix:
  - Run the probe (≈30 lines:
    /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t12review/check_mech.py)
    inside investigate_misses.py or compare_papers.py, and report its table.
  - Drop the dilution explanation and prediction 3, or restate them as contradicted on this trio.
  - Name the other candidates for the D_ins gap.
  - Add to section 3: "on this trio, verifying absences does not change D_pav or its age gradient; LTRpav's mechanism
    layer is descriptive here".
  - Keep the headline's first and third sentences, which are supported descriptions. Its second sentence holds
    preliminarily; LTRmix shows the same result without verification.

#### Minor

**M1. The split s disagrees with LTRmix's, and PRELIM.md does not discuss it (focus 3).**
- Where: PRELIM.md section 2, row 13 gives 0.074% ± 0.009% beside 0.048% (0.034-0.063%) with no comment. Only the
  report's concern 7 mentions it.
- What:
  - LTRpav's estimate lies above LTRmix's bootstrap interval; the two intervals overlap only in 0.056-0.063%.
  - Candidate reasons exist in the project record. Task 9's review ruled out the aligner (minimap2 gives 0.075%).
    Two candidates remain: the pair set (TIL18's own P calls vs LTRmix's ortholog table) and LTRmix's whole-record
    global alignment.
  - LTRpav's isolation fit also over-predicts the lower tail (fitted 9.8/15.1/25.3% vs observed 8.5/12.9/21.4% at
    <= 0.2/0.3/0.5%; stats.tsv cdf rows). LTRmix's fit matches its lower tail (5.6 vs 5.4% at 0.1%).
- No conclusion rests on s: 0 young insertions either way.
- Fix: one sentence in section 2 or 5 with these candidates.

**M2. The headline counts "19 PASS, 5 MISS" weigh one claim 16 times.**
- Where: DESIGN.md section 12 line 1, PRELIM.md section 2 paragraph 1, memo "result:".
- What: 16 of the 19 PASS rows are DESIGN 10.3's single windows claim (4 sizes x 2 scores x 2 weightings), and 8 of
  those are class-share windows that eval_real left unverdicted ("model-free"). The brief's wording allows the
  verdicts.
- By DESIGN 10.3 claim:
  - D_pav PASS;
  - windows PASS;
  - chromosomes PASS by the painting, MISS by class share;
  - ZmPRR37a MISS;
  - 52 HF regions MISS.
- The text right after the count lists exactly this, so nothing is hidden. But the leading ratio reads as roughly 80%
  passed when the per-claim picture is about half.
- Fix: lead with the per-claim summary; keep row counts in parentheses.

**M3. Tract recall has no chance baseline.**
- Where: PRELIM.md section 2, row 7: "recall of ELAI runs < 10 kb by any tract 0.31", with LTRmix's 0.37.
- What: LTRpav's tracts cover 469 Mb of chr1-10's 2,132 Mb (22.0%), and LTRmix's ancestry tracts 594 Mb (27.9%).
  Point-like runs are hit at about those rates by chance, so 0.31 and 0.37 are about 1.4x and 1.3x chance.
- Fix: add the coverage fraction beside each recall.

**M4. Literature provenance (focus 4).**
- Inv4m's v5 coordinates (172,883,881-188,131,462) are called "published" in PRELIM.md row 10 and the TSV. No project
  document cites a source; they appear only in LTRmix's scripts (eval_real.py, analyze_six.py, fig1_painting.py),
  LTRmix's REPORT table and the brief. Yang's PDF gives no coordinates. Fix: name the source, or say "LTRmix's v5
  coordinates (source not recorded)".
- "ZmLPCAT1 not called in B73 (Barnes)": Barnes names ZmLPCAT1 as a selection candidate (PBE outlier) and says
  nothing about its ancestry in B73. The expectation rests on Yang's B73 ELAI of 0.08 (the truth file's own note).
  The phrasing is inherited from DESIGN 10.3. Fix: "(Barnes: selection candidate; Yang's ELAI 0.08)".
- Verified as stated:
  - Yang: 15-25%, mean 18%, 845 genomes; ~10-kb haplotypes (main text, fig. S3) with the 80% < 9.1 kb from
    lit_review.md; chromosomes 5/8/9; 11 regions; ELAI > 1.8 in > 80% of lines.
  - Barnes: HPC1.
  - Anderson ~5% and Munasinghe 85.9% (lit_review.md).
  - CLR + Canu vs HiFi (DESIGN section 14).

**M5. Memo reproducibility (focus 6).** The run can be rebuilt from the memo's Plan 2 section, with three small gaps:
- the `sha256sum ... > snapshots/fai.before.sha256` line is missing from the command block;
- `python investigate_misses.py` needs the ltrpav env, because it imports compare_papers and so ltrpav; write
  `mamba run -n ltrpav python ...`;
- run_analyses.sh is given as a comment summary, not verbatim (it omits the `cd` and the date echoes). The file
  itself is in V, so this is a nit.

**M6. Wording in PRELIM.md.**
- Section 7: "lineage sorting gives the same sharing at every age". Lineage sorting gives *symmetric* sharing (D = 0)
  at every age; the amount of sharing does depend on age.
- Section 1: "Genome-wide: yes." could carry "(prelim)" like the next bullet.
- Section 5: the CLR caveat would be stronger with the per-age resolution symmetry above.

**M7. Figure check (focus 5): I agree with the implementer.**
- Lines 1-6: yes. I inspected full-resolution crops of the panel-A "B" marker, panel D's labels and keys, and panel B's
  right column. All are clean, and the "B" marker sits in white space.
- Line 7: no, in part, for the two stated reasons:
  - the short legend states test statistics and thresholds: "none of B73's reach q ≤ 0.05" (A); "D +0.60 at K = 0
    against +0.20 at K ≥ 0.01" (F);
  - its headline says "gene flow from TIL18-like donors into B73, not incomplete lineage sorting" without
    "preliminary".
- Also minor:
  - the short legend's opening runs about 55 words against the ~40-word target;
  - the long legend's last line names a module (`ltrpav.plot.overview`), not a script path.
- These go to the final wave as stated.

### Recomputed numbers
| Item | Claimed | Mine | Source / method |
|---|---|---|---|
| D_pav all | +0.2905 ± 0.0392, Z 7.42; 1,317/724; 425 blocks | +0.2905 ± 0.0392, Z 7.42; 1,317/724; 425 | check_dpav2.py: pair files TIL18→B73/TIL01/Zd, loci.tsv TIL18 members, own 5-Mb delete-one jackknife |
| D_pav raw pair-file count | — | 1,330/733 (+0.2894, Z 7.38) | 22 extra = secondary TIL18 members of multi-element loci (1,622 such elements); the tool's count is right |
| Age bins | 32/8 +0.600 (Z 4.82); 320/77 +0.612 (11.78); 965/639 +0.203 (5.08) | identical | check_dpav.py, K = TIL18_k from loci.tsv; 0 counted loci at K = 0.01 |
| dD | +0.3968 ± 0.1268, Z 3.13, 421 blocks | +0.3968 ± 0.1268, Z 3.13, 421 | own jackknife over the union's blocks |
| Window 1 Mb, LTRpav posterior | r +0.274 / +0.273 (unw/w), p 0.0010, n 2,106 | identical | eval_real's own `windows` + `shift_test` (seed 1, 1,000) |
| Window 1 Mb, class share / LTRmix | +0.258 (n 1,739) / LTRmix +0.284 | identical | same |
| Window 10 Mb | +0.380 / +0.384 / class +0.374 / LTRmix +0.356 | identical | same |
| Chromosomes by posterior | chr5, chr8, chr9 (both weightings); Spearman +0.59 | chr5, chr8, chr9; +0.588 | check_windows.py |
| Chromosomes by class share | chr4, chr5, chr9; +0.60; chr4 0.294, chr8 0.321 | chr4, chr5, chr9; +0.600; 0.2935, 0.3208 | same |
| HF test LTRpav | 0.386 vs 0.369, p 0.3427; w 0.388 vs 0.369, p 0.3297 | 0.3864/0.3691, 0.3427; 0.3879/0.3695, 0.3297 | check_hf_np.py (independent numpy port) |
| HF test LTRmix | 0.399 vs 0.383, p 0.3686 (w 0.3497); 0.413 at 200 | 0.3992/0.3834, 0.3686 (w 0.3497); 0.4129 at 200 | same |
| ZmPRR37a ±50 kb | 6 loci (missing 5, old 1), max 0.160, mean 0.140, no tract; nearest RS 510/188 kb | identical | awk on posterior.B73.tsv and tracts.B73.bed |
| ZmPRR37a ±200 kb | 20 loci (missing 11, neither 5, old 2, RS 1, both 1) | identical | same |
| ZmLPCAT1 | tract q 0.855; max 0.905 | tract chr5:203,235,770-203,581,542, n_RD 2, n_RS 0, q 0.855; max 0.905 | same |
| Outgroup bound, B73 | 0.0268 (321/11,990) | 321/11,990 = 0.0268 | check_dpav2.py: first annotated discoverer TIL18, else TIL01; its own calls into Zd (P/S/T) and B73 (resolved) |
| Identity s | 0.0742% ± 0.0094%, m 0.01564, 23,779 pairs | s 0.000742, m 0.01564, 23,779 | check_split.py: own closed form (matches quad integration to 1e-15), L-BFGS-B, 4 starts |
| Pairs below s | B73-TIL18 8.2% (27,029); TIL01-TIL18 3.2% | 8.23%; 3.23% | same |
| AUROC | 0.7123 / 0.7675 (n_pos 2,647/778; n_neg 26,700) | identical | eval_real's `per_element_truth` + `auc` |
| Tract recall | 0.310, 0.419, 0.486, 0.500 (n 1,807/523/218/10) | identical | eval_real's run loop |
| Spacing; tracts | 84.4 / 283.1 kb; 770 tracts, 0 at q ≤ 0.05, min q 0.20 | identical | check_auc.py |
| LTRmix classes | 31,395 informative of 127,636; PAV-only 23,449 | 31,395; 23,449 (3.1x LTRpav's 7,515 of 126,853) | zcat/awk |
| Sparse flags | 303 of 523; medians 53.8/39.9/36.1/42.2 | 303 (57.9%); same medians; only 71 blocks < 1 locus/Mb on either side | own recount from inversions.tsv |
| Inv4m block | B73~TIL18 172.81-188.08 Mb, 464 loci, 43 discordant; left 0.07 Mb, right contains | 172,809,051-188,082,251; 464; 43; left interval ends 74.8 kb before 172,883,881; right 188,082,251-188,227,865 contains 188,131,462 | inversions.tsv |
| main3 unchanged | before = after = final | my snapshot now = before | `find -maxdepth 3 -printf` + cmp |
| New: library-style D (I2) | — | +0.287 (1,869/1,035); P-only +0.281; added D/O 552/311 (+0.279) | check_mech.py |
| New: tract coverage (M3) | — | 469/2,132 Mb (22.0%); LTRmix 594 Mb (27.9%) | fai + tract BEDs |
| New: resolution by age | B73 0.728, TIL01 0.710 (all) | K=0 0.748/0.730; 0<K<0.01 0.691/0.681; K≥0.01 0.746/0.724 | check_resol_age.py |

### Assessment
**Task quality: Needs fixes.**

The comparison itself is excellent: one scoring code proven equal to eval_real, and every number I recomputed matches.
But PRELIM.md must stop calling the met-by-construction HPC1/ZmLPCAT1 rows hits (I1). Its hypothesis section must also
report, rather than call untested, the same-loci test that contradicts its dilution mechanism and third prediction
(I2). Both are text fixes to PRELIM.md, plus a ~30-line probe for I2. Neither touches the run or the verdict column.

## Re-review (fix round 1)

Scope: findings I1, I2 and M1-M6 against the rulings in task-12-fix-1.md, plus what the fix changed. M7 is deferred
to the final wave by ruling.

What I read:
- the report's "Fix round 1" section;
- review-88e07b2..4b73977.diff;
- the new PRELIM.md (all of it);
- prelim_papers.tsv's new and changed rows;
- compare_papers.py's new `absence_readings`, `state_by`, `READINGS`/`STATE`, `coverage` and the recall cells;
- the memo's Plan 2 section and the new dead_ends.md entry.

Probes (scratch t12review/, read-only, under `timeout 15m`):
- `check_mech2.py`: the I2 readings with jackknife Z, bins and dD.
- `check_recall_chance.py`: the chance overlap per run-length bin, from 200 circular shifts of the ELAI runs.
- An awk recount of the in-gene ELAI dosages.
- A scratch copy of investigate_misses.py run against the new compare_papers.py (`-B`, nothing written to V). Its
  output is byte-identical to investigate_misses.txt.
- A heredoc-vs-file diff for the memo.
- A fresh main3 snapshot: still identical to `main3.before.tsv`, as is the implementer's `main3.fix1.tsv`.

Commit 4b73977 "Correct the Plan 2 outcome summary" is author cwb14, has no trailers and touches only
docs/DESIGN.md.

### Verdict per finding
- **I1 — ADDRESSED.**
  - PRELIM.md's table now labels HPC1 and ZmLPCAT1 "met by construction (no tract passes q anywhere)", and so do the
    TSV notes. A new caveat in section 5 says these rows carry no evidence.
  - ZmLPCAT1's disagreement is stated plainly: posterior 0.905 under a q 0.855 tract of 2 R+D loci, against ELAI 0.08,
    "only the q rule keeps it from being called".
  - HPC1's "weakly" is gone (interpolated posterior, no local evidence). The cob-weight row says its posterior is
    interpolated from donor-like loci 567 and 669 kb away; I confirmed that no informative locus lies within ±200 kb.
  - The new in-gene ELAI dosages are correct: ZmPRR37a 1.554 (39 SNPs), HPC1 0.027 (8), ZmLPCAT1 0.081 (42), cob
    weight 0.657 (5).
- **I2 — ADDRESSED.** The numbers are verified (table below). Every required text change is in:
  - section 1 ("does not hinge on verification");
  - section 2 (new row 3, "Does verification matter?");
  - section 3 ("A different D: no ... what verification adds here is the outgroup polarization and the description of
    how absences arise, not a sharper gene-flow test");
  - section 7 (dilution mechanism withdrawn, prediction 3 removed, headline restated);
  - DESIGN section 12, the memo and dead_ends.md (a "Withdrawn" entry).

  The D_pav vs D_ins gap is marked untested, with the ruled candidates named and none asserted. The age-composition
  candidate is partly tested and correctly so: LTRpav's D is higher in every matched bin. My own reweighting agrees:
  LTRmix's bin D's on LTRpav's age mix give +0.208, and LTRpav's on LTRmix's mix +0.271. Age mix accounts for 0.01-0.02
  of the 0.096 gap. One candidate points the wrong way (N2).
- **M1 — ADDRESSED.** Section 5 caveat:
  - the aligner is ruled out (minimap2 0.075%);
  - the pair set and LTRmix's whole-record global alignment remain open;
  - the lower-tail over-prediction is given (9.8/15.1/25.3% fitted vs 8.5/12.9/21.4% observed; stats.tsv cdf rows);
  - "no conclusion rests on s".
- **M2 — ADDRESSED.** The per-claim summary leads PRELIM section 2, DESIGN section 12 and the memo's result line, with
  row counts in parentheses ("19 PASS, 16 of them windows").
- **M3 — PARTIALLY ADDRESSED.**
  - The coverage fractions are right and stand beside the recall: 22.0% (469 Mb) and 27.9% (594 Mb), recent 18.3%.
  - But the new "x chance" multipliers divide every run-length bin's recall by the point-like coverage. Longer runs
    are hit far more often by chance (N1).
- **M4 — ADDRESSED.**
  - Inv4m reads "LTRmix's (B73) v5 coordinates (source not recorded)". "Published" is gone from the TSV (0 hits) and
    from PRELIM.md.
  - ZmLPCAT1 reads "(Barnes: selection candidate; Yang's ELAI 0.08)".
- **M5 — ADDRESSED.**
  - The memo has the fai sha256 line and `mamba run -n ltrpav python investigate_misses.py`.
  - The run_analyses.sh heredoc is byte-identical to V/run_analyses.sh (diff empty).
- **M6 — ADDRESSED.**
  - "symmetric sharing (D = 0) at every age";
  - "Genome-wide: yes (prelim)";
  - the CLR caveat cites the per-age resolution: 0.748/0.730, 0.691/0.681, 0.746/0.724; overall 0.728/0.710. These
    match my values, and they are computed now in compare_papers.py (TSV row 20).

### I2 numbers (implementer's, against check_mech2.py)
| reading of the sisters' absence (D_pav's candidates, TIL18's calls, Zd E) | implementer | mine |
|---|---|---|
| verified, E only | 1,317/724, D +0.2905 (Z 7.42); 32/8, 320/77, 965/639; dD +0.397 ± 0.127 (Z 3.13) | identical |
| E, D or O absent | 1,869/1,035, D +0.2872 (Z 7.74); +0.644 (37/8), +0.586 (437/114), +0.209 (1,395/913); dD +0.436 ± 0.116 (Z 3.74) | identical |
| P only present; E/D/O/S/T absent | 1,896/1,065, D +0.2806 (Z 7.92); +0.610 (33/8), +0.580 (421/112), +0.208 (1,442/945); dD +0.402 ± 0.124 (Z 3.23) | identical |
| added D/O patterns alone | 552/311, D +0.2793 (Z 5.23) | identical |

`absence_readings` is correct. It reads states through `state_by` from the discoverer's own calls on
`discover(..., "E")`'s candidates, and its verified row equals D_pav exactly.

### Are the restated headline and the withdrawn mechanism now supported?
- **Headline. Yes, supported, with one wording nit (N3).** "Only a third to a half ... are empty sites, fewer for
  older insertions" rests on frac_E 0.31-0.53, falling in all six pairs. "Counting the unverified absences as absent
  leaves the introgression signal and its young-insertion excess unchanged on this trio" holds within jackknife error:
  D moves 0.003 (≈0.1 SE) and dD 0.04 (≈0.3 SE), in both library readings. "Verification ... without sharpening the
  gene-flow test" follows.
- **Mechanism. Yes.**
  - The dilution mechanism and its prediction are explicitly withdrawn, with the evidence: the D/O patterns split
    552:311, the empty sites' asymmetry.
  - The two remaining readings are offered as alternatives, not asserted: ancestral absences that could not be
    verified, or the same introgressed haplotypes.
  - "That fits the empty-site share falling with insertion age" is appropriately modest.
  - The generality line now notes that the verification test is one trio too.
  - The predictions left (falling empty-site share; unequal recombination; painting resolution) are not contradicted
    by anything in the run.

### New findings in the fix diff

**N1 (Important). The new "x chance" multipliers on tract recall are wrong for every bin above < 10 kb, and they
flatter both tools.**
- Where:
  - prelim_papers.tsv rows 54-57 (recall cells "(… x chance)");
  - PRELIM.md section 2, row 7: "1.4-2.3x that chance rate" for LTRpav and "1.3-2.9x chance" for LTRmix.
  - Code: compare_papers.py:1117 divides each bin's recall by `coverage(...)`, the fraction of chr1-10 under
    tracts.
- What: the coverage row's own note says that fraction is the chance hit rate for a *point-like* run. A longer run
  is overlapped by chance whenever any tract falls within its length, so its chance rate rises with run length.
  Circular shifts of the ELAI runs within chromosomes, against each tool's actual tracts (200 replicates), give:

  | tracts | < 10 kb | 10-100 kb | 100-500 kb | >= 500 kb (n 10) |
  |---|---|---|---|---|
  | LTRpav all: chance / obs / ratio | 0.230 / 0.310 / 1.3x | 0.245 / 0.419 / 1.7x | 0.305 / 0.486 / 1.6x | 0.524 / 0.500 / 1.0x |
  | stated ratio | 1.4x | 1.9x | 2.2x | 2.3x |
  | LTRmix ancestry: chance / obs / ratio | 0.299 / 0.374 / 1.3x | 0.328 / 0.488 / 1.5x | 0.441 / 0.601 / 1.4x | 0.731 / 0.800 / 1.1x |
  | stated ratio | 1.3x | 1.8x | 2.2x | 2.9x |
  | LTRmix recent: ratio (stated) | 1.1x (1.2x) | 1.1x (1.2x) | 1.1x (1.4x) | 0.6x (1.1x) |

  The honest range is 1.0-1.7x for LTRpav and 1.1-1.5x for LTRmix ancestry, against the stated 1.4-2.3x and
  1.3-2.9x. The recent-mode q <= 0.05 cell "4.8x chance" (≥ 500 kb, 2 of 10 runs) has the same flaw.
- Why it matters: this is a wrong number in PRELIM.md's main table, introduced by the fix, and it overstates both
  tools' tract recall. At >= 500 kb, LTRpav's recall equals chance. The overall conclusion (no tract-scale
  resolution) does not change.
- Fix (about 20 lines, ~2 s): compute the chance rate per run-length bin by circularly shifting the runs within each
  chromosome against the tool's tracts. That is the same null family as the HF test; my probe is
  `t12review/check_recall_chance.py`. Alternatively, give the multiplier only for the < 10 kb bin and say longer runs
  are hit more often by chance. Then update row 7 and the TSV cells.

**N2 (Minor; follows ruling I2's candidate list, for the controller). The annotation-completeness candidate points
the other way.**
- Where: PRELIM.md section 7, "The D_pav vs D_ins gap is untested", second candidate.
- What: LTRmix's own code says one-sided annotation dropout "biases D_kmer and D_ins toward the more complete sister"
  (ltrmix.py:1185-1187). The ratio B73/TIL01 is 1.081, so the bias would raise D_ins. It cannot explain D_ins being
  *lower* than D_pav.
- Fix: say so in the candidate line (it would widen the gap, not explain it), or drop it.

**N3 (Minor). The headline's "describes how absences arise" says more than the data show.**
- Only the E share (35%) is shown ancestral and at least 1.3% shown derived. The rest are "not shown derived", and in
  the D test they behave like empty sites (PRELIM section 3; dead_ends: "a description of absence states").
- Fix: "describes the state of each absence" or "shows which absences are empty sites".

**N4 (Minor, code nit).** `absence_readings` hard-codes the state codes (`[1, 2, 3]`, `[5, 6]`, `[1, 2, 3, 4]`)
beside the `STATE` map it uses one line earlier. They are correct (they equal catalog.STATE_CODE), but
`STATE[...]` lookups would keep one source of truth.

### Out-of-Scope Observations
None.

### Assessment (fix round 1)
**Task quality: Needs fixes (N1 only).**

I1, I2, M1, M2 and M4-M6 are addressed, and every number I rechecked matches. The restated headline and the withdrawn
mechanism now stand on the run's own evidence. The one blocker is new and small: the recall "x chance" multipliers
apply a point-like baseline to long runs and overstate both tools' recall.

## Re-review (fix round 2)

Scope: N1-N4 and M3, plus what the fix changed.

What I read:
- the report's "Fix round 2" section;
- compare_papers.py's new `recall_chance`, its call site and the `STATE = STATE_CODE` change;
- prelim_papers.tsv rows 53-57 and a sample of unchanged rows;
- PRELIM.md rows 7 and sections 3 and 7;
- the memo's fix-round-2 line.

The repo is unchanged: HEAD is 4b73977 and the tree is clean.

Probe: `t12review/check_recall_chance2.py`, my run-shifting null (each ELAI run shifted on its own within its
chromosome, 1,000 replicates, seed 7), now with the recent q <= 0.05 set added. It also gives the
chromosome-weighted coverage and a binomial test. It ran read-only under `timeout 15m`.

main3 is still identical to `main3.before.tsv`, by `main3.fix2.tsv` and by my own snapshot. V has no `__pycache__`.

### Verdict per finding
- **N1 — ADDRESSED.**
  - `recall_chance` is correct:
    - one uniform offset per chromosome per replicate, drawn before the empty-set `continue`, so every tract set sees
      the same offsets;
    - wrapped tracts split at the chromosome end;
    - overlap by eval_real's closed rule through a cumulative maximum end;
    - the mean over 1,000 replicates.
  - Shifting the tracts has the same per-run expectation as my run-shifting null, and the numbers agree within Monte
    Carlo error:

    | tracts | reported chance (< 10 / 10-100 / 100-500 / >= 500 kb) | mine | reported ratio | mine |
    |---|---|---|---|---|
    | LTRpav all | 0.231 / 0.246 / 0.304 / 0.520 | 0.231 / 0.245 / 0.303 / 0.520 | 1.3, 1.7, 1.6, 1.0x | 1.3, 1.7, 1.6, 1.0x |
    | LTRmix ancestry all | 0.297 / 0.328 / 0.442 / 0.743 | 0.298 / 0.327 / 0.442 / 0.736 | 1.3, 1.5, 1.4, 1.1x | 1.3, 1.5, 1.4, 1.1x |
    | LTRmix recent all | 0.195 / 0.202 / 0.228 / 0.326 | 0.195 / 0.202 / 0.228 / 0.331 | 1.1, 1.1, 1.1, 0.6x | 1.1, 1.1, 1.1, 0.6x |
    | LTRmix recent q <= 0.05 | 0.040 / 0.040 / 0.042 / 0.051 | 0.040 / 0.040 / 0.041 / 0.055 | 0.9, 1.0, 1.3, 3.9x | 0.9, 1.0, 1.3, 3.6x |

  - The < 10 kb chance rates are consistent with the coverage fractions. The gap between genome-wide coverage and the
    < 10 kb chance rate (0.220 against 0.231) is where the runs lie: coverage weighted by each chromosome's share of
    the < 10 kb runs gives exactly the chance rates.

    | tract set | genome-wide coverage | run-weighted coverage = < 10 kb chance |
    |---|---|---|
    | LTRpav | 0.220 | 0.231 |
    | LTRmix ancestry | 0.279 | 0.296 |
    | LTRmix recent | 0.183 | 0.195 |
    | LTRmix recent q <= 0.05 | 0.042 | 0.040 |

  - The text claims nothing the multipliers do not show:
    - PRELIM row 7 gives each bin's recall, chance and ratio for both tools, and says "at >= 500 kb recall equals
      chance (n 10 runs)";
    - DESIGN section 12 quotes no multiplier;
    - the memo quotes only the LTRpav and LTRmix-ancestry ratios, correctly.
  - The 3.9x (LTRmix recent q <= 0.05, >= 500 kb) appears only in TSV row 57's cell, never in PRELIM.md. It rests on
    2 of 10 runs: one-sided binomial p = 0.089 against chance 0.051, and my null gives 3.6x. It is noise, and nothing
    reads it as enrichment (N5 suggests a label).
- **M3 — ADDRESSED.**
  - Each recall now stands beside its own bin's chance rate, in PRELIM row 7 and in every TSV recall cell.
  - The coverage row is relabeled "the chance rate for a point-like run", with a note that longer runs are hit more
    often.
  - This meets the ruling's intent better than the coverage fraction alone.
- **N2 — ADDRESSED.** The completeness candidate now reads "would widen the gap, not explain it". It cites LTRmix's
  completeness diagnostic, where one-sided dropout biases D_ins toward the more complete sister, B73/TIL01 1.08.
- **N3 — ADDRESSED.**
  - The headline reads "genome verification shows which absences are empty sites without sharpening the gene-flow
    test".
  - Section 3 reads "the state of each absence (which ones are empty sites)".
  - "How absences arise" no longer appears in PRELIM.md, dead_ends.md, the memo or DESIGN.md.
- **N4 — ADDRESSED.** `STATE = STATE_CODE` is imported from ltrpav.analysis.catalog, and `absence_readings` builds every
  code set from `STATE[...]`. No literal codes remain.

Nothing else moved:
- 109 rows, 19 PASS / 5 MISS / 84 reported / 1 skipped;
- the cross-check is still 58 equal / 1 different;
- the I2 rows (17, 19, 20) and the ZmLPCAT1 row equal their fix-round-1 values.

### New findings in the fix diff
**N5 (Minor, optional).** TSV row 57's cell "q <= 0.05 0.200 (chance 0.051, 3.9x)" for LTRmix recent rests on 2 of 10
runs (binomial p = 0.089). The ratio is unstable at this n: my null gives 3.6x. Fix: put the counts in the cell,
e.g. "(2 of 10 runs; chance 0.051)". PRELIM.md does not cite it, so nothing is overclaimed.

### Out-of-Scope Observations
None.

### Assessment (fix round 2)
**Task quality: Approved.**

N1-N4 and M3 are addressed, and the chance rates reproduce independently. The restated text claims nothing the
numbers do not show. Only one optional Minor label remains (N5).
