# Task 12 report: window alignment (`localign.py`) and toy builders

Status: DONE_WITH_CONCERNS (the concerns are about how mappy places alignment ends; Tasks 13 and 14 need them)
Commit: `ec1f12c Add window alignment map and toy builders` (branch plan1-engine, existing git identity, no trailers)

## What I implemented

### `src/ltrpav/localign.py` (new)
- `Gap(a0, a1, b0, b1)`: a dataclass. All coordinates are 0-based half-open window coordinates.
- `AlnMap(seg_a, seg_b, seg_len, seg_mm, inv)`: segments are collinear and gap-free, sorted by A, and never
  overlap on A or B. `__post_init__` converts the inputs to int64 arrays and fails fast with ValueError when
  the arrays differ in length, a length is 0 or less, mismatches fall outside 0..len, a coordinate is
  negative, or segments overlap or are out of order. This guards the registered backends.
  `AlnMap.empty()` builds an empty map.
  - `aligned_bp(a0, a1)`: exact count of aligned bases. Uses searchsorted over the segments.
  - `a2b(a)`: exact inside a segment, None elsewhere.
  - `identity(a0, a1)`: 1 - mm/aligned over the parts of segments that overlap the interval. Each segment's
    mismatches are prorated by its overlapping fraction. Returns **nan** when no aligned base overlaps.
  - `gap_around(a, min_seg=MIN_SEG)`: works on **runs**, as the ruling says. Consecutive segments join one
    run when both the A gap and the B gap between them are < min_seg. A run qualifies when it holds
    >= min_seg aligned bases. The method returns the Gap between the last qualifying run ending at or before
    `a` and the first one starting at or after `a`, or None when either side has no qualifying run. When `a`
    lies inside a qualifying run, it returns a zero-length Gap at `a`, with b = a2b(a). If `a` sits on a small
    A-only gap inside the run, a2b(a) is None, so b is the B end of the segment before it, which is the
    insertion point. Runs are cached per min_seg.
  - `b_gaps_within(a0, a1)`: Gaps between consecutive raw segments with B gap > 0. A gap's "A position" is
    where it starts on A (the end of its left segment), and that position must lie in [a0, a1).
- `align_window(a_seq, b_seq, preset="asm20", backend="mappy")` looks the backend up in the registry and
  raises ValueError for an unknown name. `register_backend(name, fn)` adds a backend.
  `preset_for_divergence(d)` maps <= 0.001 to asm5, <= 0.01 to asm10, and anything else, including nan, to
  asm20. A negative d raises ValueError.
- mappy backend: calls `mappy.Aligner(seq=b_seq, preset=preset, best_n=5)` and keeps every hit. Empty A or B
  gives an empty map. The preset must be asm5, asm10 or asm20, otherwise ValueError, because mappy silently
  ignores an unknown preset name (verified).
- `alnmap_from_hits(hits, a_seq, b_seq)` is a public helper that any backend producing mappy-like hits can
  reuse:
  - `-` hits go to `inv` as (q_st, q_en, r_st, r_en), deduplicated and sorted.
  - `+` hits pass through an O(n^2) DP that maximizes total `mlen`. Hit j may precede hit i only if q_st,
    q_en, r_st and r_en of i are all strictly greater. Ties go to the hit that sorts first.
  - CIGAR ops: M, = and X make segments (abutting runs merge); I advances A; D and N advance B. Any other op
    raises ValueError, as does a CIGAR whose length does not match the hit span.
  - Each match run is clipped on the diagonal so it starts at or after the previous kept segment's end on
    both axes. Parts that overlap an earlier hit are dropped.
  - Mismatches are counted with numpy on the uppercased bytes.

### `tests/toy.py` (extended; `rand_seq` and `mutate` are byte-identical)
- `make_element(rng, ltr_len, int_len)` returns `(LTR+INT+LTR, ltr_len, ltr_len)` with identical LTRs.
- `CASES` lists the 21 names in table order. `case(name, rng)` returns a `ToyCase` with fields a, b,
  elements, expect, flags, noflags, tiers and reasons. Unknown names raise ValueError.
- Elements are on seqid "a", genome "toy", 1-based inclusive, with k = 0.0, strand "+" and the tsd set.
  Nesting comes from `assign_nesting`.
- The labels come from one `_LABELS` table, filled from the table's expected column plus the ruling.
- Constructions follow the brief and ruling exactly:
  - L and R are 3 kb; T = CTCTC and T2 = GAGAG.
  - e = LTR(400) + INT(4000) + LTR.
  - h = LTRh(400) + INTh[:2000] + T2 + c + T2 + INTh[2000:] + LTRh, with INTh 4 kb and c = LTRc(300) +
    INTc(2400) + LTRc.
  - T' is fixed rather than random: E_mm1 uses `CTGTC` and E_mm2 uses `CACAC` (1 and 2 middle-base
    substitutions).
- Draw order: L, R, then the element(s), then filler. Only the chosen case draws filler (lazy lambdas).
- `build_pair(rng, cases=None)` returns a `ToyPair` with the same fields, on seqid chr1. The default is CASES
  without U_flank.
  - Layout: spacer, case, spacer, ..., case, spacer. Each slot gets a fresh 20-kb spacer, identical in A and
    B, so there are no repeats across the chromosome.
  - Elements are renamed `"<case>.<name>"`. Coordinates, LTR bounds and eids are shifted, the label dicts are
    re-keyed, and nesting is recomputed.
  - Draw order: the cases first, then the spacers. The offset test relies on this.

## Tests (`tests/test_localign.py`, 86 tests)
- The brief's five tests, with the brief's values:
  - identical 20 kb: >= 19950 aligned bp, 1 segment, identity 1.0
  - 6-kb insertion: `gap_around(13000)` within 50 bp of the element on A and B
  - 2% mutation: identity within 0.98 +- 0.005
  - 3-kb inversion: an inv tuple covers it and `aligned_bp` over it is 0
  - presets, plus boundaries, nan and negative
- gap_around, on hand-built maps:
  - a 1-bp A indel inside a flank does not split the run
  - zero-length gap inside a run, including on the indel itself
  - a run ending exactly at `a`
  - None when a side has no qualifying run, and None on an empty map
  - joining by A gap and by B gap at MIN_SEG - 1 versus MIN_SEG
  - short segments that sum to >= MIN_SEG qualify
  - a short run is ignored even when `a` falls inside it
- gap_around through mappy: a 1-bp deletion in B's left flank. The flank splits into raw segments, yet the
  gap still spans the element, and `gap_around(3000)` is zero-length.
- Map queries:
  - `b_gaps_within`: inclusion, the end boundary, and A-only gaps excluded
  - `a2b` and `aligned_bp`: exact values, None outside segments, empty or reversed intervals
  - `identity`: prorated, nan when nothing overlaps
  - AlnMap validation rejects bad segments
- Hits to map:
  - the chain DP picks the best collinear set and rejects hits that do not advance on all axes
  - a hit is dropped entirely when it overlaps on both axes, and clipped on the diagonal otherwise
  - =/X runs merge; an I op splits segments
  - an unsupported CIGAR op raises
  - duplicate inverted hits are deduplicated
  - N counts as a mismatch, and lowercase input is handled
  - no hits (unrelated sequences, or empty input) gives an empty map
- Backends and presets: unknown backend raises ValueError; `register_backend` dispatch works (the registry
  is restored by monkeypatch); unknown preset raises ValueError.
- Toy sanity:
  - Per case, all 21:
    - element fields
    - eid
    - length
    - LTR bounds, with identical LTR sequence at both bounds
    - TSD on both sides at the reported coordinates
    - labels (expect, flags, noflags, tiers, reasons) against a table written out in the test
  - Exact B construction from A's pieces for the 15 deterministic cases. Filler cases get structural checks;
    P is checked for a 0.5-1.5% Hamming fraction.
  - Host and child nesting: level 0/1, parent eid, and the child offset of +2405.
  - `build_pair` offsets: the pieces sit at the expected A and B offsets, and the spacers are the same in A
    and B. Shifted elements, LTRs and eids are correct, the labels are re-keyed, and the parent is remapped.
  - The default `build_pair` holds every case except U_flank.
  - Both flanks of every toy case anchor under mappy (left always; right except U_flank).

## TDD evidence
RED (new module absent):
```
$ mamba run -n ltrpav pytest tests/test_localign.py
E   ModuleNotFoundError: No module named 'ltrpav.localign'
1 error in 0.24s
```
GREEN:
```
$ mamba run -n ltrpav pytest tests/test_localign.py
86 passed in 0.88s
```
RED/GREEN for inv dedup, which I added after probing showed duplicate `-` hits:
```
$ mamba run -n ltrpav pytest tests/test_localign.py -k chain_picks
E       assert [(2200, 2400,...00, 100, 300)] == [(2200, 2400, 100, 300)]
1 failed, 85 deselected in 0.22s
(fix: sorted(set(inv)))
86 passed in 0.91s
```
Full suite and lint, after the final edits:
```
$ mamba run -n ltrpav pytest -W error
179 passed in 20.49s
$ mamba run -n ltrpav ruff check src tests
All checks passed!
```

## Files changed
- `src/ltrpav/localign.py` (new, 285 lines)
- `tests/test_localign.py` (new, 407 lines)
- `tests/toy.py` (+201 lines; only the module docstring line changed among the existing lines)

## Self-review findings, including deviations and additions beyond the brief
1. **N counts as a mismatch.** A position where either base is N counts as a mismatch, not only bytes that
   differ, so identity never credits unconfirmed bases. This differs from pure byte comparison only for
   N-vs-N. It is stated in the AlnMap docstring.
2. **Preset whitelist** (asm5, asm10, asm20) in the mappy backend, because mappy silently falls back to
   defaults for an unknown preset. Task 24 can widen it if the bake-off needs other presets.
3. **`inv` is deduplicated.** mappy reported the same inverted alignment as primary and as an identical
   secondary in 11/40 inv_site seeds.
4. **Additions beyond the brief:**
   - public `alnmap_from_hits`, so other backends can reuse the chain and clip logic and it can be tested
     with synthetic hits
   - `AlnMap.empty()`
   - constructor validation
   - `preset_for_divergence` maps nan to asm20 and raises ValueError for negative input
5. **Local constants.** The preset cut-offs (0.001 and 0.01) and best_n = 5 are module-level constants in
   localign.py, each with a reason comment, following the `NCAND` precedent in window.py. They are not in
   constants.py, which was not in this task's file list. Move them if the controller prefers.
6. **No mismatch vectorization.** Mismatch counting loops over segments in Python, one numpy compare each.
   That is fine at tens to hundreds of segments per window; vectorize it only if profiling at genome scale
   says so.

## Concerns: how mappy (asm20) places alignment ends, measured on all 21 toy cases over 40 seeds
Offsets below are (gap.a0 - element start0, gap.a1 - element end0, B-gap length), from `gap_around` at the
element midpoint. The probe scripts are in the session scratchpad and are not committed.

1. **Long A-only sequence is one `I` op in one hit, placed at the leftmost equivalent position.**
   - E, E_mm1, E_mm2, G_near and G_far all give the same geometry: the gap is "T e", (-5, 0, 0), never
     "e T". So a0 sits one TSD left of the element and a1 equals the element end.
   - Chance microhomology shifts both ends further left: 30/40 exact, 8/40 by 1 bp, 1/40 by 2 bp, 1/40 by
     5 bp. The gap length is always exact.
   - The same pattern shows in D_left (-505/-506, +5/+4), D_both, T, S, host_E, host_S and adjacent_E.
   - nested_E's child gap sat at (-5..-9, 0..-4): 2-4 bp beyond the T2 copy.
   - **Task 13:** treat the reported ends as one member of the gap's equivalence (slide) range and test the
     whole range, not the reported ends. Against the E slop of 2 × TSD = 10 bp, all 40 seeds pass, but the
     worst seed, at (-10, -5), sits exactly on the limit. A longer chance microhomology would push it out.
2. **Identical LTRs.** In S, B's solo LTR aligned to A's *right* LTR, giving a gap of (0, -400) shifted
   0-2 bp left. In S_notsd it aligned to the *left* LTR, giving (+400, +5), because that is the only
   single-gap placement. So which LTR the solo LTR matches depends on the TSD context. The classifier should
   measure the B side's length, not which LTR it hit.
3. **N runs in B are aligned through as M, not left as gaps.** Those bases count as mismatches.
   - G (B = L T N100 R): the right run starts 95-99 bp *inside* the element and contains the N100, giving
     a gap of (0, -95, 0). `aligned_bp` over the element is about 96.
   - G_near and G_far give exactly the E geometry, with the N50 inside the left flank segment (50
     mismatches).
   - host_G behaves like G.
   - **Task 14:** gap geometry cannot detect G. Look for N in B around b0/b1 and inside the flanking runs,
     for example with `seqio.n_runs` on the B window. Alternatively, Task 13 could split segments at N.
4. **O (B-only random filler).** mappy does not bridge it: there are two `+` hits. The ends wander 0-2 bp
   from chance matches and the B gap is 1997-2000. `b_gaps_within` reports O-type gaps (A gap > 0) as well as
   nestB gaps (A gap 0), so the caller must filter on A-gap size too.
5. **inv_site.** `gap_around` returns an O-like gap: A and B both have about 4.8 kb unaligned, (0..2, 0..-2,
   4796-4800). The classifier must check `inv` overlap before calling O.
6. **Host cases.** In nested_E the host's midpoint falls inside the child's gap, so `gap_around(host mid)`
   returns the child's gap. Query host presence through coverage of its LTR and INT parts, or through
   positions outside the child. In adjacent_E both elements get one merged gap covering e1 T T2 e2.
7. **Window ends.** mappy may trim a few bases at a window end when a mismatch lies near it (P: the hit
   starts at 5), so the first and last window bases are not guaranteed to be aligned.
8. **Runtime.** The mappy index is built per window (`Aligner(seq=b_seq)`, single-threaded string index).
   The 86 tests run in about 0.9 s. I have not benchmarked 100–500-kb windows.

## Headline (engineering task, no biological claim)
For Task 13: mappy reports each long indel at its leftmost equivalent position, so a junction needs
refining over its slide range, and N-runs in the assembly come back as aligned bases, not gaps.

## Fix round 1 (review finding: thresholds must live in constants.py)
Commit: `3c152ed Move window-alignment thresholds to constants` (no trailers)

Changes:
- `src/ltrpav/constants.py`: added two public constants, each with a one-line reason.
  - `MAPPY_BEST_N = 5`: secondary hits kept so window chaining can see alternatives.
  - `PRESET_CUTS = ((0.001, "asm5"), (0.01, "asm10"))`: from the minimap2 manual (asm5/asm10/asm20 suit
    ~0.1/1/5% divergence). A divergence d at or below a cut takes that preset; anything else gets asm20.
- `src/ltrpav/localign.py`: removed the private `_BEST_N` and `_PRESET_CUTS`. The module now imports
  `MAPPY_BEST_N` and `PRESET_CUTS` from `.constants` and uses them in `_align_mappy` and
  `preset_for_divergence`. `_PRESETS`, a list of names, stays local, as the review allowed.
- Behavior is identical: same values and same lookup order. No test changed.

Tests:
```
$ grep -rn "_BEST_N\|_PRESET_CUTS" src tests | grep -v MAPPY_BEST_N
(no output)
$ mamba run -n ltrpav pytest -W error tests/test_localign.py tests/test_smoke.py
88 passed in 0.90s
$ mamba run -n ltrpav pytest -W error
179 passed in 19.71s
$ mamba run -n ltrpav ruff check src tests
All checks passed!
```
