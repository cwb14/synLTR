"""All S-D ortholog pairs of main3's trio (B73, TIL01; TIL18), aligned by the identity module's own workers
(no self alignments), then the module's own split routine (fit, jackknife, mixture, CDF check). Read-only view.
Usage: split_main3.py VIEW THREADS"""
import logging, sys, time
from pathlib import Path
import numpy as np
from ltrpav.samples import read_samples
from ltrpav.analysis.catalog import load_catalog, STATE_CODE
from ltrpav.analysis.relations import pav_distances, discover
from ltrpav.analysis.stats import Findings, block_size
from ltrpav.analysis.trio import Trio
from ltrpav.analysis import identity as idm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
view, threads = Path(sys.argv[1]), int(sys.argv[2])
t0 = time.monotonic()
cat = load_catalog(view, read_samples(view / "samples.tsv"), view / "samples.tsv")
trio = Trio("B73", "TIL01", "TIL18", True)
R, S, D = trio.R, trio.S, trio.D
dist = pav_distances(cat)[0]
size = block_size(cat)
gd = cat.g(D)
c = discover(cat, R, S, D, dist, "E")
pmask = {S: cat.member[:, gd] & (cat.proj[D][:, cat.g(S)] == STATE_CODE["P"])}
loci = np.flatnonzero(pmask[S])
elements = {D: idm._elements(cat, D, loci)}
jobs = [((), idm._job(cat, int(i), [D], elements, pmask, D)[1]) for i in loci]
print(f"{len(jobs):,} {S}-{D} pairs; block size {size:,}", flush=True)
t = time.monotonic()
res = idm._align_all(cat, jobs, threads)
dt = time.monotonic() - t
print(f"aligned {len(jobs):,} pairs in {dt:.1f} s at {threads} threads: {len(jobs) / dt:.2f} pairs/s", flush=True)
tab = idm._Tables(cat, loci, jobs, res, D)
print(f"orientation inferred {tab.n_inferred}, skipped {tab.n_skipped}", flush=True)
sd = tab.fit_pairs(S)
t = time.monotonic()
f = Findings()
rows, s = idm._split(cat, trio, c, size, sd, f)
print(f"split routine (fit, {len(set(rows[0].note.split()))} ..., jackknife, mixture, CDF) in {time.monotonic() - t:.1f} s", flush=True)
for _, line in f.items():
    print(line, flush=True)
for r in rows:
    print(r.statistic, r.value, r.se, r.n, flush=True)
v = tab.pairs[S]
st = np.array([x[1] for x in v]); dd = np.array([x[2] for x in v])
print(f"sites: median {np.median(st):.0f}, < {idm.IDENT_MIN_SITES}: {int((st < idm.IDENT_MIN_SITES).sum())}; "
      f"median div (fit set) {np.median(dd[st >= 200] / st[st >= 200]):.5f}; frac below s {np.mean(sd[1] / sd[2] < s):.4f}", flush=True)
print(f"total {time.monotonic() - t0:.1f} s", flush=True)
