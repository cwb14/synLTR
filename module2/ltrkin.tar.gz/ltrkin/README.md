# ltrkin

Genotype every annotated LTR retrotransposon from long reads (PacBio HiFi or ONT), and trace each new insertion to
the copy it most likely came from.

![ltrkin workflow](docs/img/workflow.png)

## What it does
- **`ltrkin genotype`** tells you, for every element in your annotation and every sample, what each chromosome copy
  carries at that site:
  - **F**: the full element;
  - **S**: a solo LTR (the element was removed, one LTR left behind);
  - **E**: the empty site from before the insertion, so the insertion is new;
  - **N**: nothing, because this haplotype lacks the region.

  So F/E is a new insertion on one haplotype, and F/N is an element in sequence the other haplotype lacks. Run on
  other individuals, it gives presence/absence. Any ploidy.
- **`ltrkin source`** takes those genotypes. For each new insertion it reports the nearest fixed copy of its family
  (the likely source), with checks: ties, duplicated segments, two parents (recombination), same chromosome.

## Run it
Install once, from this directory:
```bash
mamba env create -f environment.yml && mamba activate ltrkin
pip install --no-deps .
pytest                      # optional check: 56 tests, ~5 min
```
Then:
```bash
# reads -> sorted, indexed BAM, one per sample (map-ont for ONT reads)
minimap2 -ax map-hifi ref.fa reads.fq.gz | samtools sort -o s1.bam && samtools index s1.bam
ltrkin genotype -r ref.fa -a ltr_rts.gff3 -o out -t 8 s1.bam [s2.bam ...]
ltrkin source   -r ref.fa -a ltr_rts.gff3 -g out.genotypes.tsv -o src -t 8      # optional
```
- **Annotation:** GFF3 from LTRquest, EDTA, LTR_retriever, LTRharvest or DANTE_LTR (elements with both LTRs).
- **Reads:** keep supplementary alignments (minimap2's default); a primary-only BAM works but loses about one point.
- **Options:** `--ploidy` (default 2; use 1 for inbred lines or reads of one haplotype), `--min-mapq` (20),
  `-t` (threads). Nothing else to tune: read error, coverage, annotation precision and genotype frequencies are
  learned from each sample.

## How good is it
Truth: haplotype-resolved assemblies of two outcrossing plants, giving each element's state on the other haplotype.
Ranges span the two reference haplotypes.

| | PacBio HiFi (*Cardamine amara*) | ONT (*Medicago sativa* subsp. *falcata*) |
|---|---|---|
| genotypes correct, 10x / 20x / 40x | 89-91% / 93-94% / 94-96% | 88-89% / 91-92% / 93-94% |
| same at 20x: Sniffles2 / kanpig | 54-55% / 46-47% | 50-51% / 34-35% |
| new insertions (F/E) at 20x: recall / precision | 0.96-0.97 / 0.97-0.98 | 0.94-0.95 / 0.93-0.94 |
| elements on one haplotype (F/N) at 20x: recall | 0.89-0.92 | 0.87-0.89 |
| calls with GQ >= 20 at 20x: correct (share of sites) | 97-98% (65-70%) | 95% (62-64%) |
| presence/absence in another individual, 10-20x: calls correct | 99.3-99.9% | 97.8-99.5% |
| run time, memory (8 threads) | 1.5 min, 0.14 GB (5,839 elements, 60x) | 16.5 min, 0.33 GB (24,203 elements, 40x) |

- Use `pav` for presence/absence and `genotype` with `gq` for zygosity. Read GQ as a ranking: calls with GQ >= 20
  are 95-98% correct, not 99%.
- Harder cases: (1) where the two haplotypes are identical (inbred lines, identical-by-descent stretches), one vs
  two copies rests on read depth and is uncertain below ~30x; (2) highly divergent haplotypes may not align to the
  reference at all; (3) only insertions present in the reference can be genotyped.
- `source` reports the nearest fixed copy, a proxy for the parent (the true parent may be unsampled or lost).

Fig. 1 and the full benchmark (more depths, other species, robustness): [docs/benchmark_v0.2.md](docs/benchmark_v0.2.md).

## Outputs
| file | content |
|---|---|
| `out.genotypes.tsv` | one row per element x sample: `genotype`, `gq`, `pav` (present / absent / solo / uncertain), read counts per allele, `flags` |
| `out.vcf.gz` | the same calls as VCF (indexed): ALT `<DEL:ME:LTR>` = empty site, `<DEL:ME:SOLO>` = solo LTR, GT `.` = null haplotype |
| `src.sources.tsv` | each new copy with its likely source copy: divergence, ties, age, shared mutations, two-parent test, flags |
| `src.copies.tsv` | every element: new / fixed / other, LTR divergence (age), nearest relatives |
| `src.locality.tsv` | per clade and family: do new copies sit on their source's chromosome, against a null? |

Selected columns of `out.genotypes.tsv` (*C. amara*, 20x HiFi; IDs shortened):
```
element_id   chrom       start    end      sample  n_F  n_S  n_E  genotype  gq  pav      flags
LTRRT_00001  CM152318.1  100325   115311   Camara  67   0    0    F/F       86  present  PASS
LTRRT_00003  CM152318.1  391525   396948   Camara  23   0    16   F/E       99  present  PASS
LTRRT_05201  CM152318.1  8646047  8662432  Camara  22   20   0    F/S       99  present  PASS
LTRRT_00007  CM152318.1  1482205  1486961  Camara  19   0    0    F/N       9   present  PASS
```
`n_F`, `n_S`, `n_E`: reads showing each allele. Every column and flag: [docs/outputs.md](docs/outputs.md).

## More
How it works: [docs/DESIGN.md](docs/DESIGN.md) · changes: [CHANGELOG.md](CHANGELOG.md) · benchmark code and how to
rerun it: [benchmark/](benchmark/README.md).
