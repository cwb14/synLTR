# Task 11 Part B: SIM_RESULTS.md and the misses (Task 11 Steps 2-3)

Plan 3 benchmarks LTRpav (presence/absence genotyping of LTR-RT insertions, and the admixture analyses built on it)
against LTRmix on 144 simulated runs at 50 Mb, plus 3 LTRquest-annotated runs. Every run has now been rescored with
the final scoring code (Task 11 Step 1; `sim/rescore.log`), and `sim/tables/` holds summarize.py's tables plus
ltrmix_absent.py's `ltrmix_absent.tsv` and `pa_readings.tsv`. This dispatch writes the results and investigates each
miss. It changes no code, bar or rule, and edits nothing in the repo. DESIGN edits, any default change and the commit
are Part C, a later dispatch.

Paths: `P=/data2/chris/maize_introgression`, `SIM=$P/benchmark_pav/plan3/sim`.

## Read first
- `task-11-brief.md`: your requirements, Steps 2-3 (sections 1-11 of SIM_RESULTS.md, and the misses).
- `task-11-rulings.md`: R1-R4 and "Rule 5 with no calls". These bind as much as the brief and override it where the
  two differ.
- `$SIM/RULES.md`: pre-registered; read-only; sha256 4111826d...a293. Every bar is judged by it as written.
- `$SIM/memo.md`: the scoring sections, the readings Task 9 fixed for summarize (ledger lines on rule 5 anydecoy, the
  rule 7 false call, the rule 8 bootstrap CI, LTRmix's right sister pair), and the "Scoring fixes after the Part P
  smoke test" entry.
- `$SIM/tables/*.tsv` and their header comments.
- `$SIM/direction_predictions.tsv`.
- `$SIM/pilot/realism.tsv` and `$SIM/tables/realism.tsv`.
- These, in this directory: `task-11p-report.md` (sections on ltrmix_absent and the PA readings),
  `task-11p-review.md`, and `task-8-report.md` (the realism readout; read by grep, it is long).

## Write
1. **`$SIM/SIM_RESULTS.md`**, sections 1-11 as Step 2 lists them.
   - Every bar reads PASS or MISS by RULES.md, with its numbers, n and the table it comes from.
   - A bar the data cannot decide is a MISS with the reason ("not demonstrated: ..."), never a silent NA. One example
     is a calibration reading whose statistic is NA in most nulls.
   - Rule 5's precision clause with 0 informative pairs reads "PASS (vacuous: 0 informative pairs)".
   - Present the presence/absence head-to-head from `pa_readings.tsv`: the binary truth (present P/S/T, absent E/D/O,
     G excluded and counted) first, strict E-only beside it. Label genotype.tsv's "ltrmix pairs" rows as the strict
     E-only reading.
   - LTRmix's absent-but-present calls: the library-first breakdown (orthology miss, annotation dropout, S/T not
     annotated). The pilot's "62% truth-present" was 62% not-E; the truly present share is about 38%.
   - Section 10 names each realism gap, states its effect on the results, and states once, plainly, that simulated
     power is optimistic for the real data beyond the locus-count projection. The gaps:
     - resolved fraction 0.74-0.77 against main3's 0.46;
     - U 1.5% against 14.6%;
     - 3.6-4x the informative loci per Mb;
     - G calls 5.5-6.1% against 0.02%;
     - the K of outgroup-shared elements 0.095 against 0.060;
     - more nesting;
     - the 28.6% insertion deficit in replacing sequence.
   - Section 11 (decision 11): `nodonor`'s null count and power on their own. Say that Task 14 adds the genus `zd`
     case, that the rule is unchanged, and that the user decides after Plan 3.
   - Report direction (section 5) exactly as rule 7 reads. State the predictions, the observed codes, the posctl
     confirmation, false calls (default and bottleneck), ptlike, and D_dir against its null.
   - Close with CLAUDE.md's headline test: one sentence on the process or rule a geneticist working on another
     organism would care about, then the mechanism, how general it is (tested or assumed), and what it predicts. A
     method-validation outcome is honest here; say so plainly, and never present a null as a finding.
   - Save the file after each section, so an interrupted run can resume from the last saved section.
2. **The LTRquest runs (section 7).** Write `$SIM/lq_compare.py` and its output `$SIM/tables/lq_compare.tsv`. The
   script compares each `lq/<name>` with `runs/<name>` from their eval.json and eval_ltrmix.json:
   - LTRpav genotype precision (P, E) and the unmatched elements;
   - D_pav and its Z;
   - the roles;
   - painting AUROC;
   - LTRmix's four D;
   - annotation counts (LTRquest elements matched, missed and extra against truth, at the eval's 10-bp slop).

   Read-only on the run directories. Note in the table that ltrmix_absent does not attribute these runs.
3. **`$P/benchmark_pav/dead_ends.md`.** Add a dated section "2026-11-14 Plan 3 simulation benchmark (Task 11)", with
   one entry per MISS in the file's existing format: What, Result, Evidence, Cause tested, What would change it.
   - Investigate each miss with truth D and the per-pair genotype scores before writing its cause.
   - Mark a cause you did not test as untested.
   - Never change a bar or a rule. Untested causes of the s and D gaps (section 9) become Plan 4 leads; list them in
     SIM_RESULTS.md.

## Constraints
- Nothing in the repo; no edit to RULES.md, the scoring scripts, run_one.sh, run_grid.sh, lq/run_lq.sh or
  common/env.sh; never write in `runs/` or `lq/`.
- Env ltrpav via `. $P/benchmark_pav/plan3/common/env.sh`. Set `NUMPY_MADVISE_HUGEPAGE=0 OMP_NUM_THREADS=1
  OPENBLAS_NUM_THREADS=1`. Never run python with -I or -E. Never install packages.
- The server is busy with detached jobs: at most 8 threads and 15 minutes per probe, and never kill a process.
- No figures: Plan 4 draws them. If a quick working plot would settle a question, load the `making-figures` skill
  first and keep it in your scratch directory.
- Writing: American English. Plain declarative sentences a biologist follows; define any technical term on first
  use. Simple statistics with every claim (n, mean +- SD or 95% CI, the test). No AI attribution anywhere.
