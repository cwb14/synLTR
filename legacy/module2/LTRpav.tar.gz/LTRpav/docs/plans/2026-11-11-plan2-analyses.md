# LTRpav Plan 2: Analyses from the PAV Matrix Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn a finished genotyping run into admixture results. `ltrpav-stats`, `ltrpav-paint` and `ltrpav-plot` (and
`ltrpav run`, which now ends with them) produce relationships and roles, trio tests with age strata and an f4-ratio,
decoy-calibrated painting, dating, an exploratory direction test, inversions, mechanisms and one overview figure. The
last task then answers, as a preliminary result on B73/TIL18/TIL01 + *Z. diploperennis*, whether LTR-RT PAVs could have
found the published *mexicana* introgression into maize.

**Architecture:**
- A read-only loader turns the run directory into numpy arrays (`Catalog`). It reads `loci.tsv`,
  `pairs/*.calls.tsv.gz`, `work/elements/`, `qc.tsv`, the samples sheet and the FASTA indexes.
- The catalog holds two kinds of state side by side:
  - `loci.tsv`'s merged state of each genome;
  - each annotated genome's own calls, from its pair files.
- A statistic with a discovery rule (DESIGN 7.1) reads only the discovering genome's own calls, through one discovery
  function (`relations.discover`). Merged states serve the any-discovery descriptions.
- Each analysis module is a set of functions of the catalog. They return `StatRow`s, findings lines and the module's own
  files, and each row declares its counted loci in its `loci` column.
- All Plan 2 code lives in two packages: `ltrpav.analysis` (modules, constants, commands) and `ltrpav.plot` (the
  figure). Neither is part of the engine.
- Analysis stage keys use the analysis packages' own fingerprint, plus the checksums of the engine outputs they read. An
  engine edit therefore reruns an analysis only when those outputs change, and an analysis edit never touches an
  engine stage key.
- Two checkpointed stages (stats, paint) write their parts under `work/analysis/`, and `report.assemble` rebuilds
  `stats.tsv` and `findings.txt` from the parts that exist. A third stage draws the figure. The commands run alone, or
  inside `ltrpav run` through one hook in the engine's `cli.py`.

**Tech Stack:**
- Python >= 3.10 (env 3.12), numpy, numba (HMM forward-backward), pysam (`seqio.Fasta`).
- scipy: binomial tests, chi2, incomplete gamma, Nelder-Mead.
- matplotlib: the figure.
- LASTZ, through `ltrpav.localign.align_window` with the engine's `DEFAULT_BACKEND`: the identity layer only.
- pytest, ruff.

**Spec:** `/data2/chris/maize_introgression/LTRpav/docs/DESIGN.md` (approved 2026-11-10), as on `plan1-final-fixes`.
Section 7 is the scope; sections 6, 1-3, 8 and 10-14 also bind. Literature: `docs/lit_review.md`.

LTRmix, read-only, is the port source:
- `/data2/chris/maize_introgression/LTRmix/ltrmix.py`: `jackknife` (l. 893), `set_block_size` 919, `_fb_cat` 936,
  `fit_hmm_cat` 999, `tracts_from_post` 1033, `Trio._hmm` 1328 (q-values 1359-1375), `Trio.fratio` 1430, and the role
  and second-donor rules in `Trio.__init__` (1076) and `main` (1624).
- `benchmark/scripts/rate_free_split.py`: `nll`, `fit`, `MG_MAX`, `fit_mix` (l. 68), `pred_cdf` (l. 85).
- `benchmark/scripts/eval_real.py`: the template for Task 12's comparison.
- Its main3 results are in `/data2/chris/maize_introgression/LTRmix/benchmark/results/main3/`.

Reviews: `.superpowers/sdd/2026-11-10-plan1-genotyping-engine/plan2-review.md` (review and re-review) and
`.superpowers/sdd/2026-11-11-plan2-analyses/preflight-rulings.md` (pre-flight rulings). Both are applied below.

**Engine API this plan relies on** (`plan1-final-fixes` with the per-stage fingerprint ruling):
- `ltrpav.checkpoint.package_fingerprint(*modules_or_packages: str) -> str`;
- `ltrpav.checkpoint.stage_key(stage, inputs, params, fingerprint=None)`;
- `file_checksum`, `is_done`, `mark_done`, `clear_done`;
- `ltrpav.cli._execute`, `_options`, `CliError`; `ltrpav.localign.align_window`;
- `ltrpav.constants.DEFAULT_BACKEND` (`"lastz"`), `MIN_SEG`, `SLOP_TSD_MULT`, `TSD_DEFAULT`, `WINDOW_PAD`.

**Plan series:**
1. Engine, pair simulator, bake-off, QC.
2. This plan: analyses and the overview figure.
3. Population simulator and benchmark (DESIGN 10.2-10.4).
4. Head-to-head, report, release.

**Builder calls made here.** Task 1 records them in DESIGN.md section 12. The full list, with reasons and what changes if
one is wrong, is in `.superpowers/sdd/2026-11-10-plan1-genotyping-engine/plan2-draft-summary.md`.
1. Analyses read the engine's outputs as data and never change their formats (`CALL_COLUMNS`, `loci.tsv`); the catalog
   also reads each discoverer's own calls from the pair files.
2. The sequence-identity layer realigns orthologous copies with the engine's own aligner (`align_window` with
   `DEFAULT_BACKEND`, LASTZ) and counts substitutions in the donor copy's LTR columns. The pair files keep no LTR site
   counts, so DESIGN's "free from the local alignment" becomes "same aligner, one more pass".
3. `stats.tsv` is long format: `layer test scope stratum statistic value se z n loci note`. `loci` declares the counted
   loci of each row (DESIGN 7.1).
4. Painting files are one per recipient, with `sister` and `donor` columns. Two files are added: `decoy_tracts.<S>.bed`
   and `decoy_posterior.<S>.tsv`, the control the figure draws.
5. D_pav's primary count follows DESIGN exactly, all read from D's own calls, at any tier:
   - loci discovered in the donor D, with D present;
   - R and S resolved;
   - every outgroup E.

   Three check strata are reported beside it: high tier only (D's call tiers), nested clusters collapsed, no outgroup
   filter.
6. Painting sets aside loci an outgroup carries (P/S/T in the recipient's own call), and keeps loci where the outgroup is
   missing.
7. The target-decoy scale is the ratio of informative loci (RD+RS against SD+SR), not of all elements (LTRmix).
8. An inverted block is resolved loci (x order) whose y positions run against the seqid pair's dominant direction.
   Reversed runs are merged across a few discordant loci. `INV_MIN_LOCI` = 5 is a named heuristic.
9. Direction:
   - DFOIL-alt with its own sign table. The full-DFOIL table does not apply once single-derived patterns are dropped;
     dfoil.py's dfoilalt mode reuses it.
   - Jackknife Z, with |Z| >= 3 as significant.
   - Each DFOIL pattern pair is counted on loci discovered by a genome present in both patterns.
   - D_dir is reported but not read as direction: unequal Ne alone drives it.
   - "Sister taxon" = every ingroup genome outside the two taxa.
10. Ingroup E calls at loci an outgroup carries give an upper bound on the combined rate of ingroup false E and outgroup
    false presence. Deep lineage sorting and parallel insertions also produce them.
11. Fallback discovery (D unannotated) uses only annotated ingroup genomes that split with D from the sisters, by the
    four-point condition on PAV distances. This is a controller ruling of 2026-11-11, made while the user was away: a
    discovery genome inside the sisters' clade biases the null D_pav (+0.35, Z +6.7 in a coalescent probe). The user is
    to confirm it.
12. Plan 2 code lives in `ltrpav.analysis` and `ltrpav.plot`; engine modules are never edited for Plan 2's needs,
    except one hook in `cli.py` so that `ltrpav run` ends with the analyses.
    - Analysis constants and the commands `ltrpav-stats`, `ltrpav-paint` and `ltrpav-plot` live in the analysis
      package.
    - Analysis stage keys use `stage_key(..., fingerprint=analysis_fingerprint(stage))`, where `analysis_fingerprint` =
      `package_fingerprint("ltrpav.analysis", *closure)` over the import closure of every engine module any analysis module
      imports, with ltrpav/cli.py and ltrpav/__init__.py as the boundary (Task 10 as built); the plot stage adds `"ltrpav.plot"`.
    - The analysis commands read a finished run as data and never run an engine-fingerprint check such as
      `_check_pair_files`.

## Global Constraints

- Branch `plan2-analyses`, cut from `plan1-engine` after the controller fast-forwards `plan1-engine` to the reviewed
  head of `plan1-final-fixes`. Commits are local; never push.
- The `ltrpav` and `ltrpav_bench` envs import this working tree (editable installs). Before switching branch or editing,
  `pgrep -af 'ltrpav|run_variant|bakeoff'` must list no job; while one runs, work in a `git worktree`.
- The user is the sole author:
  - pyproject's `authors` entry stays as it is;
  - no AI attribution in any file, commit message or trailer;
  - commit with the global git identity; never set author or committer.
- Engine modules stay untouched. All Plan 2 code, constants and commands go in `src/ltrpav/analysis/` and
  `src/ltrpav/plot/`. The single exception is Task 10's hook in `src/ltrpav/cli.py`. `pyproject.toml`,
  `environment.yml`, the lock file and `docs/` are not engine modules.
- Analysis stage keys never include the engine fingerprint, and the analysis commands never run engine-fingerprint
  checks (`_check_pair_files`). Task 12 therefore runs them on main3 (engine 7d71073) without re-genotyping.
- Python `>=3.10` (CI 3.10, 3.12, 3.13). The only new runtime dependencies are `scipy>=1.11` and `matplotlib>=3.8`, added
  to pyproject, `environment.yml` and the lock file.
- The lock file is refreshed by commit 84c8088's portable procedure (Task 1), never by a raw `mamba env export`.
- Analyses run in the `ltrpav` env only. `ltrpav_bench` imports this tree but has neither scipy nor matplotlib, so every
  import of scipy, matplotlib, `ltrpav.analysis` modules and `ltrpav.plot` sits inside the stage functions.
  `import ltrpav.cli` and `import ltrpav.analysis.cli` must work without scipy or matplotlib. There, an analysis stage
  (`ltrpav run` included) ends with one CliError line and exit 1, and the engine's outputs are kept.
- The suite command is `python -m pytest -W error -m "not slow"`, with no extra `-q`: pyproject's addopts already has
  one. A slow test runs once, in the task that adds it, as `python -m pytest -W error <its file>`. CI's
  `pytest -m "not slow"` is unchanged.
- `NUMPY_MADVISE_HUGEPAGE=0` before numpy: the package sets it; scripts outside the package export it.
- Never load a genome:
  - FASTA only through `seqio.Fasta.fetch` and `lengths`;
  - `loci.tsv` and the pair files streamed line by line.
- Input formats stay unchanged:
  - `loci.tsv` (`outputs/tables.py`);
  - `pairs/<A>__<B>.calls.tsv.gz` (`classify.CALL_COLUMNS`);
  - `work/elements/<label>.tsv` (`elements.ELEMENT_COLUMNS`);
  - `qc.tsv`.

  Analyses never write into `pairs/` or `work/elements/`.
- States (DESIGN 5.4):
  - P/S/T are present; E is absent (ancestral); D/O/G/U are missing.
  - A missing state never counts as absent in a sharing statistic and is never imputed.
  - Every test reports the resolved fractions of its genomes, through `stats.resolution`.
- A statistic with a discovery rule reads every other genome's state from the discovering genome's own calls
  (`relations.discover`, `cat.pcls_by(gstar, label)`), never from `loci.tsv`'s merged state. In `loci.tsv`, a member
  genome is P/annot whatever the discoverer's call says, and a member's own calls give the other genomes extra chances
  to be resolved. Merged states therefore let annotation depth into the count (DESIGN 7.1). Merged states remain for the
  any-discovery descriptions only: run summary, distances, the sharing counts that pick the sister pair, Dollo
  placement, inversions, and n(X->Y) and 4-LIST (declared `disc=any`).
- Every `StatRow` names its counted loci in `loci`: the discovery genome(s), the genomes required present or resolved, and
  the outgroup rule.
- Nothing depends on the anchoring route. Nothing in `src/` names *Zea*, maize, chromosome names or genome sizes;
  maize-specific code lives only in `benchmark_pav/`.
- Thresholds live in `ltrpav/analysis/constants.py` with a one-line reason. None is chosen against ELAI, the papers or
  LTRmix results, and every remaining heuristic is named as one in `findings.txt`.
- User-facing coordinates are 1-based inclusive, BED 0-based half-open. `Fasta.fetch` is 0-based half-open, so a
  1-based `start..end` is fetched as `(start - 1, end)`. Output order is deterministic; randomness is seeded.
- CLI: argparse, help under 40 lines, `-v`. Exit status as Plan 1: 0; 1 with one line "error: ..."; 2 for usage.
- Real-data jobs:
  - <= 64 threads and <= 250 GB;
  - anything over 15 min runs as `setsid -f nohup ... > log 2>&1 < /dev/null`, PID verified (SID = PID, PPID 1);
  - never write into `benchmark_pav/bakeoff/`, `run/`, `inputs/`, `benchmark/` or `LTRmix/`.
- Every figure: load the `making-figures` skill (Skill tool) first and follow it.
- American English in code, docs and messages.

## Review Focus

1. **Genomes that share seqid names** ("chr1" in every genome, the common case). Block ids, inversion blocks, painting
   and the figure must key on (genome, seqid index), never on the name alone. Test: Task 10 `test_stats_shared_seqids`.
2. **Annotations without K2P** (BED; GFF3 without `ltr_identity`). Age strata, the gradient and youngest-per-tract are
   skipped with one findings line each, never an error or a table of nans. Tests: Task 4 `test_age_strata_without_k`,
   Task 6 `test_tracts_without_k`.
3. **A distant genotype-only outgroup missing at most loci** (U/D/O/G in D's calls). "Outgroup must be E" removes
   those loci; `findings.txt` must say how many, and the `no_outgroup_filter` stratum stands beside the primary D. Test:
   Task 4 `test_outgroup_mostly_missing`.
4. **Hundreds of small scaffolds** with one or two loci each. No crash in the jackknife or the HMM (chains of one locus),
   and the figure draws only the largest sequences. Tests: Task 6 `test_paint_many_scaffolds`, Task 11
   `test_overview_many_scaffolds`.
5. **Fewer than three ingroup genomes.** Analyses that need a trio are skipped with their reason, the rest run, and the
   figure still renders. Tests: Task 10 `test_run_two_genomes`, Task 11 `test_overview_two_genomes`.

## File Structure

```
src/ltrpav/
  cli.py              (modify, Task 10 only) the hook: `ltrpav run` gains --trio and --identity and ends with the
                      analyses
  analysis/           not part of the engine; its own fingerprint
    __init__.py       docstring only (imports nothing heavy)
    constants.py      analysis constants, one-line reason each
    catalog.py        run directory -> Catalog: merged states and each discoverer's own calls; age bins; cluster keys
    stats.py          StatRow, stats.tsv I/O, block size and ids, jackknife, u95, resolution rows, Findings
    relations.py      run summary, discovery (discover, four-point fallback), sharing, KKSC symmetry, PAV distances,
                      NJ tree, outgroup conflicts, sister pairs
    trio.py           roles, D_pav and strata, age gradient, nested collapse, f4-ratio
    inversions.py     inverted blocks per genome pair, inversions.tsv, block membership
    paint.py          classes, HMM (numba), EM, tracts, target-decoy q, resolution, painting files
    direction.py      n(X->Y), DFOIL-alt, 4-LIST pattern counts
    mechanisms.py     pair-file reads, states by family and age, O and D split by their junctions, absence events,
                      Dollo placement, missingness
    identity.py       optional sequence-identity layer: self and pair LTR counts, rate-free split (isolation and
                      mixture fits), younger-than-split counts
    report.py         stage keys and markers, parts, assembly of stats.tsv and findings.txt, run_stats, run_paint
    cli.py            ltrpav-stats, ltrpav-paint, ltrpav-plot; run_analyses (called by the engine hook)
  plot/               not part of the engine; fingerprinted with the analysis package
    __init__.py
    overview.py       overview.png, overview.pdf (figure + short + long legend), overview_numbers.tsv
tests/
  conftest.py         (modify) session fixture toy_fastas
  catalog_toy.py      toy run directories written through Plan 1's writers (exact and simulated)
  test_catalog.py test_stats_core.py test_relations.py test_trio.py test_inversions.py test_paint.py
  test_direction.py test_mechanisms.py test_identity.py test_cli_analysis.py test_overview.py
benchmark_pav/main3/  (outside the repo) run_analyses.sh, analyses.log, analyses.done, compare_papers.py,
                      prelim_papers.tsv, PRELIM.md
```

Run-directory outputs added:
- `stats.tsv`, `findings.txt`;
- `tracts.<R>.bed`, `posterior.<R>.tsv`, `decoy_tracts.<S>.bed`, `decoy_posterior.<S>.tsv`;
- `inversions.tsv`, `mechanisms.tsv`, `identity.tsv` (with `--identity`);
- `overview.png`, `overview.pdf`, `overview_numbers.tsv`.

Stage parts and done markers go in `work/analysis/`.

**Array conventions:**
- An argument named `rows`, `cand` or `keep` is a boolean mask over the catalog's n loci.
- An index array (int64) is named `idx`, and its order is stated where it is defined.
- `gstar` is an int16 array (n,) holding, for each row, the catalog index of the genome whose own calls the row is read
  from (-1 = none).
- A sequence is keyed as (genome, fai index) everywhere; names appear only in output files.

**Test conventions:**
- Every test below is complete code with its expected values.
- Hand fixtures use `loc()` (Task 1); `ToyRun.load()` returns the catalog.
- Values from a simulation give the seed. Where a count-level replica of the toy (the reviewer's `rr_toy.py`) is
  quoted, the implementation's draws differ, so the test asserts the stated bound, not the replica's value.
- A seeded statistical test that fails is investigated, never fixed by changing the toy, the seed or the bound. The
  investigation reruns seeds 6-25: |Z| >= 3 in at most 1 of 20 (DESIGN 10.2's null bar) clears the model, and anything
  more is a defect.
---

### Task 1: Foundations — dependencies, constants, catalog loader, toy runs

**Files:**
- Modify: `pyproject.toml` (dependencies), `environment.yml`, `environment.lock.yml`, `tests/conftest.py`,
  `docs/DESIGN.md` (section 12)
- Create: `src/ltrpav/analysis/__init__.py`, `src/ltrpav/analysis/constants.py`, `src/ltrpav/analysis/catalog.py`,
  `src/ltrpav/plot/__init__.py` (empty docstring), `tests/catalog_toy.py`, `tests/test_catalog.py`

**Interfaces:**
- Consumes:
  - `outputs.tables.write_loci_tsv`, `write_qc`;
  - `loci.Locus`, `GenomeState`;
  - `elements.Element`, `make_eid`, `read_elements`, `write_elements`;
  - `classify.CALL_COLUMNS`, `genotype.tsv_field`;
  - `samples.Sample`, `read_samples`, `PAIR_SEP`, `seqio.Fasta`;
  - `checkpoint.file_checksum`, `package_fingerprint`, `stage_key`, `STAGE_MODULES` (the engine's per-stage module
    sets).
- Produces, `analysis/catalog.py`:

```python
STATE_CODE = {"P": 1, "S": 2, "T": 3, "E": 4, "D": 5, "O": 6, "G": 7, "U": 8}   # 0 = no call
TIER_CODE = {".": 0, "low": 1, "medium": 2, "high": 3, "annot": 4}
FLAGS = ("inv", "nestB", "host_empty", "inherit", "tsd_match", "solo_tsd", "adjacent", "small_ins", "filler",
         "conflict", "annot_conflict", "no_call")
FLAG_BIT = {f: 1 << i for i, f in enumerate(FLAGS)}   # other flag words are ignored
AGE_LABELS = ("K=0", "0<K<0.01", "K>=0.01")
class AnalysisError(ValueError): ...
@dataclass
class Catalog:
    outdir: Path; samples: list[Sample]; sheet: Path; sheet_sha: str    # sheet path and its sha256
    labels: tuple[str, ...]; ingroup: tuple[str, ...]; outgroups: tuple[str, ...]   # sheet order; role "outgroup"
    annotated: dict[str, bool]; groups: dict[str, str | None]
    seqids: dict[str, tuple[str, ...]]; lengths: dict[str, np.ndarray]   # fai order, from seqio.Fasta (work/fai cache)
    # loci.tsv, merged across discoverers: any-discovery descriptions only
    lid: np.ndarray                    # (n,) str, loci.tsv order
    state: np.ndarray                  # (n, G) uint8 STATE_CODE
    tier: np.ndarray                   # (n, G) uint8 TIER_CODE
    seq: np.ndarray                    # (n, G) int32 fai index; -1 = no coordinates
    start: np.ndarray; end: np.ndarray # (n, G) int64, 1-based inclusive; 0 = none
    strand: np.ndarray                 # (n, G) int8: +1, -1, 0 (unknown or none)
    k: np.ndarray                      # (n, G) float64: a member's K2P, else nan
    flags: np.ndarray                  # (n, G) uint32 FLAG_BIT mask
    member: np.ndarray                 # (n, G) bool: the genome's annotation holds the locus (its discovery)
    eid: np.ndarray                    # (n, G) object: the member eid, else None
    family: np.ndarray; superfamily: np.ndarray; tsd: np.ndarray   # (n,) object, None = unknown (loci.tsv columns)
    length: np.ndarray; ltr_len: np.ndarray       # (n,) int64 (loci.tsv `length`, `ltr_len`)
    top: dict[str, dict[str, str]]     # genome -> member eid -> eid of its outermost annotated ancestor (itself at level 0)
    # each annotated genome A's own calls: pairs/<A>__<B>.calls.tsv.gz joined on eid[:, g(A)] (extra members ignored);
    # A's own column holds its member element (P, tier high); rows where A has no member hold "no call"
    proj: dict[str, np.ndarray]        # A -> (n, G) uint8 STATE_CODE of A's call into each genome; 0 = no call
    ptier: dict[str, np.ndarray]       # same shape: TIER_CODE of those calls
    pseq: dict[str, np.ndarray]        # same shape: int32 fai index of the call's site in that genome; -1 = none
    pstart: dict[str, np.ndarray]; pend: dict[str, np.ndarray]   # same shape: int64, 1-based inclusive; 0 = none
    pstrand: dict[str, np.ndarray]     # same shape: int8, the element's strand at the site (b_strand turned as loci.py does)
    def g(self, label: str) -> int
    def cls(self, label: str) -> np.ndarray   # (n,) int8 from the merged state: 1 = P/S/T, 0 = E, -1 = D/O/G/U
    def mid(self, label: str) -> np.ndarray   # (n,) float64 (start + end) / 2 of the merged site; nan without one
    def pcls(self, disc: str, label: str) -> np.ndarray   # (n,) int8 from proj[disc]: 1 P/S/T, 0 E, -1 D/O/G/U or no call
    def pcls_by(self, gstar: np.ndarray, label: str) -> np.ndarray    # (n,) int8: row i read from genome gstar[i]; -1 if < 0
    def ptier_by(self, gstar: np.ndarray, label: str) -> np.ndarray   # (n,) uint8: likewise from ptier; 0 if gstar[i] < 0
    def proj_site(self, gstar: np.ndarray, label: str) -> tuple[np.ndarray, np.ndarray]
        # (fai index, mid) of label's site in row i's call from genome gstar[i]; (-1, nan) where there is none
def load_catalog(outdir: Path, samples: list[Sample], sheet: Path) -> Catalog
def age_bin(k: np.ndarray) -> np.ndarray     # int8: 0 K == 0; 1 0 < K < AGE_EDGES[1]; 2 K >= AGE_EDGES[1]; -1 nan
def cluster_keys(cat: Catalog, gstar: np.ndarray, rows: np.ndarray) -> np.ndarray
    # object, one per selected row (catalog order): (label of gstar, top eid of that genome's member element)
```

- Produces, `analysis/constants.py`: the block in Step 5.
- Produces, `tests/catalog_toy.py`:
  - `ToyLocus`, `ToyRun` (with `.load() -> Catalog`), `loc`, `write_run`, `simulate_run`, `dmat`, `read_tsv`,
    `GENOMES`, `TRACTS` (Step 3);
  - the conftest fixture `toy_fastas` (session-scoped directory of N-only FASTAs, written once per seqid layout).

- [ ] **Step 1: Branch and environment.**
  - Check the preconditions:
    - `plan1-engine` is the reviewed head of `plan1-final-fixes`;
    - `pgrep -af 'ltrpav|run_variant|bakeoff'` prints nothing;
    - `git status` is clean.
  - Branch: `git checkout -b plan2-analyses plan1-engine`.
  - Run `mamba install -n ltrpav -c conda-forge scipy matplotlib`.
  - Add `scipy` and `matplotlib` to `environment.yml`, and `scipy>=1.11`, `matplotlib>=3.8` to pyproject `dependencies`.
  - Refresh the lock by commit 84c8088's portable procedure:

```bash
mamba env export -n ltrpav | sed -e '/^  - pip:$/,$d' -e '/^prefix:/d' > environment.lock.yml
echo '# ltrpav itself is not locked: install it from this repository into the environment (pip install -e .)' \
  >> environment.lock.yml
! grep -qE '^prefix:|ltrpav==' environment.lock.yml && grep -qE '^  - scipy=' environment.lock.yml
```

  - Leave `ltrpav_bench` untouched (Global Constraints).

- [ ] **Step 2: Write the failing tests** (`tests/test_catalog.py`)

```python
def test_load_roundtrip(tmp_path, toy_fastas):
    run = write_run(tmp_path, [
        loc(10_001, "R:P* S:E D:P* O:E", k=0.0, calls={("D", "S"): "U"}),
        loc(20_001, "R:U S:P* D:P* O:P", k=0.02),
        loc(5_001, "R:P* S:D D:E O:E", seqid="chr2", k=None, length=6000, flags={"S": ["inherit"]}),
        loc(9_001, "R:P* S:P D:G O:U", seqid="chr2", parent=2)], fasta_dir=toy_fastas)
    cat = run.load()
    assert cat.labels == ("R", "S", "D", "O") and cat.outgroups == ("O",) and cat.ingroup == ("R", "S", "D")
    assert cat.sheet == run.sheet and len(cat.sheet_sha) == 64 and cat.tsd[0] == "ACGTA"
    assert cat.cls("S").tolist() == [0, 1, -1, 1] and cat.cls("D").tolist() == [1, 1, 0, -1]
    assert cat.member[:, cat.g("D")].tolist() == [True, True, False, False]
    assert cat.k[0, cat.g("D")] == 0.0 and np.isnan(cat.k[0, cat.g("S")])         # K only for members
    assert cat.flags[2, cat.g("S")] & FLAG_BIT["inherit"]
    assert cat.top["R"][cat.eid[3, cat.g("R")]] == cat.eid[2, cat.g("R")]         # nested in locus 2's element
    assert cat.lengths["R"].tolist() == [1_000_000] * 4
    # the discoverer's own calls: D's call into S is U although the merged S is E (R's call)
    assert cat.pcls("D", "S")[0] == -1 and cat.pcls("R", "S")[0] == 0 and cat.pcls("D", "D")[0] == 1
    assert cat.ptier["D"][0, cat.g("R")] == TIER_CODE["high"]                     # a member's call tier, never "annot"
    assert cat.pcls("S", "R")[0] == -1                                            # S has no member at locus 0: no call
    gstar = np.array([cat.g("D"), cat.g("D"), -1, -1], dtype=np.int16)
    assert cat.pcls_by(gstar, "S").tolist() == [-1, 1, -1, -1]
    seq, mid = cat.proj_site(gstar, "D")
    assert seq.tolist()[:2] == [0, 0] and mid[0] == pytest.approx(10_001 + 149 / 2) and seq[2] == -1

def test_missing_or_mismatched_run(tmp_path, toy_fastas):
    run = write_run(tmp_path, [loc(10_001, "R:P* S:E D:P* O:E")], fasta_dir=toy_fastas)
    loci = run.outdir / "loci.tsv"
    text = loci.read_text()
    loci.rename(run.outdir / "loci.bak")
    with pytest.raises(AnalysisError, match="ltrpav-merge"):
        run.load()
    loci.write_text(text)
    with pytest.raises(AnalysisError, match="X"):
        load_catalog(run.outdir, [replace(s, label="X") if s.label == "O" else s for s in run.samples], run.sheet)
    loci.write_text(text.replace("\tE\t", "\tQ\t", 1))
    with pytest.raises(AnalysisError, match="line 2"):
        run.load()
    loci.write_text(text)
    pair = run.outdir / "pairs" / "D__S.calls.tsv.gz"
    with gzip.open(pair, "wt") as fh:
        fh.write("eid\tstate\n")
    with pytest.raises(AnalysisError, match="D__S.*CALL_COLUMNS"):
        run.load()
    pair.unlink()
    with pytest.raises(AnalysisError, match="D__S"):
        run.load()

def test_age_bin():
    assert age_bin(np.array([0.0, 0.004, 0.01, 0.05, np.nan])).tolist() == [0, 1, 2, 2, -1]

def test_simulate_run_deterministic(tmp_path, toy_fastas):
    a = simulate_run(tmp_path / "a", seed=3, fasta_dir=toy_fastas)
    b = simulate_run(tmp_path / "b", seed=3, fasta_dir=toy_fastas)
    assert (a.outdir / "loci.tsv").read_bytes() == (b.outdir / "loci.tsv").read_bytes()
    cat = a.load()
    assert len(cat.lid) > 4000 and cat.member.any(axis=1).all()     # every locus has a discoverer
    with pytest.raises(ValueError, match="spacing"):                # 998_000 // 4000 = 249 bp < 2 x 150 bp
        simulate_run(tmp_path / "c", seed=3, n_per_seq=4000, fasta_dir=toy_fastas)

def test_analysis_edit_keeps_engine_keys(tmp_path):
    src = tmp_path / "src"
    shutil.copytree(Path(ltrpav.__file__).parent, src / "ltrpav", ignore=shutil.ignore_patterns("__pycache__"))
    prog = ("import ltrpav.checkpoint as c\n"                          # fresh process: fingerprints are cached
            "print(c.package_fingerprint('ltrpav.analysis'))\n"
            "print(' '.join(c.stage_key(s, {}, {}) for s in sorted(c.STAGE_MODULES)))\n")   # every engine stage key
    def prints():
        r = subprocess.run([sys.executable, "-c", prog], env={**os.environ, "PYTHONPATH": str(src)},
                           capture_output=True, text=True, check=True)
        return r.stdout.splitlines()
    a0, e0 = prints()
    with open(src / "ltrpav" / "analysis" / "catalog.py", "a") as fh:
        fh.write("\n# an edit to an analysis module\n")
    a1, e1 = prints()
    assert a1 != a0 and e1 == e0                                    # every engine stage key unchanged
    assert stage_key("stats", {}, {}, fingerprint=a0) != stage_key("stats", {}, {}, fingerprint=a1)
```

- [ ] **Step 3: Write `tests/catalog_toy.py`.**
  - `GENOMES = [("R", "taxR", None, True), ("S", "taxS", None, True), ("D", "taxD", None, True), ("O", "taxO",
    "outgroup", False)]`: label, group, role, annotated.
  - `TRACTS = [("chr1", 100_001, 400_000), ("chr2", 500_001, 800_000), ("chr3", 200_001, 500_000)]`.
  - `ToyLocus`, a dataclass:

```python
@dataclass
class ToyLocus:
    seqid: str; pos: int; states: dict[str, str]                       # loci.tsv (merged) states
    members: frozenset[str] = frozenset()
    k: float | None = 0.01; length: int = 150; ltr: int = 40           # LTRs = the first and last `ltr` bp
    family: str = "famA"; superfamily: str = "Gypsy"
    parent: int | None = None                                          # index of the host locus in the list
    flags: dict[str, list[str]] = field(default_factory=dict)          # genome -> extra flags
    evidence: dict[str, tuple[int, int, int]] = field(default_factory=dict)   # genome -> (dl, dr, b_ins) in pair files
    calls: dict[tuple[str, str], str] = field(default_factory=dict)    # (A, B) -> state of A's call into B
    strand: dict[str, str] = field(default_factory=dict)               # genome -> strand ("+" by default)
    wid: int | None = None                                             # pair-file wid; None: the locus index
```

  - **`loc(pos, spec, seqid="chr1", **kw) -> ToyLocus`.** `spec` is space-separated `G:X`, X a state letter, with `*`
    after it marking a member: `"R:P* S:E D:P* O:E"`. Other keywords go to `ToyLocus`.
  - **Default calls.** A member B's default call is `P`, tier `high` ("annot" is a `loci.tsv` tier, not a call tier); a
    non-member B's default call is its `loci.tsv` state.
  - **`dmat(pairs, default, labels) -> np.ndarray`:** a symmetric (G, G) distance matrix, 0 on the diagonal, `pairs`
    maps `(a, b)` to a distance, everything else `default`.
  - **`read_tsv(path) -> list[dict[str, str]]`:** a header-keyed reader; a leading `#` on the header is dropped.

  `write_run(tmp, loci, genomes=GENOMES, seqids=("chr1", "chr2", "chr3", "chr4"), seq_len=1_000_000, seq_lens=None,
  fasta_dir=None, fastas=None, inversion=None, prefix=False) -> ToyRun(outdir, sheet, samples, loci, truth={})` writes:
  - **FASTAs:** `<fasta_dir>/<layout>/<label>.fa`, N only, written once per layout. `seq_lens` overrides single seqids'
    lengths, and `fastas` (label -> path) overrides whole genomes with real sequences. `prefix=True` names each genome's
    seqids `<label>_<seqid>`.
  - **`samples.tsv`:** relative paths; annotation `ann/<label>.gff3` for annotated genomes (never opened), `.` otherwise.
  - **`loci.tsv`:** through `write_loci_tsv`, lids `L0000001...` in list order. Per genome:

    | case | GenomeState |
    |---|---|
    | member | `P`, tier `annot`, the locus coordinates, strand, `k`, flags |
    | other P/S/T | tier `high`, coordinates, strand |
    | E | tier `high`, the site `pos-5..pos-1`, strand, flags `tsd_match` (+ given) |
    | D | tier `medium`, coordinates |
    | O, G, U | tier `medium` for O, `.` for G and U; no coordinates |

    An `inversion=(label, seqid, a, b)` mirrors that genome's loci whose start lies in `[a, b]`: new start = `a + b -
    end`, new end = `a + b - start`, strand `-`.
  - **`work/elements/<label>.tsv`:** through `write_elements`, one `Element` per member:
    - `eid=make_eid(...)`;
    - LTRs = the first and last `ltr` bp; TSD `ACGTA`;
    - `k`, family and superfamily as given;
    - `parent` = the host locus's member eid in that genome, with `level` set.
  - **`pairs/<A>__<B>.calls.tsv.gz`:** for each annotated A and every other B, one `CALL_COLUMNS` row per A element
    (gzip, `tsv_field` values):
    - the call's state (defaults above, `calls` overrides), tier `high` (`.` for G and U), flags, the B site as in the
      table, `wid`;
    - reason `no_anchor` for U;
    - `dl dr b_ins` from `evidence`, else E `0 0 0`, D `300 0 0`, O `2 -1 500`;
    - `tsd_a` `ACGTA`; other evidence `.`.
  - **`qc.tsv`:** through `write_qc`: `annot_sensitivity 0.9` per annotated genome, and `skipped_malformed_coordinates
    2` for the first one (a reason the loaders emit).
  - **`manifest.json`:** `{}`.

  `simulate_run(tmp, *, seed, tracts=(), inversion=None, p_missing: float | dict[str, float] = 0.15, p_member: float |
  dict[str, float] = 0.9, n_per_seq=1500, k_known=True, prefix=False, fasta_dir=None) -> ToyRun` draws loci with
  `np.random.default_rng(seed)` and writes them with `write_run`. A dict for `p_missing` or `p_member` sets the listed
  genomes; the others keep the default.
  - **Layout:** `n_per_seq` loci per seqid on chr1-chr4 (1 Mb each), at `1001 + j * 998_000 // n_per_seq`, 150 bp each,
    LTRs 40 bp. Spacing must be >= 2 × the element length, else ValueError naming the spacing; `n_per_seq` <= 3000
    keeps 332 bp.
  - **Pattern** over (R, S, D), with the K values each drawn with probability 1/2:

    | pattern | p | K | O |
    |---|---|---|---|
    | 111 | 0.24 | 0.02 | E |
    | 110 | 0.15 | 0.01, 0.02 | E |
    | 101 | 0.06 | 0.004, 0.02 | E |
    | 011 | 0.06 | 0.004, 0.02 | E |
    | 100, 010, 001 | 0.11 each | 0.0, 0.004 | E |
    | old (all four present) | 0.16 | 0.03 | P |

  - **Inside a tract** (an R interval): R's presence := D's presence. A pattern left empty everywhere is dropped.
  - **True states:** a present genome is P (0.9), S (0.05) or T (0.05), drawn once per locus and genome; a member is P;
    an absent genome is E.
  - **Members:** each present annotated genome is a member with probability `p_member[g]`; a locus with no member is
    dropped.
  - **Calls**, the engine's behavior in miniature: each member A's call into each other genome B (members included)
    resolves to B's true state with probability `1 - p_missing[B]`, else U.
  - **`loci.tsv` merges like `loci.py`:**
    - a member is P/annot whatever the calls say;
    - a non-member takes the first resolved call among the members (sheet order), else U.
  - **K:** `k_known=False` sets K to None everywhere.
  - **Truth:** `{"tracts": tracts, "n_rd_tract": <D-private loci copied into R>}`.

  Add the session fixture `toy_fastas` to `tests/conftest.py`: one `tmp_path_factory` directory, shared.

- [ ] **Step 4: Run** `python -m pytest -W error tests/test_catalog.py`. Expected: FAIL (ImportError).

- [ ] **Step 5: Implement.**
  - `src/ltrpav/analysis/constants.py`, with its docstring "Analysis constants; each has a one-line reason. Nothing here
    is tuned to a dataset.":

```python
BLOCK_BP = 5_000_000       # jackknife block: >> LD in outcrossing grasses, hundreds of blocks per genome (LTRmix)
BLOCK_FRAC = 100           # or 1/100 of the smallest genome, so a small genome still gives ~100 blocks (DESIGN 7.3)
BLOCK_MIN = 10_000         # LTRmix's floor on the block size
AGE_EDGES = (0.0, 0.01)    # age bins by LTR-LTR K2P: identical, below 1%, older (DESIGN 7.3: few bins, by LTR differences)
Z_SIG = 3.0                # |Z| >= 3 counts as significant: the bar of every D test in DESIGN 10
P_WARN = 0.05              # conventional level of the sister-pair and lineage-sorting symmetry tests
RESOLVE_WARN = 0.1         # heuristic (LTRmix donor_resolved): warn when two genomes' resolved fractions differ by > 0.1
PI_MAX = 0.5               # donor-like fraction <= 1/2: a recipient more donor-like than sister-like is the donor's sister
BF_TRACT = 3.0             # tract loci need posterior odds >= 3x prior odds (Kass & Raftery 1995, "positive")
HMM_L_GRID = (1e4, 5e7, 41)  # mean tract lengths tried by EM: 10 kb-50 Mb, 41 log steps (LTRmix)
HMM_ITERS = 100            # EM rounds at most (LTRmix)
HMM_TOL = 1e-7             # EM stops when the log-likelihood moves by < 1e-7 of itself (LTRmix)
INV_MIN_LOCI = 5           # heuristic: shortest reversed run reported as an inverted block; named in findings.txt
```

  - `load_catalog`:
    - Fail fast without `outdir/manifest.json` or `loci.tsv`.
    - Read `loci.tsv` in two passes: count the rows, then fill preallocated arrays with the csv module. Never collect
      per-field Python lists.
    - Stream each pair file once (every annotated A against every other genome) into `proj`, `ptier`, `pseq`, `pstart`,
      `pend` and `pstrand`. Fail fast on a missing file or a header other than `CALL_COLUMNS`, naming it.
    - `sheet_sha` = `file_checksum(sheet, outdir/"work"/CHECKSUM_CACHE)`.
    - Lengths and seqid order come from `Fasta(s.fasta, cache_dir=outdir/"work"/"fai").lengths()`.
    - `top` comes from each annotated genome's `work/elements/<label>.tsv`, by walking `parent` links.
    - Never call an engine-fingerprint check.

- [ ] **Step 6: Run** `python -m pytest -W error tests/test_catalog.py && ruff check .`. Expected: PASS, clean.

- [ ] **Step 7: Record the builder calls.** In DESIGN.md section 12, add "Build decisions (plan 2)" with the twelve calls
  above, one line each. Call 11 reads: "Fallback discovery uses only annotated ingroup genomes that split with D from
  the sisters (four-point condition on PAV distances). Controller ruling 2026-11-11 while the user was away (a discovery
  genome inside the sisters' clade biases the null D_pav: +0.35, Z +6.7 in a coalescent probe); user to confirm."

- [ ] **Step 8: Commit.**
  `git add -A && git commit -m "Add analysis catalog loader, constants and toy runs"`
---

### Task 2: Statistics core — rows, blocks, jackknife, u95, resolution, findings

**Files:**
- Create: `src/ltrpav/analysis/stats.py`, `tests/test_stats_core.py`

**Interfaces:**
- Consumes: `Catalog`; the analysis constants `BLOCK_BP`, `BLOCK_FRAC`, `BLOCK_MIN`, `RESOLVE_WARN`;
  `scipy.stats.chi2` (imported inside `u95`).
- Produces:

```python
STATS_COLUMNS = ("layer", "test", "scope", "stratum", "statistic", "value", "se", "z", "n", "loci", "note")
@dataclass
class StatRow:
    layer: str; test: str; scope: str; stratum: str; statistic: str
    value: float | int | str; se: float = math.nan; z: float = math.nan; n: int | None = None
    loci: str = "."; note: str = "."
@dataclass(frozen=True)
class Jk:
    est: float; se: float; z: float; nblocks: int
def block_size(cat: Catalog) -> int          # min(BLOCK_BP, max(smallest genome total // BLOCK_FRAC, BLOCK_MIN))
def block_ids(seq: np.ndarray, mid: np.ndarray, size: int) -> np.ndarray   # int64 (seq << 32) | (mid // size); seq >= 0
def jackknife(stat: Callable[[np.ndarray], float], blocks: np.ndarray) -> Jk
def d_ratio(a: np.ndarray, b: np.ndarray) -> Callable[[np.ndarray], float]   # keep -> (Σa - Σb) / (Σa + Σb), nan if 0
def u95(d: np.ndarray, n: np.ndarray) -> np.ndarray   # chi2.ppf(0.95, 2(d + 1)) / 2 / n: one-sided 95% Poisson bound
def resolution(test: str, scope: str, fracs: dict[str, float], n: int, loci: str, findings: Findings,
               section: str) -> list[StatRow]
    # one row "resolved_<genome>" per entry (layer "pav", stratum "all"); a WARNING when max - min > RESOLVE_WARN
    # (named a heuristic in its text); the caller sets layer or note when it needs another
def write_stats(rows: list[StatRow], path: Path) -> None   # header row STATS_COLUMNS only; tsv_field values; nan -> "."
def read_stats(path: Path) -> list[StatRow]
SECTIONS = ("Run", "Relationships", "Trio tests", "Painting", "Dating", "Direction (exploratory)", "Inversions",
            "Mechanisms", "Sequence-identity layer (outside the PAV-only core)")
class Findings:
    def add(self, section: str, text: str) -> None
    def warn(self, section: str, text: str) -> None    # stores "WARNING: " + text
    def extend(self, other: Findings) -> None
    def items(self) -> list[tuple[str, str]]           # (section, line), insertion order
```

`u95` and `resolution` are written once here. Tasks 3, 4, 6, 7 and 9 import them; nobody re-derives the formula or the
warning.

The callers pass `block_ids` the coordinates their rule names, e.g. D's site in each row's discoverer call
(`cat.proj_site`).

`jackknife` ports LTRmix `jackknife` (l. 893) for any statistic:
- `est = stat(all rows)`;
- one pseudovalue `stat(blocks != b)` per distinct block, non-finite ones dropped;
- `se = sqrt((m'-1)/m' * Σ(p - mean)²)` over the m' finite pseudovalues;
- `se` and `z` are nan with fewer than 3 blocks, counted as distinct blocks among the rows before non-finite
  pseudovalues are dropped (LTRmix);
- `z = est / se` when `se > 0`.

This is the unweighted delete-one form, kept for comparability with LTRmix. Busing's weighted form, standard for unequal
blocks, is a candidate for Plan 3's stability checks.

- [ ] **Step 1: Write the failing tests**

```python
def test_jackknife_matches_leave_one_out():
    rng = np.random.default_rng(0)
    a = rng.integers(0, 2, 200); b = 1 - a; blocks = rng.integers(0, 20, 200)
    jk = jackknife(d_ratio(a, b), blocks)
    loo = np.array([(a[blocks != x].sum() - b[blocks != x].sum()) / (blocks != x).sum() for x in range(20)])
    assert jk.est == pytest.approx((a.sum() - b.sum()) / 200) and jk.nblocks == 20
    assert jk.se == pytest.approx(math.sqrt(19 / 20 * ((loo - loo.mean()) ** 2).sum()))

def test_jackknife_two_blocks_has_no_se():
    jk = jackknife(d_ratio(np.array([1, 1, 0]), np.array([0, 0, 1])), np.array([0, 0, 1]))
    assert jk.est == pytest.approx(1 / 3) and jk.nblocks == 2 and math.isnan(jk.se) and math.isnan(jk.z)

def test_block_size():
    lens = lambda *t: SimpleNamespace(lengths={f"g{i}": np.array(x) for i, x in enumerate(t)})
    assert block_size(lens([600_000, 400_000], [2_000_000])) == 10_000
    assert block_size(lens([2_100_000_000])) == 5_000_000 and block_size(lens([300_000_000])) == 3_000_000
    assert block_size(lens([500_000])) == 10_000

def test_block_ids_split_by_seqid_and_size():
    ids = block_ids(np.array([0, 1, 0, 0, 0, 0]), np.array([5e3, 5e3, 19_999.5, 20_000.5, 21e3, 29e3]), 10_000)
    assert ids[0] != ids[1] and ids[2] != ids[3] and ids[3] == ids[4] == ids[5]

def test_u95():
    assert u95(np.array([0]), np.array([1000]))[0] == pytest.approx(0.0029957, rel=1e-4)
    assert u95(np.array([2]), np.array([500]))[0] == pytest.approx(chi2.ppf(0.95, 6) / 2 / 500)

def test_resolution_rows_and_warning():
    f = Findings()
    rows = resolution("resolution", "R,S;D", {"R": 0.85, "S": 0.40}, 1000, "disc=D", f, "Trio tests")
    assert [(r.statistic, r.value, r.n, r.loci) for r in rows] == [("resolved_R", 0.85, 1000, "disc=D"),
                                                                ("resolved_S", 0.40, 1000, "disc=D")]
    assert len(f.items()) == 1 and f.items()[0][1].startswith("WARNING:") and "heuristic" in f.items()[0][1]
    g = Findings()
    resolution("resolution", "R,S;D", {"R": 0.85, "S": 0.80}, 1000, "disc=D", g, "Trio tests")
    assert g.items() == []

def test_stats_roundtrip(tmp_path):
    rows = [StatRow("pav", "D_pav", "R,S;D", "all", "D", 0.123456789, 0.01, 12.3456789, 400, "disc=D", "."),
            StatRow("pav", "tree", "all", "all", "newick", "(A,B);")]
    write_stats(rows, tmp_path / "s.tsv")
    lines = (tmp_path / "s.tsv").read_text().splitlines()
    assert lines[0].split("\t") == list(STATS_COLUMNS) and len(lines) == 3
    assert lines[1].split("\t")[5:9] == ["0.123457", "0.01", "12.3457", "400"]
    assert lines[2].split("\t")[5:9] == ["(A,B);", ".", ".", "."]
    back = read_stats(tmp_path / "s.tsv")
    assert back[0].value == pytest.approx(0.123457) and math.isnan(back[1].se) and back[1].value == "(A,B);"

def test_findings_order():
    f = Findings()
    f.add("Painting", "p1"); f.warn("Run", "w1"); f.add("Run", "r1")
    assert f.items() == [("Painting", "p1"), ("Run", "WARNING: w1"), ("Run", "r1")]
```

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_stats_core.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** the tests. Expected: PASS.
- [ ] **Step 5: Commit.** `"Add statistics core: rows, blocks, jackknife, u95, resolution, findings"`
---

### Task 3: Relationships — run summary, discovery, sharing, tree, sister pairs, outgroup conflicts (DESIGN 7.1, 7.2)

**Files:**
- Create: `src/ltrpav/analysis/relations.py`, `tests/test_relations.py`

**Interfaces:**
- Consumes: `Catalog` (`cls`, `pcls_by`), `StatRow`, `Findings`, `P_WARN`; `scipy.stats.binomtest`.
- Produces:

```python
@dataclass(frozen=True)
class Node:
    name: str | None; children: tuple[Node, ...] = (); length: float = 0.0
    def leaves(self) -> frozenset[str]
    def newick(self) -> str                     # lengths to 6 significant digits, ";" at the end
@dataclass
class Counted:
    rows: np.ndarray                           # (n,) bool: candidates with x and y resolved in gstar's calls
    cand: np.ndarray                           # (n,) bool: gstar exists, z present, outgroup rule (gstar's calls)
    gstar: np.ndarray                          # (n,) int16: each row's discovering genome (z, or a fallback genome); -1 none
    disc: tuple[str, ...]                      # z, or the eligible fallback genomes
    loci: str                                  # e.g. "disc=D;present=D;res=R,S;outgroup=E"
    excluded: dict[str, str]                   # fallback genomes left out -> why
def run_summary(cat: Catalog) -> tuple[list[StatRow], Findings]
def pav_distances(cat: Catalog) -> tuple[np.ndarray, np.ndarray]    # (G, G) distance, (G, G) loci counted
def shared_derived(cat: Catalog) -> np.ndarray                      # (G, G) counts of derived insertions two genomes share
def neighbor_joining(d: np.ndarray, labels: list[str]) -> Node       # unrooted: top node with 3 children (2 for 2 leaves)
def root_on(tree: Node, outgroup: str) -> Node                      # root on the outgroup's branch: (outgroup, rest)
def four_point_ok(dist: np.ndarray, cat: Catalog, r: str, s: str, x: str, d: str) -> bool
    # d(r,s) + d(x,d) < min(d(r,x) + d(s,d), d(r,d) + d(s,x)): x splits with d from r and s (cat: label -> index)
def eligible_fallback(cat: Catalog, x: str, y: str, z: str, dist: np.ndarray) -> tuple[tuple[str, ...], dict[str, str]]
def discover(cat: Catalog, x: str, y: str, z: str, dist: np.ndarray, outgroup: str) -> Counted | None
    # outgroup: "E" (every outgroup E), "not_present" (no outgroup present), "none" (no rule)
@dataclass(frozen=True)
class SisterCall:
    pair: tuple[str, str]; donor: str; counts: dict[str, int]; p_top: float; p_kksc: float; kksc_loci: str
    ambiguous: bool
def trio_sharing(cat: Catalog, genomes: tuple[str, str, str]) -> tuple[dict[str, int], int]   # "x+y" -> count; loci counted
def sister_pair(cat: Catalog, genomes: tuple[str, str, str], dist: np.ndarray) -> SisterCall
def relations(cat: Catalog) -> tuple[list[StatRow], Findings, Node | None, np.ndarray]   # rows, findings, rooted tree, distances
```

**`discover` is the one discovery function** (DESIGN 7.1; review A12). D_pav, the f4-ratio and the identity layer call
it with `outgroup="E"` (DESIGN 7.1: an outgroup must be E). `p_kksc` calls it with `"not_present"` (DESIGN 7.2's
set-aside). The rule goes into `Counted.loci`.
- `disc = (z,)` if z is annotated, else `eligible_fallback`: the annotated ingroup genomes w outside {x, y, z} with
  `four_point_ok(dist, cat, x, y, w, z)`. The others go to `excluded` ("groups with x", "groups with y" or "distance
  unresolved"); terminal-branch effects of annotation depth cancel in each four-point sum. An empty `disc` returns
  `None`, and the caller writes "skipped" with a WARNING naming the excluded genomes and why (builder call 11).
- Per row, `gstar` = z if z is a member there; under fallback, the first eligible genome that is a member there, in
  sheet order.
- `cand` = `gstar >= 0`, `pcls_by(gstar, z) == 1`, and the outgroup rule on `pcls_by(gstar, o)` for every outgroup o.
- `rows` = `cand` with `pcls_by(gstar, x) >= 0` and `pcls_by(gstar, y) >= 0`.
- `loci` = `disc=<disc joined by ,>;present=z;res=x,y;outgroup=<rule>`.

Other rules (every row carries its `loci` declaration):

- **`run_summary`** (test `catalog`, section "Run"):
  - n loci; per genome `resolved_frac` (merged cls >= 0) and whether it is annotated;
  - quotes `qc.tsv`'s `annot_sensitivity` and every `skipped_<reason>` count (DESIGN 7.1, 8); a missing `qc.tsv` is one
    findings line.
- **Distances** (merged states, any discovery):
  - `d(x, y)` = loci where x and y are both resolved and differ (present against E), over loci where both are resolved;
  - every locus counts, outgroups included; `loci` = `disc=any;res=x,y`;
  - rows `distance`, scope `x~y`, statistic `d`, with n.
- **Shared derived insertions** (DESIGN 7.2's pairwise counts), for ingroup x, y:
  - loci present in both, with no outgroup present, and E in at least one other ingroup genome (so not fixed);
  - `loci` = `disc=any;present=x,y;absent=another ingroup genome;outgroup=not_present`;
  - rows `shared_derived`, scope `x~y`, statistic `n`.
- **Tree:**
  - Neighbor joining (Saitou & Nei Q-matrix; ties to the first pair in sheet order; negative branch lengths set to 0) on
    every genome.
  - Rooted on the branch that splits the outgroup clade from the ingroup (one outgroup: its own branch); if the outgroups
    form no clade, rooted on the first outgroup with a WARNING; unrooted without an outgroup (Task 3 fix round 1).
  - Row `tree`, scope `all`, statistic `newick`.
  - Skipped with a findings line when a distance is nan or there are fewer than three genomes.
- **Sharing**, which only picks the sister pair; per trio of ingroup genomes in sheet order:
  - merged states: loci resolved in all three, with no outgroup present (DESIGN 7.2);
  - `n_x+y` = x and y present, the third E;
  - `loci` = `disc=any;res=a,b,c;outgroup=not_present`.
- **Sister pair:**
  - `pair` = the largest count (ties: first pair in sheet order); `donor` = z, the third genome;
  - `p_top` = two-sided `binomtest(n_top, n_top + n_second)`;
  - `ambiguous` when `p_top >= P_WARN`, which also writes a WARNING naming the sister pair.
- **`p_kksc`**, the symmetry the KKSC tests rest on (equal minority counts under lineage sorting):
  - two-sided `binomtest(n_x+z, n_x+z + n_y+z)` on `discover(cat, x, y, z, dist, "not_present")`;
  - n_x+z = `pcls_by(gstar, x) == 1` and `pcls_by(gstar, y) == 0` on its rows; n_y+z the mirror;
  - `kksc_loci` = that `Counted.loci`, or `none` (with `p_kksc` nan) when `discover` returns `None`;
  - the note: it ignores block dependence (nested clusters, linkage), so its p is anti-conservative; the jackknifed D_pav
    is the test of record.

  Rows `sharing`: statistics `n_x+y` for the three pairs, `sister_pair`, `p_top`, `p_kksc` (its own `loci`).
- **Outgroup conflicts:**
  - Per ingroup genome g, from the discoverers' own calls (Task 3 fix round 1, controller ruling): among loci discovered by
    genomes other than g where some outgroup is present in the discoverer's call and g is resolved in it, the fraction
    where g is E. g's own member loci never enter (g is present there by construction).
  - Row `outgroup_conflict`, statistic `frac_E`, n, note "an upper bound on the combined rate of ingroup false E and
    outgroup false presence; deep lineage sorting and parallel insertions also give it".

- [ ] **Step 1: Write the failing tests**

```python
D5 = np.array([[0, 5, 9, 9, 8], [5, 0, 10, 10, 9], [9, 10, 0, 8, 7], [9, 10, 8, 0, 3], [8, 9, 7, 3, 0]], float)

def leaf_distances(t: Node, labels: list[str]) -> np.ndarray:
    """Path lengths between leaves on the unrooted tree."""
    edges, stack = {}, [t]
    while stack:
        node = stack.pop()
        for c in node.children:
            edges.setdefault(id(node), []).append((id(c), c.length)); edges.setdefault(id(c), []).append((id(node), c.length))
            stack.append(c)
    leaf = {n.name: id(n) for n in _walk(t) if not n.children}
    def dist_from(a):
        seen, out, todo = {a: 0.0}, {}, [a]
        while todo:
            u = todo.pop()
            for v, w in edges.get(u, ()):
                if v not in seen:
                    seen[v] = seen[u] + w; todo.append(v)
        return seen
    return np.array([[dist_from(leaf[a])[leaf[b]] for b in labels] for a in labels])

def splits(t: Node) -> set[frozenset[str]]:
    """Leaf sets below every inner node."""
    return {n.leaves() for n in _walk(t) if n.children}

def _walk(t):
    yield t
    for c in t.children:
        yield from _walk(c)

def test_nj_recovers_additive_tree():
    t = neighbor_joining(D5, list("abcde"))
    assert leaf_distances(t, list("abcde")) == pytest.approx(D5)
    assert {frozenset("ab"), frozenset("de")} <= splits(t) | {frozenset("abcde") - s for s in splits(t)}

def test_root_on_outgroup():
    t = root_on(neighbor_joining(D5, list("abcde")), "e")
    assert t.leaves() == frozenset("abcde")
    assert {c.leaves() for c in t.children} == {frozenset("e"), frozenset("abcd")} and t.newick().endswith(";")

R_S_SISTER = ([loc(1000 * i, "R:P* S:P D:E O:E") for i in range(1, 13)]          # R+S x12
              + [loc(20_000 + 1000 * i, "R:P S:E D:P* O:E") for i in range(2)]      # R+D x2, D members
              + [loc(30_000, "R:E S:P D:P* O:E")]                                   # S+D x1, D member
              + [loc(40_000 + 1000 * i, "R:P* S:P D:E O:P") for i in range(3)]      # outgroup present x3
              + [loc(50_000, "R:P* S:U D:E O:E")])                                  # S unresolved

def test_sharing_and_sister(tmp_path, toy_fastas):
    cat = write_run(tmp_path, R_S_SISTER, fasta_dir=toy_fastas).load()
    sc = sister_pair(cat, ("R", "S", "D"), pav_distances(cat)[0])
    assert sc.pair == ("R", "S") and sc.donor == "D" and sc.counts == {"R+S": 12, "R+D": 2, "S+D": 1}
    assert sc.p_top == pytest.approx(binomtest(12, 14).pvalue) and not sc.ambiguous          # 0.0129
    assert sc.p_kksc == pytest.approx(1.0) and sc.kksc_loci == "disc=D;present=D;res=R,S;outgroup=not_present"

def test_kksc_reads_the_third_genomes_calls(tmp_path, toy_fastas):
    # sister pair (R, S), donor D: D's own calls are read. One more R+D locus whose merged S is E (R, a member, calls it E)
    # while D's own call into S is U: the merged sharing counts it, p_kksc does not
    loci = R_S_SISTER + [loc(60_000, "R:P* S:E D:P* O:E", calls={("D", "S"): "U"})]
    cat = write_run(tmp_path / "a", loci, fasta_dir=toy_fastas).load()
    sc = sister_pair(cat, ("R", "S", "D"), pav_distances(cat)[0])
    assert sc.pair == ("R", "S") and sc.counts["R+D"] == 3 and not sc.ambiguous             # binomtest(12, 15): 0.035
    assert sc.p_kksc == pytest.approx(binomtest(2, 3).pvalue)                               # n_R+D 2, n_S+D 1
    unannotated_d = [GENOMES[0], GENOMES[1], ("D", "taxD", None, False), GENOMES[3]]
    loci2 = [loc(1000 * i, "R:P* S:P D:E O:E") for i in range(1, 13)] + [loc(30_000, "R:P* S:E D:P O:E")]
    cat2 = write_run(tmp_path / "b", loci2, genomes=unannotated_d, fasta_dir=toy_fastas).load()
    sc2 = sister_pair(cat2, ("R", "S", "D"), pav_distances(cat2)[0])
    assert math.isnan(sc2.p_kksc) and sc2.kksc_loci == "none"

def test_discover_rules(tmp_path, toy_fastas):
    loci = [loc(10_000, "R:P S:E D:P* O:E"), loc(20_000, "R:P S:E D:P* O:U"), loc(30_000, "R:P S:E D:P* O:P"),
            loc(40_000, "R:P* S:E D:P O:E"), loc(50_000, "R:P S:U D:P* O:E")]
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    dist = pav_distances(cat)[0]
    e, np_ = discover(cat, "R", "S", "D", dist, "E"), discover(cat, "R", "S", "D", dist, "not_present")
    assert e.cand.tolist() == [True, False, False, False, True] and e.rows.tolist() == [True, False, False, False, False]
    assert np_.cand.tolist() == [True, True, False, False, True]
    assert e.gstar.tolist() == [2, 2, 2, -1, 2] and e.disc == ("D",)
    assert e.loci == "disc=D;present=D;res=R,S;outgroup=E" and np_.loci.endswith("outgroup=not_present")

def test_sister_tie_warns(tmp_path, toy_fastas):
    loci = ([loc(1000 * i, "R:P* S:P D:E O:E") for i in range(1, 4)]
            + [loc(10_000 + 1000 * i, "R:P* S:E D:P O:E") for i in range(3)])
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    rows, f, tree, dist = relations(cat)
    sc = sister_pair(cat, ("R", "S", "D"), dist)
    assert sc.pair == ("R", "S") and sc.ambiguous
    assert any(t.startswith("WARNING:") and "R+S" in t for _, t in f.items())

def test_outgroup_conflict(tmp_path, toy_fastas):
    loci = ([loc(1000 * i, "R:P* S:P D:P O:P") for i in range(1, 8)] + [loc(9000, "R:E S:P* D:P O:P")]
            + [loc(10_000 + 1000 * i, "R:U S:P* D:P O:P") for i in range(2)])
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    r = next(x for x in relations(cat)[0] if x.test == "outgroup_conflict" and x.scope == "R")
    assert r.value == pytest.approx(1 / 8) and r.n == 8 and "upper bound" in r.note

def test_distances_pairwise_complete(tmp_path, toy_fastas):
    loci = [loc(1000, "R:P* S:P D:E O:E"), loc(2000, "R:P* S:E D:E O:E"), loc(3000, "R:E S:P* D:E O:E"),
            loc(4000, "R:P* S:U D:E O:E")]
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    d, n = pav_distances(cat)
    assert d[cat.g("R"), cat.g("S")] == pytest.approx(2 / 3) and n[cat.g("R"), cat.g("S")] == 3

def test_shared_derived(tmp_path, toy_fastas):
    loci = ([loc(1000 * i, "R:P* S:P D:E O:E") for i in range(1, 4)]
            + [loc(5000 + 1000 * i, "R:P* S:P D:P O:E") for i in range(2)] + [loc(9000, "R:P* S:P D:E O:P")])
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    assert shared_derived(cat)[cat.g("R"), cat.g("S")] == 3

def test_four_point():
    cat = SimpleNamespace(g=["R", "S", "D", "X"].index)
    near_d = np.array([[0, .2, .5, .5], [.2, 0, .5, .5], [.5, .5, 0, .1], [.5, .5, .1, 0]])
    near_r = np.array([[0, .2, .5, .1], [.2, 0, .5, .25], [.5, .5, 0, .5], [.1, .25, .5, 0]])
    assert four_point_ok(near_d, cat, "R", "S", "X", "D")          # 0.3 < 1.0
    assert not four_point_ok(near_r, cat, "R", "S", "X", "D")      # 0.7 > 0.6

def test_run_summary_quotes_qc(tmp_path, toy_fastas):
    cat = write_run(tmp_path, [loc(1000, "R:P* S:E D:P* O:E")], fasta_dir=toy_fastas).load()
    rows, f = run_summary(cat)
    lines = [t for s, t in f.items() if s == "Run"]
    assert any("annot_sensitivity" in t and "0.9" in t for t in lines)
    assert any("skipped_malformed_coordinates 2" in t for t in lines)
    assert next(r for r in rows if r.statistic == "resolved_frac" and r.scope == "S").value == 1.0
```

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_relations.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** the tests. Expected: PASS.
- [ ] **Step 5: Commit.** `"Add relationships: discovery, sharing, tree, sister pairs, outgroup conflicts"`
---

### Task 4: Trio roles and tests — D_pav, age strata and gradient, nested collapse, f4-ratio (DESIGN 7.1, 7.3, 7.5)

**Files:**
- Create: `src/ltrpav/analysis/trio.py`, `tests/test_trio.py`

**Interfaces:**
- Consumes:
  - `Catalog` (`pcls_by`, `ptier_by`, `proj_site`), `age_bin`, `cluster_keys`;
  - `jackknife`, `d_ratio`, `block_ids`, `block_size`, `resolution`;
  - `discover`, `Counted`, `sister_pair`, `pav_distances`, and the distances from `relations`.
- Produces:

```python
@dataclass(frozen=True)
class Trio:
    R: str; S: str; D: str; fixed: bool
    @property
    def scope(self) -> str                     # f"{R},{S};{D}"
def d_pav(cat: Catalog, R: str, S: str, D: str, c: Counted, size: int, keep: np.ndarray | None = None
          ) -> tuple[Jk, int, int]                                  # (jk, n_RD, n_SD) on c.rows & keep
def trios(cat: Catalog, fixed: tuple[str, str, str] | None, size: int, dist: np.ndarray
          ) -> tuple[list[Trio], list[StatRow], Findings]
def trio_tests(cat: Catalog, trio: Trio, size: int, dist: np.ndarray) -> tuple[list[StatRow], Findings]
def second_donors(cat: Catalog, trio: Trio, dist: np.ndarray) -> list[str]
def f4_ratio(cat: Catalog, trio: Trio, d2: str, size: int, dist: np.ndarray) -> list[StatRow]
```

Rules. The counted loci are `discover(cat, R, S, D, dist, "E")` (Task 3), so every state comes from each row's
discovering genome's own calls.

- **`d_pav`:**
  - `a` = `pcls_by(gstar, R) == 1` and `pcls_by(gstar, S) == 0`; `b` the mirror;
  - blocks = `block_ids(*cat.proj_site(gstar, D), size)` on the rows: D's coordinates as each row's discoverer reads
    them (D's own when D discovers);
  - `jackknife(d_ratio(a, b), blocks)`.
- **`trios`:**
  - **Fixed trio:** the three labels must be distinct ingroup genomes, else AnalysisError. It yields
    `[Trio(*fixed, fixed=True)]` with no inference.
  - **Otherwise,** for each 3-combination of ingroup genomes in sheet order:
    - `sister_pair` gives the pair and D;
    - D_pav of (pair[0], pair[1]; D);
    - R = pair[0] if that D >= 0, pair[1] if D < 0. A nan D keeps pair[0] (sheet order); LTRmix sends nan to pair[1].
  - Rows `roles`, statistic `source` (`data` or `--trio`).
  - With fewer than three ingroup genomes: no trios, and the line "Trio tests skipped: fewer than three ingroup genomes".
- **`trio_tests`** writes rows `D_pav` for each stratum: statistic `D` (se, z, n = n_RD + n_SD), plus counts `n_RD` and
  `n_SD`. A stratum with no loci writes no rows. With `discover` returning `None`, the test is skipped with its
  WARNING.
  - **Resolution:** `resolution("resolution", scope, {"R": ..., "S": ...}, ...)` over `cand`, from
    `pcls_by(gstar, ·)`.
  - **Outgroup filter** (row `outgroup_filter`, statistic `removed_frac`): the fraction of `discover(..., "none")`
    candidates that the outgroup rule drops. Always one findings line quoting it to two decimals.
  - **Strata:**
    - `all`;
    - the `AGE_LABELS` bins, by K of each row's gstar copy (`cat.k[i, gstar[i]]`);
    - `high_tier`: `ptier_by(gstar, R)` and `ptier_by(gstar, S)` are `high` (call tiers; a member's "annot" never
      enters);
    - `nested_collapsed`: the informative counted rows (a | b), sorted by the gstar genome's (seq, start, -end),
      keeping the first row per `cluster_keys(cat, gstar, ·)` key;
    - `no_outgroup_filter`.

    No finite K at all gives one findings line "age strata skipped: no K2P" and no age rows.
  - **Gradient:**
    - `dD = D(K=0) - D(K>=0.01)`, one statistic jackknifed over the union of blocks;
    - row `D_pav_gradient`, stratum `K=0 minus K>=0.01`, statistic `dD`;
    - findings in section "Dating".
  - **f4-ratio**, for each `second_donors` genome D2 (DESIGN 7.3, LTRmix `fratio`); `f4_ratio`:
    - on the D_pav rows with `pcls_by(gstar, D2) >= 0`, from the same calls: `num = [R pres, S E] - [S pres, R E]`
      and `den = [D2 pres, S E] - [S pres, D2 E]`;
    - `f = Σnum / Σden`, jackknifed on D's blocks;
    - rows `f4_ratio`, scope `R,S;D;D2`: statistics `f`, `num`, `den`, plus `resolution(...)` rows for D2.
- **`second_donors`:** genomes g of the ingroup outside the trio with `dist[D, g] < min(dist[x, y] for x in (D, g) for
  y in (R, S))`.

- [ ] **Step 1: Write the failing tests**

```python
def _trio_tests(cat, trio):
    return trio_tests(cat, trio, block_size(cat), pav_distances(cat)[0])

def _row(rows, test, stratum, statistic):
    return next(r for r in rows if (r.test, r.stratum, r.statistic) == (test, stratum, statistic))

def test_counted_rule_and_d(tmp_path, toy_fastas):
    loci = ([loc(10_000 * i, "R:P S:E D:P* O:E") for i in range(1, 5)]
            + [loc(10_000 * i, "R:E S:P D:P* O:E") for i in range(5, 7)]
            + [loc(70_000, "R:P S:E D:P* O:P"), loc(80_000, "R:P S:E D:P* O:U"),
               loc(90_000, "R:P* S:E D:P O:E"), loc(100_000, "R:P S:U D:P* O:E")])
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    c = discover(cat, "R", "S", "D", pav_distances(cat)[0], "E")
    jk, n_rd, n_sd = d_pav(cat, "R", "S", "D", c, block_size(cat))
    assert (n_rd, n_sd) == (4, 2) and jk.est == pytest.approx(2 / 6) and c.cand.sum() == 7
    assert c.loci == "disc=D;present=D;res=R,S;outgroup=E"

def test_counted_reads_discoverer_calls(tmp_path, toy_fastas):
    loci = ([loc(10_000 * i, "R:P S:E D:P* O:E") for i in range(1, 5)]                               # counted
            + [loc(10_000 * i, "R:P* S:E D:P* O:E", calls={("D", "R"): "U"}) for i in range(5, 8)]  # R P/annot merged
            + [loc(10_000 * i, "R:P* S:E D:P* O:E", calls={("D", "S"): "U"}) for i in range(8, 10)] # S E merged (R's call)
            + [loc(10_000 * i, "R:E S:P D:P* O:E") for i in range(10, 14)])                         # counted
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    c = discover(cat, "R", "S", "D", pav_distances(cat)[0], "E")
    _, n_rd, n_sd = d_pav(cat, "R", "S", "D", c, block_size(cat))
    assert (n_rd, n_sd) == (4, 4)
    assert (cat.ptier_by(c.gstar, "R")[c.rows] == TIER_CODE["high"]).all()        # call tiers; never "annot"

def test_null_with_unequal_annotation(tmp_path, toy_fastas):
    # the review's depth-leak probe, scaled down: no tracts, R annotated more completely than S
    for seed in (1, 2, 3):
        cat = simulate_run(tmp_path / str(seed), seed=seed, n_per_seq=3000, p_member={"R": 0.95, "S": 0.5},
                           p_missing=0.3, fasta_dir=toy_fastas).load()
        c = discover(cat, "R", "S", "D", pav_distances(cat)[0], "E")
        jk, _, _ = d_pav(cat, "R", "S", "D", c, block_size(cat))
        assert abs(jk.z) < 3                         # replica rr_toy.py: |Z| <= 0.15 at seeds 1-3
        if seed == 1:                                # the same rule on merged loci.tsv states: the leak it avoids
            m = (cat.member[:, cat.g("D")] & (cat.cls("D") == 1) & (cat.cls("O") == 0)
                 & (cat.cls("R") >= 0) & (cat.cls("S") >= 0))
            a = (m & (cat.cls("R") == 1) & (cat.cls("S") == 0)).sum()
            b = (m & (cat.cls("S") == 1) & (cat.cls("R") == 0)).sum()
            assert (a - b) / (a + b) > 0.05          # expected about +0.13 (+0.127 with the engine-faithful toy, Task 1 fix round 1)

def test_roles_from_sign(tmp_path, toy_fastas):
    loci = ([loc(1000 * i, "R:P* S:P D:E O:E") for i in range(1, 13)]           # sisters R, S
            + [loc(20_000 + 1000 * i, "R:E S:P D:P* O:E") for i in range(4)]   # S+D x4
            + [loc(30_000, "R:P S:E D:P* O:E")])                               # R+D x1: D(R,S;D) = -0.6
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    found, rows, f = trios(cat, None, block_size(cat), pav_distances(cat)[0])
    assert found == [Trio("S", "R", "D", False)] and _row(rows, "roles", "all", "source").value == "data"

def test_fixed_trio(tmp_path, toy_fastas):
    cat = write_run(tmp_path, [loc(1000, "R:P* S:E D:P* O:E")], fasta_dir=toy_fastas).load()
    size, dist = block_size(cat), pav_distances(cat)[0]
    found, rows, _ = trios(cat, ("S", "R", "D"), size, dist)
    assert found == [Trio("S", "R", "D", True)] and _row(rows, "roles", "all", "source").value == "--trio"
    for bad in (("R", "R", "D"), ("R", "S", "O")):
        with pytest.raises(AnalysisError):
            trios(cat, bad, size, dist)

def test_null_and_admixed(tmp_path, toy_fastas):
    for seed in range(1, 6):                         # replica rr_toy.py: |Z| < 3 in 200 of 200 seeds
        cat = simulate_run(tmp_path / f"n{seed}", seed=seed, fasta_dir=toy_fastas).load()
        dist = pav_distances(cat)[0]
        (trio,), _, _ = trios(cat, None, block_size(cat), dist)
        jk, _, _ = d_pav(cat, trio.R, trio.S, trio.D, discover(cat, trio.R, trio.S, trio.D, dist, "E"), block_size(cat))
        assert {trio.R, trio.S} == {"R", "S"} and trio.D == "D" and abs(jk.z) < 3
    cat = simulate_run(tmp_path / "adm", seed=1, tracts=TRACTS, n_per_seq=3000, fasta_dir=toy_fastas).load()
    dist = pav_distances(cat)[0]
    (trio,), _, _ = trios(cat, None, block_size(cat), dist)
    rows, _ = trio_tests(cat, trio, block_size(cat), dist)
    assert trio == Trio("R", "S", "D", False)
    assert _row(rows, "D_pav", "all", "D").value > 0 and _row(rows, "D_pav", "all", "D").z > 3   # replica: median Z 5.0
    assert _row(rows, "D_pav", "K=0", "D").value > _row(rows, "D_pav", "K>=0.01", "D").value
    assert _row(rows, "D_pav_gradient", "K=0 minus K>=0.01", "dD").z > 0

def test_fallback_discovery(tmp_path, toy_fastas):
    genomes = [("R", "taxR", None, True), ("S", "taxS", None, True), ("D", "taxD", None, False),
               ("X", "taxD", None, True), ("O", "taxO", "outgroup", False)]
    cat = write_run(tmp_path, [loc(1000, "R:P S:E D:P X:P* O:E")], genomes=genomes, fasta_dir=toy_fastas).load()
    near_d = dmat({("R", "S"): 0.2, ("D", "X"): 0.1}, 0.5, cat.labels)
    near_r = dmat({("R", "S"): 0.2, ("R", "X"): 0.1, ("S", "X"): 0.25}, 0.5, cat.labels)
    assert discover(cat, "R", "S", "D", near_d, "E").disc == ("X",)
    assert discover(cat, "R", "S", "D", near_r, "E") is None
    _, f = trio_tests(cat, Trio("R", "S", "D", True), block_size(cat), near_r)
    assert any(t.startswith("WARNING:") and "skipped" in t and "X" in t for _, t in f.items())

def test_resolution_warning(tmp_path, toy_fastas):
    cat = simulate_run(tmp_path, seed=1, p_missing={"S": 0.6}, fasta_dir=toy_fastas).load()
    rows, f = _trio_tests(cat, Trio("R", "S", "D", True))
    assert _row(rows, "resolution", "all", "resolved_R").value == pytest.approx(0.85, abs=0.03)   # replica 0.838
    assert _row(rows, "resolution", "all", "resolved_S").value == pytest.approx(0.40, abs=0.03)   # replica 0.408
    assert any(t.startswith("WARNING:") and "resolved" in t for _, t in f.items())

def test_nested_collapse(tmp_path, toy_fastas):
    loci = []
    for h in range(10):                              # 10 RD hosts in D, each with 3 nested RD children
        host = len(loci)
        loci += [loc(50_000 * (h + 1), "R:P S:E D:P* O:E", length=6000)]
        loci += [loc(50_000 * (h + 1) + 1000 * (j + 1), "R:P S:E D:P* O:E", parent=host) for j in range(3)]
    host = len(loci)                                 # a host present in R, S and D with 3 RD children
    loci += [loc(100_000, "R:P S:P D:P* O:E", seqid="chr2", length=6000)]
    loci += [loc(101_000 + 1000 * j, "R:P S:E D:P* O:E", seqid="chr2", parent=host) for j in range(3)]
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    rows, _ = _trio_tests(cat, Trio("R", "S", "D", True))
    assert _row(rows, "D_pav", "all", "n_RD").value == 43
    assert _row(rows, "D_pav", "nested_collapsed", "n_RD").value == 11      # 10 + 1; the old outermost-row rule gave 10

def test_age_strata_without_k(tmp_path, toy_fastas):   # Review Focus 2
    cat = simulate_run(tmp_path, seed=1, k_known=False, fasta_dir=toy_fastas).load()
    rows, f = _trio_tests(cat, Trio("R", "S", "D", True))
    assert not [r for r in rows if r.stratum in AGE_LABELS or r.test == "D_pav_gradient"]
    assert sum("age strata skipped" in t for _, t in f.items()) == 1

def test_outgroup_mostly_missing(tmp_path, toy_fastas):   # Review Focus 3
    cat = simulate_run(tmp_path, seed=1, p_missing={"O": 0.8}, fasta_dir=toy_fastas).load()
    rows, f = _trio_tests(cat, Trio("R", "S", "D", True))
    removed = _row(rows, "outgroup_filter", "all", "removed_frac").value
    assert removed == pytest.approx(0.85, abs=0.03)                                # replica 0.856
    assert any(r.test == "D_pav" and r.stratum == "no_outgroup_filter" for r in rows)
    assert any(f"{removed:.2f}" in t for _, t in f.items())

def test_second_donors_and_f4(tmp_path, toy_fastas):
    genomes = [GENOMES[0], GENOMES[1], GENOMES[2], ("D2", "taxD", None, True), GENOMES[3]]
    loci = ([loc(1000 * i, "R:P S:E D:P* D2:P O:E") for i in range(1, 4)]
            + [loc(5000, "R:E S:P D:P* D2:E O:E")]
            + [loc(6000 + 1000 * i, "R:E S:E D:P* D2:P O:E") for i in range(2)])
    cat = write_run(tmp_path, loci, genomes=genomes, fasta_dir=toy_fastas).load()
    trio, dist = Trio("R", "S", "D", True), dmat({("D", "D2"): 0.1}, 0.3, cat.labels)
    assert second_donors(cat, trio, dist) == ["D2"]
    assert second_donors(cat, trio, dmat({("D", "D2"): 0.1, ("D2", "S"): 0.05}, 0.3, cat.labels)) == []
    got = {r.statistic: r.value for r in f4_ratio(cat, trio, "D2", block_size(cat), dist)}
    assert (got["num"], got["den"], got["f"], got["resolved_D2"]) == (2, 4, 0.5, 1.0)
```

`_row` reads stratum `all` for the rows that carry no stratum of their own (`roles`, `resolution`,
`outgroup_filter`): those rows are written with stratum `all`.

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_trio.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** the tests. Expected: PASS. A seeded test that fails follows the Test conventions (investigate, never
  tune).
- [ ] **Step 5: Commit.** `"Add trio roles, D_pav with age strata, nested collapse and f4-ratio"`
---

### Task 5: Inversions (DESIGN 7.7)

**Files:**
- Create: `src/ltrpav/analysis/inversions.py`, `tests/test_inversions.py`

**Interfaces:**
- Consumes: `Catalog` (merged states: any discovery); `INV_MIN_LOCI`.
- Produces:

```python
INV_COLUMNS = ("genome_x", "seqid_x", "start_x", "end_x", "bp_left_x", "bp_right_x",
               "genome_y", "seqid_y", "start_y", "end_y", "bp_left_y", "bp_right_y", "n_loci", "n_strand",
               "n_discordant")
@dataclass(frozen=True)
class InvBlock:
    x: str; y: str; seq_x: int; seq_y: int                                 # genomes and fai indexes: the keys
    start_x: int; end_x: int; start_y: int; end_y: int                     # extent of the block's loci, 1-based
    bp_left_x: tuple[int, int] | None; bp_right_x: tuple[int, int] | None  # breakpoint intervals; None at a sequence end
    bp_left_y: tuple[int, int] | None; bp_right_y: tuple[int, int] | None
    n_loci: int; n_strand: int; n_discordant: int  # block loci; of them, those whose strands also say inverted; rows merged over
def inverted_blocks(cat: Catalog) -> list[InvBlock]
def reversed_blocks(y: np.ndarray) -> list[tuple[np.ndarray, int]]
    # one (seq_x, seq_y) group's mid_y in x order -> (row indexes, n_discordant) of each kept block (the rule below)
def write_inversions(blocks: list[InvBlock], cat: Catalog, path: Path) -> None
    # names from cat.seqids for output only; intervals "lo-hi"; "." for None
def inside(blocks: list[InvBlock], label: str, partners: set[str], seq: np.ndarray, pos: np.ndarray) -> np.ndarray
    # bool per position: inside a block of label against a partner; seq = label's fai indexes, pos = 1-based positions
def inversion_rows(blocks: list[InvBlock], cat: Catalog) -> tuple[list[StatRow], Findings]
```

Blocks are keyed by (genome, fai index), never by name, so two genomes that both name a sequence "chr2" never collide
(Review Focus 1).

The algorithm is not fixed by the signatures:

```
for each pair (x, y), x before y in sheet order (outgroups included: they polarize arrangements):
  rows = loci resolved (P/S/T/E) in x and in y, with coordinates in both
  for each (seq_x, seq_y) group (fai indexes) holding >= INV_MIN_LOCI rows:
    sort by mid_x (ties: mid_y); step_i = sign(mid_y[i+1] - mid_y[i]) (0 for equal y, e.g. host_empty E sites)
    dominant = +1 if sum(step) >= 0 else -1                 # a whole reversed seqid is not an inversion
    run = maximal stretch of rows joined by steps equal to -dominant (0-steps join without breaking it)
    candidates = runs of >= 2 rows (a single row is collinear or isolated)
    merge consecutive candidates A and B (x order, left to right; a merged block is the next A): find the fewest rows
      u trimmed from A's end and v from B's start such that A's last remaining row and B's first remaining row are in
      reversed order (dominant +1: y(B) < y(A); -1: y(B) > y(A)), with u + v + (rows between A and B) < min(|A|, |B|);
      merge when found. The trimmed rows and the rows between are the block's n_discordant
    keep merged blocks with >= INV_MIN_LOCI rows of distinct mid_y outside n_discordant   (reversed_blocks: these steps)
    bp_left_x = (end_x of the row before the block, start_x of its first row); bp_right_x = (end_x of its last row,
      start_x of the row after); y intervals from the same rows' y coordinates, low-high; None at a group end
    n_strand = block rows with strand_x * strand_y == -dominant
```

Rows `inversions` (scope `x~y`):
- `n_blocks`;
- `n_blocks_1Mb` (blocks spanning >= 1 Mb on x);
- `bp_inverted_x`.

The findings name each pair's three largest blocks, and name `INV_MIN_LOCI` as a heuristic. They also note that short
inversions, and breakpoints inside unresolved stretches, show up as U `inv_site` (counted in missingness, Task 8).

- [ ] **Step 1: Write the failing tests**

```python
X = 1001 + np.arange(1500) * 998_000 // 1500 + 250        # the review probe rr_inv_fix.py's row midpoints on 1 Mb

def _inv(y, a, b):
    y = y.copy(); m = (X >= a) & (X <= b); y[m] = a + b - X[m]; return y

def make_case(case: str) -> np.ndarray:
    y0 = _inv(X.astype(float), 300_001, 700_000)
    mid = np.flatnonzero((X >= 300_001) & (X <= 700_000))
    if case == "clean inversion":
        return y0
    if case.startswith("one locus moved"):
        y = y0.copy(); y[mid[len(mid) // 2]] += 50_000 if "+" in case else -50_000; return y
    if case == "two adjacent loci moved":
        y = y0.copy(); y[mid[300]] += 50_000; y[mid[301]] += 60_000; return y
    if case == "two separate inversions on one seqid":
        return _inv(_inv(X.astype(float), 100_001, 200_000), 600_001, 800_000)
    if case == "30-locus nested re-inversion":
        y = y0.copy(); s = (X >= 480_001) & (X <= 500_000); y[s] = 500_001 + (X[s] - 480_001); return y
    if case == "collinear":
        return X.astype(float)
    if case == "wholly reversed seqid":
        return (2_000_000 - X).astype(float)
    y = X.astype(float); y[700:704] = y[700:704][::-1]; return y          # "4 reversed loci"

@pytest.mark.parametrize("case, expected", [         # expected = n_discordant of each block, in x order
    ("clean inversion", [0]), ("one locus moved +50 kb", [1]), ("one locus moved -50 kb", [1]),
    ("two adjacent loci moved", [2]), ("two separate inversions on one seqid", [0, 0]),
    ("30-locus nested re-inversion", [29]), ("collinear", []), ("wholly reversed seqid", []), ("4 reversed loci", [])])
def test_reversed_blocks_cases(case, expected):
    blocks = reversed_blocks(make_case(case))
    assert [d for _, d in blocks] == expected
    if case == "clean inversion":
        assert len(blocks[0][0]) == 601
    if case == "two separate inversions on one seqid":
        assert [len(b) for b, _ in blocks] == [150, 301]

def test_block_found(tmp_path, toy_fastas):
    cat = simulate_run(tmp_path, seed=2, inversion=("S", "chr2", 300_001, 700_000), fasta_dir=toy_fastas).load()
    blocks, spacing = inverted_blocks(cat), 998_000 // 1500
    pair = lambda a, b: [blk for blk in blocks if {blk.x, blk.y} == {a, b}]
    for other in ("R", "D", "O"):                    # every genome against S carries the inversion, S~O included
        (blk,) = pair("S", other)
        on_other = blk.x == other
        seq = blk.seq_x if on_other else blk.seq_y
        lo, hi = (blk.start_x, blk.end_x) if on_other else (blk.start_y, blk.end_y)
        left, right = (blk.bp_left_x, blk.bp_right_x) if on_other else (blk.bp_left_y, blk.bp_right_y)
        assert cat.seqids[other][seq] == "chr2" and 300_001 <= lo and hi <= 700_000 + 150
        assert abs(left[1] - 300_001) <= spacing and abs(right[0] - 700_000) <= spacing
        assert blk.n_strand == blk.n_loci and blk.n_discordant == 0
    assert not pair("R", "D") and not pair("R", "O") and not pair("D", "O")

def test_inside(tmp_path, toy_fastas):
    cat = simulate_run(tmp_path, seed=2, inversion=("S", "chr2", 300_001, 700_000), fasta_dir=toy_fastas).load()
    blocks = inverted_blocks(cat)
    chr2 = cat.seqids["R"].index("chr2")
    got = inside(blocks, "R", {"S"}, np.array([chr2, chr2, chr2, 0]), np.array([500_000, 200_000, 800_000, 500_000]))
    assert got.tolist() == [True, False, False, False]
    assert inside(blocks, "R", {"D"}, np.array([chr2]), np.array([500_000])).tolist() == [False]

def test_write_inversions(tmp_path):
    blk = InvBlock("R", "S", 1, 1, 300_001, 699_850, 300_150, 700_000, (299_400, 300_001), (699_850, 700_400),
                   None, (700_000, 700_600), 601, 601, 0)
    cat = SimpleNamespace(seqids={"R": ("chr1", "chr2"), "S": ("chr1", "chr2")})
    write_inversions([blk], cat, tmp_path / "inv.tsv")
    head, row = (tmp_path / "inv.tsv").read_text().splitlines()
    assert head.split("\t") == list(INV_COLUMNS)
    assert row.split("\t") == ["R", "chr2", "300001", "699850", "299400-300001", "699850-700400",
                               "S", "chr2", "300150", "700000", ".", "700000-700600", "601", "601", "0"]
```

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_inversions.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** the tests. Expected: PASS.
- [ ] **Step 5: Commit.** `"Add inverted blocks from chains of resolved loci"`
---

### Task 6: Painting — HMM, tracts, target-decoy q-values, youngest insertion per tract (DESIGN 7.4, 7.5)

**Files:**
- Create: `src/ltrpav/analysis/paint.py`, `tests/test_paint.py`

**Interfaces:**
- Consumes:
  - `Catalog` (`pcls`, `cls`), `Trio`, `InvBlock`, `inside`, `inverted_blocks`, `age_bin`;
  - `StatRow`, `Findings`, `resolution`, `u95`;
  - the analysis constants `PI_MAX`, `BF_TRACT`, `HMM_L_GRID`, `HMM_ITERS`, `HMM_TOL`.
- Produces:

```python
PAINT_CLASSES = ("RD", "RS", "both", "neither", "missing", "old")   # emissions: RD 0, RS 1, the rest -1 (missing data)
POSTERIOR_COLUMNS = ("lid", "seqid", "start", "end", "sister", "donor", "class", "post", "tract", "inv")
TRACT_COLUMNS = ("#chrom", "start0", "end", "name", "score", "strand", "sister", "donor", "n_loci", "n_RD", "n_RS",
                 "mean_post", "sum_post", "q", "p_decoy", "youngest_k", "youngest_u95", "n_identical", "inv_frac")
@dataclass
class HmmFit:
    pi: float; L: float; e0: np.ndarray; e1: np.ndarray; post: np.ndarray; loglik: float
@dataclass
class Tract:
    seq: int; start: int; end: int; first: int; last: int; mean_post: float; sum_post: float   # seq: X's fai index;
                                                                                                # first/last: positions in idx
@dataclass
class Painting:
    trio: Trio; idx: np.ndarray; cls: np.ndarray; post: np.ndarray; inv: np.ndarray      # recipient loci, idx in X order
    fit: HmmFit | None; donor_state: bool; tracts: list[Tract]; q: list[float | None]; p: list[float | None]
    decoy_idx: np.ndarray; decoy_cls: np.ndarray; decoy_post: np.ndarray; decoy_tracts: list[Tract]
    skipped: str | None                                                                  # why nothing was painted
def classes(cat: Catalog, X: str, Y: str, D: str, discovery: str = "recipient") -> tuple[np.ndarray, np.ndarray]
    # (idx: int64 catalog indexes in X's (fai index, start) order, cls: int8 index into PAINT_CLASSES)
def forward_backward(pos: np.ndarray, emit: np.ndarray, starts: np.ndarray, pi: float, lam: float, e0: np.ndarray,
                     e1: np.ndarray) -> tuple[np.ndarray, float, np.ndarray, np.ndarray]
    # numba: post, loglik, c1, c0; starts = each chain's first index plus a final len(pos) sentinel (LTRmix)
def fit_hmm(pos: np.ndarray, emit: np.ndarray, starts: np.ndarray, e0: np.ndarray, e1: np.ndarray) -> HmmFit
def call_tracts(seq: np.ndarray, start: np.ndarray, end: np.ndarray, post: np.ndarray, pi: float) -> list[Tract]
def target_decoy(target: np.ndarray, decoy: np.ndarray, scale: float) -> tuple[np.ndarray, np.ndarray]   # (q, p)
def shortest_callable(fit: HmmFit, spacing: float) -> tuple[tuple[int | None, float | None], tuple[int | None, float | None]]
    # ((loci, bp) lower bound: no flanks; (loci, bp) upper bound: 20 RS loci on each side)
def paint(cat: Catalog, trio: Trio, blocks: list[InvBlock], discovery: str = "recipient",
          self_counts: dict[tuple[str, str], tuple[int, int]] | None = None) -> Painting
    # self_counts: (lid, genome) -> (sites, diffs) from identity.tsv's self rows, when that file exists
def write_paintings(paintings: list[Painting], cat: Catalog, outdir: Path) -> list[Path]
def paint_rows(p: Painting, cat: Catalog) -> tuple[list[StatRow], Findings]
```

Rules:

- **`classes`** (X = target, Y = the other sister, D = donor):
  - Rows are X's members (`discovery="recipient"`).
  - Y's, D's and the outgroups' states are X's own calls (`pcls(X, ·)`). Class, checked in this order: `old` (some
    outgroup present); `missing` (Y or D unresolved); then `RD` (D present, Y E), `RS` (Y present, D E), `both`,
    `neither`.
  - The `"any"` variant takes loci with merged `cls(X) == 1` and keeps `loci.tsv`'s merged states, and says so in its
    `loci` declaration. It is DESIGN 7.1's simulation-only alternative, the one Plan 3 tests under one-sided dropout,
    and is never exposed on the command line.
- **`forward_backward`:** port LTRmix `_fb_cat` (l. 936): bp-distance switching `q = exp(-lam * d)`, `p01 = pi(1 - q)`,
  `p10 = (1 - pi)(1 - q)`, missing emission 1, a chain restarting at each `starts` boundary. Return the posterior of
  state 1 and the expected emission counts.
- **`fit_hmm`:** port `fit_hmm_cat` (l. 999). Start at pi 0.1, L 1e5. Each round scans `np.geomspace(*HMM_L_GRID)` for the
  best log-likelihood, then updates `e1 = (c1 + 0.5) / Σ`, `e0 = (c0 + 0.5) / Σ` and
  `pi = clip(mean post of emitting loci, 1e-4, PI_MAX)`. Stop at `HMM_TOL` or `HMM_ITERS`.
- **Initial emissions** (LTRmix `_hmm`): `e0` = the decoy's class frequencies + 1 (the target's own if there is no
  decoy); `e1 = e0 * (5, 0.2)`, normalized.
- **`donor_state`:** `e1[0] > e0[0]`. Without it, no tracts are called.
- **Tract length:**
  - L, the switch scale, is reported as `mean_tract_bp`: LTRmix's name and quantity (its `mean_tract_bp = Lh`).
  - The mean donor-like run under the model, `L / (1 - pi)` (the rate out of state 1 is `(1 - pi) / L`), is reported
    as `mean_donor_run_bp`.
- **`call_tracts`:** maximal runs, on one sequence (fai index), of loci with post > 0.5 and post/(1 - post) >=
  `BF_TRACT` × pi/(1 - pi). Bounds: X's start of the first locus and end of the last.
- **Decoy** (DESIGN 7.4, LTRmix):
  - S's loci under the same `discovery` (its members, classed by S's own calls `pcls(S, ·)` with X = S and Y = R, or
    S-present loci under `"any"`);
  - painted with the fitted parameters unchanged; decoy tracts use the same rule.
- **`target_decoy`:** port LTRmix's q (l. 1359-1375). Scores are each tract's `sum_post`.
  - `raw = ((#decoy >= x) * scale + 1) / #target >= x`;
  - `q` = the smallest raw at or below the tract's score, capped at 1;
  - `p = (1 + #decoy >= x) / (1 + #decoy)`;
  - `scale = n informative(R) / n informative(S)`.

  With S unannotated there is no decoy: q and p are written `none`, with a WARNING.
- **`shortest_callable`**, at the median informative spacing (consecutive RD/RS loci on one sequence):
  - The lower bound is the fewest consecutive RD loci, with no flanks, whose middle locus (index k // 2) passes the tract
    rule. Missing flanks would change nothing, because the chain is stationary across missing loci.
  - The upper bound is the same with 20 RS loci on each side.
  - For each, bp = k × spacing; k is tried from 1 to 200, and None past 200.
- **Per tract:**
  - `youngest_k` = min K of X's copy (the annotation's K2P) over the tract's RD loci, `.` without any. The admixture is
    younger than any insertion it transferred.
  - `youngest_u95`, from exact counts only:
    - it exists only when the identity layer (Task 9, `--identity`) has written `identity.tsv`. `paint` takes its self
      rows as `self_counts`; without them, the column is `.` (no K-based stand-in);
    - with them, it is the min over the tract's RD loci of `u95(diffs, sites)` (Task 2), taken from X's own copy, else
      from the donor's copy of the same insertion (also a self row; either dates it);
    - loci without a self row are left out.
  - `n_identical` = RD loci with K == 0.
  - `inv_frac` = the share of loci inside an inverted block of X against Y or D (`inside`, with X's fai indexes).
  - Posterior rows carry the same `inv` flag. The fit itself is unchanged by inverted blocks (DESIGN 7.7 flags only).
- **Skips** (`Painting.skipped`):
  - X unannotated under `"recipient"`;
  - no RD or no RS locus.
- **`write_paintings`:**
  - removes old `tracts.*.bed`, `posterior.*.tsv`, `decoy_tracts.*.bed` and `decoy_posterior.*.tsv` first;
  - writes one `tracts.<R>.bed` and `posterior.<R>.tsv` per recipient, and one `decoy_*.<S>` per sister, all trios
    included, ordered by trio scope then position;
  - BED is 0-based; name `<D>-like`; score `min(1000, int(1000 * mean_post))`; strand `.`; seqid names from
    `cat.seqids` (output only).
- **`paint_rows`** (test `paint`, scope = trio):
  - Statistics: `pi`, `mean_tract_bp` (= L), `mean_donor_run_bp` (= L/(1 - pi)), `donor_state`, `loglik`,
    `n_informative`, `n_RD`, `n_RS`, `posterior_mean`, `decoy_posterior_mean`, `excess` (their difference),
    `n_tracts`, `n_decoy_tracts`, `n_tracts_q05`, `spacing_median`, `spacing_mean`, `shortest_callable_loci_lo`,
    `shortest_callable_bp_lo`, `shortest_callable_loci_hi`, `shortest_callable_bp_hi`, `n_inv_loci`.
  - Posterior means are taken over loci, unweighted.
  - Resolution: `resolution("paint_resolution", scope, {"S": ..., "D": ...}, ...)` over X's loci from X's own calls.
  - Rows `paint_seqid`, one per X sequence (stratum = its name): `posterior_mean`, `n_RD`, `n_RS`, `class_share`
    (RD/(RD+RS)).
  - The "Dating" findings give the median `youngest_k` over tracts and the number of tracts holding an identical-LTR RD
    insertion. Two caveats go with them: K = 0 is not age 0, and LTR-LTR gene conversion (40% of maize elements, lit
    review) makes K too young, so the bound can be too recent. Without any K: one line "youngest insertion per tract
    skipped: no K2P". `youngest_u95` gets its own line only with `identity.tsv`.

- [ ] **Step 1: Write the failing tests**

```python
TOTAL = sum(b - a + 1 for _, a, b in TRACTS)

def enumerate_paths(pos, emit, pi, lam, e0, e1):
    """Brute force over the 2**n state paths of one chain: posterior of state 1 and log-likelihood."""
    n, tot, p1 = len(pos), 0.0, np.zeros(len(pos))
    for path in itertools.product((0, 1), repeat=n):
        w = pi if path[0] else 1 - pi
        for t in range(1, n):
            q = math.exp(-lam * (pos[t] - pos[t - 1])); p01, p10 = pi * (1 - q), (1 - pi) * (1 - q)
            w *= (p01 if path[t] else 1 - p01) if path[t - 1] == 0 else (1 - p10 if path[t] else p10)
        for t, k in enumerate(emit):
            if k >= 0:
                w *= (e1 if path[t] else e0)[k]
        tot += w; p1 += w * np.array(path)
    return p1 / tot, math.log(tot)

def covered_bp(tracts, cat, truth):
    """bp of the truth intervals (R seqid name, a, b) covered by called tracts on the same R sequence."""
    return sum(max(0, min(b, t.end) - max(a, t.start) + 1) for name, a, b in truth for t in tracts
               if cat.seqids["R"][t.seq] == name)

def test_forward_backward_matches_enumeration():
    pos = np.array([0.0, 5e4, 6e4, 3e5]); emit = np.array([0, 1, -1, 0])
    e0, e1 = np.array([0.3, 0.7]), np.array([0.8, 0.2])
    post, ll, c1, c0 = forward_backward(pos, emit, np.array([0, 4]), 0.2, 1 / 1e5, e0, e1)
    exp_post, exp_ll = enumerate_paths(pos, emit, 0.2, 1 / 1e5, e0, e1)
    assert np.allclose(post, exp_post, atol=1e-9) and ll == pytest.approx(exp_ll, abs=1e-9)

def test_tract_rule():
    tr = call_tracts(np.zeros(6, dtype=int), np.arange(6) * 1000 + 1, np.arange(6) * 1000 + 500,
                     np.array([0.9, 0.95, 0.4, 0.8, 0.99, 0.6]), pi=0.5)     # prior odds 1: post >= 0.75
    assert [(t.first, t.last) for t in tr] == [(0, 1), (3, 4)]

def test_target_decoy_plus_one():
    q, p = target_decoy(np.arange(30, 0, -1.0), np.array([5.5]), 1.0)
    assert np.allclose(q[:25], 1 / 25) and np.allclose(q[25:], 2 / 30)
    assert p[0] == pytest.approx(0.5) and p[-1] == pytest.approx(1.0)
    assert target_decoy(np.array([10.0]), np.array([1.0, 2.0]), 1.0)[0][0] == 1.0   # a lone target is not significant

def test_classes(tmp_path, toy_fastas):
    loci = [loc(1000, "R:P* S:E D:P O:E"), loc(2000, "R:P* S:P D:E O:E"), loc(3000, "R:P* S:P D:P O:E"),
            loc(4000, "R:P* S:E D:E O:E"), loc(5000, "R:P* S:U D:P O:E"), loc(6000, "R:P* S:E D:P O:P"),
            loc(7000, "R:P* S:E D:P* O:E", calls={("R", "S"): "U"})]          # merged S E (D's call); R's own call U
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    idx, cls = classes(cat, "R", "S", "D")
    assert idx.tolist() == list(range(7))
    assert [PAINT_CLASSES[c] for c in cls] == ["RD", "RS", "both", "neither", "missing", "old", "missing"]

def test_paint_finds_tracts(tmp_path, toy_fastas):
    cat = simulate_run(tmp_path, seed=1, tracts=TRACTS, fasta_dir=toy_fastas).load()
    p = paint(cat, Trio("R", "S", "D", False), [])
    assert p.donor_state and covered_bp(p.tracts, cat, TRACTS) >= 0.8 * TOTAL and len(p.decoy_tracts) < len(p.tracts)

def test_paint_null_and_positive_control(tmp_path, toy_fastas):
    null = paint(simulate_run(tmp_path / "n", seed=1, fasta_dir=toy_fastas).load(), Trio("R", "S", "D", False), [])
    assert sum(q is not None and q < 0.05 for q in null.q) == 0
    assert null.post.mean() < null.decoy_post.mean() + 0.05        # the fitted proportion stays at the decoy's level
    cat = simulate_run(tmp_path / "a", seed=1, tracts=TRACTS, fasta_dir=toy_fastas).load()
    adm = paint(cat, Trio("R", "S", "D", False), [])                # positive control: known tracts recovered
    assert covered_bp(adm.tracts, cat, TRACTS) >= 0.8 * TOTAL and adm.post.mean() > adm.decoy_post.mean() + 0.05

def test_outputs(tmp_path, toy_fastas):
    run = simulate_run(tmp_path, seed=1, tracts=TRACTS, inversion=("S", "chr2", 300_001, 700_000),
                       fasta_dir=toy_fastas)
    cat = run.load(); blocks = inverted_blocks(cat)
    p = paint(cat, Trio("R", "S", "D", False), blocks)
    write_paintings([p], cat, run.outdir)
    post = read_tsv(run.outdir / "posterior.R.tsv")
    assert len(post) == cat.member[:, cat.g("R")].sum() and {r["class"] for r in post} <= set(PAINT_CLASSES)
    beds = read_tsv(run.outdir / "tracts.R.bed")
    t = p.tracts[0]
    assert int(beds[0]["start0"]) == t.start - 1 and int(beds[0]["end"]) == t.end and beds[0]["youngest_u95"] == "."
    rd = [p.idx[i] for i in range(t.first, t.last + 1) if PAINT_CLASSES[p.cls[i]] == "RD"]
    assert float(beds[0]["youngest_k"]) == pytest.approx(min(cat.k[i, cat.g("R")] for i in rd))
    (blk,) = [b for b in blocks if {b.x, b.y} == {"R", "S"}]
    flagged = {cat.lid[i] for i in p.idx if cat.seq[i, cat.g("R")] == blk.seq_x
               and blk.start_x <= cat.start[i, cat.g("R")] <= blk.end_x}
    assert {r["lid"] for r in post if r["inv"] == "1"} == flagged and flagged
    assert (run.outdir / "decoy_tracts.S.bed").is_file() and (run.outdir / "decoy_posterior.S.tsv").is_file()

def test_no_decoy_without_sister_annotation(tmp_path, toy_fastas):
    genomes = [GENOMES[0], ("S", "taxS", None, False), GENOMES[2], GENOMES[3]]
    loci = ([loc(1000 * i, "R:P* S:E D:P* O:E") for i in range(1, 40)]
            + [loc(50_000 + 1000 * i, "R:P* S:P D:E O:E") for i in range(40)])
    run = write_run(tmp_path, loci, genomes=genomes, fasta_dir=toy_fastas)
    cat = run.load(); p = paint(cat, Trio("R", "S", "D", True), [])
    write_paintings([p], cat, run.outdir); _, f = paint_rows(p, cat)
    beds = read_tsv(run.outdir / "tracts.R.bed")
    assert len(beds) >= 1 and all(b["q"] == "none" and b["p_decoy"] == "none" for b in beds)
    assert any(t.startswith("WARNING:") and "decoy" in t for _, t in f.items())

def test_tracts_without_k(tmp_path, toy_fastas):   # Review Focus 2
    run = simulate_run(tmp_path, seed=1, tracts=TRACTS, k_known=False, fasta_dir=toy_fastas)
    cat = run.load(); p = paint(cat, Trio("R", "S", "D", False), [])
    write_paintings([p], cat, run.outdir); _, f = paint_rows(p, cat)
    assert p.tracts and {b["youngest_k"] for b in read_tsv(run.outdir / "tracts.R.bed")} == {"."}
    assert sum("youngest insertion per tract skipped" in t for s, t in f.items() if s == "Dating") == 1

def test_paint_many_scaffolds(tmp_path, toy_fastas):   # Review Focus 4
    seqids = ("chr1",) + tuple(f"scaf{i:03d}" for i in range(300))
    loci = ([loc(1000 * i, "R:P* S:E D:P O:E") for i in range(1, 60)]
            + [loc(70_000 + 1000 * i, "R:P* S:P D:E O:E") for i in range(60)]
            + [loc(1001, "R:P* S:E D:P O:E" if i % 2 else "R:P* S:P D:E O:E", seqid=f"scaf{i:03d}") for i in range(300)])
    cat = write_run(tmp_path, loci, seqids=seqids, seq_len=5_000, seq_lens={"chr1": 200_000},
                    fasta_dir=toy_fastas).load()
    p = paint(cat, Trio("R", "S", "D", True), [])
    assert p.skipped is None and len(p.idx) == 419 and np.isfinite(p.post).all()
    assert all(t.start <= t.end and t.first <= t.last for t in p.tracts)  # one-locus chains give well-formed tracts

def test_shortest_callable():
    fit = HmmFit(pi=0.1, L=1e5, e0=np.array([0.1, 0.9]), e1=np.array([0.9, 0.1]), post=np.zeros(0), loglik=0.0)
    assert shortest_callable(fit, 5000.0) == ((2, 10_000.0), (4, 20_000.0))   # the re-review's recomputation
```

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_paint.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified. `forward_backward` is `@njit(cache=True)`, as in `chain.py`.
- [ ] **Step 4: Run** the tests. Expected: PASS.
- [ ] **Step 5: Commit.** `"Add painting HMM with target-decoy q-values"`
---

### Task 7: Direction, exploratory (DESIGN 7.6)

**Files:**
- Create: `src/ltrpav/analysis/direction.py`, `tests/test_direction.py`

**Interfaces:**
- Consumes: `Catalog` (`pcls_by`, `proj_site`, `cls`), `age_bin`, `jackknife`, `d_ratio`, `block_ids`, `resolution`,
  distances; `Z_SIG`.
- Produces:

```python
DFOIL_ALT = {   # (left, right) patterns: presence in P1 P2 P3 P4, outgroup absent. Pease & Hahn 2015; dfoil.py weights,
                # single-derived (terminal) patterns dropped (DFOIL-alt)
    "DFO": (("1010", "1110", "0101"), ("1001", "1101", "0110")),
    "DIL": (("0110", "1001", "1110"), ("0101", "1010", "1101")),
    "DFI": (("1010", "1011", "0101"), ("0110", "0111", "1001")),
    "DOL": (("0110", "1001", "1011"), ("0101", "0111", "1010")),
}
DFOIL_ALT_SIGNS = {   # DFOIL-alt codes over DFO DIL DFI DOL: infinite-sites expectations without the single-derived
                      # patterns (checked by coalescent simulation). Each directional entry has one branch-length slot:
                      # deep root (Troot - T12 > T12 - t, Troot - T34 > T34 - t) gives the first code, a non-significant
                      # slot the second, the opposite sign one of the two ambiguous classes at the end.
    "+++-": "P1=>P3", "+0+-": "P1=>P3", "---+": "P1=>P4", "-0-+": "P1=>P4",
    "++-+": "P2=>P3", "0+-+": "P2=>P3", "--+-": "P2=>P4", "0-+-": "P2=>P4",
    "+-++": "P3=>P1", "+-+0": "P3=>P1", "-+++": "P4=>P1", "-+0+": "P4=>P1",
    "-+--": "P3=>P2", "-+-0": "P3=>P2", "+---": "P4=>P2", "+-0-": "P4=>P2",
    "++00": "P1+P2<=>P3", "--00": "P1+P2<=>P4",
    "+-+-": "P1<=>P3 or P2<=>P4 (direction unresolved)", "-+-+": "P1<=>P4 or P2<=>P3 (direction unresolved)",
}
PAIR_DISC = {   # each left|right pattern pair: genomes present in both patterns that may discover it, in order of use
    "DFO": {("1010", "1001"): ("P1",), ("1110", "1101"): ("P1", "P2"), ("0101", "0110"): ("P2",)},
    "DIL": {("0110", "0101"): ("P2",), ("1110", "1101"): ("P1", "P2"), ("1001", "1010"): ("P1",)},
    "DFI": {("1010", "0110"): ("P3",), ("1011", "0111"): ("P3", "P4"), ("0101", "1001"): ("P4",)},
    "DOL": {("1001", "0101"): ("P4",), ("1011", "0111"): ("P3", "P4"), ("0110", "1010"): ("P3",)},
}
def taxa(cat: Catalog) -> dict[str, tuple[str, ...]]       # group -> its ingroup genomes, groups with >= 2 genomes
def dfoil_values(counts: dict[str, float]) -> dict[str, float]
    # pattern -> count  ->  DFO DIL DFI DOL = (left - right) / (left + right); nan for 0 / 0
def pair_counts(cat: Catalog, quartet: tuple[str, str, str, str], z: tuple[str, ...]) -> dict[str, dict[str, int]]
    # statistic -> pattern -> count, each pattern counted by its PAIR_DISC rule on the quartet (P1, P2, P3, P4)
def signature(z: dict[str, float]) -> str
    # sign code over DFO DIL DFI DOL: "+" / "-" when |z| >= Z_SIG, else "0" (nan too); the DFOIL_ALT_SIGNS label, else "none"
def direction(cat: Catalog, size: int, dist: np.ndarray) -> tuple[list[StatRow], Findings]
```

The rules are not fixed by the signatures:

```
no outgroup, or fewer than two taxa with >= 2 genomes -> every row skipped, one findings line with the reason
  ("skipped: no outgroup", "skipped: needs two genomes per taxon")
for each pair of taxa X, Y (order of first sheet appearance):
  Z = ingroup genomes outside X and Y ("absent from the sister taxon's genomes")
  n(X->Y), n(Y->X), 4-LIST: merged states, disc=any, with a findings note that three present genomes nearly saturate
    discovery (Plan 3's one-sided dropout runs check it):
    rows = loci resolved in every genome of X, Y, Z and the outgroups, with Z and the outgroups all E
    n(X->Y) = all X present and 1 <= (Y present) <= |Y| - 1;  n(Y->X) the mirror
    D_dir = (n(X->Y) - n(Y->X)) / sum, jackknife on the first X+Y genome's merged coordinates; strata "all" and the age
      bins of the median member K; rows test "direction", scope "X>Y", statistics D_dir, n_XY, n_YX
    resolution(...) rows: each genome of X, Y, Z and the outgroups, resolved fraction among loci present in some X or Y
  each quartet (two genomes of X, two of Y): (P1, P2) = the pair with the smaller PAV distance (DFOIL needs the more
    recent split there)
    pair_counts: per left|right pattern pair (PAIR_DISC), gstar = the first listed genome that is a member at the row;
      the pair's patterns are read from gstar's own calls on rows where gstar's calls resolve all four quartet genomes,
      Z and the outgroups, with Z and the outgroups E
    each DFOIL-alt statistic: left - right summed over its three pairs, / their sum; jackknife on P1's coordinates as
      each row's gstar reads them (proj_site)
    rows "dfoil", scope "P1,P2;P3,P4": statistics DFO DIL DFI DOL (value, se, z) and "signature" (signature()); then
      resolution(...) rows for the four quartet genomes in the gstar calls; then the ten 4-LIST pattern counts (two or
      three of the four present; merged states) as rows "four_list", statistic = the pattern
every row's note: "exploratory: kept only if simulations with known direction recover it (DESIGN 7.6, 10.2)";
  D_dir rows add: "not read as direction: unequal Ne alone drives it (no gene flow: +0.93 at Ne 1000 vs 5000), and drift
  in a small recipient fixes transferred insertions. DFOIL-alt is the direction statistic."
```

- [ ] **Step 1: Write the failing tests**

```python
QUARTET = [("x1", "X", None, True), ("x2", "X", None, True), ("y1", "Y", None, True), ("y2", "Y", None, True)]
OUT = ("O", "OG", "outgroup", False)

def spec(p: str, member: int | None = None) -> str:
    """'x1:P* x2:E y1:P y2:E O:E' from presence pattern p over x1 x2 y1 y2; member = index (default: the first present)."""
    m = p.index("1") if member is None else member
    return " ".join(f"{g}:{'P' if c == '1' else 'E'}{'*' if j == m else ''}"
                    for j, (g, c) in enumerate(zip(("x1", "x2", "y1", "y2"), p))) + " O:E"

def test_counts(tmp_path, toy_fastas):
    genomes = [*QUARTET, ("z", "Z", None, True), OUT]
    loci = ([loc(1000 * i, "x1:P* x2:P y1:P y2:E z:E O:E") for i in range(1, 4)]     # X->Y x3
            + [loc(5000, "x1:P* x2:E y1:P y2:P z:E O:E")]                              # Y->X x1
            + [loc(6000, "x1:P* x2:P y1:P y2:E z:P O:E"), loc(7000, "x1:P* x2:P y1:P y2:E z:E O:U")])   # not counted
    cat = write_run(tmp_path, loci, genomes=genomes, fasta_dir=toy_fastas).load()
    rows, f = direction(cat, block_size(cat), pav_distances(cat)[0])
    got = {r.statistic: r.value for r in rows if r.test == "direction" and r.stratum == "all"}
    assert (got["n_XY"], got["n_YX"], got["D_dir"]) == (3, 1, 0.5) and all("exploratory" in r.note for r in rows)

def test_dfoil_alt_values():
    v = dfoil_values({"1010": 4, "1001": 1})
    assert [round(v[k], 3) for k in ("DFO", "DIL", "DFI", "DOL")] == [0.6, -0.6, 0.6, -0.6]
    assert math.isnan(dfoil_values({"1110": 1})["DFI"])

def test_dfoil_signature():
    assert signature({"DFO": 4, "DIL": 5, "DFI": 3.5, "DOL": -4}) == "P1=>P3"
    assert signature({"DFO": 4, "DIL": 5, "DFI": 3.5, "DOL": 0.2}) == "none"    # full-DFOIL P1=>P3 is no alt code
    assert signature({"DFO": 4, "DIL": -5, "DFI": 3.5, "DOL": -4}).startswith("P1<=>P3 or P2<=>P4")

# expected DFOIL-alt pattern counts by the branch-length rule: on ((P1,P2),(P3,P4)),O with T12 = 2, T34 = 4, Troot = 8,
# each branch adds its length to the pattern of the leaves below it; with f = 0.1 the recipient's lineage follows the
# donor's from t = 1 (ancestral scenarios: the P1+P2 ancestor's, from t = 3). The species tree holds none of these
# patterns, so each count is f times its branch length in the migrant genealogy.
BRANCH_COUNTS = {
    "P1=>P3": {"1010": 0.1, "1110": 0.6}, "P1=>P4": {"1001": 0.1, "1101": 0.6},
    "P2=>P3": {"0110": 0.1, "1110": 0.6}, "P2=>P4": {"0101": 0.1, "1101": 0.6},
    "P3=>P1": {"1010": 0.3, "1011": 0.4}, "P4=>P1": {"1001": 0.3, "1011": 0.4},
    "P3=>P2": {"0110": 0.3, "0111": 0.4}, "P4=>P2": {"0101": 0.3, "0111": 0.4},
    "P1+P2<=>P3": {"1110": 0.5}, "P1+P2<=>P4": {"1101": 0.5}}

def test_dfoil_alt_signatures_from_branch_lengths():
    for scenario, counts in BRANCH_COUNTS.items():
        assert signature({k: 1000 * x for k, x in dfoil_values(counts).items()}) == scenario

def test_pair_discovery(tmp_path, toy_fastas):
    loci = [loc(1000, spec("1010", member=2)),      # 1010 discovered only by P3 (y1)
            loc(2000, spec("1010", member=0)),      # 1010 discovered by P1 (x1)
            loc(3000, spec("1110", member=1))]      # 1110 with P1 not a member: read from P2's (x2) calls
    cat = write_run(tmp_path, loci, genomes=[*QUARTET, OUT], fasta_dir=toy_fastas).load()
    pc = pair_counts(cat, ("x1", "x2", "y1", "y2"), ())
    assert pc["DFO"].get("1010", 0) == 1 and pc["DFO"].get("1110", 0) == 1 and pc["DFI"].get("1010", 0) == 1

def test_four_list_counts(tmp_path, toy_fastas):
    pats = ["1100", "1010", "1001", "0110", "0101", "0011", "1110", "1101", "1011", "0111"]
    loci = ([loc(20_000 * i + 1000 * (k + 1), spec(p)) for i, p in enumerate(pats) for k in range(i + 1)]
            + [loc(900_000, spec("1000"))])
    cat = write_run(tmp_path, loci, genomes=[*QUARTET, OUT], fasta_dir=toy_fastas).load()
    rows, _ = direction(cat, block_size(cat), dmat({("x1", "x2"): 0.05}, 0.5, cat.labels))
    assert {r.statistic: r.value for r in rows if r.test == "four_list"} == {p: i + 1 for i, p in enumerate(pats)}

def test_skips(tmp_path, toy_fastas):
    cat = write_run(tmp_path / "a", [loc(1000, spec("1100"))], genomes=QUARTET, fasta_dir=toy_fastas).load()
    rows, f = direction(cat, block_size(cat), pav_distances(cat)[0])
    assert rows == [] and any("skipped: no outgroup" in t for _, t in f.items())
    cat = write_run(tmp_path / "b", [loc(1000, "R:P* S:P D:E O:E")], fasta_dir=toy_fastas).load()
    rows, f = direction(cat, block_size(cat), pav_distances(cat)[0])
    assert rows == [] and any("skipped: needs two genomes per taxon" in t for _, t in f.items())

def test_p1p2_by_distance(tmp_path, toy_fastas):
    cat = write_run(tmp_path, [loc(1000, spec("1010")), loc(2000, spec("0101"))], genomes=[*QUARTET, OUT],
                    fasta_dir=toy_fastas).load()
    scope = lambda d: {r.scope for r in direction(cat, block_size(cat), d)[0] if r.test == "dfoil"}
    assert scope(dmat({("x1", "x2"): 0.05, ("y1", "y2"): 0.2}, 0.5, cat.labels)) == {"x1,x2;y1,y2"}
    assert scope(dmat({("x1", "x2"): 0.3, ("y1", "y2"): 0.05}, 0.5, cat.labels)) == {"y1,y2;x1,x2"}
```

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_direction.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** the tests. Expected: PASS.
- [ ] **Step 5: Commit.** `"Add exploratory direction tests: n(X->Y), DFOIL-alt, 4-LIST counts"`
---

### Task 8: Mechanisms and missingness (DESIGN 7.8)

**Files:**
- Create: `src/ltrpav/analysis/mechanisms.py`, `tests/test_mechanisms.py`

**Interfaces:**
- Consumes:
  - `Catalog`, `Node`, `age_bin`, `read_elements`, `CALL_COLUMNS`;
  - `MIN_SEG`, `SLOP_TSD_MULT`, `TSD_DEFAULT` (engine constants, read only), `samples.PAIR_SEP`.
- Produces:

```python
MECH_COLUMNS = ("table", "scope", "superfamily", "family", "age_bin", "metric", "value")
def pair_calls(path: Path) -> Iterator[dict[str, str]]     # streamed; fails on a header that is not CALL_COLUMNS
def o_kind(dl: int, dr: int, tsd: str | None) -> str       # "O_site" if |dl| <= w and |dr| <= w, else "O_complex"
def d_kind(dl: int, dr: int, tsd: str | None) -> str       # "D_inside" if dl < -w or dr < -w, else "D_beyond"
                                                           # w = SLOP_TSD_MULT * L (L = len(tsd) or TSD_DEFAULT)
def pair_mechanisms(cat: Catalog, a: str, b: str) -> tuple[list[tuple], list[StatRow]]
def dollo(cat: Catalog, tree: Node) -> tuple[list[tuple], list[StatRow]]
def mechanisms(cat: Catalog, tree: Node | None) -> tuple[list[tuple], list[StatRow], Findings]
def write_mechanisms(rows: list[tuple], path: Path) -> None   # sorted by (table, scope, superfamily, family, age_bin, metric)
```

Rules. Each ordered pair file `pairs/<A>__<B>.calls.tsv.gz` is read once. A call's age bin and family come from A's element
(`work/elements/<A>.tsv`). Age bins are labeled with `AGE_LABELS`, plus `all`.

- **`d_kind`:** a gap end lying more than w inside the element means B keeps fewer than `MIN_SEG` aligned bases of it
  but still some of its sequence, so B carried the element: `D_inside`, a derived absence. Otherwise `D_beyond`.
- **table `states`:**
  - metrics `n_P n_S n_T n_E n_D_inside n_D_beyond n_O_site n_O_complex n_G n_U`;
  - per (superfamily, family, age_bin), with rollups `all` for family, superfamily and age.
  - O is split with `o_kind` (the brief: O includes complex events; `dl`, `dr`, `b_ins` separate them); D with `d_kind`.
- **table `absence`** (per age bin and `all`; superfamily and family `all`): `n_absent` (E + D + O), then `frac_E`,
  `frac_D_inside`, `frac_D_beyond`, `frac_O_site`, `frac_O_complex`.
  - `frac_E` is ancestral, shown: an empty site, with no precise excision.
  - `frac_D_inside` is derived, shown.
  - The other three are not determined (DESIGN 5.4: D and O say nothing about whether the insertion happened): a deletion
    in B, an A-only insertion of an unannotated unit, an independent insertion at the site, or a replacement.
- **table `events`** (scope `A>B`, superfamily, family and age `all`; absence events from `parent` links and flags):
  - an E event is an E call without `host_empty`, together with its descendants that are E with `host_empty`;
  - a D event is a D call without `inherit`, together with its descendants that are D with `inherit`;
  - E calls flagged `adjacent` within one `wid` form one event, and D calls likewise.

  An event with more than one element, or an `adjacent` one, is multi-element:
  - E: a nested cluster inserted as a unit;
  - D: a multi-element deletion, whose own origin stays open as for any D.

  Metrics: `n_E_single n_E_cluster n_E_cluster_elements n_D_single n_D_multi n_D_multi_elements`.
- **table `missingness`:** `U_<reason>` and `G`, as fractions of the pair's calls.
- **`dollo`** (needs an outgroup and the rooted tree; otherwise one "skipped" line), over merged states:
  - present = genomes with `cls == 1`; the clade is their MRCA.
  - An E genome under the clade makes the locus incongruent: counted, not placed.
  - Otherwise the insertion goes on the branch above the clade (`before_root` at the root).
  - For each of S, T and D: one event per maximal subclade of the clade whose genomes are all that state or missing,
    with at least one of the state. "Missing" is D/O/G/U for S and T events, and O/G/U for D events. A D genome outside
    the clade is not placed: it is missing.
  - Branch label = its leaves joined by `+` in sheet order.
  - Table `branches`: per (branch, superfamily) and `all`, `n_insertion n_solo n_truncation n_deletion`. Scope
    `incongruent` (superfamily `all`): `n_loci`.
- **Stats rows** mirror the absence, event and branch tables: tests `mechanisms`, `absence_events`, `branches`,
  `missingness`.
- **Findings:**
  - per pair and by age: "absences not shown ancestral = 1 - frac_E (an upper bound on derived absences); shown
    derived = frac_D_inside (a lower bound)";
  - the multi-element split (clusters against deletions);
  - insertions and losses per branch.

- [ ] **Step 1: Write the failing tests**

```python
def _table(rows, table, scope):
    """{(superfamily, family, age_bin, metric): value} of one table and scope."""
    return {(sf, fam, age, m): v for t, sc, sf, fam, age, m, v in rows if (t, sc) == (table, scope)}

def test_o_kind_and_d_kind():
    assert o_kind(3, -2, "ACGTA") == "O_site" and o_kind(400, 0, "ACGTA") == "O_complex"
    assert o_kind(10, 10, None) == "O_site" and o_kind(11, 0, None) == "O_complex"    # TSD_DEFAULT 5 -> w 10
    assert d_kind(-12, 0, "ACGTA") == "D_inside" and d_kind(300, 0, "ACGTA") == "D_beyond"

def test_state_counts_by_family_age(tmp_path, toy_fastas):
    loci = [loc(1000, "R:P* S:E D:E O:E", k=0.0), loc(2000, "R:P* S:E D:E O:E", k=0.02),
            loc(3000, "R:P* S:D D:E O:E", k=0.02, family="famB", superfamily="Copia", evidence={"S": (300, 0, 0)}),
            loc(4000, "R:P* S:O D:E O:E", k=0.004, family="famB", superfamily="Copia", evidence={"S": (2, -1, 500)}),
            loc(5000, "R:P* S:P D:E O:E", k=0.0)]
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    st = _table(mechanisms(cat, None)[0], "states", "R>S")
    assert st[("Gypsy", "famA", "K=0", "n_E")] == 1 and st[("Gypsy", "famA", "K>=0.01", "n_E")] == 1
    assert st[("Copia", "famB", "K>=0.01", "n_D_beyond")] == 1 and st[("Copia", "famB", "0<K<0.01", "n_O_site")] == 1
    assert st[("all", "all", "all", "n_E")] == 2 and st[("all", "all", "all", "n_P")] == 1
    assert st[("Gypsy", "all", "K=0", "n_P")] == 1

def test_absence_fractions(tmp_path, toy_fastas):
    specs = ([("E", (0, 0, 0))] * 4 + [("D", (-12, 0, 0))] + [("D", (300, 0, 0))] * 2
             + [("O", (2, -1, 500))] + [("O", (400, 0, 900))] * 2)
    loci = [loc(1000 * (i + 1), f"R:P* S:{s} D:E O:E", evidence={"S": ev}) for i, (s, ev) in enumerate(specs)]
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    ab = _table(mechanisms(cat, None)[0], "absence", "R>S")
    got = [ab[("all", "all", "all", m)] for m in ("n_absent", "frac_E", "frac_D_inside", "frac_D_beyond",
                                                  "frac_O_site", "frac_O_complex")]
    assert got == [10, 0.4, 0.1, 0.2, 0.1, 0.2]

def test_absence_events(tmp_path, toy_fastas):
    loci = [loc(10_000, "R:P* S:E D:E O:E", length=6000),
            loc(11_000, "R:P* S:E D:E O:E", parent=0, flags={"S": ["host_empty"]}),
            loc(12_000, "R:P* S:E D:E O:E", parent=0, flags={"S": ["host_empty"]}),
            loc(30_000, "R:P* S:D D:E O:E", length=6000),
            loc(31_000, "R:P* S:D D:E O:E", parent=3, flags={"S": ["inherit"]}),
            loc(50_000, "R:P* S:E D:E O:E"),
            loc(60_000, "R:P* S:E D:E O:E", flags={"S": ["adjacent"]}, wid=7),
            loc(60_400, "R:P* S:E D:E O:E", flags={"S": ["adjacent"]}, wid=7)]
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    ev = {m: v for (sf, fam, age, m), v in _table(mechanisms(cat, None)[0], "events", "R>S").items()}
    assert (ev["n_E_single"], ev["n_E_cluster"], ev["n_E_cluster_elements"]) == (1, 2, 5)
    assert (ev["n_D_single"], ev["n_D_multi"], ev["n_D_multi_elements"]) == (0, 1, 2)

def test_dollo_branches(tmp_path, toy_fastas):
    loci = [loc(1000, "R:P* S:P D:E O:E"),      # insertion on R+S
            loc(2000, "R:S S:P* D:E O:E"),      # insertion on R+S, solo on R
            loc(3000, "R:D S:P* D:P O:E"),      # insertion on R+S+D, deletion on R
            loc(4000, "R:D S:P* D:E O:E"),      # insertion on S; R outside the clade: missing, no deletion
            loc(5000, "R:P* S:E D:P O:E")]      # incongruent: S E inside the R+S+D clade
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    tree = Node(None, (Node("O"), Node(None, (Node(None, (Node("R"), Node("S"))), Node("D")))))
    rows, _ = dollo(cat, tree)
    br = lambda scope, m: _table(rows, "branches", scope).get(("all", "all", "all", m), 0)
    assert (br("R+S", "n_insertion"), br("R+S+D", "n_insertion"), br("S", "n_insertion")) == (2, 1, 1)
    assert (br("R", "n_solo"), br("R", "n_deletion"), br("incongruent", "n_loci")) == (1, 1, 1)

def test_missingness(tmp_path, toy_fastas):
    loci = ([loc(1000 * (i + 1), "R:P* S:U D:E O:E") for i in range(3)]
            + [loc(5000, "R:P* S:G D:E O:E"), loc(6000, "R:P* S:E D:E O:E")])
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    mi = _table(mechanisms(cat, None)[0], "missingness", "R>S")
    assert mi[("all", "all", "all", "U_no_anchor")] == pytest.approx(3 / 5) and mi[("all", "all", "all", "G")] == pytest.approx(1 / 5)

def test_write_mechanisms(tmp_path):
    rows = [("states", "R>S", "all", "all", "all", "n_E", 2), ("absence", "R>S", "all", "all", "K=0", "frac_E", 0.5)]
    write_mechanisms(rows, tmp_path / "m.tsv")
    lines = (tmp_path / "m.tsv").read_text().splitlines()
    assert lines[0].split("\t") == list(MECH_COLUMNS)
    assert lines[1:] == ["absence\tR>S\tall\tall\tK=0\tfrac_E\t0.5", "states\tR>S\tall\tall\tall\tn_E\t2"]
```

Missingness, event and branch rows carry superfamily, family and age `all`.

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_mechanisms.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** the tests. Expected: PASS.
- [ ] **Step 5: Commit.** `"Add mechanisms: states by family and age, absence events, Dollo placement"`
---

### Task 9: Sequence-identity layer, optional (DESIGN 7.5)

**Files:**
- Create: `src/ltrpav/analysis/identity.py`, `tests/test_identity.py`
- Modify: `src/ltrpav/analysis/constants.py` (append `MG_MAX`, `IDENT_MIN_SITES`)

**Interfaces:**
- Consumes:
  - `Catalog` (`pcls`, `pseq`, `pstart`, `pend`, `pstrand`), `Trio`, `discover`, `block_ids`, `jackknife`, `u95`;
  - `localign.align_window` with `constants.DEFAULT_BACKEND` (LASTZ, the engine's aligner), `seqio.Fasta`, `revcomp`,
    `read_elements`;
  - `MIN_SEG`, `WINDOW_PAD` (engine constants, read only);
  - `scipy.special.gammaincc`, `scipy.stats.chi2`, `scipy.optimize.minimize`.
- Produces:

```python
IDENTITY_COLUMNS = ("kind", "lid", "trio", "genome", "partner", "sites", "diffs", "div", "u95", "young")
def ltr_counts(x: str, y: str, ltrs: list[tuple[int, int]]) -> tuple[int, int]   # (sites, substitutions) in x's LTR columns
def self_counts(ltr5: str, ltr3: str) -> tuple[int, int]
def orient(x: str, y: str) -> int        # +1 / -1: y's strand that aligns x better (>= MIN_SEG bases); 0: neither aligns
def split_nll(params: np.ndarray, k: np.ndarray, n: np.ndarray) -> float          # params = (log s, log m)
def fit_split(k: np.ndarray, n: np.ndarray, start: tuple[float, float] = (1e-3, 1e-2)) -> tuple[float, float]
def fit_mix(k: np.ndarray, n: np.ndarray, s0: float, m0: float) -> tuple[np.ndarray, float, float, float, float, float]
    # (weights isolation/gene flow/tail, gene-flow mean, s, m, tail mean, nll): LTRmix fit_mix, its 18 starts
def pred_cdf(x: float, n: np.ndarray, s: float, m: float, nsim: int = 200, seed: int = 0) -> float   # LTRmix pred_cdf
def identity(cat: Catalog, trio: Trio, size: int, threads: int, dist: np.ndarray
             ) -> tuple[list[StatRow], Findings, list[tuple]]
def write_identity(rows: list[tuple], path: Path) -> None
```

Rules. This is outside the PAV-only core. Rows have layer `identity`, the findings their own section, and per-locus rows
go to `identity.tsv`.

- **Constants**, appended to `ltrpav/analysis/constants.py`:

```python
MG_MAX = 1e-3              # mixture fit: post-split gene-flow component's mean divergence <= 0.1% (LTRmix rate_free_split.py)
IDENT_MIN_SITES = 200      # LTR sites an ortholog pair needs to enter the split fit: LTRmix's validated --min-sites
```

- **Needs D annotated** (D's LTR bounds); otherwise skipped with a line.
- **The aligner** is the engine's: `align_window(x, y, "asm20", DEFAULT_BACKEND)`, LASTZ. Its preset argument is the
  engine's own default.
- **`ltr_counts`** counts aligned columns and substitutions exactly, by comparing bases over each segment's overlap with
  the LTR intervals; columns with N on either side are skipped. **`self_counts`** does the same, aligning the 5' LTR to
  the 3' LTR.
- **Loci the layer reads:**
  - the pair loci: loci D discovers where D's own call into Y (S or R) is P;
  - the D_pav counted rows, `discover(cat, R, S, D, dist, "E")` (all tiers, outgroup E);
  - the loci of R's RD painting class (R a member; R's own calls give D present, S E).
- **`identity.tsv` row kinds:**
  - **self rows:** one per annotated copy of R, S or D at those loci whose two LTRs align (`self_counts` with
    >= `MIN_SEG` sites). `genome` = the copy's genome, partner `.`, `u95` from `stats.u95`.
  - **pair rows:** one per pair locus and partner Y with two P copies. `genome` = D, `partner` = Y.
  - Loci with neither get no row.
- **Pair alignment:**
  - Y's site comes from D's own call: `pseq[D][:, Y]`, `pstart`, `pend`, `pstrand`.
  - x = D's element and y = Y's site ± `WINDOW_PAD`, both fetched on their genome's + strand. y is reverse-complemented
    when its strand differs from D's.
  - Where either strand is unknown (BED annotations write `.`), `orient(x, y)` takes the orientation from the alignment.
    A pair it cannot orient is skipped and counted, never silently: one findings line "<n> pair(s) skipped: orientation
    not inferred".
  - The LTR intervals are D's `ltr_left` and `ltr_right` in x coordinates.
  - Pairs with `sites < IDENT_MIN_SITES` are written with `div` `.` and left out of the fits.
- **Rate-free split** (LTRmix `rate_free_split.py`):
  - **Isolation model:** k ~ Poisson(n(s + X)), X ~ Exp(m), with the closed form
    `s/m - log(m n) - (k+1) log(1 + 1/(n m)) + log Q(k+1, n (1 + 1/(n m)) s)`. Nelder-Mead on the logs, fitted to the
    S–D pairs. SE of s and m by delete-one-block jackknife on D's blocks, each refit starting from the full fit.
  - **Guard, the mixture fit** (`fit_mix`): isolation, plus post-split gene flow (unshifted, mean <= `MG_MAX`), plus an
    unshifted upper tail. Post-split S–D gene flow pulls the isolation s down: LTRmix's own check found 0.024% against a
    true 0.18% at 4% gene flow. Rows: `s_mix`, `m_mix`, `w_iso`, `w_flow`, `w_tail`, `m_flow`, `m_tail`, and `aic_mix`
    against `aic_iso` (2·nll + 12 against 2·nll + 4).
  - **Fit check** (LTRmix's points): for x in 0, 0.001, 0.002, 0.003 and 0.005, `cdf_obs_<x>` (observed fraction of
    pairs with diffs/sites <= x) against `cdf_fit_<x>` (`pred_cdf` under the isolation fit).
- **Younger than the split** (on the D_pav counted rows):
  - each RD and SD locus whose D copy has a self row is young if its `u95 < s` (column `young` 1 or 0);
  - counts `n_RD_young`, `n_SD_young`, `D_young`;
  - `sites_needed = chi2.ppf(0.95, 2) / 2 / s`: identical LTR sites a single insertion needs to qualify.
- **Below the split:** fractions of R–D and of S–D pairs with `diffs / sites < s`.
- **Rows:**
  - `identity_split` (scope `S;D`): `s`, `m` (with se), the mixture rows, the fit-check rows, n pairs;
  - `identity_young` (trio): `n_RD_young`, `n_SD_young`, `D_young`, `sites_needed`;
  - `identity_below_split`: `frac_RD_below`, `frac_SD_below`.
- **Workers:** a fork `ProcessPoolExecutor(threads)` over locus chunks. Each worker opens its own `Fasta` (cache
  `work/fai`); results come back in locus order.

- [ ] **Step 1: Write the failing tests**

```python
needs_lastz = pytest.mark.skipif(shutil.which("lastz") is None, reason="lastz missing (the engine's aligner)")

def substitute(seq: str, positions: list[int]) -> str:
    """Each listed base replaced by the next one in ACGT order (always a change)."""
    s = list(seq)
    for p in positions:
        s[p] = "ACGT"[("ACGT".index(s[p]) + 1) % 4]
    return "".join(s)

INT_POSITIONS_12 = [500 + 250 * i for i in range(12)]           # inside the internal region [400, 3400)

@needs_lastz
def test_ltr_counts_exact():
    rng = random.Random(5); e = toy.make_element(rng, 400, 3000)[0]          # LTRs [0, 400) and [3400, 3800)
    y = toy.rand_seq(800, rng) + substitute(e, [10, 50, 90, 120, 3405, 3700] + INT_POSITIONS_12) + toy.rand_seq(800, rng)
    assert ltr_counts(e, y, [(0, 400), (3400, 3800)]) == (800, 6)

@needs_lastz
def test_self_counts():
    rng = random.Random(6); ltr = toy.rand_seq(400, rng)
    assert self_counts(ltr, substitute(ltr, [20, 200, 380])) == (400, 3)

@needs_lastz
def test_orient():
    rng = random.Random(7); e = toy.make_element(rng, 400, 2000)[0]
    site = toy.rand_seq(500, rng) + e + toy.rand_seq(500, rng)
    assert orient(e, site) == 1 and orient(e, revcomp(site)) == -1 and orient(e, toy.rand_seq(3800, rng)) == 0

def test_fit_split_recovers():
    rng = np.random.default_rng(1); n = np.full(50_000, 800.0)
    k = rng.poisson(n * (0.002 + rng.exponential(0.01, n.size)))
    s, m = fit_split(k, n)
    assert s == pytest.approx(0.002, rel=0.15) and m == pytest.approx(0.01, rel=0.15)

@pytest.mark.slow          # about 5 min (18 Nelder-Mead starts on 50,000 pairs; 10,000 is too few): CI deselects it
def test_fit_mix_guards_against_gene_flow():
    rng = np.random.default_rng(2); n = np.full(50_000, 800.0)
    flow = rng.random(n.size) < 0.04                                          # 4% post-split gene flow
    k = rng.poisson(n * np.where(flow, rng.exponential(3e-4, n.size), 0.002 + rng.exponential(0.01, n.size)))
    s_iso, m_iso = fit_split(k, n)
    w, m_flow, s_mix, m_mix, m_tail, nll = fit_mix(k, n, s_iso, m_iso)
    assert abs(s_mix - 0.002) < abs(s_iso - 0.002) and 0.01 < w[1] < 0.1    # re-review: w_flow 0.042, s 0.00210 vs 0.00115

def test_pred_cdf_at_zero():
    n = np.full(1000, 800.0)                                                  # P(k = 0) = e^(-ns) / (1 + nm)
    assert pred_cdf(0.0, n, 0.002, 0.01) == pytest.approx(math.exp(-1.6) / 9, abs=0.01)

@needs_lastz
def test_identity_end_to_end(tmp_path, toy_fastas):
    rng = random.Random(9)
    els = [toy.make_element(rng, 400, 2000)[0] for _ in range(7)]          # 2,800 bp; LTRs [0, 400) and [2400, 2800)
    flanks = [toy.rand_seq(2000, rng) for _ in range(8)]
    copies = {"D": els,
              "R": [substitute(e, list(range(10, 10 * i + 1, 10))) for i, e in enumerate(els[:6])] + [els[6]],
              "S": [substitute(e, [2500]) for e in els[:6]] + [toy.rand_seq(2800, rng)]}   # S's 7th site: unrelated
    fastas = {}
    for g, cs in copies.items():
        fastas[g] = tmp_path / f"{g}.fa"
        fastas[g].write_text(">chr1\n" + "".join(f + c for f, c in zip(flanks, cs)) + flanks[7] + "\n")
    pos = [2001 + 4800 * i for i in range(7)]
    loci = ([loc(p, "R:P* S:P* D:P* O:E", length=2800, ltr=400) for p in pos[:6]]
            + [loc(pos[6], "R:P* S:P D:P* O:E", length=2800, ltr=400, strand={"D": "."})])
    cat = write_run(tmp_path / "run", loci, seqids=("chr1",), fastas=fastas, fasta_dir=toy_fastas).load()
    rows, f, out = identity(cat, Trio("R", "S", "D", True), block_size(cat), 2, pav_distances(cat)[0])
    pairs = sorted((r[1], r[4], r[5], r[6]) for r in out if r[0] == "pair")       # (lid, partner, sites, diffs)
    assert [(s, d) for _, y, s, d in pairs if y == "R"] == [(800, i) for i in range(6)] + [(800, 0)]
    assert [(s, d) for _, y, s, d in pairs if y == "S"] == [(800, 1)] * 6
    selfs = {(r[3], r[1]): (r[5], r[6]) for r in out if r[0] == "self"}          # (genome, lid) -> (sites, diffs)
    assert len(selfs) == 20 and {s for s, _ in selfs.values()} == {400}
    assert [selfs[("R", lid)][1] for lid in cat.lid] == [0, 1, 2, 3, 4, 5, 0]
    assert {selfs[("S", lid)][1] for lid in cat.lid[:6]} == {1} and {selfs[("D", lid)][1] for lid in cat.lid} == {0}
    assert rows and all(r.layer == "identity" for r in rows)
    assert any("1 pair(s) skipped: orientation not inferred" in t for _, t in f.items())
```

`test_pred_cdf_at_zero` uses the model's closed form at k = 0: `P(k=0) = e^(-ns) / (1 + nm)`, with n = 800, s = 0.002,
m = 0.01. The tolerance 0.01 covers its 200-replicate simulation.

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_identity.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** `python -m pytest -W error tests/test_identity.py`. This is the one run that includes the slow
  `fit_mix` test, about 5 min; the suite command deselects it everywhere else. Expected: PASS.
- [ ] **Step 5: Commit.** `"Add optional sequence-identity layer with rate-free split"`
---

### Task 10: Stages, assembly and commands

**Files:**
- Create: `src/ltrpav/analysis/report.py`, `src/ltrpav/analysis/cli.py`, `tests/test_cli_analysis.py`
- Modify:
  - `src/ltrpav/cli.py`: the single engine hook (below);
  - `pyproject.toml`: scripts `ltrpav-stats = "ltrpav.analysis.cli:stats_main"` and
    `ltrpav-paint = "ltrpav.analysis.cli:paint_main"`, then `pip install -e . --no-deps` in the env;
  - `docs/DESIGN.md` section 8 (checkpointing).

**Interfaces:**
- Consumes:
  - every module above; `checkpoint.file_checksum`, `package_fingerprint`, `stage_key`, `is_done`, `mark_done`,
    `clear_done`;
  - `ltrpav.cli._execute`, `_options`, `CliError` (imported, not edited).
- Produces:

```python
# analysis/report.py
STAGES = ("stats", "paint")
def stage_inputs(cat: Catalog, stage: str, identity: bool) -> dict[str, str]   # file name -> checksum
def analysis_fingerprint(stage: str) -> str
    # package_fingerprint("ltrpav.analysis", *closure) (Task 10 as built); the plot stage adds "ltrpav.plot"
    # (not the engine's checkpoint.stage_fingerprint, which covers engine stages only)
def write_part(outdir: Path, stage: str, rows: list[StatRow], findings: Findings) -> list[Path]
def assemble(outdir: Path) -> tuple[Path, Path]                                # stats.tsv, findings.txt
def run_stats(cat: Catalog, trio: tuple[str, str, str] | None, identity: bool, threads: int) -> list[Path]
def run_paint(cat: Catalog, trio: tuple[str, str, str] | None) -> list[Path]
# analysis/cli.py
def stats_main(argv: list[str] | None = None) -> int     # ltrpav-stats --samples --outdir [--trio R,S,D] [--identity] [--threads N] [-v]
def paint_main(argv: list[str] | None = None) -> int     # ltrpav-paint --samples --outdir [--trio R,S,D] [-v]
def run_analyses(samples_path: Path, outdir: Path, trio: tuple[str, str, str] | None, identity: bool,
                 threads: int) -> None                    # the stats, paint (and, from Task 11, plot) stages in order
```

Rules:

- **Stage inputs** (checksums through `file_checksum`, with the cache in `work/checksums.json`):
  - **stats:** `cat.sheet_sha`, `loci.tsv`, `qc.tsv`, every pair file and element TSV, and the FASTAs with
    `--identity`.
  - **paint:** `cat.sheet_sha`, `loci.tsv`, `qc.tsv`, the element TSVs, every pair file, and `identity.tsv` when
    present.
- **Keys:** `stage_key(stage, inputs, {"trio": ..., "identity": ...}, fingerprint=analysis_fingerprint(stage))`. They hold
  the analysis package's own fingerprint and the checksums of the engine outputs read, never the engine fingerprint.
- **Markers:** `work/analysis/<stage>.done.json`.
  - Each lists exactly the files its stage writes. stats: `inversions.tsv`, `mechanisms.tsv`, `identity.tsv` (with
    `--identity`) and its two part files. paint: the painting files and its two part files.
  - `stats.tsv` and `findings.txt` are assembled outputs that any stage rewrites, so no marker lists them, and a later
    stage never breaks an earlier one's "done, skip".
  - A finished stage logs `<stage>: done, skip` (logger `ltrpav.analysis`).
- **`run_stats` order:**
  1. `run_summary`, `relations`.
  2. `trios`, then `trio_tests` per trio.
  3. `inverted_blocks`, `write_inversions` (`inversions.tsv`), `inversion_rows`.
  4. `direction`.
  5. `mechanisms`, `write_mechanisms` (`mechanisms.tsv`).
  6. `identity`, per trio with D annotated (`identity.tsv`). Without `--identity`, a stale `identity.tsv` is deleted,
     and one findings line says that DESIGN 7.5's counts of shared insertions younger than the split need `--identity`.

  It writes the `stats` part.
- **`run_paint`:**
  - `relations` (for `dist`), `trios` and `inverted_blocks` are recomputed, their rows discarded;
  - `identity.tsv`'s self rows are read as `self_counts` when the file exists;
  - then `paint` per trio, `write_paintings`, and the `paint` part.
- **Parts:** `work/analysis/<stage>.rows.tsv` (`STATS_COLUMNS`) and `<stage>.findings.tsv` (section, line).
- **`assemble`** rewrites both files, each atomically:
  - `stats.tsv`: the header row `STATS_COLUMNS`, then the parts' rows in `STAGES` order. No other header line.
  - `findings.txt`: a first line with the version and the run directory; the lines grouped in `SECTIONS` order, each
    section under its name; a closing "Warnings" section repeating every WARNING line.
- **`analysis/cli.py`:**
  - Builds its parsers with the engine's `_options` and runs them through `_execute` (exit 0 / 1 / 2).
  - Imports scipy, matplotlib, the analysis modules and `ltrpav.plot` inside the stage functions only, so that
    `import ltrpav.analysis.cli` needs neither scipy nor matplotlib.
  - An ImportError of scipy or matplotlib becomes `CliError("analyses need scipy and matplotlib: run ltrpav-stats and
    ltrpav-paint in the ltrpav env")`: one error line, exit 1.
  - It never calls `_check_pair_files` or any other engine-fingerprint check.
  - Fail fast:
    - no `manifest.json` gives CliError "no finished merge in OUTDIR (manifest.json missing): run ltrpav run or
      ltrpav-merge first";
    - `--trio` must name three distinct sheet labels, none an outgroup.
- **The engine hook** (`src/ltrpav/cli.py`, the only engine edit of Plan 2):
  - `ltrpav run` gains `--trio R,S,D` and `--identity`.
  - After `_merge`, `_run` imports `ltrpav.analysis.cli` and calls `run_analyses(args.samples, args.outdir, args.trio,
    args.identity, args.threads)`. The engine's outputs are already complete at that point; an analysis error ends the
    run with one error line, and the outputs are kept.
  - With per-stage engine fingerprints, this edit invalidates no genotyping stage.
- **DESIGN 8:** add to the checkpointing item:
  - resuming `ltrpav run` in an outdir finished by an older engine recomputes every stage whose engine modules changed,
    genotyping included;
  - the analysis commands read a finished run as data, are keyed on their own package's fingerprint, and never check
    engine fingerprints.

- [ ] **Step 1: Write the failing tests**

```python
def _args(run):
    return ["--samples", str(run.sheet), "--outdir", str(run.outdir)]

@needs_lastz                                       # from tests/test_cli.py: `ltrpav run` aligns with LASTZ
def test_run_includes_analyses(tmp_path, caplog):
    w = make_world(tmp_path / "w")                   # tests/test_cli.py: A, B annotated; C genotype-only
    out, argv = tmp_path / "out", ["run", "--samples", str(w.sheet), "--outdir", str(tmp_path / "out")]
    assert main(argv) == 0
    assert all((out / f).is_file() for f in ("stats.tsv", "findings.txt", "inversions.tsv", "mechanisms.tsv"))
    assert "Trio tests" in (out / "findings.txt").read_text().splitlines()
    caplog.clear()
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert main(argv) == 0
    assert "stats: done, skip" in caplog.text and "paint: done, skip" in caplog.text

def test_stats_then_paint(tmp_path, toy_fastas):
    run = simulate_run(tmp_path, seed=1, tracts=TRACTS, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0
    assert {"sharing", "D_pav", "paint"} <= {r.test for r in read_stats(run.outdir / "stats.tsv")}
    assert (run.outdir / "stats.tsv").read_text().splitlines()[0].split("\t") == list(STATS_COLUMNS)
    lines = (run.outdir / "findings.txt").read_text().splitlines()
    assert lines[0].startswith("ltrpav ") and str(run.outdir) in lines[0]
    heads = [l for l in lines if l in SECTIONS]
    assert heads == sorted(heads, key=SECTIONS.index) and (run.outdir / "tracts.R.bed").is_file()

def test_stats_skip_after_paint(tmp_path, toy_fastas, caplog):
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0      # paint re-assembles stats.tsv
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert stats_main(_args(run)) == 0
    assert "stats: done, skip" in caplog.text

def test_rerun_after_sheet_change(tmp_path, toy_fastas, caplog):
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0
    run.sheet.write_text(run.sheet.read_text().replace("\toutgroup", "\t."))
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert stats_main(_args(run)) == 0
    assert "stats: done, skip" not in caplog.text

def test_trio_validation(tmp_path, toy_fastas, capsys):
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    for bad in ("R,R,D", "R,S,X", "R,S,O"):
        assert stats_main([*_args(run), "--trio", bad]) == 1
        err = capsys.readouterr().err
        assert err.strip().splitlines()[-1].startswith("error:") and "Traceback" not in err

def test_missing_merge(tmp_path, toy_fastas, capsys):
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    (run.outdir / "manifest.json").unlink()
    assert stats_main(_args(run)) == 1
    assert "ltrpav-merge" in capsys.readouterr().err.strip().splitlines()[-1]

def test_help_is_short(capsys):
    for fn in (stats_main, paint_main):
        with pytest.raises(SystemExit):
            fn(["--help"])
        assert len(capsys.readouterr().out.splitlines()) < 40

@needs_lastz
def test_cli_imports_without_scipy(tmp_path):
    block = "import sys; sys.modules['scipy'] = None; sys.modules['matplotlib'] = None; "
    for mod in ("ltrpav.cli", "ltrpav.analysis.cli"):
        assert subprocess.run([sys.executable, "-c", block + f"import {mod}"], capture_output=True).returncode == 0
    w, out = make_world(tmp_path / "w"), tmp_path / "out"
    code = block + f"from ltrpav.cli import main; sys.exit(main(['run', '--samples', {str(w.sheet)!r}, " \
                   f"'--outdir', {str(out)!r}]))"
    r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
    lines = r.stderr.strip().splitlines()                      # INFO log lines come first (C4)
    assert r.returncode == 1 and "Traceback" not in r.stderr and (out / "loci.tsv").is_file()
    assert lines[-1] == ("error: analyses need scipy and matplotlib: run ltrpav-stats and ltrpav-paint in the "
                         "ltrpav env") and sum(l.startswith("error:") for l in lines) == 1

def test_stats_shared_seqids(tmp_path, toy_fastas):        # Review Focus 1
    a = simulate_run(tmp_path / "a", seed=1, tracts=TRACTS, fasta_dir=toy_fastas)
    b = simulate_run(tmp_path / "b", seed=1, tracts=TRACTS, prefix=True, fasta_dir=toy_fastas)
    for run in (a, b):
        assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0
    norm = lambda run: [re.sub(r"\b[RSDO]_(chr\d)\b", r"\1", l)
                        for l in (run.outdir / "stats.tsv").read_text().splitlines()]
    assert norm(a) == norm(b)

def test_run_two_genomes(tmp_path, toy_fastas):            # Review Focus 5
    run = write_run(tmp_path, [loc(1000 * i, "R:P* S:E O:E") for i in range(1, 20)],
                    genomes=[GENOMES[0], GENOMES[1], GENOMES[3]], fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0
    assert "Trio tests skipped: fewer than three ingroup genomes" in (run.outdir / "findings.txt").read_text()
    assert (run.outdir / "mechanisms.tsv").is_file()
```

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_cli_analysis.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** `python -m pytest -W error -m "not slow" && ruff check .`. Expected: everything passes.
- [ ] **Step 5: Smoke on real data.**
  - Copy the finished chr10 run `/data2/chris/maize_introgression/benchmark_pav/bakeoff/chr10/runs/flank-mm2_2k/` into
    the scratchpad: `loci.tsv`, `qc.tsv`, `manifest.json`, `pairs/`, `work/elements/`, and the sheet
    `bakeoff/chr10/samples.tsv` with absolute FASTA paths. Never write into `benchmark_pav/bakeoff/`.
  - Check `ls .../bakeoff/chr10/fasta/*.fai`. If any index is missing, copy the FASTAs too and point the sheet at the
    copies.
  - Run `ltrpav-stats` and `ltrpav-paint` there, with `/usr/bin/time -v`.
  - Report the wall time, peak RSS, the roles and D_pav. The data is one chromosome with no outgroup: a smoke test, not a
    result.
- [ ] **Step 6: Commit.** `"Add analysis stages, report assembly, ltrpav-stats and ltrpav-paint"`
---

### Task 11: Overview figure

**Files:**
- Create: `src/ltrpav/plot/overview.py`, `tests/test_overview.py`
- Modify:
  - `src/ltrpav/analysis/cli.py`: `plot_main`, and the plot stage at the end of `run_analyses`. In `ltrpav run`, a
    figure error is a warning, never a lost result (LTRmix). A missing matplotlib is Task 10's CliError, not a warning;
  - `src/ltrpav/analysis/report.py`: `stage_inputs` gains the `plot` stage;
  - `pyproject.toml`: `ltrpav-plot = "ltrpav.analysis.cli:plot_main"`;
  - `docs/DESIGN.md` section 6: one paragraph on the panels and the selection rules.

**Interfaces:**
- Consumes:
  - the run files: `stats.tsv`, `findings.txt`, `posterior.*`, `tracts.*`, `decoy_*`, `inversions.tsv`, `mechanisms.tsv`,
    `loci.tsv`;
  - `load_catalog` (`Catalog.tsd` for the base-pair panel), `seqio.Fasta` (0-based half-open `fetch`),
    `report.stage_inputs`, `report.analysis_fingerprint("plot")`.
- Produces:

```python
NUMBERS_COLUMNS = ("key", "value", "source")   # source "<file>:<test>/<scope>/<stratum>/<statistic>" or "<file>:<column>"
MAX_ROWS = 24          # display limit, not a data threshold: sequences drawn in panel A (LTRmix)
MIN_FRAC = 0.02        # display limit: sequences shorter than 2% of the longest are not drawn (LTRmix)
def overview(outdir: Path, samples: list[Sample], sheet: Path, trio: tuple[str, str, str] | None = None) -> list[Path]
    # [overview.png, overview.pdf, overview_numbers.tsv]
def plot_main(argv: list[str] | None = None) -> int     # in analysis/cli.py: ltrpav-plot --samples --outdir [--trio R,S,D] [-v]
```

The plot stage is checkpointed like the others. Its key uses `analysis_fingerprint("plot")` (the analysis and plot
packages) and the checksums of the run files listed under Consumes. Its marker lists the three overview files.

- [ ] **Step 1: Load the `making-figures` skill** (Skill tool). Read its `SKILL.md`, `figure-spec-template.md` and every
  image in its `examples/` folder. This task is the figure's own phase: give it the whole figure budget (about an hour of
  work, three or more render-inspect rounds).

- [ ] **Step 2: Write the spec block** (every slot of the template) as the first part of `overview.py`'s docstring. The
  panels are suggestions; choose by the skill.
  - **Story** (method first, DESIGN 2): insertions the recipient shares with the donor, at sites where the sister shows an
    empty target site, cluster along the recipient's chromosomes beyond what the sister's mirror pattern shows, and are
    concentrated in young insertions. Lineage sorting would give the same clustering in the sister's mirror and no age
    excess.
  - **Lead trio:** `--trio`, else the trio with the largest D_pav Z. Every trio appears as small multiples when there
    are more than one.
  - **Suggested panels:**
    - A, lead: the recipient's chromosomes to scale (at most `MAX_ROWS` sequences of >= `MIN_FRAC` of the longest),
      with:
      - every informative locus a tick: RD accent on one side, RS blue on the other;
      - the posterior as a thin track;
      - tracts boxed with their q;
      - inverted blocks as background bands;
      - stretches without informative loci hatched.

      The sister's decoy painting is drawn as a full partner at the same bp scale, rows paired by dominant synteny.
      Sequences are keyed as (genome, fai index); names are labels only.
    - B: one typical tract ± a few hundred kb. Every locus is drawn as a box, with rows for R, S, D and the outgroup
      (present filled, empty site open, missing hatched) and the posterior above.
    - C: one RD locus at base-pair scale: R's element ends with its two TSD copies against S's empty site with one TSD
      copy, fetched as `Fasta.fetch(seqid, start - 1, end)` from the 1-based catalog coordinates.
    - D: D_pav by age bin, points with 95% intervals, the lineage-sorting line D = 0 drawn, n shown.
    - E: the three sharing counts with the lineage-sorting expectation drawn: equal minority counts.
    - F: fates of absences by age: E; D and O inside the element (shown); D and O inside but unshown; D beyond it; O at
      the site; complex O (Task 8's classes as built).
    - G: every trio's D_pav as small multiples.
  - **Example rules** (typical, never the most dramatic):
    - the tract is the q <= 0.05 tract (else any tract) nearest the medians of n_loci and length;
    - the locus is an RD locus in that tract with D tier `annot` or `high`, S's E carrying `tsd_match`, and R's TSD known
      (`Catalog.tsd`), nearest the median K of all RD loci;
    - before drawing, check from the FASTA that R's two TSD copies are identical and that S's single copy matches.
  - **Fallbacks**, each also a numbers row:
    - no trio: a composition panel per genome, and numbers row `no_trio` with value `fewer than three ingroup genomes`;
    - no tract: the posterior only, "no tract called";
    - no FASTA: panel C omitted, with a legend note.

- [ ] **Step 3: Sketch 2-3 layouts** (ASCII), choose one and say why. Report them in the task handback; they are not a
  file.

- [ ] **Step 4: Write the failing tests**

```python
def _analyzed(path, toy_fastas, **kw):
    run = simulate_run(path, seed=1, fasta_dir=toy_fastas, **kw)
    args = ["--samples", str(run.sheet), "--outdir", str(run.outdir)]
    assert stats_main(args) == 0 and paint_main(args) == 0
    return run

def _numbers(path):
    return {r["key"]: r for r in read_tsv(path)}

def test_overview_files(tmp_path, toy_fastas):
    run = _analyzed(tmp_path, toy_fastas, tracts=TRACTS, inversion=("S", "chr2", 300_001, 700_000))
    png, pdf, nums = overview(run.outdir, run.samples, run.sheet)
    assert min(PIL.Image.open(png).info["dpi"]) >= 299.5                      # Pillow reports 299.9994 for 300
    assert len(re.findall(rb"/Type\s*/Page[^s]", pdf.read_bytes())) == 3
    rows = read_tsv(nums)
    assert list(rows[0]) == list(NUMBERS_COLUMNS) and len(rows) >= 10
    assert all((run.outdir / r["source"].split(":")[0]).is_file() for r in rows)
    assert "D_pav" in _numbers(nums)

@pytest.mark.skipif(shutil.which("pdftotext") is None, reason="poppler missing")
def test_overview_legend_text(tmp_path, toy_fastas):
    run = _analyzed(tmp_path, toy_fastas, tracts=TRACTS)
    _, pdf, nums = overview(run.outdir, run.samples, run.sheet)
    text = subprocess.run(["pdftotext", "-f", "2", "-l", "3", str(pdf), "-"], capture_output=True, text=True,
                          check=True).stdout
    assert _numbers(nums)["D_pav"]["value"] in text and "Analysis:" in text

def test_overview_two_genomes(tmp_path, toy_fastas):       # Review Focus 5
    run = write_run(tmp_path, [loc(1000 * i, "R:P* S:E O:E") for i in range(1, 20)],
                    genomes=[GENOMES[0], GENOMES[1], GENOMES[3]], fasta_dir=toy_fastas)
    args = ["--samples", str(run.sheet), "--outdir", str(run.outdir)]
    assert stats_main(args) == 0 and paint_main(args) == 0
    png, pdf, nums = overview(run.outdir, run.samples, run.sheet)
    assert png.is_file() and _numbers(nums)["no_trio"]["value"] == "fewer than three ingroup genomes"

def test_overview_many_scaffolds(tmp_path, toy_fastas):    # Review Focus 4
    seqids = ("chr1",) + tuple(f"scaf{i:03d}" for i in range(300))
    loci = ([loc(1000 * i, "R:P* S:E D:P O:E") for i in range(1, 60)]
            + [loc(70_000 + 1000 * i, "R:P* S:P D:E O:E") for i in range(60)]
            + [loc(1001, "R:P* S:E D:P O:E", seqid=f"scaf{i:03d}") for i in range(300)])
    run = write_run(tmp_path, loci, seqids=seqids, seq_len=5_000, seq_lens={"chr1": 200_000}, fasta_dir=toy_fastas)
    args = ["--samples", str(run.sheet), "--outdir", str(run.outdir)]
    assert stats_main(args) == 0 and paint_main(args) == 0
    num = _numbers(overview(run.outdir, run.samples, run.sheet)[2])
    assert int(num["sequences_drawn"]["value"]) <= MAX_ROWS and int(num["sequences_not_drawn"]["value"]) >= 277

def test_overview_deterministic(tmp_path, toy_fastas):
    run = _analyzed(tmp_path, toy_fastas, tracts=TRACTS)
    first = overview(run.outdir, run.samples, run.sheet)[2].read_text()
    assert overview(run.outdir, run.samples, run.sheet)[2].read_text() == first

def test_plot_help_is_short(capsys):
    with pytest.raises(SystemExit):
        plot_main(["--help"])
    assert len(capsys.readouterr().out.splitlines()) < 40
```

- [ ] **Step 5: Run** `python -m pytest -W error tests/test_overview.py`. Expected: FAIL.

- [ ] **Step 6: Implement.**
  - **Style:**
    - matplotlib; Liberation Sans (system) or Arial, falling back to DejaVu Sans with a warning;
    - `pdf.fonttype 42`; 180 mm wide; no titles; bold panel letters on one grid;
    - colorblind-safe colors, with context in gray.
  - **Outputs:**
    - `PdfPages`: page 1 the figure, page 2 the short legend, page 3 the long legend. Legend text is built from
      `stats.tsv` in the code.
    - The long legend ends `Analysis: <host>:<outdir> · Script: ltrpav.plot.overview · <date>`.
    - The PNG is the figure only, saved at 300 dpi.
    - Every number quoted in a legend gets a row in `overview_numbers.tsv`, among them `D_pav`, `sequences_drawn`,
      `sequences_not_drawn` and the fallback rows.

- [ ] **Step 7: Run** `python -m pytest -W error -m "not slow" && ruff check .`. Expected: PASS.

- [ ] **Step 8: Render and iterate.**
  - Render on a toy run, then on the chr10 scratch copy from Task 10 Step 5.
  - Inspect full-resolution PNG crops and the legend pages (`pdftoppm -r 150`). Fix clipping, collisions and lines too
    thin to read.
  - Repeat at least three rounds.
  - Answer the skill's 7-line figure check in the handback. The final check on real data comes in Task 12, by a reviewer
    who did not make the figure.

- [ ] **Step 9: Commit.** `"Add the overview figure and ltrpav-plot"`
---

### Task 12: Preliminary run on B73, TIL18, TIL01 + Zd and comparison with the papers

**Files** (outside the repo): `benchmark_pav/main3/{run_analyses.sh, analyses.log, analyses.done, compare_papers.py,
prelim_papers.tsv, PRELIM.md}`, `benchmark_pav/dead_ends.md`, `/data2/chris/maize_introgression/memo_ltrpav.md`.
**Repo:** `docs/DESIGN.md` (section 12: Plan 2 outcome, 3-5 lines).

The genomes, by their main3 sheet labels (the labels used everywhere in this task; `B73v5` is only the LTRmix/LTRquest
element-name and FASTA prefix):
- B73, maize;
- TIL18, *Z. mays* ssp. *mexicana*;
- TIL01, ssp. *parviglumis*;
- Zd, the *Z. diploperennis* outgroup: genotype-only, with no annotation.

This follows DESIGN and Plan 1's sheet. Roles are inferred, never set, and checking them against the sheet's groups is the
first result. Every verdict here is **preliminary**: DESIGN 10.3's bars, the simulated null of D_pav and the controls
belong to Plan 3. Verdicts read "PASS (prelim)" or "MISS (prelim)".

main3 was genotyped by engine 7d71073. The analysis commands read it as data and run no engine-fingerprint check, so
nothing is re-genotyped. Do not run `ltrpav run` or `ltrpav-merge` there.

- [ ] **Step 1: Preconditions.**
  - `main3/manifest.json` exists.
  - `main3/samples.tsv` has labels B73, TIL18, TIL01 and Zd, with groups `maize`, `mexicana` (TIL18), `parviglumis`
    (TIL01) and `diploperennis` (Zd, role `outgroup`).
  - `pgrep -af ltrpav` shows no job.
  - `python -m pytest -W error -m "not slow"` passes on `plan2-analyses`.

- [ ] **Step 2: Launch detached.** Identity alignments may pass 15 min.
  - `run_analyses.sh` (`set -euo pipefail`, `export NUMPY_MADVISE_HUGEPAGE=0`) runs, in order:
    `ltrpav-stats --samples samples.tsv --outdir . --identity --threads 32`, then `ltrpav-paint --samples samples.tsv
    --outdir .`, then `ltrpav-plot --samples samples.tsv --outdir .`, then `touch analyses.done`.
  - Launch from `main3/`: `setsid -f nohup mamba run -n ltrpav bash run_analyses.sh > analyses.log 2>&1 < /dev/null`.
  - Verify with `pgrep -af run_analyses.sh`, which lists the `mamba run` leader and its bash child. Check the leader with
    `ps -o pid,ppid,sid,cmd -p <pid>`. Expected: SID = PID and PPID 1. The child shares the SID, with the leader as
    PPID.

- [ ] **Step 3: Check outputs.**
  - `analyses.done` exists.
  - `findings.txt`'s Run, Relationships and Trio tests sections.
  - `stats.tsv` holds the rows the comparison reads.

- [ ] **Step 4: Write `compare_papers.py`.**
  - Constraints:
    - numpy, scipy and csv only (no new environment), plus `ltrpav.analysis` (`load_catalog`, `discover`) for per-locus
      recounts;
    - `NUMPY_MADVISE_HUGEPAGE=0`;
    - reads the run's files and the truth files in `/data2/chris/maize_introgression/benchmark/truth/`
      (`elai_summary.v5.tsv` column `B73.amp`, -999 = missing, dosage 0-2; `hf.v5.bed`; `loci.v5.tsv`);
    - B73's seqids map to ELAI chromosomes by their trailing `chr<N>`;
    - modeled on LTRmix `eval_real.py`.
  - **One scoring code for both tools.** LTRmix's files from
    `/data2/chris/maize_introgression/LTRmix/benchmark/results/main3/` go through the same window, AUROC, tract-recall,
    named-locus and high-frequency functions as LTRpav's, with the same weights, 1000 shifts and seeds:
    - `elements.B73v5.tsv.gz`: class, `post_ancestry_TIL18`, span;
    - `tracts.B73v5.bed` (recent mode) and `ancestry.B73v5.bed` (ancestry mode).

    LTRmix's `benchmark_real.tsv` is a cross-check only. Every row names LTRmix's HMM mode: ancestry for posteriors,
    windows and AUROC; both modes for tracts. Every window, chromosome and high-frequency mean is computed both
    unweighted and length-weighted, for both tools.
  - It writes `prelim_papers.tsv` with columns `section item ltrpav ltrmix bar verdict note`, one row per item:
    1. **Roles:** sister pair, donor and recipient against the sheet's groups. Expected: sisters B73 + TIL01
       (*parviglumis*), donor TIL18 (*mexicana*), recipient B73.
    2. **Admixture in B73** (Yang): D_pav `all`, bar D > 0 and Z > 3. Beside it:
       - the checks `high_tier`, `nested_collapsed` and `no_outgroup_filter`;
       - LTRmix `D_ins` (+0.1949, Z 7.2), placed beside the `no_outgroup_filter` stratum since LTRmix uses no
         outgroup. A note says that LTRmix's `D_ins` needs the sisters' own annotation (ABBA on R's elements, BABA on
         S's), so it is not blind to the 1.08 completeness ratio.
    3. **Gene flow, not lineage sorting** (Yang): D_pav by age bin and `dD` with its Z, reported against "excess
       concentrated in young insertions".
       - For the side-by-side, LTRpav's counts are re-binned into LTRmix's right-closed bins (K = 0, 0 < K <= 0.01,
         K > 0.01). A K = 0.01 locus cannot be moved out of LTRmix's middle bin, so the comparison goes that way.
       - `compare_papers.py` recounts LTRpav's D_pav rows per locus (`load_catalog`, `discover(..., "E")`, the K of each
         row's discovering copy) into those bins.
       - LTRmix's own counts per bin, from its `stats.tsv` `D_ins_by_age` rows (`nA`, `nB`), summed over its finer bins:

       | bin | LTRmix D | counts |
       |---|---|---|
       | K = 0 | +0.506 | 122 vs 40 |
       | 0 < K <= 0.01 | +0.404 | 2,001 vs 850 |
       | K > 0.01 | +0.153 | 8,795 vs 6,467 |
       | gradient | dD +0.354 | — |

    4. **Amount:** painting `posterior_mean` (unweighted and length-weighted), `decoy_posterior_mean` and `excess`,
       reported beside the B73 ELAI mean dosage/2 (0.1695) and Yang's 15-25%. Not an estimate (no second donor in
       main3).
    5. **Chromosomes 5, 8, 9 depleted** (Yang): over B73 seqids ending `chr1`..`chr10` only (`paint_seqid` also holds
       scaffolds), the three lowest by `posterior_mean` and by `class_share`, against {chr5, chr8, chr9}. An exact match
       has p = 1/120. Also the Spearman correlation with per-chromosome ELAI means.
    6. **Ancestry along the genome** (Yang): windows of 0.1, 0.5, 1, 2, 5 and 10 Mb.
       - Window means of the B73 posterior (rows with donor TIL18), and of the class share, against window ELAI means
         (>= 5 SNPs).
       - Spearman r; p from 1000 per-chromosome circular shifts (seed 1).
       - Bar: p < 0.01 at >= 1 Mb.
    7. **Tract scale** (Yang: 80% of tracts < 9.1 kb):
       - element AUROC of the posterior: ELAI dosage within ±20 kb (>= 3 SNPs), >= 1.0 and >= 1.5 against <= 0.2;
       - tract recall by ELAI-run length (dosage > 1: < 10 kb, 10-100 kb, 100-500 kb, >= 500 kb), for all tracts and
         q <= 0.05;
       - the ELAI dosage inside called tracts against the whole genome;
       - the resolution: `spacing_median`, `spacing_mean`, both shortest-callable bounds (LTRmix: 25 kb median
         spacing);
       - like with like: LTRpav's `mean_tract_bp` (its L, the switch scale) beside LTRmix's `mean_tract_bp` (197 kb,
         its L under the same name). LTRpav's `mean_donor_run_bp` (L/(1 - pi)) is reported on its own line.
    8. **Named loci** (`loci.v5.tsv`, ±50 kb and ±200 kb): classes, max posterior, tracts and q. Hit or miss against
       the expectations: ZmPRR37a *mexicana*; HPC1 not; ZmLPCAT1 not called; cob-weight locus intermediate.
    9. **52 high-frequency regions** (Yang): mean posterior of loci within 50 kb against outside; 1000 circular shifts of
       the regions per chromosome (seed 2); bar p < 0.01.
    10. **Inversions:**
        - Inv4m (B73 chr4:172,883,881-188,131,462, v5) in B73~TIL18;
        - Inv1n (chr1 ~65-115 Mb, approximate v2 coordinates as in LTRmix) in B73~TIL01;
        - the blocks found, with their `n_discordant` and the distances of their breakpoint intervals to the published
          ends.
    11. **Outgroup error-rate upper bound**, per ingroup genome. `compare_papers.py` computes it from the catalog itself
        (ingroup E at loci Zd carries, counted from the discoverers' own calls as Task 3 does, decision 18) and checks that it equals `stats.tsv`'s
        `outgroup_conflict`. It does not quote `QC.md`.
    12. **Mechanisms:** `frac_E`, `frac_D_inside`, `frac_O_inside`, `frac_D_inside_unshown`, `frac_O_inside_unshown`,
        `frac_D_beyond`, `frac_O_site` and `frac_O_complex` by age (Task 8 as built: an inside gap end is shown derived only
        when its remnant is shorter than MIN_SEG and holds no annotated child), with the bounds:
        - absences not shown ancestral, 1 - frac_E, an upper bound on derived absences;
        - shown derived, frac_D_inside + frac_O_inside, a lower bound (main3 B73->TIL18: 0.0129; K>=0.01: 0.0155).

        The literature reports absences of old elements as mostly deletions. Also the multi-element split (nested
        clusters against deletions; Munasinghe's 85.9% lead).
    13. **Identity layer:**
        - `s` (isolation fit, >= 200 sites) against LTRmix's isolation fit, 0.048% (block bootstrap 0.034-0.063%);
        - `s_mix` against LTRmix's mixture fit, 0.070%;
        - the younger-than-split counts and `sites_needed`;
        - `frac_RD_below` and `frac_SD_below` (LTRmix: 7.6% against 3.5%).
    14. **Direction:** skipped (one genome per taxon); say so.

  Rows with a DESIGN 10.3 bar get "PASS (prelim)" or "MISS (prelim)"; the others `reported`.

- [ ] **Step 5: Run** `export NUMPY_MADVISE_HUGEPAGE=0 && mamba run -n ltrpav python compare_papers.py`. Expected:
  `prelim_papers.tsv` with the 14 sections.

- [ ] **Step 6: Write `PRELIM.md`.**
  1. Open with the direct answer to the user's question: could LTR-RT PAVs have discovered the *mexicana* introgression
     into maize described by Yang et al. 2023 and Barnes et al. 2022? Answer genome-wide, then for gene flow against
     lineage sorting, then locally (with the resolution), in 3-5 lines.
  2. The table.
  3. What LTRpav adds over LTRmix: resolution, outgroup polarization, mechanisms.
  4. Caveats:
     - preliminary: no simulated null yet;
     - one genome per taxon;
     - B73 is a CLR assembly against PanAnd HiFi.
  5. The figure check: a reviewer who did not make the figure answers the seven lines from `overview.png` and the legend
     pages.
  6. End with, labeled "hypothesis: one trio, no simulated null" (CLAUDE.md):
     - the headline sentence about what genome-verified PAVs add over library-only inference;
     - the mechanism;
     - generality, tested or assumed;
     - predictions for other species.

  Each MISS gets a one-line entry in `benchmark_pav/dead_ends.md` plus an investigation note. A rule changes only for a
  reason independent of the papers, and is then rechecked.

- [ ] **Step 7: Memo and record.**
  - Append a Plan 2 section to `memo_ltrpav.md` (CLAUDE.md format): date, purpose, env versions, inputs, exact commands,
    outputs, gotchas, and the `claude --resume` name.
  - Add the outcome to DESIGN.md section 12.
  - Run `python -m pytest -W error -m "not slow"`.
  - Commit: `"Record Plan 2 analyses outcome"`.

- [ ] **Step 8: Hand off.** Report to the user:
  - the direct answer;
  - `prelim_papers.tsv`'s verdicts;
  - the figure path;
  - the misses;
  - what Plan 3 must settle:
    - the simulated null and power of D_pav and painting;
    - direction: Plan 3's simulations must include unequal Ne between taxa (the maize bottleneck), in both the null and
      the gene-flow runs;
    - the painting discovery variant;
    - the six-genome controls;
  - the user's confirmation of builder call 11 (the fallback-discovery ruling).

---

## Spec coverage

| DESIGN | Task |
|---|---|
| 7.1 discovery rules (discoverer's own calls), fallback (four-point), skip; outgroup E | 1 (`proj`, `pcls`), 3 (`discover`), 4; 6 (painting rule) |
| 7.1 resolution symmetry, annotation sensitivity | 2 (`resolution`); 4, 6, 7 (rows, WARNING); 3 (`run_summary` quotes qc.tsv) |
| 7.1 painting variant "any discovery" | 6 (`discovery="any"`; evaluated in Plan 3) |
| 7.2 sharing, shared-derived counts, distances, NJ tree, sister pair, outgroup set-aside, error bound | 3; roles in 4 |
| 7.3 D_pav with 5-Mb / 1/100 block jackknife; age split; nested collapse; f4-ratio | 2, 4 |
| 7.4 RD/RS HMM, EM, fitted tract length, posterior, tract rule, target-decoy q, spacing, shortest tract | 6 |
| 7.5 age gradient; youngest insertion per tract; identity layer, rate-free split, younger-than-split counts | 4, 6, 9 |
| 7.6 n(X->Y), age strata, jackknife, DFOIL-style, KKSC/4-LIST, exploratory | 7 (KKSC symmetry in 3) |
| 7.7 inverted blocks, breakpoint intervals, locus counts; painting loci flagged | 5, 6 |
| 7.8 counts by pair/family/age; O and D split by junctions; Dollo placement; multi-element split | 8 |
| 6 outputs: stats.tsv, findings.txt, tracts, posterior, inversions, mechanisms, overview + numbers | 2, 5, 6, 8, 10, 11 |
| 8 commands ltrpav-stats, -paint, -plot; run = everything; checkpoints (own fingerprint); warn-and-skip counts in findings | 3, 10, 11 |
| 10.1 outgroup impossible patterns as an error bound | 3, 12 |
| 11 item 3; brief's final real-data task | 12 |
