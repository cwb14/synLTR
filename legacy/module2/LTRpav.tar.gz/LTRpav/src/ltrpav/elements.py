"""Normalized LTR-RT annotation record (1-based inclusive, like GFF3) and its TSV form."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, fields
from pathlib import Path


@dataclass(frozen=True, slots=True)
class Element:
    genome: str
    eid: str
    name: str
    seqid: str
    start: int
    end: int
    strand: str  # '+', '-' or '.'
    ltr_left: tuple[int, int]  # genome orientation, 1-based inclusive
    ltr_right: tuple[int, int]
    tsd: str | None
    k: float | None
    family: str | None
    superfamily: str | None
    clade: str | None
    confidence: str | None
    parent: str | None = None  # filled by assign_nesting; None = top-level
    level: int = 0


ELEMENT_COLUMNS: tuple[str, ...] = tuple(f.name for f in fields(Element))
_TUPLES = {"ltr_left", "ltr_right"}
_INTS = {"start", "end", "level"}


def make_eid(genome: str, seqid: str, start: int, end: int) -> str:
    return f"{genome}|{seqid}:{start}-{end}"


def elements_digest(elements: list[Element] | None) -> str:
    """sha256 of the element records (every field, in order); "none" without an annotation."""
    if elements is None:
        return "none"
    h = hashlib.sha256()
    for e in elements:
        h.update(repr(e).encode())
        h.update(b"\n")
    return h.hexdigest()


def _fmt(name: str, v) -> str:
    if v is None:
        return "."
    if name in _TUPLES:
        return f"{v[0]}-{v[1]}"
    if isinstance(v, float):
        return repr(v)
    return str(v)


def _parse(name: str, s: str):
    if name in _TUPLES:
        a, b = s.split("-")
        return (int(a), int(b))
    if name in _INTS:
        return int(s)
    if s == "." and name != "strand":
        return None
    if name == "k":
        return float(s)
    return s


def write_elements(elements: list[Element], path: Path) -> None:
    with open(path, "w") as fh:
        fh.write("\t".join(ELEMENT_COLUMNS) + "\n")
        fh.writelines("\t".join(_fmt(c, getattr(e, c)) for c in ELEMENT_COLUMNS) + "\n" for e in elements)


def read_elements(path: Path) -> list[Element]:
    out = []
    with open(path) as fh:
        header = fh.readline().rstrip("\n").split("\t")
        if tuple(header) != ELEMENT_COLUMNS:
            raise ValueError(f"{path}: unexpected header {header}")
        for line in fh:
            if not line.strip():
                continue
            vals = line.rstrip("\n").split("\t")
            out.append(Element(**{c: _parse(c, v) for c, v in zip(ELEMENT_COLUMNS, vals)}))
    return out
