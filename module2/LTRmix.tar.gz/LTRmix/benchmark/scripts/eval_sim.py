#!/usr/bin/env python3
"""Score one ltrmix run on a simulated trio against the simulation truth (B's segments of M ancestry).
Prints one JSON line: true f, each D (D, Z), fraction estimates, element-level AUC, tract precision/recall (bp),
recall by true tract length class and false-discovery rate of tracts at q <= 0.05."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import argparse
import json
import os

import numpy as np
import pandas as pd


def auc(score, label):
    from scipy.stats import rankdata
    label = np.asarray(label, bool)
    n1, n0 = label.sum(), (~label).sum()
    if n1 == 0 or n0 == 0:
        return float("nan")
    r = rankdata(score)
    return float((r[label].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def overlap_bp(a, b):
    """Total overlap of interval lists a and b (same chromosome), both sorted, non-overlapping within."""
    i = j = 0
    s = 0
    while i < len(a) and j < len(b):
        lo, hi = max(a[i][0], b[j][0]), min(a[i][1], b[j][1])
        if hi > lo:
            s += hi - lo
        if a[i][1] < b[j][1]:
            i += 1
        else:
            j += 1
    return s


def merge(iv):
    iv = sorted(iv)
    out = []
    for s, e in iv:
        if out and s <= out[-1][1]:
            out[-1][1] = max(out[-1][1], e)
        else:
            out.append([s, e])
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("sim")
    ap.add_argument("out")
    a = ap.parse_args()
    P = json.load(open(os.path.join(a.sim, "params.json")))
    st = pd.read_csv(os.path.join(a.out, "stats.tsv"), sep="\t")
    fnd = open(os.path.join(a.out, "findings.txt")).read()
    res = dict(sim=os.path.basename(a.sim.rstrip("/")), f=P["f"], Ta=P["Ta"], fn=P["fn"], seed=P["seed"],
               true_frac=P["true_frac_B"], sisters_ok="Sister pair (most single-copy k-mers shared): B + P" in fnd
               or "Sister pair (most single-copy k-mers shared): P + B" in fnd)
    for test in ("D_kmer", "D_ins", "D3_triples", "D_self_outgroup"):
        r = st[st.test == test]
        if len(r):
            r = r.iloc[0]
            res[test] = float(r["D"])
            res[test + "_Z"] = float(r["Z"])
    # D_ins by insertion age (donor copy K2P), pooled into young (K2P <= 0.005) and old (> 0.02) classes
    ag = st[st.test == "D_ins_by_age"]
    if len(ag):
        young = ag[ag.stratum.isin(["K2P 0", "K2P (0,0.002]", "K2P (0.002,0.005]"])]
        old_ = ag[ag.stratum.isin(["K2P (0.02,0.05]", "K2P (0.05,0.1]", "K2P >0.1"])]
        for nm, g in (("young", young), ("old", old_)):
            a_, b_ = g.nA.astype(float).sum(), g.nB.astype(float).sum()
            res[f"Dins_{nm}"] = (a_ - b_) / (a_ + b_) if a_ + b_ else float("nan")
            res[f"Dins_{nm}_n"] = a_ + b_
    # orientation: positive D means the first-named sister shares more with the donor; the tool names R = recipient
    res["recipient_called"] = fnd.split("D(single-copy k-mers; ")[1].split(",")[0] if "D(single-copy" in fnd else ""
    r = st[st.test == "f_lower_bound"]
    res["f_low"] = float(r.iloc[0]["f"]) if len(r) else float("nan")
    for mode in ("ancestry", "recent"):
        h = st[(st.test == f"hmm_{mode}") & (st.stratum == "B")]
        if len(h):
            h = h.iloc[0]
            res.update({f"{mode}_pi": float(h["pi"]), f"{mode}_excess": float(h["excess_over_decoy"]),
                        f"{mode}_L": float(h["mean_tract_bp"]), f"{mode}_n_tracts": int(h["n_tracts"]),
                        f"{mode}_n_q05": int(h["n_tracts_q05"])})
    # truth
    tr = pd.read_csv(os.path.join(a.sim, "truth_B.bed"), sep="\t", header=None, names=["chrom", "s", "e"])
    T = {c: merge(list(zip(g.s, g.e))) for c, g in tr.groupby("chrom")}
    el_path = os.path.join(a.out, "elements.B.tsv")
    if os.path.exists(el_path):
        e = pd.read_csv(el_path, sep="\t")
        mid = (e.start + e.end) // 2
        lab = np.zeros(len(e), bool)
        for c, iv in T.items():
            m = (e.chrom == c).values
            if not m.any():
                continue
            arr = np.array(iv)
            idx = np.searchsorted(arr[:, 0], mid[m].values, side="right") - 1
            ok = (idx >= 0) & (mid[m].values < arr[np.clip(idx, 0, None), 1])
            lab[np.where(m)[0][ok]] = True
        res["elem_frac_true"] = float(lab.mean())
        for mode in ("ancestry", "recent"):
            col = f"post_{mode}_M"
            res[f"auc_{mode}"] = auc(e[col].values, lab) if col in e else float("nan")
    for mode, fn in (("recent", "tracts.B.bed"), ("ancestry", "ancestry.B.bed")):
        bed = os.path.join(a.out, fn)
        if not os.path.exists(bed):
            continue
        b = pd.read_csv(bed, sep="\t")
        b.columns = [c.lstrip("#") for c in b.columns]
        for qmax, tag in ((1.01, "all"), (0.05, "q05"), (-1, "p01")):
            bb = b[b.q <= qmax] if qmax >= 0 else b[b.p_decoy <= 0.01]
            called = {c: merge(list(zip(g.start0, g.end))) for c, g in bb.groupby("chrom")}
            tp = sum(overlap_bp(called.get(c, []), T.get(c, [])) for c in set(called) | set(T))
            cl = sum(e - s for iv in called.values() for s, e in iv)
            tt = sum(e - s for iv in T.values() for s, e in iv)
            res[f"{mode}_bp_precision_{tag}"] = tp / cl if cl else float("nan")
            res[f"{mode}_bp_recall_{tag}"] = tp / tt if tt else float("nan")
            nf = 0
            for c, iv in called.items():
                for s, e in iv:
                    if overlap_bp([[s, e]], T.get(c, [])) == 0:
                        nf += 1
            ncall = sum(len(v) for v in called.values())
            res[f"{mode}_tract_fdr_{tag}"] = nf / ncall if ncall else float("nan")
            res[f"{mode}_n_called_{tag}"] = ncall
            for lo, hi, nm in ((0, 5e4, "lt50k"), (5e4, 2e5, "50-200k"), (2e5, 1e6, "200k-1M"), (1e6, 1e12, "ge1M")):
                tot = got = 0
                for c, iv in T.items():
                    for s, e in iv:
                        if lo <= e - s < hi:
                            tot += 1
                            if overlap_bp([[s, e]], called.get(c, [])) > 0:
                                got += 1
                res[f"{mode}_recall_{nm}_{tag}"] = got / tot if tot else float("nan")
                res[f"n_true_{nm}"] = tot
    print(json.dumps(res))


if __name__ == "__main__":
    main()
