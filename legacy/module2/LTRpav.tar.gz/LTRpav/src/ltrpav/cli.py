"""Command line: `ltrpav run` runs every stage; ltrpav-anchor, ltrpav-genotype and ltrpav-merge run one.

Stages, each checkpointed (a rerun skips what is done and resumes what is not):
  elements  each annotated genome's annotation, loaded and normalized: <outdir>/work/elements/<label>.tsv
            (+ <label>.skipped.json, the loader's skip counts), keyed by the FASTA and annotation checksums
  anchor    each ordered pair (annotated A, any other B; sheet order): anchor_pair's netted blocks
  genotype  each ordered pair: genotype_pair's <outdir>/pairs/<A>__<B>.calls.tsv.gz (it anchors first)
  merge     build_loci over every pair file, then the outputs in <outdir>: loci.tsv, pav_matrix.tsv, qc.tsv,
            pav.vcf.gz (+ .tbi, pav.unplaced.tsv) on --vcf-ref's coordinates, <label>.pav.gff3 and .bed per
            genome, and manifest.json, written last (present only after a finished merge)
  analyses  `ltrpav run` only, after the merge: the analysis stages and the overview figure
            (ltrpav.analysis.cli.run_analyses; alone: ltrpav-stats, ltrpav-paint, ltrpav-plot), with --trio and
            --identity. --trio is checked before any genotyping.
            The genotyping outputs are complete by then and are kept whatever follows: a stats or paint
            failure logs one ERROR and exits 3; a plot-stage error (the figure) is a warning only (exit 0).
Every FASTA's .fai index is written next to the FASTA when its folder is writable, else to <outdir>/work/fai,
so a FASTA in a read-only folder works in place.
Exit status: 0 done; 1 a handled error, one line "error: <message>" on stderr (the traceback too with -v), a
Python module that cannot be imported included (its name and the install route are in the line);
2 a usage error (argparse); 3 `ltrpav run` only: the genotyping outputs are complete but the analyses failed
(one ERROR, then one line "error: analyses failed: <message>").
"""
from __future__ import annotations

import argparse
import logging
import shutil
import sys
import time
import traceback
from collections import Counter
from collections.abc import Callable
from contextlib import ExitStack
from datetime import datetime, timezone
from functools import partial
from pathlib import Path

from . import __version__, checkpoint
from .anchor import PairContext, Route, anchor_pair, get_route
from .annotation import annotation_files, elements_stage
from .checkpoint import (
    CHECKSUM_CACHE,
    done_meta,
    file_checksum,
    marker,
)
from .constants import DEFAULT_BACKEND, DEFAULT_ROUTE, RESOLVED_WARN
from .elements import Element, elements_digest
from .genotype import genotype_pair
from .loci import build_loci
from .outputs.manifest import write_manifest
from .outputs.tables import write_loci_tsv, write_pav_matrix, write_qc
from .outputs.tracks import write_tracks
from .outputs.vcf import write_vcf
from .samples import PAIR_SEP, Sample, read_samples
from .seqio import Fasta

log = logging.getLogger("ltrpav")

BACKEND = DEFAULT_BACKEND  # the window aligner (align_window's backend); fixed, no option
_BINARIES = {"fastga": ("FastGA",), "flank-blast": ("blastn", "makeblastdb")}  # executables a route runs
_BACKEND_BINARIES = {"lastz": ("lastz",)}  # executables a window aligner runs
_HANDLED = (ValueError, RuntimeError, OSError)  # bad input (sheet, annotation, files), failed tools and workers
_STAGES = ("Single stages: ltrpav-anchor, ltrpav-genotype, ltrpav-merge (each takes --samples and --outdir, "
           "as `run` does; anchor and genotype also take --threads, --anchor and --pair, merge --vcf-ref); "
           "the analyses alone: ltrpav-stats, ltrpav-paint, ltrpav-plot (see their --help).")
_ANCHOR_HELP = (f"how each pair is anchored (default: {DEFAULT_ROUTE}); "
                "genotyping also needs lastz, whatever the route. "
                "flank-mm2 and mm2: minimap2 through mappy (the minimap2 program is optional); "
                "fastga: FastGA; flank-blast: blastn and makeblastdb; hybrid: FastGA if on PATH, else "
                "minimap2; paf:<dir>: your own alignments, <dir>/<A>__<B>.paf[.gz]")
_CONDA = "the conda environment in environment.yml"
_INSTALL = f"{_CONDA} (mamba env create -f environment.yml), or pip install -e . from the repository"


class CliError(ValueError):
    """A problem found once the sheet is read: an unknown label, a missing binary or pair file."""


class AnalysesFailed(RuntimeError):
    """`ltrpav run`'s analyses failed after complete genotyping outputs: exit status 3."""


# ---------------------------------------------------------------- commands


def main(argv: list[str] | None = None) -> int:
    """`ltrpav run`: every stage."""
    parser = argparse.ArgumentParser(
        prog="ltrpav", epilog=_STAGES,
        description="Genotype LTR-retrotransposon presence/absence across genome assemblies, then run the "
                    "gene-flow analyses (D_pav, trio tests, painting of introgressed tracts, inversions, "
                    "mechanisms) on the result.")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True, metavar="COMMAND")
    run = _options(sub.add_parser(
        "run", help="every stage: elements, anchors, pair calls, loci, outputs and analyses",
        description="Genotype every annotated element of each genome in every other genome, merge the calls "
                    "into loci and write the outputs (loci.tsv, pav_matrix.tsv, qc.tsv, pav.vcf.gz, tracks, "
                    "manifest.json), then the analyses (stats.tsv, findings.txt, painting, inversions, "
                    "mechanisms) and the overview figure (overview.png, overview.pdf). Finished stages are "
                    "skipped on a rerun.", epilog=_STAGES),
        route=True, vcf_ref=True, version=False)
    from .analysis.cli import add_options  # the analyses' options; it imports nothing heavy
    add_options(run, identity=True)
    return _execute(parser, argv, "ltrpav", _run)


def anchor_main(argv: list[str] | None = None) -> int:
    """`ltrpav-anchor`: anchor each ordered pair (or --pair)."""
    parser = _options(argparse.ArgumentParser(
        prog="ltrpav-anchor", description="Anchor each ordered genome pair (annotated A, any other B): the "
                                          "netted alignment blocks under OUTDIR/work/anchors."),
        route=True, pair=True)
    return _execute(parser, argv, "ltrpav-anchor", _anchor)


def genotype_main(argv: list[str] | None = None) -> int:
    """`ltrpav-genotype`: genotype each ordered pair (or --pair), anchoring it first if needed."""
    parser = _options(argparse.ArgumentParser(
        prog="ltrpav-genotype", description="Genotype each ordered genome pair (annotated A, any other B; "
                                            "anchored first if needed): OUTDIR/pairs/<A>__<B>.calls.tsv.gz."),
        route=True, pair=True)
    return _execute(parser, argv, "ltrpav-genotype", _genotype)


def merge_main(argv: list[str] | None = None) -> int:
    """`ltrpav-merge`: loci and outputs from the pair files of every ordered pair."""
    parser = _options(argparse.ArgumentParser(
        prog="ltrpav-merge", description="Merge the pair files of every ordered pair (all must be finished) "
                                         "into loci and write the outputs."),
        vcf_ref=True)
    return _execute(parser, argv, "ltrpav-merge", _merge_only)


def _options(p: argparse.ArgumentParser, route: bool = False, pair: bool = False,
             vcf_ref: bool = False, version: bool = True) -> argparse.ArgumentParser:
    p.add_argument("--samples", required=True, type=Path, metavar="SHEET",
                   help="samples sheet: TSV with the header line 'label fasta annotation' and optional "
                        "'group' (taxon) and 'role' (outgroup); every row needs a FASTA; in annotation, "
                        "group and role '.' or empty means none; relative paths resolve against the sheet's "
                        "folder; labels use A-Z a-z 0-9 _ . - with no '__', no leading or trailing '_', "
                        "and not 'all'")
    p.add_argument("--outdir", required=True, type=Path, metavar="DIR", help="output directory (cache: DIR/work)")
    if route:
        p.add_argument("--threads", type=positive_int, default=8, metavar="N",
                       help="threads for the alignments (default: 8); at 32 threads 2.2-3.3-Gb maize "
                            "genomes peak near 20 GiB in all processes (4 or 7 genomes alike), about 25 GiB "
                            "with --anchor mm2")
        p.add_argument("--anchor", type=_route_name, default=DEFAULT_ROUTE, metavar="ROUTE",
                       help=_ANCHOR_HELP)
    if pair:
        p.add_argument("--pair", type=_pair, metavar="A,B", help="only this ordered pair (default: every pair)")
    if vcf_ref:
        p.add_argument("--vcf-ref", metavar="LABEL", help="genome of the VCF coordinates (default: first sheet row)")
    p.add_argument("-v", "--verbose", action="store_true", help="debug log; tracebacks on errors")
    if version:
        p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return p


def positive_int(text: str) -> int:
    """argparse type: an integer of at least 1."""
    try:
        n = int(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"not an integer: {text!r}") from None
    if n < 1:
        raise argparse.ArgumentTypeError(f"must be at least 1: {n}")
    return n


def _route_name(spec: str) -> str:
    try:
        get_route(spec)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(str(exc)) from None
    return spec


def _pair(text: str) -> tuple[str, str]:
    a, sep, b = text.partition(",")
    if not (sep and a and b) or "," in b or a == b:
        raise argparse.ArgumentTypeError(f"expected two different labels A,B: {text!r}")
    return a, b


def _execute(parser: argparse.ArgumentParser, argv: list[str] | None, prog: str,
             command: Callable[[argparse.Namespace, list[str]], None]) -> int:
    """Parse, log to stderr at INFO (DEBUG with -v) for the command's duration, run it; the exit status."""
    argv = sys.argv[1:] if argv is None else list(argv)
    args = parser.parse_args(argv)
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s", "%Y-%m-%d %H:%M:%S"))
    level = log.level
    log.addHandler(handler)
    log.setLevel(logging.DEBUG if args.verbose else logging.INFO)
    try:
        command(args, [prog, *argv])
    except KeyboardInterrupt:
        print("error: interrupted", file=sys.stderr)
        return 130
    except AnalysesFailed as exc:
        if args.verbose:
            traceback.print_exc()
        print(f"error: {exc}", file=sys.stderr)
        return 3
    except _HANDLED as exc:
        if args.verbose:
            traceback.print_exc()
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except ImportError as exc:  # a broken environment: name the module and the way to install it
        if args.verbose:
            traceback.print_exc()
        print(f"error: cannot import the Python module {exc.name or exc}: install ltrpav's dependencies with "
              f"{_INSTALL}", file=sys.stderr)
        return 1
    finally:
        log.removeHandler(handler)
        log.setLevel(level)
    return 0


# ---------------------------------------------------------------- stages


def _run(args: argparse.Namespace, command: list[str]) -> None:
    started, t0 = _now(), time.perf_counter()
    samples, by = _sheet(args)
    # the analyses' command module: --help and parsing stay fast because it imports nothing heavy; a missing
    # scipy or matplotlib is found now, not after the genotyping
    from .analysis import cli as analyses
    analyses.import_analysis_modules()
    analyses.check_trio(samples, args.trio, args.samples)  # before any genotyping
    route = _route(args.anchor)
    _backend(BACKEND)
    pairs = _pairs(samples)
    ref = args.vcf_ref or samples[0].label
    log.info("ltrpav %s run: %d genomes (%d annotated), %d pairs, route %s, %d threads -> %s", __version__,
             len(samples), sum(s.annotation is not None for s in samples), len(pairs), args.anchor, args.threads,
             args.outdir)
    with ExitStack() as stack:
        fastas = _open(samples, args.outdir, stack)
        elements, skipped = _elements(samples, fastas, args.outdir)
        calls = {}
        for k, (a, b) in enumerate(pairs, 1):
            log.info("pair %d/%d: %s vs %s", k, len(pairs), a, b)
            ctx = _context(a, b, by, fastas, elements, args.outdir, args.threads)
            calls[(a, b)] = genotype_pair(ctx, route, backend=BACKEND)
        params = {"stage": "run", "samples": str(Path(args.samples).resolve()),
                  "outdir": str(Path(args.outdir).resolve()), "threads": args.threads, "anchor": args.anchor,
                  "backend": BACKEND, "vcf_ref": ref}
        n = _merge(samples, fastas, elements, skipped, calls, ref, args.outdir, command, params, started)
    log.info("done in %.1f s: %d loci -> %s", time.perf_counter() - t0, n, args.outdir)
    try:
        analyses.run_analyses(args.samples, args.outdir, args.trio, args.identity, args.threads)
    except Exception as exc:  # a stats or paint failure: exit 3, the genotyping outputs kept
        what = " ".join(f"{type(exc).__name__}: {exc}".split())  # one line
        log.error("analyses failed (%s); the genotyping outputs in %s are complete: fix the cause, then run "
                  "ltrpav-stats and ltrpav-paint (or ltrpav run again: finished stages are skipped)", what,
                  args.outdir)
        raise AnalysesFailed(f"analyses failed: {what}") from exc


def _anchor(args: argparse.Namespace, command: list[str]) -> None:
    _pairwise(args, "anchor", anchor_pair)


def _genotype(args: argparse.Namespace, command: list[str]) -> None:
    _pairwise(args, "genotype", partial(genotype_pair, backend=BACKEND), backend=BACKEND)


def _pairwise(args: argparse.Namespace, stage: str, step: Callable[[PairContext, Route], object],
              backend: str | None = None) -> None:
    """step(context, route) on each ordered pair (or --pair), with only the genomes in them opened and loaded;
    `backend`: the window aligner the step runs, checked before anything is read."""
    t0 = time.perf_counter()
    samples, by = _sheet(args)
    route = _route(args.anchor)
    if backend is not None:
        _backend(backend)
    pairs = [args.pair] if args.pair else _pairs(samples)
    log.info("ltrpav %s %s: %d pair(s), route %s, %d threads -> %s", __version__, stage, len(pairs), args.anchor,
             args.threads, args.outdir)
    with ExitStack() as stack:
        used = _used(samples, pairs)
        fastas = _open(used, args.outdir, stack)
        elements, _ = _elements(used, fastas, args.outdir)
        for k, (a, b) in enumerate(pairs, 1):
            log.info("pair %d/%d: %s vs %s", k, len(pairs), a, b)
            step(_context(a, b, by, fastas, elements, args.outdir, args.threads), route)
    log.info("done in %.1f s: %s, %d pair(s)", time.perf_counter() - t0, stage, len(pairs))


def _merge_only(args: argparse.Namespace, command: list[str]) -> None:
    started, t0 = _now(), time.perf_counter()
    samples, _ = _sheet(args)
    ref = args.vcf_ref or samples[0].label
    calls = _pair_files(samples, args.outdir)
    log.info("ltrpav %s merge: %d genomes, %d pair files -> %s", __version__, len(samples), len(calls),
             args.outdir)
    with ExitStack() as stack:
        fastas = _open(samples, args.outdir, stack)
        elements, skipped = _elements(samples, fastas, args.outdir)
        _check_pair_files(calls, elements)
        params = {"stage": "merge", "samples": str(Path(args.samples).resolve()),
                  "outdir": str(Path(args.outdir).resolve()), "vcf_ref": ref}
        n = _merge(samples, fastas, elements, skipped, calls, ref, args.outdir, command, params, started)
    log.info("done in %.1f s: %d loci -> %s", time.perf_counter() - t0, n, args.outdir)


def _merge(samples: list[Sample], fastas: dict[str, Fasta], elements: dict[str, list[Element]],
           skipped: dict[str, Counter], calls: dict[tuple[str, str], Path], ref: str, outdir: Path,
           command: list[str], params: dict, started: datetime) -> int:
    """build_loci and every output; manifest.json last. Returns the number of loci."""
    outdir = Path(outdir)
    manifest = outdir / "manifest.json"
    manifest.unlink(missing_ok=True)  # present only after a finished merge
    order = {x: {sid: i for i, sid in enumerate(fa.lengths())} for x, fa in fastas.items()}
    loci, qc = build_loci(samples, elements, calls, order, skipped=skipped)
    for scope, metric, value in qc:
        if metric == "resolved_frac" and value < RESOLVED_WARN:  # nan (no calls) never warns
            a, b = scope.split(">")
            log.warning("%s vs %s: %.2f%% of the calls resolved (P/S/T/E): no orthologous alignment between %s "
                        "and %s?", a, b, 100 * value, a, b)
    write_loci_tsv(loci, samples, outdir / "loci.tsv")
    write_pav_matrix(loci, samples, outdir / "pav_matrix.tsv")
    write_qc(qc, outdir / "qc.tsv")
    _, unplaced = write_vcf(loci, samples, ref, fastas[ref], outdir / "pav.vcf.gz")
    write_tracks(loci, samples, outdir, order, {x: fa.lengths() for x, fa in fastas.items()})
    with open(unplaced) as fh:
        n_unplaced = sum(1 for _ in fh) - 1
    log.info("%d loci -> loci.tsv, pav_matrix.tsv, qc.tsv, pav.vcf.gz (%d on %s's coordinates, %d unplaced), "
             "<label>.pav.gff3/.bed", len(loci), len(loci) - n_unplaced, ref, n_unplaced)
    sums = outdir / "work" / CHECKSUM_CACHE
    write_manifest(manifest, command, params, samples, {s.label: _checksums(s, sums) for s in samples}, started,
                   _now(), skipped)
    return len(loci)


# ---------------------------------------------------------------- inputs


def _sheet(args: argparse.Namespace) -> tuple[list[Sample], dict[str, Sample]]:
    """The samples sheet, and its genomes by label; fails on an unknown --vcf-ref or --pair label, or a --pair
    whose first genome has no annotation."""
    samples = read_samples(args.samples)
    by = {s.label: s for s in samples}
    labels = ", ".join(by)
    ref = getattr(args, "vcf_ref", None)
    if ref is not None and ref not in by:
        raise CliError(f"--vcf-ref {ref!r} is not a label of {args.samples} ({labels})")
    pair = getattr(args, "pair", None)
    if pair is not None:
        for x in pair:
            if x not in by:
                raise CliError(f"--pair {','.join(pair)}: {x!r} is not a label of {args.samples} ({labels})")
        if by[pair[0]].annotation is None:
            raise CliError(f"--pair {','.join(pair)}: {pair[0]} has no annotation; the first genome of a pair "
                           "must be annotated (its elements are called)")
    return samples, by


def _route(spec: str) -> Route:
    """The anchoring route; fails if an executable it runs is not on PATH, or a PAF directory is missing."""
    missing = [exe for exe in _BINARIES.get(spec, ()) if shutil.which(exe) is None]
    if missing:
        raise CliError(f"route {spec!r} needs {' and '.join(missing)} on PATH (not found); install it with "
                       f"{_CONDA}")
    if spec.startswith("paf:") and not Path(spec[len("paf:"):]).is_dir():
        raise CliError(f"route {spec!r}: {spec[len('paf:'):]} is not a directory")
    return get_route(spec)


def _backend(name: str) -> None:
    """Fails if an executable the window aligner runs is not on PATH."""
    missing = [exe for exe in _BACKEND_BINARIES.get(name, ()) if shutil.which(exe) is None]
    if missing:
        raise CliError(f"window aligner {name!r} needs {' and '.join(missing)} on PATH (not found); install "
                       f"it with {_CONDA}, or bioconda's lastz")


def _pairs(samples: list[Sample]) -> list[tuple[str, str]]:
    """Every ordered pair (annotated A, any other B), in sheet order."""
    return [(a.label, b.label) for a in samples if a.annotation is not None for b in samples if b is not a]


def _used(samples: list[Sample], pairs: list[tuple[str, str]]) -> list[Sample]:
    """The genomes in `pairs`, in sheet order."""
    used = {x for pair in pairs for x in pair}
    return [s for s in samples if s.label in used]


def _pair_files(samples: list[Sample], outdir: Path) -> dict[tuple[str, str], Path]:
    """Every ordered pair's calls file; fails if one is missing or unfinished (no done marker: it may be left
    from other inputs by an interrupted rerun)."""
    files = {(a, b): Path(outdir) / "pairs" / f"{a}{PAIR_SEP}{b}.calls.tsv.gz" for a, b in _pairs(samples)}
    missing = [f"{a}{PAIR_SEP}{b}" for (a, b), p in files.items()
               if not (p.is_file() and marker(p).is_file())]
    if missing:
        raise CliError(f"{len(missing)} of {len(files)} pair files missing or unfinished in {Path(outdir) / 'pairs'}"
                       f": {', '.join(missing)}; run ltrpav-genotype (or ltrpav run) first")
    return files


def _check_pair_files(calls: dict[tuple[str, str], Path], elements: dict[str, list[Element]]) -> None:
    """Fails on a pair file that other genotyping code (the genotype stage's fingerprint: an edit outside its
    modules, such as the outputs', never counts) or another annotation of its A genome (elements digest)
    wrote, as recorded in its done marker: merging it would mix stale calls into the loci."""
    code = checkpoint.stage_fingerprint("genotype_pair")
    stale = []
    for (a, b), path in calls.items():
        meta = done_meta(marker(path)) or {}
        if meta.get("code") != code or meta.get("elements") != elements_digest(elements[a]):
            stale.append(f"{a}{PAIR_SEP}{b}")
    if stale:
        raise CliError(f"{len(stale)} pair file(s) written by other genotyping code or for another "
                       f"annotation: {', '.join(stale)}; rerun ltrpav-genotype (or ltrpav run) to recompute "
                       "them")


def _open(samples: list[Sample], outdir: Path, stack: ExitStack) -> dict[str, Fasta]:
    """Each genome's FASTA, its index cached in <outdir>/work/fai when its own directory is read-only."""
    cache = Path(outdir) / "work" / "fai"
    out = {}
    for s in samples:
        try:
            out[s.label] = stack.enter_context(Fasta(s.fasta, cache_dir=cache))
        except Exception as exc:  # pysam raises several kinds on a malformed or unindexable FASTA
            raise CliError(f"{s.label}: cannot open FASTA {s.fasta}: {exc}") from exc
    return out


def _elements(samples: list[Sample], fastas: dict[str, Fasta],
              outdir: Path) -> tuple[dict[str, list[Element]], dict[str, Counter]]:
    """The elements and skip counts of each annotated genome among `samples` (stage `elements`)."""
    elements, skipped = {}, {}
    for s in samples:
        if s.annotation is not None:
            elements[s.label], skipped[s.label] = _load_elements(s, fastas[s.label], Path(outdir) / "work")
    return elements, skipped


def _load_elements(s: Sample, fa: Fasta, work: Path) -> tuple[list[Element], Counter]:
    """One genome's elements and skip counts: the cached `elements` stage (annotation.elements_stage), keyed
    by the genome's FASTA and annotation checksums."""
    return elements_stage(s.label, s.annotation, fa, work, _checksums(s, work / CHECKSUM_CACHE))


def _checksums(s: Sample, sums: Path) -> dict[str, str]:
    """sha256 of the genome's inputs: "fasta"; "annotation" for a GFF3/BED file, or "annotation:<name>" for each
    table of an LTRquest prefix (none if no file matches: load_annotation then says why)."""
    out = {"fasta": file_checksum(s.fasta, sums)}
    if s.annotation is not None:
        files = annotation_files(s.annotation)
        one = files == [Path(s.annotation)]
        for f in files:
            out["annotation" if one else f"annotation:{f.name}"] = file_checksum(f, sums)
    return out


def _context(a: str, b: str, by: dict[str, Sample], fastas: dict[str, Fasta], elements: dict[str, list[Element]],
             outdir: Path, threads: int) -> PairContext:
    return PairContext(a=by[a], b=by[b], a_fa=fastas[a], b_fa=fastas[b], a_elements=elements[a],
                       b_elements=elements.get(b), outdir=Path(outdir), threads=threads)


def _now() -> datetime:
    return datetime.now(timezone.utc).replace(microsecond=0)
