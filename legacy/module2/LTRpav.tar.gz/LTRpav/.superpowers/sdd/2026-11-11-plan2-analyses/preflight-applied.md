# Plan 2 pre-flight: rulings applied

**Plan:** `docs/plans/2026-11-11-plan2-analyses.md`, 2554 lines after this round (1795 before).
- **Engine read at:** `plan1-engine` 12279a1, which includes "Key each stage on the modules it depends on":
  `package_fingerprint`, `stage_key(..., fingerprint=None)`, `STAGE_MODULES`, `stage_fingerprint`.
- **How:** the plan was rebuilt section by section. Line numbers below are the new plan's.
- **Result:** every ruling applied; nothing left unapplied.

## Engine fingerprint (C1-C3, as replaced by the coordinator's update)

- **C1, update applied (no NON_ENGINE entry).**
  - Plan 2 code lives in `ltrpav.analysis` and `ltrpav.plot`: Architecture l. 23-26, builder call 12 l. 100-107, File
    Structure l. 187-226, Task 1 Files l. 251-253 (creates both packages).
  - Analysis stages key on `stage_key(..., fingerprint=package_fingerprint("ltrpav.analysis"))`: builder call 12 l. 104,
    Task 10 Keys l. 2040.
  - Task 1's test l. 402 (`test_analysis_edit_keeps_engine_keys`): an analysis edit changes the analysis key, and every
    engine stage key (`stage_key(s, {}, {})` for every `STAGE_MODULES` stage, in a fresh process) is unchanged.
- **C2.**
  - Engine modules untouched: Global Constraints l. 119-121.
  - Analysis constants in `ltrpav/analysis/constants.py`: Task 1 Step 5 l. 519-535; Task 9 l. 1858-1861.
  - Commands in `ltrpav/analysis/cli.py`, registered in pyproject: Task 10 Files l. 2001-2006, l. 2067-2077;
    Task 11 l. 2201-2206.
  - One `cli.py` hook: Task 10 l. 2078-2083.
  - No engine-fingerprint check: Global Constraints l. 122-123, Task 1 Step 5 (`load_catalog`), Task 10 l. 2074.
  - Task 12 runs on main3 (engine 7d71073) without re-genotyping: l. 2378-2380.
  - DESIGN 8 sentence: Task 10 l. 2084-2087.
- **C3.** Keys hold the analysis package's own fingerprint plus the checksums of the engine outputs read:
  - Architecture l. 23-25 and Task 10 Keys l. 2040-2041;
  - `analysis_fingerprint(stage)` in Task 10 Interfaces (renamed from `stage_fingerprint` to avoid the engine's
    function);
  - the plot stage: Task 11 l. 2214 and l. 2226.

## Other engine rows

- **C4.** `test_cli_imports_without_scipy`, Task 10 l. 2153-2165: stderr's last line is the one `error:` line, there is
  exactly one `error:` line and no traceback; INFO lines may precede it.
- **C5.** The identity layer uses the engine's `DEFAULT_BACKEND` (LASTZ):
  - Tech Stack l. 34; builder call 2 l. 66-68; Engine API l. 52-56; Task 9 aligner l. 1865-1866;
  - LASTZ-dependent tests carry `needs_lastz` (Task 9 l. 1913).
  - "mappy" no longer appears.
- **C6.** The lock is refreshed by 84c8088's portable procedure: Global Constraints l. 126, Task 1 Step 1 l. 330-337
  (export filtered of `pip:` and `prefix:`, comment line appended, then a check).
- **C7.** The suite command `python -m pytest -W error -m "not slow"` has no extra `-q`: Global Constraints l. 131-133,
  and every Run step (Task 1 l. 516 and 549, and every later Run step; Task 10 l. 2186; Task 11 Step 7; Task 12 Steps 1 and 7).
- **C8.** Branch line: Global Constraints l. 111-112; Task 1 Step 1 preconditions.
- **C9.** Smoke-test path `runs/flank-mm2_2k/`: Task 10 Step 5 l. 2187.

## Plan-text defects

- **A4/D1.** `ToyLocus` dict fields use `field(default_factory=dict)`: Task 1 l. 428-440.
- **A5/D14.**
  - Toy elements are 150 bp with 40-bp LTRs. Spacing must be >= 2 × the element length, so `simulate_run` raises below
    it, and `n_per_seq` <= 3000 keeps 332 bp. Task 1 l. 488-490.
  - The test: `test_simulate_run_deterministic` l. 393-401, with 4000 rejected.
  - Tests at 3000 (Tasks 4, 6) stay valid.
- **A10.** `assemble`'s version line goes in `findings.txt` only; `stats.tsv` is a pure header row. Task 10 l. 2063-2066;
  asserted in `test_stats_then_paint` l. 2108-2117.
- **A12/D2.** One discovery function, `relations.discover(cat, x, y, z, dist, outgroup)`, with the rule as a parameter.
  D_pav, f4 and identity use "E"; KKSC uses "not_present". Each `loci` names its rule. Task 3 l. 710-733; used in
  Task 4 l. 925-940, Task 9 l. 1871.
- **B3.** `test_kksc_reads_the_third_genomes_calls` has sister pair (R, S) and donor D, with stated counts (merged R+D 3,
  D-read 2 vs 1, p_top binomtest(12, 15)) and a "none" case. Task 3 l. 831-844.
- **A18.** Blocks key on (genome, fai index): `InvBlock.seq_x/seq_y`, names for output only; `inside` takes fai
  indexes; `Tract.seq`; the array conventions. Task 5 l. 1137-1157; Task 6 l. 1290; File Structure l. 230-236.
- **B5/D7.** `test_block_found` is valid code: it selects each pair with S (S~O included) and asserts that R~D, R~O and
  D~O have none. Task 5 l. 1228-1242.
- **A19.** `inversion_rows` is in `run_stats`' order: Task 10 l. 2051.
- **A21 and the T6/T9 dependency.**
  - `youngest_k` comes from the annotation's K; `youngest_u95` uses exact counts only and is `.` without
    `identity.tsv`. Task 6 l. 1356-1366.
  - identity.tsv row kinds (self, pair), IDENTITY_COLUMNS with `kind`/`genome`/`partner`: Task 9 l. 1840, l. 1874-1879.
  - `run_paint` reads the self rows: Task 10 l. 2058-2061.
- **D4.** `u95` is written once, in Task 2 (l. 584, `test_u95` l. 642), and imported by Tasks 6 and 9.
- **D3.** `resolution()` is written once, in Task 2 (l. 585-587, test l. 646-655), and used by Tasks 4, 6, 7 and 9.
- **A24/D13.**
  - LTRpav's `mean_tract_bp` is L, LTRmix's name and quantity; L/(1 - pi) is `mean_donor_run_bp`. Task 6 l. 1334-1338.
  - Task 12 item 7 compares like with like: l. 2461-2463.
- **A30/A31/A32.**
  - `Catalog.sheet` and `sheet_sha`; `load_catalog(outdir, samples, sheet)`: Task 1 l. 276, l. 309.
  - Stage inputs from `cat.sheet_sha`: Task 10 l. 2035-2039.
  - Markers list exactly the files each stage writes; assembled files are never listed: Task 10 l. 2042-2049.
  - Skip test `test_stats_skip_after_paint`: l. 2118-2124.
  - Plot stage: Task 11 l. 2214-2215.
- **A35.** main3 labels (B73, TIL18, TIL01, Zd) are used throughout Task 12; `B73v5` is the element-name prefix only.
  l. 2366-2371, items 1 and 2.
- **A36.** LTRpav's counts are re-binned into LTRmix's right-closed bins (recounted per locus by `compare_papers.py`):
  Task 12 l. 2427-2440.
- **A37.** Task 12 computes the outgroup upper bound from the catalog and checks it against `stats.tsv`; it does not quote
  QC.md. Item 11 l. 2471-2473; Step 1 and Step 3 no longer reference QC.md.
- **D5.** Every test is complete code with expected values: Task 1 l. 341-425, Task 2 l. 617-670, Task 3 l. 775-898,
  Task 4 l. 980-1118, Task 5 l. 1189-1259, Task 6 l. 1391-1505, Task 7 l. 1588-1664, Task 8 l. 1740-1815, Task 9
  l. 1910-1988, Task 10 l. 2090-2180, Task 11 l. 2280-2333.
  - Helpers are written out: `loc`, `dmat`, `read_tsv`, `leaf_distances`, `splits`, `make_case`, `enumerate_paths`,
    `covered_bp`, `spec`, `substitute`, `INT_POSITIONS_12`, `BRANCH_COUNTS`.
  - Simulated values give the seed. Replica values (rr_toy.py) are quoted as context, and the tests assert bounds.
- **D6.** Test conventions, l. 237-245: a failing seeded test is investigated, never fixed by changing the toy, seed or
  bound. Seeds 6-25 are rerun, and |Z| >= 3 in at most 1 of 20 clears the model. Task 4 Step 4 points to it.
- **D8.** `test_paint_null_and_positive_control`: 0 tracts at q < 0.05 in the null, the posterior mean stays within
  0.05 of the decoy's, and the admixed run recovers >= 80% of the known tract bp. Task 6 l. 1447-1454.
- **D9.** `BRANCH_COUNTS` is inline, derived from the plan's branch-length rule (every scenario recomputed:
  deep-root codes, ancestral ++00/--00). Task 7 l. 1620-1634.
- **D10.** BED strand "." handled:
  - `orient()` takes the orientation from the alignment; an un-orientable pair is skipped and counted in findings
    ("<n> pair(s) skipped: orientation not inferred"). Task 9 l. 1843, l. 1880-1885;
  - `test_orient` and the end-to-end test's seventh locus assert it.
- **D12.** The PNG dpi assertion is >= 299.5: Task 11 l. 2288.

## Scan rows without a separate ruling, fixed in the same spirit

- **A3:** `FLAG_BIT` is in Task 1's Produces (l. 271).
- **A34:** `Catalog.tsd` (l. 291) feeds the figure's base-pair panel; `Fasta.fetch` is 0-based (Global Constraints and
  Task 11 l. 2255).
- **B1:** the toy's skip reason is `skipped_malformed_coordinates`, a reason the loaders emit (l. 479; asserted l. 897).
- **B6:**
  - `shortest_callable` asserts the exact (2, 10,000) and (4, 20,000) (l. 1503);
  - `forward_backward`'s `starts` carries a final sentinel (l. 1302).
- **B8:** `MIN_SEG` is in Task 8's Consumes (l. 1681).
- **B9:** `substitute` and `INT_POSITIONS_12` are defined (Task 9 l. 1915-1922).
- **B12:** `analyses.done` is in Task 12's Files and the File Structure (l. 218, l. 2363).
- **D11:** covered by C4, A31 and A32 above.
- The re-review's N1-N5 remain in place: the merge rule and nine cases in Task 5; the +0.15 and 0.05 bar in Task 4; the
  CliError in Task 10; the slow test in Task 9; the donor's copy in Task 6.

## Self-review (writing-plans), rerun after the edits

- **Spec coverage:** the table at the end was updated (discover in Task 3, resolution in Task 2). Every DESIGN 7.1-7.8
  item, the section-6 outputs and the CLI have a task.
- **Names and types across Interfaces:** consistent after the Catalog change. Checked:
  - `load_catalog(outdir, samples, sheet)`;
  - `discover`/`Counted` in Task 3, used by Tasks 4 and 9;
  - `d_pav(cat, R, S, D, c, size, keep)`;
  - `block_ids(seq, mid, size)`, `cluster_keys(cat, gstar, rows)`;
  - `InvBlock.seq_x/seq_y`, `Tract.seq`, `Painting.idx`;
  - `paint(..., self_counts)` and identity self rows;
  - `analysis_fingerprint`, `run_analyses`, `overview(outdir, samples, sheet, trio)`.

  Two slips were fixed: `resolution` rows now state stratum `all`, and Task 3's Consumes names `P_WARN`.
- **Step scan:** no signature-only or `...` test bodies remain.
- **Review Focus:** all five tests are present (Task 10 `test_stats_shared_seqids`, `test_run_two_genomes`; Task 4 two;
  Task 6 two; Task 11 two).
- **Proportion:** 2554 lines and about 22k words, about 3.4 times DESIGN. The growth is the full test code D5 requires,
  not implementation bodies.
