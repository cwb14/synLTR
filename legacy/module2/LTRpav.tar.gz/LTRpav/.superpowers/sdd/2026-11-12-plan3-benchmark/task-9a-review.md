# Task 9 Part A review (evalib, RULES.md, eval_run.py)

Reviewed 2026-11-13. Files (plan3/, unchanged during the review; sha256 checked before and after):
`common/evalib.py` f9f61a20…3da, `common/test_evalib.py` cdb676bf…d56, `sim/eval_run.py` 145049f2…02a,
`sim/RULES.md` 4111826d…a293 (read-only, byte-identical). All probes ran on copies in
`scratchpad/p3t9review/` (code copies in `common/`, `sim/`; toy copies from `toy2/runs/` in `runs/`; QA scripts in
`qa/`), with `. common/env.sh`, at most 8 threads, under `timeout 15m`. Nothing in plan3/ changed except the pilot's
own `pilot.tsv.mem.tsv`.

Reproduction: `eval_run.py` on fresh copies of both toys gives eval.json identical to the implementer's (all keys but
created/run_dir/elapsed_s), NA counts 45 and 106. `python -W error -m pytest -q -p no:cacheprovider test_evalib.py`:
9 passed. ruff clean on all three files.

## Spec Compliance

| Item | Verdict | Evidence |
|---|---|---|
| evalib signatures (brief "Produces") | ✅ | evalib.py:68, 113, 163, 178, 196, 208, 262, 224, 291 match the brief's eight signatures |
| auroc: Mann-Whitney, ties one half, nan on an empty class | ✅ | average ranks evalib.py:56-65, U/(n1 n0) :81, nan :78-79. Fuzzed against brute-force pair counting with heavy ties (200 random cases): equal to 1e-12 |
| bp_overlap: merged intervals | ✅ | merge :87-97 then two-pointer :100-110. Fuzzed against bitmasks (300 cases): exact |
| recall_by_length: found at >= 50% cover | ✅ | :163-175 (`2 * cov >= len`, cover against merged calls via tract_cover :130-138). Fuzzed: exact |
| precision_by_length: per called tract, by its own length | ✅ | :178-193. Fuzzed: exact |
| tract_fdr | ✅ | :196-199; touching = no overlap. Fuzzed: exact |
| dfoil_direction vs `direction.DFOIL_ALT_SIGNS` | ✅ | :208-221. All 20 labels of snap direction.py:70-75 mapped in both quartet orientations: P1/P2=>P3/P4 -> A>C, P3/P4=>P1/P2 -> C>A, both `<=>` kinds -> unresolved, none -> none |
| truth_d: blocks, outgroup rule, jackknife | ✅ | :262-285 counts R,S in PSTE and O == "E" (:279), the tool's rule "every outgroup E" (snap trio.py:4-14); every counted row in the jackknife, `common.why` on informative blocks, `common.guard` (:232-250), as snap trio.py:109-120. Independent csv + own delete-one jackknife (qa/truthd_check.py) reproduces D, se, z, n, nblocks to the last digit on both toys |
| resign | ✅ | :224-226 |
| match_by_coords: both ends within slop, one-to-one | ✅ | :291-322 (`ds <= slop and de <= slop` :310-311) |
| Tests pin exact values | ✅ | test_evalib.py: auroc 1.0/0.5/0.0/0.875/nan (:26-33), bp_overlap 5/20/0/10 (:36-41), recall/precision dicts (:44-58), fdr tuples (:61-66), dfoil labels (:69-77), truth_d counts, D, analytic se and z (:84-114), jackknife guard (:117-124), resign (:127-130), match dicts (:133-151). Gaps: Minor m8 |
| RULES.md verbatim | ✅ | `diff <(sed -n 110,172p task-9-brief.md) <(sed -n '10,$p' RULES.md)`: the only difference is the two R2 lines (RULES.md:54-55) |
| RULES.md dated, R2 sentence under rule 7 | ✅ | RULES.md:3 "Date: 2026-11-13"; RULES.md:54-55 is rule 7's first sub-bullet, marked (R2) |
| RULES.md before eval_run.py and before any scoring | ✅ | birth times: RULES.md 01:47:41, eval_run.py 01:52:40, evalib/tests 01:46:48; the only eval.json files anywhere are the toy copies' (02:03); no `eval/` under plan3/sim/runs |
| Design fields | ✅ | eval_run.py:289-334; f and pulse cross-checked with params.json :293-297 |
| Calibration (main): strata incl. no_outgroup_filter, dD + z, f4 vs true fraction, n counted/informative | ✅ | :98, :340-375; values equal stats.tsv rows (spot-checked on both toys) |
| Roles | ✅ | :381-414 |
| Truth D: donor-discovered with and without outgroup filter; brief's block rule | ✅ | :449-458, :420-429; brief rule = stats.block_size = stats.tsv block_bp on both toys (140,296; 147,709) |
| Truth D: sister-discovered per I3 | ✅ | :470 (`in_d[n] == "P" and n in annotated[D]`, A1/B1 annotated, other sister E). Independent recount: null 41/23 D +0.28125 z 2.0938; trio 33/43 D -0.13158 z -1.0004, equal to eval.json. Block coordinates: Minor m1 |
| Head-to-head (roles): AUROC, bp P/R all and q05, by length, by loci bins, FDR, excess vs fraction | ✅ | :540-572, :604-617; bins `LOCI_BINS` (0,1,3,10,30,inf) :97 as ruled. Independent recompute (bitmask intervals, scipy mannwhitneyu; qa/paint_check.py) equals eval.json for all four models on the trio toy: AUROC 0.598228/0.594448/0.600132/0.592912, every bp, bin and FDR count. The q05 path (no q05 tract on either toy) was exercised on a copy with q = 0.01 set on 5 tracts: 5 called, 337,444 bp, 132,173 TP, FDR 3/5, bins all equal to the independent recompute |
| wrong_recipient / wrong_trio (I4) | ✅ | :620-651. Exercised on copies: A1,B1;C1 (--trio) -> 0/0 and head-to-head accuracy == models.main; A1,C1;B1 -> 0/1, scored as painted; B1,A1;C1 -> 1/1, recall 0, AUROC NA; "sheet order" A1 -> 1/0 (I2, not ruled: ⚠️ below) |
| Model comparison: main/any/decoy/anydecoy, e0/e1, degenerate, n q05 tracts, excess | ✅ | :1036-1040, :525-537 (`e1_RD > 0.99 and e0_RS > 0.99` :535); tract counts cross-checked against the files :586-589 |
| Direction: dfoil_direction vs predictions and truth, D_dir | ✅ | :657-691; prediction read in the probe's orientation P1P2 = A (probe_direction.py:41) :680; uses the label only (R2); call none/unresolved/right/wrong :685 |
| Decision 11 (nodonor) | ✅ | :697-716 |
| Genotypes: join eid -> Name -> truth; parity with `ltrpav-sim score` | ✅ | :791-816, :831-866. Independent csv join (qa/geno_check.py) equals pooled, by_target (O1, ingroup) and by_window (c01-c05) tp/fp/fn for every state and tier set on both toys, and the summary counts. A tampered score file (B1__C1 P high tp) stops the run, rc 1, naming pair, state and tier set |
| Pooled high-tier P/E precision | ✅ | null 11,919/11,946 = 0.997740, E 7,861/7,898 = 0.995315; trio P 0.996060, E 0.992155 (independent, equal) |
| LTRquest coords pool (I6, ruled separate) | ✅ | :885-894, :926-937; `--coords-check` on a copy: 2,613 matched = 2,613 equal to the true eid, 0 unmatched, pooled counts equal to the eid join |
| Identity s vs 0.0036 | ✅ | :945-954; row B1;C1 s 0.00340238; true 2 x 3e-8 x 60,000 from params.json |
| Realism fields | ✅ | :957-987; main3 references verbatim from the brief :101-108 |
| Every NA has a reason; sha256 of scripts | ✅ | `finalize` refuses a bare None/nan :143-156; scripts :1022-1025 (eval_ltrmix.py NA until Part B) |
| Independence from the toys | ✅ | No toy-derived constant: Q05 = Q_TRACT (asserted :109), DEGEN from rule 6, SLOP from the tool's constants, block rule from the brief, LOCI_BINS ruled, main3 values from the brief. Toy artifacts are reported as such (report "Toy-scale artifacts") |
| I2 ("sheet order" = not identified) | ⚠️ | :410-411, :623-626. Not covered by a ruling; conservative (counts a tie as a miss for LTRpav) and symmetric with LTRmix sending nan to y. Controller should confirm |
| Brief "Consumes: `resolution`" | ⚠️ | not read anywhere in eval_run.py (Minor m6) |

## Strengths
- The scoring core is small and right: every evalib function matches its definition and survives fuzzing against
  brute force; truth D reuses the snapshot's jackknife and guard, so its se means what D_pav's se means.
- Parity with `ltrpav-sim score` is enforced per pair, per state and tier set, and pooled; it fails loudly.
- NA discipline is mechanical: no value can reach eval.json as null without a reason (`finalize`).
- Cross-checks against the tool's own outputs (tract counts vs stats.tsv, genotyped names vs GFF3, block rule vs
  stats.block_size and the stats.tsv row, snapshot import path) turn silent mismatches into errors.
- Every interpretation and simplification is named in the docstring and the report.

## Issues

### Critical
None.

### Important
None.

### Minor
- **m1. Sister-discovered blocks: stale rationale, and LTRmix uses the donor's coordinates.** eval_run.py:41-42,
  :461, :471, :478 put each locus on its own sister's coordinates "because a C1 copy reading S or T has no position
  in C1's truth". After ruling I3 every counted locus is P and annotated in C1, so C1's coordinates exist for all of
  them, and LTRmix blocks D_ins on the donor copies (ltrmix.py:1143-1145). The two choices change se: null toy
  0.1343 (own) vs 0.1444 (C1), trio 0.1315 vs 0.1334 (44 vs 51 blocks); D is unchanged. Rules 1-2 read truth D's Z,
  so prefer C1's coordinates (the C1 row of the same eid), or keep the choice and fix the stated reason.
- **m2. `wrong_trio` overlaps `wrong_recipient`.** :629 sets wrong_trio for any scope other than A1,B1;C1, so
  B1,A1;C1 gives 1/1 and "sheet order" A1,B1;C1 gives 1/0. It is documented (:16), but summarize (Part B) must
  count "A1 recipient, wrong sister or donor" as `wrong_recipient == 0 and wrong_trio == 1`, or the flag should be
  narrowed to the sister pair and donor.
- **m3. Rule 5's NA and q05 recall.** RULES.md:40-41 drops runs "where either model's value is NA (no q <= 0.05
  tract)"; eval.json gives q05.bp_recall 0.0 with no q05 tract (:555) and NA only for precision. Not an eval_run
  defect, but Part B must state which reading summarize applies (q05.n_called carries what both readings need).
- **m4. q "none" stops the run.** :494 parses q with `float`; the tool writes `none` when a painting has no decoy
  (snap paint.py:580). The run then fails with a ValueError instead of scoring q as undefined (never <= 0.05) with a
  reason. Unlikely on this grid (B1 is always annotated), loud if it happens.
- **m5. Edge paths.** :661-665 keeps the last A-C quartet silently (one per run while per_taxon <= 2);
  :620-622 returns no wrong_recipient field when roles has no row on {A1,B1,C1}; :646 writes bp_recall 0.0 even if
  A1's tract file were empty. None arises on the grid as built.
- **m6. `resolution` rows not carried.** The brief lists stats `resolution` (resolved_A1, resolved_B1) as consumed;
  eval_run never reads them. They are the direct readout of one-sided dropout bias (trio toy 0.816 vs 0.755), useful
  beside rules 4-5's dropout nulls.
- **m7. Dead code.** `no_accuracy` (:575-576) is never called.
- **m8. Test gaps (behavior correct, not pinned).** No test drops an outgroup-unresolved (D/O/G) locus under the
  outgroup rule (only O = P, test_evalib.py:90); no bin-edge case (a tract of exactly 50,000 bp); no test of
  `tract_cover` with touching called intervals.

## Assessment
**Approved.** Spec ✅ (two ⚠️: I2 needs the controller's confirmation; `resolution` not consumed). Quality: no
Critical or Important issue; every scored number I recomputed independently (truth D, painting accuracy at all and
q05, genotype pools and splits, high-tier precision, identity) matches eval.json exactly. m1-m3 should be settled
before Part B's summarize relies on them.
