#!/usr/bin/env bash
# Summary of robustness.sh (confirmed truth): jitter, primary-only, multi-sample vs single-sample runs.
# usage: robust_summary.sh <version tag> [S=Camara] [ref=hap1]
set -euo pipefail
V=$1; S=${2:-Camara}; ref=${3:-hap1}
W=$(dirname "$(readlink -f "$0")"); O=$S/robust/$V; T=$(mktemp -d)
args=""; for f in $O/*.genotypes.tsv; do n=$(basename $f .genotypes.tsv); [[ $n == multi ]] && continue; args="$args ${n}=$f"; done
python $W/../eval_hap_truth.py --truth $S/truth/${ref}_truth.tsv --mode diploid --ltrkin $args -o $T/r > /dev/null 2> $T/r.log
python - "$T/r.metrics.tsv" "$O" "$V" "$S" "$ref" <<'PY'
import sys, pandas as pd
m = pd.read_csv(sys.argv[1], sep="\t"); O, V, S, ref = sys.argv[2:6]
x = m[(m.stratum == "truth_source") & (m.level == "confirmed") & (m.scope == "all")]
print(x[["tool", "n", "concordance"]].sort_values("tool").to_string(index=False))
mu = pd.read_csv(f"{O}/multi.genotypes.tsv", sep="\t")     # multi-sample run vs single-sample runs
for s, single in [(mu["sample"].unique()[0], f"{S}/calls/{V}/sub/{ref}_d20_s1.p2.genotypes.tsv"),
                  (mu["sample"].unique()[-1], f"{S}/calls/{V}/part/{ref}_h10.p2.genotypes.tsv")]:
    a = mu[mu["sample"] == s].set_index("element_id")[["genotype", "gq"]]
    b = pd.read_csv(single, sep="\t").set_index("element_id")[["genotype", "gq"]].reindex(a.index)
    print(f"multi vs single ({s}): genotype identical {(a.genotype == b.genotype).mean():.4f}, "
          f"GQ identical {(a.gq == b.gq).mean():.4f} (n {len(a)})")
PY
for f in $O/*.log; do echo "$(basename $f): $(grep -o 'boundary error[^|]*tolerance +[0-9]* bp' $f | head -1)"; done
rm -rf $T
