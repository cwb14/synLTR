"""Fixed internal constants; each has a one-line reason."""

TSD_DEFAULT = 5            # most LTR-RTs make 4-6-bp TSDs; 5 bp is the common case
SLOP_TSD_MULT = 2          # E needs the gap within ~2 TSD lengths of the element ends (classify.py, rule 4)
COV_PRESENT = 0.8          # Wicker et al. 2007 80-80-80 rule: >=80% of a part aligned = present
SOLO_LEN = (0.8, 1.2)      # a solo-LTR is one LTR's worth of aligned sequence, same 80% rule
MIN_SEG = 80               # Wicker's 80-bp minimum: less aligned sequence counts as none
IDENT_MIN = 0.8            # flank identity below the 80% rule: site placement not trusted
MARGIN_HIGH = 0.5          # orthologous chain outscores any competitor 2:1
IDENT_FLANK = 1000         # local A-B identity is read over the element +-1 kb: its own neighborhood
ANCHOR_MIN = 100           # FastGA's default minimum alignment length; shorter anchors not trusted (and the
#                            chaining DP's minimum advance of each block end on each genome: chain_blocks)
WINDOW_PAD = 500           # anchored sequence kept at each window end so the local aligner can seed
WINDOW_CAP = 500_000       # runtime guard on window span (A and B)
CHAIN_MAX_GAP = 1_000_000  # no chaining across >1 Mb without alignment
CHAIN_INDEL_COST = 0.05    # per bp of diagonal shift: a 30-kb insertion is bridged after > 1.5 kb of chain
CHAIN_OVERLAP = 100        # an overlap this small between two chains' blocks is edge slop, not competition
CHAIN_LOOKBACK = 200       # predecessors examined per block in the chaining DP
MIN_CHAIN_SCORE = 1000     # a chain must carry >=1 kb of aligned sequence
REFINE_PAD = 150           # junction refinement half-width; covers local-aligner end error
SCORE = (1, 4, 6, 2)       # match, mismatch, gap open, gap extend: minimap2 asm20 short-gap scoring
MM2_CHUNK = 100_000        # query chunk for in-process whole-genome mapping; bounds memory
MM2_OVERLAP = 10_000       # context mapped on each side of a chunk's core: an alignment across a core edge is
#                            found in full by both chunks, each keeping its own core's part
MM2_PRESET = "asm20"       # minimap2's preset for assemblies up to ~5% divergent: covers intraspecific pairs
# Wicker's 80-bp minimum; split at longer indels, blocks stay near-collinear: A->B errs < 80 bp per indel
SPLIT_INDEL = 80
# secondaries kept per mapping (rivals) and a bound on the hits: 5 is minimap2's generic default -N; its asm
# presets use -N 50
MAPPY_BEST_N = 5
# window alignment maps each strand apart (MM_F_FOR_ONLY, MM_F_REV_ONLY), never with long join (MM_F_NO_LJOIN)
MAPPY_FWD_FLAGS = 0x400 | 0x100000  # flanks stay separate chains, never bridged over an element and Z-dropped
MAPPY_REV_FLAGS = 0x400 | 0x200000  # inverted hits apart: never outrank (and drop) the short flank chains
# minimap2 manual: asm5/asm10/asm20 suit ~0.1/1/5% divergence; d <= cut takes that preset, else asm20 (mappy
# window backend; LASTZ scores every pair as asm20: see lastz_args)
PRESET_CUTS = ((0.001, "asm5"), (0.01, "asm10"))
FLANK_TARGET = 2000        # unique flank bases collected per side (shorter flanks are often repeats)
FLANK_CAP = 2_000          # farthest a flank may reach: longer caps (5-20 kb) cost more, no gain (sims)
FLANK_PIECE_MIN = 200      # shorter flank pieces seed poorly and multi-map
CHUNK_WINDOWS = 2000       # most windows per genotyping chunk: bounds its memory and the work a crash loses
CHUNK_MIN = 8              # fewest windows per chunk: fewer add file and marker overhead
CHUNK_TARGET = 256         # chunks per pair: ~4 per worker at 64 threads; not --threads: resumes reuse chunks
U_WARN = 0.99              # > 99% U calls: the pair shares next to no anchored sequence; warn
RESOLVED_WARN = 0.01       # < 1% of a pair's calls resolved (P/S/T/E): no orthologous alignment; warn
# malformed annotation records warned one by one (file:line, reason), later ones only counted: a bad line per
# record must not flood the log of a multi-Gb EDTA GFF3
RECORD_WARNINGS = 5
DEFAULT_ROUTE = "flank-mm2"  # as accurate as whole-genome mm2 on simulated pairs at half its cost
DEFAULT_BACKEND = "lastz"  # resolves more elements correctly than mappy on simulated pairs (0.930 vs 0.898)
LASTZ_SEED = "12of19"      # LASTZ's default spaced seed, one transition allowed: sensitive at 0-3% divergence
NCAND = 3                  # nearest anchor candidates tried per side: rescues a window whose nearest anchor
#                            is out of order (a breakpoint) without searching far
BLAST_EVALUE = "1e-20"     # megablast on ~kb pieces: only real homology (a 200-bp piece scores ~1e-40 at 90%)
BLAST_MAX_TARGETS = 50     # subjects kept per flank piece (the first found, not the best): above a
#                            chromosome-scale assembly's count; scaffold-rich genomes may lose rivals
BLAST_MAX_HSPS = 20        # HSPs kept per subject: bounds a multi-copy piece's output; margins need one rival
BED_LTR_EDGE = 20          # a BED element's LTR self-alignment may start or end this far from its ends
BED_LTR_MAX = 6000         # longest LTR searched for in a BED element (LTRs rarely exceed ~5 kb)
