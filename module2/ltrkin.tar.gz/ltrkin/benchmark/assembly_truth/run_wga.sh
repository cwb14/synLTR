#!/usr/bin/env bash
# Whole-genome alignment of each haplotype (query) to the other (target), for the read-independent truth.
# usage: run_wga.sh <S> [threads]   -> <S>/wga/hap1_on_hap2.paf.gz, hap2_on_hap1.paf.gz
set -euo pipefail
S=$1; T=${2:-20}
mkdir -p $S/wga
minimap2 --version > $S/wga/minimap2.version
for q in 1 2; do
  t=$((3 - q)); o=$S/wga/hap${q}_on_hap${t}
  [[ -s $o.paf.gz ]] && continue
  # asm20: the haplotypes differ by 1-7% around TEs (asm5 left 57% of C. amara elements unplaced)
  minimap2 -cx asm20 --eqx --secondary=no -t $T data/$S/${S}_hap${t}.fa data/$S/${S}_hap${q}.fa 2> $o.log | gzip -1 > $o.paf.gz.tmp
  mv $o.paf.gz.tmp $o.paf.gz
done
