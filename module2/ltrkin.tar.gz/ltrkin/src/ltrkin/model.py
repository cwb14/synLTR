"""Genotype model (see docs/DESIGN.md, "Genotype: model").

Alleles: F full, S solo LTR, E empty site, N null (the haplotype gives no informative reads: the site and its
flanks are missing or rearranged on it). A haplotype carrying allele a yields informative reads at rate d_hap * r_a,
with r_a from the sample's read-span distribution (r_N = 0). Likelihood of genotype g:
  NB(total informative reads | d_hap * sum_a n_g(a) r_a, k)  x  multinomial(F/S/E counts | allele mixture, error eps)
Flat prior over genotypes; GQ = phred(1 - posterior of the best genotype).
"""
import math
import random
from itertools import combinations_with_replacement

import numpy as np

from .constants import (ANCHOR as A, EB_MIN_PER_CLASS, N_DEPTH_POINTS, SEED, GQ_CAP, EPS_FLOOR, EPS_CAP, EPS_MIN_READS, PAV_P, PH_ERR,
                        CAL_MIN_SITES)

CLASSES = "FSE"
MU_MIN = 0.5          # expected stray informative reads at a site absent from every haplotype (allows mismaps)


def _nb_logpmf_vec(x, mu, k, logfact):
    """NB log-pmf for an array of integer counts x (mean mu, size k); logfact[n] = log(n!). Uses
    lgamma(x + k) - lgamma(k) = sum_{i < x} log(k + i), exact for integer x (no scipy needed)."""
    xmax = int(x.max())
    lg = np.concatenate(([0.0], np.cumsum(np.log(k + np.arange(xmax)))))
    xi = x.astype(np.int64)
    p = k / (k + mu)
    return lg[xi] - logfact[xi] + k * np.log(p) + x * np.log1p(-p)


def fit_copy_mixture(depths, ploidy):
    """Depth at random positions as a mixture of 1..ploidy copies of one haplotype depth d: copy number c has
    NB(c d, size c k) (a sum of c haplotypes). Returns (d, k, weights). Grid search over d and k (vectorized over d),
    EM for the weights, a mild Dirichlet prior (alpha 2 on the full-ploidy component) to break the tie a single peak
    leaves between "ploidy copies of d" and "fewer copies of a larger d"."""
    x = np.asarray(depths, float)
    med = float(np.median(x))
    x = np.round(x[x <= 3 * med])                        # collapsed repeats are not copies of the genome
    xi = x.astype(np.int64)
    logfact = np.concatenate(([0.0], np.cumsum(np.log(np.arange(1, int(x.max()) + 1)))))
    cs = np.arange(1, ploidy + 1)
    d_grid = med / ploidy * np.exp(np.linspace(np.log(0.4), np.log(2.5), 46))
    k_grid = np.exp(np.linspace(np.log(2.0), np.log(1000.0), 16))
    prior = np.where(cs == ploidy, 1.0, 0.0)
    best = _mixture_search(x, xi, logfact, cs, d_grid, k_grid, prior, ploidy)
    # refine around the best grid point (+-1 step in d and k)
    d0, k0 = best[1], best[2]
    d_fine = d0 * np.exp(np.linspace(-0.045, 0.045, 19))
    k_fine = k0 * np.exp(np.linspace(-0.4, 0.4, 9))
    fine = _mixture_search(x, xi, logfact, cs, d_fine, k_fine, prior, ploidy)
    best = fine if fine[0] > best[0] else best
    return best[1], best[2], best[3]


def _mixture_search(x, xi, logfact, cs, d_grid, k_grid, prior, ploidy):
    best = None
    for k in k_grid:
        L = np.empty((len(x), len(d_grid), ploidy))
        for j, c in enumerate(cs):
            kc = c * k
            lg = np.concatenate(([0.0], np.cumsum(np.log(kc + np.arange(int(x.max()))))))[xi]
            p = kc / (kc + c * d_grid)                       # per d
            L[:, :, j] = (lg - logfact[xi])[:, None] + kc * np.log(p)[None, :] + x[:, None] * np.log1p(-p)[None, :]
        m = L.max(2, keepdims=True)
        P = np.exp(L - m)                                    # points x d x copies
        w = np.full((len(d_grid), ploidy), 1.0 / ploidy)
        for _ in range(30):
            R = P * w[None]
            R /= R.sum(2, keepdims=True)
            w = R.sum(0) + prior[None]
            w /= w.sum(1, keepdims=True)
        ll = (m[:, :, 0] + np.log((P * w[None]).sum(2))).sum(0) + np.log(w[:, -1])
        j = int(np.argmax(ll))
        if best is None or ll[j] > best[0]:
            best = (float(ll[j]), float(d_grid[j]), float(k), w[j].copy())
    return best


class ReadModel:
    """Per-sample depth and read-span model, estimated from random positions."""

    def __init__(self, depths, spans, ploidy):
        depths = np.asarray(depths, float)
        self.spans = np.sort(np.asarray(spans, float))
        self.ploidy = ploidy
        pos = depths[depths > 0]
        if len(pos) < 20 or len(self.spans) < 50:
            raise ValueError(f"too little coverage to model depth ({len(pos)} covered points, {len(self.spans)} reads)")
        # the genome may be partly hemizygous (outcrossers: up to ~40% of sequence on one haplotype): fit depth as a
        # mixture of 1..ploidy copies of one haplotype depth instead of taking a single mode
        self.d_hap, k_hap, self.copy_weights = fit_copy_mixture(pos, ploidy)
        self.depth = self.d_hap * ploidy
        self.k = float(min(1000.0, max(5.0, k_hap * ploidy)))   # NB size of all-haplotype depth (overdispersion)
        self.mean_span = float(self.spans.mean())

    def r(self, x):
        """Expected reads covering an interval of length x per unit depth: E[max(0, l - x) / l] over a
        coverage-weighted (length-biased) sample of read spans."""
        return float(np.mean(np.clip(self.spans - x, 0, None) / self.spans))

    def rates(self, site):
        """Informative-read rates per allele for one element (reads per unit per-haplotype depth)."""
        el = site.el
        l5, l3 = el.lltr[1] - el.lltr[0], el.rltr[1] - el.rltr[0]
        rF = self.r(l5 + 2 * A) + self.r(l3 + 2 * A) - self.r(site.L + 2 * A)
        rS = self.r(el.ltr_mean + 2 * A + site.t)
        rE = self.r(2 * A + site.t)
        return {"F": max(rF, 1e-9), "S": max(rS, 1e-9), "E": max(rE, 1e-9)}


def sample_points(chrom_lengths, n=N_DEPTH_POINTS, seed=SEED):
    """Random positions, uniform over the given sequences (dict name -> length)."""
    rng = random.Random(seed)
    names = list(chrom_lengths)
    tot = sum(chrom_lengths.values())
    pts = []
    for _ in range(n):
        u = rng.randrange(tot)
        for c in names:
            if u < chrom_lengths[c]:
                pts.append((c, u))
                break
            u -= chrom_lengths[c]
    return pts


def depth_and_spans(bam, points, min_mapq):
    """Depth (primary alignments, MAPQ >= min_mapq) at each point, and the reference spans of those alignments
    (a coverage-weighted sample of read spans)."""
    depths, spans = [], []
    for c, p in points:
        n = 0
        for x in bam.fetch(c, p, p + 1):
            if (x.is_unmapped or x.is_secondary or x.is_supplementary or x.is_duplicate or x.is_qcfail
                    or x.mapping_quality < min_mapq):          # the reads evidence() can use
                continue
            n += 1
            spans.append(x.reference_end - x.reference_start)
        depths.append(n)
    return depths, spans


def read_profile(bam, points, min_mapq, n_max=2000):
    """Share of reads with base qualities and median read divergence (NM / aligned bases) over primary alignments at
    the sampled points: decides whether read phasing is safe for the sample (see phase.py)."""
    seen, qual, div = set(), 0, []
    for c, p in points:
        for x in bam.fetch(c, p, p + 1):
            if (x.is_unmapped or x.is_secondary or x.is_supplementary or x.is_duplicate or x.is_qcfail
                    or x.mapping_quality < min_mapq
                    or x.query_name in seen):
                continue
            seen.add(x.query_name)
            qual += x.query_qualities is not None
            if x.has_tag("NM") and x.query_alignment_length:
                div.append(x.get_tag("NM") / x.query_alignment_length)
            if len(seen) >= n_max:
                break
        if len(seen) >= n_max:
            break
    if not seen:
        return 0.0, float("nan")
    return qual / len(seen), (float(np.median(div)) if div else float("nan"))


def genotypes(ploidy):
    return ["/".join(g) for g in combinations_with_replacement("FSEN", ploidy)]


def _nb_logpmf(x, mu, k):
    p = k / (k + mu)
    return (math.lgamma(x + k) - math.lgamma(k) - math.lgamma(x + 1) + k * math.log(p) + x * math.log1p(-p))


def loglik(counts, gt, rates, d_hap, eps, k):
    alle = gt.split("/")
    lam = {a: alle.count(a) * rates[a] for a in CLASSES}
    tot = sum(lam.values())
    T = sum(counts[c] for c in CLASSES)
    ll = _nb_logpmf(T, max(d_hap * tot, MU_MIN), k)
    if T:
        for c in CLASSES:
            if counts[c]:
                p = sum((lam[a] / tot) * ((1 - eps) if c == a else eps / 2) for a in CLASSES) if tot > 0 else 1 / 3
                ll += counts[c] * math.log(p)
    # read phasing: h distinct haplotypes seen carrying allele a need >= h copies of a (each missing copy = a
    # spurious haplotype group, probability PH_ERR)
    for a in CLASSES:
        short = counts.get("hap_" + a, 0) - alle.count(a)
        if short > 0:
            ll += short * math.log(PH_ERR)
    return ll


def allele_posteriors(lls):
    """Posterior probability that at least one haplotype carries F, E or S (sum over genotypes; lls are the
    log-posteriors returned by call(), so the sample's genotype prior is included)."""
    mx = max(lls.values())
    post = {g: math.exp(v - mx) for g, v in lls.items()}
    z = sum(post.values())
    return {a: sum(p for g, p in post.items() if a in g.split("/")) / z for a in CLASSES}


def pav_call(pa):
    """Presence/absence from allele posteriors: present (an F allele), solo, absent (empty site, no F), else uncertain."""
    if pa["F"] >= PAV_P:
        return "present"
    if pa["F"] <= 1 - PAV_P and pa["E"] >= PAV_P:
        return "absent"
    if pa["F"] <= 1 - PAV_P and pa["S"] >= PAV_P:
        return "solo"
    return "uncertain"


def genotype_prior(lls_list, gts, n_iter=20):
    """Empirical-Bayes genotype frequencies of one sample: EM over the per-site genotype log-likelihoods, with
    add-one (Dirichlet 1) smoothing. Returns {genotype: log prior}, or None (flat prior) with fewer than
    EB_MIN_PER_CLASS sites per genotype class, where the frequencies cannot be estimated. Near-ties then follow the
    genotypes common in this sample (e.g. F/N in an outcrosser, F/F in an inbred line) instead of a flat prior."""
    L = np.array([[ll[g] for g in gts] for ll in lls_list], float)
    if len(L) < EB_MIN_PER_CLASS * len(gts):
        return None
    L -= L.max(1, keepdims=True)
    P0 = np.exp(L)
    pi = np.full(len(gts), 1.0 / len(gts))
    for _ in range(n_iter):
        P = P0 * pi
        P /= P.sum(1, keepdims=True)
        pi = (P.sum(0) + 1.0) / (len(P) + len(gts))
    return {g: float(np.log(p)) for g, p in zip(gts, pi)}


def call(counts, rates, model, eps, logprior=None):
    """Return (best genotype, GQ, dict of log-posteriors up to a constant (log-likelihood + log prior; flat prior if
    logprior is None), expected informative reads under the best genotype).
    No informative read but reads placed here with low MAPQ: no call ('./.', GQ 0, flat likelihoods); the
    absence of evidence there reflects mappability, not the alleles."""
    gts = genotypes(model.ploidy)
    if sum(counts[c] for c in CLASSES) == 0 and counts.get("lowq", 0) > 0:
        return "/".join("." * model.ploidy), 0, {g: 0.0 for g in gts}, 0.0
    lls = {g: loglik(counts, g, rates, model.d_hap, eps, model.k) + (logprior[g] if logprior else 0.0)
           for g in gts}
    mx = max(lls.values())
    post = {g: math.exp(v - mx) for g, v in lls.items()}
    z = sum(post.values())
    best = max(post, key=post.get)
    pb = post[best] / z
    gq = GQ_CAP if pb >= 1 - 10 ** (-GQ_CAP / 10) else int(round(-10 * math.log10(1 - pb)))
    alle = best.split("/")
    mu = model.d_hap * sum(alle.count(a) * rates[a] for a in CLASSES)
    return best, min(gq, GQ_CAP), lls, mu


def site_calibration(records, model):
    """Per-haplotype depth and overdispersion of informative reads, learned from the sample's own sites whose full-
    allele dosage the reads fix without depth: sites called with an empty or solo allele beside >= 1 full allele (GQ
    >= 20, >= 2 empty/solo reads), where the full reads come from the called number of full haplotypes. Genome-wide
    depth misleads where much of the genome is on one haplotype only (outcrossers) or depth is very overdispersed
    (ONT). records: (counts, rates, genotype, gq). Returns (d_hap, k, n_sites) or None (< CAL_MIN_SITES sites)."""
    obs, base = [], []
    for counts, rates, gt, gq in records:
        al = gt.split("/")
        nf = al.count("F")
        if gq < 20 or nf == 0 or not ({"E", "S"} & set(al)) or counts["E"] + counts["S"] < 2:
            continue
        obs.append(counts["F"])
        base.append(nf * rates["F"])
    if len(obs) < CAL_MIN_SITES:
        return None
    obs, base = np.asarray(obs, float), np.asarray(base, float)
    d_hap = float(np.median(obs / base))
    mu = d_hap * base
    inv_k = float(np.mean(((obs - mu) ** 2 - mu) / mu ** 2))
    k = 1000.0 if inv_k <= 1e-3 else float(min(1000.0, max(5.0, 1 / inv_k)))
    return d_hap, k, len(obs)


def estimate_eps(records):
    """Misclassification rate from confident homozygous calls: discordant / total informative reads.
    records: iterable of (counts, genotype, gq)."""
    disc = tot = 0
    for counts, gt, gq in records:
        alle = set(gt.split("/")) - {"N"}
        if "." in alle:
            continue
        T = sum(counts[c] for c in CLASSES)
        if len(alle) != 1 or T < EPS_MIN_READS or gq < 20:
            continue
        (a,) = alle
        disc += T - counts[a]
        tot += T
    if tot == 0:
        return None
    return min(EPS_CAP, max(EPS_FLOOR, disc / tot))
