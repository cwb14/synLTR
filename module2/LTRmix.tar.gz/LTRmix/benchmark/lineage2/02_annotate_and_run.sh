#!/usr/bin/env bash
# Citrus generality test (sweet orange = pummelo x mandarin admixture).
# 1) inputs/<label>.fa with seqids <label>_chrN; 2) LTRquest 5042a1e, same flags as the maize runs, two parallel
# 3-genome runs (32 threads each); 3) ltrmix on all six libraries (every trio).
# Labels: CsA = Valencia DVS_A (mandarin-derived haplotype), CsB = DVS_B (pummelo-derived haplotype),
#         Cr = Sun Chu Sha Kat hap1 (mandarin), Cm = Guanximiyou (pummelo),
#         CaM / CaP = sour orange ZGSC mandarin / pummelo haplotype (F1: negative control).
set -u
P=/data2/chris/maize_introgression
L=$P/benchmark/lineage2
RAW=$P/inputs/raw
COMMIT=5042a1e
ev() { echo "$(date '+%F %T') $*" >> $L/events.log; }
declare -A ACC=([CsA]=GCA_022201045.1_DVS_A1.0 [CsB]=GCA_022201065.1_DVS_B1.0 [Cr]=GCA_059628685.1_ASM5962868v1
                [Cm]=GCA_047301065.1_ASM4730106v1 [CaM]=GCA_046470815.1_ASM4647081v1 [CaP]=GCA_046470805.1_ASM4647080v1)
for l in CsA CsB Cr Cm CaM CaP; do
  a=${ACC[$l]}
  [ -s $P/inputs/$l.fa ] && continue
  zcat $RAW/$a/${a}_genomic.fna.gz | awk -v p="$l" -v m="$L/seqids.$l.tsv" '
    /^>/ { acc = substr($1, 2); n = "";
           if (match($0, /chromosome [0-9]+/)) n = p "_chr" substr($0, RSTART + 11, RLENGTH - 11);
           else n = p "_scaf_" (++k);
           print acc "\t" n > m; print ">" n; next }
    { print }' > $P/inputs/$l.fa.tmp && mv $P/inputs/$l.fa.tmp $P/inputs/$l.fa
done
ev "INPUTS_READY"
PROT=$RAW/GCF_022201045.2_DVS_A1.0/GCF_022201045.2_DVS_A1.0_protein.faa.gz
set +u; source /home/chris/bin/etc/profile.d/conda.sh; conda activate "ltrquest_$COMMIT"; set -u
export LTRQUEST_TOOLS_DIR=$P/code/tools OMP_NUM_THREADS=8
run_lq() {   # $1 = run dir, rest = labels
  local d=$1; shift
  mkdir -p $d; cd $d || return 1
  local g=(); for l in "$@"; do g+=("$P/inputs/$l.fa"); done
  ev "LTRQUEST_START $d $*"
  /usr/bin/time -v -o ltrquest.time ltrquest --genome "${g[@]}" --proteins $PROT --threads 32 \
    --max-rounds 3 --detect-args "ltr-timeout=300" --run-sdust --no-plots --reboundary > ltrquest.log 2>&1
  local rc=$?; echo $rc > job.exit; ev "LTRQUEST_EXIT $d rc=$rc"
}
( run_lq $L/ltrquest_a CsA CsB Cr ) &
( run_lq $L/ltrquest_b Cm CaM CaP ) &
wait
[ "$(cat $L/ltrquest_a/job.exit)" = 0 ] && [ "$(cat $L/ltrquest_b/job.exit)" = 0 ] || { ev "ABORT ltrquest failed"; exit 1; }
conda activate ltrmix
export NUMPY_MADVISE_HUGEPAGE=0
cd $L
/usr/bin/time -v -o ltrmix.time python $P/LTRmix/ltrmix.py \
  --genome CsA=$L/ltrquest_a/CsA_LTRs --genome CsB=$L/ltrquest_a/CsB_LTRs --genome Cr=$L/ltrquest_a/Cr_LTRs \
  --genome Cm=$L/ltrquest_b/Cm_LTRs --genome CaM=$L/ltrquest_b/CaM_LTRs --genome CaP=$L/ltrquest_b/CaP_LTRs \
  --outdir out -t 32 -v > ltrmix.log 2>&1
ev "LTRMIX_EXIT rc=$?"
