"""Read intact LTR retrotransposons from GFF3 (LTRquest, EDTA, LTR_retriever, LTRharvest and DANTE_LTR conventions).

An element is a feature whose type ends in 'LTR_retrotransposon' (case-insensitive), or a DANTE_LTR
'transposable_element', with two 'long_terminal_repeat' features linked to it: as children (Parent = element ID) or,
as in EDTA/LTR_retriever, as children of the same 'repeat_region' parent that lie inside the element. Elements with
fewer than two LTRs (e.g. DANTE_LTR's domain-only partial elements) are skipped and counted.
Coordinates are kept 0-based half-open internally.
"""
import gzip
import re
from dataclasses import dataclass, field
from urllib.parse import unquote

from .constants import DEFAULT_TSD

COORD_LIKE = re.compile(r"^[^:]+:\d+[-.]+\d+")


@dataclass
class Element:
    id: str
    chrom: str
    start: int            # 0-based, first base of the 5'-most LTR
    end: int              # 0-based exclusive, after the last base of the 3'-most LTR
    strand: str
    lltr: tuple           # (start, end) of the left LTR (by position), 0-based half-open
    rltr: tuple           # (start, end) of the right LTR
    family: str = "."
    clade: str = "."
    tsd: str = ""         # TSD sequence if annotated or inferred
    n_inner: int = 0      # other elements contained in this one (nested insertions inside it)
    n_outer: int = 0      # elements that contain this one
    inner: list = field(default_factory=list)   # (start, end) of elements nested inside this one
    attrs: dict = field(default_factory=dict)

    @property
    def length(self):
        return self.end - self.start

    @property
    def ltr_mean(self):
        return ((self.lltr[1] - self.lltr[0]) + (self.rltr[1] - self.rltr[0])) / 2

    @property
    def internal(self):
        return (self.lltr[1], self.rltr[0])

    @property
    def tsd_len(self):
        return len(self.tsd) if self.tsd else DEFAULT_TSD


def _open(path):
    return gzip.open(path, "rt") if str(path).endswith(".gz") else open(path)


def _attrs(col9):
    d = {}
    for kv in col9.strip().strip(";").split(";"):
        if "=" in kv:
            k, v = kv.split("=", 1)
            d[k.strip()] = unquote(v.strip())
    return d


def read_gff3(path):
    """Return a list of Element sorted by (chrom, start). Elements without two LTRs are skipped (counted in .skipped)."""
    feats = []
    with _open(path) as fh:
        for line in fh:
            if line.startswith("##FASTA"):
                break
            if not line.strip() or line.startswith("#"):
                continue
            x = line.rstrip("\n").split("\t")
            if len(x) != 9:
                raise ValueError(f"{path}: malformed GFF3 line (need 9 columns): {line[:80]}")
            feats.append((x[0], x[2], int(x[3]) - 1, int(x[4]), x[6], _attrs(x[8])))
    by_id = {f[5]["ID"]: f for f in feats if "ID" in f[5]}
    ltrs_by_parent, tsd_by_parent = {}, {}
    for f in feats:
        t = f[1].lower()
        for p in f[5].get("Parent", "").split(","):
            if not p:
                continue
            if t == "long_terminal_repeat":
                ltrs_by_parent.setdefault(p, []).append(f)
            elif t == "target_site_duplication":
                tsd_by_parent.setdefault(p, []).append(f)
    out, skipped, seen = [], 0, set()
    for chrom, ftype, s, e, strand, a in feats:
        if not (ftype.lower().endswith("ltr_retrotransposon") or ftype.lower() == "transposable_element"):
            continue
        eid = a.get("ID") or f"{chrom}:{s + 1}-{e}"
        if eid in seen:   # IDs key the LTR lookup and every output: a repeated ID merges LTRs of different elements
            raise ValueError(f"{path}: element ID {eid} occurs more than once (concatenated GFF3 files?); "
                             "element IDs must be unique")
        seen.add(eid)
        cand = [g for g in ltrs_by_parent.get(eid, []) if g[0] == chrom]
        if len(cand) < 2:  # EDTA / LTR_retriever: LTRs are siblings under a repeat_region
            for p in a.get("Parent", "").split(","):
                cand += [g for g in ltrs_by_parent.get(p, []) if g[0] == chrom and g[2] >= s and g[3] <= e]
        cand = sorted({(g[2], g[3]) for g in cand})
        if len(cand) < 2:
            skipped += 1
            continue
        lltr, rltr = cand[0], cand[-1]
        fam = a.get("family") or a.get("Family") or ""
        if not fam:
            nm = a.get("Name", "")
            fam = nm if nm and not COORD_LIKE.match(nm) else "."
        clade = a.get("clade") or "."
        cls = a.get("classification") or a.get("Classification") or a.get("Final_Classification")
        if clade == "." and cls:
            clade = re.split(r"[/|]", cls)[-1]       # LTR/Copia/Ale (EDTA, LTRquest) or Class_I|LTR|Ty1/copia|Ale
        tsd = a.get("tsd", "") or a.get("TSD", "")
        if not re.fullmatch(r"[ACGTacgt]{3,8}", tsd or ""):
            tsd = ""
        out.append(Element(eid, chrom, min(s, lltr[0]), max(e, rltr[1]), strand if strand in "+-" else ".",
                           lltr, rltr, fam, clade, tsd.upper(), attrs=a))
    out.sort(key=lambda r: (r.chrom, r.start, -r.end))
    _nesting(out)
    read_gff3.skipped = skipped
    return out


def _nesting(els):
    """Count containment per chromosome (elements sorted by start, longest first)."""
    by_chrom = {}
    for e in els:
        by_chrom.setdefault(e.chrom, []).append(e)
    for lst in by_chrom.values():
        open_ = []  # stack of elements whose span may still contain later ones
        for e in lst:
            open_ = [o for o in open_ if o.end > e.start]
            for o in open_:
                if o.start <= e.start and e.end <= o.end and o is not e:
                    o.n_inner += 1
                    o.inner.append((e.start, e.end))
                    e.n_outer += 1
            open_.append(e)


def infer_tsd(fasta, el, kmax=6, kmin=4):
    """TSD from sequence: longest k in kmax..kmin with identical k-mers before start and after end."""
    if el.tsd:
        return el.tsd
    try:
        L = fasta.get_reference_length(el.chrom)
    except KeyError:
        return ""
    for k in range(kmax, kmin - 1, -1):
        if el.start - k < 0 or el.end + k > L:
            continue
        a = fasta.fetch(el.chrom, el.start - k, el.start).upper()
        b = fasta.fetch(el.chrom, el.end, el.end + k).upper()
        if a == b and "N" not in a:
            return a
    return ""
