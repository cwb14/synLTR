# ltrmix_plot — overview figure written by every LTRmix run

date: 2026-11-07
purpose: `LTRmix/ltrmix_plot.py` `overview(outdir, mu=None, verbose=False)` -> overview.png (300 dpi, figure only),
  overview.pdf (figure, short legend, long legend; text as text, fonttype 42) and overview_numbers.tsv (every legend
  number + source file), for one ltrmix trio output directory; CLI `python ltrmix_plot.py OUTDIR [--mu RATE] [-v]`
env: `source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix` (python 3.11.18, matplotlib 3.11.2,
  numpy 2.4.6, pandas 3.1.1); nothing installed
inputs (read-only, symlinked into test_*/ so outputs land here):
  benchmark/results/main3 (ltrmix run 13:50-14:20, B73v5 / TIL01 / TIL18; findings.txt + completeness_ratio present)
  benchmark/sim/out/f0.18_Ta5000_r1 (simulated B / P / M); truth used only for the example check below
  benchmark/results/dev/v_near (older output format, no decoy/ancestry/blocks: speed + missing-file test)
outputs here: ltrmix_plot.{png,pdf} + ltrmix_plot_numbers.tsv (main3), ltrmix_plot_sim.{png,pdf,_numbers.tsv},
  test_{main3,sim,devnear}/overview.*, test_ltrmix_plot.py (9 pytest tests, synthetic fixtures), build_renders.sh

```bash
bash /data2/chris/maize_introgression/benchmark/figures/ltrmix_plot/build_renders.sh      # rebuilds all renders
pytest -q /data2/chris/maize_introgression/benchmark/figures/ltrmix_plot/test_ltrmix_plot.py  # 9 passed
```
timing (server load ~180): main3 7.4 s wall / 6.0 s CPU, 250 MB; sim 3.8 s; dev 4.6 s (limit 60 s)

## Layout sketches (chosen: 1)
1. Horizontal chromosome rows (chosen)
```
key: ticks by class (n) | posterior, decoy mean | tracts (n), q<=0.05 (n), decoys (n)          B key
A  chr1  ~~~ ancestry posterior (window mean) ~~~ - - mean in S - -                       B |  o-  D k-mers
         ||| | shared with D, not S (light) / near-identical to D                           |  *-  D insertions
         [==tract==]  [=]   R chromosome                                                     |  (homologous D
         | || near-identical to S / shared with S, not D (light)                             |   chromosome; 0)
         [=]   [=]    S homolog, same bp scale, decoy tracts (same box height)               |
C  zoom on one typical tract: per element its divergence to the D and S ortholog (dumbbell; log %, '0' and
   'absent' slots, near-identity line), elements to size, recent + ancestry tracts, both posteriors
D  D(insertions) by LTR age    E identity spectrum R-D vs S-D (scaled)    F four genome-wide tests, null 0
```
2. Vertical ideograms as examples/fig1 (S | ribbons | R, ticks left/right): striking, but the trace and tracts
   read worse vertically and a per-chromosome test cannot align to the columns.
3. Circos of the three genomes with near-identical links: positions hard to read; rejected.
Why 1: positions read in Mb; the control (sister + decoys) sits under every recipient chromosome at the same bp
scale; the per-chromosome test aligns to the rows; the zoom shows the per-element evidence behind ticks and tracts.

## Example (panel C) rule and checks
rule: among tracts of the most confident tier present (q <= 0.05 from the ltrmix ':high' label, else q <= 0.2,
  else all), the tract with the median sum of posteriors; window = tract + one tract length each side, widened
  (10 kb or 1/4 tract steps) until >= 60 informative elements. Stated on the long legend.
why not the median of all tracts: in the simulation it fell on chr7 7.60 Mb, a tract with no true introgression
  (truth_B.bed) — a miss. Truth overlap by tier (sim): q<=0.05 25/25 true (mean 81% of length), q<=0.2 89%,
  low 60%. Chosen sim example chr10:9,798,633-10,054,370: 100% inside a true segment.
main3 example: chr2:195,266,582-199,235,371 (3.97 Mb, 228 elements, q = 0.048): inside 36/38 elements with both
  orthologs closer to TIL18; flanks 8/20. No truth; no bp check possible (outdir holds no sequences).

## Figure check (main3 render; sim the same)
1 Panel A, genome coordinates, every element drawn: YES — every informative element (31,395 in maize) as a tick at
  its position on each B73 chromosome; the 94,181 shared/private/near-both/unresolved are not drawn in A (stated)
  but every element of the zoom window is drawn to size in C.
2 Raw evidence for a typical, verified example: PARTLY — C shows each element's divergence to its TIL18 and TIL01
  ortholog and presence/absence for a rule-chosen tract; no base-pair alignment or TSD check (overview(outdir)
  reads only the run's tables; no sequences). Sim example verified against truth.
3 Control as full partner, same scale: YES — sister homolog under every chromosome, same bp scale, decoy tracts
  at the tracts' box height (A); decoy posterior mean (A); scaled mirror spectrum (E).
4 Every null drawn: YES — D = 0 in B, D, F; decoys + decoy mean in A; mirror in E.
5 On-figure text only letters/axes/ticks/labels/keys/n: YES.
6 Full-res crops clean, one grid, reading order, no empty bands: YES — crops of A (top, right, bottom), C (left,
  right), D-F and PDF page 1 at 200 dpi inspected; A, C, D share the left edge, B, C, F the right edge; letters
  assigned in reading order to the panels actually drawn. Smallest text 5-5.5 pt (posterior scale digits, sister
  labels); everything else >= 6 pt. White space right of short rows = chromosome lengths.
7 Different question per panel; legend rules: YES — A where, B which chromosomes, C what one call rests on, D how
  young, E how much near-identity excess (lower bound on f), F do the genome-wide tests agree. Short legend ~210
  words, long ~700; last line Analysis/Script/date; text recoverable with pdftotext (Liberation Sans, CID TT).

## Gotchas
- NUMPY_MADVISE_HUGEPAGE=0 must be set before numpy import (as in ltrmix.py): without it the PDF image writer
  stalled 205 s in memory compaction on this server (cProfile: backend_pdf.writeImages); now ~1 s.
- matplotlib's font cache in env ltrmix lacks Liberation Sans: registered from /usr/share/fonts at run time.
- tract 'q' is written to 3 significant digits: 15 sim tracts show q = 0.05 but are 'medium'; the ':high' label
  (unrounded q) is used, matching findings.txt (25 at FDR <= 0.05).
- TIL01 chromosomes are longer than B73's (chr2 337.6 vs 243.7 Mb; fai confirms): sister bars extend past
  their B73 partners; x-range follows the longest bar.
- TIL18_alt-scaf_20's best collinear partner is B73 chr3: panel B uses reciprocal-best, non-scaffold pairs only.
- 'mean tract 571 kb' in findings is the HMM's fitted mean length; the legend reports the called tracts' median.
- blocks.tsv is read from the trio directory or its parent (>= 4-genome runs write it at the top level).
- not done: base-pair panel (no sequences in the outdir); tests live here, not in LTRmix/tests (write scope).
