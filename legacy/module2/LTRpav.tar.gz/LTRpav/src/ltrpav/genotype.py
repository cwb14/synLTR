"""Pair genotyping: the calls table of one ordered genome pair (A, whose elements are called; B, the target).

`genotype_pair` runs anchor_pair -> make_windows -> per window: the A and B sequences (B reverse-complemented
on a minus-strand window), align_window (mappy with the preset for the pair's divergence; LASTZ, the default,
scores every pair as asm20), classify_window -> one row per element of A. The windows, in A fai order, are cut into chunks (`_chunk_size`: about CHUNK_TARGET per
pair, whatever the thread count), genotyped by forked worker processes (each opens both FASTAs itself: pysam
handles must not be shared across processes), or in this process with one thread. A chunk that fails, or a
worker that dies (killed, out of memory, crashed), stops the pair with an error naming it: pending chunks are
canceled, running ones finish first (minutes on a large chunk), finished ones stay done. A worker exits when
the parent dies, killing its running lastz child and removing its temp folder; the folders of workers killed
outright are swept at the next pair.

Outputs: gzip TSV with a header line, 1-based inclusive coordinates and reproducible bytes (gzip mtime 0, no
file name):
  <outdir>/pairs/<A>__<B>.calls.tsv.gz       CALL_COLUMNS, every element of A (all levels) exactly once,
                                              sorted by (A fai order, start, -end, level). An element in no
                                              window (its parent is not annotated) is U no_anchor, wid ".".
  <workdir>/windows/<A>__<B>.tsv.gz          WINDOW_COLUMNS, one row per window (wid order).
  <workdir>/calls/<A>__<B>/chunk_<n>.tsv.gz  the rows of chunk n (same columns and order as the pair file).
The pair file and each chunk have a done marker keyed by the anchors, both FASTAs, the elements, the backend,
its version and the preset (a chunk also by the windows and its wids), and by the fingerprint of the stage's
modules (checkpoint.STAGE_MODULES): a pair finished by other genotyping code or another aligner is recomputed.
A rerun skips a finished pair; an interrupted one recomputes only its unfinished chunks, then merges the
chunks again. The pair's marker also records the digest of A's elements and the code fingerprint
(`ltrpav-merge` checks both).

TSV values (`tsv_field`): None and nan -> "."; bool -> 1/0; float -> 6 significant digits; int, str as is.
"""
from __future__ import annotations

import contextlib
import ctypes
import gzip
import heapq
import io
import logging
import math
import multiprocessing
import os
import signal
import sys
import threading
import time
from collections import Counter
from collections.abc import Callable, Iterable, Iterator
from concurrent.futures import Future, ProcessPoolExecutor, as_completed
from concurrent.futures.process import BrokenProcessPool
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .anchor import PairContext, Route, anchor_pair, anchors_path
from .checkpoint import (
    CHECKSUM_CACHE,
    atomic_path,
    clear_done,
    file_checksum,
    is_done,
    mark_done,
    marker,
    stage_fingerprint,
    stage_key,
)
from .classify import CALL_COLUMNS, STATES, call_row, classify_window
from .constants import CHUNK_MIN, CHUNK_TARGET, CHUNK_WINDOWS, DEFAULT_BACKEND, U_WARN
from .elements import Element, elements_digest
from .localign import (
    align_window,
    backend_version,
    kill_lastz,
    pid_alive,
    preset_for_divergence,
    sweep_lastz_tmp,
)
from .seqio import Fasta, revcomp
from .window import Window, make_windows

log = logging.getLogger("ltrpav.genotype")

WINDOW_COLUMNS = ("wid", "a_seqid", "a_start", "a_end", "b_seqid", "b_start", "b_end", "strand", "status",
                  "left_anchor", "right_anchor", "margin", "eids")
_GZ_LEVEL = 6  # zlib's default level: near level 9's size in a fraction of its time


def genotype_pair(ctx: PairContext, route: Route, backend: str = DEFAULT_BACKEND) -> Path:
    """Call every element of A in B; returns the calls table <outdir>/pairs/<A>__<B>.calls.tsv.gz.

    `route` anchors the pair (anchor_pair); `backend` aligns each window (align_window; DEFAULT_BACKEND,
    lastz, unless another registered backend is named).
    """
    t0 = time.perf_counter()
    pair, label = f"{ctx.a.label}__{ctx.b.label}", f"{ctx.a.label} vs {ctx.b.label}"
    out = Path(ctx.outdir) / "pairs" / f"{pair}.calls.tsv.gz"
    order = {s: i for i, s in enumerate(ctx.a_fa.lengths())}  # A fai order
    elements, children = _index(ctx.a_elements, order)  # fails fast, before the anchoring
    blocks, a_names, b_names, d = anchor_pair(ctx, route)
    preset = preset_for_divergence(d)
    sums = ctx.workdir / CHECKSUM_CACHE
    # the anchors alone miss what they do not hold: element fields (a route may not read elements at all)
    # and sequence outside the blocks
    a_digest = elements_digest(ctx.a_elements)
    inputs = {"anchors": file_checksum(anchors_path(ctx, route), sums), "A": file_checksum(ctx.a_fa.path, sums),
              "B": file_checksum(ctx.b_fa.path, sums), "elements": a_digest}
    params = {"pair": pair, "backend": backend, "aligner": backend_version(backend), "preset": preset}
    key = stage_key("genotype_pair", inputs, {**params, "route": route.name})
    if is_done(marker(out), key):
        log.info("%s: calls done, skip (%s)", label, out)
        return out
    clear_done(marker(out))

    windows = make_windows(ctx.a_elements, blocks, a_names, b_names, ctx.b_fa.lengths(), ctx.a_fa.lengths())
    wpath = ctx.workdir / "windows" / f"{pair}.tsv.gz"
    for path in (out, wpath):
        _sweep_tmp(path)
    _write_tsv(wpath, WINDOW_COLUMNS, map(_window_line, windows))
    chunk_inputs = {**inputs, "windows": file_checksum(wpath, sums)}
    chunks, jobs, size = [], [], _chunk_size(len(windows))
    for n, i in enumerate(range(0, len(windows), size)):
        part = windows[i:i + size]
        path = ctx.workdir / "calls" / pair / f"chunk_{n}.tsv.gz"
        ckey = stage_key("genotype_chunk", chunk_inputs,
                         {**params, "chunk": n, "wids": [part[0].wid, part[-1].wid]})
        chunks.append(path)
        if not is_done(marker(path), ckey):
            clear_done(marker(path))
            jobs.append(_Job(n, part, path, ckey))
    cdir = ctx.workdir / "calls" / pair
    for extra in cdir.glob("chunk_*.tsv.gz*") if cdir.is_dir() else ():  # chunks of an earlier, longer run
        n = extra.name.split(".", 1)[0].removeprefix("chunk_")
        if n.isdigit() and int(n) >= len(chunks):
            extra.unlink(missing_ok=True)
    if jobs:
        for tmp in cdir.glob(".chunk_*.tmp") if cdir.is_dir() else ():  # left by a worker killed mid-write
            tmp.unlink(missing_ok=True)
        # the most work first (LPT): a large chunk submitted last becomes the pair's straggler
        jobs.sort(key=lambda j: -sum(w.a_end - w.a_start + w.b_end - w.b_start for w in j.windows
                                     if w.status == "ok"))
        _run(ctx, jobs, elements, children, preset, backend, label)

    alone = sorted(map(_no_window_line, _in_no_window(windows, elements, children)), key=_sort_key(order))
    states = _merge(chunks, alone, out, elements, order, label)
    mark_done(marker(out), key, [out],
              meta={"elements": a_digest, "code": stage_fingerprint("genotype_pair")})

    total = sum(states.values())
    summary = ", ".join(f"{states[s]} {s}" for s in STATES if states[s]) or "none"
    log.info("%s: %d windows (%d anchored), %d chunk(s) (%d computed), %d calls (%s) -> %s, %.1f s", label,
             len(windows), sum(w.status == "ok" for w in windows), len(chunks), len(jobs), total, summary, out,
             time.perf_counter() - t0)
    if total and states["U"] > U_WARN * total:
        log.warning("%s: %d of %d calls are U: no orthologous alignment between %s and %s?", label,
                    states["U"], total, ctx.a.label, ctx.b.label)
    return out


def _chunk_size(n_windows: int) -> int:
    """Windows per chunk: max(CHUNK_MIN, min(CHUNK_WINDOWS, ceil(n_windows / CHUNK_TARGET))).

    About CHUNK_TARGET chunks per pair balance the workers; the size never depends on the thread count, so a
    resumed run finds its chunks (keyed by index and wids) at any --threads. The calls do not depend on it.
    """
    return max(CHUNK_MIN, min(CHUNK_WINDOWS, -(-n_windows // CHUNK_TARGET)))


def tsv_field(v) -> str:
    """A TSV value: None and nan -> "."; bool -> "1"/"0"; float -> 6 significant digits; int, str as is."""
    if v is None:
        return "."
    if isinstance(v, (bool, np.bool_)):
        return "1" if v else "0"
    if isinstance(v, (int, np.integer)):
        return str(int(v))
    if isinstance(v, (float, np.floating)):
        return "." if math.isnan(v) else format(float(v), ".6g")
    return str(v)


# ---------------------------------------------------------------- workers


@dataclass
class _Job:
    """Chunk n: its windows, its output and its stage key."""

    n: int
    windows: list[Window]
    path: Path
    key: str


class _Genotyper:
    """Genotypes chunks in one process: both FASTAs open, the elements, children map, preset and backend."""

    def __init__(self, a_fa: Fasta, b_fa: Fasta, elements: dict[str, Element],
                 children: dict[str, list[str]], preset: str, backend: str):
        self.a_fa, self.b_fa = a_fa, b_fa
        self.elements, self.children = elements, children
        self.preset, self.backend = preset, backend
        self.sort_key = _sort_key({s: i for i, s in enumerate(a_fa.lengths())})

    def rows(self, win: Window) -> list[dict]:
        """The calls of the window's elements as CALL_COLUMNS rows; sequences only for an ok window."""
        a_seq = b_seq = ""
        aln = None
        if win.status == "ok":
            a_seq = self.a_fa.fetch(win.a_seqid, win.a_start, win.a_end)
            b_seq = self.b_fa.fetch(win.b_seqid, win.b_start, win.b_end)
            if win.strand == -1:
                b_seq = revcomp(b_seq)  # into A's orientation
            aln = align_window(a_seq, b_seq, self.preset, self.backend)
        calls = classify_window(win, aln, a_seq, b_seq, self.elements, self.children)
        return [call_row(c, self.elements[c.eid], win) for c in calls]

    def chunk(self, job: _Job) -> tuple[int, int]:
        """Write the job's rows, sorted, to its chunk file and mark it done; returns (n, rows)."""
        lines = sorted((_line(r[c] for c in CALL_COLUMNS) for w in job.windows for r in self.rows(w)),
                       key=self.sort_key)
        _write_tsv(job.path, CALL_COLUMNS, lines)
        mark_done(marker(job.path), job.key, [job.path])
        return job.n, len(lines)


_WORKER: _Genotyper | None = None  # a pool worker's genotyper (set by _init_worker)
_WORKER_ERROR: Exception | None = None  # why _init_worker could not open a FASTA: raised by every task
_PR_SET_PDEATHSIG = 1  # <linux/prctl.h>: the signal a process gets when its parent dies


def _init_worker(parent: int, a_path: Path, a_cache: Path | None, b_path: Path, b_cache: Path | None,
                 elements: dict[str, Element], children: dict[str, list[str]], preset: str, backend: str) -> None:
    """Pool initializer: this process first ties its life to the parent's (pid `parent`, _die_with_parent),
    then opens both FASTAs; elements and children come through the fork.

    A FASTA that cannot be opened (OSError, ValueError, RuntimeError: what Fasta and pysam raise) is kept and
    raised by the worker's tasks, so the parent reports its cause; anything else raises here and shows as a
    broken pool."""
    global _WORKER, _WORKER_ERROR
    _die_with_parent(parent)
    try:
        _WORKER = _Genotyper(Fasta(a_path, a_cache), Fasta(b_path, b_cache), elements, children, preset, backend)
    except (OSError, ValueError, RuntimeError) as exc:
        _WORKER_ERROR = exc


def _pool_chunk(job: _Job) -> tuple[int, int]:
    if _WORKER_ERROR is not None:
        raise _WORKER_ERROR
    return _WORKER.chunk(job)


def _die_with_parent(parent: int) -> None:
    """Make this worker exit when the parent dies (SIGKILL, the OOM killer). An orphaned worker would wait on
    the call queue forever (it holds a write end of the queue's pipe, so it never reads EOF), keeping its memory.

    SIGTERM runs _on_sigterm (whatever handler the parent had): it kills the worker's running lastz child,
    removes its temp folder and exits. On Linux the kernel sends SIGTERM when the parent dies (prctl
    PR_SET_PDEATHSIG; the forking thread's exit counts as the parent's, so genotype_pair runs from the main or
    a long-lived thread), elsewhere a daemon thread polls the parent pid once a second. A parent that died
    before this ran (the worker is already reparented) means exit now. The pool's own terminate is a SIGTERM
    too.
    """
    signal.signal(signal.SIGTERM, _on_sigterm)
    if not _pdeathsig():
        threading.Thread(target=_watch_parent, args=(parent,), name="watch-parent", daemon=True).start()
    if os.getppid() != parent:
        os._exit(1)


def _on_sigterm(signum: int, frame) -> None:
    """A worker's SIGTERM: kill its lastz child and remove its temp folder (kill_lastz), then exit at once."""
    kill_lastz()
    os._exit(128 + signal.SIGTERM)


def _pdeathsig() -> bool:
    """Ask the kernel for SIGTERM when this process's parent dies (Linux prctl); False where it cannot."""
    if not sys.platform.startswith("linux"):
        return False
    try:
        prctl = ctypes.CDLL(None, use_errno=True).prctl
    except (OSError, AttributeError):
        return False
    zero = ctypes.c_ulong(0)
    return prctl(ctypes.c_int(_PR_SET_PDEATHSIG), ctypes.c_ulong(signal.SIGTERM), zero, zero, zero) == 0


def _watch_parent(parent: int) -> None:
    """Exit this process, after kill_lastz, once its parent is no longer `parent` (checked once a second)."""
    while os.getppid() == parent:
        time.sleep(1)
    kill_lastz()
    os._exit(1)


def _run(ctx: PairContext, jobs: list[_Job], elements: dict[str, Element], children: dict[str, list[str]],
         preset: str, backend: str, label: str) -> None:
    """Genotype the jobs' chunks: in this process with one thread, else in forked worker processes.

    A chunk is marked done only by the worker that finished it. A failing chunk, or a worker that dies (a
    broken pool: killed by a signal or the OOM killer, crashed, or never started), raises a RuntimeError
    naming the pair (and the chunk when known); pending chunks are canceled, running ones finish first.
    """
    threads = max(1, ctx.threads)
    if backend == "lastz" and (n := sweep_lastz_tmp()):
        log.info("%s: removed %d LASTZ temp folder(s) left by killed workers", label, n)
    if threads == 1:
        g = _Genotyper(ctx.a_fa, ctx.b_fa, elements, children, preset, backend)
        for job in jobs:
            try:
                n, rows = g.chunk(job)
            except Exception as exc:
                raise RuntimeError(f"{label}: chunk {job.n} failed: {type(exc).__name__}: {exc}") from exc
            log.debug("chunk %d: %d calls", n, rows)
        return
    init = (os.getpid(), ctx.a_fa.path, ctx.a_fa.cache_dir, ctx.b_fa.path, ctx.b_fa.cache_dir, elements, children,
            preset, backend)
    pool = ProcessPoolExecutor(min(threads, len(jobs)), mp_context=multiprocessing.get_context("fork"),
                               initializer=_init_worker, initargs=init)
    try:
        futures = {pool.submit(_pool_chunk, job): job for job in jobs}
        for fut in as_completed(futures):
            job = futures[fut]
            try:
                n, rows = fut.result()
            except BrokenProcessPool as exc:
                left = ", ".join(str(j.n) for f, j in futures.items() if not _finished(f))
                raise RuntimeError(f"{label}: a worker process died or could not start (killed by a signal or "
                                   f"out of memory, or crashed); chunk(s) {left} unfinished") from exc
            except Exception as exc:
                raise RuntimeError(f"{label}: chunk {job.n} failed: {type(exc).__name__}: {exc}") from exc
            log.debug("chunk %d: %d calls", n, rows)
    finally:
        pool.shutdown(wait=True, cancel_futures=True)
        if backend == "lastz":
            sweep_lastz_tmp()  # the folders of workers that died in this pool


def _finished(fut: Future) -> bool:
    """True if `fut` completed without an error."""
    return fut.done() and not fut.cancelled() and fut.exception() is None


# ---------------------------------------------------------------- elements, rows and files


def _index(elements: list[Element], order: dict[str, int]) -> tuple[dict[str, Element], dict[str, list[str]]]:
    """eid -> element, and eid -> its children's eids in A order (`order`: seqid -> fai index; start, -end).

    Fails on a duplicate eid or a seqid absent from A: each element gets exactly one row.
    """
    by: dict[str, Element] = {}
    for e in elements:
        if e.seqid not in order:
            raise ValueError(f"element {e.eid}: seqid {e.seqid!r} is not in the A FASTA")
        if e.eid in by:
            raise ValueError(f"duplicate element id {e.eid}")
        by[e.eid] = e
    children: dict[str, list[str]] = {}
    for e in sorted(elements, key=lambda e: (order[e.seqid], e.start, -e.end)):
        if e.parent is not None and e.parent in by:
            children.setdefault(e.parent, []).append(e.eid)
    return by, children


def _in_no_window(windows: list[Window], elements: dict[str, Element],
                  children: dict[str, list[str]]) -> list[Element]:
    """The elements no window reaches: neither top-level nor below an annotated ancestor."""
    seen: set[str] = set()
    todo = [eid for w in windows for eid in w.eids]
    while todo:
        eid = todo.pop()
        if eid not in seen:
            seen.add(eid)
            todo.extend(children.get(eid, ()))
    return [e for eid, e in elements.items() if eid not in seen]


def _no_window_line(e: Element) -> str:
    """U no_anchor for an element in no window: the call of an unresolved window holding only it, wid "."."""
    win = Window(-1, e.seqid, e.start - 1, e.end, None, 0, 0, 0, [e.eid], "no_anchor", 0, 0, math.nan)
    [call] = classify_window(win, None, "", "", {e.eid: e}, {})
    row = call_row(call, e, win)
    row["wid"] = None
    return _line(row[c] for c in CALL_COLUMNS)


def _window_line(w: Window) -> str:
    """The window as a WINDOW_COLUMNS line: 1-based inclusive (the anchors: the last anchored A base on the left,
    the first on the right); B fields and anchors "." without a B locus."""
    b = w.b_seqid is not None
    return _line((w.wid, w.a_seqid, w.a_start + 1, w.a_end, w.b_seqid, w.b_start + 1 if b else None,
                  w.b_end if b else None, {1: "+", -1: "-"}.get(w.strand), w.status,
                  w.left_anchor + 1 if b else None, w.right_anchor + 1 if b else None, w.margin, ",".join(w.eids)))


def _line(values: Iterable) -> str:
    return "\t".join(map(tsv_field, values)) + "\n"


_SEQID, _START, _END, _LEVEL, _STATE_COL = map(CALL_COLUMNS.index, ("a_seqid", "a_start", "a_end", "level",
                                                                   "state"))
_SPLIT = max(_SEQID, _START, _END, _LEVEL, _STATE_COL) + 1  # a calls line is split only this far


def _sort_key(order: dict[str, int]) -> Callable[[str], tuple[int, int, int, int]]:
    """Key of a calls line: (A fai order, a_start, -a_end, level)."""
    def key(line: str) -> tuple[int, int, int, int]:
        f = line.split("\t", _SPLIT)
        return order[f[_SEQID]], int(f[_START]), -int(f[_END]), int(f[_LEVEL])
    return key


def _merge(chunks: list[Path], alone: list[str], out: Path, elements: dict[str, Element],
           order: dict[str, int], label: str) -> Counter:
    """Merge the sorted chunk files and the no-window lines into `out`; returns the count of each state.

    Every element must appear exactly once, or nothing is written and the chunks' markers are cleared (a
    rerun recomputes them).
    """
    seen: Counter = Counter()
    states: Counter = Counter()
    with _gz_writer(out) as fh:
        fh.write(_line(CALL_COLUMNS))
        for line in heapq.merge(*map(_chunk_lines, chunks), alone, key=_sort_key(order)):
            f = line.split("\t", _SPLIT)
            seen[f[0]] += 1
            states[f[_STATE_COL]] += 1
            fh.write(line)
        bad = {"element(s) missing from the calls": [x for x in elements if x not in seen],
               "element(s) called more than once": [x for x, n in seen.items() if n > 1],
               "call(s) of no annotated element": [x for x in seen if x not in elements]}
        problems = [f"{len(v)} {what}: {', '.join(v[:5])}{' ...' if len(v) > 5 else ''}"
                    for what, v in bad.items() if v]
        if problems:
            for path in chunks:
                clear_done(marker(path))
            raise RuntimeError(f"{label}: {'; '.join(problems)}; chunks cleared, they are recomputed on rerun")
    return states


def _chunk_lines(path: Path) -> Iterator[str]:
    """The data lines of a chunk file (its header checked)."""
    with gzip.open(path, "rt", encoding="utf-8", newline="") as fh:
        if fh.readline() != _line(CALL_COLUMNS):
            raise ValueError(f"{path}: the header is not CALL_COLUMNS")
        yield from fh


def _sweep_tmp(path: Path) -> None:
    """Remove the temp files of `path` (checkpoint.atomic_path's .<name>.<pid>.<thread>.tmp) whose writer no
    longer runs: left by a run killed mid-write."""
    for tmp in path.parent.glob(f".{path.name}.*.tmp") if path.parent.is_dir() else ():
        pid = tmp.name[len(path.name) + 2:-len(".tmp")].split(".")[0]
        if pid.isdigit() and not pid_alive(int(pid)):
            tmp.unlink(missing_ok=True)


def _write_tsv(path: Path, columns: tuple[str, ...], lines: Iterable[str]) -> None:
    with _gz_writer(path) as fh:
        fh.write(_line(columns))
        fh.writelines(lines)


@contextlib.contextmanager
def _gz_writer(path: Path) -> Iterator[io.TextIOWrapper]:
    """Text handle on a new gzip file `path` with mtime 0 and no file name (same text, same bytes), written
    to a temp file renamed into place on success: a reader never sees a partial file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as tmp, open(tmp, "wb") as raw, \
            gzip.GzipFile(filename="", mode="wb", compresslevel=_GZ_LEVEL, fileobj=raw, mtime=0) as gz, \
            io.TextIOWrapper(gz, encoding="utf-8", newline="") as fh:
        yield fh
