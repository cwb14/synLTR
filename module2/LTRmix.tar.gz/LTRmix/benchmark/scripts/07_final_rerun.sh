#!/usr/bin/env bash
# Final reruns with the frozen ltrmix.py: all simulations (3- and 4-genome) and the real B73/TIL18/TIL01 trio.
set -u
B=/data2/chris/maize_introgression/benchmark
source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix
while pgrep -f "^bash ./rescore_m2.sh" > /dev/null; do sleep 30; done
cd $B/sim && ./rescore.sh > rescore_final.log 2>&1 && ./rescore_m2.sh
python $B/scripts/sim_summary.py $B/sim > $B/sim/sim_summary.txt 2>&1
cd $B/results && rm -rf main3 && ./run_main3.sh > main3.log 2>&1
python $B/scripts/eval_real.py main3 --nperm 1000 > main3/benchmark_real.stdout 2>&1
echo "$(date '+%F %T') FINAL_RERUN_DONE" >> $B/logs/final_rerun.log
