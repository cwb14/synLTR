# Task 24F report: syntenic anchor net and adaptive chunking

Status: DONE_WITH_CONCERNS. Commit `8dfc012` on `plan1-engine` (parent `bfeeb55`), subject "Make the anchor net
syntenic and chunk windows adaptively", existing identity (cwb14), no trailers, not pushed.

Gate: I drafted and tested everything in `D/task24f_scratch/repo/` (a `git archive` of bfeeb55) while the gate
was closed. Both `batch.exit` files existed at 07:14 (sims batch exit 0 at 07:09; chr10 batch stopped by the
controller at 06:36), and `pgrep` showed no batch process. The repo was clean at bfeeb55 when I copied the eight
files in. `D = /data2/chris/maize_introgression/benchmark_pav/bakeoff`.

## What changed, file by file

- `src/ltrpav/chain.py`
  - The module docstring now describes the syntenic net.
  - `net_blocks`:
    - The docstring documents the rule, its rationale, the named costs, the log line and the complexity.
    - New input check: a chain must lie on one A sequence, one B sequence and one strand. The synteny index
      assumes this, and `chain_blocks` output always satisfies it.
    - It builds a `_KeptChains` index and a tally, and logs through `_log_net`.
  - `_net_chain`: credit and trimming are unchanged. After the existing MIN_CHAIN_SCORE check, each trimmed
    piece gets its place in A's and B's frames, chain-level top support is applied, and unsupported pieces are
    dropped. The MIN_CHAIN_SCORE check then runs again on what is left, and only the kept pieces claim.
  - New helpers:
    - `_kind`: the INFO class of a kept piece.
    - `_log_net`: the INFO line, plus a DEBUG line with chains tested, kept, cut and lost, and the (A place,
      B place) cross-tab.
    - `_KeptChains`: per-sequence extent indexes in both frames, plus each kept chain's pieces in A order and
      in B order.
    - `_place`: the parent and gap test in one frame.
    - `_Extents`: 64-kb buckets of kept chain extents, with the innermost-containing query.
  - `_credit`, `_trim`, `_Claims` and the chain order are untouched.
- `src/ltrpav/anchor/__init__.py`: `_CHAIN_PARAMS` gains `"net": "syntenic"`; the comment and the docstrings
  are updated.
- `src/ltrpav/genotype.py`: `_chunk_size(n)` = max(CHUNK_MIN, min(CHUNK_WINDOWS, ceil(n / CHUNK_TARGET))) is
  used in `genotype_pair`'s chunk loop. The module docstring is updated. This is the only place in the package
  that chunks windows (checked with grep).
- `src/ltrpav/constants.py`:
  - CHUNK_MIN = 8 and CHUNK_TARGET = 256 are new, each with a one-line reason.
  - CHUNK_WINDOWS's comment now calls it the cap.
  - MAPPY_BEST_N stays 5. Its comment now says that minimap2's generic default -N is 5, that its asm presets
    use -N 50, and that the bake-off's mm2_N50 variant tests the choice.
- `docs/DESIGN.md`:
  - 5.1: the "1:1 orthologous chain set" sentence is replaced by the syntenic net. It gives one sentence for the
    rule, the citations (Kent et al. 2003 PNAS 100:11484 with netSyntenic/`netFilter -syn`; Song et al. 2022
    PNAS 119:e2113075119, AnchorWave; Goel et al. 2019 Genome Biol 20:277, SyRI), "no parameter", and both
    named costs.
  - 5.3: "mappy with long join" now reads "each strand mapped apart and without long join".
  - 5.4: `boundary_offset (bp)` is removed from the flag list. A new sentence says the junction overhangs are
    the evidence columns `dl`/`dr`, not flags.
- `tests/test_chain.py`: new fixtures and a plain re-implementation of the rule (below), plus 16 new tests. One
  existing assertion is changed.
- `tests/test_genotype.py`: 8 new tests. Existing chunk patches and assertions are adapted.
- `tests/test_routes.py`: one new test, the old-checkpoint recompute.

## The rule as implemented

Chains are visited by decreasing chain_score, as before. Each block is credited (`_credit`) and trimmed
(`_trim`) exactly as before. If the trimmed pieces carry fewer than MIN_CHAIN_SCORE matches, the chain is dropped
as before, without being tested (the outcome is the same). Otherwise each trimmed piece x is placed in each frame
against the chains already kept:

- **Parent.** The A-parent is the kept chain with the smallest A extent containing x's A span on x's A sequence;
  ties go to the earlier, better chain. An extent runs from the first kept piece's start to the last kept
  piece's end. The B-parent is defined the same way on B.
- **Place in a frame.**
  - top: there is no parent.
  - syn or inv: x's span in the other genome lies on the parent's sequence there, inside the gap between the
    parent's two kept pieces that flank x in this frame (+ strand: [L.end, R.start); - strand: [R.end,
    L.start)). It is syn on the parent's strand and inv on the other.
  - out: anything else.
- **Chain-level support.** If any trimmed piece of x's chain is top in a frame, every out piece of the chain is
  supported in that frame. These pieces are counted as "chain".
- **Keep** x only if it is supported in both frames. A dropped piece claims nothing. Its credit was already
  recorded during trimming, so it stands. If the kept pieces still carry >= MIN_CHAIN_SCORE matches, they claim
  and the chain is filed in the index; otherwise the chain is dropped.
- **Exactness.** A trimmed piece overlaps no kept piece on A or B. So for every kept extent and gap, it lies
  wholly inside or wholly outside: no slop and no new parameter.

**Complexity.**
- Per frame and sequence, `_Extents` files each kept extent in every 64-kb bucket it touches (the same
  `_BUCKET_BITS` as `_Claims`).
- An extent that contains x contains x's start. So finding the parent scans one bucket and checks containment,
  and bisecting the parent's starts finds the two flanking pieces.
- That gives O(b + log k) per piece, where b is the number of kept extents touching the bucket (the nesting depth
  plus the chains with pieces in those 64 kb) and k is the parent's piece count.
- Filing a kept chain costs O(k log k + extent / 64 kb).
- No lookup scans all kept chains. A brute-force scan is used only as the test oracle.

**Measured times** (net only, at most 8 threads, loaded shared machine):
- chr10 mm2 directions: 0.27-0.33 s, against 0.26-0.35 s for the flat net.
- FastGA chr10, the largest cached input (1,044,266 raw blocks, 759,317 chains): 16.6 s, against 15.8 s.
- Synthetic, 400k blocks over 10,000 sequence pairs (283k kept pieces, 17k kept chains): 6.6 s, against 5.5 s.
- Synthetic, 1M blocks: 17.4 s, against 14.8 s.

**INFO line** (one per net):
`syntenic net: kept N pieces (T top in both genomes, S syn, I inv, C chain-supported); dropped D out of place, X bp of A in total`.
- Each kept piece is counted once, in this order of precedence: chain-supported, then inv, then syn, then top in
  both frames.
- X sums the dropped pieces' A lengths. A position freed by a drop can be tried, and dropped, again by later
  chains, so X can exceed a sequence's length. The docstring says so.

## Tests

The full suite passes under `-W error`: **726 passed** (701 before; 25 new). It ran from the repo root with the
editable install and the slow test included, in 79 s. `ruff check .` is clean. The env's `bin` must be on PATH:
without it, `test_fail_fast_on_missing_binary[flank-blast-makeblastdb]` fails at bfeeb55 too, because blastn is
missing.

**New tests in `tests/test_chain.py`:**
- **Brief's cases:**
  - `drops_paralog_fill_out_of_place_in_both_genomes` (both strands).
  - `keeps_fill_in_its_parents_gap`: syn on the same strand and off-diagonal, and an inverted fill.
  - `keeps_chain_top_level_in_both_genomes`.
  - `keeps_crept_in_inversion_by_chain_support`: a 2-Mb inversion whose better right-hand chain creeps in with
    a 5-kb forward piece. All 21 inversion pieces are kept, 4 of them chain-supported, one frame each.
  - `drops_leak_into_uncovered_b`: B past every chain, and an unplaced B scaffold (the second named cost).
  - `drops_short_transposition` (the first named cost).
  - `dropped_piece_still_lowers_margin`: margins 1 - 9000/149000, 1, 1 - 9000/149000.
  - `net_without_drops_equals_the_flat_net`: 400 competing single-block chains; output identical to the flat
    net, margins included; 0 dropped.
  - `net_50k_blocks_in_seconds`: 60k blocks, more than 5,000 kept chains, net under 5 s; about 1.1 s measured.
  - The old-cache recompute test, in `tests/test_routes.py` (below).
- **Beyond the brief:**
  - `net_matches_the_rule_written_plainly`: on 4 genome-like and 3 random fixtures, the output is byte-identical
    to a plain re-implementation that scans every kept chain (`_reference_net`/`_brute_place`). The fixtures
    produce top, syn, inv, chain and dropped places.
  - `drops_chain_top_level_in_a_only`: the B-frame mirror of the leak.
  - `rejects_mixed_chain`.
  - `logs_one_info_line`.
- **Mutation check.** I ran the new chain tests against four mutant nets (in `D/task24f_scratch/mut/`):
  - HEAD's flat net fails 15 tests. Some fail only because it logs no INFO line; the paralog, leak, A-only,
    transposition, credit and oracle tests fail on behavior.
  - The prototype's first version (B-frame top escape) fails both leak cases, the A-only case and the oracle.
  - An A-frame-only rule fails the A-only case, the oracle and the log test.
  - A rule without chain-level support fails the crept-in inversion, the oracle and the random test.

**`tests/test_genotype.py`:**
- `test_chunk_size` for n = 0, 1, 100, 5,600, 60,000 and 10^6 gives 8, 8, 8, 22, 235 and 2000.
- `test_calls_do_not_depend_on_threads_or_chunks`: the toy pair at 1 thread and at 3 threads (3 chunks), then
  with chunks of 1 window and of all 20. All are byte-identical to the 2-thread base.
- `test_resume_at_another_thread_count_reuses_chunks`: a 3-thread run is interrupted before the merge and resumed
  at 1 thread. The chunks are reused (mtime unchanged) and the calls are identical.

**`tests/test_routes.py`:** `test_anchors_from_the_flat_net_are_recomputed`. It writes a checkpoint under the
old key (`_CHAIN_PARAMS` without "net"). The next call recomputes it, and the call after that reuses the new
checkpoint.

**Existing tests changed, with reasons:**
- `test_net_is_one_to_one_on_random_blocks`: it asserted more than 10 kept chains, more than 20 trimmed pieces
  and some margin of 1. Those were the random paralogs being kept: this fixture's paralogs land anywhere, so they
  are fills out of place in both genomes, and the syntenic net keeps 3-4 chains.
  - The assertion is now 3 or more chains, 3 or more trimmed pieces, and some margin below 1.
  - The invariants moved into `_check_net`, which the new tests also run.
  - Competition among many kept chains (more than 10 chains, more than 20 trimmed pieces) moved to
    `test_net_without_drops_equals_the_flat_net`.
- `test_pair_file_has_each_element_once_and_threads_do_not_matter`: it expected one chunk file. The toy's 20
  windows now make ceil(20 / 8) = 3 chunks.
- `test_resume`, `test_worker_failure_fails_fast_and_resumes` and the `_PARENT` script patched CHUNK_WINDOWS (6
  and 1). Under the new rule CHUNK_WINDOWS is only the cap and CHUNK_MIN = 8 would win, so they now patch
  CHUNK_MIN (6 and 1) to keep the same chunking.

## Real-data check (chr10, mm2 cached raw blocks; no genotyping)

How the check ran:
- Script `D/task24f_scratch/probe/realcheck.py`; outputs `realcheck_{windows,net,largest}.tsv`; memo
  `D/task24f_scratch/memo.md`.
- The run used the committed code. "Flat" is bfeeb55's `net_blocks`, loaded from git. As a control, it
  reproduces the batch's cached anchors byte for byte in all six directions and on FastGA.
- Windows are `make_windows` on the batch's elements.
- "Elements ok" counts top-level elements in ok windows. The genome totals are B73v5 6,516, TIL18 6,040 and
  TIL01 6,685.

| direction | net | windows | ok | breakpoint | span_cap | no left / right anchor | elements ok |
|---|---|---|---|---|---|---|---|
| B73v5 -> TIL18 | flat | 5,671 | 3,013 | 2,054 | 604 | 0 / 0 | 3,858 |
| | prototype | 3,444 | 3,091 | 175 | 117 | 32 / 29 | 6,163 |
| | **syntenic** | **3,416** | **3,087** | **167** | **101** | **32 / 29** | **6,187** |
| B73v5 -> TIL01 | flat | 5,651 | 3,300 | 1,759 | 592 | 0 / 0 | 4,165 |
| | prototype | 3,714 | 3,394 | 192 | 97 | 13 / 18 | 6,196 |
| | syntenic | 3,663 | 3,393 | 101 | 102 | 33 / 34 | 6,246 |
| TIL18 -> B73v5 | flat | 5,039 | 3,088 | 1,462 | 488 | 0 / 1 | 4,089 |
| | prototype | 3,420 | 3,091 | 200 | 106 | 12 / 11 | 5,711 |
| | syntenic | 3,365 | 3,086 | 134 | 95 | 27 / 23 | 5,761 |
| TIL18 -> TIL01 | flat | 5,087 | 3,001 | 1,564 | 519 | 0 / 3 | 3,954 |
| | prototype | 3,289 | 3,050 | 170 | 60 | 3 / 6 | 5,801 |
| | syntenic | 3,262 | 3,047 | 128 | 78 | 3 / 6 | 5,825 |
| TIL01 -> B73v5 | flat | 5,574 | 3,488 | 1,627 | 459 | 0 / 0 | 4,599 |
| | prototype | 3,837 | 3,532 | 173 | 95 | 16 / 21 | 6,380 |
| | syntenic | 3,833 | 3,526 | 109 | 81 | 60 / 57 | 6,378 |
| TIL01 -> TIL18 | flat | 5,823 | 2,992 | 2,108 | 723 | 0 / 0 | 3,854 |
| | prototype | 3,354 | 3,058 | 159 | 96 | 21 / 20 | 6,389 |
| | syntenic | 3,301 | 3,049 | 117 | 88 | 21 / 26 | 6,433 |

| direction | net s (flat -> syntenic) | flat pieces / A Mb / chains | kept pieces / A Mb / chains | kept: top / syn / inv / chain | dropped pieces (A Mb summed) | d |
|---|---|---|---|---|---|---|
| B73v5 -> TIL18 | 0.35 -> 0.32 | 14,847 / 75.5 / 2,645 | 8,951 / 52.5 / 84 | 8,518 / 120 / 44 / 269 | 12,111 (56.8) | 0.0375 -> 0.0253 |
| B73v5 -> TIL01 | 0.35 -> 0.29 | 14,422 / 83.6 / 2,526 | 8,931 / 62.0 / 90 | 8,696 / 126 / 109 / 0 | 10,284 (47.8) | 0.0313 -> 0.0207 |
| TIL18 -> B73v5 | 0.28 -> 0.29 | 14,845 / 75.5 / 2,644 | 8,948 / 52.5 / 84 | 8,515 / 120 / 44 / 269 | 12,111 (56.8) | 0.0375 -> 0.0253 |
| TIL18 -> TIL01 | 0.31 -> 0.31 | 16,143 / 74.8 / 2,889 | 9,301 / 49.1 / 85 | 9,126 / 99 / 74 / 2 | 13,788 (64.5) | 0.0410 -> 0.0282 |
| TIL01 -> B73v5 | 0.26 -> 0.27 | 14,424 / 83.6 / 2,528 | 8,931 / 62.0 / 90 | 8,696 / 126 / 109 / 0 | 10,288 (47.8) | 0.0313 -> 0.0207 |
| TIL01 -> TIL18 | 0.33 -> 0.33 | 16,142 / 74.8 / 2,892 | 9,302 / 49.1 / 85 | 9,126 / 100 / 74 / 2 | 13,790 (64.5) | 0.0410 -> 0.0282 |

**Largest available input** (FastGA chr10 B73v5 vs TIL18, 1,044,266 raw blocks):
- `chain_blocks` takes 3.1 s; the net takes 16.6 s (flat: 15.8 s).
- The net keeps 15,102 pieces (flat: 39,717). It drops 394,746 pieces, 1.55 Gb summed.
- For context, its B73v5 windows improve too: elements ok 4,616 -> 5,679, breakpoints 1,465 -> 619, span_cap
  435 -> 218, d 0.059 -> 0.036. So the 62% shrink is the removal of paralogous fills.

**Against the prototype**, as the brief predicted, the corrected rule keeps a little less: 8,951 pieces against
9,118 on B73v5 -> TIL18 (-1.8%).
- **What drops.** In every direction, 117-172 prototype pieces (0.44-0.80 Mb) are missing from the new net,
  and only 3-5 new ones appear.
  - I reran the prototype (`synnet.py` on bfeeb55's chain code, `probe/protocheck.py`), and it reproduces its
    saved nets byte for byte.
  - Of the 887 prototype-only pieces over the six directions, 885 had support in one frame only: top, syn or
    inv in one frame, out in the other. On B73v5 -> TIL18 that is 95 "A top, B out" and exactly the 75 leaked
    "A out, B top" pieces the diagnosis named.
  - The other 2 (TIL18 -> B73v5) were top level in both frames under the prototype. A different chain fills
    their positions now.
- **Breakpoints** fall further: 101-167 per direction against 159-200 in the prototype. Elements in ok windows
  rise by 24-50 in five directions and fall by 2 in TIL01 -> B73v5.
- **Element-level changes against the prototype**, as (breakpoint or span_cap -> ok) / (ok -> unresolved),
  from `probe/noanchor2.py`:

  | B73v5 -> TIL18 | B73v5 -> TIL01 | TIL18 -> B73v5 | TIL18 -> TIL01 | TIL01 -> B73v5 | TIL01 -> TIL18 |
  |---|---|---|---|---|---|
  | 29 / 5 | 50 / 0 | 54 / 4 | 26 / 2 | 3 / 5 | 52 / 8 |

- **The largest differences** are the new no-anchor windows in the TIL01 directions: no left / right anchor
  33 / 34 against 13 / 18, and 60 / 57 against 16 / 21.
  - 149 elements newly lack an anchor: 36, 27, 80 and 6 in the four directions that have any.
  - For every one, the prototype's nearest anchor candidate on that side is a piece the corrected rule dropped.
  - 148 were already unresolved under the prototype (breakpoint or span_cap), so only the reason changes. One
    (TIL18 -> B73v5) had an ok window.
- **Unknown:** whether the 2-8 ok -> unresolved elements per direction (in five directions) lost a real ortholog
  or a paralog that happened to give a consistent pair. No yardstick exists for the TIL01 directions, and I did
  not check the B73v5 -> TIL18 ones against AnchorWave.

## Cache-key change

- `_CHAIN_PARAMS` gains `"net": "syntenic"`. The anchor stage key includes `_CHAIN_PARAMS`, so every anchors
  checkpoint written before this commit misses and is recomputed. The new test checks this.
- **Downstream caches**, all checked:
  - `genotype_pair` and each `genotype_chunk` key on the anchors file's checksum, and the chunks also on the
    windows file's checksum. New anchors therefore mean new calls. If re-netted anchors come out byte-identical,
    reusing the calls is correct.
  - The hybrid route's provisional windows (`anchor/flanks.py:274`) are computed inside `raw_blocks` and never
    cached. A non-W route's raw blocks are not cached by themselves, so they are rebuilt whenever its anchors
    checkpoint misses, and that key carries `_CHAIN_PARAMS`.
  - The W routes' raw-block cache ("raw" stage) and the mm2 index do not depend on the net. They stay valid, so
    phase B reruns re-net without re-mapping when they reuse a workdir.
  - Elements, the BLAST database and the checksum cache are upstream of the net.
- The package version is unchanged.

## Deviations, with reasons

1. **Chains below MIN_CHAIN_SCORE before the test are dropped untested.** The outcome is identical, because they
   would be dropped anyway and their credit was already recorded. It saves time. As a result, my dropped counts
   cover only tested chains. The prototype tested every chain, so its 12,218 dropped pieces and my 12,111 are not
   counted the same way.
2. **New `ValueError`** when a chain spans more than one A sequence, B sequence or strand. The index files a
   chain under one sequence per genome, and `chain_blocks` never produces such a chain.
3. **The INFO line's "X bp of A in total"** is the sum the brief asks for, labeled as a sum. It can exceed a
   sequence's length because later chains retry the positions a drop frees (FastGA chr10: 1.55 Gb summed on a
   152-Mb chromosome). A union of positions would need all dropped intervals in memory.
4. **Tests beyond the brief's list:** the plain-rule oracle, the B-frame mirror, the unplaced-scaffold leak, the
   mixed-chain check, the log line, chunk sizes of 1 and 2000, and resume at another thread count. One more n
   (10^6) checks the 2000 cap.
5. **DESIGN 5.4**: besides removing `boundary_offset`, one sentence says where the offsets actually are (the
   `dl`/`dr` columns).
6. **Reading outside the pointed files.** To understand the context I read `global-constraints.md`,
   `task-24-rulings.md` (the brief cites its ruling 16) and the tail of `progress.md`. I wrote only this report
   under `.superpowers/`.
7. **The real-data check adds a control and context:** HEAD's net is checked against the batch's cached anchors,
   and the FastGA window context is included. No genotyping was run.

## Concerns

1. **Bake-off harness.** `run_variant.py --chunk-windows N` patches `genotype.CHUNK_WINDOWS`, which is now the
   cap. With the floor CHUNK_MIN = 8, N = 8 still gives exactly 8 windows per chunk, but N < 8 would be ignored.
   Phase B should know that the shipped default is ceil(n / 256) (22 windows per chunk on chr10, 235 at 60k
   windows), not 8. I did not touch the script.
2. **Named costs, and their mirror.** The rule drops real transpositions under 1 Mb, and orthologs on unplaced B
   scaffolds whose A side lies in a chromosome chain's gap. By symmetry it also drops a chain on an unplaced A
   scaffold (top level in A) whose B side lies in a B chromosome chain's gap, because it has no B support
   (`test_net_drops_chain_top_level_in_a_only` shows the structure). Assemblies with many scaffolds will lose
   such elements to U/D/O; whole genomes (Task 25) should report it.
3. **The window aligner gets wider windows.** Windows widen, and the diagnosis measured genotyping at about twice
   the time on chr10, with newly resolved calls agreeing less with AnchorWave. Per the brief, this is not
   re-measured here. The disputes inspection covers the classifier side.
4. **Sims not rerun.** The diagnosis measured the first-version rule on R1_s1 and R2_s1 (unchanged except 4
   calls). The corrected rule differs only by dropping one-frame-only pieces. Phase B's reruns will show the
   effect.
5. **FastGA.** With the syntenic net, FastGA still has 619 breakpoint windows on chr10, against 167 for mm2. That
   is route-specific residue for phase B.
