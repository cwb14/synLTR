# Task 13 review: six genomes (controls, direction, f4-ratio, HPC1, Inv4m, default trio view)

## Re-review (fix round 1)

Reviewer: opus, 2026-11-14 17:00-17:15. Scope: what the fix round changed in text, code and tests (task-13-report.md,
"Fix round 1"). Read only. The probe is
`/tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3t13-review/probe_round2.py`;
its output is `probe_round2.out` in the same folder, which is scratch and not durable.

**Assessment: Approved.** I1, I2 and M1-M9 are addressed. My independent recomputation agrees with every new number,
and no verdict moved. Two new text errors (N1, N2) can be fixed in passing without a re-review.

**Recomputed independently.** I used my own code on snapshot 2's catalog through a scratch view, and scipy for the
ranks.
- Maize strata, negative control: D(maize absent) − D(maize present) = +0.1162 ± 0.0854, Z 1.36. This holds over the
  union of the two strata's blocks (418, the implementer's method) and over all counted blocks (426), equal to 4
  decimals.
- Age contrast: D(0<K<0.01) − D(K≥0.01) = +0.2489 ± 0.0783, Z 3.18 (426 blocks).
- D_pav against the SNP D, over the 5 trios whose roles match: Spearman rho 0.900, exact one-sided p 5/120 = 0.042,
  Pearson r 0.958. The other two SNP trios (TIL18,TIL25;B73 and TIL25,TIL01;TIL18) have no view-all trio with those
  roles.
- LTRmix's D_ins against the SNP D: rho 1.000, r 0.998.
- PT-like runs: codes 0000 in all 3, on 100-145 loci per statistic (their eval.json).

All of these match investigate_neg.txt and six_results.tsv.

**Outputs.**
- six_results.tsv has 19 rows. The 18 earlier items keep their verdicts: PASS 1, MISS 1, not estimable 2, and
  reported 14, now 15 with the new rank row. Only some text changed: the notes of rows 1, 2 and 4, and the Inv4m
  breakpoint distances in 3 rows.
- trios_all.tsv and inversions_flagged.tsv are byte-identical to round 1. I compared them with `cmp` against my
  round-1 rerun (sha256 07dd4775… and 48cafd65…).
- A scratch rerun of score_six.py reproduces all three files byte for byte.
- On scratch copies, the tests give 15 passed with `-W error`. Of 6 mutants of the new code, 5 are killed; the one
  survivor is listed under Out of scope.
- Inputs are untouched. fai.start.task13.tsv equals fai.end.task13.tsv, and nothing is newer in six/geno, sim/runs,
  sim/tables, snap/6282541, results/six or gene_snp.

| Finding | Verdict | Where |
|---|---|---|
| I1: controls' equal D_pav, the unexplained size, the headline's statistic | ADDRESSED | RESULTS.md:13-15, 20-23, 26-28, 105, 125-129, 144-148, 336-342; six_results.tsv: notes of "1 positive control" and "2 negative control", and the new row "1 beside: D_pav against the gene-space SNP D"; score_six.py:200-231, 534-542, 552-584, 595-596; dead_ends.md:438-443 |
| I2a: "not only through maize" | ADDRESSED | RESULTS.md:28-30, 152-159; dead_ends.md:415-423; investigate_neg.py:46-66, 103-104; investigate_neg.txt (Z 1.36, 418 blocks) |
| I2b: TIL25 contrast labeled untested | ADDRESSED | RESULTS.md:30-32, 160-164; dead_ends.md:424-429; investigate_neg.py:117-126 (ratios 0.308-0.662) |
| I2c: age contrast tested | ADDRESSED | RESULTS.md:29, 165-168; dead_ends.md:430-434; investigate_neg.py:105-116 |
| M1: margin 0.01 | ADDRESSED | RESULTS.md:122 |
| M2: right breakpoint 4 kb outside | ADDRESSED | RESULTS.md:49-50, 246-248; score_six.py:448-457, 470-471 (the three Inv4m rows now read "47.2 kb" or "74.8 kb", and "4.0 kb") |
| M3: power wording | ADDRESSED | RESULTS.md:208-212, 327-329; score_six.py:635-661 |
| M4: observed PT-like codes | ADDRESSED | RESULTS.md:196-198; six_results.tsv row 4 note; score_six.py:181-197 |
| M5: mechanism labeled as expected | ADDRESSED | RESULTS.md:343-347 (nit N3) |
| M6: terms defined | ADDRESSED, one error | RESULTS.md:81-96 (N1). The ELAI citation checks out: PMID 38033071 is Yang N et al., Science 382(6674) eadg8940, doi 10.1126/science.adg8940 |
| M7: null columns in the 20-trio table | ADDRESSED | RESULTS.md:285-310 (matches trios_all.tsv) |
| M8: tests and run pattern | ADDRESSED | score_six.py:152-178; test_score_six.py:173-177, 182-196, 273-283, 309-322, 329-330, 341-350 |
| M9: memo names env ltrpav's python | ADDRESSED | real/memo.md:151-153 |
| ⚠️ `-N 50` | resolved | Dropped from memo.md:155 and place_hpc1.sh:7. The memo instead checks asm5's scoring from the hit: AS 991 = 1,495 − 24 × 19 − (39 + 3 × 3). I re-derived this, and it agrees with NM 27 (24 mismatches and a 3-bp gap) |

**New issues** (Minor, text only):
- **N1. RESULTS.md:82-83 says the PAV distance "decides the sister pair". That is wrong.**
  - The sister pair is the pair that shares the most derived insertions (relations.sister_pair: "pair = the largest
    sharing count (trio_sharing)"; DESIGN 7.2; findings.txt "the pair sharing the most insertions").
  - The PAV distance decides the second donor, the DFOIL-alt P1/P2 order and the fallback discoverer.
  - Fix: drop "the sister pair", or say it comes from the shared-insertion counts.
- **N2. real/memo.md:159 still reads "six_results.tsv (18 rows: … reported 14)".** The file now has 19 rows, 15
  reported, and memo.md:153 already says 19. Fix the count.
- **N3 (nit). RESULTS.md:345-346 lists the young-insertion excess as seen only in B73,TIL01;TIL18 and the negative
  control.**
  - dD also reaches Z 5.10 in PT,TIL01;TIL18 and Z 4.33 in B73,TIL01;TIL25.
  - This understates rather than overclaims. Suggested wording: "dD Z ≥ 3 in 3 of 20 trios".

**Out of scope** (pre-existing, or tests only):
- dead_ends.md:424-425 says "LTRmix's second control, all |Z| <= 0.5". Its D3 Z is 0.546; RESULTS.md:107 correctly says
  ≤ 0.55.
- test_score_six.py has no end_text case with a distance between 0 and 1 kb, so a `d == 0` → `d <= 1000` mutant
  survives. Harmless for these data.
- score_six.py:595-596 writes "as large as" and "smaller here" as fixed words, not computed from the values. They are
  right for these data.
- compare_papers' two six-genome misreads stay with Task 16, as ruled.

## Original review (round 1)

Reviewer: opus, 2026-11-14 16:25-16:55. Read only; probes in
`/tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3t13-review/`
(snapshot 2 via `SNAP_SHA=6282541 . plan3/common/env.sh`, single thread, a scratch view that links `six/geno`).
S = `benchmark_pav/plan3/real/six`.

Every number and verdict I re-read agrees with the report. No verdict changes. Two text issues matter: RESULTS.md never
says that the positive and negative controls have the same D_pav, and the negative-control investigation states two
exclusions more firmly than its own output supports.

## Spec compliance

- ✅ Step 1 views: S/run_view.sh; 19 step logs record `SNAP_SHA=6282541` and `ltrpav=.../snap/6282541/src/...` on line
  1; every `logs/*.exit` is 0; `--trio` as briefed (logs/*.stats.log line 2); every view's samples.tsv equals
  S/samples.tsv (md5); nothing in six/geno, main3_analyses, results/six, gene_snp, snap/6282541 or sim/runs is newer
  than fai.start.task13.tsv; inputs .fai unchanged.
- ✅ Step 2 compare_papers.py: `diff` against main3_analyses/compare_papers.py shows only `--prefix` (docstring 17-21,
  argument and refusal 822-828, uses at 1077, 1519, 1522); source sha256 59635200…b9462 matches the file and is
  recorded (memo.md:144, RESULTS.md:307, the copy's docstring). Ran after view main's paint finished (15:59:37 then
  15:59:52), exit 0.
- ✅ Step 3 score_six.py: columns `item ltrpav ltrmix bar verdict note` (six_results.tsv:1); LTRmix values from
  `$P/benchmark/results/six/analysis/trio_summary.tsv` (score_six.py:46, 446); bars DESIGN 10.4 / Plan 3 decision 24
  (score_six.py:246-260).
- ✅ Step 4 RESULTS.md: table (74-89), the MISS with its investigation (108-127, and dead_ends.md:398-433), PT
  Toronto Agreement caveat (8-9, 272; DESIGN.md:102).
- ✅ Step 5 / R4 memo: Task 13 entry (memo.md:127-167, `claude --resume` at 167); queue entry (118-125) covers the
  `--tag w1..w5` workers at nice 10, per-block `.queue.lock`, per-worker step files, shared markers, completion by
  `block.done`, `queue.<tag>.done` per worker, and the pause. genotype_all.sh untouched (mtime 08:14).
- ✅ R2: null quantiles beside every main D_pav Z (six_results rows 2-4, 6-8; trios_all.tsv); direction rows carry
  "not validated by simulation (Plan 3)"; simulated power called optimistic (six_results:9, RESULTS.md:163, 276).
- ✅ R3: minimap2 `--help` read and the asm5 choice reasoned in memo.md:154; no figures.
- ⚠️ R4's pause start: the memo has 12:17 (the ruling's time); the ledger says "touched real/queue.pause at 12:20". No
  log records the start. Not the implementer's call.
- ⚠️ memo.md:154 says asm5 sets `-N 50`. Installed 2.31's `--help` shows only the default `-N 5` and no man page is
  installed, so I could not confirm it. It changes nothing: `s1 1154, s2 149` shows the hit is unique either way.

## Item table (re-read from the views' stats.tsv and findings.txt, the PAF, the sims' eval.json)

| # | Item | Reported | Re-read | |
|---|---|---|---|---|
| 1 | Positive control D_pav(PT,B73;TIL18), view pos | +0.1385 ± 0.0439, Z 3.16, 1,192/902; nulls 0/30 default (max 1.97), 0/30 bottleneck (max 3.14), p 0.032; PASS | D 0.138491, SE 0.0438592, Z 3.15762, 1192/902; from the 60 eval.json: default max \|Z\| 1.9668, bottleneck 3.1434, both 0/30, p 1/31; strata high_tier 2.75, nested 2.66, no-filter 3.30; LTRmix and SNP values match trio_summary.tsv and ltr_vs_snp.tsv | agree (margin is 0.014, not 0.02: M1) |
| 2 | Negative control D_pav(TIL11,TIL01;TIL18), view neg | +0.1445 ± 0.0451, Z 3.20, 1,085/811; MISS, explained | 0.144515, 0.0451489, 3.20085; SNP D: gene_abba_baba.TIL11_TIL01_TIL18.tsv sums ABBA 55,183, BABA 49,730 = +0.0520, and gene_snp_D.py:5,130 defines ABBA as P1 = P3, so positive = TIL11 (D_pav's sign); LTRmix D3 +0.0259 (Z 3.23), recipient TIL11 | agree (investigation overstated: I2) |
| 3 | TIL25 as donor, view til25 | +0.1131 ± 0.0405, Z 2.79, Z > 3 no; 0/30, 2/30 (p 0.097); LTRmix D_self Z 4.39 | 0.113139, 0.0404927, 2.79405; 0/30, 2/30; trio_summary D_self_outgroup_Z 4.38566; SNP 65,416/59,190 = +0.050 | agree |
| 4 | Direction, view all | DFOIL-alt 0000 none (DFO +0.001/0.02, DIL −0.060/−1.41, DFI −0.051/−1.10, DOL −0.081/−1.90; n 1,304-1,307); D_dir +0.0641 ± 0.0710, Z 0.90 (307/270); ptlike predicted 0000, none 3/3; not estimable | all match stats.tsv; direction.tsv pt: 0000, n_none 3 of 3, D_dir −0.477 ± 0.097; D_dir nulls default −0.239 ± 0.112 (0/30 at or above), bottleneck −0.103 ± 0.155 (4/30); posctl 2 of 8 (bars.tsv:51) | agree |
| 5 | f4-ratio of B73, view main | not estimable: TIL18~TIL25 0.3432 vs TIL18~B73 0.3428 | distance rows 0.343184 vs 0.342776; findings.txt:64 "f4-ratio skipped: no second donor"; ELAI 0.1695 (six_main_papers row "4 amount") | agree |
| 6 | HPC1 in PT, view hpc1 | PT_chr3:9,088,384-9,089,905 (+), 1,519/1,519 bp, 1,495/1,522, NM 27, MAPQ 60, 1 hit; 8 loci within 50 kb (missing 5, old 2, neither 1), 0 informative; max posterior 0.892; tract 8,965,957-9,449,986, 31 loci, q 0.879; nearest RD 101 kb right, RS 1,206 kb left; B73: 7 loci, RS at 4 kb, max 0.048, no tract | PAF tstart 9088383 (0-based), s1 1154, s2 149, de 0.0164; query equals pysam's fetch of 1-based closed 8,497,916-8,499,434; posterior.PT.tsv and tracts.PT.bed rows re-filtered: all match; LTRmix's asm10 gene alignment puts Zm00001eb121780 at PT_chr3:9,087,119-9,091,256 (contains the hit); LTRmix also counts 27 B73-PT differences in 1,522 positions | agree; placement credible |
| 7 | Inv4m in PT, view all | one B73~PT block 172.84-188.14 Mb (679 loci) ~ PT 173.46-187.00 Mb, coverage 1.000, sparse on neither; 25 of 1,888 blocks sparse on y (19 with Zd), 0 on x | inversions.tsv: 172,835,031-188,135,457 ~ 173,463,334-187,002,178, 679 loci; recount 1,888 blocks, 21 pairs, 25 sparse_y, 0 sparse_x, 19 Zd; the same rule gives main3's 11 of 417; all six views' inversions.tsv identical (md5) | agree, except RESULTS.md:197 (M2) |
| 8 | Decision 11, view all | 0 of 20 trios with an unannotated donor, 0 fallback | 20 roles rows; every D_pav `disc=` equals its donor; Zd annotation "." and role outgroup; the 5 trio views likewise | agree |

Beside rows checked too: D_pav(PT,TIL01;TIL18) +0.4065 Z 11.91; D_pav(TIL11,TIL01;TIL25) +0.0445 Z 1.11; the 4 matched
PT-vs-B73 comparisons and "6 of 8 Z > 3"; the two ambiguous sister pairs (findings.txt:26, 45); view main against main3
(D_pav 0.2905 Z 7.42 → 0.2898 Z 7.39; dD 0.397 → 0.398; AUROC 0.7123 → 0.7118); six_main_papers.tsv 144 rows (19 / 5 /
118 / 2) and, keyed on (section, item), 98 rows shared with prelim_papers.tsv with 0 verdict differences.

## The negative-control investigation (question 2)

"TIL18-specific, not via maize" is only partly supported by investigate_neg.txt (details in I2):
- Not via maize: the maize-absent stratum (+0.236, Z 3.76) rules out an excess carried only by B73- or PT-like
  haplotypes. It does not show "the opposite" of a maize-borne excess. A joint jackknife of the two strata on the same
  426 blocks gives D(absent) − D(present) = +0.116 ± 0.085, Z 1.36 (`probe_neg_diff.out`). In counts, 140 of the 274
  excess loci are where a maize genome carries the insertion and 122 where both lack it.
- TIL18-specific: this rests on Z 3.20 against Z 1.11, a difference of 0.100 that was not tested (Z about 1.7 if the
  two were independent). TIL25 gives a weaker signal than TIL18 in every trio.
- Younger insertions: supported, by a test the text does not cite. D(0<K<0.01) − D(K≥0.01) = +0.249 ± 0.078, Z 3.18
  (`probe_neg_age.out`; the main trio's is +0.410, Z 7.64).
- Untested causes: the gene flow versus population structure split is labeled (RESULTS.md:124-125, dead_ends.md:424).
  The unexplained size (D_pav 2.8 times the SNP D) is labeled only in dead_ends.md:427, not in RESULTS.md.

## score_six.py and its tests (question 3)

Correct on every row I traced: scopes and their negated mirrors, LTRmix row matching and orientation to the tested
genome, SNP orientation (convention checked in gene_snp_D.py), null loading (30 + 30, kind checked), PAF 0→1-based,
posterior and BED window edges, the sparse rule, Inv4m overlap and coverage, decision-11 counts. A rerun into scratch
gives byte-identical six_results.tsv, trios_all.tsv and inversions_flagged.tsv. A scratch copy of the tests gives 12
passed with `-W error`. Mutation check (9 mutants of the key lines): 7 are killed. The two that survive are an
equivalent mutant (`0 not in signs` cannot matter once |Z| ≥ 3) and the D_dir null count's direction (M8).

## Strengths

- Numbers are exact and traceable: every value above came back the same from the source files, and the scorer is
  deterministic, stdlib-only, fail-fast with a one-line error, and states its coordinate conventions at each boundary.
- The controls are framed honestly: "PASS, narrowly", the strata below 3, the bottleneck-null margin, the 30-null
  floor of p 0.032, and "the trios share genomes, so they are not independent tests".
- Direction is handled as rule 7 and R2 require: "none" is neither a miss nor a finding. D_dir is kept exploratory,
  and its against-null counts are given.
- HPC1 placement is careful: the whole-genome target judges uniqueness, the 1-based cut is checked against pysam, the
  asm5 versus 1.6% divergence trade-off is reasoned in the memo, and the result agrees with LTRmix's independent
  alignment.
- The compare_papers copy is minimal and verified against main3. Both of its six-genome misreads were found and routed
  (ruled to Task 16).
- Citations check out: Barnes et al. 2022 (PMID 35771940, doi 10.1073/pnas.2100036119, PNAS 119(27) e2100036119) and
  Pease & Hahn 2015 (Syst Biol 64(4):651-662, doi 10.1093/sysbio/syv023) were confirmed through NCBI and Crossref.

## Issues

### Critical
None.

### Important

**I1. The two controls have the same D_pav, and RESULTS.md does not say so where the verdicts are read**
(RESULTS.md:15-24, 91-106, 284-289).
- What is wrong:
  - The positive control is +0.1385, Z 3.16; the negative control is +0.1445, Z 3.20. Their difference is −0.006, Z
    about −0.1 if independent.
  - The comparators separate them. The SNP D is 0.112 against 0.052 (difference Z about 2.2). LTRmix's D_ins is Z 4.57
    against Z 1.19.
  - The fact appears only in the headline, as "one adjacent swap". The same sentence then calls the negative control's
    excess "small … seen by both", but D_pav's excess is as large as the positive control's: D_pav is 2.78 times the
    SNP D here, against 1.24 for the positive control.
  - The headline's ranking claim gives no statistic. Over the 5 trios with a SNP D, Spearman rho is 0.9 (exact
    one-sided p 0.042 if the trios were independent; they share genomes) and Pearson r is 0.96.
- Why it matters: a reader takes the positive-control PASS to mean D_pav detects PT's extra mexicana ancestry. On these
  single-accession trios, D_pav gives the control pair, which should be near zero, the same excess. The user's rules
  require naming that exception plainly.
- Fix:
  - In "Verdicts in plain words" items 1-2, and in §1 and §2, state that the two controls have equal D_pav sizes and
    what the SNPs and LTRmix show.
  - Move dead_ends.md:427's "Untested: the size of the excess" into RESULTS.md §2.
  - In the headline, give rho with its caveat, say the swap is the two controls, and drop "small" for D_pav.

**I2. The investigation's exclusions overstate investigate_neg.txt** (RESULTS.md:22-24, 117-125;
dead_ends.md:415-426).
- What is wrong:
  - (a) "Not shared through maize … The opposite is seen". The strata do not differ (Z 1.36, joint jackknife), and
    slightly more of the excess (140 of 274 loci) lies where a maize genome holds the insertion. With two maize genomes,
    "both lack it" also does not mean "absent from maize".
  - (b) "Specific to TIL18, not to any donor". This is a difference in significance whose difference was not tested.
    TIL25 gives 0.31-0.66 of TIL18's D_pav in every trio with a parviglumis sister: B73,TIL01 0.39; PT,TIL01 0.52;
    PT,TIL11 0.66; B73,TIL11 0.39; here 0.31. The SNPs show the same for B73,TIL01 (0.30). So the TIL25 contrast does not
    single out this trio. It fits LTRmix's note that TIL25 may carry parviglumis or maize ancestry
    (benchmark/REPORT.md:163-166).
  - (c) "Carried by younger insertions" is right, but it is argued from two separate Z values. view neg's own
    findings.txt:74 reads the dD contrast as "no clear age profile".
- Why it matters: the plain-words summary tells a biologist that sharing through maize was "ruled out", and that claim
  is not earned.
- Fix:
  - Reword (a) to "not only through maize: an excess remains where both maize genomes lack the insertion; a maize-borne
    share is not excluded (strata differ at Z 1.36)".
  - Reword (b) to "weaker with TIL25, as in every trio; the difference was not tested".
  - Add the two joint-jackknife differences (maize strata; 0<K<0.01 against K≥0.01) to investigate_neg.py with the
    snapshot's own blocks, so the numbers are durable and cited. My probes are in the scratchpad.
  - Note that the age contrast, like dD, has no simulated null.

### Minor

- **M1** RESULTS.md:97 says "a margin of 0.02 in Z". The margin is 3.1576 − 3.1434 = 0.014. Write 0.01.
- **M2** RESULTS.md:197-198 says "its right one contains the reference right end". The interval
  188,135,457-188,225,070 starts 3,995 bp after 188,131,462 (six_results.tsv:13 says "0.00 Mb from", rounded). The
  phrase was carried over from PRELIM.md's main3 text. Write "lies 4 kb from".
- **M3** RESULTS.md:163-164: "so a direction the simulations cannot see is less likely still to be seen here" does
  not follow.
  - The real DFOIL statistics count 1,304-1,307 loci each. The PT-like prediction counted 264-368 (4 × 10 Mb, perfect
    genotypes; sim/direction_counts.tsv), and a 50-Mb null 74-93.
  - SIM_RESULTS §10's optimism is per locus ("beyond the locus-count projection").
  - Say that instead. The "not estimable" reading rests on rule 7, not on this inference.
- **M4** six_results.tsv:9 (score_six.py:536-537) gives the PT-like call ("none in 3 of 3") rather than the observed
  codes that R2 asks for. Add "observed 0000 in 3 of 3" (SIM_RESULTS §5).
- **M5** RESULTS.md:290-292: "the donor-shared excess therefore concentrates in young insertions" does not hold for
  the positive control (dD Z 1.10, "flat") or for the 4 trios with dD < 0 (trios_all.tsv). Mark it as the expected pattern, not a
  shown one.
- **M6** Undefined terms for a biologist reader:
  - "PAV distance" (RESULTS.md:33, 117, 169);
  - what an f4-ratio estimates;
  - ELAI;
  - "mapping quality 60" and "chain scores" (RESULTS.md:178).

  Add them to Terms.
- **M7** RESULTS.md:238-259, the 20-trio table, omits the null columns that R2 asks for beside each D_pav Z.
  trios_all.tsv has them. Add the bottleneck count and p, or point to trios_all.tsv.
- **M8** Tests and scorer:
  - The end-to-end test does not check the D_dir null counts (score_six.py:523-524; a `>=`→`<=` mutant survives) or
    the f4 "reported" branch (557-561).
  - load_nulls' glob `null_s*` (score_six.py:156) also matches `runs/null_s101.100Mb`. That run has no eval.json today.
    Once it is scored, the script stops with "31 null runs, not 30": safe, but a `null_s<digits>` pattern avoids it.
- **M9** memo.md:151-152 call a bare `python` for pytest and score_six.py. Name env ltrpav's python so the block reruns
  from a fresh shell.

## Assessment

**Needs fixes.** The fixes are text, plus one small computation in investigate_neg.py (I2). No number, verdict or
scoring path changes. I1 and I2 are needed so RESULTS.md and dead_ends.md say what the data support. The minors can
go in the same pass.
