# Inspection report: who is right where the engine and AnchorWave disagree on real chr10

Date 2026-11-11. Read-only on the repo and on the bake-off outputs. Everything I wrote is in `D/inspect_disputes/`
(D = `/data2/chris/maize_introgression/benchmark_pav/bakeoff`): scripts, tables (`data/`), dotplots (`fig/`) and
`memo.md` (exact commands). ltrpav is a snapshot of bfeeb55 (`snap/`); every script checks that `ltrpav.__file__`
is in it. Env `ltrpav_bench`; `bench_tools` only renders the dotplots. At most 4 processes, every probe under
`timeout 15m` in the foreground.

## Summary

Status: DONE_WITH_CONCERNS.

**Who is right.**
- **Q1, 82 high-tier E against read-out O (66 independent sites).** The engine is right at 74 calls (59 sites).
  - The read-out's O never observes the site. At every one of the 66 sites, AnchorWave leaves at least 3.6 kb of
    flank unaligned next to the element (median 110 kb). The classifier then reads the unaligned bubble as O.
  - The engine is wrong at 8 calls (7 sites). The true state there is undecidable.
    - 7 calls (6 sites): the E is read inside a copy of the host's TE family, placed by the host's own unanchored
      present call.
    - 1 call: a paralogous empty site in old, unannotated TE sequence.
- **Q2, 37 high-tier present-versus-absent contradictions (35 sites).**
  - The engine is right at 29 calls. At 24 of them, the read-out aligned the element to a copy of the same family
    elsewhere in the window, with no flank continuity and no TSD.
  - At 5 calls the engine is wrong: its P sits on a copy of the same family. The read-out's E is right at 1 of
    them and unverified at 4.
  - 1 call is wrong on both sides, and 2 calls (1 site) are undecidable.
- **Q3, 10 of the 114 T against read-out O.** All 10 engine T calls are wrong: the element is aligned to a copy of
  the same family, with no flank continuity and no TSD. The read-out's O is unverified (a bubble); it is plausible
  at 2. Across all 114, 97 T calls have no flank continuity (95 also lack the TSD).
- **Q4, e_in_annot.** 20 sampled stock E calls whose site lies in a TIL18 element:
  - 17 are correct nested E calls: 85%, 95% CI 62-97%. In 11 of them the host is annotated only in TIL18. In 6, B73
    annotates the host too, but the QC's ancestor link misses it.
  - 2 are engine errors: off-synteny paralogous sites, 33-51 Mb away: 10%, CI 1-32%.
  - 1 is something else: 5%, CI 0-25%.

**Defect: yes, in the classifier's present branch.**
- Rule 5 calls P, S or T as soon as ≥ MIN_SEG of the element's own bases align anywhere in the window chain.
  Nothing requires those bases to sit at the element's site, that is, to be joined to its flanks. The E rule does
  require this.
- In wide windows, the window chain routes the element through a copy of the same TE family between distant flank
  images, so P/S/T is called on a paralog.
- Scale in the syntenic run:
  - 427 of 2,854 own present calls have no flank continuity; 419 of them also lack A's TSD beside the element's image;
  - 45 more resolved calls sit nested inside those calls;
  - together, 472 of 4,292 resolved calls (11%), against 177 of 3,570 (5%) in the stock run.
- The read-out uses the same classifier and has 495 such calls. This is why it is a weak yardstick for present
  calls.

**Proposal (rule 5a, frozen before measurement).** A present call must be joined to its flank on at least one side
by an AlnMap run (with ≥ MIN_SEG aligned flank bases), or have A's TSD on both sides of its image in B. Otherwise
the call is U, with reason "unanchored". Measured once:
- **Syntenic run against the read-out (both patched).** Contradictions fall from 58 to 6, and from 37 to 5 at
  high tier. Class agreement of the newly resolved elements rises from 95.0% to 99.7%.
- **Sims.** False present calls fall from 46 to 10. True present calls fall from 3,388 to 3,385, and 4 correct
  calls in all become U. Absent calls are unchanged.

## How the evidence was read

- **Reproduction.** Every inspected window was realigned exactly as the engine does it (mappy asm20, MAPPY_BEST_N,
  strand-split flags) and reclassified with the snapshot classifier.
  - All 741 calls of the 86 case windows match the syntenic run's calls file.
  - So do all 8,564 calls in its 3,091 ok windows, the stock run's 5,317, and the read-out's 8,766, the last rebuilt
    from the MAF segments.
- **Decider.** A host_empty or inherit call takes its host's call. Each case is therefore judged at its decider,
  the outermost element whose own rule made the call. Q1's 82 calls have 66 deciders, Q2's 37 have 35.
- **Flank uniqueness (E calls).**
  - The A bases of the engine's two flank runs (≤ 1 kb next to the refined gap) are searched with blastn against
    TIL18 chr10.
  - A side is *unique* when the HSP at the engine site beats every HSP elsewhere by ≥ 10 bits, a likelihood ratio
    of about 1,000 under the scoring model.
  - Rule: E is right if a flank is unique. E is wrong if neither flank is unique and the element sits inside a host
    whose present call is unanchored. Otherwise E is undecidable.
  - One dotplot-based override, 62523255, is named below.
- **Anchoring (present calls).**
  - *Continuity*: an AlnMap run (segments joined across A and B gaps < MIN_SEG, as `gap_around` reads them) crosses
    the element end and holds ≥ MIN_SEG aligned bases outside the element.
  - *TSD at site*: the classifier's own `_solo_tsd` read, applied to any present call. B's bases beside the
    extrapolated LTR ends must match an A TSD copy within `tsd_allowance`.
- **AnchorWave frame.**
  - AnchorWave segments are joined into runs (≥ MIN_SEG aligned bases).
  - The engine site lies either in the B gap that faces the element ("bubble"), inside an AnchorWave run that aligns
    the site's B bases to the element's own TSD or flank ("run": AnchorWave agrees on one flank), or in another
    AnchorWave gap ("path elsewhere").
- **Dotplots** (`fig/<q>_<decider>.png`, 111 made, 36 inspected).
  - Overview: the whole window, with mappy hits, chain membership, AnchorWave segments and both annotations.
  - Two element ±4-kb zooms and four 4-kb junction panels, with exact 16-mer matches as raw evidence. The zooms are
    fetched past the window edges.

## Q1. High-tier E against read-out O (82 calls, 66 sites)

Every engine E has a TSD match (tsd_mm 0-1) and flank runs adjacent within ±w by construction. The read-out O is
low tier at 67 calls (local identity undefined, because nothing is aligned within ±1 kb) and medium at 15. The
B window has a median of 97 kb (q10 45, q90 231).

| verdict | mechanism | sites | calls |
|---|---|---|---|
| engine right | AnchorWave bubble: the engine site lies in the B gap facing the element; AnchorWave aligns neither flank | 42 | 49 |
| engine right | AnchorWave aligns one flank to the same B bases as the engine and leaves the other unaligned (≥ 21 kb) | 5 | 8 |
| engine right | AnchorWave path elsewhere: the site lies in another AnchorWave gap (local order conflict, or AnchorWave aligning sparse matches) | 12 | 17 |
| engine wrong, truth undecidable | paralogous host copy: E read in a host-family copy placed by the host's unanchored P/T (cont 00, no TSD); flanks have ~350-1,300 near-equal copies | 6 | 7 |
| engine wrong, truth undecidable | paralogous empty site: flanks are old TE sequence at 83-86% inside a TIL18 TE copy, with ~950 better copies (62523255) | 1 | 1 |
| read-out right / both wrong | — | 0 | 0 |

- **Flanks.**
  - Both flanks are unique at 56 sites and one flank at 3.
  - Neither flank is unique at the 7 "engine wrong" sites. The at-site identity there is 83-96%, while copies
    elsewhere reach about 99%.
- **Read-out O.**
  - At every site, the larger AnchorWave flank overhang next to the element is ≥ 3.6 kb (median 110 kb).
  - The read-out's O comes from rule 4g, which calls O when the gap holding the element has ≥ MIN_SEG B-only
    bases, however far the gap edges are from the element.
  - It therefore means "AnchorWave left this region unaligned", not "another insertion at the site".
- **With rule 5a** (measured below): 73 of the 82 calls stay E/O. The 7 paralogous-host calls become U through
  inheritance, together with 2 E calls that have unique flanks; their host is unanchored. 62523255 stays E (a
  residual).

Inspected dotplots (15):

| case (B73v5 chr10) | verdict | mechanism / what the plot shows | figure |
|---|---|---|---|
| 6371124-6413502 | engine | AnchorWave aligns the left flank to the site; the right flank's 2.1 kb are adjacent at the site; AnchorWave leaves 130 kb of A unaligned | `fig/Q1_6371124-6413502.png` |
| 9071578-9087880 | engine wrong (undecidable) | nested; flanks are a host fragment at B 7.6-12.5 kb (host T unanchored), with 1,200+ near copies; AnchorWave leaves 232 kb of A unaligned (B lacks the region) | `fig/Q1_9071578-9087880.png` |
| 18996411-19004699 | engine | unique flanks adjacent at the window start; AnchorWave puts A 27 kb upstream 105 kb later in B (path elsewhere) | `fig/Q1_18996411-19004699.png` |
| 54091260-54100678 | engine | unique flanks adjacent (96%); AnchorWave's path aligns the region 33-57 kb away, with sparse k-mers | `fig/Q1_54091260-54100678.png` |
| 59978499-59987423 | engine | unique flanks adjacent; window A 302 kb by B 12.8 kb; AnchorWave's order conflicts (local rearrangement) | `fig/Q1_59978499-59987423.png` |
| 62523255-62533556 | engine wrong (undecidable) | not nested; flanks at 83-86% inside a TIL18 TE copy, with 950 better copies: paralogous empty site | `fig/Q1_62523255-62533556.png` |
| 67542758-67556583 | engine | nested; the right flank is unique; the host T is anchored on one side; clean junctions; AnchorWave bubble | `fig/Q1_67542758-67556583.png` |
| 74624669-74636754 | engine | nested; AnchorWave and the engine agree on the left flank; the right flank is adjacent; AnchorWave stops for 105 kb | `fig/Q1_74624669-74636754.png` |
| 90651236-90656845 | engine | dense k-mer flank diagonals, adjacent; AnchorWave bubble of A 223 kb by B 123 kb | `fig/Q1_90651236-90656845.png` |
| 96283369-96292801 | engine | AnchorWave aligns the left flank to the same bases; the right flank is adjacent (B holds a second copy 2.6 kb on) | `fig/Q1_96283369-96292801.png` |
| 97943484-97957499 | engine wrong (undecidable) | nested; the host copy at B 74.5-88 kb is an unanchored P whose TSD differs; flanks at 94%, with 500+ better copies | `fig/Q1_97943484-97957499.png` |
| 104393147-104417502 | engine | unique flanks adjacent at B 2.3 kb; AnchorWave aligns A upstream 117 kb later in B (order conflict) | `fig/Q1_104393147-104417502.png` |
| 129995905-130005071 | engine | inversion window; unique flanks adjacent; the site lies inside AnchorWave's 234-kb B bubble | `fig/Q1_129995905-130005071.png` |
| 141132593-141147985 | engine | the right flank is unique at 99% and adjacent, the left flank is 0.5 kb at 88%; AnchorWave maps the region 127 kb away | `fig/Q1_141132593-141147985.png` |
| 148481061-148495203 | engine wrong (undecidable) | nested; the host copy is reached by a 157-kb jump in B (host T unanchored); flanks repetitive | `fig/Q1_148481061-148495203.png` |

## Q2. High-tier present-versus-absent contradictions (37 calls, 35 sites)

There are 32 engine E against read-out P, S or T, and 5 engine P against read-out E. 13 are newly resolved by the
syntenic net, and 24 were already resolved by the stock net. B window: median 29 kb, q10 1 kb, q90 216 kb.

| verdict | mechanism | sites | calls |
|---|---|---|---|
| engine right | the read-out's element sits on a copy of the same family elsewhere: no flank continuity and no TSD (at 18 of these sites AnchorWave aligns one engine flank to the same B bases) | 23 | 24 |
| engine right | the read-out's present call is partly anchored (one side, or TSD); the engine's flanks are unique | 5 | 5 |
| read-out right | the engine's P sits on a copy of the same family with no flanks; the read-out's E has a unique flank | 1 | 1 |
| engine wrong, read-out unverified | the engine's P sits on a copy of the same family; the read-out's E has repetitive flanks inside a host copy, or a 200-bp flank | 4 | 4 |
| both wrong | the engine's E sits in a host copy of a high-copy family (93% at the site, against 99% elsewhere); the read-out's P is 100 kb away | 1 | 1 |
| undecidable | repetitive flanks (97-98%); AnchorWave agrees on the right flank | 1 | 2 |

- **Read-out present calls.** Of the 32 read-out present calls, 31 lack A's TSD beside their image. 27 have no
  flank continuity, and 5 have it on one side.
- **Engine P calls.** All 5 have no continuity and no TSD.
- **Window 3184 (137640788) shows the mechanism directly.**
  - Two collinear paths join the same two anchors: the element on a copy of the same family (12,293 matched bases),
    or the true right flank (11,552).
  - `_chain` keeps the larger sum, so the flank hits drop out of the AlnMap.
- **With rule 5a** (both patched): 26 calls become E/U, 3 E/P, 2 E/T, 3 U/U and 3 U/E. The 5 E calls that stay
  against a present read-out are among the 6 residual contradictions below.

Inspected dotplots (11):

| case | verdict | mechanism / what the plot shows | figure |
|---|---|---|---|
| 13230015-13244471 (E/P) | engine | empty site, flanks best at the site by a narrow margin; the read-out's element is on a copy 44 kb away (TSD AAATA against ATGGC) | `fig/Q2_13230015-13244471.png` |
| 21779777-21789217 (E/P) | engine | empty site with both flanks (the right one confirmed by AnchorWave); the read-out's element is on a TIL18 copy 12-21 kb away, without flanks | `fig/Q2_21779777-21789217.png` |
| 37778327-37785598 (E/P) | engine | 1-kb B window; empty site; the read-out's element is on a same-family insertion 2-9 kb upstream | `fig/Q2_37778327-37785598.png` |
| 68210384-68224649 (P/E) | engine wrong, read-out unverified | the engine's P is the element on a TIL18 copy 57 kb from AnchorWave's clean empty site; the chain chose the element hit over the flank hits | `fig/Q2_68210384-68224649.png` |
| 116181519-116190509 (E/P) | both wrong | nested in a high-copy host (93% at the site, against 99% elsewhere); AnchorWave agrees on the right flank; the read-out's element is 100 kb away | `fig/Q2_116181519-116190509.png` |
| 118026414-118035336 (P/E) | engine wrong, read-out unverified | the engine's P is on a copy with no flanks; the read-out's E is 69 kb away, inside a host copy that AnchorWave anchors on one side | `fig/Q2_118026414-118035336.png` |
| 131521544-131535324 (E/P) | engine | empty site, left flank confirmed by AnchorWave; the read-out's element is on a TIL18 copy 88 kb away (inversion) | `fig/Q2_131521544-131535324.png` |
| 132801894-132811245 (P/E) | read-out | the engine's P is on a TIL18 copy with no flanks; the read-out's E is at B 23.5 kb, where its right flank is unique | `fig/Q2_132801894-132811245.png` |
| 137640788-137664342 (P/E) | engine wrong, read-out unverified | the engine's P is on a copy; the chain took the element path (12,293 bp) over the right-flank path (11,552 bp); the read-out's left flank is 200 bp | `fig/Q2_137640788-137664342.png` |
| 141241248-141250673 (P/E) | engine wrong, read-out unverified | the engine's P is on a copy 28 kb from AnchorWave's empty site (both AnchorWave flanks dense); the host is unanchored in both | `fig/Q2_141241248-141250673.png` |
| 149166527-149190001 (E/T) | undecidable | AnchorWave agrees on the right flank; flanks repetitive (97-98%); the read-out's T is on a copy 19-31 kb away | `fig/Q2_149166527-149190001.png` |

## Q3. T against read-out O (10 of 114, seed 20261111)

The engine's T is wrong in all 10. Each is the element, or part of it, aligned to a copy of the same family that
lies between distant flank images. The nearest flank run is 0.2-55 kb from the element, and there is no
continuity on either side. In 5 of them the B copy is an annotated TIL18 element; 3 of those have an annotated TSD,
and it differs from A's.

The read-out's O is a bubble in all 10: AnchorWave leaves ≥ 4.6 kb of flank unaligned (median 99 kb), so it is
unverified. It is plausible at 2: 120552434, where AnchorWave's flanks lie within 4.5 kb with a 13-kb B gap, and
97630574, where TIL18 has another element 5.6 kb beyond the left flank. The windows are wide (B median 168 kb, up
to 432 kb).

- **All 114.** 97 have no flank continuity (95 without the TSD), 14 have it on one side without the TSD, and 3 on
  one side with it.
- **With rule 5a.** 96 become U and 18 stay T.

| case | verdict | mechanism / what the plot shows | figure |
|---|---|---|---|
| 15046393-15054848 | engine wrong (undecidable) | T in two pieces on a copy 50 kb from AnchorWave's site | `fig/Q3_15046393-15054848.png` |
| 25493081-25508005 | engine wrong (undecidable) | part of the element on a TIL18 copy at B 273-284 kb in a 335-kb window; no flanks within 14-32 kb | `fig/Q3_25493081-25508005.png` |
| 26769757-26780856 | engine wrong (undecidable) | T on a TIL18 copy inside AnchorWave's bubble; different TSD; no flanks | `fig/Q3_26769757-26780856.png` |
| 68708854-68717935 | engine wrong (undecidable) | T on a copy 200 kb from AnchorWave's frame in a window of 423 by 432 kb | `fig/Q3_68708854-68717935.png` |
| 88626678-88635624 | engine wrong (undecidable) | T on a TIL18 copy in a window of 306 by 176 kb; no flanks; AnchorWave bubble | `fig/Q3_88626678-88635624.png` |
| 95830277-95842196 | engine wrong (undecidable) | T from 574 bp; 36 kb of A faces about 1 kb of B, so likely D; AnchorWave bubble | `fig/Q3_95830277-95842196.png` |
| 97630574-97640107 | engine wrong (O plausible) | the left flank aligns 1.45 kb before the element; the T piece is on a TIL18 element 5.6 kb further on | `fig/Q3_97630574-97640107.png` |
| 120552434-120575316 | engine wrong (O plausible) | T on a TIL18 copy 20-30 kb from AnchorWave's site; AnchorWave's flanks lie within 4.5 kb, with a 13-kb B gap | `fig/Q3_120552434-120575316.png` |
| 138862584-138882537 | engine wrong (undecidable) | T in two pieces on copies 15-30 kb past AnchorWave's right bracket; nested TE cluster | `fig/Q3_138862584-138882537.png` |
| 146013793-146022724 | engine wrong (undecidable) | T (91% of the element) on a TIL18 copy; no flanks; AnchorWave bubble | `fig/Q3_146013793-146022724.png` |

## Q4. e_in_annot: E calls whose site lies inside a TIL18 element (stock mm2 run, B73v5 -> TIL18)

The QC definition was reproduced with the snapshot's own catalog (`_Catalog` over all 6 pair files, ancestor
loci excluded): 224 of 1,114 E calls, 0.201077, the same as qc.tsv. 20 were drawn with seed 20261111
(`data/q4_sample.tsv`). Per call:
- **H (the containing TIL18 element).** Its 1-kb flanks were mapped to B73: do they bracket the element X?
- **X's own flanks.** The blastn uniqueness test at the E site.
- **Hosts.** X's annotated B73 ancestors, their calls, and their reciprocal overlap with H.
- **AnchorWave.** Its image of X's position.

| class | n | share (95% CI, Clopper-Pearson) | scaled to 224 | evidence |
|---|---|---|---|---|
| correct nested E; B73 annotates the host too, but the QC's ancestor link misses it | 6 | 30% (12-54%) | 67 (27-122) | H's flanks bracket X; X's B73 host is P/high inside H, with reciprocal overlap 0.24-0.58 < 0.8, so no locus link; or H is the ortholog of an adjacent B73 element with other boundaries |
| correct nested E; the host is annotated only in TIL18 | 11 | 55% (32-77%) | 123 (71-172) | H's flanks bracket X in B73, and no B73 element spans them: the host is split there by X and other insertions |
| engine error: paralogous site off synteny | 2 | 10% (1-32%) | 22 (3-71) | 73385690 (site 51 Mb from AnchorWave's image) and 58602114 (33 Mb); H's flanks map elsewhere; X's flanks repetitive (90-93%) |
| something else | 1 | 5% (0-25%) | 11 (0-56) | 30080846: the TSD copy lies 14 bp inside the edge of an adjacent TIL18 element; the E itself is supported by a unique right flank |

Brief's classes: the first is my rows 1 and 2 together, and the second ("nested in an ortholog the annotation
missed in A") is my row 2.

All-224 cross-check (`data/q4_evidence_all.tsv`, same tests):
- H's flanks bracket X in 166 calls (74%), lie near X in 35, and map elsewhere in 23 (10%).
- The E site lies inside AnchorWave's image in 206 calls and ≥ 1 Mb from it in 10 (4.5%).

**Reading.** e_in_annot mostly measures annotation asymmetry of old hosts, not engine error. A host disrupted by
nested insertions in one genome is annotated as an intact element only in the other. The rate is about 20% in
both directions and on every route. The sims have few such hosts, hence 2-9%. Real errors are the off-synteny
paralogous sites of stock windows anchored on paralog chains (the diagnosis's cause), at about 5-10%.

## Q5. Verdict

### The defect
- **Rule and step.** Rule 5 of `classify.py` (`_present`), reached when ≥ MIN_SEG of the element's own bases are
  aligned.
  - It calls P, S or T from coverage alone.
  - Rule 2 asks only for ≥ MIN_SEG aligned bases somewhere on each side of the element, not next to it.
  - So nothing places the element at its site, whereas E needs both gap edges within ±w (rule 4f).
- **Trigger.** A wide window in TE-dense sequence that holds a copy of the element's family between the flank images.
  - `localign._chain` keeps the collinear chain with the most matched bases. The element's hit on that copy is
    collinear with the distant flank runs, and it can even displace shorter true-flank hits (window 3184).
  - The syntenic net creates such windows: unanchored present calls sit in B windows with a median of 114 kb,
    against 21 kb for anchored ones.
- **Calls touched, syntenic run.**
  - 427 own P/S/T calls (89 P, 17 S, 321 T) are unanchored.
  - The independent TSD test separates the two groups sharply. A's TSD flanks the B image at 98% of the 2,028
    anchored calls, and at 2% of the 427 unanchored ones (419 lack it). A shared insertion carries the same TSD
    copies in both genomes; a paralog almost never does.
  - 45 more resolved calls are nested in them (36 E, 4 P, 5 T): E read inside a paralogous host copy.
  - Total: 472 of 4,292 resolved calls (11%). Stock run: 154 + 23 = 177 of 3,570 (5%).
  - Of the syntenic net's 445 newly resolved present calls, 304 are unanchored. They include 97 of the 114 T/O,
    16 of the 25 P/O and all 5 high-tier P/E.
- **Same defect in the read-out.** The read-out uses the same classifier on AnchorWave's alignment and has 495
  unanchored present calls (484 without the TSD). These are its side of 31 of the 32 high-tier E-against-present
  disputes.

### Proposal (written and frozen before measurement; `D/inspect_disputes/proposal_frozen.md`, 2026-11-11T07:23:15-05:00, sha256 `660d1ee4…0a68` in `proposal_frozen.log`)

**Rule 5a: a present call must be anchored at its site.**
- A P, S or T call needs the element's own aligned bases joined to its flank on at least one side. That is, an
  AlnMap run (segments joined across A and B gaps < MIN_SEG, the runs `gap_around` already reads) crosses the
  element's start or end and holds ≥ MIN_SEG aligned A bases outside the element on that side.
- If no run does, the call stands only if B's bases beside the element's image match an A TSD copy on both sides
  within `tsd_allowance` (the solo_tsd read, the evidence S already uses).
- Otherwise the element is U, with reason "unanchored". Rule 0 passes the U to its nested elements unchanged.
- There is no new constant: MIN_SEG and tsd_allowance are the classifier's own.

**Why.**
- **Positional orthology.** A shared insertion is the same element between the same flanks, with the same TSD.
  E already demands both flanks next to the element. A present call demands at least one, because a truncation or
  an adjacent insertion can break the other junction.
- **Alignment geometry.** A run crossing the element end means the alignment passes from flank into element with
  offsets < MIN_SEG, the tolerance `gap_around` already uses.

**Named, not measured.**
- 5a turns a misplaced P/S/T into U; it does not recover the call at the true site. Recovering it needs the window
  chain chosen on flank sequence: score each hit by its matched bases outside the window's annotated element spans,
  choose the chain on that score, then add element hits collinear with it (repeat-masked chaining).
- A paralogous empty site whose flanks are unannotated old TE sequence needs a flank-uniqueness test that uses data
  outside the window.

### Measurement (once, after the freeze)
`measure_5a.py`:
- A monkeypatch of `_present` in the snapshot.
- Every ok window of 15 datasets is reclassified twice from one alignment: rule 5a off and on.
- With the rule off, the calls equal every dataset's calls file exactly (0 differences in 28,664 calls).

**chr10 B73v5 -> TIL18.**

| calls | changed to U | resolved | both resolved with read-out | class agreement | contradictions (high tier) |
|---|---|---|---|---|---|
| syntenic, before (read-out unpatched) | — | 4,292 | 3,743 | 98.45% | 58 (37) |
| syntenic, rule 5a (read-out also 5a) | 536: 90 P, 16 S, 322 T; inherited 35 E, 53 O, 20 D | 3,829 | 3,433 | 99.83% | 6 (5) |
| syntenic, newly resolved 790: before → 5a | 324 | 790 → 466 | 476 → 305 | 94.96% → 99.67% | 24 (13) → 1 (1) |
| stock: before → 5a | 199 | 3,570 → 3,397 | 3,272 → 3,131 | 98.96% → 99.84% | 34 (24) → 5 (4) |
| read-out | 599: 187 P, 27 S, 282 T; inherited 58 E, 18 O, 27 D | | | | |

- **Dispute classes after 5a.**
  - T/O (114): 96 become U and 18 stay T.
  - E/O (83): 74 stay E and 9 become U.
  - P/O (25): 16 become U and 9 stay P.
- **The 6 remaining contradictions.** 5 are engine E calls with unique flanks against a partly anchored read-out
  P/T: 37778327, 66937978, 100292333, 107758899 and 131521544. One is engine T (anchored on one side) against
  read-out E.
- **Cost on chr10.**
  - The syntenic net's U count rises from 1,412 to 1,948, still well below stock's 4,295.
  - 35 E calls become U through inheritance (31 deciders). 24 have repetitive flanks on both sides, so they are
    likely paralogous-host E calls. 6 have unique flanks, so they are likely correct E calls that are lost.

**Simulations** (6 sims × 2 directions, 6,055 scored elements, `ltrpav-sim score` code from the snapshot).

| tier set | class | before tp / fp / fn | 5a tp / fp / fn | precision | recall |
|---|---|---|---|---|---|
| all | present | 3,388 / 46 / 94 | 3,385 / 10 / 97 | 0.9866 → 0.9971 | 0.9730 → 0.9721 |
| high | present | 3,018 / 2 / 464 | 3,018 / 1 / 464 | 0.9993 → 0.9997 | 0.8667 → 0.8667 |
| all, high | absent | 1,249 / 3 / 229; 1,236 / 3 / 242 | unchanged | — | — |

- 43 sim calls become U.
  - 39 had the wrong state. 36 of these were false present calls, among them 22 truth-E elements called T,
    7 truth-D called T and 1 truth-E called high-tier P.
  - 4 had the right state: 2 T calls, plus 1 O and 1 D that inherited their host's U.
  - In class terms, present true positives fall by 3 (the 2 T calls and 1 truth-S element called T).
- Unresolved calls rise from 3.55% to 4.26%. The sims show the same failure (truth E called T) at a low rate,
  because their windows are narrow.

### Two neighboring issues, not part of the proposal
- **Bubble O (rule 4g).**
  - O is called whenever ≥ MIN_SEG B-only bases face the element, before the gap edges are tested.
  - In the syntenic run, 1,005 of 1,512 own O calls have a gap edge more than 10 kb from the element; only 10 have
    both edges within ±10 bp. In the read-out, 1,339 of 1,572 do.
  - The class (missing) is usually plausible, but "another insertion at the site" is not shown. Every read-out O in
    Q1 and Q3 is of this kind.
- **Paralogous empty sites in old, unannotated TE sequence.** An example is 62523255 in Q1, and Q4's off-synteny
  sites in stock windows anchored on paralog chains (about 5-10% of e_in_annot). Rule 5a does not reach them.

## What would change my verdict
- **chr10 only.** Flank uniqueness was tested on TIL18 chr10 alone. An empty allele duplicated on another
  chromosome, while the orthologous site holds the element, would make some "engine right" Q1/Q2 calls wrong. A
  whole-genome search would settle it.
- **Engine right at unique-flank sites.** This rests on flank uniqueness plus adjacency plus the TSD.
  - Long reads, or TIL01 showing the same unaligned region, would test it where AnchorWave's path conflicts in
    order (12 Q1 "path elsewhere" sites).
  - It would fall if the TIL18 assembly were wrong there, for example a misjoin that brings unique flanks together.
- **The anchoring test.** It takes the TSD test as independent evidence (98% against 2%). If unanchored present
  calls were mostly orthologs with badly aligned ends, 5a would cost real calls. The sims argue otherwise (36 wrong
  calls removed for 4 right ones), but they have few such windows.
- **Small samples.** Q3 is 10 of 114, and Q4 is 20 of 224, so its intervals are wide.
- **The yardstick.** The read-out shares the classifier, so agreement with it is not independent evidence for
  present calls. Its O calls in bubbles carry no site information.
