# Task 13: controller rulings (binding; they override task-13-brief.md where the two differ)

## R1. Code and inputs
- **Snapshot 2** for every analysis (stats, paint, plot): select it with `SNAP_SHA=6282541` (snapshot 2, `benchmark_pav/plan3/snap/6282541`) when sourcing
  `common/env.sh` or running `common/view.sh`. Its sha and procedure are in `real/memo.md` (Task 11 Part C). Check
  that `ltrpav.__file__` resolves inside it before the first analysis.
- **Genotypes:** `real/six/geno`. The block finished 2026-11-14 12:22 across four runs of the queue. Per-run logs:
  `genotype.log.run1-3` and `genotype.w1.*`; markers `genotype.done`, `merge.done`, `block.done`. Never write in
  `real/six/geno`; views link to it (`common/view.sh RUN VIEW SHEET`).
- **The sheet:** `real/six/samples.tsv` (the one the queue genotyped).
- Two queue workers (w4, w5) are genotyping `real/stability/*` from `snap/12d3e6c`. Do not touch `real/stability/`,
  `real/genotype_all.sh` or `snap/12d3e6c`.

## R2. Simulation results to cite (sim/SIM_RESULTS.md, reviewed)
- **Direction (item 4).** Rule 7 was not confirmed. The C1>A1 positive control cannot pass at any genome size: its
  design leaves DFOIL classes empty, and LTRpav names no direction when a jackknife Z is undefined. A1>C1 is short of
  loci at 50 Mb. The real direction rows therefore carry the note "not validated by simulation (Plan 3)". Report the
  ptlike runs' predicted and observed codes from SIM_RESULTS section 5. A real "none" is not a miss and not an
  implementation fault; neither is a real call validated.
- **D_pav's null.** Rule 1 passes (0 of 30 nulls with |Z| > 3), but the null Z is not calibrated (rule 2 reading).
  Where Task 13 reports a D_pav Z, also report its empirical null quantile against both the default nulls (max |Z|
  1.97) and the bottleneck nulls (max |Z| 3.14). The verdict rests on the bottleneck null (controller ruling (I4),
  2026-11-14). The bars themselves stay DESIGN 10.4's (Z > 3; |Z| < 3).
- **Simulated power is optimistic for real data** (SIM_RESULTS section 10). Say so where the six-genome results lean
  on it.

## R3. Science and reporting
- Bars as DESIGN 10.4 states them, each PASS or MISS. Each MISS is investigated in `benchmark_pav/dead_ends.md`; never
  change a bar.
- HPC1 placement uses `minimap2 -x asm5`. Read the installed minimap2's `--help` first, question the defaults that
  matter for one gene placed across maize genomes, and record the choice and why in `real/memo.md`.
- The PT caveat is a Toronto Agreement release: state it in RESULTS.md.
- No figures: Plan 4 draws them.

## R4. real/memo.md
Append this task's entry (dates, commands, outputs, snapshot 2). Also add a short "Queue, 2026-11-14" entry,
covering:
- the queue ran as parallel workers (`genotype_all.sh --tag w1..w5`, nice 10), one block per worker, through
  per-block locks (`<block>/.queue.lock`);
- step files are per worker (`<step>.<tag>.{log,time,mem.tsv}`), and the markers `<step>.done` and `block.done` are
  shared;
- the queue is complete when every block has `block.done`; `queue.<tag>.done` is per worker;
- `queue.pause` was set 12:17-13:40 to keep the user's combined thread count under the weekend ceiling.

The script's own header already documents `--tag`; do not edit `genotype_all.sh` (workers are running it).
