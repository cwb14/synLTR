"""Analysis stages and commands (ltrpav.analysis.report, ltrpav.analysis.cli): ltrpav-stats and ltrpav-paint on
toy runs (tests/catalog_toy.py), their checkpoints and markers, the assembly of stats.tsv and findings.txt, the
`ltrpav run` hook, and the analysis fingerprint (its own package plus the engine modules it runs, never an
engine stage's)."""
from __future__ import annotations

import ast
import json
import logging
import math
import random
import re
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

import toy
from catalog_toy import GENOMES, TRACTS, loc, simulate_run, write_run
from conftest import needs_lastz
from ltrpav import __version__, checkpoint, cli
from ltrpav.analysis import report
from ltrpav.analysis.catalog import AnalysisError
from ltrpav.analysis.cli import paint_main, plot_main, stats_main
from ltrpav.analysis.constants import BLOCK_MIN
from ltrpav.analysis.identity import IDENTITY_COLUMNS
from ltrpav.analysis.report import (
    ENGINE_MODULES,
    STAGES,
    analysis_fingerprint,
    assemble,
    write_part,
)
from ltrpav.analysis.stats import PART, SECTIONS, STATS_COLUMNS, Findings, StatRow, read_stats
from ltrpav.annotation.gff3 import write_gff3
from ltrpav.checkpoint import mark_done, stage_key
from ltrpav.cli import main
from ltrpav.constants import DEFAULT_BACKEND
from ltrpav.localign import backend_version
from test_cli import element, make_world


def _args(run):
    return ["--samples", str(run.sheet), "--outdir", str(run.outdir)]

@needs_lastz                                       # from tests/conftest.py: `ltrpav run` aligns with LASTZ
def test_run_includes_analyses(tmp_path, caplog):
    w = make_world(tmp_path / "w")                   # tests/test_cli.py: A, B annotated; C genotype-only
    out, argv = tmp_path / "out", ["run", "--samples", str(w.sheet), "--outdir", str(tmp_path / "out")]
    assert main(argv) == 0
    assert all((out / f).is_file() for f in ("stats.tsv", "findings.txt", "inversions.tsv", "mechanisms.tsv"))
    assert "Trio tests" in (out / "findings.txt").read_text().splitlines()
    caplog.clear()
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert main(argv) == 0
    assert "stats: done, skip" in caplog.text and "paint: done, skip" in caplog.text

def test_stats_then_paint(tmp_path, toy_fastas):
    run = simulate_run(tmp_path, seed=1, tracts=TRACTS, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0
    assert {"sharing", "D_pav", "paint"} <= {r.test for r in read_stats(run.outdir / "stats.tsv")}
    assert (run.outdir / "stats.tsv").read_text().splitlines()[0].split("\t") == list(STATS_COLUMNS)
    lines = (run.outdir / "findings.txt").read_text().splitlines()
    assert lines[0].startswith("ltrpav ") and str(run.outdir) in lines[0]
    heads = [ln for ln in lines if ln in SECTIONS]
    assert heads == sorted(heads, key=SECTIONS.index) and (run.outdir / "tracts.R.bed").is_file()

def test_stats_skip_after_paint(tmp_path, toy_fastas, caplog):
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0      # paint re-assembles stats.tsv
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert stats_main(_args(run)) == 0
    assert "stats: done, skip" in caplog.text

def test_rerun_after_sheet_change(tmp_path, toy_fastas, caplog):
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0
    run.sheet.write_text(run.sheet.read_text().replace("\toutgroup", "\t."))
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert stats_main(_args(run)) == 0
    assert "stats: done, skip" not in caplog.text

def test_trio_validation(tmp_path, toy_fastas, capsys):
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    for bad in ("R,R,D", "R,S,X", "R,S,O"):
        assert stats_main([*_args(run), "--trio", bad]) == 1
        err = capsys.readouterr().err
        assert err.strip().splitlines()[-1].startswith("error:") and "Traceback" not in err

def test_missing_merge(tmp_path, toy_fastas, capsys):
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    (run.outdir / "manifest.json").unlink()
    assert stats_main(_args(run)) == 1
    assert "ltrpav-merge" in capsys.readouterr().err.strip().splitlines()[-1]

def test_help_is_short(capsys):
    for fn in (stats_main, paint_main):
        with pytest.raises(SystemExit):
            fn(["--help"])
        assert len(capsys.readouterr().out.splitlines()) < 40

_NO_SCIPY = "import sys; sys.modules['scipy'] = None; sys.modules['matplotlib'] = None; "


def test_cli_imports_without_scipy():
    """Both command modules import with scipy and matplotlib blocked: the heavy imports wait for a command to
    run."""
    for mod in ("ltrpav.cli", "ltrpav.analysis.cli"):
        r = subprocess.run([sys.executable, "-c", _NO_SCIPY + f"import {mod}"], capture_output=True, text=True,
                           check=False)
        assert r.returncode == 0, r.stderr


def test_stats_shared_seqids(tmp_path, toy_fastas):
    a = simulate_run(tmp_path / "a", seed=1, tracts=TRACTS, fasta_dir=toy_fastas)
    b = simulate_run(tmp_path / "b", seed=1, tracts=TRACTS, prefix=True, fasta_dir=toy_fastas)
    for run in (a, b):
        assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0

    def norm(run):   # the parts' sentinel rows hold stage keys, which hash the runs' differing files: left out
        return [re.sub(r"\b[RSDO]_(chr\d)\b", r"\1", ln) for ln in (run.outdir / "stats.tsv").read_text().splitlines()
                if ln.split("\t")[1] != PART]
    assert norm(a) == norm(b)

def test_run_two_genomes(tmp_path, toy_fastas):
    run = write_run(tmp_path, [loc(1000 * i, "R:P* S:E O:E") for i in range(1, 20)],
                    genomes=[GENOMES[0], GENOMES[1], GENOMES[3]], fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0
    assert "Trio tests skipped: fewer than three ingroup genomes" in (run.outdir / "findings.txt").read_text()
    assert (run.outdir / "mechanisms.tsv").is_file()


# ---------------------------------------------------------------- markers, stale parts, assembly and failures


def _marker_outputs(outdir: Path, stage: str) -> set[str]:
    """The files a stage's marker lists, relative to the run directory."""
    rec = json.loads((outdir / "work" / "analysis" / f"{stage}.done.json").read_text())
    return {(Path("work/analysis") / o["path"]).as_posix().removeprefix("work/analysis/../../")
            for o in rec["outputs"]}


def test_markers_list_the_files_each_stage_writes(tmp_path, toy_fastas):
    """Each marker lists exactly the files its stage writes; stats.tsv and findings.txt,
    which every stage rewrites, are in no marker."""
    run = simulate_run(tmp_path, seed=1, tracts=TRACTS, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0
    parts = {s: {f"work/analysis/{s}.rows.tsv", f"work/analysis/{s}.findings.tsv"} for s in STAGES}
    assert _marker_outputs(run.outdir, "stats") == {"inversions.tsv", "mechanisms.tsv"} | parts["stats"]
    painted = {"tracts.R.bed", "posterior.R.tsv", "decoy_tracts.S.bed", "decoy_posterior.S.tsv"}
    assert _marker_outputs(run.outdir, "paint") == painted | parts["paint"]
    assert {p.name for p in run.outdir.iterdir() if p.is_file()} == (
        {"loci.tsv", "qc.tsv", "manifest.json", "stats.tsv", "findings.txt", "inversions.tsv", "mechanisms.tsv"}
        | painted)


def test_stale_identity_tsv_removed_and_paint_left_out(tmp_path, toy_fastas, caplog):
    """Without --identity the stats stage deletes a stale identity.tsv and says what needs --identity. The paint
    stage read that file, so its key no longer holds: its part leaves stats.tsv and findings.txt, with a WARNING
    naming identity.tsv, until ltrpav-paint reruns it."""
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    ident = run.outdir / "identity.tsv"
    ident.write_text("\t".join(IDENTITY_COLUMNS) + "\n")      # as a --identity run with no rows leaves it
    assert paint_main(_args(run)) == 0
    assert "identity.tsv" not in _marker_outputs(run.outdir, "paint")            # read, not written
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert stats_main(_args(run)) == 0
    left = [r.getMessage() for r in caplog.records if "left out" in r.getMessage()]
    assert len(left) == 1 and left[0].startswith("paint: ") and "its inputs changed (identity.tsv)" in left[0]
    assert not ident.exists()
    text = (run.outdir / "findings.txt").read_text()
    assert "need the sequence-identity layer: rerun ltrpav-stats with --identity" in text
    assert "Painting" not in text.splitlines() and "WARNING: the paint part is left out" in text
    assert "paint" not in {r.test for r in read_stats(run.outdir / "stats.tsv")}
    caplog.clear()
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert paint_main(_args(run)) == 0
    assert "paint: done, skip" not in caplog.text and "left out" not in caplog.text
    assert "paint" in {r.test for r in read_stats(run.outdir / "stats.tsv")}


def test_sheet_change_leaves_the_stale_painting_out(tmp_path, toy_fastas, caplog):
    """After a sheet change only ltrpav-stats reruns. The painting, made with the old sheet
    (O an outgroup), no longer holds its key, so it stays out of stats.tsv and findings.txt, with one line naming
    it and why, until ltrpav-paint reruns."""
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0
    run.sheet.write_text(run.sheet.read_text().replace("\toutgroup", "\t."))     # O becomes an ingroup genome
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert stats_main(_args(run)) == 0
    left = [r.getMessage() for r in caplog.records if "left out" in r.getMessage()]
    assert len(left) == 1 and left[0].startswith("paint: ") and "its inputs changed (the samples sheet)" in left[0]
    assert "paint" not in {r.test for r in read_stats(run.outdir / "stats.tsv")}
    text = (run.outdir / "findings.txt").read_text()
    assert "Painting" not in text.splitlines() and "WARNING: the paint part is left out" in text
    caplog.clear()
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert paint_main(_args(run)) == 0
    assert "left out" not in caplog.text and "paint" in {r.test for r in read_stats(run.outdir / "stats.tsv")}


def test_code_change_leaves_the_stale_stats_out(tmp_path, toy_fastas, caplog, pkg):
    """After an analysis-code edit (here in a copy of the package that the fingerprint
    reads) only ltrpav-paint reruns. The stats part was made by the old code, so it stays out, with one line
    naming it and why."""
    run = simulate_run(tmp_path / "w", seed=1, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0
    path = pkg / "analysis" / "paint.py"
    path.write_bytes(path.read_bytes() + b"\n# an edit\n")
    checkpoint._fingerprint.cache_clear()
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert paint_main(_args(run)) == 0
    assert "paint: done, skip" not in caplog.text
    left = [r.getMessage() for r in caplog.records if "left out" in r.getMessage()]
    assert len(left) == 1 and left[0].startswith("stats: ") and "the analysis code changed" in left[0]
    tests = {r.test for r in read_stats(run.outdir / "stats.tsv")}
    assert "paint" in tests and "D_pav" not in tests


def _sequence_run(tmp_path: Path, toy_fastas: Path, n: int = 4):
    """R, S and D holding the same four 2,800-bp elements (S's with 0.2% substitutions) in real sequence, the
    outgroup O empty: a run the identity layer can align. n: the first n of the four loci are written (fewer:
    the same run re-merged with loci left out)."""
    rng = random.Random(9)
    els = [toy.make_element(rng, 400, 2000)[0] for _ in range(4)]
    flanks = [toy.rand_seq(2000, rng) for _ in range(5)]
    copies = {"R": els, "S": [toy.mutate(e, 0.002, rng) for e in els], "D": els}
    fastas = {}
    for g, cs in copies.items():
        fastas[g] = tmp_path / f"{g}.fa"
        fastas[g].write_text(">chr1\n" + "".join(f + c for f, c in zip(flanks, cs)) + flanks[4] + "\n")
    loci = [loc(2001 + 4800 * i, "R:P* S:P* D:P* O:E", length=2800, ltr=400) for i in range(n)]
    return write_run(tmp_path / "w", loci, seqids=("chr1",), fastas=fastas, fasta_dir=toy_fastas)


@needs_lastz
def test_identity_through_the_commands(tmp_path, toy_fastas, caplog, monkeypatch):
    """--identity end to end: identity.tsv is written and listed in the stats marker, the identity rows reach
    stats.tsv; paint reads the file (its key holds it, so paint reruns after it changes); the stats key holds
    LASTZ's version, so without lastz the stats part reads as stale; a stats rerun without --identity deletes
    identity.tsv and leaves the painting out until paint reruns."""
    run = _sequence_run(tmp_path, toy_fastas)
    assert paint_main(_args(run)) == 0
    assert stats_main([*_args(run), "--identity", "--threads", "1"]) == 0
    assert "identity.tsv" in _marker_outputs(run.outdir, "stats")
    rows = (run.outdir / "identity.tsv").read_text().splitlines()
    assert rows[0].split("\t") == list(IDENTITY_COLUMNS) and sum(r.startswith("self\t") for r in rows) == 12
    assert any(r.layer == "identity" for r in read_stats(run.outdir / "stats.tsv"))
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert paint_main(_args(run)) == 0                  # identity.tsv appeared: not a skip
        assert stats_main([*_args(run), "--identity", "--threads", "1"]) == 0
    assert "paint: done, skip" not in caplog.text and "stats: done, skip" in caplog.text
    caplog.clear()
    monkeypatch.setattr(report, "backend_version", lambda backend: None)   # lastz no longer on PATH
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert paint_main(_args(run)) == 0
    assert "paint: done, skip" in caplog.text and "LASTZ's version differs (lastz is not on PATH" in caplog.text
    assert not any(r.layer == "identity" for r in read_stats(run.outdir / "stats.tsv"))   # stats part left out
    monkeypatch.undo()
    assert "paint" in {r.test for r in read_stats(run.outdir / "stats.tsv")}
    assert stats_main(_args(run)) == 0                       # without --identity: rerun, identity.tsv deleted
    assert not (run.outdir / "identity.tsv").exists()
    assert "paint" not in {r.test for r in read_stats(run.outdir / "stats.tsv")}   # the painting read it: left out


@needs_lastz
def test_plot_check_probes_no_tool(tmp_path, toy_fastas, monkeypatch, capsys):
    """The plot stage's currency check (stale_parts, probe_tools=False) takes LASTZ's version
    from the stats marker, so with lastz gone from PATH a current --identity stats.tsv is drawn, though the
    assembly's check (probe_tools=True) calls that part stale; a catalog change is still refused."""
    run = _sequence_run(tmp_path, toy_fastas)
    assert stats_main([*_args(run), "--identity", "--threads", "1"]) == 0 and paint_main(_args(run)) == 0
    monkeypatch.setattr(report, "backend_version", lambda backend: None)   # lastz no longer on PATH
    cat = run.load()
    assert "LASTZ's version differs" in report.stale_parts(cat, warn=False)["stats"]
    assert report.stale_parts(cat, warn=False, probe_tools=False) == {}
    assert plot_main(_args(run)) == 0 and (run.outdir / "overview.png").is_file()
    _sequence_run(tmp_path, toy_fastas, n=3)                                # re-merged: one locus fewer
    capsys.readouterr()
    assert plot_main(_args(run)) == 1
    err = capsys.readouterr().err.strip().splitlines()[-1]
    assert err.startswith("error: stats.tsv in ") and "the stats part: its inputs changed (loci.tsv" in err
    assert "the paint part: its inputs changed (loci.tsv" in err and "LASTZ" not in err


@needs_lastz
def test_another_lastz_reruns_stats_and_still_draws(tmp_path, toy_fastas, monkeypatch, caplog, capsys):
    """With a LASTZ version other than the one the stats marker recorded, ltrpav-plot draws
    while stats.tsv holds the stats part (its check probes no tool). Once an assembly (here ltrpav-paint's, which
    probes LASTZ) has left that part out of stats.tsv, ltrpav-plot refuses, naming why, instead of drawing a
    figure without the trio. ltrpav-stats --identity reruns (its key probes LASTZ), and the figure is drawn."""
    run = _sequence_run(tmp_path, toy_fastas)
    ident = [*_args(run), "--identity", "--threads", "1"]
    assert stats_main(ident) == 0 and paint_main(_args(run)) == 0
    monkeypatch.setattr(report, "backend_version", lambda backend: "lastz 0.0 (another build)")
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert plot_main(_args(run)) == 0
    assert "plot: running" in caplog.text and (run.outdir / "overview.png").is_file()
    assert paint_main(_args(run)) == 0                                     # its assembly leaves the stats part out
    assert "D_pav" not in {r.test for r in read_stats(run.outdir / "stats.tsv")}
    assert report.assembled_parts(run.outdir / "stats.tsv")["stats"] == (
        "left_out", "LASTZ's version differs (now lastz 0.0 (another build))")
    capsys.readouterr()
    assert plot_main(_args(run)) == 1
    err = capsys.readouterr().err.strip().splitlines()[-1]
    assert err.startswith("error: stats.tsv in ") and ("(the stats part: left out when stats.tsv was last assembled: "
                                                       "LASTZ's version differs (now lastz 0.0 (another build))): "
                                                       "rerun the analyses") in err
    caplog.clear()
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert stats_main(ident) == 0
    assert "stats: running" in caplog.text and "stats: done, skip" not in caplog.text
    meta = json.loads((run.outdir / "work" / "analysis" / "stats.done.json").read_text())["meta"]
    assert meta["params"]["backend_version"] == "lastz 0.0 (another build)"
    assert report.assembled_parts(run.outdir / "stats.tsv")["stats"][0] == "key" and plot_main(_args(run)) == 0


def test_identity_key_holds_the_aligner_version(tmp_path, toy_fastas, monkeypatch):
    """LASTZ runs outside the fingerprint, so the --identity stats key holds its version
    (localign.backend_version); without --identity it is not in the key."""
    cat = write_run(tmp_path, [loc(10_001, "R:P* S:E D:P* O:E")], fasta_dir=toy_fastas).load()
    params = report.stage_params(cat, "stats", None, True)
    assert (params["backend"], params["backend_version"]) == (DEFAULT_BACKEND, backend_version(DEFAULT_BACKEND))
    assert "backend_version" not in report.stage_params(cat, "stats", None, False)
    def key(identity):
        return stage_key("stats", report.stage_inputs(cat, "stats", identity),
                         report.stage_params(cat, "stats", None, identity),
                         fingerprint=report.analysis_fingerprint("stats"))

    before = {x: key(x) for x in (False, True)}
    monkeypatch.setattr(report, "backend_version", lambda backend: "lastz 0.0 (another build)")
    after = {x: key(x) for x in (False, True)}
    assert after[False] == before[False] and after[True] != before[True]
    inputs = report.stage_inputs(cat, "stats", True)
    assert {f"fasta:{x}" for x in cat.labels} <= set(inputs) and "fasta:R" not in report.stage_inputs(
        cat, "stats", False)
    assert {"samples", "loci.tsv", "qc.tsv", "work/elements/R.tsv", "pairs/R__S.calls.tsv.gz", "fai:O"} <= set(inputs)


def test_never_checks_engine_fingerprints(tmp_path, toy_fastas, monkeypatch):
    """The analysis commands read a finished run as data. The toy's pair files
    carry no done markers, which the engine's checks would refuse; here those checks also fail the test if
    called, and so does any engine stage fingerprint."""
    def refuse(*args, **kwargs):
        raise AssertionError("an engine-fingerprint check was called")
    for name in ("_check_pair_files", "_pair_files"):
        monkeypatch.setattr(cli, name, refuse)
    monkeypatch.setattr(checkpoint, "stage_fingerprint", refuse)
    run = write_run(tmp_path, [loc(10_001, "R:P* S:E D:P* O:E"), loc(20_001, "R:E S:P* D:P* O:E")],
                    fasta_dir=toy_fastas)
    assert not list((run.outdir / "pairs").glob("*.done.json"))
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0


def test_assemble(tmp_path, monkeypatch):
    """stats.tsv: one header row, then the parts of the finished stages (a marker) in STAGES order. findings.txt:
    the version and run directory, each section under its name in SECTIONS order, a closing Warnings section
    repeating every WARNING; parts made with different --trio options are warned about."""
    out = tmp_path / "run"
    work = out / "work" / "analysis"
    f = Findings()
    f.add("Trio tests", "t1")
    f.warn("Run", "w1")
    f.add("Run", "r1")
    g = Findings()
    g.add("Painting", "p1\twith a tab\nand a newline")
    g.add("Run", "r2")
    a = write_part(out, "stats", [StatRow("pav", "sharing", "R,S,D", "all", "n_R+S", 3, n=7)], f)
    b = write_part(out, "paint", [StatRow("pav", "paint", "R,S;D", "all", "pi", 0.25)], g)
    assert a == [work / "stats.rows.tsv", work / "stats.findings.tsv"]
    row_a, row_b = "pav\tsharing\tR,S,D\tall\tn_R+S\t3\t.\t.\t7\t.\t.", "pav\tpaint\tR,S;D\tall\tpi\t0.25\t.\t.\t.\t.\t."
    key_a, key_b = (f"run\tpart\t{s}\tall\tkey\t{k}\t.\t.\t1\tnone\tthe {s} stage's part: its 1 row(s) follow, made "
                    f"under this stage key (work/analysis/{s}.done.json)" for s, k in (("stats", "k1"), ("paint", "k2")))
    mark_done(work / "stats.done.json", "k1", a, meta={"trio": None, "identity": False})
    stats, findings = assemble(out)
    assert (stats, findings) == (out / "stats.tsv", out / "findings.txt")
    assert stats.read_text().splitlines() == ["\t".join(STATS_COLUMNS), key_a, row_a]   # paint: no marker, left out
    assert report.assembled_parts(stats) == {"stats": ("key", "k1")}
    mark_done(work / "paint.done.json", "k2", b, meta={"trio": ["R", "S", "D"], "identity": False})
    stats, findings = assemble(out)
    assert stats.read_text().splitlines() == ["\t".join(STATS_COLUMNS), key_a, row_a, key_b, row_b]
    mismatch = ("WARNING: stats.tsv and findings.txt join parts made with different trios: the stats stage with "
                "the roles from the data, the paint stage with --trio R,S,D; rerun both with the same --trio")
    assert findings.read_text().splitlines() == [
        f"ltrpav {__version__} findings for the run in {out}", "",
        "Run", f"- {mismatch}", "- WARNING: w1", "- r1", "- r2", "",
        "Trio tests", "- t1", "",
        "Painting", "- p1\twith a tab and a newline", "",
        "Warnings", f"- Run: {mismatch}", "- Run: WARNING: w1"]
    mark_done(work / "paint.done.json", "k2", b, meta={"trio": None, "identity": False})
    monkeypatch.chdir(tmp_path)                                  # a relative run directory: named absolute
    lines = assemble(Path("run"))[1].read_text().splitlines()
    assert lines[0].endswith(f" {out}") and lines[-2:] == ["Warnings", "- Run: WARNING: w1"]
    with pytest.raises(ValueError, match="not a findings section"):
        write_part(out, "stats", [], _findings("Nowhere", "x"))
    stats, findings = assemble(out, {"paint": "its inputs changed (the samples sheet)"})
    assert stats.read_text().splitlines() == ["\t".join(STATS_COLUMNS), key_a, row_a,
                                             ("run\tpart\tpaint\tall\tleft_out\tits inputs changed (the samples sheet)"
                                              "\t.\t.\t.\tnone\tthe paint stage's part is left out of this file "
                                              "(findings.txt says why too)")]
    assert report.assembled_parts(stats)["paint"] == ("left_out", "its inputs changed (the samples sheet)")
    assert ("- WARNING: the paint part is left out of this file and stats.tsv: its inputs changed (the samples "
            "sheet); rerun ltrpav-paint (or ltrpav run)") in findings.read_text().splitlines()
    (work / "stats.findings.tsv").write_text("section\tline\nRun without a tab\n")
    with pytest.raises(AnalysisError, match="line 2 is not a findings section and a line: rerun the stats stage"):
        assemble(out)


def _findings(section: str, text: str) -> Findings:
    f = Findings()
    f.add(section, text)
    return f


def _mini(d: Path) -> Path:
    """tests/test_cli.py's mini world: A (annotated, one element) and B, unrelated 6-kb genomes."""
    rng = random.Random(1)
    toy.write_fasta(d / "A.fa", {"chr1": toy.rand_seq(6000, rng)})
    toy.write_fasta(d / "B.fa", {"chr1": toy.rand_seq(6000, rng)})
    write_gff3([element("A", "e", "chr1", 1001, 1000, 100)], d / "A.gff3")
    sheet = d / "samples.tsv"
    sheet.write_text("label\tfasta\tannotation\nA\tA.fa\tA.gff3\nB\tB.fa\t.\n")
    return sheet


def test_run_trio_fails_fast(tmp_path, capsys):
    """ltrpav run checks --trio against the sheet before any genotyping: one error line, nothing written; a
    --trio that is not three labels is a usage error."""
    sheet = _mini(tmp_path)
    base = ["--samples", str(sheet), "--outdir", str(tmp_path / "out")]
    for bad, message in (("A,B,Z", "'Z' is not a label"), ("A,A,B", "three different genomes")):
        assert main(["run", "--trio", bad, *base]) == 1
        err = capsys.readouterr().err
        assert err.startswith(f"error: --trio {bad}: ") and message in err and err.count("\n") == 1, err
    with pytest.raises(SystemExit) as exc:
        main(["run", "--trio", "A,B", *base])
    assert exc.value.code == 2 and not (tmp_path / "out").exists()


@needs_lastz
@pytest.mark.parametrize("stage", ["run_stats", "run_paint"])
def test_analysis_error_in_run_exits_3(tmp_path, caplog, capsys, monkeypatch, stage):
    """`ltrpav run`'s genotyping outputs are complete when the analyses
    start, and they are kept. A stats or paint failure logs one ERROR, ends stderr with exactly one error line
    (no traceback without -v) and exits 3; stats.tsv then holds only the stages that finished."""
    def planted(*args, **kwargs):
        raise ValueError("a planted analysis error")
    monkeypatch.setattr(report, stage, planted)
    out = tmp_path / "out"
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert main(["run", "--samples", str(_mini(tmp_path)), "--outdir", str(out), "--threads", "1"]) == 3
    errors = [r.getMessage() for r in caplog.records if r.levelno >= logging.ERROR]
    assert len(errors) == 1 and "planted" in errors[0] and "ltrpav-stats and ltrpav-paint" in errors[0], errors
    err = capsys.readouterr().err
    lines = err.strip().splitlines()
    assert lines[-1] == "error: analyses failed: ValueError: a planted analysis error"
    assert sum(ln.startswith("error:") for ln in lines) == 1 and "Traceback" not in err
    assert (out / "manifest.json").is_file() and (out / "loci.tsv").is_file()
    tests = {r.test for r in read_stats(out / "stats.tsv")}
    assert ("catalog" in tests) == (stage == "run_paint") and "paint" not in tests   # the finished stages only


def test_failed_stage_leaves_the_assembled_files(tmp_path, toy_fastas, monkeypatch, capsys):
    """A stage that fails has cleared its marker, and stats.tsv and findings.txt are reassembled without its
    part: they never hold a part whose stage is not finished."""
    def planted(*args, **kwargs):
        raise ValueError("a planted analysis error")
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0
    monkeypatch.setattr(report, "run_stats", planted)
    assert stats_main([*_args(run), "--trio", "R,S,D"]) == 1           # another key: the stage reruns, and fails
    assert capsys.readouterr().err.strip().splitlines()[-1] == "error: a planted analysis error"
    tests = {r.test for r in read_stats(run.outdir / "stats.tsv")}
    assert "paint" in tests and "D_pav" not in tests and "Trio tests" not in (run.outdir / "findings.txt").read_text()


# ---------------------------------------------------------------- the analysis fingerprint


def _engine_closure(root: Path) -> set[str]:
    """The engine files the analysis and plot packages' static imports reach (tests/test_checkpoint.py's rule:
    imports anywhere in a module, TYPE_CHECKING blocks skipped, a package's __init__ counted only when imported
    from), relative to `root`. Not followed: ltrpav.cli, the engine's command layer that analysis/cli.py takes its
    parsers, logging and exit status from. Left out: ltrpav/__init__.py (the version, in every key anyway)."""

    def path_of(dotted):
        p = root.joinpath(*dotted.split(".")[1:])
        if p.is_dir() and (p / "__init__.py").is_file():
            return p / "__init__.py"
        return p.with_suffix(".py") if p.with_suffix(".py").is_file() else None

    def imports(path):
        pkg = ["ltrpav", *path.relative_to(root).with_suffix("").parts[:-1]]
        out = set()

        def visit(node):
            for child in ast.iter_child_nodes(node):
                if isinstance(child, ast.If) and "TYPE_CHECKING" in ast.unparse(child.test):
                    for c in child.orelse:
                        visit(c)
                    continue
                if isinstance(child, ast.Import):
                    out.update(a.name for a in child.names if a.name.split(".")[0] == "ltrpav")
                elif isinstance(child, ast.ImportFrom):
                    start = pkg[:len(pkg) - child.level + 1] if child.level else []
                    base = ".".join(start + ([child.module] if child.module else []))
                    if base.split(".")[0] == "ltrpav":
                        out.update(f"{base}.{a.name}" if path_of(f"{base}.{a.name}") else base for a in child.names)
                visit(child)
        visit(ast.parse(path.read_text()))
        return out

    analysis_files = {*(root / "analysis").rglob("*.py"), *(root / "plot").rglob("*.py")}
    seen, todo = set(), sorted(analysis_files)
    while todo:
        p = todo.pop()
        if p is not None and p not in seen and p != root / "cli.py":
            seen.add(p)
            todo.extend(path_of(m) for m in imports(p))
    return {p.relative_to(root).as_posix() for p in seen - analysis_files} - {"__init__.py"}


def test_engine_modules_are_the_import_closure():
    """ENGINE_MODULES is exactly the static import closure of the engine modules the analysis and plot packages
    import, so a new engine import fails here until ENGINE_MODULES follows it (no stale analysis key)."""
    root = Path(checkpoint.__file__).parent
    declared = {f.relative_to(root).as_posix() for n in ENGINE_MODULES for f in checkpoint._source_files(root, n)}
    closure = _engine_closure(root)
    assert declared == closure
    assert {"constants.py", "genotype.py", "localign.py", "classify.py", "checkpoint.py"} <= closure
    assert not closure & {"cli.py", "loci.py", "outputs/tables.py", "annotation/__init__.py"}


@pytest.fixture
def pkg(tmp_path, monkeypatch):
    """A copy of the ltrpav package that package_fingerprint reads instead of the installed one."""
    copy = tmp_path / "ltrpav"
    shutil.copytree(Path(checkpoint.__file__).parent, copy, ignore=shutil.ignore_patterns("__pycache__"))
    monkeypatch.setattr(checkpoint, "_ROOT", copy)
    checkpoint._fingerprint.cache_clear()
    yield copy
    checkpoint._fingerprint.cache_clear()


ALL = {"stats", "paint", "plot"}


@pytest.mark.parametrize("module, changed", [
    ("analysis/report.py", ALL), ("analysis/cli.py", ALL), ("analysis/catalog.py", ALL),
    ("genotype.py", ALL), ("localign.py", ALL), ("constants.py", ALL), ("classify.py", ALL), ("window.py", ALL),
    ("anchor/paf.py", ALL), ("checkpoint.py", ALL), ("samples.py", ALL), ("plot/__init__.py", {"plot"}),
    ("cli.py", set()), ("loci.py", set()), ("outputs/vcf.py", set()), ("annotation/gff3.py", set()),
    ("sim/genome.py", set()), ("__init__.py", set()),
])
def test_analysis_keys_follow_their_modules(pkg, module, changed):
    """An edit to the analysis package changes the analysis keys and leaves every engine
    stage key unchanged; an edit to an engine module the analyses run changes them; an edit to the engine's
    CLI, locus catalog, outputs, annotation loaders or simulator does not. The plot stage adds ltrpav.plot."""
    engine = {s: stage_key(s, {}, {}) for s in checkpoint.STAGE_MODULES}
    before = {s: analysis_fingerprint(s) for s in ALL}
    path = pkg / module
    path.write_bytes(path.read_bytes() + b"\n# an edit\n")
    checkpoint._fingerprint.cache_clear()
    after = {s: analysis_fingerprint(s) for s in ALL}
    assert {s for s in ALL if before[s] != after[s]} == changed
    if module.startswith(("analysis/", "plot/")):
        assert {s: stage_key(s, {}, {}) for s in checkpoint.STAGE_MODULES} == engine
    keys = {s: stage_key(s, {"loci.tsv": "l" * 64}, {}, fingerprint=after[s]) for s in ALL}
    assert len(set(keys.values())) == 3          # each stage keyed on its own name and fingerprint
    with pytest.raises(ValueError, match="no analysis stage"):
        analysis_fingerprint("genotype_pair")


# ---------------------------------------------------------------- identity.tsv, resume warnings, hand-edited markers


def test_paint_reads_identity_tsv_only_when_current(tmp_path, toy_fastas, caplog):
    """The paint stage reads identity.tsv only while the stats part that wrote it is current (lids follow the
    run's order, so after a re-merge its counts would be other loci's). Run alone after the run changed, it ignores
    the file with a WARNING, and the stats part's WARNING names its stale side files."""
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0
    ident = run.outdir / "identity.tsv"
    ident.write_text("\t".join(IDENTITY_COLUMNS) + "\n")      # as a --identity stats run leaves it, here empty
    assert report.identity_usable(run.load()) == (True, None)
    assert paint_main(_args(run)) == 0
    paint_marker = run.outdir / "work" / "analysis" / "paint.done.json"
    assert json.loads(paint_marker.read_text())["meta"]["params"]["identity"] is True
    assert "identity.tsv is ignored" not in (run.outdir / "findings.txt").read_text()
    simulate_run(tmp_path, seed=2, fasta_dir=toy_fastas)      # the run is re-merged; identity.tsv stays
    usable, why = report.identity_usable(run.load())
    assert not usable and why.startswith("the stats part that wrote it is stale (its inputs changed (loci.tsv")
    caplog.clear()
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert paint_main(_args(run)) == 0                    # ltrpav-paint alone, without ltrpav-stats
    warn = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert any(m.startswith("paint: identity.tsv is ignored: the stats part that wrote it is stale") for m in warn)
    stats_left = [m for m in warn if m.startswith("stats: its part is left out")]
    assert len(stats_left) == 1
    assert stats_left[0].endswith("; inversions.tsv, mechanisms.tsv and identity.tsv, written with that part, are "
                                  "stale too")
    text = (run.outdir / "findings.txt").read_text()
    assert "WARNING: identity.tsv is ignored" in text and "identity.tsv, written with that part, are stale too" in text
    assert json.loads(paint_marker.read_text())["meta"]["params"]["identity"] is False


def test_resume_without_identity_warns(tmp_path, toy_fastas, caplog):
    """A stats run without --identity that deletes identity.tsv says so in one WARNING naming the file and
    that --identity keeps it."""
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    (run.outdir / "identity.tsv").write_text("\t".join(IDENTITY_COLUMNS) + "\n")
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert stats_main(_args(run)) == 0
    warn = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING and "identity.tsv" in r.getMessage()]
    assert len(warn) == 1 and warn[0].startswith("stats: deleting identity.tsv") and "with --identity to keep it" in warn[0]
    assert not (run.outdir / "identity.tsv").exists()


def test_hand_edited_marker_reads_as_stale(tmp_path, toy_fastas):
    """A marker edited by hand (a parameter the current key lacks, another key) reads as stale, never as a
    KeyError."""
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0
    marker = run.outdir / "work" / "analysis" / "stats.done.json"
    rec = json.loads(marker.read_text())
    rec["key"] = "edited"
    rec["meta"]["params"]["backend_version"] = "lastz 9.9"
    marker.write_text(json.dumps(rec))
    assert report.stale_parts(run.load(), warn=False) == {"stats": "its parameters differ (backend_version)"}


# ---------------------------------------------------------------- the stage options, the block size


def _meta(run, stage: str) -> dict:
    """A stage marker's meta (the options it recorded, and what its key was made of)."""
    return json.loads((run.outdir / "work" / "analysis" / f"{stage}.done.json").read_text())["meta"]


def test_paint_has_no_variant_options(tmp_path, toy_fastas, capsys):
    """Painting has one model (discovery in the recipient, EM-fitted emissions): `ltrpav-paint` and `ltrpav run`
    take neither --discovery nor --emission (a usage error, exit 2), and the paint stage records no option."""
    with pytest.raises(SystemExit) as exc:
        paint_main(["--help"])
    assert exc.value.code == 0
    helptext = capsys.readouterr().out
    assert "--discovery" not in helptext and "--emission" not in helptext
    run = simulate_run(tmp_path, seed=1, tracts=TRACTS, fasta_dir=toy_fastas)
    for option in (["--discovery", "any"], ["--emission", "decoy"]):
        with pytest.raises(SystemExit) as exc:
            paint_main([*_args(run), *option])
        assert exc.value.code == 2
        with pytest.raises(SystemExit) as exc:
            main(["run", *_args(run), *option])
        assert exc.value.code == 2
    assert paint_main(_args(run)) == 0
    assert {r.value for r in read_stats(run.outdir / "stats.tsv")
            if r.test == "paint" and r.statistic == "emission"} == {"em"}
    assert "discovery" not in _meta(run, "paint")["params"] and "emission" not in _meta(run, "paint")["params"]


def test_block_size_option(tmp_path, toy_fastas, capsys):
    """ltrpav-stats --block-size BP replaces the default block rule (stats.block_size; here
    1/100 of the 4-Mb toy genome, 40 kb) in the stats stage's jackknives, and stats.tsv says which in its
    block_bp row. 1-Mb blocks give the toy's four 1-Mb
    sequences one block each, enough for a jackknife: D_pav's se is finite and differs from the rule's. Below
    BLOCK_MIN, or not an integer, is a usage error (exit 2)."""
    run = simulate_run(tmp_path, seed=1, tracts=TRACTS, fasta_dir=toy_fastas)

    def rows():
        got = read_stats(run.outdir / "stats.tsv")
        bp = [(r.value, r.n, r.loci, r.note) for r in got
              if (r.layer, r.test, r.scope, r.stratum, r.statistic) == ("pav", "jackknife", "all", "all", "block_bp")]
        d = [r for r in got if (r.test, r.scope, r.stratum, r.statistic) == ("D_pav", "R,S;D", "all", "D")]
        return bp, d[0]

    assert stats_main(_args(run)) == 0
    bp, rule = rows()
    assert bp == [(40_000, None, "none", "rule")] and _meta(run, "stats")["block_size"] is None
    assert stats_main([*_args(run), "--block-size", "1000000"]) == 0
    bp, mb = rows()
    assert bp == [(1_000_000, None, "none", "--block-size")] and _meta(run, "stats")["block_size"] == 1_000_000
    assert "4 jackknife blocks of 1,000,000 bp" in mb.note
    assert math.isfinite(mb.se) and mb.se != rule.se and mb.value == rule.value
    for bad in ("5", str(BLOCK_MIN - 1), "1e6", "x"):
        capsys.readouterr()
        with pytest.raises(SystemExit) as exc:
            stats_main([*_args(run), "--block-size", bad])
        err = capsys.readouterr().err.strip().splitlines()[-1]
        assert exc.value.code == 2 and "--block-size" in err, err
    assert stats_main([*_args(run), "--block-size", str(BLOCK_MIN)]) == 0
    assert rows()[0] == [(BLOCK_MIN, None, "none", "--block-size")]


def test_left_out_advice_names_the_options(tmp_path, toy_fastas, caplog):
    """A stale stats part made with a non-default --block-size is left out with advice that remakes it with the
    same option, and says that `ltrpav run` remakes it at the defaults; a stale default part keeps the plain
    advice, in the WARNING and in findings.txt."""
    run = simulate_run(tmp_path, seed=1, tracts=TRACTS, fasta_dir=toy_fastas)
    marker = run.outdir / "work" / "analysis" / "stats.done.json"
    again = "(ltrpav run remakes it at the defaults)"
    for options, advice in (([], "ltrpav-stats (or ltrpav run)"),
                            (["--block-size", "1000000"], f"ltrpav-stats --block-size 1000000 {again}")):
        assert stats_main([*_args(run), *options]) == 0
        rec = json.loads(marker.read_text())
        rec["key"] = "edited"
        rec["meta"]["params"]["backend_version"] = "lastz 9.9"          # stale: the key no longer matches
        marker.write_text(json.dumps(rec))
        caplog.clear()
        with caplog.at_level(logging.WARNING, logger="ltrpav"):
            stale = report.stale_parts(run.load())
        assert "stats" in stale
        warned = [r.getMessage() for r in caplog.records
                  if "left out" in r.getMessage() and r.getMessage().startswith("stats:")]
        assert len(warned) == 1 and f"stage reruns, with {advice}: " in warned[0]
        report.assemble(run.outdir, stale)
        left = [ln for ln in (run.outdir / "findings.txt").read_text().splitlines() if "stats part is left out" in ln]
        assert len(left) == 2 and all(ln.endswith(f"; rerun {advice}") for ln in left)   # Run and Warnings


@needs_lastz                                       # --identity needs the window aligner on PATH
def test_block_size_reaches_every_jackknife(tmp_path, toy_fastas, monkeypatch):
    """--block-size is one `size` that run_stats hands to the trio tests, to direction and to the identity layer
    (stats.block_size): each of the three receives the 1-Mb block, and the default rule's 40 kb without the
    option."""
    run = simulate_run(tmp_path, seed=1, tracts=TRACTS, fasta_dir=toy_fastas)
    seen: dict[str, set] = {}
    for name in ("trio_tests", "direction", "identity_layer"):
        real = getattr(report, name)

        def spy(*args, _real=real, _name=name, **kwargs):
            seen.setdefault(_name, set()).add(args[1] if _name == "direction" else args[2])
            return ([], Findings(), []) if _name == "identity_layer" else _real(*args, **kwargs)   # no LASTZ alignment
        monkeypatch.setattr(report, name, spy)
    for options, size in (([], 40_000), (["--block-size", "1000000"], 1_000_000)):
        seen.clear()
        assert stats_main([*_args(run), "--identity", *options]) == 0
        assert seen == {"trio_tests": {size}, "direction": {size}, "identity_layer": {size}}, seen


def test_plot_accepts_default_options(tmp_path, toy_fastas, caplog, capsys):
    """The plot stage's refusal rules (report.plot_refusals) hold with the options: stats and paint at their
    defaults (their markers record them) are drawn; a stats marker whose recorded option no longer gives its
    key is refused, and nothing is drawn."""
    run = simulate_run(tmp_path, seed=1, tracts=TRACTS, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0
    stats, paint = _meta(run, "stats"), _meta(run, "paint")
    assert stats["block_size"] is None and stats["params"]["block_size"] is None
    assert not {"block_size", "discovery", "emission"} & set(paint["params"])
    assert not {"discovery", "emission"} & set(stats["params"])
    assert plot_main(_args(run)) == 0 and (run.outdir / "overview.png").is_file()
    marker = run.outdir / "work" / "analysis" / "stats.done.json"
    rec = json.loads(marker.read_text())
    rec["meta"]["block_size"] = 1_000_000              # not the block size the part's key was made with
    marker.write_text(json.dumps(rec))
    (marker.parent / "plot.done.json").unlink()        # no file the figure's key holds changed: rerun its check
    capsys.readouterr()
    assert plot_main(_args(run)) == 1
    err = capsys.readouterr().err.strip().splitlines()[-1]
    assert err.startswith("error: stats.tsv in ") and "the stats part: its parameters differ (block_size)" in err
    assert not list(run.outdir.glob("overview*"))
