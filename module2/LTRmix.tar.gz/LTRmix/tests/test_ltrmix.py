"""End-to-end tests on tiny synthetic trios: planted tract, inversion and decoy family; a true-negative trio."""
import os
import sys

import numpy as np
import pandas as pd
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)
import ltrmix  # noqa: E402
from synth import make_trio  # noqa: E402


def _run(tmp, admix, seed=3):
    paths, truth, tract, inv = make_trio(os.path.join(tmp, "in"), seed=seed, admix=admix)
    out = os.path.join(tmp, "out")
    ltrmix.main([f"--genome=R={paths['R']}", f"--genome=S={paths['S']}", f"--genome=D={paths['D']}",
                 "--outdir", out, "-t", "2"])
    st = pd.read_csv(os.path.join(out, "stats.tsv"), sep="\t")
    return out, st, truth, tract, inv


@pytest.fixture(scope="module")
def admixed(tmp_path_factory):
    return _run(str(tmp_path_factory.mktemp("adm")), True)


@pytest.fixture(scope="module")
def null(tmp_path_factory):
    return _run(str(tmp_path_factory.mktemp("null")), False)


def _row(st, test, stratum="all"):
    r = st[(st.test == test) & (st.stratum == stratum)]
    assert len(r) == 1, (test, stratum)
    return r.iloc[0]


def test_sister_pair_inferred(admixed):
    out, st, *_ = admixed
    txt = open(os.path.join(out, "findings.txt")).read()
    assert "Sister pair (most single-copy k-mers shared): R + S" in txt


def test_orthology_precision(admixed):
    out, st, truth, tract, inv = admixed
    e = pd.read_csv(os.path.join(out, "elements.R.tsv"), sep="\t")
    e = e[~e.name.str.contains("fam9")]           # decoy copies have no orthologs by construction
    t = pd.DataFrame(truth)
    t = t[t.carriers.str.contains("R")]
    pres_true = set(zip(t.chrom, t.pos, t.carriers.str.contains("D")))
    # element start = locus position for R (no shift)
    e["c"] = e.chrom.str.extract(r"chr(\d+)")[0].astype(int)
    m = e.merge(t.assign(c=t.chrom, start=t.pos)[["c", "start", "carriers"]], on=["c", "start"])
    called = m[f"in_D"] == "present"
    true = m.carriers.str.contains("D")
    prec = (called & true).sum() / max(called.sum(), 1)
    rec = (called & true).sum() / max(true.sum(), 1)
    assert prec > 0.95 and rec > 0.8, (prec, rec)


def test_decoy_not_orthologous(admixed):
    out, *_ = admixed
    e = pd.read_csv(os.path.join(out, "elements.R.tsv"), sep="\t")
    d = e[e.name.str.contains("fam9")]
    assert (d.in_D == "present").mean() < 0.2


def test_D_positive_when_admixed(admixed):
    out, st, *_ = admixed
    for test in ("D_kmer", "D_ins"):
        r = _row(st, test)
        assert r.D > 0 and r.Z > 3, (test, r.D, r.Z)


def test_D_null_when_not_admixed(null):
    out, st, *_ = null
    for test in ("D_kmer", "D_ins"):
        r = _row(st, test)
        assert abs(r.Z) < 3, (test, r.D, r.Z)


def test_tract_recovered(admixed):
    out, st, truth, tracts, inv = admixed
    b = pd.read_csv(os.path.join(out, "tracts.R.bed"), sep="\t")
    b.columns = [c.lstrip("#") for c in b.columns]
    inside = np.zeros(len(b), bool)
    for c, s0, e0 in tracts:
        ov = (b.chrom == f"R_chr{c}") & (b["end"] > s0) & (b["start0"] < e0)
        inside |= ov.values
        covered = sum(min(r["end"], e0) - max(r["start0"], s0) for _, r in b[ov].iterrows())
        assert covered / (e0 - s0) > 0.6, (c, s0, e0, covered)
    assert (b[~inside]["q"] <= 0.05).sum() == 0


def test_no_confident_tracts_when_not_admixed(null):
    out, *_ = null
    b = pd.read_csv(os.path.join(out, "tracts.R.bed"), sep="\t")
    assert (b["q"] <= 0.05).sum() == 0


def test_inversion_found(admixed):
    out, st, truth, tract, inv = admixed
    v = pd.read_csv(os.path.join(out, "inversions.tsv"), sep="\t")
    v = v[(v.chrom_a.str.endswith(f"chr{inv[0]}")) & (v.n_anchor >= 10)]
    assert len(v) >= 1


def test_four_genomes_fratio(tmp_path):
    """Four genomes (a second donor E, sister of D): every trio runs and the f-ratio is reported."""
    paths, truth, tracts, inv = make_trio(str(tmp_path / "in"), seed=5, admix=True)
    # second donor: D's library with light extra mutation (a sister of D)
    import numpy as np
    rng = np.random.default_rng(9)
    fa, tb = paths["D"].split(",")
    seqs = open(fa).read().split(">")[1:]
    with open(tmp_path / "E.fa", "w") as f:
        for rec in seqs:
            name, seq = rec.split("\n", 1)
            seq = list(seq.replace("\n", ""))
            for i in rng.choice(len(seq), max(1, len(seq) // 400), replace=False):
                seq[i] = "ACGT"[("ACGT".index(seq[i]) + 1) % 4]
            f.write(f">{name.replace('D_', 'E_')}\n{''.join(seq)}\n")
    with open(tb) as fi, open(tmp_path / "E.tsv", "w") as fo:
        for line in fi:
            fo.write(line.replace("D_", "E_"))
    out = str(tmp_path / "out")
    ltrmix.main([f"--genome=R={paths['R']}", f"--genome=S={paths['S']}", f"--genome=D={paths['D']}",
                 f"--genome=E={tmp_path / 'E.fa'},{tmp_path / 'E.tsv'}", "--outdir", out, "-t", "2"])
    st = pd.read_csv(os.path.join(out, "R_S_D", "stats.tsv"), sep="\t")
    r = st[st.test == "f_ratio_ins"]
    assert len(r) == 1 and np.isfinite(r.iloc[0]["alpha"])


def test_overview_figure(admixed):
    """main() draws the overview figure of the trio next to its tables."""
    out = admixed[0]
    for f in ("overview.png", "overview.pdf", "overview_numbers.tsv"):
        assert os.path.getsize(os.path.join(out, f)) > 0
