"""LTRpav: genotype LTR-retrotransposon presence/absence across genome assemblies, then run the gene-flow
analyses on it (D_pav trio tests, painting of introgressed tracts, inversions, mechanisms), draw the
overview figure; ltrpav-sim simulates genomes with known truth."""
import os

# Must run before numpy is imported anywhere: transparent huge pages make numpy
# allocations balloon resident memory on large arrays.
os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")

__version__ = "0.1.0"
