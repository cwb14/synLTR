#!/usr/bin/env bash
# Rebuild the test renders of LTRmix/ltrmix_plot.py in this folder (inputs are symlinked; results stay read-only).
# usage: bash build_renders.sh
set -euo pipefail
source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix
FD=/data2/chris/maize_introgression/benchmark/figures/ltrmix_plot
PLOT=/data2/chris/maize_introgression/LTRmix/ltrmix_plot.py
link() {  # link <dir> <source dir> <files...>
  local d=$1 src=$2; shift 2; mkdir -p "$d"
  for f in "$@"; do [ -e "$src/$f" ] && ln -sf "$src/$f" "$d/$f"; done
}
link $FD/test_main3 /data2/chris/maize_introgression/benchmark/results/main3 \
  stats.tsv findings.txt elements.B73v5.tsv tracts.B73v5.bed ancestry.B73v5.bed decoy_tracts.TIL01.bed blocks.tsv
link $FD/test_sim /data2/chris/maize_introgression/benchmark/sim/out/f0.18_Ta5000_r1 \
  stats.tsv findings.txt elements.B.tsv tracts.B.bed ancestry.B.bed decoy_tracts.P.bed blocks.tsv
link $FD/test_devnear /data2/chris/maize_introgression/benchmark/results/dev/v_near \
  stats.tsv findings.txt elements.B73v5.tsv tracts.B73v5.bed          # older format, optional files absent
for t in test_main3 test_sim test_devnear; do /usr/bin/time -f "$t %e s wall %U s user %M KB" python $PLOT $FD/$t; done
cp $FD/test_main3/overview.png $FD/ltrmix_plot.png
cp $FD/test_main3/overview.pdf $FD/ltrmix_plot.pdf
cp $FD/test_main3/overview_numbers.tsv $FD/ltrmix_plot_numbers.tsv
cp $FD/test_sim/overview.png $FD/ltrmix_plot_sim.png
cp $FD/test_sim/overview.pdf $FD/ltrmix_plot_sim.pdf
cp $FD/test_sim/overview_numbers.tsv $FD/ltrmix_plot_sim_numbers.tsv
