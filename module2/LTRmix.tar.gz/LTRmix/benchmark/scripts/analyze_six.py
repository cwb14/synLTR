#!/usr/bin/env python3
"""Six-genome follow-up (B73v5, TIL18, TIL01, PT, TIL25, TIL11): trio summary, negative control, direction of gene
flow (does TIL18 carry maize-derived haplotypes?), PT positive control (mexicana ancestry, HPC1 with TIL25, Inv4m),
admixture fractions with a second donor. Reads ltrmix outputs only (plus ELAI truth for B73 coordinates)."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import glob
import os
import re
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, "/data2/chris/maize_introgression/benchmark/scripts")
from eval_real import load_truth  # noqa: E402

SIX = sys.argv[1] if len(sys.argv) > 1 else "/data2/chris/maize_introgression/benchmark/results/six"
OUT = os.path.join(SIX, "analysis")
os.makedirs(OUT, exist_ok=True)


def trio_summary():
    rows = []
    for d in sorted(glob.glob(os.path.join(SIX, "*_*_*"))):
        if not os.path.exists(os.path.join(d, "stats.tsv")):
            continue
        st = pd.read_csv(os.path.join(d, "stats.tsv"), sep="\t")
        f = open(os.path.join(d, "findings.txt")).read()
        m = re.search(r"Sister pair \(most single-copy k-mers shared\): (\S+) \+ (\S+); third genome: (\S+)\.", f)
        r = dict(trio=os.path.basename(d), sister1=m[1], sister2=m[2], donor=m[3],
                 recipient=re.search(r"D\(single-copy k-mers; (\S+?),", f)[1])
        for t, s in (("D_kmer", "all"), ("D_ins", "all"), ("D3_triples", "all"), ("D_self_outgroup", "LTR sites")):
            x = st[(st.test == t) & (st.stratum == s)]
            if len(x):
                r[f"{t}"] = float(x.iloc[0]["D"])
                r[f"{t}_Z"] = float(x.iloc[0]["Z"])
        for t, c in (("f_lower_bound", "f"), ("completeness_ratio", "ratio")):
            x = st[st.test == t]
            if len(x):
                r[t] = float(x.iloc[0][c])
                if "SE" in x and pd.notna(x.iloc[0].get("SE")):
                    r[t + "_SE"] = float(x.iloc[0]["SE"])
        for t in ("f_ratio_ins", "f_ratio_identity"):
            x = st[st.test == t]
            for _, xx in x.iterrows():
                r[f"{t}[{xx.stratum.replace('second donor ', '')}]"] = float(xx["alpha"])
                if t == "f_ratio_ins":
                    r[f"{t}_SE[{xx.stratum.replace('second donor ', '')}]"] = float(xx["SE"])
        for mode in ("ancestry", "recent"):
            x = st[st.test == f"hmm_{mode}"]
            if len(x):
                x = x.iloc[0]
                r[f"{mode}_excess"] = float(x.excess_over_decoy)
                r[f"{mode}_tracts_q05"] = int(x.n_tracts_q05)
                r[f"{mode}_tracts"] = int(x.n_tracts)
                r[f"{mode}_decoys"] = int(x.n_decoy_tracts)
        rows.append(r)
    t = pd.DataFrame(rows)
    t.to_csv(os.path.join(OUT, "trio_summary.tsv"), sep="\t", index=False)
    return t


def mapped_mid(ortho_tsv, elements):
    """Map elements (names of genome A) to genome B midpoints through orthologs.A.B (present only)."""
    o = pd.read_csv(ortho_tsv, sep="\t")
    a, b = o.columns[0], o.columns[6]
    o = o[o.iloc[:, 5] == "present"]
    m = o.set_index(a)[b]
    return m.reindex(elements)


def main():
    t = trio_summary()
    cols = [c for c in ["trio", "sister1", "sister2", "donor", "recipient", "D_kmer_Z", "D_ins_Z", "D3_triples_Z",
                        "D_self_outgroup_Z", "D_ins", "D_self_outgroup", "f_lower_bound", "completeness_ratio",
                        "recent_tracts_q05", "ancestry_excess"] if c in t]
    with pd.option_context("display.width", 260, "display.max_columns", 30):
        print(t[cols].round(3).to_string(index=False))
        fr = [c for c in t.columns if c.startswith("f_ratio")]
        print(t[["trio", "recipient", "donor"] + fr].dropna(how="all", subset=fr).round(3).to_string(index=False))
    # direction: TIL18 vs TIL25 sharing with maize; map TIL18's maize-like recent tracts to B73 coordinates
    res = []
    for tri in t.itertuples():
        if {tri.sister1, tri.sister2} == {"TIL18", "TIL25"} and tri.donor in ("B73v5", "PT"):
            res.append(f"Direction ({tri.donor} as donor): recipient {tri.recipient}; D_kmer Z {tri.D_kmer_Z:.1f}, "
                       f"D_ins Z {tri.D_ins_Z:.1f}, D3 Z {tri.D3_triples_Z:.1f}, D_self Z {tri.D_self_outgroup_Z:.1f}; "
                       f"recent tracts q<=0.05: {getattr(tri, 'recent_tracts_q05', 'na')}")
    tdir = os.path.join(SIX, "B73v5_TIL18_TIL25")
    b73dir = os.path.join(SIX, "B73v5_TIL18_TIL01")
    if os.path.exists(os.path.join(tdir, "tracts.TIL18.bed")) and os.path.exists(os.path.join(b73dir, "tracts.B73v5.bed")):
        # TIL18 elements inside TIL18's B73-like recent tracts -> B73 coordinates
        e = pd.read_csv(os.path.join(tdir, "elements.TIL18.tsv"), sep="\t")
        tr = pd.read_csv(os.path.join(tdir, "tracts.TIL18.bed"), sep="\t")
        tr.columns = [c.lstrip("#") for c in tr.columns]
        tr = tr[tr.q <= 0.05]
        inside = np.zeros(len(e), bool)
        for r_ in tr.itertuples():
            inside |= ((e.chrom == r_.chrom) & (e.start >= r_.start0) & (e.end <= r_.end)).values
        mp = mapped_mid(os.path.join(SIX, "orthologs.TIL18.B73v5.tsv.gz"), e.name[inside])
        bnames = mp.dropna()
        bm = bnames.str.extract(r"_(chr\d+):(\d+)-(\d+)#")
        bm = bm.dropna()
        bm.columns = ["c", "s", "e"]
        bm["mid"] = (bm.s.astype(int) + bm.e.astype(int)) // 2
        # B73's own confident recent tracts with TIL18 (trio 1) and their ELAI
        bt = pd.read_csv(os.path.join(b73dir, "tracts.B73v5.bed"), sep="\t")
        bt.columns = [c.lstrip("#") for c in bt.columns]
        bt = bt[bt.q <= 0.05].copy()
        bt["c"] = bt.chrom.str.extract(r"_(chr\d+)$")[0]
        truth = load_truth()
        truth = truth[truth["B73.amp"] > -900]
        rows = []
        for r_ in bt.itertuples():
            n_til18 = int(((bm.c == r_.c) & (bm.mid >= r_.start0) & (bm.mid <= r_.end)).sum())
            g = truth[(truth.chrom == r_.c) & (truth.pos >= r_.start0) & (truth.pos <= r_.end)]
            rows.append(dict(chrom=r_.c, start=r_.start0, end=r_.end, n_elements=r_.n_elements,
                             elai_anc=g["B73.amp"].mean() / 2 if len(g) else np.nan,
                             til18_maize_tract_elements=n_til18))
        o = pd.DataFrame(rows)
        o["til18_maize_like"] = o.til18_maize_tract_elements > 0
        o.to_csv(os.path.join(OUT, "b73_recent_tracts_vs_til18_maize_tracts.tsv"), sep="\t", index=False)
        if len(o):
            a = o[o.til18_maize_like]
            b = o[~o.til18_maize_like]
            res.append(f"B73 recent-sharing tracts (q<=0.05) overlapping TIL18's maize-like tracts: {len(a)}/{len(o)}; "
                       f"ELAI ancestry in those {a.elai_anc.mean():.3f} vs others {b.elai_anc.mean():.3f} "
                       f"(genome {truth['B73.amp'].mean() / 2:.3f})")
    # PT positive control
    for tri in t.itertuples():
        if {tri.sister1, tri.sister2} == {"B73v5", "PT"} and tri.donor in ("TIL18", "TIL25"):
            res.append(f"PT vs B73 with {tri.donor} as donor: recipient {tri.recipient} (D_kmer Z {tri.D_kmer_Z:.1f}, "
                       f"D_ins Z {tri.D_ins_Z:.1f}, D3 Z {tri.D3_triples_Z:.1f}, D_self Z {tri.D_self_outgroup_Z:.1f})")
    # HPC1 in PT with TIL25 (Barnes: PT and TIL25 share the introgressed HPC1 haplotype)
    loci = pd.read_csv("/data2/chris/maize_introgression/benchmark/truth/loci.v5.tsv", sep="\t").set_index("name")
    for donor in ("TIL25", "TIL18"):
        d = os.path.join(SIX, f"TIL01_PT_{donor}") if donor == "TIL25" else os.path.join(SIX, "TIL18_TIL01_PT")
        f = os.path.join(d, "elements.PT.tsv")
        if not os.path.exists(f):
            continue
        ept = pd.read_csv(f, sep="\t")
        b = pd.read_csv(os.path.join(SIX, "orthologs.B73v5.PT.tsv.gz"), sep="\t")
        for locus in ("HPC1", "ZmLPCAT1", "ZmPRR37a"):
            L = loci.loc[locus]
            for fl in (50_000, 200_000):
                nb = b[(b.chrom == f"B73v5_chr{L.chrom}") & (b.end >= L.start - fl) & (b.start <= L.end + fl) &
                       (b.status_in_PT == "present")]
                if not len(nb):
                    res.append(f"{locus} +-{fl // 1000} kb: no B73 element with a PT ortholog")
                    continue
                pm = nb.PT.str.extract(r"_(chr\d+):(\d+)-(\d+)#").dropna()
                c = pm[0].mode()[0]
                lo, hi = pm[1].astype(int).min(), pm[2].astype(int).max()
                w = ept[(ept.chrom == f"PT_{c}") & (ept.end >= lo) & (ept.start <= hi)]
                pc = [x for x in w.columns if x.startswith("post_ancestry_")][0]
                rc = [x for x in w.columns if x.startswith("post_recent_")][0]
                res.append(f"PT at {locus} +-{fl // 1000} kb (via {len(nb)} B73 anchors; PT {c}:{lo}-{hi}) with {donor} as "
                           f"donor: {len(w)} PT elements, classes {w['class'].value_counts().to_dict()}, max ancestry "
                           f"posterior {w[pc].max():.3f}, max recent {w[rc].max():.3f}")
    # Inv4m in PT relative to B73 (B73 v5 chr4:172.88-188.13 Mb)
    bl = pd.read_csv(os.path.join(SIX, "blocks.tsv"), sep="\t")
    for (ga, gb), g in bl.groupby(["genome_a", "genome_b"]):
        if "B73v5" not in (ga, gb) or not ({"PT", "TIL18", "TIL25", "TIL01", "TIL11"} & {ga, gb}):
            continue
        g = g[g.chrom_a.str.endswith("chr4") & g.chrom_b.str.endswith("chr4")]
        if not len(g):
            continue
        dom = 1 if g[g.sign == 1].n_anchor.sum() >= g[g.sign == -1].n_anchor.sum() else -1
        inv = g[g.sign != dom]
        if ga == "B73v5":
            ov = inv[(inv.end_a >= 172_883_881) & (inv.start_a <= 188_131_462)]
            sp = [f"{r.start_a / 1e6:.2f}-{r.end_a / 1e6:.2f} Mb ({r.n_anchor} anchors)" for r in ov.itertuples()]
        else:
            ov = inv[(inv.end_b >= 172_883_881) & (inv.start_b <= 188_131_462)]
            sp = [f"{r.start_b / 1e6:.2f}-{r.end_b / 1e6:.2f} Mb ({r.n_anchor} anchors)" for r in ov.itertuples()]
        res.append(f"Inv4m region, {ga} vs {gb}: inverted blocks in B73 coordinates: {'; '.join(sp) if sp else 'none'}")
    with open(os.path.join(OUT, "six_findings.txt"), "w") as fo:
        fo.write("\n".join(res) + "\n")
    print("\n".join(res))


if __name__ == "__main__":
    main()
