"""Annotation dispatcher: load any supported annotation into validated, nested Elements; and the cached
`elements` stage (elements_stage)."""
from __future__ import annotations

import glob
import json
import logging
import zlib
from collections import Counter
from dataclasses import replace
from pathlib import Path

import mappy

from ltrpav.annotation.bed import load_bed
from ltrpav.annotation.gff3 import load_gff3
from ltrpav.annotation.ltrquest import load_ltrquest
from ltrpav.checkpoint import atomic_path, atomic_write, clear_done, is_done, mark_done, marker, stage_key
from ltrpav.elements import Element, read_elements, write_elements
from ltrpav.seqio import Fasta

log = logging.getLogger(__name__)

_GFF_EXT = (".gff3", ".gff", ".gff3.gz", ".gff.gz")
_BED_EXT = (".bed", ".bed.gz")
_TSD_LENGTHS = (5, 4, 6)  # 5 bp is the modal LTR-RT TSD, then 4 and 6


class AnnotationError(ValueError):
    """Unusable annotation: unknown format, unreadable file, a missing required column, no usable record, or
    inconsistent with the FASTA."""


def assign_nesting(elements: list[Element]) -> list[Element]:
    """Set `parent` (eid of the innermost containing element) and `level` on each element.

    Sweeps per seqid in (start, -end) order with a stack. Partially overlapping
    elements stay on the stack but are never parents.
    """
    out: list[Element] = []
    stack: list[Element] = []  # already-annotated elements
    seqid = None
    for e in sorted(elements, key=lambda x: (x.seqid, x.start, -x.end)):
        if e.seqid != seqid:
            stack, seqid = [], e.seqid
        while stack and stack[-1].end < e.start:
            stack.pop()
        parent = next((p for p in reversed(stack) if p.end >= e.end), None)
        e = replace(e, parent=parent.eid, level=parent.level + 1) if parent else replace(e, parent=None, level=0)
        stack.append(e)
        out.append(e)
    return out


def infer_tsd(fasta: Fasta, e: Element) -> str | None:
    """Direct repeat flanking the element (5, 4, then 6 bp), or None. Element is 1-based inclusive."""
    for n in _TSD_LENGTHS:
        if e.start - 1 - n < 0:
            continue
        left = fasta.fetch(e.seqid, e.start - 1 - n, e.start - 1)
        right = fasta.fetch(e.seqid, e.end, e.end + n)
        if len(left) == n and len(right) == n and left == right and "N" not in left:
            return left
    return None


def loader_versions(spec: str) -> dict[str, str]:
    """The versions of the libraries the loader of `spec` aligns with, for the elements stage's key: mappy for
    a BED (its LTRs are found by self-alignment, bed.find_ltrs); none for GFF3 and LTRquest tables."""
    return {"mappy": mappy.__version__} if spec.lower().endswith(_BED_EXT) else {}


def annotation_files(spec: str) -> list[Path]:
    """The files `spec` names, as load_annotation reads it: the GFF3/BED file, or the LTRquest prefix's
    {prefix}_depth*_clean_ltr.tsv tables (sorted); [] if there are none."""
    if spec.lower().endswith(_GFF_EXT + _BED_EXT):
        return [Path(spec)] if Path(spec).is_file() else []
    return sorted(Path(p) for p in glob.glob(glob.escape(spec) + "_depth*_clean_ltr.tsv"))


def _dispatch(spec: str, genome: str, fasta: Fasta) -> tuple[list[Element], Counter]:
    low = spec.lower()
    if low.endswith(_GFF_EXT):
        if not Path(spec).is_file():
            raise AnnotationError(f"annotation file not found: {spec}")
        return load_gff3(Path(spec), genome)
    if low.endswith(_BED_EXT):
        if not Path(spec).is_file():
            raise AnnotationError(f"annotation file not found: {spec}")
        return load_bed(Path(spec), genome, fasta)
    if glob.glob(glob.escape(spec) + "_depth*_clean_ltr.tsv"):
        return load_ltrquest(spec, genome)
    raise AnnotationError(
        f"cannot detect annotation format of {spec!r}: expected .gff3/.gff/.bed (optionally .gz) "
        "or an LTRquest prefix with {prefix}_depth*_clean_ltr.tsv files"
    )


def _validate(elements: list[Element], lengths: dict[str, int], genome: str, spec: str) -> None:
    where = f"{genome}: annotation {spec}: "
    missing = sorted({e.seqid for e in elements if e.seqid not in lengths})
    if missing:
        raise AnnotationError(
            f"{where}{len(missing)} annotation seqid(s) absent from the FASTA: {', '.join(missing[:5])}"
            + (" ..." if len(missing) > 5 else "")
        )
    for e in elements:
        if e.end > lengths[e.seqid]:
            raise AnnotationError(
                f"{where}element {e.name} ({e.seqid}:{e.start}-{e.end}) ends beyond its sequence length "
                f"{lengths[e.seqid]}"
            )


def load_annotation(spec: str, genome: str, fasta: Fasta, skipped: Counter | None = None) -> list[Element]:
    """Load, validate, de-duplicate, nest and TSD-annotate one genome's LTR-RT annotation.

    `spec` is a GFF3/BED path or an LTRquest prefix. A malformed record is skipped by its loader with a warning
    naming its file and line; skip reasons (the loader's plus `duplicate`) are logged
    as one warning line and added to `skipped` if given. Structural problems fail with one AnnotationError
    line: an unknown format, an unreadable or corrupt file, a missing required column, records outside the
    FASTA, or no usable record at all.
    """
    try:
        elements, reasons = _dispatch(spec, genome, fasta)
    except AnnotationError:
        raise
    except (ValueError, OSError, EOFError, zlib.error) as exc:  # UnicodeDecodeError is a ValueError
        detail = str(exc) if isinstance(exc, (ValueError, FileNotFoundError)) else f"{type(exc).__name__}: {exc}"
        raise AnnotationError(f"{genome}: cannot read annotation {spec}: {detail}") from exc
    reasons = Counter(reasons)
    if not elements:
        why = ", ".join(f"{k}={reasons[k]}" for k in sorted(reasons)) or "no LTR-RT record in it"
        raise AnnotationError(f"{genome}: annotation {spec} holds no usable LTR-RT record ({why})")
    lengths = fasta.lengths()
    _validate(elements, lengths, genome, spec)

    seen: set[tuple[str, int, int]] = set()
    unique: list[Element] = []
    for e in elements:
        key = (e.seqid, e.start, e.end)
        if key in seen:
            reasons["duplicate"] += 1
            continue
        seen.add(key)
        unique.append(e)

    if reasons:
        detail = ", ".join(f"{k}={reasons[k]}" for k in sorted(reasons))
        log.warning("%s: skipped %d annotation records (%s)", genome, sum(reasons.values()), detail)
        if skipped is not None:
            skipped.update(reasons)

    unique = [e if e.tsd is not None else replace(e, tsd=infer_tsd(fasta, e)) for e in unique]
    order = {s: i for i, s in enumerate(lengths)}
    nested = assign_nesting(unique)
    nested.sort(key=lambda x: (order[x.seqid], x.start, -x.end))
    return nested


def elements_stage(label: str, spec: str, fasta: Fasta, work: Path,
                   inputs: dict[str, str]) -> tuple[list[Element], Counter]:
    """The cached `elements` stage of genome `label`: its normalized elements and its loader's skip counts,
    through <work>/elements/<label>.tsv and <label>.skipped.json, keyed by `inputs` (the FASTA and annotation
    checksums), the loader's library versions and the stage's own modules (checkpoint.STAGE_MODULES). Always
    read back from the files, so a fresh run and a rerun hand the later stages the same elements."""
    d = Path(work) / "elements"
    tsv, counts = d / f"{label}.tsv", d / f"{label}.skipped.json"
    done = marker(tsv)
    key = stage_key("elements", inputs, {"genome": label, **loader_versions(spec)})
    if is_done(done, key):
        n = sum(json.loads(counts.read_text()).values())
        log.info("%s: elements done, skip (%s; %d annotation records skipped)", label, tsv, n)
    else:
        clear_done(done)
        skipped: Counter = Counter()
        found = load_annotation(spec, label, fasta, skipped)
        d.mkdir(parents=True, exist_ok=True)
        with atomic_path(tsv) as tmp:
            write_elements(found, tmp)
        atomic_write(counts, json.dumps(dict(sorted(skipped.items()))) + "\n")
        mark_done(done, key, [tsv, counts])
        log.info("%s: %d elements (%d top-level), %d annotation records skipped -> %s", label, len(found),
                 sum(e.level == 0 for e in found), sum(skipped.values()), tsv)
    return read_elements(tsv), Counter(json.loads(counts.read_text()))
