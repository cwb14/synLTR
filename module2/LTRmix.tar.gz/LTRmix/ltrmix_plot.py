#!/usr/bin/env python3
"""ltrmix_plot.py - overview figure of one LTRmix trio: where the recipient shares recent ancestry with the donor, and
the genome-wide evidence for gene flow, each drawn against its mirror (sister) control.

overview(outdir) reads one trio output directory of ltrmix.py:
  findings.txt          roles (sister pair, donor, recipient)
  stats.tsv             every statistic (required)
  elements.<R>.tsv      every recipient element: class, orthologs, divergences, posteriors (required)
  tracts.<R>.bed        recent-shared-ancestry tracts (q, p_decoy)
  ancestry.<R>.bed      ancestry tracts
  decoy_tracts.<S>.bed  the same model's tracts in the sister (the chance level)
  blocks.tsv            collinear blocks (trio directory or its parent)
and writes into the same directory:
  overview.png          figure only, 300 dpi
  overview.pdf          page 1 figure, page 2 short legend, page 3 long legend (text kept as text, fonttype 42)
  overview_numbers.tsv  every number quoted in the legends, with its source file
A missing optional file skips its panel (or that part of a panel) with a warning.

usage: python ltrmix_plot.py OUTDIR [--mu RATE] [-v]
"""
from __future__ import annotations

import argparse
import datetime
import glob
import math
import os
import re
import socket
import sys
import time

# as in ltrmix.py: NumPy's transparent-huge-page advice can stall large allocations (here: the PDF image writer) for
# minutes in direct memory compaction on a busy, fragmented server; output does not depend on it
os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.ticker as mticker  # noqa: E402
from matplotlib import font_manager  # noqa: E402
from matplotlib import transforms as mtrans  # noqa: E402
from matplotlib.backends.backend_pdf import PdfPages  # noqa: E402
from matplotlib.collections import LineCollection, PolyCollection  # noqa: E402
from matplotlib.font_manager import FontProperties  # noqa: E402
from matplotlib.patches import Rectangle  # noqa: E402
from matplotlib.textpath import TextToPath  # noqa: E402

__all__ = ["overview"]

# ---------------------------------------------------------------------------------------------------------------------
# Style (one place)
# ---------------------------------------------------------------------------------------------------------------------
VERM, BLUE, DARK, GRAY, LGRAY = "#D55E00", "#0072B2", "#333333", "#BBBBBB", "#EDEDED"
VERM_L, BLUE_L = "#EBA77A", "#7DB6D8"          # presence-only classes: same hue, lighter
CLASS_COLOR = {"near_donor": VERM, "donor_only": VERM_L, "near_sister": BLUE, "sister_only": BLUE_L,
               "shared": GRAY, "private": GRAY, "near_both": GRAY, "unresolved": "white"}
INFORMATIVE = ("donor_only", "near_donor", "near_sister", "sister_only")
MM = 1 / 25.4                                  # inches per mm
FIG_W = 180.0                                  # figure width (mm)
FS, FS_S, FS_T, FS_L = 6.5, 6.0, 6.0, 9.0      # label, small, tick and panel-letter sizes (pt)
MAX_ROWS = 24                                  # at most this many recipient sequences are drawn (longest kept)
MIN_FRAC = 0.02                                # sequences shorter than 2% of the longest are not drawn
UNPLACED = re.compile(r"(?i)(scaf|contig|ctg|unplaced|unloc|random|chrun|(^|[_.])un($|[_.]))")
_VERBOSE = [False]


def _log(msg, verbose_only=False):
    if verbose_only and not _VERBOSE[0]:
        return
    print(f"[ltrmix_plot {time.strftime('%H:%M:%S')}] {msg}", file=sys.stderr, flush=True)


def _warn(msg):
    _log(f"WARNING: {msg}")


def _font_family():
    """Arial, else Liberation Sans (metric-compatible), registered from the usual font folders if matplotlib's cache
    lacks them; DejaVu Sans as the last resort."""
    names = {f.name for f in font_manager.fontManager.ttflist}
    if not names & {"Arial", "Liberation Sans"}:
        pats = ["/usr/share/fonts/**/LiberationSans-*.ttf", "/usr/share/fonts/**/[Aa]rial*.ttf",
                "/usr/local/share/fonts/**/LiberationSans-*.ttf", "~/.local/share/fonts/**/LiberationSans-*.ttf",
                "~/.fonts/**/LiberationSans-*.ttf", "/System/Library/Fonts/Supplemental/Arial*.ttf",
                "/Library/Fonts/Arial*.ttf", "~/Library/Fonts/Arial*.ttf"]
        for p in pats:
            for f in glob.glob(os.path.expanduser(p), recursive=True):
                try:
                    font_manager.fontManager.addfont(f)
                except Exception:  # unreadable font file: skip
                    pass
        names = {f.name for f in font_manager.fontManager.ttflist}
    for fam in ("Arial", "Liberation Sans"):
        if fam in names:
            _FAMILY[0] = fam
            return fam
    _warn("neither Arial nor Liberation Sans found; using DejaVu Sans")
    _FAMILY[0] = "DejaVu Sans"
    return "DejaVu Sans"


def _rc(fam):
    return {"font.family": "sans-serif", "font.sans-serif": [fam, "DejaVu Sans"], "font.size": FS,
            "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none", "axes.linewidth": 0.5,
            "axes.labelsize": FS, "xtick.labelsize": FS_T, "ytick.labelsize": FS_T, "xtick.major.width": 0.5,
            "ytick.major.width": 0.5, "xtick.minor.width": 0.4, "ytick.minor.width": 0.4, "xtick.major.size": 2.0,
            "ytick.major.size": 2.0, "xtick.minor.size": 1.2, "ytick.minor.size": 1.2, "xtick.major.pad": 1.5,
            "ytick.major.pad": 1.5, "axes.labelpad": 2.0, "lines.linewidth": 0.7, "hatch.linewidth": 0.3,
            "axes.unicode_minus": True, "mathtext.default": "regular", "savefig.facecolor": "white"}


# ---------------------------------------------------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------------------------------------------------
def _nat(s):
    """Natural sort key: chr2 < chr10."""
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", str(s))]


def _short(names):
    """Strip the prefix shared by all names up to its last separator (B73v5_chr1 -> chr1)."""
    names = [str(n) for n in names]
    if not names:
        return {}
    p = os.path.commonprefix(names)
    cut = max(p.rfind(c) for c in "_.-|:")
    p = p[:cut + 1] if cut >= 0 else ""
    if p and all(len(n) > len(p) for n in names):
        return {n: n[len(p):] for n in names}
    return {n: n for n in names}


def _nice(x):
    """Nearest of 1, 2, 5 x 10^k (log scale)."""
    if not np.isfinite(x) or x <= 0:
        return 1.0
    k = math.floor(math.log10(x))
    cands = [m * 10.0 ** kk for kk in (k - 1, k, k + 1) for m in (1, 2, 5)]
    return min(cands, key=lambda c: abs(math.log(c / x)))


def _bp(x):
    """Human-readable length."""
    if x >= 1e6:
        return f"{x / 1e6:,.3g} Mb"
    if x >= 1e3:
        return f"{x / 1e3:,.3g} kb"
    return f"{x:,.0f} bp"


def _pct(x):
    """A fraction as a percentage in plain digits (0.00025 -> '0.025')."""
    v = x * 100
    s = f"{v:.4g}"
    return s


def _f(x, nd=3):
    return "n/a" if x is None or not np.isfinite(x) else f"{x:+.{nd}f}"


def _read(path, required=False):
    """TSV/BED with a header line (a leading '#' is stripped); None if absent; empty frame if header only."""
    if not os.path.exists(path):
        if required:
            raise FileNotFoundError(path)
        return None
    try:
        df = pd.read_csv(path, sep="\t")
    except pd.errors.EmptyDataError:
        return pd.DataFrame()
    df.columns = [str(c).lstrip("#") for c in df.columns]
    return df


def _row(st, test, stratum=None):
    if st is None or "test" not in st:
        return None
    m = st["test"].astype(str) == test
    if stratum is not None:
        m &= st["stratum"].astype(str) == stratum
    r = st[m]
    return r.iloc[0] if len(r) else None


def _val(r, col, default=np.nan):
    if r is None or col not in r.index:
        return default
    try:
        v = float(r[col])
    except (TypeError, ValueError):
        return default
    return v


def _homologs(blocks, ga, gb):
    """{chromosome of ga: chromosome of gb sharing most collinear anchors with it}."""
    if blocks is None or blocks.empty or not {"genome_a", "genome_b"} <= set(blocks.columns):
        return {}
    b = blocks
    w = "n_anchor" if "n_anchor" in b else None
    parts = []
    for x, y, sel in (("chrom_a", "chrom_b", (b.genome_a == ga) & (b.genome_b == gb)),
                      ("chrom_b", "chrom_a", (b.genome_a == gb) & (b.genome_b == ga))):
        s = b[sel]
        if len(s):
            parts.append(pd.DataFrame({"x": s[x].astype(str), "y": s[y].astype(str),
                                       "w": s[w].astype(float) if w else 1.0}))
    if not parts:
        return {}
    t = pd.concat(parts).groupby(["x", "y"], as_index=False)["w"].sum().sort_values("w", ascending=False)
    return dict(zip(t.drop_duplicates("x")["x"], t.drop_duplicates("x")["y"]))


def _extents(blocks, g):
    """{chromosome of g: largest coordinate seen in collinear blocks}."""
    if blocks is None or blocks.empty:
        return {}
    out = {}
    for gc, cc, ec in (("genome_a", "chrom_a", "end_a"), ("genome_b", "chrom_b", "end_b")):
        s = blocks[blocks[gc] == g]
        for c, e in s.groupby(cc)[ec].max().items():
            out[str(c)] = max(out.get(str(c), 0), float(e))
    return out


def _by_name(src, dst):
    """Fallback homolog map by name after stripping each genome's shared prefix."""
    a, b = _short(src), _short(dst)
    inv = {v: k for k, v in b.items()}
    return {k: inv[v] for k, v in a.items() if v in inv}


def _hi_conf(t):
    """Tract confidence as written by ltrmix (label from the unrounded q); q <= 0.05 if the label is missing."""
    if t is None or t.empty:
        return np.zeros(0, bool)
    if "name" in t and t["name"].astype(str).str.contains(":").any():
        return t["name"].astype(str).str.endswith(":high").to_numpy()
    if "q" in t:
        return (pd.to_numeric(t["q"], errors="coerce") <= 0.05).to_numpy()
    return np.zeros(len(t), bool)


class _Fig:
    """Figure in mm: axes placed from the top-left corner."""

    def __init__(self, w, h):
        self.w, self.h = w, h
        self.fig = plt.figure(figsize=(w * MM, h * MM))

    def ax(self, x, y, w, h, **kw):
        return self.fig.add_axes([x / self.w, 1 - (y + h) / self.h, w / self.w, h / self.h], **kw)

    def text(self, x, y, s, **kw):
        return self.fig.text(x / self.w, 1 - y / self.h, s, **kw)

    def letter(self, x, y, s):
        self.text(x, y, s, fontsize=FS_L, fontweight="bold", ha="left", va="top")


_TTP = TextToPath()
_FAMILY = ["DejaVu Sans"]


def _textw(s, size=FS, weight="normal"):
    """Width of a string in mm (font metrics; no artist created)."""
    if not s:
        return 0.0
    fp = FontProperties(family=_FAMILY[0], size=size, weight=weight)
    w = 0.0
    for part in str(s).split("\n"):
        w = max(w, _TTP.get_text_width_height_descent(part, fp, ismath=False)[0])
    return w * 0.3528


KEY_LH = FS * 0.3528 * 1.55   # key line height (mm)


def _key(F, x, y, items, xmax, size=FS, gap=2.6, draw=True):
    """Lines of key items [(glyph, style, label)], None = line break, starting at (x, y) mm and wrapping at xmax (one
    value, or one per line). Returns the y of the line below the last one (draw=False: measure only)."""
    x0, lh = x, KEY_LH
    xm = list(xmax) if isinstance(xmax, (list, tuple)) else [xmax]
    line = 0
    for it in items:
        if it is None:
            x, y, line = x0, y + lh, line + 1
            continue
        glyph, sty, lab = it
        w = 3.2 + _textw(lab, size)
        if x + w > xm[min(line, len(xm) - 1)] and x > x0:
            x, y, line = x0, y + lh, line + 1
        if not draw:
            x += w + gap
            continue
        ax = F.ax(x, y - 1.3, 2.6, 2.6)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis("off")
        c = sty.get("color", DARK)
        if glyph == "tick":
            ax.plot([0.5, 0.5], [0.1, 0.9], color=c, lw=sty.get("lw", 1.0), solid_capstyle="butt")
        elif glyph == "box":
            ax.add_patch(Rectangle((0.2, 0.2), 0.6, 0.6, facecolor=sty.get("fc", c), edgecolor=c,
                                   lw=sty.get("lw", 0.6)))
        elif glyph == "line":
            ax.plot([0, 1], [0.5, 0.5], color=c, lw=sty.get("lw", 0.8), ls=sty.get("ls", "-"))
        elif glyph == "dot":
            ax.plot([0.5], [0.5], "o", ms=sty.get("ms", 2.6), mfc=sty.get("mfc", c), mec=c, mew=0.6)
        elif glyph == "dotbar":
            ax.plot([0.05, 0.95], [0.5, 0.5], color=c, lw=0.6)
            ax.plot([0.5], [0.5], "o", ms=sty.get("ms", 2.6), mfc=sty.get("mfc", c), mec=c, mew=0.6)
        F.text(x + 3.0, y, lab, fontsize=size, va="center", ha="left")
        x += w + gap
    return y + lh


# ---------------------------------------------------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------------------------------------------------
def _load(outdir):
    d = {"outdir": os.path.abspath(outdir), "src": {}}
    st = _read(os.path.join(outdir, "stats.tsv"), required=True)
    d["stats"] = st
    d["src"]["stats"] = "stats.tsv"
    R = S = D = None
    fp = os.path.join(outdir, "findings.txt")
    if os.path.exists(fp):
        txt = open(fp).read()
        d["findings"] = txt
        m = re.search(r"D\(single-copy k-mers; ([^,;()]+),([^;()]+);([^)]+)\)", txt)
        if m:
            R, S, D = (x.strip() for x in m.groups())
    else:
        _warn("findings.txt missing: roles taken from stats.tsv")
        d["findings"] = ""
    if R is None:
        h = st[st["test"].astype(str).str.startswith("hmm")] if "test" in st else st.iloc[:0]
        if len(h) and {"sister", "donor"} <= set(h.columns):
            R, S, D = str(h["stratum"].iloc[0]), str(h["sister"].iloc[0]), str(h["donor"].iloc[0])
    if R is None:
        raise ValueError(f"cannot tell recipient, sister and donor from {outdir} (findings.txt and stats.tsv)")
    d["R"], d["S"], d["D"] = R, S, D
    ep = os.path.join(outdir, f"elements.{R}.tsv")
    if not os.path.exists(ep):
        raise FileNotFoundError(ep)
    hdr = pd.read_csv(ep, sep="\t", nrows=0).columns.tolist()
    pa = next((c for c in hdr if c.startswith("post_ancestry_")), None) or \
        next((c for c in hdr if c.startswith("post_") and not c.startswith("post_recent_")), None)
    pr = next((c for c in hdr if c.startswith("post_recent_")), None)
    ren = {pa: "post_a", pr: "post_r", f"div_{D}": "div_D", f"div_{S}": "div_S", f"in_{D}": "in_D",
           f"in_{S}": "in_S"}
    cols = ["chrom", "start", "end", "class"] + [c for c in ren if c and c in hdr]
    el = pd.read_csv(ep, sep="\t", usecols=cols, dtype={"chrom": str, "class": str})
    el = el.rename(columns={k: v for k, v in ren.items() if k})
    for c in ("post_a", "post_r", "div_D", "div_S"):
        if c not in el:
            el[c] = np.nan
    for c in ("in_D", "in_S"):
        if c not in el:
            el[c] = "unresolved"
    el["mid"] = 0.5 * (el["start"] + el["end"])
    d["el"] = el
    d["src"]["el"] = f"elements.{R}.tsv"
    d["has_recent_post"] = pr is not None
    for key, fn in (("tracts", f"tracts.{R}.bed"), ("anc", f"ancestry.{R}.bed"), ("decoy", f"decoy_tracts.{S}.bed")):
        t = _read(os.path.join(outdir, fn))
        if t is None:
            _warn(f"{fn} missing: skipped")
        elif not t.empty:
            t["chrom"] = t["chrom"].astype(str)
        d[key] = t
        d["src"][key] = fn
    bp = os.path.join(outdir, "blocks.tsv")
    if not os.path.exists(bp):
        bp = os.path.join(os.path.dirname(os.path.abspath(outdir)), "blocks.tsv")
    d["blocks"] = _read(bp)
    if d["blocks"] is None:
        _warn("blocks.tsv missing (trio directory and its parent): homologs matched by name")
    d["src"]["blocks"] = os.path.relpath(bp, outdir) if os.path.exists(bp) else "blocks.tsv"
    return d


def _chromosomes(d):
    """Recipient sequences to draw: natural order; unplaced/unlocalized names and sequences < 2% of the longest
    dropped; at most MAX_ROWS (longest kept)."""
    el = d["el"]
    ext = el.groupby("chrom")["end"].max()
    if d.get("tracts") is not None and not d["tracts"].empty:
        te = d["tracts"].groupby("chrom")["end"].max()
        ext = pd.concat([ext, te]).groupby(level=0).max()
    longest = float(ext.max())
    keep = [c for c in ext.index if not UNPLACED.search(c) and ext[c] >= MIN_FRAC * longest]
    if not keep:
        keep = list(ext.index)
    if len(keep) > MAX_ROWS:
        keep = sorted(keep, key=lambda c: -ext[c])[:MAX_ROWS]
    keep = sorted(keep, key=_nat)
    dropped = [c for c in ext.index if c not in keep]
    n_drop = int(el["chrom"].isin(dropped).sum())
    return keep, {c: float(ext[c]) for c in keep}, dropped, n_drop


# ---------------------------------------------------------------------------------------------------------------------
# Panels
# ---------------------------------------------------------------------------------------------------------------------
# row tracks in mm from the row top (scaled with the row height); body = the recipient chromosome
# the sister's bar (decoy) has the body's height, so decoy tracts look like the tracts they are compared with
TRACKS = {"trace": (0.0, 2.7), "donor_only": (3.0, 3.9), "near_donor": (4.0, 4.9), "body": (5.1, 6.4),
          "near_sister": (6.6, 7.5), "sister_only": (7.6, 8.5), "decoy": (8.85, 10.15)}
ROW_H = 11.6


def _panel_A(F, ax, d, chroms, ext, rh, zoom):
    """Recipient chromosomes: element ticks by class, windowed ancestry posterior, recent tracts, and below each the
    sister's homologous chromosome with its decoy tracts."""
    R, S = d["R"], d["S"]
    el = d["el"]
    sc = rh / ROW_H
    T = {k: (a * sc, b * sc) for k, (a, b) in TRACKS.items()}
    n = len(chroms)
    row = {c: i for i, c in enumerate(chroms)}
    sext = _extents(d["blocks"], S)
    hom = _homologs(d["blocks"], R, S)
    dec = d.get("decoy")
    if not hom:
        snames = list(sext) + (list(dec["chrom"].unique()) if dec is not None and not dec.empty else [])
        hom = _by_name(chroms, sorted(set(snames), key=_nat))
    if dec is not None and not dec.empty:
        for c, e in dec.groupby("chrom")["end"].max().items():
            sext[c] = max(sext.get(c, 0), float(e))
    xmax = max(max(ext.values()), max([sext.get(hom.get(c), 0) for c in chroms] + [0])) * 1.003
    ax.set_xlim(0, xmax)
    ax.set_ylim(n * rh, 0)
    ax_w = ax.get_position().width * F.w
    bp_per_mm = xmax / ax_w
    # Mb grid
    step = _nice(xmax / 6)
    ticks = np.arange(0, xmax + 1, step)
    for t in ticks:
        ax.axvline(t, color="#E4E4E4", lw=0.3, zorder=0)
    ax.set_xticks(ticks)
    ax.set_xticklabels([f"{t / 1e6:g}" for t in ticks])
    ax.set_xlabel("position (Mb)")
    for s in ("left", "right", "top"):
        ax.spines[s].set_visible(False)
    ax.set_yticks([])
    lab_tr = mtrans.blended_transform_factory(ax.transAxes, ax.transData) + \
        mtrans.ScaledTranslation(-1.2 * MM, 0, F.fig.dpi_scale_trans)
    rs, ss = _short(chroms), _short(sorted({hom[c] for c in chroms if c in hom}, key=_nat))
    # elements on drawn rows
    m = el["chrom"].isin(row)
    e = el[m]
    erow = e["chrom"].map(row).to_numpy()
    ex = e["mid"].to_numpy()
    ecl = e["class"].to_numpy()
    counts = {}
    total_px = sum(ext[c] for c in chroms) / bp_per_mm / 0.0847
    for cls in INFORMATIVE:
        k = ecl == cls
        counts[cls] = int(k.sum())
        if not k.any():
            continue
        dens = k.sum() / max(total_px, 1)
        alpha = float(np.clip(1.0 / (1 + 1.25 * dens), 0.08, 0.9))
        ya, yb = T[cls]
        base = erow[k] * rh
        seg = np.stack([np.c_[ex[k], base + ya], np.c_[ex[k], base + yb]], axis=1)
        ax.add_collection(LineCollection(seg, colors=CLASS_COLOR[cls], linewidths=0.35, alpha=alpha,
                                         rasterized=True, zorder=2))
    counts["other"] = int(len(e) - sum(counts.values()))
    # windowed ancestry posterior
    dens_bp = len(e) / max(sum(ext.values()), 1)
    W = min(max(_nice(max(ext.values()) / 200), _nice(25 / max(dens_bp, 1e-12))), _nice(max(ext.values()) / 40))
    dm = _val(_row(d["stats"], "hmm_ancestry", R), "decoy_posterior_mean")
    if not np.isfinite(dm):
        dm = _val(_row(d["stats"], "hmm", R), "decoy_posterior_mean")
    ta, tb = T["trace"]
    post = e["post_a"].to_numpy(float)
    wl = (e["end"] - e["start"] + 1).to_numpy(float)
    have_post = np.isfinite(post).any()
    for c in chroms:
        y0 = row[c] * rh
        k = (erow == row[c]) & np.isfinite(post)
        nwin = int(ext[c] // W) + 1
        if have_post:
            wi = (ex[k] // W).astype(int)
            num = np.bincount(wi, weights=wl[k] * post[k], minlength=nwin)[:nwin]
            den = np.bincount(wi, weights=wl[k], minlength=nwin)[:nwin]
            val = np.where(den > 0, num / np.maximum(den, 1e-12), np.nan)
            xc = np.minimum((np.arange(nwin) + 0.5) * W, ext[c])
            ax.plot(xc, y0 + ta + (1 - val) * (tb - ta), color=DARK, lw=0.5, zorder=3, solid_joinstyle="round")
            # empty windows hatched
            emp = np.where(den == 0)[0]
            if len(emp):
                runs = np.split(emp, np.where(np.diff(emp) > 1)[0] + 1)
                for r_ in runs:
                    x0, x1 = r_[0] * W, min((r_[-1] + 1) * W, ext[c])
                    ax.add_patch(Rectangle((x0, y0 + ta), x1 - x0, tb - ta, fill=False, hatch="//////",
                                           edgecolor="#C8C8C8", lw=0, zorder=1))
            if np.isfinite(dm):
                ax.plot([0, ext[c]], [y0 + ta + (1 - dm) * (tb - ta)] * 2, color="#8C8C8C", lw=0.45,
                        ls=(0, (2.2, 1.6)), zorder=2.5)
        # recipient chromosome body
        ba, bb = T["body"]
        ax.add_patch(Rectangle((0, y0 + ba), ext[c], bb - ba, facecolor=LGRAY, edgecolor="#9A9A9A", lw=0.4,
                               zorder=1.5))
        ax.text(0, y0 + 0.5 * (ba + bb), rs[c], transform=lab_tr, ha="right", va="center",
                fontsize=FS if sc >= 0.8 else max(5.0, FS * sc / 0.8))
        # sister homolog with decoy tracts
        if c in hom and hom[c] in sext:
            da, db = T["decoy"]
            ax.add_patch(Rectangle((0, y0 + da), sext[hom[c]], db - da, facecolor="#F6F6F6", edgecolor="#B5B5B5",
                                   lw=0.35, zorder=1.5))
            if sc >= 0.7:
                ax.text(0, y0 + 0.5 * (da + db), f"{S} {ss.get(hom[c], hom[c])}", transform=lab_tr, ha="right",
                        va="center", fontsize=FS_S - 0.5, color="#777777")
    # tract boxes
    ba, bb = T["body"]
    tr = d.get("tracts")
    ntr = {"all": 0, "high": 0}
    if tr is not None and not tr.empty:
        t = tr[tr["chrom"].isin(row)]
        hi = _hi_conf(t)
        ty = t["chrom"].map(row).to_numpy() * rh
        x0, x1 = t["start0"].to_numpy(float), t["end"].to_numpy(float)
        ntr = {"all": int(len(t)), "high": int(hi.sum())}
        ext_hi = 0.18 * sc
        for sel, fc, lw, pad, z in ((~hi, "none", 0.4, 0.0, 3.2), (hi, VERM, 0.3, ext_hi, 3.4)):
            if sel.any():
                v = np.stack([np.c_[x0[sel], ty[sel] + ba - pad], np.c_[x0[sel], ty[sel] + bb + pad],
                              np.c_[x1[sel], ty[sel] + bb + pad], np.c_[x1[sel], ty[sel] + ba - pad]], axis=1)
                ax.add_collection(PolyCollection(v, facecolors=fc, edgecolors=VERM, linewidths=lw, zorder=z))
    ndec = 0
    if dec is not None and not dec.empty:
        inv = {v: c for c, v in hom.items()}
        t = dec[dec["chrom"].isin(inv)]
        ndec = int(len(dec))
        if len(t):
            da, db = T["decoy"]
            ty = t["chrom"].map(lambda s: row[inv[s]]).to_numpy() * rh
            x0, x1 = t["start0"].to_numpy(float), t["end"].to_numpy(float)
            v = np.stack([np.c_[x0, ty + da], np.c_[x0, ty + db], np.c_[x1, ty + db], np.c_[x1, ty + da]], axis=1)
            ax.add_collection(PolyCollection(v, facecolors="none", edgecolors="#4D4D4D", linewidths=0.4, zorder=3.2))
    # posterior scale (0-1) beside the first row's trace
    if have_post:
        bl = mtrans.blended_transform_factory(ax.transAxes, ax.transData)
        sx = bl + mtrans.ScaledTranslation(-0.7 * MM, 0, F.fig.dpi_scale_trans)
        ax.plot([0, 0], [ta, tb], transform=sx, color="#777777", lw=0.4, clip_on=False)
        for yy, s in ((ta, "1"), (tb, "0")):
            ax.plot([0], [yy], transform=sx, marker="_", ms=1.6, mew=0.4, color="#777777", clip_on=False)
            ax.text(0, yy, s, transform=bl + mtrans.ScaledTranslation(-1.3 * MM, 0, F.fig.dpi_scale_trans),
                    fontsize=FS_S - 1.0, color="#777777", va="center", ha="right")
    # zoom locator
    if zoom is not None:
        c, w0, w1 = zoom
        y0 = row[c] * rh
        wmin = 0.9 * bp_per_mm
        if w1 - w0 < wmin:
            cx = 0.5 * (w0 + w1)
            w0, w1 = cx - wmin / 2, cx + wmin / 2
        ax.add_patch(Rectangle((w0, y0 + ta - 0.2), w1 - w0, T["sister_only"][1] - ta + 0.4, fill=False,
                               edgecolor="black", lw=0.6, zorder=5))
        loc = ax.text(w1 + 0.6 * bp_per_mm, y0 + ta + 0.3, "C", fontsize=FS, fontweight="bold", va="top",
                      ha="left", zorder=5, bbox=dict(boxstyle="square,pad=0.08", fc="white", ec="none"))
    else:
        loc = None
    return dict(counts=counts, W=W, dm=dm, ntr=ntr, ndec=ndec, hom=hom, xmax=xmax, loc=loc)


def _panel_B(ax, d, chroms, rh):
    """Per-chromosome D (k-mers, insertions) of each donor chromosome, beside its homologous recipient chromosome."""
    R, D = d["R"], d["D"]
    st = d["stats"]
    sc = rh / ROW_H
    yb = 0.5 * (TRACKS["body"][0] + TRACKS["body"][1]) * sc
    ax.set_ylim(len(chroms) * rh, 0)
    # donor chromosome -> recipient chromosome: reciprocal best by collinear anchors (scaffolds and unplaced
    # sequences excluded), else by name
    fwd, rev = _homologs(d["blocks"], D, R), _homologs(d["blocks"], R, D)
    hom = {a: b for a, b in fwd.items() if rev.get(b) == a and not UNPLACED.search(a)}
    out = {}
    xs = []
    for test, off, mfc in (("D_kmer_by_chrom", -0.75 * sc, "white"), ("D_ins_by_chrom", 0.75 * sc, DARK)):
        r = st[st["test"].astype(str) == test]
        if r.empty:
            continue
        names = [x for x in r["stratum"].astype(str) if not UNPLACED.search(x)]
        hm = hom or _by_name(names, chroms)
        rows = []
        for _, x in r.iterrows():
            c = hm.get(str(x["stratum"]))
            if c not in chroms or not np.isfinite(_val(x, "SE")):
                continue
            y = chroms.index(c) * rh + yb + off
            Dv, se = float(x["D"]), float(x["SE"])
            ax.plot([Dv - 2 * se, Dv + 2 * se], [y, y], color=DARK, lw=0.6, zorder=2)
            ax.plot([Dv], [y], "o", ms=2.6, mfc=mfc, mec=DARK, mew=0.6, zorder=3)
            xs += [Dv - 2 * se, Dv + 2 * se]
            rows.append((str(x["stratum"]), c, Dv, se, float(x["Z"]) if "Z" in x else np.nan))
        out[test] = rows
    if not xs:
        ax.axis("off")
        return None
    lo, hi = min(xs + [0]), max(xs + [0])
    pad = 0.08 * (hi - lo)
    ax.set_xlim(lo - pad, hi + pad)
    ax.axvline(0, color="#8C8C8C", lw=0.6, zorder=1)
    for s in ("left", "right", "top"):
        ax.spines[s].set_visible(False)
    ax.set_yticks([])
    ax.xaxis.set_major_locator(mticker.MaxNLocator(4, symmetric=False))
    ax.set_xlabel(f"D per chromosome of {D}\n(± 2 SE)")
    return out


def _stack(starts, ends, gap):
    """Greedy row packing (IGV 'expanded'): row index per feature."""
    order = np.argsort(starts, kind="stable")
    last = []
    rows = np.zeros(len(starts), int)
    for i in order:
        for j, le in enumerate(last):
            if starts[i] > le + gap:
                rows[i] = j
                last[j] = ends[i]
                break
        else:
            rows[i] = len(last)
            last.append(ends[i])
    return rows


MIN_EL_MM = 0.3   # elements narrower than this on the page are drawn this wide, centered (wide zoom windows)


def _minw_note(C):
    n = int(C.get("n_min", 0))
    return f"; {n:,} narrower than {MIN_EL_MM:g} mm are drawn {MIN_EL_MM:g} mm wide" if n else ""


def _drawn(s0, s1, bp_mm):
    """Drawn extent of elements: to size, but at least MIN_EL_MM wide."""
    minw = MIN_EL_MM * bp_mm
    narrow = (s1 - s0) < minw
    xs = np.where(narrow, 0.5 * (s0 + s1) - 0.5 * minw, s0)
    return xs, np.where(narrow, xs + minw, s1), narrow


def _zoom_rows(d, z, width_mm):
    """Number of stacked rows the zoom window's elements need."""
    el = d["el"]
    e = el[(el["chrom"] == z["chrom"]) & (el["end"] >= z["w0"]) & (el["start"] <= z["w1"])]
    if e.empty:
        return 1
    bp_mm = (z["w1"] - z["w0"]) / width_mm
    xs, xe, _ = _drawn(e["start"].to_numpy(float), e["end"].to_numpy(float), bp_mm)
    return int(_stack(xs, xe, 0.25 * bp_mm).max()) + 1


def _tiers(t):
    """Confidence label per tract as written by ltrmix (from the unrounded q), else from the q column."""
    if "name" in t and t["name"].astype(str).str.contains(":").any():
        return t["name"].astype(str).str.rsplit(":", n=1).str[-1].to_numpy()
    q = pd.to_numeric(t["q"], errors="coerce") if "q" in t else pd.Series(np.nan, index=t.index)
    return np.where(q <= 0.05, "high", np.where(q <= 0.2, "medium", "low"))


def _zoom_choice(d, chroms):
    """Example tract, typical of the most confident tier present (q <= 0.05, else q <= 0.2, else all tracts): the
    one with the median expected number of donor-like elements (sum of posteriors); ties by length nearest the tier's
    median. Window: the tract with flanks of one tract length, widened until it holds >= 60 informative elements."""
    tr = d.get("tracts")
    if tr is None or tr.empty:
        return None
    t = tr[tr["chrom"].isin(chroms)].copy()
    if t.empty:
        return None
    t["tier"] = _tiers(t)
    tier = next((x for x in ("high", "medium") if (t["tier"] == x).any()), "all")
    if tier != "all":
        t = t[t["tier"] == tier]
    t["len"] = t["end"] - t["start0"]
    sp = t["sum_post"].astype(float) if "sum_post" in t else t["n_elements"].astype(float)
    t["k1"] = (sp - sp.median()).abs()
    t["k2"] = (np.log(t["len"]) - np.log(t["len"].median())).abs()
    best = t.sort_values(["k1", "k2"]).iloc[0]
    c, s0, s1 = str(best["chrom"]), float(best["start0"]), float(best["end"])
    el = d["el"]
    ec = el[(el["chrom"] == c)]
    inf = ec[ec["class"].isin(INFORMATIVE)]["mid"].to_numpy()
    cext = float(ec["end"].max())
    cx = 0.5 * (s0 + s1)
    half = 1.5 * (s1 - s0)
    step = max(0.25 * (s1 - s0), 10_000.0)
    while half < cext and int(((inf >= cx - half) & (inf <= cx + half)).sum()) < 60:
        half += step
    w0, w1 = max(0.0, cx - half), min(cext, cx + half)
    return dict(chrom=c, w0=w0, w1=w1, tract=best, tier=tier, n_tier=len(t), median_sum_post=float(sp.median()))


SLOT = 1.1   # distance of the '0' and 'absent' slots from the log-scale ends (decades)


def _ytr(v, lo, hi):
    """Divergence (fraction) -> y: log10(%) for v > 0, a '0' slot below the log scale for 0."""
    v = np.asarray(v, float)
    y = np.full(v.shape, np.nan)
    pos = np.isfinite(v) & (v > 0)
    y[pos] = np.log10(v[pos] * 100)
    y[np.isfinite(v) & (v == 0)] = lo - SLOT
    return np.clip(y, lo - SLOT, hi + SLOT)


def _panel_C(F, axes, d, z):
    """Zoom: every element of the window to size by class; its divergence to the donor and sister orthologs;
    posteriors and tracts."""
    ax1, ax2, ax3 = axes
    R = d["R"]
    c, w0, w1 = z["chrom"], z["w0"], z["w1"]
    el = d["el"]
    e = el[(el["chrom"] == c) & (el["end"] >= w0) & (el["start"] <= w1)].sort_values("mid")
    for a in axes:
        a.set_xlim(w0, w1)
    # --- divergence dumbbells
    dD, dS = e["div_D"].to_numpy(float), e["div_S"].to_numpy(float)
    allpos = np.r_[dD[np.isfinite(dD) & (dD > 0)], dS[np.isfinite(dS) & (dS > 0)]]
    lo = math.floor(np.log10(allpos.min() * 100)) if len(allpos) else -2
    hi = math.ceil(np.log10(allpos.max() * 100)) if len(allpos) else 1
    lo, hi = min(lo, hi - 2), max(hi, lo + 2)
    yab = hi + SLOT

    def yv(dv, status):
        y = _ytr(dv, lo, hi)
        y[(status == "absent")] = yab
        y[~np.isin(status, ["present", "absent"])] = np.nan
        return y

    yD = yv(dD, e["in_D"].astype(str).to_numpy())
    yS = yv(dS, e["in_S"].astype(str).to_numpy())
    x = e["mid"].to_numpy(float)
    cl = e["class"].astype(str).to_numpy()
    both = np.isfinite(yD) & np.isfinite(yS)
    seg = np.stack([np.c_[x[both], yD[both]], np.c_[x[both], yS[both]]], axis=1)
    cols = [CLASS_COLOR.get(k, GRAY) if k in INFORMATIVE else "#C9C9C9" for k in cl[both]]
    ax1.add_collection(LineCollection(seg, colors=cols, linewidths=0.55, zorder=2))
    kD, kS = np.isfinite(yD), np.isfinite(yS)
    ax1.plot(x[kS], yS[kS], "o", ms=2.1, mfc=BLUE, mec="white", mew=0.25, zorder=3)
    ax1.plot(x[kD], yD[kD], "o", ms=2.1, mfc=VERM, mec="white", mew=0.25, zorder=4)
    thr = _val(_row(d["stats"], "hmm_recent", R), "near_threshold")
    if not np.isfinite(thr):
        thr = _val(_row(d["stats"], "hmm_ancestry", R), "near_threshold")
    if np.isfinite(thr) and thr > 0:
        yt = np.log10(thr * 100)
        ax1.axhline(yt, color="#8C8C8C", lw=0.5, ls=(0, (2.2, 1.6)), zorder=1)
    ax1.set_ylim(lo - SLOT - 0.45, hi + SLOT + 0.45)
    yt_ = [lo - SLOT] + list(range(lo, hi + 1)) + [yab]
    ax1.set_yticks(yt_)
    ax1.set_yticklabels(["0"] + [_pct(10.0 ** k / 100) for k in range(lo, hi + 1)] + ["absent"])
    for k in range(lo, hi + 1):
        ax1.axhline(k, color="#EFEFEF", lw=0.3, zorder=0)
    ax1.set_ylabel("divergence to\northolog (%)")
    for s in ("top", "right", "bottom"):
        ax1.spines[s].set_visible(False)
    ax1.set_xticks([])
    # axis breaks between the '0' / 'absent' slots and the log scale
    brk = mtrans.blended_transform_factory(ax1.transAxes, ax1.transData)
    for yb_ in (lo - 0.55 * SLOT, hi + 0.55 * SLOT):
        ax1.plot([-0.008, 0.008], [yb_ - 0.1, yb_ + 0.1], transform=brk, color="black", lw=0.5, clip_on=False,
                 zorder=6)
    # --- element boxes (stacked where they overlap), then the tracts of both models
    span = w1 - w0
    bp_mm = span / (ax2.get_position().width * F.w)
    xs, xe, narrow = _drawn(e["start"].to_numpy(float), e["end"].to_numpy(float), bp_mm)
    rws = _stack(xs, xe, 0.25 * bp_mm)
    nr = int(rws.max()) + 1 if len(rws) else 1
    eh = min(1.0, 3.2 / nr)
    for s0, s1, k, r_, nw in zip(xs, xe, cl, rws, narrow):
        # a white outline separates abutting boxes but would hide a minimum-width one
        ec = "#9A9A9A" if k == "unresolved" else ("none" if nw else "white")
        ax2.add_patch(Rectangle((s0, r_ * (eh + 0.2)), s1 - s0, eh, facecolor=CLASS_COLOR.get(k, GRAY),
                                edgecolor=ec, lw=0.25))
    yl = {"elements": 0.5 * nr * (eh + 0.2) - 0.1}
    y = nr * (eh + 0.2) + 1.0
    for key, col, lab in (("tracts", VERM, "recent tracts"), ("anc", DARK, "ancestry tracts")):
        t = d.get(key)
        if t is None:
            continue
        yl[lab] = y + 0.5
        if not t.empty:
            tt = t[(t["chrom"] == c) & (t["end"] >= w0) & (t["start0"] <= w1)]
            for s0, s1, h in zip(tt["start0"].to_numpy(float), tt["end"].to_numpy(float), _hi_conf(tt)):
                ax2.add_patch(Rectangle((s0, y), s1 - s0, 1.0, facecolor=col if h else "none", edgecolor=col,
                                        lw=0.5))
        y += 2.2
    ax2.set_ylim(y - 1.2 + 0.1, -0.1)
    ax2.axis("off")
    lt = mtrans.blended_transform_factory(ax2.transAxes, ax2.transData) + \
        mtrans.ScaledTranslation(-1.2 * MM, 0, F.fig.dpi_scale_trans)
    for lab, yy in yl.items():
        ax2.text(0, yy, lab, transform=lt, ha="right", va="center", fontsize=FS_S)
    # background bands: the recent tracts, so the per-element evidence lines up with the calls
    t = d.get("tracts")
    if t is not None and not t.empty:
        tt = t[(t["chrom"] == c) & (t["end"] >= w0) & (t["start0"] <= w1)]
        for s0, s1, h in zip(tt["start0"].to_numpy(float), tt["end"].to_numpy(float), _hi_conf(tt)):
            for a in (ax1, ax3):
                a.axvspan(s0, s1, color=VERM, alpha=0.10 if h else 0.05, lw=0, zorder=0)
    # --- posteriors
    if np.isfinite(e["post_a"]).any():
        ax3.plot(x, e["post_a"].to_numpy(float), color=DARK, lw=0.6, zorder=3)
    if d.get("has_recent_post") and np.isfinite(e["post_r"]).any():
        ax3.plot(x, e["post_r"].to_numpy(float), color=VERM, lw=0.6, zorder=4)
    ax3.set_ylim(-0.05, 1.05)
    ax3.set_yticks([0, 1])
    ax3.set_ylabel("posterior", rotation=0, ha="right", va="center", fontsize=FS_S)
    for s in ("top", "right"):
        ax3.spines[s].set_visible(False)
    step = _nice(span / 7)
    t0 = math.ceil(w0 / step) * step
    ticks = np.arange(t0, w1 + 1, step)
    ax3.set_xticks(ticks)
    nd = max(0, -int(math.floor(math.log10(step / 1e6)))) if step < 1e6 else 0
    ax3.set_xticklabels([f"{t / 1e6:.{nd}f}" for t in ticks])
    ax3.set_xlabel(f"position on {R} {z['short']} (Mb)")
    inside = (e["mid"] >= z["tract"]["start0"]) & (e["mid"] <= z["tract"]["end"])
    okb = np.isfinite(dD) & np.isfinite(dS)
    closer = dD < dS
    return dict(n=len(e), n_min=int(narrow.sum()), n_in=int((inside & okb).sum()),
                k_in=int((inside & okb & closer).sum()),
                n_out=int((~inside & okb).sum()), k_out=int((~inside & okb & closer).sum()),
                n_inf=int(np.isin(cl, INFORMATIVE).sum()))


def _parse_age(lab):
    s = str(lab).replace("K2P", "").strip()
    if s == "0":
        return (0.0, 0.0)
    m = re.match(r"\(([^,]+),([^\]]+)\]", s)
    if m:
        return (float(m.group(1)), float(m.group(2)))
    m = re.match(r">\s*(.+)", s)
    if m:
        return (float(m.group(1)), math.inf)
    return None


def _slots(intervals):
    """Ordered slots [(lo, hi, payload)] with gaps filled by empty slots; the (0, 0) point slot first."""
    iv = sorted(intervals, key=lambda t: (t[0], t[1]))
    out = []
    prev_hi = None
    for lo, hi, p in iv:
        if prev_hi is not None and lo > prev_hi * (1 + 1e-9) + 1e-15:
            out.append((prev_hi, lo, None))
        out.append((lo, hi, p))
        prev_hi = hi
    return out


def _ordinal_axis(ax, slots, label_every=1, pct=True):
    """x positions for slots: the zero point slot at 0, interval slots from 1.4 on; boundary ticks labeled with the
    interval edges (in %)."""
    xs, ticks, labs = [], [], []
    k = 0
    for i, (lo, hi, _) in enumerate(slots):
        if hi == 0:
            xs.append(0.0)
            ticks.append(0.0)
            labs.append("0")
        else:
            xs.append(1.4 + k)
            k += 1
    bvals = []
    for i, (lo, hi, _) in enumerate(slots):
        if hi == 0 or not np.isfinite(hi) or i == len(slots) - 1:
            continue
        bvals.append((xs[i] + 0.5, hi))
    # label every n-th boundary, keeping the one at 0.1% (or nearest) labeled
    if bvals:
        anchor = int(np.argmin([abs(math.log10(v) + 3) for _, v in bvals]))
        for j, (xb, v) in enumerate(bvals):
            ticks.append(xb)
            labs.append(_pct(v) if (j - anchor) % label_every == 0 else "")
    ax.set_xticks(ticks)
    ax.set_xticklabels(labs)
    has0 = any(hi == 0 for _, hi, _ in slots)
    xmin = -0.6 if has0 else 0.8
    ax.set_xlim(xmin, (xs[-1] if xs else 1) + 0.6)
    if has0:
        for xb in (0.62, 0.74):
            ax.plot([xb - 0.05, xb + 0.05], [-0.025, 0.025], transform=mtrans.blended_transform_factory(
                ax.transData, ax.transAxes), color="black", lw=0.5, clip_on=False, zorder=6)
    return np.array(xs)


def _panel_D(ax, d, mu):
    st = d["stats"]
    r = st[st["test"].astype(str) == "D_ins_by_age"]
    iv = []
    for _, x in r.iterrows():
        p = _parse_age(x["stratum"])
        if p is not None:
            iv.append((p[0], p[1], x))
    if not iv:
        ax.axis("off")
        return None
    sl = _slots(iv)
    xs = _ordinal_axis(ax, sl)
    rows = []
    for xx, (lo, hi, p) in zip(xs, sl):
        if p is None:
            continue
        Dv, se = float(p["D"]), float(p["SE"])
        ax.plot([xx, xx], [Dv - 2 * se, Dv + 2 * se], color=DARK, lw=0.6, zorder=2)
        ax.plot([xx], [Dv], "o", ms=3.0, mfc=DARK, mec=DARK, zorder=3)
        rows.append((lo, hi, Dv, se, float(p["Z"]), int(p["nA"]), int(p["nB"])))
    ax.axhline(0, color="#8C8C8C", lw=0.6, zorder=1)
    lo = min([0.0] + [r[2] - 2 * r[3] for r in rows])
    hi = max([0.0] + [r[2] + 2 * r[3] for r in rows])
    pad = 0.08 * (hi - lo if hi > lo else 1.0)
    ax.set_ylim(lo - pad, hi + pad)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_ylabel("D, shared insertions")
    ax.set_xlabel("insertion age: divergence between\nthe element's two LTRs (%)")
    if mu:
        top = ax.secondary_xaxis("top")
        tk = [t for t in ax.get_xticks()]
        labs = []
        for t, lab in zip(tk, [tl.get_text() for tl in ax.get_xticklabels()]):
            try:
                v = float(lab) / 100 if lab else None
            except ValueError:
                v = None
            labs.append("" if v is None else f"{v / (2 * mu) / 1e3:,.0f}")
        top.set_xticks(tk)
        top.set_xticklabels(labs)
        top.set_xlabel(f"kyr at {mu:g} substitutions per site per year", fontsize=FS_S)
    return rows


def _panel_E(ax, d):
    st = d["stats"]
    r = st[st["test"].astype(str) == "identity_spectrum"]
    iv = []
    for _, x in r.iterrows():
        m = re.search(r"\[([^,]+),([^)]+)\)", str(x["stratum"]))
        if not m:
            continue
        lo, hi = float(m.group(1)), float(m.group(2))
        if hi <= 1e-6:                     # the identical bin [0, 1e-9)
            iv.append((0.0, 0.0, x))
        else:
            iv.append((0.0 if lo <= 1e-6 else lo, hi, x))
    if not iv:
        ax.axis("off")
        return None
    sl = _slots(iv)
    xs = _ordinal_axis(ax, sl, label_every=2)
    fr = _row(st, "f_lower_bound")
    cal = _val(fr, "calibration", 1.0)
    if not np.isfinite(cal) or cal <= 0:
        cal = 1.0
    nt = np.array([float(p["n_target"]) if p is not None else np.nan for _, _, p in sl])
    nm = np.array([float(p["n_mirror"]) if p is not None else np.nan for _, _, p in sl]) / cal
    floor = 0.4
    yt, ym = np.where(nt > 0, nt, floor), np.where(nm > 0, nm, floor)
    ok = np.isfinite(nt)
    xo = xs[ok]
    ax.fill_between(xo, ym[ok], yt[ok], where=yt[ok] > ym[ok], color=VERM, alpha=0.13, lw=0, interpolate=True,
                    zorder=1)
    ax.plot(xo, ym[ok], "-o", color=BLUE, lw=0.7, ms=2.4, mfc="white", mew=0.6, zorder=3)
    ax.plot(xo, yt[ok], "-o", color=VERM, lw=0.7, ms=2.4, zorder=4)
    ax.set_yscale("log")
    top = max(np.nanmax(yt), np.nanmax(ym))
    ax.set_ylim(floor * 0.7, top * 2.2)
    dec = [10 ** k for k in range(0, int(math.log10(top)) + 1)]
    ax.set_yticks([floor] + dec)
    ax.set_yticklabels(["0"] + [f"{v:,.0f}" for v in dec])
    ax.yaxis.set_minor_locator(mticker.NullLocator())
    for yb_ in (0.62,):
        ax.plot([-0.025, 0.025], [yb_ * 0.93, yb_ * 1.07], transform=mtrans.blended_transform_factory(
            ax.transAxes, ax.transData), color="black", lw=0.5, clip_on=False, zorder=6)
    thr = _val(_row(st, "hmm_recent", d["R"]), "near_threshold")
    if not np.isfinite(thr):
        thr = _val(_row(st, "hmm_ancestry", d["R"]), "near_threshold")
    xthr = None
    if np.isfinite(thr) and thr > 0:
        for xx, (lo, hi, p) in zip(xs, sl):
            if lo > 0 and np.isfinite(hi) and lo <= thr < hi:
                xthr = xx - 0.5 + (math.log(thr) - math.log(lo)) / (math.log(hi) - math.log(lo))
        if xthr is not None:
            ax.axvline(xthr, color="#8C8C8C", lw=0.5, ls=(0, (2.2, 1.6)), zorder=0)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_ylabel("orthologs per divergence bin")
    ax.set_xlabel("divergence between orthologs (%)")
    return dict(slots=sl, nt=nt, nm=nm, cal=cal, thr=thr, xthr=xthr)


TESTS = [("D_kmer", "single-copy\nk-mers"), ("D_ins", "shared\ninsertions"), ("D3_triples", "ortholog\ntriples"),
         ("D_self_outgroup", "LTR sites, own\nLTR as outgroup")]


def _panel_F(ax, d):
    st = d["stats"]
    rows = []
    for i, (t, lab) in enumerate(TESTS):
        r = _row(st, t, "all") if t in ("D_kmer", "D_ins", "D3_triples") else _row(st, t)
        if r is None:
            r = _row(st, t)
        if r is None:
            continue
        Dv, se, Z = _val(r, "D"), _val(r, "SE"), _val(r, "Z")
        rows.append((t, lab, Dv, se, Z, _val(r, "nA"), _val(r, "nB"), i))
    if not rows:
        ax.axis("off")
        return None
    for t, lab, Dv, se, Z, nA, nB, i in rows:
        if np.isfinite(se):
            ax.plot([Dv - 2 * se, Dv + 2 * se], [i, i], color=DARK, lw=0.7, zorder=2)
        ax.plot([Dv], [i], "o", ms=3.2, mfc=DARK, mec=DARK, zorder=3)
    ax.axvline(0, color="#8C8C8C", lw=0.6, zorder=1)
    ax.set_ylim(len(TESTS) - 0.4, -0.6)
    ax.set_yticks([i for *_, i in rows])
    ax.set_yticklabels([lab for _, lab, *_ in rows])
    ax.tick_params(axis="y", length=0)
    lo = min([0] + [Dv - 2 * se for _, _, Dv, se, *_ in rows if np.isfinite(se)] + [Dv for _, _, Dv, *_ in rows])
    hi = max([0] + [Dv + 2 * se for _, _, Dv, se, *_ in rows if np.isfinite(se)] + [Dv for _, _, Dv, *_ in rows])
    pad = 0.1 * (hi - lo if hi > lo else 1)
    ax.set_xlim(lo - pad, hi + pad)
    ax.xaxis.set_major_locator(mticker.MaxNLocator(4))
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    ax.set_xlabel("D genome-wide (± 2 SE)")
    return rows


# ---------------------------------------------------------------------------------------------------------------------
# Figure
# ---------------------------------------------------------------------------------------------------------------------
def _counts(d, chroms):
    """Element classes on the drawn sequences; tract and decoy counts genome-wide (as in findings.txt)."""
    el = d["el"]
    vc = el.loc[el["chrom"].isin(set(chroms)), "class"].value_counts()
    c = {k: int(vc.get(k, 0)) for k in INFORMATIVE}
    c["other"] = int(vc.sum() - sum(c.values()))
    tr = d.get("tracts")
    hi = _hi_conf(tr) if tr is not None else np.zeros(0, bool)
    c["tracts"] = 0 if tr is None else int(len(tr))
    c["tracts_high"] = int(hi.sum())
    dec = d.get("decoy")
    c["decoys"] = 0 if dec is None else int(len(dec))
    return c


def _figure(d, mu):
    R, S, D = d["R"], d["S"], d["D"]
    st = d["stats"]
    chroms, ext, dropped, n_drop = _chromosomes(d)
    n = len(chroms)
    rh = min(ROW_H, 10 * ROW_H / max(n, 1))      # panel A keeps the height of 10 full rows
    z = _zoom_choice(d, chroms)
    if z:
        z["short"] = _short(chroms)[z["chrom"]]
    has_B = any((st["test"].astype(str) == t).any() for t in ("D_kmer_by_chrom", "D_ins_by_chrom"))
    cnt = _counts(d, chroms)
    itemsC = ([("dot", dict(color=VERM, ms=2.6), f"{D} ortholog"), ("dot", dict(color=BLUE, ms=2.6), f"{S} ortholog"),
               ("line", dict(color="#8C8C8C", lw=0.7, ls=(0, (2.2, 1.6))), "near-identity threshold"),
               ("box", dict(color="white", fc=GRAY), "shared by all, private or near both"),
               ("box", dict(color="#9A9A9A", fc="white"), "unresolved"),
               ("line", dict(color=DARK), "ancestry posterior")]
              + ([("line", dict(color=VERM), "recent posterior")] if d.get("has_recent_post") else []))
    # ---- horizontal grid (mm): A, C and D share the left edge L; B, C and F share the right edge RE
    hom_s = _homologs(d["blocks"], R, S)
    s_short = _short(sorted(set(hom_s.values()), key=_nat)) if hom_s else {}
    lab_w = max([_textw(s, FS) for s in _short(chroms).values()] +
                [_textw(f"{S} {v}", FS_S - 0.5) for v in s_short.values()] + [8.0])
    L = max(16.0, lab_w + 3.0, _textw("ancestry tracts", FS_S) + 2.5)
    RE = FIG_W - 1.5
    B_w = 27.0 if has_B else 0.0
    xB = RE - B_w
    A_w = (xB - 6.0 - L) if has_B else (RE - L)
    # ---- keys (measured first, so the panels start below them)
    itemsA = [("tick", dict(color=VERM, lw=1.2), f"near-identical to {D} ({cnt['near_donor']:,})"),
              ("tick", dict(color=VERM_L, lw=1.2), f"shared with {D}, not {S} ({cnt['donor_only']:,})"),
              ("tick", dict(color=BLUE, lw=1.2), f"near-identical to {S} ({cnt['near_sister']:,})"),
              ("tick", dict(color=BLUE_L, lw=1.2), f"shared with {S}, not {D} ({cnt['sister_only']:,})")]
    if np.isfinite(d["el"]["post_a"]).any():
        itemsA.append(("line", dict(color=DARK, lw=0.8), f"{D}-like ancestry posterior"))
        dm = _val(_row(st, "hmm_ancestry", R), "decoy_posterior_mean")
        if np.isfinite(dm):
            itemsA.append(("line", dict(color="#8C8C8C", lw=0.8, ls=(0, (2.2, 1.6))), f"its mean in {S}"))
    itemsA.insert(4, None)
    if d.get("tracts") is not None:
        itemsA += [None, ("box", dict(color=VERM, fc=VERM), f"recent tract, q ≤ 0.05 ({cnt['tracts_high']:,})"),
                   ("box", dict(color=VERM, fc="none"), f"other recent tract ({cnt['tracts'] - cnt['tracts_high']:,})")]
    if d.get("decoy") is not None:
        itemsA.append(("box", dict(color="#4D4D4D", fc="none"), f"decoy tract in {S} ({cnt['decoys']:,})"))
    itemsB = [("dotbar", dict(color=DARK, mfc="white"), "k-mers"), ("dotbar", dict(color=DARK), "insertions")]
    ky = 2.6
    xmA = [RE, L + A_w] if has_B else [RE]
    yk = _key(None, L, ky, itemsA, xmA, draw=False)
    if has_B:
        yk = max(yk, _key(None, xB, ky + KEY_LH, itemsB, RE + 1.0, size=FS_S, gap=1.6, draw=False))
    # ---- vertical budget (mm)
    A_top = yk + 0.4
    A_h = n * rh
    y = A_top + A_h + 8.0
    C = None
    if z:
        C = dict(top=y + 2.5)
        C["k"] = C["top"] + 1.2                      # key line(s)
        C["y1"] = _key(None, L, C["k"], itemsC, RE, size=FS_S, gap=2.2, draw=False) + 0.6   # divergence axes
        C["h1"] = 15.0
        nr = _zoom_rows(d, z, RE - L)
        C["eh"] = min(1.0, 3.2 / nr)
        C["y2"] = C["y1"] + C["h1"] + 1.2            # element and tract tracks
        C["h2"] = nr * (C["eh"] + 0.2) + 1.0 + 2 * 2.2 - 1.2 + 0.2
        C["y3"] = C["y2"] + C["h2"] + 1.4            # posteriors
        C["h3"] = 6.5
        y = C["y3"] + C["h3"] + 8.0
    DEF_top = y + 6.0
    DEF_h = 32.0
    H = DEF_top + DEF_h + 11.0
    F = _Fig(FIG_W, H)
    # ---- A
    axA = F.ax(L, A_top, A_w, A_h)
    infoA = _panel_A(F, axA, d, chroms, ext, rh, (z["chrom"], z["w0"], z["w1"]) if z else None)
    infoA["counts"] = cnt
    marks = [("A", 1.0, 1.0)]                    # panel letters, assigned in reading order once all are drawn
    _key(F, L, ky, itemsA, xmA)
    out = dict(A=infoA, chroms=chroms, ext=ext, dropped=dropped, n_drop=n_drop, zoom=z, B=None, C=None)
    # ---- B
    if has_B:
        axB = F.ax(xB, A_top, B_w, A_h)
        out["B"] = _panel_B(axB, d, chroms, rh)
        if out["B"] is not None:
            marks.append(("B", xB - 5.5, 1.0 + KEY_LH))
            _key(F, xB, ky + KEY_LH, itemsB, RE + 1.0, size=FS_S, gap=1.6)
    # ---- C
    if z:
        wC = RE - L
        axC1 = F.ax(L, C["y1"], wC, C["h1"])
        axC2 = F.ax(L, C["y2"], wC, C["h2"])
        axC3 = F.ax(L, C["y3"], wC, C["h3"])
        out["C"] = _panel_C(F, (axC1, axC2, axC3), d, z)
        marks.append(("C", 1.0, C["top"]))
        _key(F, L, C["k"], itemsC, RE, size=FS_S, gap=2.2)
    # ---- D, E, F
    wD, gDE, wE, gEF = 40.0, 15.0, 44.0, 24.5
    xD, xE = L, L + wD + gDE
    xF = xE + wE + gEF
    axD = F.ax(xD, DEF_top, wD, DEF_h)
    axE = F.ax(xE, DEF_top, wE, DEF_h)
    axF = F.ax(xF, DEF_top, RE - xF, DEF_h)
    out["D"] = _panel_D(axD, d, mu)
    out["E"] = _panel_E(axE, d)
    out["F"] = _panel_F(axF, d)
    ly = DEF_top - 5.0
    for lab, x, ok in (("D", 1.0, out["D"]), ("E", xE - 14.0, out["E"]), ("F", xF - 23.5, out["F"])):
        if ok is not None:
            marks.append((lab, x, ly))
    letters = {nom: chr(65 + i) for i, (nom, _, _) in enumerate(marks)}
    for nom, x, y_ in marks:
        F.letter(x, y_, letters[nom])
    if infoA.get("loc") is not None:
        infoA["loc"].set_text(letters.get("C", "C"))
    out["letters"] = letters
    if out["E"] is not None:
        cal = out["E"]["cal"]
        mlab = f"{S}–{D}" + (f" (×{1 / cal:.2f})" if abs(cal - 1) > 0.005 else "")
        _key(F, xE, DEF_top - 2.6, [("dot", dict(color=VERM), f"{R}–{D}"),
                                    ("dot", dict(color=BLUE, mfc="white"), mlab)], xE + wE + 12, size=FS_S, gap=2.2)
    return F, out


# ---------------------------------------------------------------------------------------------------------------------
# Legends (generated from the run's own numbers)
# ---------------------------------------------------------------------------------------------------------------------
class _Num:
    def __init__(self):
        self.rows = []

    def __call__(self, key, value, src, fmt="{}"):
        s = fmt.format(value)
        self.rows.append((key, s, src))
        return s


def _p2(x):
    """Percentage with two significant digits (0.003335 -> '0.33')."""
    return "n/a" if x is None or not np.isfinite(x) else f"{x * 100:.2g}"


def _legends(d, out, mu, script):
    """Short and long legend paragraphs [(bold lead, text)], built from this run's numbers; every number quoted in the
    long legend is recorded with its source file."""
    R, S, D = d["R"], d["S"], d["D"]
    st, src = d["stats"], d["src"]
    N = _Num()
    cnt = out["A"]["counts"]
    # ---------------------------------------------------------------- numbers the wording depends on
    F_ = out.get("F") or []
    zs = {t: Z for t, _, _, _, Z, *_ in F_}
    nstrong = sum(1 for Z in zs.values() if np.isfinite(Z) and Z >= 3)
    nweak = sum(1 for Z in zs.values() if np.isfinite(Z) and Z >= 2)
    ntest = len(zs)
    verdict = "flow" if ntest and nstrong >= max(3, ntest - 1) else ("none" if nweak == 0 else "mixed")
    Dage = out.get("D") or []
    young, old = (Dage[0], Dage[-1]) if len(Dage) >= 2 else (None, None)
    rises = bool(young and old and young[2] > old[2] + 2 * math.hypot(young[3], old[3]))
    E = out.get("E")
    if E is not None:
        sl, nt, nm = E["slots"], E["nt"], E["nm"]
        lowm = np.array([(p is not None) and hi <= 0.002 + 1e-12 for lo, hi, p in sl])
        n_t_low, n_m_low = float(np.nansum(nt[lowm])), float(np.nansum(nm[lowm]))
        ratio_low = n_t_low / max(n_m_low, 1.0)
    else:
        n_t_low = n_m_low = ratio_low = np.nan
    flow = _val(_row(st, "f_lower_bound"), "f")
    ha, hr = _row(st, "hmm_ancestry", R), _row(st, "hmm_recent", R)
    pm, dm = _val(ha, "posterior_mean"), _val(ha, "decoy_posterior_mean")
    thr = _val(hr, "near_threshold")
    if not np.isfinite(thr):
        thr = _val(ha, "near_threshold")
    ntr, nhi, ndec = cnt["tracts"], cnt["tracts_high"], cnt["decoys"]
    B = out.get("B") or {}
    kk, ii = B.get("D_kmer_by_chrom", []), B.get("D_ins_by_chrom", [])
    C, z = out.get("C"), out.get("zoom")
    # ---------------------------------------------------------------- short legend
    sh = []
    if verdict == "flow":
        sh.append(("", f"{R} shares more young LTR-retrotransposon insertions and more near-identical copies with {D} "
                       f"than its sister {S} does: gene flow between the {D} and {R} lineages after {R} and {S} split. "
                       f"Sorting of ancestral variation would share copies with both sisters equally."))
    elif verdict == "none":
        sh.append(("", f"{R} and its sister {S} share LTR retrotransposons with {D} equally: no excess sharing, and so "
                       f"no gene flow with {D}, is detected. Stretches of {D}-like ancestry in {R} are as many as "
                       f"chance yields in {S}."))
    else:
        sh.append(("", f"Evidence that {R} shares more LTR retrotransposons with {D} than its sister {S} does is "
                       f"weak or inconsistent: gene flow between {D} and {R} is not established by this run."))
    sh.append(("A", f"The {R} genome, chromosome by chromosome. Each tick is one element whose copy is near-identical "
                    f"to, or shared only with, {D} (above) or {S} (below). The trace follows {D}-like ancestry; boxes "
                    f"mark stretches of recent shared ancestry with {D}; the gray bar beneath each chromosome shows the "
                    f"stretches that chance alone yields in {S}."))
    if kk or ii:
        allr = kk + ii
        frac = sum(1 for r in allr if r[2] > 0) / max(len(allr), 1)
        sh.append(("B", f"Excess sharing with {D}, chromosome by chromosome: "
                        + ("spread over nearly every chromosome." if frac >= 0.8 else
                           "present on some chromosomes, absent from others." if frac >= 0.5 else
                           "absent from most chromosomes.")))
    if C and z:
        inner = C["k_in"] / max(C["n_in"], 1)
        outer = C["k_out"] / max(C["n_out"], 1)
        sh.append(("C", "One typical stretch, element by element: "
                        + ((f"inside it, {R}'s elements are closer to their {D} copies than to their {S} copies; "
                            + ("outside, mostly the reverse." if outer < 0.5 else "outside, less often."))
                           if inner > outer + 0.15 else
                           f"its elements are about as close to their {D} copies as the flanking ones.")))
    if Dage:
        sh.append(("D", "Excess sharing by insertion age: "
                        + ("strongest among the youngest insertions, as expected from recent gene flow rather than "
                           "old shared variation." if rises else "no rise among the youngest insertions, where recent "
                           "gene flow would show most.")))
    if E is not None:
        sh.append(("E", f"Copies near-identical between {R} and {D} "
                        + ("far outnumber" if ratio_low >= 3 else "outnumber" if ratio_low >= 1.3 else "match")
                        + f" those between {S} and {D}."))
    if F_:
        sh.append(("F", "Four different genome-wide measures of excess sharing "
                        + ("agree." if verdict == "flow" else "find none." if verdict == "none" else "disagree.")))
    # ---------------------------------------------------------------- long legend
    lg = []
    nb = _val(_row(st, "D_kmer", "all"), "nblocks")
    m = re.search(r"blocks of ([\d.]+) Mb", d.get("findings", ""))
    blk = f" over {N('jackknife_blocks', int(nb), src['stats'])} blocks" if np.isfinite(nb) else ""
    if m and blk:
        blk += f" of {m.group(1)} Mb"
    lg.append(("", f"{R} and {S} are the sister genomes (the pair sharing most single-copy k-mers), {D} the third; {R} "
                   f"is the sister sharing more with {D}. Near-identical: ortholog divergence below "
                   f"{N('near_threshold_pct', _p2(thr), src['stats'])}% (5th percentile of {S}–{D} orthologs). "
                   f"D = (a − b)/(a + b), a counting what {R} shares with {D} and b what {S} shares with {D}; 0 "
                   f"without gene flow. Error bars: ±2 SE, delete-one-block jackknife{blk}. q: tract "
                   f"false-discovery rate from decoy tracts, which the same model calls in {S}."))
    a = (f"{len(out['chroms'])} {R} sequences of ≥ {MIN_FRAC:.0%} of the longest, drawn to their last element"
         + (f" ({len(out['dropped'])} shorter or unplaced, holding "
            f"{N('elements_not_drawn', out['n_drop'], src['el'], '{:,}')} elements, omitted)" if out["dropped"] else "")
         + f". Ticks, every element near-identical to its {D} ortholog "
           f"({N('n_near_donor', cnt['near_donor'], src['el'], '{:,}')}) or present in {D} and absent from {S} "
           f"({N('n_donor_only', cnt['donor_only'], src['el'], '{:,}')}) above; near-identical to {S} "
           f"({N('n_near_sister', cnt['near_sister'], src['el'], '{:,}')}) or in {S} and absent from {D} "
           f"({N('n_sister_only', cnt['sister_only'], src['el'], '{:,}')}) below; "
           f"{N('n_not_drawn_classes', cnt['other'], src['el'], '{:,}')} elements shared by all three, private, "
           f"near-identical to both or unresolved are not drawn.")
    if np.isfinite(pm):
        a += (f" Trace: {D}-like ancestry posterior, length-weighted mean per {_bp(out['A']['W'])} window (hatched: "
              f"no elements); genome mean {N('posterior_mean', pm, src['stats'], '{:.3f}')} against "
              f"{N('decoy_posterior_mean', dm, src['stats'], '{:.3f}')} in {S} (dashed).")
    if d.get("tracts") is not None:
        tl = d["tracts"]
        medl = float((tl["end"] - tl["start0"]).median()) if ntr else np.nan
        a += (f" Boxes: {N('n_tracts', ntr, src['tracts'], '{:,}')} tracts of recent shared ancestry"
              + (f" (median {N('tract_median_length', _bp(medl), src['tracts'])})" if np.isfinite(medl) else "")
              + f", {N('n_tracts_q05', nhi, src['tracts'], '{:,}')} with q ≤ 0.05 (filled)")
        if d.get("decoy") is not None:
            a += (f"; beneath each chromosome, its {S} homolog (most collinear anchors; own coordinates) with "
                  f"{N('n_decoy_tracts', ndec, src['decoy'], '{:,}')} decoy tracts in all")
            if ndec:
                a += f": {N('tract_decoy_ratio', ntr / ndec, src['tracts'], '{:.2f}')} tracts per decoy"
        a += "."
        if nhi == 0:
            a += " No tract reaches q ≤ 0.05: single tracts are not resolved."
    lg.append(("A", a))
    if kk or ii:
        b = (f"D per {D} chromosome (k-mers open, insertions filled; ±2 SE), beside the {R} chromosome sharing most "
             f"collinear anchors with it. Above 0: "
             f"{N('chrom_kmer_D_pos', sum(1 for r in kk if r[2] > 0), src['stats'])} of {len(kk)} for k-mers, "
             f"{N('chrom_ins_D_pos', sum(1 for r in ii if r[2] > 0), src['stats'])} of {len(ii)} for insertions; "
             f"Z ≥ 2: {sum(1 for r in kk if np.isfinite(r[4]) and r[4] >= 2)} and "
             f"{sum(1 for r in ii if np.isfinite(r[4]) and r[4] >= 2)}.")
        names = _short(sorted({r[0] for r in kk + ii}, key=_nat))
        neg = sorted({names[r[0]] for r in kk + ii if r[2] < 0}, key=_nat)
        if neg:
            b += f" Below 0: {', '.join(neg)}."
        lg.append(("B", b))
    if C and z:
        t = z["tract"]
        q = float(t["q"]) if "q" in t.index else np.nan
        tier = {"high": f"the {z['n_tier']:,} tracts with q ≤ 0.05",
                "medium": f"the {z['n_tier']:,} tracts with q ≤ 0.2 (none reaches q ≤ 0.05)",
                "all": f"all {z['n_tier']:,} tracts (none reaches q ≤ 0.2)"}[z["tier"]]
        reg = f"{z['short']}:{int(t['start0']) + 1:,}-{int(t['end']):,}"
        lg.append(("C", f"Example typical of the most confident tracts present, not the strongest: among {tier}, the "
                        f"one with the median expected number of {D}-like elements (sum of posteriors, "
                        f"{N('zoom_median_sum_post', z['median_sum_post'], src['tracts'], '{:.1f}')}), "
                        f"{N('zoom_tract', reg, src['tracts'])} ({_bp(float(t['end']) - float(t['start0']))}, "
                        f"{int(t['n_elements'])} elements, q = {N('zoom_q', q, src['tracts'], '{:.2g}')}), with one tract "
                        f"length of flank on each side, widened if needed to ≥ 60 informative elements ({C['n']} "
                        f"elements drawn to size{_minw_note(C)}, colored as in A, stacked where they overlap). Dots: divergence of each element to its {D} (vermillion) and "
                        f"{S} (blue) ortholog, joined; 'absent': no ortholog in the collinear interval. Inside the "
                        f"tract {N('zoom_in_closer_D', C['k_in'], src['el'])} of {C['n_in']} elements with both "
                        f"orthologs are closer to {D} than to {S}; in the flanks "
                        f"{N('zoom_out_closer_D', C['k_out'], src['el'])} of {C['n_out']}. Below: ancestry (black) "
                        f"and recent (vermillion) posteriors and both models' tracts."))
    if Dage:
        def lab(lo, hi):
            if hi == 0:
                return "identical LTRs"
            if not np.isfinite(hi):
                return f"> {_pct(lo)}%"
            return f"{_pct(lo)}–{_pct(hi)}%"
        parts = "; ".join(f"{lab(lo, hi)} {N(f'Dins_age_{lab(lo, hi)}', Dv, src['stats'], '{:+.2f}')} "
                          f"(n = {nA + nB:,})" for lo, hi, Dv, se, Z, nA, nB in Dage)
        dd = (f"D from insertions present in one sister and in {D} but absent from the other, by the age of the {D} "
              f"copy: the K2P divergence between its two LTRs, identical at insertion (strata in %; strata with "
              f"fewer than 10 insertions omitted"
              + (f"; top axis, kyr at {mu:g} substitutions per site per year" if mu else "") + f"). {parts}.")
        dd += (" The excess is largest among the youngest insertions, as expected for recent gene flow; sorting of "
               "ancestral variation would give D = 0 at every age." if rises else
               " D does not rise among the youngest insertions.")
        lg.append(("D", dd))
    if E is not None:
        lg.append(("E", f"Orthologs per divergence bin (doubling bins; 0 = identical): {R}–{D} (vermillion) and "
                        f"{S}–{D} (blue, scaled ×{N('mirror_scale', 1 / E['cal'], src['stats'], '{:.2f}')} to equal "
                        f"totals above the median divergence). Below 0.2%: "
                        f"{N('n_RD_below_0.2pct', n_t_low, src['stats'], '{:,.0f}')} vs "
                        f"{N('n_SD_below_0.2pct', n_m_low, src['stats'], '{:,.0f}')} "
                        f"({N('ratio_below_0.2pct', ratio_low, src['stats'], '{:.1f}')}×). The shaded excess is a "
                        f"lower bound on the admixed fraction of {R}'s {D} orthologs: "
                        f"{N('f_lower_bound', flow, src['stats'], '{:.3f}')}. Dashed: near-identity threshold."))
    if F_:
        names = {"D_kmer": "single-copy k-mers", "D_ins": f"insertions shared with {D}, absent from the other sister",
                 "D3_triples": "divergence of ortholog triples (D3)",
                 "D_self_outgroup": "ABBA/BABA at LTR sites polarized by the element's other LTR"}
        parts = "; ".join(f"{names.get(t, t)} {N(f'{t}_D', Dv, src['stats'], '{:+.3f}')} ± "
                          f"{N(f'{t}_SE', se, src['stats'], '{:.3f}')} (Z = {N(f'{t}_Z', Z, src['stats'], '{:.1f}')})"
                          for t, _, Dv, se, Z, *_ in F_)
        ff = f"Genome-wide D: {parts}; {nstrong} of {ntest} reach Z ≥ 3."
        cr = _row(st, "completeness_ratio")
        if cr is not None:
            ratio, se = _val(cr, "ratio"), _val(cr, "SE")
            off = abs(ratio - 1) > 2 * se
            ff += (f" Annotation completeness ({D}'s old insertions present in {R} vs {S}): "
                   f"{N('completeness_ratio', ratio, src['stats'], '{:.3f}')} ± "
                   f"{N('completeness_SE', se, src['stats'], '{:.3f}')}"
                   + (", off 1: k-mer and insertion counts may be biased toward the better-annotated sister; "
                      "triples and LTR sites are not." if off else ", consistent with 1."))
        lg.append(("F", ff))
    lg.append(("", "Assumptions: k-mer and insertion counts need comparable annotation completeness and branch lengths "
                   "in the two sisters; the LTR-site test does not. With one genome per taxon the direction of gene "
                   "flow is not resolved, sorting of ancestral variation makes some single stretches look "
                   f"{D}-like, and tracts shorter than the spacing of informative elements are missed."))
    host = socket.gethostname().split(".")[0]
    adir = os.path.dirname(os.path.realpath(os.path.join(d["outdir"], "stats.tsv")))   # where the run's tables live
    lg.append(("", f"Analysis: {host}:{adir} · Script: {script} · {datetime.date.today().isoformat()}"))
    lm = out.get("letters", {})
    sh = [(lm.get(k, k) if k else k, t) for k, t in sh]
    lg = [(lm.get(k, k) if k else k, t) for k, t in lg]
    return sh, lg, N.rows


def _text_page(pdf, paras, width_mm, family, size=10.0):
    """One legend page: width of the figure, height fitted to the text; panel letters bold."""
    def tw(s, bold=False):
        return _textw(s, size, "bold" if bold else "normal")

    margin = 10.0
    avail = width_mm - 2 * margin
    lh = size * 0.3528 * 1.32
    pgap = 0.55 * lh
    layout = []
    for lead, text in paras:
        lw = tw(lead + "  ", True) if lead else 0.0
        words = text.split()
        lines, cur, first = [], "", True
        for w_ in words:
            trial = (cur + " " + w_).strip()
            if tw(trial) > avail - (lw if first else 0) and cur:
                lines.append(cur)
                cur, first = w_, False
            else:
                cur = trial
        if cur:
            lines.append(cur)
        layout.append((lead, lw, lines))
    nlines = sum(len(x[2]) for x in layout)
    H = 2 * margin + nlines * lh + (len(layout) - 1) * pgap
    fig = plt.figure(figsize=(width_mm * MM, H * MM))
    y = margin
    for lead, lw, lines in layout:
        if lead:
            fig.text(margin / width_mm, 1 - y / H, lead, fontsize=size, fontweight="bold", va="top", ha="left")
        for i, ln in enumerate(lines):
            x = margin + (lw if i == 0 else 0)
            fig.text(x / width_mm, 1 - y / H, ln, fontsize=size, va="top", ha="left")
            y += lh
        y += pgap
    pdf.savefig(fig)
    plt.close(fig)


# ---------------------------------------------------------------------------------------------------------------------
# Entry points
# ---------------------------------------------------------------------------------------------------------------------
def overview(outdir, mu=None, verbose=False):
    """Write overview.png, overview.pdf (figure + short legend + long legend) and overview_numbers.tsv into outdir,
    from the ltrmix outputs there. mu (substitutions per site per year), if given, adds an age axis in kyr.
    Returns the paths written."""
    _VERBOSE[0] = verbose
    t0 = time.time()
    fam = _font_family()
    with plt.rc_context(_rc(fam)):
        d = _load(outdir)
        _log(f"{d['R']} (sister {d['S']}, donor {d['D']}): {len(d['el']):,} elements", True)
        F, out = _figure(d, mu)
        script = os.path.abspath(__file__)
        sh, lg, nums = _legends(d, out, mu, script)
        png = os.path.join(outdir, "overview.png")
        pdfp = os.path.join(outdir, "overview.pdf")
        F.fig.savefig(png, dpi=300)
        with PdfPages(pdfp) as pdf:
            pdf.savefig(F.fig, dpi=300)
            _text_page(pdf, sh, F.w, fam)
            _text_page(pdf, lg, F.w, fam)
        plt.close(F.fig)
        nump = os.path.join(outdir, "overview_numbers.tsv")
        with open(nump, "w") as fo:
            fo.write("name\tvalue\tsource\n")
            for k, v, s in nums:
                fo.write(f"{k}\t{v}\t{s}\n")
    _log(f"overview written ({time.time() - t0:.1f}s): {png}, {pdfp}")
    return [png, pdfp, nump]


def main(argv=None):
    ap = argparse.ArgumentParser(description="Overview figure (PNG + 3-page PDF) of one ltrmix trio output "
                                             "directory.")
    ap.add_argument("outdir", help="ltrmix trio output directory (stats.tsv, elements.<R>.tsv, ...)")
    ap.add_argument("--mu", type=float, default=None,
                    help="substitutions per site per year; adds an age axis in kyr to the insertion-age panel")
    ap.add_argument("-v", "--verbose", action="store_true", help="per-step progress")
    a = ap.parse_args(argv)
    if not os.path.isdir(a.outdir):
        sys.exit(f"ERROR: not a directory: {a.outdir}")
    try:
        overview(a.outdir, mu=a.mu, verbose=a.verbose)
    except (FileNotFoundError, ValueError) as e:
        sys.exit(f"ERROR: {e}")


if __name__ == "__main__":
    main()
