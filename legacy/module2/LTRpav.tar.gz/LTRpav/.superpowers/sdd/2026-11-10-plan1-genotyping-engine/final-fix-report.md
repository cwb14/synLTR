# Plan 1 final fix wave: report

Status: DONE_WITH_CONCERNS. Worktree `/data2/chris/maize_introgression/LTRpav_finalfix`, branch `plan1-final-fixes`,
base 7d71073, head **886c6d8** (19 commits, none pushed, existing identity cwb14, no trailers). The main working
tree, the main3 run (PID 2457144) and its outputs were not touched. Scratch and probes:
`/data2/chris/maize_introgression/benchmark_pav/final_fix/` (`memo.md` lists every command).

**Verification.** `ltrpav.__file__` resolved into the worktree from `python -c` and from the `ltrpav` console script
(PYTHONVERBOSE: 0 imports from the main tree). After every commit: `pytest -W error` from the worktree (784 tests at
base, **863 at head**, all passed) and `ruff check .` clean (`final_fix/run_tests.sh`).

## Commits

| # | commit | subject | findings |
|---|---|---|---|
| 1 | f4eabba | Score every LASTZ window as asm20, whatever the pair's divergence | C1 |
| 2 | 06c2f53 | Key every stage by the engine fingerprint and its tools' versions | I2; T15, T17, T21 (stale pair files), 24H(1) |
| 3 | 9c1333a | Compute reciprocity and annot_agree as DESIGN 10.1 defines them | I1 |
| 4 | 8ddd669 | Warn and skip malformed annotation records, naming file and line | I3; T5, T6, T7, T9 |
| 5 | 0f986b1 | Clean up a dying worker's LASTZ child and temp folder | 24H(5); T16 docs; M8 |
| 6 | a050213 | Report each element's own anchor distances | 24H(2); T11 |
| 7 | 7b7577d | Move the remaining thresholds into constants.py, with reasons | M3, 24H(3); T10, T15 |
| 8 | 1817fda | Refresh DESIGN.md and docstrings that no longer match the engine | M1, M4, M11, 24H(4), 24H(7); T24F |
| 9 | f494b20 | Add the tests the reviews deferred | 24H(6); T1, T10, T12, T18, T24F, T24G |
| 10 | 14f7e30 | Harden FASTA indexing and the samples sheet | T3, T4, T16, T21 |
| 11 | 3c1fc17 | Validate pair-file sites and harden the track writers | T19, T20 |
| 12 | 555f797 | Tidy genotyping's files, chunk order and logs | M7; T15, T16, T17, T21, T24F |
| 13 | 4df38b0 | Let ltrpav-sim take donors from unrated annotations; check score inputs | M6; T23 |
| 14 | 84c8088 | Make the lock file portable and run CI's pytest at one -q | T1 |
| 15 | 4f8d13f | Read an S call's LTR image once and visit window members once | T24G, T14 |
| 16 | a224c6c | Test junction slides and annotation dispatch edge cases | T13, T8 |
| 17 | fe11e07 | Fill the remaining small test gaps from the ledger | T3, T7, T11, T17, T23 |
| 18 | 9f4143f | State the measured call changes in DESIGN 9 and 5.6 | M4 (counts measured below) |
| 19 | 886c6d8 | Pin the E/D boundary at two TSD lengths and one base more | T14 |

## Critical and Important

**C1, LASTZ under asm5/asm10 scoring: fixed (f4eabba).**
- `lastz_args()` takes no preset: SCORE (asm20: 1, 4, 6, 2), ydrop 166, for every pair. `_align_lastz` still checks
  the preset name (an unknown one fails) but ignores it. mappy keeps `PRESET_CUTS`. Docstrings, `PRESET_CUTS`'
  reason and DESIGN 5.3 updated.
- Test `test_close_pair_with_divergent_patches`: the reviewer's probe scaled down (4 sites, E P E P, 5-kb
  elements, 5% patches of element +- 1.5 kb, 300-kb identical spacers, mm2 route, default backend). The test
  asserts the pair's d <= 0.001 (0.00073: preset asm5) and E, P, E, P.
  - RED on the old code (seed 1): E -> D high, E -> U, P -> T, P -> T.
  - Probe over seeds 1-8 (`probes/c1_probe.py`): asm20 is 32/32 right; the pair preset gave D high in 3 seeds.
- Test `test_every_preset_runs_lastz_as_asm20` (stub lastz): both strands get `lastz_args()` under asm5, asm10
  and asm20.
- Sims and chr10 have d >= 0.015, so their calls are unchanged (below).

**I1, QC reciprocity and annot_agree: fixed (9c1333a).** The bars are unchanged.
- reciprocity: among links seen either way whose two calls are both resolved (P/S/T/E), the share with both
  present (the review's definition).
- link_symmetry: the old quantity, renamed. The review names it and shows it answers another question (does
  each projection find the other's element?).
- annot_agree: counts a call only if a B element is at its site. An element reaching more than w past both
  site ends (w = SLOP_TSD_MULT x the element's TSD length: the classifier's own end tolerance, no new
  threshold) spans the site and is set aside. The old annot_agree answered no named question, so it was not
  kept.
- e_in_annot: E calls overlapping a B element, as the bar says; it counted "inside" before.
- Tests with hand-computed values:
  - `test_qc_reciprocity` (2/3 against link_symmetry 1/5);
  - `test_qc_annot_agree_needs_a_b_element_at_the_site` (1/4, e_in_annot 5/6, the w and w + 1 boundary);
  - updated expectations in three older QC tests (each computed by hand in its comments).
- On the bake-off's chr10 flank-mm2_2k pair files (read-only, `i1_qc/`):
  - reciprocity 0.9878, 0.9942, 0.9859 (the review's probe: 0.988, 0.994, 0.986); link_symmetry 0.875-0.900;
  - annot_agree 0.979-0.989 (old 0.770-0.828);
  - e_in_annot 0.1425-0.1606, one direction 0.1485 -> 0.1492 (overlap, not inside).
- annot_agree sets aside 556-613 calls per direction (`decompose_flank-mm2_2k.txt`): E and D sites more than
  1 kb inside a B element (about 400), 101-1000 bp (about 110-125), 11-100 bp (3-30), and 40-60 present calls
  inside B hosts.

**I2, stale checkpoints: fixed (06c2f53).**
- `stage_key` holds `engine_fingerprint()`: the sha256 of every `*.py` under the package (relative path, length,
  bytes), computed once per process.
- Each stage's params hold its tools' versions (`checkpoint.tool_version`, cached per binary). FastGA has no
  version flag, so the sha256 of its binary stands in.
  - genotype pair and chunks: lastz's, or mappy's (`localign.backend_version`);
  - mm2 index, mm2 and flank-mm2 routes: minimap2 and mappy;
  - flank-blast: blastn and makeblastdb; blastdb: makeblastdb;
  - fastga: the binary's sha256;
  - elements of a BED: mappy.
- Markers record the engine. A pair marker also records A's elements digest, and `ltrpav-merge` refuses a pair
  file from another engine or annotation (the T21 stale-pair-file minor).
- The manifest records the engine fingerprint, lastz and makeblastdb.
- DESIGN 8: outdirs from an older engine are recomputed, not reused.
- Tests:
  - `test_stage_key_follows_the_engine`: one source byte changed in a copy of the package, through a patched
    fingerprint function, changes the key;
  - `test_source_fingerprint_follows_every_source_byte`;
  - `test_outdir_of_an_older_engine_is_recomputed`: an outdir from an "older engine" reruns every stage, and
    merge refuses its pair files, then those of another annotation;
  - `test_calls_key_follows_the_aligner_not_the_anchor_file_time`;
  - `test_tool_version`, `test_marker_records_engine_and_meta`.
- Not done: the review's "windows checksum in the pair key". The fingerprint covers window construction, and
  anchors plus elements cover its inputs.

**I3, malformed annotation records: fixed (8ddd669).**
- GFF3 parses only LTR-RT and long_terminal_repeat lines. A malformed `gene` line is never read: no warning, no
  abort.
- A malformed record of any loader is skipped with a warning `file:line: record skipped, <reason>: <why>` for
  the first RECORD_WARNINGS (5; new constant, reason and link to I3), and counted by reason:
  - GFF3 and BED: malformed_columns, malformed_coordinates;
  - LTRquest: bad_seq_id, malformed_columns, malformed_coordinates, malformed_ltr_bounds, malformed_k2p;
  - PAF records too.
- One-line errors:
  - an LTRquest header without a required column (names the file and column);
  - an unreadable or corrupt file (EOFError, BadGzipFile, OSError);
  - no usable record;
  - records outside the FASTA (line numbers given).
- Counts reach the log (summary line, and the elements stage's skip line), qc.tsv (`skipped_<reason>`) and
  manifest.json (per sample).
- Also: CRLF lines, NaN K2P as unknown, GFF3 seqid percent-decoding (and encoding in `write_gff3`), literal
  LTRquest prefixes (glob.escape), `_attrs` returning parents apart.
- Tests: one per loader (file:line warnings, the warning cap, counts), the dispatcher (no usable record,
  truncated and fake gzip) and the CLI on the review's probes. A bad gene line runs; a missing ltr3_end gives
  one error line without a traceback.
- Elements are identical, old against new loader, for the sims' GFF3s and chr10's LTRquest tables
  (`i3_elements/`). All 390,124 whole-genome LTRquest rows in `run/` pass the new checks.

## New minors

| finding | status | commit | test |
|---|---|---|---|
| M1 `inv` is orientation | fixed: DESIGN 5.4 and the classify docstring say it is orientation relative to A, not biology; inversions come from the net's inverted fills | 1817fda | (docs) |
| M2 VCF POS of E without a TSD copy | **skipped**, see Skipped | | |
| M3 thresholds outside constants.py | fixed: LASTZ_SEED, NCAND, MM2_PRESET, BED_LTR_EDGE/MAX and the BLAST limits moved, with reasons (BLAST_MAX_TARGETS and BLAST_MAX_HSPS had none) | 7b7577d | suite |
| M4 DESIGN stale | fixed: 5.1, 5.4, 5.6, section 9, the scaffold cost for both genomes, the net's test wording, CLAUDE.md mentions, the status line | 1817fda, 9f4143f | (docs) |
| M5 CI has no lastz | **skipped**, see Skipped | | |
| M6 sim donors need confidence | fixed: an annotation without confidence values gives every top-level childless element | 4df38b0 | `test_cli_pair_without_confidence_values` |
| M7 straggler chunk | fixed by the review's first option: chunks are submitted largest first (summed window spans). A single slow window still bounds its chunk | 555f797 | `test_large_chunks_are_submitted_first` |
| M8 "cancelled" | fixed | 0f986b1 | (docs) |

## Deferred minors (41)

Required by the brief: all done.
- 24H(2) anchor distances: a050213. Windows carry their anchor positions, and each call measures its own
  distances, nested and merged-window elements included.
- DESIGN 5.1 flank cap: 1817fda. "On the sims 2 kb matches the 10-20-kb caps on accuracy at about half their
  cost (and costs 0.89x as much as 5 kb)".
- DESIGN 9: 1817fda, 9f4143f.
- LASTZ_SCORING and LASTZ_SEED: SCORE in f4eabba, LASTZ_SEED in 7b7577d.
- /dev/shm and orphaned lastz: 0f986b1. Temp folders are named `ltrpav_lastz.<pid>.`. A worker's SIGTERM
  handler kills its lastz child and removes the folder. Each pair sweeps this user's dead-pid folders, never
  the old `ltrpav_lastz_*` names that main3 uses.
- inv_site LASTZ test: f494b20.
- 88 kb: 1817fda.

| ledger | status | commit / reason |
|---|---|---|
| L74 T1 lock file | fixed | 84c8088 |
| L75 T1 smoke test | fixed | f494b20 (THP checked in a fresh interpreter) |
| L76 T1 -q, license style | partly | -q 84c8088; the SPDX license string needs hatchling >= 1.27 and dropping the license classifier: Plan 4 packaging, no offline build check |
| L86 T3 string-match re-raise | fixed | 14f7e30 (plain gzip rejected up front) |
| L87 T3 seqio tests | fixed | 14f7e30, fe11e07 |
| L88 T3 stale cached .fai, racing writers | fixed | 14f7e30 (cache name keyed by size and mtime; temp build and rename) |
| L93 T4 resolve() | fixed | 14f7e30 |
| L94 T4 empty fasta, BOM, tests | fixed | 14f7e30 |
| L99 T5 LTRquest | fixed | 8ddd669 |
| L104 T6 GFF3 | partly | 8ddd669. Not done: "LTR outside the span": the ID-parented path keeps accepting it, since filtering could drop real records (none in the test data) |
| L107 T6 `_attrs` | fixed | 8ddd669 |
| L113 T7 BED | fixed | 8ddd669, fe11e07 |
| L119 T8 nesting | partly | tests in a224c6c; start/end checked in the loaders. Skipped: lazy pruning of buried stack entries (cost only in long partial-overlap chains; correctness pinned) |
| L124 T9 PAF, a_to_b | partly | 8ddd669. Skipped: the doubled peak memory of the final concatenate (non-default paf route) and tests of empty PAF, minus-strand swap and rounding |
| L133 T10 base lost at a trimmed piece's end | skipped | inherent to the linear A->B map; a fix needs per-piece CIGAR maps; stays within WINDOW_PAD |
| L138 T10 DP terms, reasons, strand | fixed | 7b7577d |
| L145 T10 conftest, constant nits | fixed | f494b20, 7b7577d |
| L159 T11 window | fixed | a050213, fe11e07 |
| L170 T12 match, INTh | fixed | f494b20 |
| L183 T13 refinement clipping, `_slide`, throughput | partly | `_slide` tested in a224c6c. Skipped: the joint clipping of the A and B refinement windows (changes D refinements whose deletion reaches within REFINE_PAD of a window edge: a call change needing its own comparison) and throughput |
| L203 T14 | partly | members visited once, identity tier and w + 1 tests: 4f8d13f, 886c6d8. Skipped: the 1-bp TSD read (changes tiers), AlnMap lookups reimplemented (no reachable defect), S calls' solo_tsd evidence (changes every S call's evidence columns) |
| L220 T15 | partly | 555f797, 06c2f53. Skipped: a damaged .mmi of the recorded size (mappy may abort while loading it) and the thread-scaling measurement (Task 25) |
| L224 T15 docstring, MM2_OVERLAP | fixed | 7b7577d |
| L225 T15 pieces under ANCHOR_MIN at a core cut | skipped | mm2 route only; changes its anchors; about 0.1% of alignment ends, within WINDOW_PAD |
| L241 T16 | fixed | 555f797. The npz timestamps are moot: np.savez dates zip members 1980-01-01, so recomputed anchors are byte-identical (tested) |
| L246 T16 | fixed | 0f986b1, 14f7e30, 555f797 |
| L251 T16 PDEATHSIG doc | fixed | 0f986b1 |
| L259 T17 | partly | FastGA in keys (06c2f53), helper order (fe11e07). Skipped: readlink (links are absolute by construction; a relative one only triggers a relink) |
| L261 T17 checksum temp per pid | fixed | 555f797 |
| L264 T17 .lock files, NFS flock | skipped | housekeeping of a non-default route; flock on NFS is an environment limit |
| L274 T18 | partly | sequence-end tests in f494b20. The flank-mm2 toy test still asserts P/E/D only; the default-route CLI world run covers more |
| L278 T18 slow test | fixed | f494b20 (4 s instead of 15 s, same 20k elements and guard) |
| L288 T19 | fixed | 3c1fc17 |
| L296 T20 | fixed | 3c1fc17, 06c2f53 |
| L302 T21 | partly | label all (14f7e30), stale pair files (06c2f53), .fai race (14f7e30). Skipped: checksum timing (a same-size rewrite within mtime granularity; rare) |
| L305 T21 | partly | command lines at DEBUG (555f797), cache errors named (14f7e30). Skipped: the duplicate warnings (genotype's and merge's answer different stages; ltrpav-merge alone needs its own) and a stages module (refactor) |
| L331 T22 O by shared target ids | skipped | simulator truth rule, about 1e-5 per simulation; changes truth tables |
| L338 T23 | partly | 4df38b0, fe11e07. Not done: the CLI joining inputs twice; -v adds nothing |
| L373 T24F | partly | mirror cost, net wording (1817fda), minus-strand parent test (f494b20), labeled INFO and DEBUG wording (555f797). Skipped: the perf test with many kept chains on one sequence (wall-clock; main3 netted 480k blocks in about 9 s) |
| L379 T24G | fixed | 4f8d13f, f494b20 |
| L417 T24H (1)-(7), M11 | fixed | as listed above |

**Counts** (53 findings: 4 Critical/Important, 8 new minors, 41 deferred): **fixed 34**, **partly fixed 13**,
**skipped 6**. No Critical or Important finding was skipped.

## Skipped (whole findings)

- **M2.** VCF POS of E sites without a TSD copy is still 1 bp right.
  - The VCF writer cannot tell a junction site from a TSD-copy site: a junction with b_ins = L - 2 has a copy's
    length. host_empty calls copy the host's site but not its tsd_b.
  - The fix needs a call-level marker, for example a flag on E calls without a copy that inheriting children
    copy, then POS = start for it. That changes the flags of about 11% of E calls, a design call.
  - Impact: 1 bp of POS; REF stays the base at POS (bcftools-consistent); GT is unaffected.
- **M5.** CI never runs the window aligner. Deferred to Plan 4 by ruling, and it cannot be verified without a
  push.
- **T10, T15, T17, T22:** the four skipped ledger lines above (L133, L225, L264, L331), each with its reason.

## Calls comparison

Default `ltrpav run` from the worktree (16 threads) on sims R1_s1 and R3_s2, both directions, and the chr10
B73v5->TIL18 genotype-only run. That run recomputed the flank-mm2_2k anchors, since the engine key changed;
they are byte-identical to the bake-off's, as are the sims' anchors. The same runs from the 7d71073 snapshot
separate Task 24H's changes from this wave's (`final_fix/calls/`, `compare_calls.py`, `anchor_diffs.py`).

| data | head vs 7d71073 | bake-off vs 7d71073 (= bake-off vs head, beyond anchor columns) |
|---|---|---|
| R1_s1 A->B | 250 calls, anchor columns only | 3 state: U->D 2, U->O 1 |
| R1_s1 B->A | 246, anchor columns only | 1 state: U->O |
| R3_s2 A->B | 271, anchor columns only | none |
| R3_s2 B->A | 239, anchor columns only | none |
| chr10 B73v5->TIL18 | 6,410, anchor columns only | 155 state, 19 reason, 1 flags (below) |

- **This wave changed no state, tier, flag, reason, B site or evidence value** in any of the 5 runs. All differing
  anchor columns are nested elements (each now measured from its own ends) or top-level elements of merged
  windows:
  - sims: 172-189 nested and 65-82 merged per direction;
  - chr10: 2,522 of 2,548 nested and 3,888 of 3,888 merged;
  - the nested calls left unchanged are in windows that are not ok (0, 0 both ways).
- **chr10, every difference from the bake-off is Task 24H's** (present already in 7d71073):
  - U->O 101, U->D 20, U->E 5 and U inv_site -> U ambiguous 19 (reason only): the chained minus strand
    (24H item 4);
  - T->U 16, P->U 6, O->U 4, E->U 3 and 1 nested U that gains `inherit`: rule 5a (a) (24H item 1, own calls
    and inheritance).
- The sims' 4 differences are 24H's chained minus strand (all from U). The merged outputs are identical between
  7d71073 and head: loci.tsv, pav_matrix, VCF, GFF3/BED and pav.unplaced. qc.tsv differs only in reciprocity,
  annot_agree and the new link_symmetry (I1). The windows file now lists anchor positions (left_anchor,
  right_anchor) instead of distances.
- Cost: chr10 genotype at 16 threads took 53-54 s for both engines in repeat runs. The first head run took
  77.8 s, its sys time doubled under load.

## Concerns

1. M2 stays open (above). If wanted, a flag such as `junction_site` with POS = start is a small follow-up.
2. Every source edit now recomputes every stage. That includes the simulator package, which is in the ruling's
   fingerprint. Rerunning main3 on this branch recomputes it whole. Expected differences against main3: anchor
   columns, QC (I1) and the manifest. Maize d is about 0.033, so asm20 already applied.
3. annot_agree's principled cut (w = two TSD lengths) sets aside more than the review's 1-kb yardstick:
   0.979-0.989 against 0.93-0.96 on chr10. Task 25 should report the decomposition (`i1_qc/`).
4. An annotation with no usable LTR-RT record now fails the run (I3). A genotype-only genome needs `.`.
5. A worker killed outright (SIGKILL) still leaves its lastz child running. It dies at its next write to the
   closed pipe or when its window finishes (about 35 s on the worst known window). PR_SET_PDEATHSIG through
   preexec_fn would cost 32 ms per spawn at 400 MB RSS, against 1.2 ms (`probes/fork_cost.py`), so it is not used.
6. Sample FASTA paths keep symlinks (T4). The manifest may name a link, and indexes are looked up beside it.
7. Commit 1817fda's message names the file "CLAUDE.md" (whose mentions it removed from DESIGN.md). It is not
   attribution, but the controller may prefer to reword it before publishing; I did not rewrite history.
8. Scripts that read `work/windows/*.tsv.gz` (anchor_left/anchor_right) need the new columns.

## Follow-up (controller's two commits, 2026-11-11)

New branch head: **0ff06eb**. After each commit, `pytest -W error` passed (864 tests) from the worktree and
`ruff check .` was clean.

- **949a2ef "Fingerprint only the engine's own modules"** (concern 2).
  - `engine_fingerprint()` now hashes the package minus `NON_ENGINE = ("sim",)`. The simulator imports the
    engine, never the reverse.
  - The rule is in checkpoint.py's docstring and DESIGN 8: "later analysis or plotting packages get their own
    fingerprints and never invalidate genotyping". Each such package joins NON_ENGINE.
  - Tests:
    - `test_stage_keys_follow_the_engine_modules_only`: on a copy of the package, a sim/ edit leaves all seven
      engine stage keys unchanged, and an engine-module edit changes every one;
    - `test_engine_never_imports_the_simulator`: an AST guard over every engine module, checked on import
      snippets of each form;
    - `source_fingerprint`'s `exclude` is tested too.
- **0ff06eb "Document the E-site position without a TSD copy"** (M2, documentation only, no new flag).
  - The VCF header gains a `##LTRpav_POS` line describing every site's POS: an E site without a readable TSD
    copy is placed at the flank junction, to within 1 bp. It adds "within the few extra bases, at most two TSD
    lengths, the reference may hold there", for E sites with a few B-only bases.
  - The vcf module docstring and DESIGN 6 say the same. DESIGN 6's stale `AA=0` now reads as build decision 5
    (the reference base).
  - Test: `test_vcf_encoding` asserts the header line; `bcftools view -h` reads it.
- Neither commit changes a call.
  - The engine fingerprint, and so every stage key, changes once more, through checkpoint.py and outputs/vcf.py.
  - pav.vcf.gz gains one header line.
- Rulings recorded: M5 goes to Plan 4 packaging; L133, L225, L264 and L331 are skipped as reasoned; the
  partly-fixed residuals stand as listed; commit 1817fda's message is left for the user.

## Follow-up 2: re-review N1, each stage keyed on its own modules (12279a1)

Commit 12279a1 "Key each stage on the modules it depends on" (branch head). `pytest -W error` passed with 886
tests from the worktree, and `ruff check .` was clean.

- **R1, the module sets.** STAGE_MODULES in checkpoint.py; each set is the static import closure of the module
  holding the stage's code. Imports anywhere in a module count; TYPE_CHECKING blocks are skipped. A
  submodule's package `__init__` counts only where something is imported from it. ltrpav/__init__.py and
  checkpoint.py are bookkeeping and are left out.
  - elements (annotation.elements_stage): ltrpav.annotation, constants, elements, seqio
  - anchor (anchor.anchor_pair): ltrpav.anchor, blocks, chain, constants, elements, seqio, window
  - raw (anchor._raw_blocks): the anchor set
  - blastdb (anchor.flanks._blast_db, which imports the package's `_raw_blocks`): the anchor set
  - mm2_index (anchor.mm2._aligner): ltrpav.anchor.mm2, blocks, constants
  - genotype_pair, genotype_chunk (genotype.genotype_pair, which calls anchor_pair): the anchor set, plus
    classify, genotype, junction, localign
  - Outside every set: cli.py, loci.py, outputs/, samples.py, sim/, checkpoint.py.
  - Tool versions in the params, as before.
- **Code moved for this.**
  - The elements stage moved from cli.py into the annotation package (`elements_stage`); cli.py is glue only.
  - The anchor package imports Sample only for type checking, so samples.py left its set.
- **R2.** `test_stage_keys_follow_their_modules_only` edits each of 22 modules in a copy of the package and
  checks exactly which keys change.
  - outputs/vcf.py, outputs/manifest.py, cli.py, loci.py, samples.py, sim/, checkpoint.py and `__init__`
    change none.
  - classify, localign, junction and genotype change the genotype keys only.
  - window changes the genotype and anchor keys.
  - anchor/ and chain change anchor, raw, blastdb and genotype; anchor/mm2 and blocks also mm2_index.
  - annotation/ changes elements only; elements.py and seqio.py change all but mm2_index; constants.py
    changes all.
  - `test_stage_modules_are_each_stages_import_closure` keeps the declared sets exactly equal to the
    closures, so a new import fails the test until STAGE_MODULES follows it.
- **R3.** `package_fingerprint(*modules_or_packages)` and `stage_key(stage, inputs, params, fingerprint=None)`.
  An undeclared stage without a fingerprint is a ValueError.
  - **NON_ENGINE is gone:** no set holds the simulator, so the per-stage sets make it moot.
  - `test_package_fingerprint`: a new ltrpav.analysis package's fingerprint follows its own source and leaves
    the engine keys alone.
- **R4.** Pair markers record the genotype stage's fingerprint (`meta.code`), which `_check_pair_files`
  compares. The merge and output stage is not cached, so it has no key.
  - `test_outdir_of_older_code_is_recomputed_stage_by_stage` runs on a copied package:
    - an outputs/vcf.py comment: every stage is skipped, and merge accepts the pair files;
    - classify.py: merge refuses them, and a rerun recomputes the calls only;
    - constants.py: everything reruns;
    - a new annotation: merge refuses its pair file.
  - The manifest records every stage's fingerprint under `code`.
- **Unchanged outputs.** A fresh `ltrpav run` on sim R1_s1 gives pair files, elements, loci.tsv, pav_matrix,
  qc.tsv and tracks byte-identical to the earlier head run (`final_fix/n1/`).
- **Concerns.**
  1. constants.py is in every set (R1), so appending analysis constants there (Plan 2 Task 1's MG_MAX,
     IDENT_MIN_SITES) still recomputes all genotyping. Plan 2 should keep its constants in its own package.
  2. The import closure over-includes:
     - genotyping also reruns after an anchor/ or chain edit, even when the netted anchors come out the same;
     - raw and blastdb rerun after any anchor-package edit;
     - elements.py and seqio.py are in nearly every set.
  3. Pair files from earlier states lack `meta.code`, so ltrpav-merge on this branch refuses them; that
     includes main3's, which came from 7d71073. Merge them with their own engine, or regenerate them.
