#!/usr/bin/env bash
# Check of the assembly truth with reads of the other haplotype only (after the partition, rule part_bam):
# reads at the flanks 200 bp outside each element end (>= 5 reads = present, 0 = absent).
# usage: truth_check.sh <S>[,<S>...]   -> <S>/truth/<ref>_truth_readcheck.tsv, truth_readcheck.summary.tsv
set -euo pipefail
W=$(dirname "$(readlink -f "$0")"); args=""
for S in ${1//,/ }; do for ref in hap1 hap2; do
  o=$S/truth/${ref}_truth_readcheck.tsv
  [[ -s $o ]] || python $W/truth_reads_check.py $S/truth/${ref}_truth.tsv $S/part/$ref.other.bam $o > $o.log 2>&1
  args="$args $S $ref"
done; done
python $W/truth_check_summary.py $args > truth_readcheck.summary.tsv
