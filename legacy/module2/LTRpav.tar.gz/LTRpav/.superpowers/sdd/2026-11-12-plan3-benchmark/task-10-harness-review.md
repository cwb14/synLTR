# Task 10 harness review (2026-11-14), read-only

Live sha256s equal the package's (genotype_all.sh 9d142c3b, run_lq.sh 146d7bb9, after_grid2.sh cb5bff5b).

## Verdicts
1. genotype_all.sh: OK (real/genotype_all.sh:121-136 lock, :29-38 parsing, :96-120 step files)
2. run_lq.sh: OK (sim/lq/run_lq.sh:117-125)
3. after_grid2.sh: OK, 2 minors (sim/after_grid2.sh:23-37)
4. Task 10 memo: OK, 3 minors (sim/memo.md:358-)

## Checks, genotype_all.sh
- Lock: exec 7>> then flock -n 7; fd 7 has no close-on-exec, so ltrpav-genotype, the sampler and time inherit it. Tested with stubs: worker
  SIGKILLed with a live child -> a second worker sees "held" until the child exits, then the lock is free. This is the right behavior
  (orphan still writing the block's outdir); the block then resumes from checkpoints. TERM path: trap -> finish -> exit frees the lock.
- Every return path of block() after the lock closes fd 7 (held-skip, done-recheck, after block_run). block_run's early returns (overrun,
  failure) return to block(), which closes 7. finish never runs with the lock held except via the TERM trap (exit releases it).
- Race: block.done is rechecked after the lock; block.done is written inside block_run, before release, so a late worker skips. OK.
- Shared markers: <step>.done, block.done, overrun.txt, queue.pause unchanged. Tagged: queue.NAME.*, <step>.NAME.{log,time,mem.tsv,stop,sampler.out}, fai.*.NAME.
  Downstream readers found by grep: only sim/after_grid.sh:40-44 (six/genotype.log|time|mem.tsv, queue.exit/.done untagged; chain has ended).
  No other script reads them. real/memo.md:44-55 documents untagged names only.
- Untagged default: identical to v1 apart from the lock and the log wording at the end.
- Parsing, tested on the extracted loop: `--tag w1 --dry-run`, `--tag` alone, `--tag a.b` behave. Edge cases below.

## Issues
- Minor genotype_all.sh:33 (case charset): `--tag --dry-run` is accepted as TAG="--dry-run" (hyphen is allowed) and runs live with files
  queue.--dry-run.exit; `--tag ""` silently runs untagged (TAG empty, ${TAG:+..} false). Fix: `[ -n "$2" ]` and reject a name starting with "-".
- Minor genotype_all.sh:131: if `exec 7>>` fails (permission, read-only), bash continues and `flock -n 7` fails on a bad fd, so the block is
  logged "held by another queue" and skipped; all blocks could be skipped silently with queue.exit 0. Fix: `exec 7>> ... || { log ERROR; return 1; }`.
- Minor genotype_all.sh:126-128: overrun.txt and queue.pause are checked before the lock, overrun.txt not rechecked after it. A worker
  that waited behind a stop could rerun a block another worker just stopped by overrun. Window is tiny; recheck after the lock.
- Minor: real/memo.md:44-55 does not mention --tag or the lock; memo says "queue complete = queue.done", but with tagged workers
  completion is every block.done (ledger already says so). Add one line.

## Checks, run_lq.sh
- ls of both bins: 621 files in ltrquest_5042a1e/bin; overlap with ltrpav/bin includes python, python3, perl, minimap2, blast*, k8, paftools.js,
  samtools-free names; python and python3 both exist in each env, so a bare `python` is also fixed. Tools only in ltrpav's bin (lastz etc.)
  still resolve through the later PATH entries, as before. PYTHONPATH is unset; NUMBA_CACHE_DIR/PYTHONDONTWRITEBYTECODE from env.sh are harmless.
  Evidence the fix is complete: all three runs finished (lq.done, record check reuse A1 B1 C1). Fix is complete.
- Residual (not a defect): the assertion checks only ltrquest and python3; a later shadow of another tool would not be caught.

## Checks, after_grid2.sh
- Waits: runners by kill -0 (PID reuse in 33 h is negligible); OLD wait ends on OLD gone or the "relaunching" line; verified in
  after_grid.log (line at 13:39:32 follows run_lq.sh, so the old chain's grid steps are finished). Race with OLD's own rerun: closed.
- Exit paths: the actual run exited via line 31 (done exists, exit 0), log 13:39:54. OK.
- Minor after_grid2.sh:37: script exits 0 even if the final pass left rows failing (the last command is an if); only the log says so.
- Minor after_grid2.sh:25-26: it lists grid_rev.tsv.failed rows as failed, but a lock-collision row (pc_C1A1_r2) is not a failure;
  the log line misleads unless the reader knows (the memo explains).

## Memo section: five numbers checked against sources, all match
1. Grid wall 33 h 25 min 23 s = 04:12:16 -> grid.tsv.done 13:37:39 (file content).
2. LTRquest wall 33:01.05 / 33:53.43 / 39:13.02 and max RSS 8609192 / 8601844 / 8616208 kB (ltrquest.time); lq.done peak 141/128, reuse.
3. Samples above 32 running: 13/189, 16/193, 13/224 (threads.tsv recomputed); mean 19.9 and 7 above 96 for null_s101.
4. Peak summed PSS 11.95 GB (grid.log) and 11.23 GB (grid_rev.log); lock collisions at grid.log:1439-1440 and grid_rev.log:409.
5. walltimes.py rerun: every row of the per-kind table, h7 0.591, trio 0.236, 78.8 h reproduced exactly; downstream times 515/342/78... match run.log, ltrmix.time.
- Rerunnable: yes for the table (python walltimes.py, stdlib only), checks, and the commands. Not reproducible from the memo alone: how
  grid_rev.tsv was built (46 rows 99-144, reversed; no command); the launch lines are reconstructions labeled "(ledger)".
- Minor sim/memo.md "reading:" lines and "expected and harmless", "the user allowed more threads" are narration, not facts; "see the ledger
  entry of 2026-11-14 12:20" points to a file outside the repo. Runner 2 start is 08:15:53 in the table and 08:15:51 in the bash block/ledger
  (08:15:51 is the launch, 08:15:53 the first log line); say so or use one.
- Minor: gotcha says rerun walltimes.py before the rescore appends eval lines; the rescore is running and the table still reproduces
  today, so it has not appended yet; state the check ("eval column unchanged") or snapshot the table into a file.

## Assessment: Approved (0 Critical, 0 Important, 8 Minor)
