# Plan 3 handoff (written 2026-11-13 10:30 for a fresh session)

**PLAN 3 COMPLETE (2026-11-14 ~20:40).** All 16 tasks, the final whole-branch review and its one fix wave are done and reviewed; branch plan3-benchmark at 256a914, suite 1,281 passed. Waiting on the user: the branch choice (merge into plan1-engine / keep), decision 11, and the commit-message scrub before any push. Read benchmark_pav/plan3/RESULTS.md first. Do not resume any task below.


Start here, then read `progress.md` in this directory: the ledger, every ruling with its reason.

## What LTRpav is, in one paragraph
LTRpav genotypes LTR-RT insertions as presence/absence across reference genomes and tests for admixture. It
complements LTRmix, which uses LTR-RT libraries alone.
- **Plan 1:** the engine. **Plan 2:** the analyses (D_pav, painting, direction, mechanisms, identity, overview
  figure). Both are done.
- **Preliminary real-data answer:** `benchmark_pav/main3_analyses/PRELIM.md`.
  - Genome-wide, D_pav is +0.29, Z 7.4, and the excess is young.
  - Tracts are not resolved locally at q <= 0.05.
- **Plan 3:** the benchmark. It is running now. **Plan 4:** the head-to-head report, figures and the release.

## Plan 3 state
- **Repo:** branch `plan3-benchmark` at 4f3973e. No main branch, no remote; never push.
- **The grid's code** is the frozen snapshot `benchmark_pav/plan3/snap/4f3973e`.
- **Tasks 1-9 are complete and reviewed:**
  - the simulator (`ltrpav-sim pop`);
  - the painting variants and CLI options;
  - the harness (`plan3/common`, `plan3/sim`);
  - the scoring code (`evalib`, `eval_run`, `eval_ltrmix`, `summarize`);
  - `sim/RULES.md`, pre-registered and dated 2026-11-13, sha256 4111826d…a293. Never edit it.
- **Gate.** At 100 Mb the projections were 111.6 h and 98.4 h, both above 96, so the 50-Mb fallback applied. At 50 Mb
  it chose 30 bottleneck nulls (70.1 h). Every grid run uses `--windows 5`.
- **Calibration.** loss_split 0.123/0.164/0.511/0.202; replace_mean 13,538; t_o 900,000.
- **Realism (pilot) — the simulations are easier than main3:**
  - resolved 0.74-0.77 against 0.46;
  - U 1.5% against 14.6%;
  - 3.6-4x the informative loci per Mb;
  - G 5.5% against 0.02%.

  This is reported, never tuned. Task 11 must state that power is optimistic for real data.

## State at 2026-11-14 ~16:30 (read the ledger's 2026-11-14 entries for detail)
- **Done and reviewed:** Tasks 1-12 (Task 12 through launch). Task 10: grid 144/144 (grid.tsv.done 13:37:39),
  3 LTRquest runs, memo. Task 11: rescore (147 runs, final scoring scripts), sim/SIM_RESULTS.md (bars PASS 9 / MISS 7;
  rule 2 and rule 8 are readings), dead_ends entries, decisions commit 6282541 (no variant adopted; direction note
  "not validated by simulation (Plan 3)"), snapshot 2 = snap/6282541 (select with SNAP_SHA=6282541 via common/env.sh).
- **Running:** Task 13 (six genomes) and Task 14 (genus, citrus, EDTA) agents, in parallel; Task 14 stages its memo
  and dead_ends entries in real/genus/*_entry_task14.md for the controller to append after Task 13. Queue workers w4
  (stability/mm2) and w5 (stability/cap5k), nice 10, logs real/queue.w4.log, queue.w5.log; six, genus, citrus, edta
  have block.done.
- **Threads:** the user's other project (poa_synthesis) also runs ~64-96 threads; keep the combined count <= 200 on
  weekends, <= 100 on workdays (memory: count-all-projects-threads).

## Next steps for the session that picks this up
1. Read Tasks 13/14 reports when they land; review each (task reviewer), fix loop, complete. Append Task 14's staged
   entries to real/memo.md and benchmark_pav/dead_ends.md after Task 13 is done.
2. Task 15 (stability) once both stability blocks have block.done; Task 16 (final view with --identity at 32 threads,
   detached; compare_papers final edits; FINAL.md; Plan 3 RESULTS.md; memo_ltrpav.md; DESIGN 12; commit).
   Rulings for Task 16: report both null quantiles of D_pav's Z (default max 1.97, bottleneck max 3.14) and rest the
   verdict on the bottleneck null (ruling I4).
3. Final whole-branch review (SDD references/final-review.md), then hand off to the user (decision 11 evidence:
   nodonor in SIM_RESULTS section 11, genus zd in Task 14).
4. Parked for Plan 4: genotype_all.sh hardening minors; FOUR_LIST_NOTE wording; Task 7 m1 (stale stats advice
   omits --identity); DFOIL-alt saturated-statistic handling and a non-empty-class positive control; D_pav higher
   with LTRquest annotation in 3/3 runs.

## How the work is run
- **Subagent-driven development** (superpowers SDD skill): one implementer per task, a task review, fix rounds, then
  a final whole-branch review. Every decision goes in the ledger as "Ruling: what — why — cost if wrong".
- **Agents cannot wait on long jobs**; they get cut off. The controller launches and watches detached jobs itself and
  dispatches the next agent when a job ends.
- **Before any figure**, load the `making-figures` skill.
- **CLAUDE.md applies:**
  - the user is the sole author (no AI attribution anywhere);
  - long jobs use `setsid -f nohup`;
  - thresholds are set by principle, never tuned to known answers;
  - never present a null as a finding.
- **Rulings digest for Plans 1-2:** `/data2/chris/maize_introgression/rulings_ltrpav.md`.
- **Memo:** `/data2/chris/maize_introgression/memo_ltrpav.md`.
