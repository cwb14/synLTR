"""Fixed internal constants (one place; each with its reason). See docs/DESIGN.md."""

# read evidence
ANCHOR = 100          # bp of aligned sequence a read needs beyond a boundary: past alignment end effects
TAU_REL = 0.03        # allele-length tolerance, fraction of the expected allele span: ONT net indel error ~1%, x3
TAU_ABS = 50          # minimum allele-length tolerance (bp): TSD length (4-6 bp) plus breakpoint misalignment
JUNC_WIN = 300        # window of internal region next to an LTR in which a full-junction read needs ANCHOR aligned bp
SLOP = 60             # bp: an alignment end "is at" a boundary within this distance (TSD + aligner shifts)
RES_WIN = 300         # bp around the expected empty length in which reads inform the annotation's boundary error
BOUND_MIN_SITES = 20  # elements without a TSD, each with >= 2 such reads, needed to estimate that error
BOUND_K = 3.0         # tolerance = BOUND_K x median |per-site offset|: 95th/50th percentile ratio of |error| for
                      # normal or triangular (two uniform ends) errors
CLIP_MIN = 500        # soft clip (bp) that marks one piece of a split read: long enough to place uniquely
CLIP_PROBE = 300      # clip bases aligned to the candidate continuation
SW_MIN_ALN = 150      # aligned columns needed for a clip match
SW_MIN_ID = 0.90      # identity for a clip match: far above chance (~0.5 for unrelated DNA), below read error floors
DEFAULT_TSD = 5       # TSD length assumed when neither the annotation nor the sequence gives one (LTR-RTs: 4-6 bp)

# genotype model
EPS_INIT = 0.02       # read misclassification rate for pass 1; pass 2 uses the per-sample data estimate
EPS_FLOOR = 0.001     # lower bound of the estimate (keeps likelihoods finite with few reads)
EPS_CAP = 0.1         # upper bound of the estimate
EPS_MIN_READS = 10    # informative reads a homozygous site needs to enter the error estimate
CAL_MIN_SITES = 30    # sites with an empty/solo allele needed to calibrate depth at element sites (else genome-wide)
EB_MIN_PER_CLASS = 5  # called sites per genotype class needed to learn the genotype prior (Cochran's rule
                      # for multinomial counts: 50 sites for a diploid); fewer -> flat prior
GQ_CAP = 99           # phred cap of genotype quality
PAV_P = 0.99          # allele-presence posterior for a presence/absence call (1% error, as GQ 20)
DEPTH_LOW = 0.25      # informative depth below this fraction of expected -> low_depth
DEPTH_HIGH = 2.5      # informative depth above this multiple of expected -> high_depth (collapsed duplication?)
FLAG_FRAC = 0.2       # other / unexplained reads at or above this fraction (and FLAG_MIN reads) are flagged
FLAG_MIN = 2
LOWQ_FRAC = 0.3       # share of junction reads with MAPQ < --min-mapq that flags a site low_mapq
N_DEPTH_POINTS = 3000 # random positions sampled per BAM: depth mixture of 1..ploidy copies and the read-span distribution
SEED = 7              # random seed for sampling (reproducible runs)

# source assignment
GQ_STATUS = 20        # genotype quality for a status call (phred 20 = 1% error)
MIN_INTERNAL = 1000   # bp of internal region for a candidate: resolves 0.1% divergence (1 difference)
MIN_ALN = 1000        # aligned bp for a relative
MIN_COV = 0.8         # aligned fraction of the shorter internal region for a relative
MIN_COV_LONG = 0.5    # aligned fraction of the longer one: a short internal region must not match inside a long one
TIE_DIFFS = 0.5       # candidates within half a difference of the best are tied
TOP_K = 20            # candidates per new copy re-aligned exactly after the approximate screen (completeness benchmarked)
N_NEAREST = 10        # nearest other relatives used as the local consensus for shared-mutation counts
CONS_MIN = 3          # relatives needed at a site to call the local consensus base
FLANK = 500           # bp of flank compared between two copies (segmental duplication check)
FLANK_DUP_ID = 0.9    # flank identity at or above this marks a likely segmental duplication
OLDER_DIFFS = 2       # source counted as clearly older if its LTR pair has >= this many more differences
MOSAIC_ALPHA = 0.01   # family-wise error of the two-parent scan test (Bonferroni over candidate pairs)
MOSAIC_COV = 0.9      # a mosaic candidate must cover this fraction of the new copy's internal region
MOSAIC_GAIN = 3       # a mosaic must explain >= this many more differences than the best single candidate

# read phasing (phase.py)
PH_FLANK = 3000       # bp of unique flank on each side compared between reads: ~30 het sites at 1% heterozygosity
PH_MIN_AF = 0.15      # floor of the minor-allele fraction of a heterozygous site (default max(0.15, 0.5/ploidy))
PH_MAX_SITES = 60     # sites nearest the element used per site (bounds work; more add little)
PH_MIN_Q = 20         # base quality for a phasing allele (error <= 1%): on simulated ONT from identical haplotypes,
                      # spurious second haplotypes fell from 13-44% (no filter) to <= 0.4%; real HiFi unaffected
PH_MIN_DIS = 2        # disagreeing sites that prove two read groups distinct
PH_MAX_READS = 80     # reads compared per element (read-name-hash subset): 40 per haplotype of a diploid is plenty;
                      # bounds time and the reads x reads matrices in collapsed repeats
PH_MAX_DIV_NOQUAL = 0.01  # reads without base qualities: phasing only if their median divergence is <= 1% (HiFi)
PH_ERR = 0.05         # spurious extra haplotype group: 4.9% of confirmed one-haplotype sites (C. amara HiFi 20x;
                      # paralog reads from sequence absent from the reference haplotype)
