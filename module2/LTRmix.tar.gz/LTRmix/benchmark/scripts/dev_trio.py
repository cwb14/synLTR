#!/usr/bin/env python3
"""Development harness: run ltrmix up to orthology once (pickled), then re-run trio analyses with alternative HMM
class sets on the same orthology, for real data or a simulation. Not part of the tool."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import argparse
import os
import pickle
import sys

import numpy as np

sys.path.insert(0, "/data2/chris/maize_introgression/LTRmix")
import ltrmix  # noqa: E402


def build(genomes, cache, threads):
    ltrmix.ARGS = ltrmix.argparse.Namespace(verbose=True, threads=threads)
    ltrmix.ARGS_THREADS[0] = threads
    libs = {lab: ltrmix.load_library(lab, sp) for lab, sp in genomes}
    if os.path.exists(cache):
        orth, T, share, block = pickle.load(open(cache, "rb"))
        ltrmix.BLOCK_BP = block
        return libs, orth, T, share
    idx = {lab: ltrmix.Index(l) for lab, l in libs.items()}
    ltrmix.set_block_size(libs)
    labels = [g for g, _ in genomes]
    orth = {}
    for i in range(len(labels)):
        for j in range(i + 1, len(labels)):
            orth[(labels[i], labels[j])] = ltrmix.orthology(libs[labels[i]], libs[labels[j]], idx[labels[i]],
                                                            idx[labels[j]])
    T, share = ltrmix.kmer_tallies(libs, idx, labels[:3])
    pickle.dump((orth, T, share, ltrmix.BLOCK_BP), open(cache, "wb"))
    return libs, orth, T, share


class TrioNoIdx(ltrmix.Trio):
    def __init__(self, libs, orth, trio, threads, outdir, T, share):
        self._T, self._share = T, share
        orig = ltrmix.kmer_tallies
        ltrmix.kmer_tallies = lambda *a, **k: (T, share)
        try:
            super().__init__(libs, None, orth, trio, threads, outdir)
        finally:
            ltrmix.kmer_tallies = orig


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--genome", action="append", required=True)
    ap.add_argument("--cache", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--classes", default="0,2,-1,1,3,-1,-1", help="HMM_CLASS mapping for CATS")
    ap.add_argument("-t", type=int, default=16)
    a = ap.parse_args()
    genomes = [g.split("=", 1) for g in a.genome]
    libs, orth, T, share = build(genomes, a.cache, a.t)
    mp = np.array([int(x) for x in a.classes.split(",")], np.int64)
    ltrmix.HMM_CLASS = mp
    k = int(mp.max()) + 1
    names = {}
    for ci, hi in enumerate(mp):
        if hi >= 0:
            names.setdefault(hi, []).append(ltrmix.CATS[ci])
    ltrmix.HMM_NAMES = ["+".join(names[i]) for i in range(k)]
    tr = TrioNoIdx(libs, orth, [g for g, _ in genomes][:3], a.t, a.out, T, share)
    tr.patterns()
    tr.divergences()
    tr.paint(tr.R, tr.S)
    tr.write()
    print(open(os.path.join(a.out, "findings.txt")).read())


if __name__ == "__main__":
    main()
