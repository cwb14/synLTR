### Task 10: Launch the grid and the LTRquest-annotated runs

**Files** (in `benchmark_pav/plan3/sim/`): `grid.log`, `grid.tsv.done`, `grid.tsv.failed`, `lq/<name>/`, `lq/run_lq.sh`,
and `memo.md` (append).

- [ ] **Step 1: Preconditions.**
  - `pgrep -af 'ltrpav|lastz|ltrmix|ltrquest'` is empty.
  - Record `uptime` and `free -g`.
  - Disk: about 2.3 GB per run, ~330 GB in all on /data2.
  - No environment changes until the grid finishes (Global Constraints).
- [ ] **Step 2: Launch.**
  - `cd sim && setsid -f nohup ./run_grid.sh grid.tsv > grid.log 2>&1 < /dev/null`.
  - Verify the PID: `pgrep -af run_grid.sh`, then `ps -o pid,ppid,sid,cmd -p <pid>`.
  - Wait with a Monitor until-loop on `grid.tsv.done` or `grid.tsv.failed`.
- [ ] **Step 3: Failures.** Rerun each failed row once; markers resume it. A second failure goes to `dead_ends.md` with
  its log. If it is an engine fault, follow the defect protocol.
- [ ] **Step 4: LTRquest runs.** They start after `grid.tsv.done`, because of the thread budget.
  - `git ls-remote https://github.com/cwb14/LTRquest.git HEAD`. If the HEAD is not 5042a1e, install that commit into a
    new env `ltrquest_<commit>`. Record the commit in the memo.
  - `run_lq.sh` runs inside the pinned env: `source $HOME/bin/etc/profile.d/conda.sh; conda activate
    ltrquest_<commit>`. It checks that `command -v ltrquest` lies in that env and never calls the PATH `ltrquest`.
  - For each of `null_s101`, `null_s102` and `f0.18_Ta5000_r1`, in `lq/<name>/`, it runs detached, one at a time at 32
    threads:

    ```
    LTRQUEST_TOOLS_DIR=$P/code/tools OMP_NUM_THREADS=8 ltrquest --genome sim/A1.fa sim/B1.fa sim/C1.fa \
      --proteins $P/inputs/B73v5.proteins.fa.gz --threads 32 --max-rounds 3 --detect-args "ltr-timeout=300" \
      --run-sdust --no-plots --reboundary
    ```

  - Sample its thread count during the first run (`ps -L`). The peak should stay near 32 (`--threads 32` with
    `OMP_NUM_THREADS=8`). If it runs well past 32, lower `--threads` to keep the budget, and record it.
  - Cleanup:
    - keep the `*.work` directories;
    - if the commit is not 5042a1e, first re-check the delete list below against that commit's code (the memory note
      checked it at 5042a1e);
    - delete only `*.bounded.fa.db`, `*.bounded.fa.aa`, `*.fxi`, `*.rexdb.cls.lib`, `*.rexdb.cls.pep` and
      `*.rexdb.dom.faa` inside them;
    - then `python -m ltrquest.record check` must print `reuse` (user memory).
  - The `lq/<name>/` layout:
    - `sim/` links the source run's FASTAs and `truth/`;
    - `sim/samples.tsv` lists A1, B1, C1 with `lq/<name>/{A1,B1,C1}_LTRs`, and O1 with `.`.
  - Then `run_lq.sh` calls `run_one.sh <name> --rundir lq/<name> --from geno`. That runs `geno`, the views, LTRmix on
    the LTRquest prefixes, and `eval`.
  - Task 9's `eval_run.py` scores these runs through its LTRquest branch: `match_by_coords` at slop 10 bp, with
    unmatched elements counted.
  - The same genomes with truth-derived annotation are the paired comparison.
- [ ] **Step 5: Memo.** Record:
  - dates and the snapshot sha;
  - commands;
  - per-kind wall times against the estimates;
  - failures;
  - the LTRquest commit and its `record check` output.

---

