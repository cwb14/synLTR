# Task 12 review: real inputs and the genotyping queue

Reviewed 2026-11-12, 18:31-18:45 EST. The queue (PID 1563670) was running the six block throughout. Nothing was written
in `benchmark_pav/plan3/real/`, and no signal was sent. All probes ran on copies in
`/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t12review/`,
with `PYTHONPATH` on the snapshot's `src`, at most 9 processes, under `timeout 15m`.

`$P=/data2/chris/maize_introgression`, `$R=$P/benchmark_pav/plan3/real`, `$SNAP=$P/benchmark_pav/plan3/snap/12d3e6c`.
File:line references are to the files in `$R` unless a path is given.

## Spec Compliance

| Requirement (brief / rulings) | Verdict | Evidence |
|---|---|---|
| Step 1 test: a toy EDTA GFF3 on seqid `1` in the TIL18 layout (repeat_region with tsd, its TSD and two LTR children, a Copia host, a homology line, an unknown seqid); against `Zn_chr1` it loads as one element, drops the homology line and counts the unknown seqid | ✅ | test_edta_prep.py:14-25, 41-61. Re-run in scratch: 3 passed. ruff passes on edta_prep.py, test_edta_prep.py and cap_variant.py |
| edta_prep keeps `Method=structural` lines whose type ends in `LTR_retrotransposon` or equals `long_terminal_repeat`, and writes no repeat_region line | ✅ | edta_prep.py:74-79. The loader pairs sibling LTRs by `(seqid, Parent)` inside the host span: `$SNAP/src/ltrpav/annotation/gff3.py:113-123` |
| Every seqid gets the prefix; a bare integer N becomes `PREFIX_chrN` only when `PREFIX_N` is absent | ✅ | edta_prep.py:35-42; test_edta_prep.py:64-70 covers the case where both forms exist |
| Records on seqids missing from the `.fai` are dropped and counted; the output is gzip | ✅ | edta_prep.py:80-86, 64-65, 90 (atomic rename); `Zn.prep.json` holds 86,649 dropped records (28,883 hosts) on 3,107 seqids |
| Step 2: six prepared files; B73's is `B73.gff3.gz` with prefix `B73v5`; kept, dropped and loader counts recorded | ✅ | memo.md:31-36; annot_edta/counts.tsv; annot_counts.py:22-29 |
| Kept equals the expected structural count (TIL01 58,346; TIL18 51,214; TIL25 48,503; Zh 55,801; Zn 60,696) | ✅ | counts.tsv. Recomputed independently from the raw GFF3s (below): identical |
| B73, TIL18 and TIL01 give the same loader count as main3's `qc_fixed/edta/*.structural.gff3` | ✅ | counts.tsv, and stronger: the element sets are identical (below) |
| Step 3: sheet labels, order, annotations, groups and roles match the brief in all six blocks; paths are absolute and exist | ✅ | six/samples.tsv:2-8; genus/samples.tsv:2-7 (Zd has no role); citrus/samples.tsv:2-7; edta/samples.tsv:2-5; stability/{mm2,cap5k}/samples.tsv:2-5; check_sheets.py:20-35. Every FASTA, `.fai`, GFF3 and LTRquest prefix was rechecked in a shell loop |
| Each genome uses the annotation source the brief names (LTRquest for six, citrus and stability; EDTA for genus and edta) | ✅ | Same sheets. The `ltrquest_extra` runs finished 2026-11-07 (`$P/benchmark/ltrquest_extra/job.exit`) |
| Step 4: blocks run in order, one at a time, at 32 threads | ✅ | genotype_all.sh:20, 22, 121, 149-151 |
| A marker is written only on success | ✅ | genotype_all.sh:109 writes `<step>.done` only when rc is 0 and there was no overrun (:104-108); :136 writes `block.done` only when there was no overrun (:133), no failure (:134) and it is not a dry run (:135) |
| stability/mm2: `--pair B73,TIL18` runs first and alone, with the tree-PSS sampler | ✅ | genotype_all.sh:123-125. B73 sorts before TIL18, so the whole-genome raw blocks are cached once and reused by TIL18 vs B73 (`$SNAP/src/ltrpav/anchor/__init__.py:167-187`) |
| Peak above 250 GB: the block stops; dead_ends.md and the user report | ✅ (ruled C2-C5) | Kill at the threshold on every step: genotype_all.sh:21, 96-97, 104-108, 133; mem_sampler.sh:15-25. dead_ends.md is the controller's job (ruled); the queue logs `OVERRUN:` at :106 |
| stability/cap5k runs through `cap_variant.py --flank-cap 5000` | ✅ | genotype_all.sh:126-127 |
| Each block runs genotype, then merge, under `/usr/bin/time -v` | ✅ | genotype_all.sh:94, 121, 132 |
| `inputs/*.fai` snapshot before and after | ✅ | genotype_all.sh:34-40, 143-145, 46-51. `fai.preflight.tsv` equals `fai.start.1794525622.tsv`, which equals a fresh snapshot taken at 18:40 |
| cap_variant sets the cap on the route that `cli.get_route` returns, calls `genotype_main`, writes `variant.json`, and the anchor key holds the cap | ✅ | cap_variant.py:51-64, 74-82, 85; flanks.py:132-140 and anchor/__init__.py:130-131 under `$SNAP/src/ltrpav/`. Tested on a toy world (below) |
| R2: snapshot of 12d3e6c; PYTHONPATH; import assertion for python and both console scripts; cap_variant checks its own import | ✅ | genotype_all.sh:18, 23, 60-85; cap_variant.py:44-49. `diff -r` against a fresh `git archive 12d3e6c` matches, apart from `__pycache__` and SHA |
| R3: pause before each block; `paused before <block>`; exit 0 without queue.done; relaunch resumes; tested dry | ✅ | genotype_all.sh:117, 43-57, 25-29, 91. My dry run on a scratch copy prints all 13 steps in the right order |
| R4: pre-flight (pgrep, uptime, free, .fai); `setsid` launch; SID = PID and PPID 1; healthy start; memo with an "Outcome (controller)" placeholder | ✅ | preflight.txt, launch.txt, queue.log, memo.md:85-86. At 18:36, `ps` shows 1563670 with PPID 1, SID and PGID 1563670; six/genotype.log has 0 error and 0 WARNING lines; pair 1/36 finished at 18:39:52 |
| R5: probe limits; read-only inputs | ✅ | annot_counts.py:47 (`--jobs 9`) |
| Global: a done marker and an exit-code file | ✅ | genotype_all.sh:52-53 |
| C1: Zn's chromosome-only rule recorded as an input limitation | ⚠️ | memo.md:72 records the facts as a gotcha. It does not call this an input limitation or cite ruling C1 (Minor M1) |
| C6: bakeoff's real path is used; a route without a cap is refused | ✅ | cap_variant.py:57-59, 69-73; memo.md:74. Toy test: `--anchor mm2` exits 1 |

**Spec verdict: compliant.** One ⚠️ (the C1 wording in the memo, Minor).

## Strengths

- **The prepared annotations match their sources exactly** (my scratch `verify_prep.py`):
  - The raw GFF3 was filtered independently (structural, LTR types, prefix, chr rule) for all six genomes. The result is
    line-for-line identical to each `annot_edta/<L>.gff3.gz`: B73 157,944 lines, TIL18 153,642, TIL01 175,038,
    TIL25 145,509, Zh 167,403 and Zn 182,088.
  - Every raw genome has exactly 2 structural LTRs per structural host. No `long_terminal_repeat` line is homology.
- **Loader output is identical, not just equal in count.** For B73, TIL18 and TIL01, the snapshot's `load_annotation`
  gives the same multiset of elements on the prepared file as on main3's qc_fixed file. Compared fields: seqid, span,
  strand, both LTRs, TSD, superfamily, K and nesting level. Counts: 52,630, 51,206 and 58,332.
- **The Zn seqid mapping is right.** I checked 300 random elements per genome, comparing the host's `tsd` with the
  FASTA on both flanks. Exact matches:
  - B73 220/300; TIL25 198/300; Zh 204/300; Zn 208/300 (all on chr).
  - Zn's rate equals B73's, whose mapping is trivially correct. A wrong mapping would match by chance at about 1e-6.
- **The duplicate explanation holds.** Duplicate host spans in the prepared files: TIL18 8 (including
  `chr1:192977323-192988793`, LTRRT_4951/4952) and Zn 17. These equal the loader's `duplicate` counts
  (`$SNAP/src/ltrpav/annotation/__init__.py:139-145`). The two copies differ only in attributes such as `motif`.
- **cap_variant is correct** (`test_cap_review.py`, run on `tests/test_cli.make_world`):
  - A spy on `flanks.flank_pieces` received cap 2000 in the default run and 5000 under cap_variant.
  - `variant.json` gives `route_params.cap = 5000`.
  - **No silent reuse.** cap5k has its own outdir, and every cache (anchors, mm2 index, checksums, elements, fai)
    lives under `<outdir>/work`. Even when cap_variant runs in the default run's outdir, it re-anchors and recomputes
    the calls, because the anchor key carries `route_params` (anchor/__init__.py:130-131) and the genotype key carries
    the anchors' checksum (genotype.py:103-106).
  - **Better than a straight copy of `run_variant.py`.** That script resets `cli.BACKEND` to `mappy` by default
    (`$P/benchmark_pav/bakeoff/run_variant.py:64, 80`). cap_variant leaves the snapshot's `lastz`, so cap5k differs
    from six only in the cap.
- **The queue's control flow holds on a stubbed copy** (stub `ltrpav-*` whose `--help` is the real one):
  - A merge failure in genus stops the queue: `queue.exit` 1, no `queue.done`, `genus/genotype.done` kept, no
    `genus/block.done`.
  - A relaunch skips six, skips genus genotype, runs genus merge and the rest, and ends with `queue.done`.
- **The stop and guard paths reach every process.**
  - The engine never starts a new session or process group: there is no setsid or `start_new_session`, and the pool
    is a fork pool (genotype.py:317). So `kill -TERM -- -1563670` reaches every worker and every lastz.
  - main3's peak tree PSS on flank-mm2 was 21.1 GB (`main3/mem.tsv`), so the 250-GB guard has more than 10x headroom
    on the flank-mm2 blocks.
- **The frozen code is verified.**
  - The snapshot equals `git archive 12d3e6c`.
  - The engine has no diff from 12d3e6c to 42607ad outside `sim/` and `analysis/`.
  - `checksums.sha256` verifies: all 12 OK.

## Issues

### Critical
None.

### Important
None. No defect was found in the blocks that have not started: genus, citrus, edta, stability/mm2 and
stability/cap5k. Nothing needs the pause point.

### Minor
- **M1. The C1 decision is recorded as a gotcha, not as an input limitation** (memo.md:72).
  - The memo gives the facts: 28,883 structural LTR-RTs (32%) on 3,107 contigs, parity with LTRmix's 60,696, and
    "genus Zn is chromosome-only".
  - It omits the ruling, the words "input limitation", the cost (both tools under-annotate Zn alike) and the effect
    (Zn as B is unaffected).
  - Fix: the controller appends one line to memo.md, for example under "Outcome (controller)". The script does not
    read memo.md, so this is safe while the queue runs.
- **M2. The TERM trap does not forward the signal to its children** (genotype_all.sh:58, 94-99).
  - `kill -TERM 1563670`, without the group minus sign, runs the trap and exits the queue. The running step and its
    sampler keep going, orphaned. A relaunch would then start a second ltrpav-genotype on the same `geno/`.
  - The documented control is the group kill (memo.md:53; ruling C2-C5), so the risk is low.
  - Affects any block while it runs: six now, then the rest.
  - Optional fix at a pause point: kill `$pid` and `$spid` in the trap before `finish`.
- **M3. Nothing stops a second queue from starting** (genotype_all.sh:140-147). There is no lock, such as
  `flock -n queue.lock`. Two queues on one `real/` would write the same outdirs. This only happens through operator
  error. It affects every block.
- **M4. The memo's control section leaves out two behaviors** (memo.md:51-55). The behavior is correct; only the
  documentation is missing:
  - A failed step stops the whole queue (genotype_all.sh:134, 150): `queue.exit` holds the step's status and there is
    no `queue.done`. The report (task-12-report.md:123) states this; the memo does not.
  - `queue.exit` 0 without `queue.done` means either a pause or an overrun. Only queue.log tells them apart.
- **M5. The memo cannot fully rebuild the inputs alone** (memo.md:24-43). It gives no command for:
  - writing the six sheets;
  - `preflight.txt`, `fai.preflight.tsv`, `checksums.sha256` and `launch.txt`;
  - copying main3's `mem_sampler.sh` and editing it.

  The sheets survive, and so does their content in check_sheets.py:20-35, so a rerun is possible. Still, it does not
  work from the memo alone.
- **M6. Timing and sampling are worse than the report says** (task-12-report.md:204-208; memo.md:78).
  - B73 vs PT took 17.7 min (six/genotype.log 18:22:08 to 18:39:52), against main3's mean of about 14.3 min. If that
    holds, six alone takes about 10 h and the queue probably runs past 24 h.
  - The sampler now samples every 32 s (the last rows of six/genotype.mem.tsv), not every 20-26 s.
  - Ruling C2-C5 covers the sampling. The controller should plan Task 8's pause with the longer duration.
- **M7. cap5k leaves little evidence of the cap in effect** (cap_variant.py:55-64).
  - `run_variant.py:96-105` logs the cap that `flank_pieces` actually receives, once per call. cap_variant only logs
    the route's cap.
  - Anchor markers store a hash only (`$SNAP/src/ltrpav/checkpoint.py:159-170`). So the evidence of cap 5000 on disk
    is `variant.json` plus one stderr line.
  - The toy test confirms the cap is applied. This item is about provenance only.
- **M8. Cosmetic:**
  - shellcheck flags genotype_all.sh:52 and :155: `done` used as a word (SC1010). It works: the stub run wrote
    `queue.done`. It also flags :47 (SC2155).
  - `real/__pycache__/` was left by the tests, because `PYTHONDONTWRITEBYTECODE` was not set.
  - test_edta_prep.py:24 tests no bare integer that matches neither form, and no structural non-LTR type such as a
    `TE_struc` TIR. The real-data line-equality check above covers both.

## Assessment

**Approved.**
- **Spec:** compliant. The one ⚠️, C1's wording in the memo, is Minor.
- **Quality:**
  - edta_prep reproduces the sources line for line, and the loader output equals main3's.
  - cap_variant applies the cap where genotyping reads it, and cannot reuse default-cap checkpoints.
  - genotype_all.sh's markers, pause, failure stop, overrun path, snapshot assertion and .fai snapshots behave as
    specified.
- **No action needs the pause point.** M1 and M4 are memo edits the controller can make now. M2 and M3 are optional
  hardening for the next time the queue is paused for another reason.
