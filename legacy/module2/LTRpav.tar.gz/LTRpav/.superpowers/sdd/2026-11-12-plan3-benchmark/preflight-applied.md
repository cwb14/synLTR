# Plan 3 pre-flight: rulings applied

- **Scan:** `preflight-scan.md`, 104 rows, of which 32 are conflicts and 7 load-bearing.
- **Ruling:** the controller accepted the scan's proposed ruling for every conflict.
- **Plan:** `docs/plans/2026-11-12-plan3-benchmark.md`, now 1,775 lines and still 16 tasks. Line numbers below are the
  edited plan's.
- **Pre-edit copy:** scratch `preflight/plan3_v2_before_preflight.md`. Edit script: scratch `preflight/apply.py` (84
  exact, uniqueness-checked replacements, each tagged with its row).

**Outcome:**
- All 32 conflicts are applied; none is declined.
- The 13 "Agree" rows that carry a note are applied too: B2, B6, B7, B12, B13, B14, C12, D5, D9, D12, E1, E11 and E13.
- The coordinator's three extra changes are applied.
- The writing-plans self-review was rerun (end of this file).

## Conflicts (32)

| Row | LB | Applied | Plan lines |
|---|---|---|---|
| A6 | | Loss-mix text gives the pooled counts and exact fractions (0.123, 0.164, 0.511, 0.202) and the pooled `b_ins` 13,538. `demography.json` governs every run. DESIGN 12 records the exact values beside the `src` drafting defaults (Task 16). **Own call:** the `src` defaults are set to these exact 3-decimal values, not left at the old rounding, because 0.17 was not a rounding of 0.164 and 2-decimal values would not sum to 1. | 106-109, 399-401, 1066, 1069-1070, 1078-1080, 1742 |
| A9 | yes | `PopGenome.lift` (`Lift`, per chromosome); `build_chrom` returns (bytes, copies, lift); `lift_pos`; `tract_bed` reads it. Task 3 now holds the empty-site window rule that `Copy.site` implements. Tests `test_lift_pos` and `test_site_window_ignores_other_insertion`. | 602, 615-616, 622-632, 640-649, 690-691, 712, 769-770 |
| A12 | yes | `view.sh` writes SHEET with absolute `fasta` and `annotation` (resolved against SHEET's directory). Task 5's relative sheet is unchanged. nodonor's C1 annotation is set to `.` by `view.sh`. | 1016-1019, 1138 |
| A22 | | `make_grid.py --bneck-nulls N`. The Step 11 gate regenerates `grid.tsv`. Under the 50-Mb fallback the pilot runs are moved aside and rerun. | 1096, 1112, 1175-1182 |
| A23 | yes | eval_run's LTRquest branch: `match_by_coords` (slop 10 bp), the same per-state counts, unmatched elements counted, no `ltrpav-sim score`. Task 10 only runs it. | 1257-1264, 1421-1424 |
| A26 | | Task 11 reports nodonor on its own; Task 14 holds the side-by-side with genus `zd`. | 1472-1473, 1640 |
| A29 | | The `edta` and `stability` sheets carry `six`'s groups (maize, mexicana, parviglumis, diploperennis). | 1539-1541 |
| A30 | | Task 15 reports per-block wall time and peak RSS, plus per-pair wall times from the genotype log. | 1682 |
| A32 | yes | Task 16 owns the final `compare_papers.py` edits: it is in Task 16's Files, the verdict constants become "PASS"/"MISS", rows read `sim/tables`, and the new sha256 is recorded. Task 13's copy keeps PRELIM's logic plus `--prefix`. | 1566-1568, 1697-1699, 1704-1711 |
| B1 | | `test_no_pulse_no_tracts` supplies `sub_a`/`sub_c` for the lineage codes; the fail-fast stays strict. | 457-458 |
| B4 | | Plan 1's rule: an insertion at another site inside the window leaves E, only a target overlap gives O, and only losses or deletions of window bases give D. Stated in Task 3 and Task 4. Test `test_truth_E_with_other_insertion_in_window`. | 643-649, 746-751, 781 |
| B5 | | Chromosomes numbered from 1. Streams: donors `[seed, 0]`, chromosome `[seed, c]`, gaps `[seed, 100, g]`, annotation `[seed, 200, g]`, stated in `pop.py`'s docstring. `add_gaps` takes one stream per genome. `shift_element` moves, and pair's CLI imports it. | 632, 811, 834-840 |
| B8a | yes | `run_grid.sh TSV [--until STEP]` passes the step on. `<TSV>.done` is written when every `run.exit` is 0 and the last requested step's marker exists. The pilot command uses it. | 1028, 1149-1154, 1161-1163 |
| B8b | | Grid column `ne` (1000 for posctl). `row.json` merges and records `sub` and `ne`. | 1096-1098, 1124-1125 |
| B9 | | eval_run joins calls to truth per element and checks its pooled totals against `ltrpav-sim score`'s (with A23). | 1257-1262 |
| B10 | | `run_one.sh` gains `--from` and `--rundir`. `lq/run_lq.sh` calls `run_one.sh <name> --rundir lq/<name> --from geno`. | 1027-1028, 1421-1424 |
| B11 | | Task 11 Files and Step 4 always edit DESIGN 7.1, 7.4 and 7.6, with a no-adoption commit message. Snapshot 2 is taken only if `src/` changed. The Global Constraint is reworded to match. | 245-246, 1439-1444, 1476-1490 |
| C1 | | `test_em_degenerates_decoy_does_not` asserts that the decoy fit's posteriors are not 0/1 copies of the classes. | 939-940 |
| C2 | | Exit codes: `A1=1` exits 2 (argparse value check); `O1`/`Z9` exit 1 (labels checked after parsing). New `test_pop_region_too_short`, also named in Review Focus 1. | 289, 881-884 |
| C3 | | Rule 6: 0.99 gets its reason (emissions within 1% of 0/1 make the posterior a copy of each class; main3's state); 10% is named a heuristic. | 1331-1338 |
| C4 | | `pair.jitter_bounds` and `pair.read_tsd` are factored out of `_annotation`, which uses them; the caller keeps the RNG draws, so `pair` stays byte-identical. `pair.py` is in Task 4's Files. Test `test_pair_annotation_unchanged`. | 708, 716, 756-763, 782 |
| C7 | | The header names `.superpowers/sdd/2026-11-12-plan3-benchmark/` and its files. | 43-47 |
| C8 | | The probes were copied into `$P/benchmark_pav/plan3/sim/probes/` (with SHA256SUMS) on 2026-11-12, and are cited there in the probes paragraph, Task 8 Files, Step 3 and Step 4. | 68-71, 1005, 1072, 1082-1083 |
| C9 | | Rule 7 states the consequence: confirmed means an exploratory output with its measured power; not confirmed means Task 11 sets the rows' note to "not validated by simulation (Plan 3)" and removal goes to Plan 4. **Own call:** that note lives in `analysis/direction.py`'s row note, with its test, changed in Task 11 Step 4. The scan did not say where "its rows carry" the label. | 1348-1352, 1441-1444, 1479-1480 |
| C10 | | TIL25 as donor is "reported" (DESIGN 10.4 sets no bar), with Z and the Z > 3 reading. | 1592-1593 |
| C11 | | An mm2 memory overrun stops the block, goes in `dead_ends.md` and is told to the user. The engine-fix task follows only if it traces to a defect. | 1548-1551 |
| D2 | yes | `view.sh` links each kept pair's `.calls.tsv.gz.done.json` marker beside its link (with A12). | 1020-1024 |
| D3 | yes | eval_ltrmix reads the trio files from `ltrmix/` with three libraries and from `ltrmix/A1_B1_C1/` with four. Stated in Task 8 and Task 9. | 1140-1141, 1208-1213 |
| D4 | | `compare_papers.py` keeps its `--run` and gains only `--prefix`. Every `--view` call becomes `--run ... --prefix ...`. | 1579-1585, 1654-1658, 1677, 1704-1711 |
| E5 | | Tasks 13-15 append dates, commands and outputs to `real/memo.md`. | 1568, 1612, 1619-1620, 1667, 1674, 1688 |
| E9 | | If LTRquest's commit is not 5042a1e, the delete list is re-checked against that commit first. | 1413-1414 |
| E10 | | `gff3_to_ltrmix.py` fetches element spans through the `.fai` (pysam) and never reads the whole FASTA. | 1030-1031 |

## Notes from "Agree" rows (applied)

| Row | Applied | Plan lines |
|---|---|---|
| B2 | Each `sim_mutations` call takes the mutation-free ts. `nested_after_loss` is defined. `test_loss_split` uses elements with at least `PARTIAL_MIN` internal region. | 563-570, 577-578 |
| B6 | e* rows are NA for a skipped or collapsed painting. | 916-917 |
| B7 | `test_block_size_option` uses a toy with at least 3 one-Mb blocks, and asserts a finite se. | 983-984 |
| B12 | EDTA files are named by sheet label (`B73.gff3.gz`, prefix `B73v5`). | 1520-1522 |
| B13 | `six_results.tsv` is in Task 13's Files. The inversion residual is folded in (extra 3). | 1566, 1605-1607 |
| B14 | `edta/views/main` is created by a Task 14 step. | 1654-1658 |
| C12 | The Global Constraint names the engine's `src/ltrpav/constants.py`; `analysis/constants.py` is analysis code. | 216-217 |
| D5 | `paint.DISCOVERY` stays the one source of the discovery choices. | 910-911 |
| D9 | Sentinel rows are skipped by the eval scripts. | 1204 |
| D12 | `_INDEL_P` is in `sim/genome.py`. | 558 |
| E1 | The direction-prediction probe and the Task 11 rescoring run detached. | 1089-1090, 1445-1448 |
| E11 | LTRquest's thread count is sampled on the first run and kept near 32. | 1409-1411 |
| E13 | If the gate picks 30 bottleneck nulls, the user is told (+12 h). | 1181 |

## The coordinator's three extra changes

| Change | Applied | Plan lines |
|---|---|---|
| Base | `plan3-benchmark` is cut from `plan1-engine` at 12d3e6c, with Plan 2 merged and `plan2-analyses` deleted. Global Constraints and Task 1 Step 1 (preconditions, checkout) are changed. No other mention of `plan2-analyses` as the base remains. | 208-209, 438, 441 |
| Decision 11 | The user decides after Plan 3, and Plan 3 measures and reports. The wording is changed in Task 11 item 11, Task 13 item 8, Task 14 `zd` and Task 16's hand-off; "awaiting confirmation" is gone. | 1472-1473, 1608-1609, 1640-1641, 1750 |
| Parked items | The inversion residual: six-genome blocks are reported with the caveat that 11 main3 blocks were sparse on their pair's second genome, where own-pair rows inside the y span are exempt, and such blocks are flagged. The overview limits with 20 trios (a page of about 264 mm; large scaffolds can be called chromosomes) are recorded as known Plan 4 figure limits in the Figures constraint and in Task 16's leads. | 275-277, 1605-1607, 1729-1730 |

## Self-review (writing-plans), rerun

1. **Spec coverage.** Every DESIGN item still maps to a task (the table at the plan's end is unchanged). C10 removed a
   bar DESIGN does not set.
2. **Step scan.**
   - Each new step names its command, file, values and expected output.
   - No "TBD" or "TODO".
   - The two remaining mentions of `plan2-analyses` and `plan3review/` are intentional: deleted branch, provenance.
3. **Type and name consistency.** These names now agree across tasks:
   - `build_chrom` returns triples; `PopGenome.lift` and `lift_pos` are used by `tract_bed`;
   - `add_gaps(genomes, per_mb, rngs)` matches Task 5's per-genome streams;
   - `run_one.sh --from/--until/--rundir` and `run_grid.sh --until` are used as defined;
   - `make_grid.py --bneck-nulls`;
   - `compare_papers.py --run ... --prefix ...` everywhere;
   - `pair.jitter_bounds` and `pair.read_tsd`.
4. **Review Focus.** Each of the five items still names a test in its owning task; item 1 gained
   `test_pop_region_too_short`.
5. **Proportion.** 1,775 lines, with tests listed by name and assertion; no code bodies were added.
