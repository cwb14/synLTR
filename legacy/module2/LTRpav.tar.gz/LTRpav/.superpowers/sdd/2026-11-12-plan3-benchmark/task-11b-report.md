# Task 11 Part B report: SIM_RESULTS.md, the misses, lq_compare

Date: 2026-11-14 (13:54-14:35). Status: DONE_WITH_CONCERNS (concerns at the end; none blocks Part C).

Paths: `P=/data2/chris/maize_introgression`, `SIM=$P/benchmark_pav/plan3/sim`,
`SCR=/tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3t11b`.
Read-only on runs/, lq/ and the repo (checked: no file in runs/ or lq/ newer than rescore/rescore.done; `git status`
of LTRpav clean; RULES.md still 4111826d...a293). No scoring defect found. No code, bar, rule or default changed.

## Every bar, its verdict and source row

PASS 16, MISS 9. Rule 2 items are judged as bars (the brief's "calibration reading ... MISS" example); RULES.md calls
rule 2 a reading whose bar "stays rule 1" (concern 1).

| rule | item | verdict | numbers | source row |
|---|---|---|---|---|
| 1 | D_pav, 30 nulls | PASS | 0 of 30, CP 0-0.116 | bars.tsv "D_pav all, pre-declared trio, the 30 nulls"; null.tsv nulls/D_pav |
| 2 | D_pav calibration | MISS | SD 0.717 (0.571-0.964), mean +0.072 (2 SE 0.262) | calibration.tsv D_pav ("not calibrated") |
| 2 | dD calibration | MISS (not demonstrated) | 1 of 30 usable | calibration.tsv dD (NA) |
| 2 | truth D donor-discovered | PASS | 0.758 (0.603-1.018); -0.096 | calibration.tsv |
| 2 | truth D donor, no outgroup filter | PASS | 0.859 (0.684-1.155); -0.022 | calibration.tsv |
| 2 | truth D sister-discovered | PASS | 0.914 (0.728-1.229); -0.006 | calibration.tsv |
| 2 | LTRmix D_kmer / D_ins / D3_triples / D_self_outgroup | PASS x4 | 0.904, 0.901, 0.822, 1.085 (all CIs include 1; means within 2 SE) | calibration.tsv |
| 3 | genotype bar | PASS | P 0.99710 (10,265,265/10,295,167), E 0.99676 (6,580,568/6,601,942) | bars.tsv rule 3 rows; genotype.tsv eid pooled high |
| 4 | main / any / decoy / anydecoy hold the null | PASS x4 | 0 of 30 each; excess within 2 SE; any, anydecoy 0 of 20 dropout nulls, excess within 2 SE | bars.tsv / variants.tsv rule 4 |
| 5 | any: FDR | MISS | 0/0, CP upper 1 | bars.tsv "any: pooled tract FDR at q <= 0.05" |
| 5 | any: recall sign test | MISS | 0 of 42 usable, p = 1 | bars.tsv "any: bp recall ..." |
| 5 | any: precision sign test | PASS (vacuous: 0 informative pairs) | 42 NA | bars.tsv "any: bp precision ..." |
| 5 | decoy: FDR | MISS | 0/0, CP upper 1 | bars.tsv |
| 5 | decoy: recall | MISS | 0 of 36 usable, p = 1 | bars.tsv |
| 5 | decoy: precision | PASS (vacuous: 0 informative pairs) | 36 NA | bars.tsv |
| 5 | anydecoy: FDR | MISS | 0 of 21 false, CP 0-0.161 | bars.tsv |
| 5 | anydecoy: recall | MISS | 1 of 42 usable (+1 -0), p = 0.5 | bars.tsv |
| 5 | anydecoy: precision | PASS | 1 usable (+1 -0), p (lower) = 1 | bars.tsv |
| 5 | adoption | default (main) kept | all four fail; default-fails clause n/a; joint n/a | bars.tsv "variant adoption" |
| 6 | degeneracy label | not applied (reading) | 7 of 36 default fits (19.4%, CP 8.2-36.0%) >= 10% | bars.tsv rule 6 ("no label") |
| 7 | posctl confirmation | MISS | 2 of 8 (the 2 posctl nulls) | bars.tsv "posctl confirmation"; direction.tsv |
| 7 | false calls; maize-like; PT-like | reported | 0/30 nulls, 0/30 bottleneck nulls; 0 wrong, 0 right, 50 none; PT-like 0 of 3 (prediction none) | bars.tsv rule 7 rows |
| 8 | D_ins / D_pav | reported | 0.543 (0.430-0.692), 30 of 36 runs, n_flip 6, frac_right_pair 0.833; 0.66 inside | bars.tsv rule 8; gaps.tsv |

Rule 1's "reported" rows: truth D (3), LTRmix (4), nodonor all 0 of 30; bottleneck nulls D_pav 1 of 30 (CP
0.0008-0.172), LTRmix D_self_outgroup 1 of 30.

## The misses, investigated (dead_ends.md has one entry per MISS: What, Result, Evidence, Cause tested, What would change it)

1. **Rule 2, D_pav calibration.** Not genotyping: truth D on the same loci is as narrow (SD 0.758); D_pav - truth D
   +0.010 +- 0.036 (p 0.12). Not a biased jackknife: label shuffles give SE = binomial SE (0.0485 vs 0.0486, 200
   shuffles x 30 nulls, scratch probe_calib.py); the real SE is 1.24-1.28x binomial because 31% of informative loci
   are in nested clusters, all concordant (1,676/1,676; design effect 1.47 predicts SD 0.059 vs SE 0.062); collapsing
   gives 1.05x. Not block size (0.25-5 Mb: SE 0.061-0.063). The across-run spread varies by replicate set: 20 dropout
   nulls (same demography) SD 1.06 (0.81-1.55), pooled 50 0.86 (0.72-1.07); bottleneck nulls 1.29 (1.03-1.74);
   truth D variance bneck/default 2.67 (F p 0.010) at equal SE. Mechanism of the demography effect: untested.
2. **Rule 2, dD.** K = 0 stratum holds 0-6 informative loci per null (mean 1.2 of 301): ILS-shared insertions predate
   the B-C split (LTR K >= 0.0036 expected). 29 NA: no B1+C1 (10), no A1+C1 (9), no informative locus (8), < 3 blocks
   (2). Whether dD would calibrate with enough young loci: untested.
3-8. **Rule 5 (6 entries).** One cause, tested on every C>A run from the tract files (scratch probe_q.py): the target-
   decoy q = (decoys >= x * scale + 1) / (targets >= x) needs >= 20 target tracts above every decoy tract; the median
   per run is 2 (main, any, decoy) or 3 (anydecoy); smallest q median 0.49 / 0.44 / 0.34 / 0.33. Only f0.50_Ta500_r1
   crossed (main 25 tracts, 3 false; anydecoy 21, 0 false). anydecoy's FDR bar needs >= 35 tracts with none false; a
   one-sided sign test needs >= 5 usable pairs. Why the decoy's best tracts keep pace with A1's: untested (lineage
   sorting gives B1 C-like stretches). Context only, not adoption evidence: at any q, decoy and anydecoy beat main on
   AUROC (30/33, 30/34) and bp precision (29/33, 31/34); any raises recall (26/34).
9. **Rule 7, posctl.** 15 of 24 DFOIL statistics in the 6 gene-flow posctl runs are exactly +-1 (all loci one side);
   the jackknife has no variation, Z is undefined, the signature reads "0". This is LTRpav's own testability rule, not
   a scoring defect. Diagnostic only (not a rule): reading those by sign gives C>A in 3/3 C1>A1 runs and A>C in 2/3
   A1>C1 runs (pc_A1C1_r2 stays "+000") = 5 of 6, still a miss. The A1>C1 design has too few loci at 50 Mb (probe
   counts scaled from 300 Mb give Z ~2.6-3.2 even with a perfect test). Not genotyping (posctl high-tier P 0.9994,
   E 0.9969). One-sided statistics occur in no other kind (0 of 440). A test for one-sided classes at genome scale:
   untested.

## Decisions Part C must record

- **Variants (DESIGN 7.1 discovery, 7.4 emission): none adopted; the default stays `main` (em emission, recipient
  discovery). No change to constants.py or the tests' expected defaults.**
  - `any` (7.1): evaluated, not adopted. Holds the null: 0 of 30 nulls and 0 of 20 one-sided dropout nulls with a
    q <= 0.05 tract, excess -0.00065 +- 2 SE (-0.0035 to +0.0022) and -0.00027 (-0.0043 to +0.0037). Rule 5: no q <= 0.05
    tract in any of the 36 C>A power runs (FDR 0/0, CP upper 1), recall sign test 0 of 42 usable pairs.
  - `decoy` (7.4): evaluated, not adopted. Holds the null (0 of 30; excess +0.00097, -0.0020 to +0.0039); no q <= 0.05
    tract in 36 runs (FDR 0/0), 0 of 36 usable pairs. Its second route does not apply (the default holds the null).
  - `anydecoy`: evaluated, not adopted. Holds the null (0 of 30; 0 of 20 dropout nulls); 21 tracts at q <= 0.05, 0
    false, CP upper 0.161 > 0.10; recall 1 of 42 usable pairs (+1 -0, p 0.5). Joint adoption therefore no.
  - Rule 6: 7 of 36 default fits degenerate (19.4%) >= 10%: the decoy decision is not labeled "not tested in main3's
    regime".
- **Rule 7 (DESIGN 7.6): not confirmed.** 2 of 8 posctl runs read their prediction (both posctl nulls); all 6
  gene-flow posctl runs read "none" (one-sided DFOIL statistics untestable by the block jackknife; too few A1>C1 loci
  at 50 Mb). No false calls (0/30 nulls, 0/30 bottleneck nulls, 0 wrong in 50 maize-like gene-flow runs); PT-like
  "none" (Task 13 states DFOIL-alt is not expected to orient it). **Consequence:** change the direction rows' note in
  `analysis/direction.py` to "not validated by simulation (Plan 3)" and the expected note in
  `tests/test_direction.py`; removing the test is a Plan 4 decision. Since src/ changes, snapshot 2 is needed (plan
  Step 4).

## Files written

- `$SIM/SIM_RESULTS.md` (688 lines; sha256 b533853c88a11dbd8c3185a926ac3fd16ee043a2e27474b34d9c85565b5b035f):
  verdict table, sections 1-11, Plan 4 leads, headline test.
- `$SIM/lq_compare.py` (sha256 cc5dbba35522a6b0e6711458c5bce43a05b0669a69ee902543ebcb52ee4e8537; env ltrpav; argparse,
  `-v`; read-only; self-checks: lq unmatched counts equal eval.json's n_unmatched_elements, grid score files exist;
  ruff E,F,W clean; 1.6 s).
- `$SIM/tables/lq_compare.tsv` (168 rows; sha256 e27286399e41ea1ac6e9bc71dec898df21bd11834a46d31ddf781af6a2fb93e1;
  rerun byte-identical). Notes in the table that ltrmix_absent.py does not attribute these runs.
- `$P/benchmark_pav/dead_ends.md`: appended section "2026-11-14 Plan 3 simulation benchmark (Task 11)", 9 entries
  (before e3ff2aa6..., after ec9f3028...; earlier text unchanged).
- Scratch only (`$SCR`): extract.py, perrun.tsv (per-run values from eval files), probe_calib.py, calib_truth.tsv,
  probe_q.py, qprobe.tsv, calib.py, smix.txt, show.py, pooled extracts, dead_ends.before.md.

## Concerns and readings where RULES.md or the rulings were silent

1. **Rule 2 counted as bars.** RULES.md: "The bar stays rule 1". I judged each rule-2 reading PASS/MISS as the brief
   asks (7 PASS, 2 MISS) and said in SIM_RESULTS that rule 1 is the bar of record. If Part C prefers rule 2 as
   "readings", the tally becomes PASS 9, MISS 7.
2. **Counting.** Rule 4's dropout-null clause is counted inside each model's "holds the null"; rule 5's adoption row,
   rule 6's label, rule 7's counts and rule 8 are outcomes or readings, not counted. anydecoy's precision clause (1
   informative pair) reads PASS, not "vacuous".
3. **Six rule-5 entries share one cause.** Kept one entry per MISS as the brief asks; the shared evidence sits in the
   first (`any` FDR) and the others cite it.
4. **lq_compare.py has no pytest.** The brief lists none; the user's CLAUDE.md asks basic tests for every standalone
   tool. It reconciles with eval.json and fails on missing inputs instead. Part C may want a small test.
5. **Investigation probes live in scratch** and may be cleared; dead_ends.md names them and describes each test so it
   can be redone. Part C could copy probe_calib.py and probe_q.py into sim/ if they should be kept.
6. **D_pav was higher with LTRquest's annotation in 3 of 3 runs** (+0.07, +0.10, +0.13; 1.0-1.7 SE; truth D fixed).
   n = 3 and the trio-vs-7-genome design is confounded, so it is a Plan 4 lead, but the real data use LTRquest
   annotations.
7. **The default's own realized FDR at q <= 0.05 was 0.12** (3 of 25, CP 0.026-0.31) in its only calling run. No bar
   applies to the default; flagged in SIM_RESULTS section 4 and as a Plan 4 lead (q construction).
8. **The lq runs' eval.json records design "7g"** (copied from the grid row) although they are trios; cosmetic, and
   lq_compare.tsv states the trio design itself.
9. **Context numbers beyond the tables.** SIM_RESULTS cites values computed in scratch from the eval files and run
   files (the calibration probe, the q floor, any-q sign tests, LTRpav's s_mix from stats.tsv, D_dir tests, the
   decomposition of rule 8 on the 30 runs). Each is labeled as an investigation or context, never as a rule input.
10. **Headline.** The closing headline is the one-sided-dropout contrast (D_pav 0 of 20 false signals against LTRmix's
    D_ins 18 of 20; Fisher p 3.4e-9), stated as a method-validation result, tested in one simulated demography only.
11. **Cleanup.** My ruff run created `sim/.ruff_cache/` at 14:29:53; I removed it. No __pycache__ was written.

## Fix round 1 (2026-11-14 14:36-15:00; ledger "Ruling (rule 2)", "Ruling (probes)", "Ruling (lq_compare.py tests)")

**Rule 2 is a reading.** Each calibration reading now reads calibrated, not calibrated or not demonstrated, never PASS
or MISS. PASS and MISS are counted over the bars only: rules 1, 3, 4, 5, the posctl confirmation of rule 7, and rule 8.

- **New totals: bars PASS 10, MISS 7; readings 7 calibrated, 1 not calibrated (D_pav), 1 not demonstrated (dD).**
  - PASS: rule 1; rule 3; rule 4 x4 (main, any, decoy, anydecoy); rule 5's three precision clauses (any and decoy
    vacuous, anydecoy +1 -0); rule 8.
  - MISS: rule 5 x6 (FDR and recall clauses of any, decoy, anydecoy); rule 7 posctl confirmation.
  - **Rule 8 is now counted as a bar**, as the coordinator's list says: PASS, because 0.66 lies inside the bootstrap
    95% interval of D_ins / D_pav (0.430-0.692; summarize's contains_0.66 = true). bars.tsv itself reads "reported"
    and RULES.md states no explicit pass line, so this is my reading of "whether D_ins/D_pav reproduces the real
    0.66" (concern below).
- **Relabeled lines in SIM_RESULTS.md:**
  - header: rule 2's readings named; "Investigations ... scratch" replaced by the probes directory and claims.txt;
  - "Verdicts at a glance": the totals paragraph rewritten (bars PASS 10, MISS 7; readings 7/1/1); the 9 rule-2 rows
    now "2 (reading)" with calibrated / not calibrated / not demonstrated; the rule 8 row PASS;
  - section 1 verdicts: D_pav "not calibrated", dD "not demonstrated", the others "calibrated", plus the line "For the
    real data, this means Task 16's final D_pav row will give the empirical null quantile of Z and rest the verdict on
    it (plan Task 16 Step 2)";
  - section 9 verdicts: "D (rule 8): PASS"; s stays a reading with no bar; its table's rule-8 cell reads "contains
    0.66: PASS".
- **Relabeled entries in dead_ends.md** (investigations kept): "### Rule 2 (reading): D_pav's null Z is calibrated"
  with Result "Not calibrated" and the Task 16 line; "### Rule 2 (reading): dD's null Z is calibrated" with Result "Not
  demonstrated". The section's preamble now says seven misses of bars plus two calibration readings. The 7 MISS
  entries are unchanged apart from probe citations. Earlier sections of the file are byte-identical (213 lines).

**Durable probes.** Copied to `$SIM/probes/task11/` and rerun from there with `rerun.sh` (59 s, one process):
- `extract_perrun.py` -> `perrun.tsv` (144 runs; per-run values from the eval files);
- `probe_calib.py` -> `calib_truth.tsv` (+ `calib_truth.log`): the truth-D jackknife probe of section 1;
- `probe_q.py` -> `qprobe.tsv`: the q-floor probe of section 4;
- `claims.py` -> `claims.txt` (new): every number in SIM_RESULTS.md and dead_ends.md that is not read from a
  `sim/tables/` file, by SIM_RESULTS section. It replaces the inline commands I had run in the shell (D_pav vs truth D,
  jackknife vs binomial, dD strata and NA reasons, power counts by f, f4 fit, tract contents, q floor, any-q sign
  tests, DFOIL codes and one-sided statistics, posctl precision, D_dir tests, dropout counts and Fisher tests,
  LTRquest D shifts, LTRmix power and f-ratio, s and s_mix, the rule 8 decomposition, nodonor discovery genomes).
  Every value it prints matches the text.
- `rerun.sh` (the four commands) and `SHA256SUMS`. perrun.tsv, calib_truth.tsv and qprobe.tsv rerun byte-identical
  to the scratch originals. I dropped two unused `math` imports (extract_perrun.py, probe_q.py) and reconfirmed
  identical outputs. Ruff reports only style findings in these probes (line length, one-line statements), no pyflakes
  errors.
- Citations point there: SIM_RESULTS.md's header, sections 1, 2, 3, 4, 5, 6, 7, 8, 9 and 11; dead_ends.md's preamble
  and the entries for both readings, the rule 5 FDR entries and rule 7.

**lq_compare.py**: unchanged (ruling: its reconciliation asserts stand in for a pytest).

**Also changed**: one sentence in the D_dir paragraph was reworded so that a wrapped "- n(C->A)" no longer renders as a
bullet; over-long paragraphs were reflowed to 120 columns (no wording change). Nothing else was written.

**Files** (sha256): SIM_RESULTS.md ac58cd5b361df47a426deb27556e3179cac7ff6eaa640b076d35905a889edfab (700 lines);
dead_ends.md 477d5aeb74bd95a65e205d9fcbaada2a1ab0060fc1e98530ee46034ad71436a9; probes/task11/SHA256SUMS
9fbe91b86bf94177dca4f9279d12a322416801c20cf3d2f46dc0772ba0962587.

**Concern from this round.** Rule 8 as a bar: I judged it PASS by the interval containing 0.66. If Part C reads rule 8
as a reported comparison (bars.tsv's "reported"), the totals become PASS 9, MISS 7.

**Rule 8 relabel (ledger "Ruling (rule 8)").** Rule 8 now reads "reproduces" (0.66 inside the bootstrap 95% CI 0.430-0.692), outside the count; the bar totals read PASS 9, MISS 7 in SIM_RESULTS.md (glance paragraph, table row, section 9 verdict and table cell; dead_ends.md had no totals or rule 8 text); SIM_RESULTS.md sha256 bf876aafe073b61258b33af7ed0039a6c1916226469fadecd3c783a61ba66123, 702 lines.

## Fix round 2 (2026-11-14; review task-11b-review.md I1-I4, M1-M12; ledger "Ruling (I1)", "Ruling (I4)", "Ruling (I2, I3, M1-M12)")

No verdict and no Part C decision changed: bars PASS 9, MISS 7; readings 7 calibrated, 1 not calibrated, 1 not
demonstrated; rule 8 reproduces; no variant adopted; rule 6 7 of 36; rule 7 not confirmed. Part C's DESIGN 7.6 text
should state the rule 7 cause as corrected under I1. No code changed. Every number added in this round is printed by
`$SIM/probes/task11/fix2_checks.py` -> `fix2_checks.txt` (new; in rerun.sh and SHA256SUMS), except McNemar's p-values,
which `claims.py` section 6 now computes in place of Fisher's. All review numbers reproduced; no minor turned out wrong.
Lines below are in the final files: SIM_RESULTS.md (764 lines, sha256 1f5a0d79985d64a243001b92cf6edef99f5f9cc6ac5483c4b048ec450a78096e) and dead_ends.md (395
lines; Task 11 section from :215).

- **I1, rule 7 (stays MISS, "not confirmed").** SIM_RESULTS.md:319-330 (verdict) and :345-380 (causes), dead_ends.md:351-395
  (entry rewritten), Plan 4 lead SIM_RESULTS.md:708-712.
  - C1>A1: design leaves DFO, DIL, DFI each with an empty class by construction (Ne 1,000; C1-C2 split 30,000
    generations; probe 510/0, 0/510, 1,046/0; in the runs 3 of 4 Z undefined in each); direction.py names no direction
    when any Z is undefined (about :312-315); the prediction's binomial Z stays finite (361). A design/prediction vs
    implementation mismatch, not power; 57-157 loci per statistic.
  - A1>C1: mostly too few loci at 50 Mb (probe minority classes scale to about 1 locus for DFO, DFI, DOL; empty in 2 of
    3 runs; scaled Z about 2.6 and 3.2), compounded by empty classes; pc_A1C1_r2 with all Z defined read "+000".
  - Posctl nulls: 0 loci, vacuous.
  - Untested, labeled: the test in any regime with two-sided classes and a predicted direction; A1>C1 at 300 Mb; P1/P2
    by smaller PAV distance (C pair put in P1, P2 in 2 of 3 C1>A1 runs).
  - "reads an undefined Z as '0'" replaced by "names no direction when any Z is undefined"; Plan 4 leads now (a) the
    saturated-statistic handling and (b) a positive control with non-empty classes; "no code change now (tuning)" added.
- **I2.** SIM_RESULTS.md:435-441 and the headline evidence :737-743: both the discovery rule and LTRmix's presence calls
  carry the bias (sister-discovery truth D -2.85 vs D_ins -5.31 at 0.4, -0.36 vs -4.95 at 0.2 with the sister pair
  right in 10 of 10; cause b 17% -> 27.8%).
- **I3.** SIM_RESULTS.md:23, :408-409, :737-738, :748: A1's annotation keeps 80% or 60% against 90% (measured 0.802,
  0.599, 0.900; pop.py:139 replaces the base dropout); "10 or 30 points less complete"; "a 10-point gap already gave
  D_ins 9 of 10". Also :752: "in proportion to the annotation gap" became "already at a 10-point annotation gap" (D_ins
  is -4.95 at 10 points and -5.31 at 30, not proportional; my own correction, not a review item).
- **I4.** SIM_RESULTS.md:93-97 and dead_ends.md:229-233, linked to :261-263: Task 16 reports the empirical null quantile
  from the default nulls (SD 0.72, max |Z| 1.97, 95th percentile 1.36) and the bottleneck nulls (SD 1.29, max 3.14,
  95th 2.74; F-test p 0.0022) and rests the verdict on the bottleneck null; the default nulls give the most lenient
  threshold.
- **M1.** SIM_RESULTS.md:255-256, dead_ends.md:337-339: 36 tracts, not 35 (0 of 35 gives 0.10003; 0 of 36 gives 0.0974).
- **M2.** SIM_RESULTS.md:411-413 and :739-740: McNemar's exact test, paired by run: D_ins p 7.6e-6, D_kmer 1.2e-4,
  D_self_outgroup 0.002, D3_triples 0.12 (were Fisher 3.4e-9, 3.3e-6, 4.4e-4, 0.11); probe claims.py section 6.
- **M3.** SIM_RESULTS.md:446-448: dropout f 0.18 runs are all Ta 5,000; matching 7-genome cell 1.41 +- 0.09 (2 runs),
  replacing the pooled 2.13.
- **M4.** SIM_RESULTS.md:133-142, dead_ends.md:244-253 and :257-259: dropout nulls are trios with A1 dropout; default vs
  dropout F 2.19, p 0.056; truth D 0.76 vs 0.85, p 0.55; 1 - 0.95^9 = 0.37; D_pav chi-square p 0.029.
- **M5.** SIM_RESULTS.md:299-300 and dead_ends.md:291-293: lineage sorting of the decoy labeled a hypothesis.
- **M6.** SIM_RESULTS.md:83-84 and :325-327: no directional call in any of the 118 seven-genome runs, so 0 false calls
  says nothing about specificity; the 2 posctl nulls have no informative locus.
- **M7.** SIM_RESULTS.md:580-582 and :607-608: LTRpav's fit (8.9% vs 3.2%) and LTRmix's own (10.6% vs 4.0%) named;
  LTRmix's 1,341 B1-C1 pairs per null (30-null mean) replaces null_s101's 1,361.
- **M8.** SIM_RESULTS.md:668-670 and :693-694: 2 of nodonor's 7 hits (Z 3.19, 3.38) used A2 for discovery.
- **M9.** SIM_RESULTS.md:190-191, :208, :217-219: wrong-trio row (6 of 36 per tool); LTRpav's 6 all A1,C1;B1 (AUROC
  0.002-0.34); per-run sign test, LTRmix higher in 22 (ancestry) and 23 (recent) of 29 runs, p 0.008 and 0.002.
- **M10.** Terms defined: posterior SIM_RESULTS.md:39; probit and profile interval :173-175; emissions and EM :250-252;
  AIC :570-571; design effect dead_ends.md:240-241. Stray breaks fixed: SIM_RESULTS.md:237-244 (section 3 "Reading")
  and dead_ends.md:301-302.
- **M11.** dead_ends.md:325-328: "Evidence" and "Cause tested" are separate headings.
- **M12.** SIM_RESULTS.md:755-761: precedent line citing Patterson et al. 2012 (Genetics, doi 10.1534/genetics.112.145037,
  PMID 22960212) and Günther and Nettelblad 2019 (PLoS Genetics, doi 10.1371/journal.pgen.1008302, PMID 31348818), both
  checked on Crossref and Europe PMC (title, authors, journal; abstracts read); the novelty for transposon insertions is
  marked unverified (literature not searched).

**Probe changes.** claims.py section 6 (McNemar replaces Fisher); new fix2_checks.py -> fix2_checks.txt; rerun.sh runs
it; SHA256SUMS refreshed (12 files OK; SHA256SUMS sha256 f7274c9134d7a1c843390bcb9d0addc08099847866d96704abd0c7a0c7e97fa0). perrun.tsv, calib_truth.tsv,
calib_truth.log and qprobe.tsv reran byte-identical; claims.txt changed only in section 6.

**Files** (sha256): SIM_RESULTS.md 1f5a0d79985d64a243001b92cf6edef99f5f9cc6ac5483c4b048ec450a78096e; dead_ends.md
84d81362b310e20fbb2315626f6dd9c9b5b7db10e2a528d9142be0fbb39eefad (earlier sections byte-identical).

**Re-review text fixes (N1-N3 and the closing line).** SIM_RESULTS.md now 769 lines, sha256 03e2597f41f3f5931bb8fc025ab21d59fecee90ac35148bd547fe1b94d67e68b; dead_ends.md 396 lines, sha256 b29936288cc257e37d5940aa0460e85a443aca8fb54fc0a5fe4a4739e69895dc (lines 1-213 unchanged).
- N1, SIM_RESULTS.md:218-222: both tools have 6 wrong trios (all A1,C1;B1; LTRpav AUROC 0.002-0.34, LTRmix ancestry 0.0002-0.20); leaving them out, LTRpav 0.72 (26 runs) and LTRmix 0.90 (ancestry, 25 runs; recent 0.92), so the gap widens. To keep every non-table number in a probe, fix2_checks.py's M9 block now also prints these (fix2_checks.txt; SHA256SUMS refreshed, sha256 6067d2596a5231b76af65a24d356c2bdbf81fc8c19242ef0d9537a53ac329a74; the other probe outputs reran unchanged).
- N2, dead_ends.md:391-392: "or predictions made with LTRpav's own testability rule" became "and".
- N3: pc_A1C1_r2's DOL Z is -0.79 (SIM_RESULTS.md:366-367, dead_ends.md:371); the two-nulls rule now cites "controller ruling (I4), 2026-11-14" beside plan Task 16 Step 2 (SIM_RESULTS.md:96, dead_ends.md:232-233; the section 1 verdict paragraph was reflowed, wording otherwise unchanged).
- Closing line, SIM_RESULTS.md:766-769: power and painting limited at 50 Mb (sections 2-4); the direction test is not validated, C1>A1 cannot pass at any genome size (design-test mismatch) and A1>C1 is short of loci at 50 Mb (section 5).
