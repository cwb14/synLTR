#!/usr/bin/env python3
"""Fig. 5 (fig5_generality): the same LTR-RT signal in two more admixture events, a wild Zea exchange and sweet orange.

Rebuilds everything from the ltrmix outputs of the citrus test (benchmark/lineage2), the wild-Zea test
(benchmark/genus) and the maize trio (benchmark/results/main3), the citrus LTR-RT libraries and assemblies (one
example element re-extracted with samtools faidx and aligned with mafft / edlib), and the published truth (Wu et al.
2023, lineage2/truth). Writes fig5_generality.pdf (figure + short legend + long legend), fig5_generality.png
(300 dpi, figure only) and fig5_generality_numbers.tsv into this script's folder; caches parsed inputs in ./work.

Run:  source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix; python fig5_generality.py [-v] [--rebuild]
"""
import argparse
import glob
import os
import re
import subprocess
import sys

os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # the shared server stalls large allocations otherwise
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.lines

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.collections import LineCollection, PatchCollection
from matplotlib.patches import Rectangle, Polygon
from scipy.stats import rankdata

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(HERE, "work")
ROOT = "/data2/chris/maize_introgression"
BENCH = f"{ROOT}/benchmark"
L2 = f"{BENCH}/lineage2"
CIT = f"{L2}/out"
GEN = f"{BENCH}/genus"
MAIN = f"{BENCH}/results/main3"
INPUTS = f"{ROOT}/inputs"
STEM = "fig5_generality"
DATE = "2026-11-07"
SCRIPT = os.path.abspath(__file__)
VERBOSE = False

# colors fixed across the benchmark figures (SPEC.md shared block); in this figure vermillion = mandarin-like (donor),
# blue = pummelo-like (sister), bluish green = published truth (outline only), gray = context
MEX, PAR, MAIZE, CTX, ELAI = "#D55E00", "#0072B2", "#333333", "#BBBBBB", "#009E73"
MEX_L, PAR_L = "#EDB48A", "#8CBFDC"
CLASS_COL = {"near_donor": MEX, "donor_only": MEX_L, "near_sister": PAR, "sister_only": PAR_L,
             "near_both": "#777777", "shared": "#999999", "private": "#D9D9D9", "unresolved": "#FFFFFF"}
INF = ["near_donor", "donor_only", "near_sister", "sister_only"]
R_, S_, D_ = "CsB", "Cm", "Cr"          # main citrus trio: recipient, sister, donor (as inferred by ltrmix)
TRIO = "CsB_Cr_Cm"
CONTROLS = ["Cr_Cm_CaM", "Cr_Cm_CaP"]   # sour-orange haplotype trios (each haplotype about pure)
LIBDIR = {"CsA": "ltrquest_a", "CsB": "ltrquest_a", "Cr": "ltrquest_a", "Cm": "ltrquest_b", "CaM": "ltrquest_b",
          "CaP": "ltrquest_b"}
CHR9 = [f"chr{i}" for i in range(1, 10)]
EDGES = [0, 1e-9, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1]
LABS = ["0", "(0,0.002]", "(0.002,0.005]", "(0.005,0.01]", "(0.01,0.02]", "(0.02,0.05]", "(0.05,0.1]", ">0.1"]
FLANK_N = 10            # elements per flank for the boundary rule (panel B)
B_HALF = 1_500_000      # panel B window: chosen boundary +- 1.5 Mb
W, H = 180.0, 233.5     # figure size, mm


def log(msg, verbose_only=False):
    if verbose_only and not VERBOSE:
        return
    print(f"[{STEM}] {msg}", file=sys.stderr, flush=True)


def die(msg):
    sys.exit(f"[{STEM}] ERROR: {msg}")


# ---------------------------------------------------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------------------------------------------------
def cached(name, fn):
    os.makedirs(WORK, exist_ok=True)
    p = os.path.join(WORK, f"{name}.pkl")
    if os.path.exists(p):
        return pd.read_pickle(p)
    log(f"building {name}", True)
    x = fn()
    pd.to_pickle(x, p)
    return x


def parse_id(s):
    """'G_chrN:start-end#cls' -> (chrom, start, end)."""
    c, rest = s.split(":", 1)
    a, b = rest.split("#")[0].split("-")
    return c, int(a), int(b)


def stats_rows(path):
    s = pd.read_csv(path, sep="\t", low_memory=False)
    return s


def stat(s, test, stratum=None):
    x = s[s.test == test]
    if stratum is not None:
        x = x[x.stratum == stratum]
    if len(x) != 1:
        die(f"stats: {len(x)} rows for {test} / {stratum}")
    return x.iloc[0]


def jack(a, b, blk):
    """Delete-one-block jackknife of D = (A - B) / (A + B) (benchmark/scripts/wg_kmer_trio.py jack())."""
    ub, inv = np.unique(blk, return_inverse=True)
    A, B = np.bincount(inv, a, len(ub)), np.bincount(inv, b, len(ub))
    D = (A.sum() - B.sum()) / (A.sum() + B.sum())
    jk = np.array([((A.sum() - A[i]) - (B.sum() - B[i])) / (A.sum() + B.sum() - A[i] - B[i]) for i in range(len(ub))])
    return D, np.sqrt((len(jk) - 1) / len(jk) * ((jk - jk.mean()) ** 2).sum()), len(ub)


def faidx(g, region):
    out = subprocess.run(["samtools", "faidx", f"{INPUTS}/{g}.fa", region], capture_output=True, text=True)
    if out.returncode != 0:
        die(f"samtools faidx {g} {region}: {out.stderr.strip()}")
    return "".join(out.stdout.split("\n")[1:]).upper()


COMP = str.maketrans("ACGTN", "TGCAN")


def rc(s):
    return s.translate(COMP)[::-1]


def fai(g):
    return pd.read_csv(f"{INPUTS}/{g}.fa.fai", sep="\t", header=None, usecols=[0, 1], names=["c", "L"]).set_index(
        "c").L


# ---------------------------------------------------------------------------------------------------------------------
# data: citrus
# ---------------------------------------------------------------------------------------------------------------------
def read_lib(g):
    def f():
        keep = ["#seq_id", "seq_len", "ltr5_start", "ltr5_end", "ltr3_start", "ltr3_end", "k2p", "k2p_se", "motif",
                "tsd", "strand", "family", "domains", "nest_status"]
        fs = sorted(glob.glob(f"{L2}/{LIBDIR[g]}/{g}_LTRs_depth*_clean_ltr.tsv"))
        if not fs:
            die(f"no LTR library tables for {g}")
        x = pd.concat([pd.read_csv(fn, sep="\t", usecols=keep, dtype={"tsd": str, "strand": str}) for fn in fs])
        x = x.drop_duplicates("#seq_id").rename(columns={"#seq_id": "name"}).set_index("name")
        return x
    return cached(f"lib_{g}", f)


def read_orth(a, b):
    def f():
        x = pd.read_csv(f"{CIT}/orthologs.{a}.{b}.tsv.gz", sep="\t", dtype={"same_tsd": str})
        return x
    return cached(f"orth_{a}_{b}", f)


def load_citrus():
    d = {}
    e = pd.read_csv(f"{CIT}/{TRIO}/elements.{R_}.tsv", sep="\t")
    e["c"] = e.chrom.str.split("_").str[1]
    e["mid"] = (e.start + e.end) / 2
    e["len"] = e.end - e.start + 1
    d["e"] = e
    tr = pd.read_csv(f"{CIT}/{TRIO}/tracts.{R_}.bed", sep="\t")
    tr.columns = [c.lstrip("#") for c in tr.columns]
    d["tracts"] = tr
    dec = pd.read_csv(f"{CIT}/{TRIO}/decoy_tracts.{S_}.bed", sep="\t")
    dec.columns = [c.lstrip("#") for c in dec.columns]
    d["decoys"] = dec
    d["truth"] = pd.read_csv(f"{L2}/truth/{R_}.M.bed", sep="\t", header=None, names=["chrom", "s", "e"])
    d["truthA"] = pd.read_csv(f"{L2}/truth/CsA.P.bed", sep="\t", header=None, names=["chrom", "s", "e"])
    d["fai"] = {g: fai(g) for g in (R_, S_, D_)}
    d["blocks"] = pd.read_csv(f"{CIT}/blocks.tsv", sep="\t")
    d["stats"] = stats_rows(f"{CIT}/{TRIO}/stats.tsv")
    d["ctrl_stats"] = {t: stats_rows(f"{CIT}/{t}/stats.tsv") for t in CONTROLS + ["CsA_Cr_Cm"]}
    d["trios"] = pd.read_csv(f"{L2}/eval/trios.tsv", sep="\t").set_index("trio")
    d["eval_tracts"] = pd.read_csv(f"{L2}/eval/tracts.tsv", sep="\t")
    d["eval_truth"] = pd.read_csv(f"{L2}/eval/truth_tracts.tsv", sep="\t")
    d["lib"] = {g: read_lib(g) for g in (R_, S_, D_)}
    d["o_RS"], d["o_RD"] = read_orth(R_, S_), read_orth(R_, D_)
    return d


def homolog_map(d):
    """CsB chromosome -> (partner chromosome, main orientation) for Cm and Cr from the collinear blocks (anchor-weighted
    sign of the blocks on the pair with most anchors)."""
    b = d["blocks"]
    out = {}
    for p in (S_, D_):
        x = b[(b.genome_a == R_) & (b.genome_b == p)].copy()
        m = {}
        for c in sorted(x.chrom_a.unique(), key=lambda s: int(s.split("chr")[1])):
            y = x[x.chrom_a == c]
            g = y.groupby("chrom_b").n_anchor.sum()
            pc = g.idxmax()
            z = y[y.chrom_b == pc]
            sign = 1 if (z.sign * z.n_anchor).sum() >= 0 else -1
            m[c] = (pc, sign)
        out[p] = m
    return out


def ortholog_pairs(d, partner):
    """1:1 ortholog pairs CsB -> partner on the homologous chromosome (partner coordinates parsed from the names)."""
    o = d["o_RS"] if partner == S_ else d["o_RD"]
    o = o[o[partner] != "."].copy()
    pc = o[partner].map(parse_id)
    o["p_chrom"] = [x[0] for x in pc]
    o["p_mid"] = [(x[1] + x[2]) / 2 for x in pc]
    o["p_start"] = [x[1] for x in pc]
    o["p_end"] = [x[2] for x in pc]
    o["mid"] = (o.start + o.end) / 2
    return o


# ---------------------------------------------------------------------------------------------------------------------
# panel B: the boundary rule
# ---------------------------------------------------------------------------------------------------------------------
def boundary_table(d, n=None):
    """Every internal boundary of the called (recent-sharing) tracts: mean posterior of the FLANK_N elements nearest the
    boundary inside the tract and outside it. Internal = >= 5 informative elements beyond it on the chromosome."""
    e, tr, truth = d["e"], d["tracts"], d["truth"]
    n = FLANK_N if n is None else n
    rows = []
    for _, t in tr.iterrows():
        ec = e[e.chrom == t.chrom].sort_values("mid")
        for side in ("start", "end"):
            if side == "start":
                pos = t.start0 + 1
                out = ec[ec.end < pos].iloc[::-1]
                ins = ec[(ec.start >= pos) & (ec.end <= t.end)]
            else:
                pos = t.end
                out = ec[ec.start > pos]
                ins = ec[(ec.start > t.start0) & (ec.end <= pos)].iloc[::-1]
            if out["class"].isin(INF).sum() < 5:
                continue
            tt = truth[(truth.chrom == t.chrom) & (truth.s < t.end) & (truth.e > t.start0)]
            rows.append(dict(chrom=t.chrom, pos=int(pos), side=side, tract_start0=int(t.start0), tract_end=int(t.end),
                             tract_Mb=(t.end - t.start0) / 1e6, post_in=ins.post_recent_Cr.iloc[:n].mean(),
                             post_out=out.post_recent_Cr.iloc[:n].mean(), n_in=min(len(ins), n),
                             overlaps_truth=len(tt) > 0))
    b = pd.DataFrame(rows)
    b["r_in"] = rankdata(b.post_in) / len(b)
    b["r_out"] = rankdata(b.post_out) / len(b)
    b["dist"] = (b.r_in - 0.5).abs() + (b.r_out - 0.5).abs()
    return b


def select_boundary(d):
    b = boundary_table(d)
    cand = b[b.overlaps_truth].sort_values("dist")
    if not len(cand):
        die("no tract boundary overlaps the published tracts")
    best = cand.iloc[0]
    log(f"panel B boundary: {best.chrom}:{best.pos:,} ({best.side}; flank posterior in {best.post_in:.3f} / out "
        f"{best.post_out:.3f}; percentile distance {best.dist:.2f}; {len(cand)} truth-overlapping of {len(b)} internal "
        f"boundaries)", True)
    return b, best


# ---------------------------------------------------------------------------------------------------------------------
# panel C: example element, rule and structural checks
# ---------------------------------------------------------------------------------------------------------------------
def example_candidates(d):
    """CsB elements inside published mandarin tracts, class donor_only or near_donor, absent from Cm (SPEC rule);
    rk = percentile distance to the medians of K2P and length of all such elements."""
    e, truth = d["e"], d["truth"]
    ok = np.zeros(len(e), bool)
    for _, t in truth.iterrows():
        ok |= ((e.chrom == t.chrom) & (e.start - 1 >= t.s) & (e.end <= t.e)).values
    c = e[ok & e["class"].isin(["donor_only", "near_donor"]) & (e[f"in_{S_}"] == "absent")].copy()
    c["rk"] = (rankdata(c.k2p) / len(c) - 0.5).__abs__() + (rankdata(c.len) / len(c) - 0.5).__abs__()
    return c


def k2p_of(a, b):
    """K2P between two aligned sequences (gap columns skipped)."""
    ts = tv = n = 0
    pur = set("AG")
    for x, y in zip(a, b):
        if x == "-" or y == "-" or x not in "ACGT" or y not in "ACGT":
            continue
        n += 1
        if x != y:
            if (x in pur) == (y in pur):
                ts += 1
            else:
                tv += 1
    if n == 0:
        return np.nan, 0, 0, 0
    P, Q = ts / n, tv / n
    try:
        k = -0.5 * np.log(1 - 2 * P - Q) - 0.25 * np.log(1 - 2 * Q)
    except (ValueError, ZeroDivisionError):
        k = np.nan
    return k, n, ts, tv


def mafft_pair(a, b, tag):
    os.makedirs(f"{WORK}/aln", exist_ok=True)
    fi, fo = f"{WORK}/aln/{tag}.fa", f"{WORK}/aln/{tag}.aln.fa"
    if not os.path.exists(fo):
        with open(fi, "w") as f:
            f.write(f">a\n{a}\n>b\n{b}\n")
        r = subprocess.run(["mafft", "--globalpair", "--maxiterate", "100", "--quiet", "--thread", "2", fi],
                           capture_output=True, text=True)
        if r.returncode != 0:
            die(f"mafft {tag}: {r.stderr[:300]}")
        with open(fo, "w") as f:
            f.write(r.stdout)
    seqs, cur = [], None
    for line in open(fo):
        if line.startswith(">"):
            seqs.append("")
        else:
            seqs[-1] += line.strip().upper()
    return seqs[0], seqs[1]


def element_seq(g, name, lib, fl):
    """Element with fl bp of flank on each side, in the element's own orientation (5' LTR first)."""
    c, s, e = parse_id(name)
    raw = faidx(g, f"{c}:{s - fl}-{e + fl}")
    r = lib.loc[name]
    minus = str(r.strand) == "-"
    return (rc(raw) if minus else raw), minus, r


def check_element(d, r, fl=60):
    """Structural checks for one candidate: TSD (5 bp, identical at both ends, = library TSD) and TG..CA in CsB and in
    its Cr ortholog; same TSD in both; self-LTR K2P re-aligned vs the annotation; CsB-Cr copy divergence; the Cm empty
    site (CsB flanks joined with one TSD copy, edlib infix search in the syntenic Cm interval)."""
    import edlib
    res = {}
    libR, libD = d["lib"][R_], d["lib"][D_]
    name, oname = r["name"], r[f"ortholog_{D_}"]
    sR, minusR, lr = element_seq(R_, name, libR, fl)
    if oname == "." or oname not in libD.index:
        return dict(ok=False, why="no Cr library record")
    sD, minusD, ld = element_seq(D_, oname, libD, fl)
    for tag, s, lb, minus in (("R", sR, lr, minusR), ("D", sD, ld, minusD)):
        t5, t3 = s[fl - 5:fl], s[len(s) - fl:len(s) - fl + 5]
        res[f"tsd_{tag}"] = (t5, t3)
        lt = str(lb.tsd).upper()
        res[f"tsd_lib_{tag}"] = lt
        # 5 bp, identical at both ends, the annotator's own TSD call (library TSD is on the + strand), and not a
        # mononucleotide run (an A5 next to an A-rich flank does not fix the insertion boundary)
        res[f"tsd_ok_{tag}"] = ((t5 == t3) and len(t5) == 5 and lt == (rc(t5) if minus else t5)
                                and len(set(t5)) > 1)
        res[f"ends_{tag}"] = s[fl:fl + 2] + ".." + s[len(s) - fl - 2:len(s) - fl]
        res[f"tgca_{tag}"] = s[fl:fl + 2] == "TG" and s[len(s) - fl - 2:len(s) - fl] == "CA"
    res["same_tsd"] = res["tsd_R"][0] == res["tsd_D"][0]
    # self-LTR K2P (CsB copy)
    core = sR[fl:len(sR) - fl]
    L5 = core[int(lr.ltr5_start) - 1:int(lr.ltr5_end)]
    L3 = core[int(lr.ltr3_start) - 1:int(lr.ltr3_end)]
    a5, a3 = mafft_pair(L5, L3, f"ltr_{re.sub('[^A-Za-z0-9]', '_', name)}")
    k, n, ts, tv = k2p_of(a5, a3)
    res["k2p_realigned"], res["k2p_lib"], res["k2p_se"] = k, float(lr.k2p), float(lr.k2p_se)
    res["k2p_ok"] = abs(k - float(lr.k2p)) <= 2 * max(float(lr.k2p_se), 1e-4)
    # copy divergence CsB vs Cr (elements only)
    cD = sD[fl:len(sD) - fl]
    ea, eb = mafft_pair(core, cD, f"copy_{re.sub('[^A-Za-z0-9]', '_', name)}")
    sub = sum(1 for x, y in zip(ea, eb) if x != y and x != "-" and y != "-")
    gaps = sum(1 for x, y in zip(ea, eb) if (x == "-") != (y == "-"))
    al = sum(1 for x, y in zip(ea, eb) if x != "-" and y != "-")
    res["copy_sub"], res["copy_gapcols"], res["copy_alnlen"] = sub, gaps, al
    res["len_R"], res["len_D"] = len(core), len(cD)
    runs = [len(m.group(0)) for m in re.finditer(r"-+", ea)] + [len(m.group(0)) for m in re.finditer(r"-+", eb)]
    res["copy_max_indel"] = max(runs) if runs else 0
    res["colinear"] = res["copy_max_indel"] <= 50     # the two copies are the same element, no large indel
    # Cm empty site: syntenic interval from the nearest CsB elements with Cm orthologs on both sides
    o = d["o_RS"]
    o = o[(o.chrom == r.chrom) & (o[S_] != ".")]
    left = o[o.end < r.start].sort_values("end").tail(3)
    right = o[o.start > r.end].sort_values("start").head(3)
    if not len(left) or not len(right):
        return dict(res, ok=False, why="no flanking Cm orthologs")
    pcs = [parse_id(x) for x in list(left[S_]) + list(right[S_])]
    chs = pd.Series([p[0] for p in pcs]).value_counts()
    pch = chs.index[0]
    pos = [p[1] for p in pcs if p[0] == pch] + [p[2] for p in pcs if p[0] == pch]
    lo, hi = max(1, min(pos) - 30_000), max(pos) + 30_000
    if hi - lo > 3_000_000:
        return dict(res, ok=False, why=f"Cm interval too long ({hi - lo:,} bp)")
    region = faidx(S_, f"{pch}:{lo}-{hi}")
    # expected empty site in the element's orientation: 5' flank incl. TSD + 3' flank after the second TSD copy
    F5, F3 = sR[:fl], sR[len(sR) - fl + 5:]
    empty = F5 + F3
    best = None
    for strand, q in (("+", empty), ("-", rc(empty))):
        a = edlib.align(q, region, mode="HW", task="locations")
        if a["editDistance"] >= 0 and (best is None or a["editDistance"] < best[0]):
            best = (a["editDistance"], strand, a["locations"][0])
    ed, strand, (ls, le) = best
    site = region[ls:le + 1]
    site = rc(site) if strand == "-" else site
    res["cm_site_ed"] = ed
    res["cm_site_len"] = len(site)
    res["cm_region"] = f"{pch}:{lo + ls}-{lo + le}"
    res["cm_strand"] = strand
    # one TSD copy: the 5' flank (with its TSD) aligns to the start of the site, the 3' flank (without the second
    # TSD) to the rest, and the site is about as long as the two flanks (no element, no second TSD)
    res["cm_single_tsd"] = (abs(len(site) - len(empty)) <= 3) and ed <= 0.10 * len(empty)
    # the element itself (its 5' end) must not be in the site's neighborhood
    res["seqs"] = dict(R=sR, D=sD, site=site, F5=F5, F3=F3, fl=fl, aR=ea, aD=eb, L5=a5, L3=a3, minusR=minusR,
                       minusD=minusD)
    # near-identical copies (the panel shows a near-identical shared copy: class near_donor)
    res["near_identical"] = r["class"] == "near_donor"
    # length typical of the family (family with >= 10 members in the CsB library, length within its 10-90th pct)
    fam = libR[libR.family == lr.family]
    res["family_n"] = len(fam)
    res["family_len_pct"] = float((fam.seq_len < lr.seq_len).mean())
    res["family_typical"] = len(fam) >= 10 and 0.10 <= res["family_len_pct"] <= 0.90
    # domain order canonical for the superfamily (Copia: GAG PROT INT RT RH; Gypsy: GAG PROT RT RH INT [CHD])
    doms = []
    for x in str(lr.domains).split(";"):
        m = re.match(r"(\w+)\|[^@]*@(\d+)-(\d+)", x)
        if m:
            doms.append((int(m.group(2)), m.group(1)))
    order = [n for _, n in sorted(doms)]
    if minusR:
        order = order[::-1]
    canon = {"Copia": ["GAG", "PROT", "INT", "RT", "RH"], "Gypsy": ["GAG", "PROT", "RT", "RH", "INT", "CHD"]}
    sup = name.split("#")[1].split("/")[1] if "#" in name else ""
    ref = [x for x in canon.get(sup, []) if x in order]
    res["domains"] = "-".join(order)
    res["domain_order"] = len(order) >= 3 and order == ref
    keys = ("tsd_ok_R", "tsd_ok_D", "tgca_R", "tgca_D", "same_tsd", "colinear", "k2p_ok", "cm_single_tsd",
            "near_identical", "family_typical", "domain_order")
    res["ok"] = bool(all(res[k] for k in keys))
    res["why"] = "" if res["ok"] else ",".join(k for k in keys if not res[k])
    return res


def select_element(d, max_screen=80):
    """Panel C example: candidates in order of closeness to the medians of K2P and length (SPEC rule); the first one
    that passes every structural check. Returns the row, its checks and the screen log."""
    c = example_candidates(d).sort_values("rk")
    logrows = []
    for _, r in c.head(max_screen).iterrows():
        chk = check_element(d, r)
        logrows.append(dict(name=r["name"], rk=r.rk, k2p=r.k2p, len=r.len, cls=r["class"], div_Cr=r.div_Cr,
                            ok=chk.get("ok"), why=chk.get("why"), copy_sub=chk.get("copy_sub"),
                            copy_max_indel=chk.get("copy_max_indel"), cm_site_ed=chk.get("cm_site_ed"),
                            family_n=chk.get("family_n"), domains=chk.get("domains")))
        if chk.get("ok"):
            log(f"panel C element: {r['name']} (rank {len(logrows)} of {len(c)} candidates)", True)
            return r, chk, pd.DataFrame(logrows), c
    die("no candidate passed the structural checks")


# ---------------------------------------------------------------------------------------------------------------------
# panel D: every shared insertion (exactly as ltrmix counts them)
# ---------------------------------------------------------------------------------------------------------------------
def shared_insertions(R, S, D):
    """ABBA: R+D share an insertion that S lacks (S has the syntenic interval, and the donor copy is absent from S
    through D's own synteny); BABA mirror. Clock = the donor copy's LTR-LTR K2P (ltrmix patterns())."""
    rd, rs = read_orth(R, D), read_orth(R, S)
    sd, sr = read_orth(S, D), read_orth(S, R)
    if not ((rd[R].values == rs[R].values).all() and (sd[S].values == sr[S].values).all()):
        die("ortholog tables out of order")
    A = rd.loc[(rd[D] != ".") & (rs[f"status_in_{S}"] == "absent")].copy()
    B = sd.loc[(sd[D] != ".") & (sr[f"status_in_{R}"] == "absent")].copy()
    dS = read_orth(D, S).set_index(D)[f"status_in_{S}"]
    dR = read_orth(D, R).set_index(D)[f"status_in_{R}"]
    A = A[dS.reindex(A[D]).values == "absent"].copy()
    B = B[dR.reindex(B[D]).values == "absent"].copy()
    k = read_lib(D).k2p
    for X in (A, B):
        X["k2p"] = k.reindex(X[D]).values
        if X.k2p.isna().any():
            die(f"donor copies without K2P in the {D} library")
        X["stratum"] = np.digitize(X.k2p.values, EDGES[1:], right=True)
    return A, B


# ---------------------------------------------------------------------------------------------------------------------
# data: wild Zea and maize
# ---------------------------------------------------------------------------------------------------------------------
ZEA = [("Zh", "TIL18", "TIL18_Zh_Zn"), ("TIL01", "TIL18", "TIL01_TIL18_Zn"), ("TIL25", "TIL18", "TIL18_TIL25_Zn")]


def load_zea():
    def f():
        z = {}
        wg = pd.read_csv(f"{GEN}/wgk/wgk_trio.tsv", sep="\t")
        z["wg"] = wg
        rows = []
        for R, S, trio in ZEA + [("Zh", "TIL01", "TIL01_Zh_Zn")]:
            t = pd.read_csv(f"{GEN}/wgk/wgk_trio.{R}_{S}_Zn.tsv", sep="\t")
            for c, g in t.groupby("chrom", sort=False):
                blk = (g.chrom + ":" + (g.start // 5_000_000).astype(str)).values
                Dc, se, nb = jack(g[f"with_{R}"].values.astype(float), g[f"with_{S}"].values.astype(float), blk)
                rows.append(dict(R=R, S=S, chrom=c.split("_")[1], D=Dc, SE=se, nblocks=nb, src="whole"))
            blk = (t.chrom + ":" + (t.start // 5_000_000).astype(str)).values
            Dg, seg, nbg = jack(t[f"with_{R}"].values.astype(float), t[f"with_{S}"].values.astype(float), blk)
            ref = wg[(wg.R == R) & (wg.S == S)].iloc[0]
            if abs(Dg - ref.D_kmer) > 1e-6 or abs(seg - ref.SE) > 1e-6:
                die(f"whole-assembly D {R} vs {S} does not reproduce wgk_trio.tsv ({Dg} vs {ref.D_kmer})")
            s = stats_rows(f"{GEN}/out/{trio}/stats.tsv")
            for _, r in s[s.test == "D_kmer_by_chrom"].iterrows():
                rows.append(dict(R=R, S=S, chrom=r.stratum.split("_")[1], D=r.D, SE=r.SE, nblocks=r.nblocks,
                                 src="library"))
            z[f"lib_{R}_{S}"] = stat(s, "D_kmer", "all")
            z[f"res_{R}_{S}"] = stat(s, "donor_resolved")
            z[f"ins_{R}_{S}"] = stat(s, "D_ins", "all")
        z["chrom"] = pd.DataFrame(rows)
        z["summary"] = pd.read_csv(f"{GEN}/out/analysis/trio_summary.tsv", sep="\t").set_index("trio")
        return z
    return cached("zea", f)


def load_maize():
    def f():
        m = {}
        s = stats_rows(f"{MAIN}/stats.tsv")
        m["D_kmer"] = stat(s, "D_kmer", "all")
        t = pd.read_csv(f"{BENCH}/wgk/wgk_all.TIL18.tsv", sep="\t")
        D, se, nb = jack(t.with_B73v5.values.astype(float), t.with_TIL01.values.astype(float),
                         (t.chrom + ":" + (t.start // 5_000_000).astype(str)).values)
        m["wg"] = (D, se, nb)
        return m
    return cached("maize", f)


# ---------------------------------------------------------------------------------------------------------------------
# figure helpers
# ---------------------------------------------------------------------------------------------------------------------
def setup_style():
    for fn in sorted(glob.glob("/usr/share/fonts/truetype/liberation*/Liberation*.ttf")):
        font_manager.fontManager.addfont(fn)
    names = {f.name for f in font_manager.fontManager.ttflist}
    if "Liberation Sans" not in names or "Liberation Mono" not in names:
        die("Liberation Sans / Liberation Mono fonts not found")
    plt.rcParams.update({
        "font.family": "Liberation Sans", "font.size": 6.5, "pdf.fonttype": 42, "ps.fonttype": 42,
        "axes.linewidth": 0.5, "axes.labelsize": 6.5, "xtick.labelsize": 6, "ytick.labelsize": 6,
        "xtick.major.width": 0.5, "ytick.major.width": 0.5, "xtick.major.size": 2, "ytick.major.size": 2,
        "xtick.minor.size": 1.2, "ytick.minor.size": 1.2, "xtick.minor.width": 0.4, "ytick.minor.width": 0.4,
        "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
        "mathtext.fontset": "custom", "mathtext.rm": "Liberation Sans", "mathtext.it": "Liberation Sans:italic",
        "mathtext.bf": "Liberation Sans:bold", "mathtext.cal": "Liberation Sans:italic",
        "mathtext.sf": "Liberation Sans", "mathtext.tt": "Liberation Mono"})


def ax_mm(fig, x, y, w, h, **kw):
    """Axes whose top-left corner is (x, y) mm from the figure's top-left."""
    return fig.add_axes([x / W, 1 - (y + h) / H, w / W, h / H], **kw)


def canvas(fig, x, y, w, h):
    """Frameless axes in mm, origin top-left, y increasing downward."""
    a = ax_mm(fig, x, y, w, h)
    a.set_xlim(0, w)
    a.set_ylim(h, 0)
    a.axis("off")
    return a


def letter(fig, k, x, y):
    fig.text(x / W, 1 - y / H, k, fontsize=10, fontweight="bold", va="top", ha="left")


def it(s):
    """Italic words via mathtext, ordinary spaces between them."""
    return r"$\mathit{" + s.replace("-", r"\text{-}").replace(" ", r"\;") + "}$"


def pack_rows(starts, ends, gap):
    """IGV 'expanded' rows: first row whose last end + gap < start."""
    order = np.argsort(starts, kind="stable")
    last, row = [], np.zeros(len(starts), int)
    for i in order:
        for k, le in enumerate(last):
            if starts[i] > le + gap:
                row[i] = k
                last[k] = ends[i]
                break
        else:
            row[i] = len(last)
            last.append(ends[i])
    return row


# ---------------------------------------------------------------------------------------------------------------------
# panel A: nine sweet-orange chromosomes between pummelo and mandarin
# ---------------------------------------------------------------------------------------------------------------------
A_Y0, A_SC = 10.8, 1.55          # top of the ideograms (mm), mm per Mb
A_GX0, A_PITCH = 11.6, 18.55     # first group's left edge, group pitch (mm)
OFF = dict(cm=(0.0, 1.2), dec=(1.32, 1.82), rib1=(1.95, 4.55), tickL=(4.62, 5.82), box=(5.9, 9.6),
           truth=(9.72, 10.22), call=(10.32, 10.82), tickR=(10.9, 12.1), rib2=(12.17, 14.8), cr=(14.85, 16.05))


def panel_A(fig, d, sel):
    ax = canvas(fig, 0, 0, W, 94)
    hm = homolog_map(d)
    e, fl = d["e"], d["fai"]
    yof = lambda mb: A_Y0 + A_SC * mb
    # left axis
    ymax = 50
    ax.plot([9.6, 9.6], [yof(0), yof(ymax)], color="k", lw=0.5)
    for v in range(0, ymax + 1, 10):
        ax.plot([9.2, 9.6], [yof(v), yof(v)], color="k", lw=0.5)
        ax.text(8.9, yof(v), f"{v}", ha="right", va="center", fontsize=6)
    ax.text(3.2, yof(25), "Position (Mb)", rotation=90, ha="center", va="center", fontsize=6.5)
    oS, oD = ortholog_pairs(d, S_), ortholog_pairs(d, D_)
    thr = float(stat(d["stats"], "hmm_recent").near_threshold)
    out = {}
    for i, c in enumerate(CHR9):
        gx = A_GX0 + i * A_PITCH
        X = lambda k, j=0: gx + OFF[k][j]
        rc_ = f"{R_}_{c}"
        LR = fl[R_][rc_] / 1e6
        pS, sgS = hm[S_][rc_]
        pD, sgD = hm[D_][rc_]
        LS, LD = fl[S_][pS] / 1e6, fl[D_][pD] / 1e6
        yS = (lambda p, L=LS, s=sgS: yof(p / 1e6) if s > 0 else yof(L - p / 1e6))
        yD = (lambda p, L=LD, s=sgD: yof(p / 1e6) if s > 0 else yof(L - p / 1e6))
        # header
        xm = (X("box") + X("box", 1)) / 2
        ax.text(xm, 3.6, c, ha="center", va="center", fontsize=6.5)
        ax.text((X("cm") + X("cm", 1)) / 2, 7.6, "P", ha="center", va="center", fontsize=6.5, color=PAR,
                fontweight="bold")
        ax.text(xm, 7.6, "S", ha="center", va="center", fontsize=6.5, color=MAIZE, fontweight="bold")
        ax.text((X("cr") + X("cr", 1)) / 2, 7.6, "M", ha="center", va="center", fontsize=6.5, color=MEX,
                fontweight="bold")
        # ribbons (every 1:1 ortholog pair on the homologous chromosome)
        segs = []
        x = oS[(oS.chrom == rc_) & (oS.p_chrom == pS)]
        segs += [[(X("rib1", 1), yof(m / 1e6)), (X("rib1"), yS(pm))] for m, pm in zip(x.mid, x.p_mid)]
        x = oD[(oD.chrom == rc_) & (oD.p_chrom == pD)]
        segs += [[(X("rib2"), yof(m / 1e6)), (X("rib2", 1), yD(pm))] for m, pm in zip(x.mid, x.p_mid)]
        ax.add_collection(LineCollection(segs, colors=CTX, linewidths=0.12, alpha=0.55, zorder=1))
        # ideograms
        for k, L in (("cm", LS), ("cr", LD)):
            ax.add_patch(Rectangle((X(k), yof(0)), OFF[k][1] - OFF[k][0], A_SC * L, fc="#EEEEEE", ec="#777777",
                                   lw=0.4, zorder=2))
        ax.add_patch(Rectangle((X("box"), yof(0)), OFF["box"][1] - OFF["box"][0], A_SC * LR, fc="white",
                               ec=MAIZE, lw=0.5, zorder=2))
        for k, sg, L in (("cm", sgS, LS), ("cr", sgD, LD)):
            if sg < 0:
                ax.plot([(X(k) + X(k, 1)) / 2], [yof(L) + 1.3], marker="^", ms=2.2, color="#555555", mew=0,
                        zorder=3)
        # ticks: every informative element
        ec = e[e.chrom == rc_]
        for cls, side in (("sister_only", "L"), ("near_sister", "L"), ("donor_only", "R"), ("near_donor", "R")):
            y = yof(ec[ec["class"] == cls].mid.values / 1e6)
            x0, x1 = (X("tickL"), X("tickL", 1)) if side == "L" else (X("tickR"), X("tickR", 1))
            ax.add_collection(LineCollection([[(x0, yy), (x1, yy)] for yy in y], colors=CLASS_COL[cls],
                                             linewidths=0.35, zorder=3))
        # posterior trace inside the S box
        ec = ec.sort_values("mid")
        bx0, bx1 = X("box") + 0.3, X("box", 1) - 0.3
        ax.plot(bx0 + ec.post_recent_Cr.values * (bx1 - bx0), yof(ec.mid.values / 1e6), color="k", lw=0.55,
                zorder=4, solid_joinstyle="round")
        # published tracts (outline), called tracts, decoy tracts on P
        for _, t in d["truth"][d["truth"].chrom == rc_].iterrows():
            ax.add_patch(Rectangle((X("truth"), yof(t.s / 1e6)), 0.5, max(A_SC * (t.e - t.s) / 1e6, 0.25),
                                   fc="none", ec=ELAI, lw=0.6, zorder=4))
        for _, t in d["tracts"][d["tracts"].chrom == rc_].iterrows():
            ax.add_patch(Rectangle((X("call"), yof(t.start0 / 1e6)), 0.5,
                                   max(A_SC * (t.end - t.start0) / 1e6, 0.25), fc="none", ec="k", lw=0.5, zorder=4))
        for _, t in d["decoys"][d["decoys"].chrom == pS].iterrows():
            y0, y1 = sorted((yS(t.start0), yS(t.end)))
            ax.add_patch(Rectangle((X("dec"), y0), 0.5, max(y1 - y0, 0.25), fc="none", ec="k", lw=0.5, zorder=4))
        out[c] = dict(gx=gx, yS=yS, yD=yD, pS=pS, pD=pD, sgS=sgS, sgD=sgD)
    # zoom marks: panel B window on chr9 (all three genomes), panel C element
    bw, cel = sel["B"], sel["C"]
    g = out[bw["chrom"].split("_")[1]]
    X = lambda k, j=0: g["gx"] + OFF[k][j]
    ax.add_patch(Rectangle((X("tickL") - 0.15, yof(bw["lo"] / 1e6)), X("tickR", 1) - X("tickL") + 0.3,
                           A_SC * (bw["hi"] - bw["lo"]) / 1e6, fc="none", ec="k", lw=0.6, zorder=6))
    for k, yfun, (plo, phi) in (("cm", g["yS"], bw["S_win"]), ("cr", g["yD"], bw["D_win"])):
        y0, y1 = sorted((yfun(plo), yfun(phi)))
        ax.add_patch(Rectangle((X(k) - 0.25, y0), OFF[k][1] - OFF[k][0] + 0.5, y1 - y0, fc="none", ec="k", lw=0.6,
                               zorder=6))
    ax.text(X("tickL") - 0.5, yof((bw["lo"] + bw["hi"]) / 2e6), "B", fontsize=7, fontweight="bold", ha="right",
            va="center", zorder=7, bbox=dict(fc="white", ec="none", pad=0.4))
    g = out[cel["chrom"].split("_")[1]]
    X = lambda k, j=0: g["gx"] + OFF[k][j]
    yc = yof((cel["start"] + cel["end"]) / 2e6)
    ax.add_patch(Rectangle((X("tickR") - 0.1, yc - 0.55), OFF["tickR"][1] - OFF["tickR"][0] + 0.2, 1.1, fc="none",
                           ec="k", lw=0.6, zorder=6))
    ax.text(X("tickR", 1) + 0.2, yc, "C", fontsize=7, fontweight="bold", ha="left", va="center", zorder=7)
    key_A(ax, d)
    return out


def partner_window(d, partner, chrom, lo, hi):
    """The partner interval homologous to CsB chrom:lo-hi at the same bp length: local orientation and offset from the
    1:1 ortholog pairs inside the window (median of p - sign * x)."""
    o = ortholog_pairs(d, partner)
    hm = homolog_map(d)[partner][chrom]
    x = o[(o.chrom == chrom) & (o.mid >= lo) & (o.mid <= hi) & (o.p_chrom == hm[0])]
    if len(x) < 5:
        die(f"too few {partner} orthologs in the panel B window")
    sg = 1 if np.corrcoef(x.mid, x.p_mid)[0, 1] >= 0 else -1
    off = float(np.median(x.p_mid - sg * x.mid))
    a, b = off + sg * lo, off + sg * hi
    return hm[0], sg, (min(a, b), max(a, b))


def selections(d):
    def f():
        b, best = select_boundary(d)
        lo, hi = best.pos - B_HALF, best.pos + B_HALF
        pS, sgS, wS = partner_window(d, S_, best.chrom, lo, hi)
        pD, sgD, wD = partner_window(d, D_, best.chrom, lo, hi)
        r, chk, lg, cand = select_element(d)
        return dict(boundaries=b, B=dict(chrom=best.chrom, pos=int(best.pos), side=best.side, lo=int(lo), hi=int(hi),
                                         S_chrom=pS, S_sign=sgS, S_win=wS, D_chrom=pD, D_sign=sgD, D_win=wD,
                                         row=best),
                    C=dict(name=r["name"], chrom=r.chrom, start=int(r.start), end=int(r.end), row=r, chk=chk),
                    screen=lg, n_cand=len(cand), cand_med_k2p=float(cand.k2p.median()),
                    cand_med_len=float(cand.len.median()))
    return cached("selections", f)


def key_A(ax, d):
    x0, y0, lh = 88.0, 73.6, 2.7
    t = lambda x, y, s, **kw: ax.text(x, y, s, va="center", ha="left", fontsize=6, **kw)
    t(x0, y0, "P", color=PAR, fontweight="bold")
    t(x0 + 2.4, y0, "pummelo Cm, " + it("C. maxima"))
    t(x0, y0 + lh, "S", color=MAIZE, fontweight="bold")
    t(x0 + 2.4, y0 + lh, "sweet orange CsB (haplotype B), " + it("C. sinensis"))
    t(x0, y0 + 2 * lh, "M", color=MEX, fontweight="bold")
    t(x0 + 2.4, y0 + 2 * lh, "mandarin Cr, " + it("C. reticulata"))
    ax.plot([x0, x0 + 1.8], [y0 + 3 * lh] * 2, color=CTX, lw=0.6)
    t(x0 + 2.4, y0 + 3 * lh, "ortholog pair")
    ax.plot([x0 + 20.4], [y0 + 3 * lh], marker="^", ms=2.2, color="#555555", mew=0)
    t(x0 + 21.5, y0 + 3 * lh, "drawn inverted")
    yy = y0 + 4 * lh
    ax.add_patch(Rectangle((x0 + 0.5, yy - 0.75), 0.6, 1.5, fc="none", ec=ELAI, lw=0.7))
    t(x0 + 2.4, yy, "published M tract")
    ax.add_patch(Rectangle((x0 + 20.1, yy - 0.75), 0.6, 1.5, fc="none", ec="k", lw=0.55))
    t(x0 + 21.5, yy, "LTR-RT tract (on P: decoy)")
    x1 = x0 + 50.0
    t(x1, y0, "element of S, tick if")
    for k, (cls, lab) in enumerate((("near_donor", "near-identical to M copy"), ("donor_only", "shared with M only"),
                                    ("near_sister", "near-identical to P copy"),
                                    ("sister_only", "shared with P only"))):
        yy = y0 + lh * (k + 1)
        ax.plot([x1, x1 + 1.6], [yy, yy], color=CLASS_COL[cls], lw=1.4, solid_capstyle="butt")
        t(x1 + 2.2, yy, lab)
    yy = y0 + 5 * lh
    ax.plot([x1, x1 + 1.6], [yy, yy], color="k", lw=0.7)
    t(x1 + 2.2, yy, "M-like posterior (0 to 1)")


# ---------------------------------------------------------------------------------------------------------------------
# panel B: zoom across one tract boundary, every element of the three genomes to size
# ---------------------------------------------------------------------------------------------------------------------
def lib_window(g, chrom, lo, hi):
    lib = read_lib(g)
    p = [parse_id(n) for n in lib.index]
    df = pd.DataFrame(p, columns=["chrom", "start", "end"], index=lib.index)
    return df[(df.chrom == chrom) & (df.end >= lo) & (df.start <= hi)].copy()


def panel_B(fig, d, sel, y0):
    bw = sel["B"]
    ax = canvas(fig, 0, y0, W, 44)
    X0, X1 = 24.5, 176.0
    lo, hi = bw["lo"], bw["hi"]
    span = hi - lo
    thr = float(stat(d["stats"], "hmm_recent").near_threshold)
    xR = lambda p: X0 + (np.asarray(p, float) - lo) / span * (X1 - X0)

    def xP(p, win, sg):
        p = np.asarray(p, float)
        return X0 + ((p - win[0]) if sg > 0 else (win[1] - p)) / (win[1] - win[0]) * (X1 - X0)
    xS = lambda p: xP(p, bw["S_win"], bw["S_sign"])
    xD = lambda p: xP(p, bw["D_win"], bw["D_sign"])
    Y = dict(axS=3.6, laneS=(4.6, 1.0), linkS=(8.4, 14.6), laneR=(14.9, 1.0), axR=19.0, truth=(22.3, 0.9),
             call=(25.0, 0.9), post=(27.2, 31.5), linkD=(31.8, 37.2), laneD=(37.5, 1.0), axD=41.6)
    e = d["e"]
    eR = e[(e.chrom == bw["chrom"]) & (e.end >= lo) & (e.start <= hi)].copy()
    eS = lib_window(S_, bw["S_chrom"], *bw["S_win"])
    eD = lib_window(D_, bw["D_chrom"], *bw["D_win"])

    def lane(df, xf, ybase, colors, ec="none", lw=0.0, rows_max=3):
        x0 = np.minimum(xf(df.start.values), xf(df.end.values))
        x1 = np.maximum(xf(df.start.values), xf(df.end.values))
        w = np.maximum(x1 - x0, 0.22)
        rows = np.minimum(pack_rows(x0, x0 + w, 0.12), rows_max - 1)
        top, hh = ybase
        for xx, ww, rr, cc in zip(x0, w, rows, colors):
            ax.add_patch(Rectangle((xx, top + rr * (hh + 0.25)), ww, hh, fc=cc, ec=ec if cc == "#FFFFFF" else "none",
                                   lw=lw, zorder=3))
        return rows

    # links (drawn first)
    segs, cols = [], []
    for _, r in eR.iterrows():
        xm = float(xR((r.start + r.end) / 2))
        o = r[f"ortholog_{S_}"]
        if o != ".":
            c, s, en = parse_id(o)
            if c == bw["S_chrom"] and bw["S_win"][0] <= (s + en) / 2 <= bw["S_win"][1]:
                segs.append([(xm, Y["linkS"][1]), (float(xS((s + en) / 2)), Y["linkS"][0])])
                cols.append(PAR if np.isfinite(r[f"div_{S_}"]) and r[f"div_{S_}"] < thr else CTX)
        o = r[f"ortholog_{D_}"]
        if o != ".":
            c, s, en = parse_id(o)
            if c == bw["D_chrom"] and bw["D_win"][0] <= (s + en) / 2 <= bw["D_win"][1]:
                segs.append([(xm, Y["linkD"][0]), (float(xD((s + en) / 2)), Y["linkD"][1])])
                cols.append(MEX if np.isfinite(r[f"div_{D_}"]) and r[f"div_{D_}"] < thr else CTX)
    order = np.argsort([0 if c == CTX else 1 for c in cols], kind="stable")
    ax.add_collection(LineCollection([segs[i] for i in order], colors=[cols[i] for i in order], linewidths=0.55,
                                     zorder=2))
    # guide from the S lane through the band for elements linked to M (thin, faint)
    # lanes
    linkedS = set(eR[f"ortholog_{S_}"]) - {"."}
    linkedD = set(eR[f"ortholog_{D_}"]) - {"."}
    lane(eS, xS, Y["laneS"], ["#8C8C8C" if n in linkedS else "#CFCFCF" for n in eS.index])
    lane(eR, xR, Y["laneR"], [CLASS_COL[c] for c in eR["class"]], ec="#999999", lw=0.3)
    lane(eD, xD, Y["laneD"], ["#8C8C8C" if n in linkedD else "#CFCFCF" for n in eD.index])
    # axes (own Mb ticks per genome)
    def axis(yy, a, b, xf, below, sg=1):
        ax.plot([X0, X1], [yy, yy], color="k", lw=0.5, zorder=1)
        step = 0.5e6
        t0 = np.ceil(min(a, b) / step) * step
        for v in np.arange(t0, max(a, b) + 1, step):
            xx = float(xf(v))
            ax.plot([xx, xx], [yy, yy + (0.7 if below else -0.7)], color="k", lw=0.5)
            ax.text(xx, yy + (1.0 if below else -1.0), f"{v / 1e6:.1f}", ha="center", va="top" if below else "bottom",
                    fontsize=6)
        ax.text(X1 + 0.8, yy + (1.0 if below else -1.0), "Mb", ha="left", va="top" if below else "bottom", fontsize=6)
    axis(Y["axS"], *bw["S_win"], xS, False)
    axis(Y["axR"], lo, hi, xR, True)
    axis(Y["axD"], *bw["D_win"], xD, True)
    # band: published tract, LTR-RT tract, posterior
    for _, t in d["truth"][d["truth"].chrom == bw["chrom"]].iterrows():
        if t.e >= lo and t.s <= hi:
            a, b = xR(max(t.s, lo)), xR(min(t.e, hi))
            ax.add_patch(Rectangle((a, Y["truth"][0]), b - a, Y["truth"][1], fc="none", ec=ELAI, lw=0.8, zorder=3))
            ax.text(a - 1.0, Y["truth"][0] + Y["truth"][1] / 2, "published M tract", ha="right", va="center",
                    fontsize=6, color=ELAI)
    for _, t in d["tracts"][d["tracts"].chrom == bw["chrom"]].iterrows():
        if t.end >= lo and t.start0 <= hi:
            a, b = xR(max(t.start0, lo)), xR(min(t.end, hi))
            ax.add_patch(Rectangle((a, Y["call"][0]), b - a, Y["call"][1], fc="none", ec="k", lw=0.6, zorder=3))
            ax.text(a - 1.0, Y["call"][0] + Y["call"][1] / 2, "LTR-RT tract", ha="right", va="center", fontsize=6)
    ee = eR.sort_values("mid")
    p0, p1 = Y["post"]
    ax.plot([X0, X1], [p1, p1], color="#DDDDDD", lw=0.4, zorder=1)
    ax.plot([X0, X1], [p0, p0], color="#DDDDDD", lw=0.4, zorder=1)
    ax.plot(xR(ee.mid), p1 - ee.post_recent_Cr.values * (p1 - p0), color="k", lw=0.7, zorder=4)
    ax.text(X0 - 0.6, p0, "1", ha="right", va="center", fontsize=5.5)
    ax.text(X0 - 0.6, p1, "0", ha="right", va="center", fontsize=5.5)
    # labels
    lab = lambda yy, s, **kw: ax.text(X0 - 2.2, yy, s, ha="right", va="center", fontsize=6.5, **kw)
    lab(Y["laneS"][0] + 1.3, "P  " + bw["S_chrom"].replace("_", " "), color=PAR)
    lab(Y["laneR"][0] + 1.3, "S  " + bw["chrom"].replace("_", " "), color=MAIZE)
    lab(Y["laneD"][0] + 1.3, "M  " + bw["D_chrom"].replace("_", " ") + ("  ▲" if bw["D_sign"] < 0 else ""),
        color=MEX)
    lab((p0 + p1) / 2, "M-like posterior")
    return dict(nR=len(eR), nS=len(eS), nD=len(eD), n_linkS=sum(1 for c in cols if c == PAR),
                n_linkD=sum(1 for c in cols if c == MEX))


# ---------------------------------------------------------------------------------------------------------------------
# panel C: the example element at base-pair resolution
# ---------------------------------------------------------------------------------------------------------------------
def domains_rel(lr, start, end, minus):
    out = []
    for x in str(lr.domains).split(";"):
        m = re.match(r"(\w+)\|[^@]*@(\d+)-(\d+)", x)
        if m:
            a, b = int(m.group(2)), int(m.group(3))
            ra, rb = (a - start, b - start) if not minus else (end - b, end - a)
            out.append((m.group(1), ra, rb))
    return sorted(out, key=lambda t: t[1])


def panel_C(fig, d, sel, y0):
    import edlib
    ax = canvas(fig, 0, y0, W, 30)
    c = sel["C"]
    chk, s = c["chk"], c["chk"]["seqs"]
    fl = s["fl"]
    lr = d["lib"][R_].loc[c["name"]]
    L = len(s["R"]) - 2 * fl
    minus = s["minusR"]
    # schematic of the two copies to scale
    Xa, Xb = 36.0, 140.0
    sc = (Xb - Xa) / L
    rows = dict(S=3.2, M=8.4)
    l5 = int(lr.ltr5_end) - int(lr.ltr5_start) + 1
    l3 = int(lr.ltr3_end) - int(lr.ltr3_start) + 1
    doms = domains_rel(lr, c["start"], c["end"], minus)
    for k, yy in rows.items():
        ax.plot([Xa - 3, Xb + 3], [yy, yy], color="#777777", lw=0.5, zorder=1)
        ax.add_patch(Rectangle((Xa, yy - 0.75), Xb - Xa, 1.5, fc=MEX_L, ec="none", zorder=2))
        for a_, b_ in ((0, l5), (L - l3, L)):
            ax.add_patch(Rectangle((Xa + a_ * sc, yy - 1.1), (b_ - a_) * sc, 2.2, fc=MEX, ec="none", zorder=3))
        for nm, a_, b_ in doms:
            ax.add_patch(Rectangle((Xa + a_ * sc, yy - 0.75), (b_ - a_) * sc, 1.5, fc="#C98B5E", ec="none", zorder=3))
    for nm, a_, b_ in doms:
        ax.text(Xa + (a_ + b_) / 2 * sc, rows["S"] - 1.5, nm, ha="center", va="bottom", fontsize=5.5,
                color="#555555")
    ax.text(Xa + l5 / 2 * sc, rows["S"] - 1.5, "LTR", ha="center", va="bottom", fontsize=5.5, color="#555555")
    ax.text(Xa + (L - l3 / 2) * sc, rows["S"] - 1.5, "LTR", ha="center", va="bottom", fontsize=5.5,
            color="#555555")
    # differences between the copies (every substitution and indel column); band between the two copies
    yb = (rows["S"] + rows["M"]) / 2
    ax.add_patch(Rectangle((Xa, yb - 0.55), Xb - Xa, 1.1, fc="#EEEEEE", ec="none", zorder=1))
    pos, i = [], 0
    for x_, y_ in zip(s["aR"], s["aD"]):
        if x_ != y_:
            pos.append(i)
        if x_ != "-":
            i += 1
    for p in pos:
        ax.plot([Xa + p * sc] * 2, [yb - 0.55, yb + 0.55], color="k", lw=0.5, zorder=2)
    ax.text(Xb + 4.0, yb, f"{len(pos)} differences in {L:,} bp" if len(pos) != 1 else f"1 difference in {L:,} bp",
            ha="left", va="center", fontsize=6, color="#555555")
    ax.text(Xa - 4.0, rows["S"], "S copy", ha="right", va="center", fontsize=6.5)
    ax.text(Xa - 4.0, rows["M"], "M copy", ha="right", va="center", fontsize=6.5, color=MEX)
    ax.plot([Xb + 4.0, Xb + 4.0 + 1000 * sc], [rows["M"] + 0.2] * 2, color="k", lw=0.6)
    ax.text(Xb + 5.0 + 1000 * sc, rows["M"] + 0.2, "1 kb", ha="left", va="center", fontsize=6)
    # base-pair junctions: S, M, P (empty site with one TSD copy)
    n_fl, n_ltr = 14, 13
    cw = 1.27 * 6.0 / 6.0           # mm per character at 6 pt Liberation Mono (0.6 em)
    fs = 6.0
    yS_, yM_, yP_ = 17.6, 21.2, 24.8
    sR, sD = s["R"], s["D"]
    # align the empty site to the S flanks to place P's bases in S columns
    empty = s["F5"] + s["F3"]
    al = edlib.align(empty, s["site"], mode="NW", task="path")
    nice = edlib.getNiceAlignment(al, empty, s["site"])
    qa, ta = nice["query_aligned"], nice["target_aligned"]
    # P bases keyed by S-empty position (gaps in S are dropped: shown as a mismatch marker)
    pmap, qi = {}, 0
    for q_, t_ in zip(qa, ta):
        if q_ != "-":
            pmap[qi] = t_
            qi += 1
    blocks = []
    # 5' junction: flank (n_fl) + TSD (5) + LTR start (n_ltr)
    a5 = fl - 5 - n_fl
    left = dict(S=sR[a5:fl + n_ltr], M=sD[a5:fl + n_ltr],
                P="".join(pmap.get(k, "-") for k in range(a5, fl)) + "-" * n_ltr)
    # 3' junction: LTR end (n_ltr) + TSD (5) + flank (n_fl)
    e3 = len(sR) - fl
    right = dict(S=sR[e3 - n_ltr:e3 + 5 + n_fl], M=sD[len(sD) - fl - n_ltr:len(sD) - fl + 5 + n_fl],
                 P="-" * (n_ltr + 5) + "".join(pmap.get(len(s["F5"]) + k, "-") for k in range(n_fl)))
    xL = 24.5
    xR_ = xL + (n_fl + 5 + n_ltr) * cw + 30.0
    for (blk, x0, tsd0, ltr_rng) in ((left, xL, n_fl, (n_fl + 5, n_fl + 5 + n_ltr)),
                                     (right, xR_, n_ltr, (0, n_ltr))):
        for k, yy in (("S", yS_), ("M", yM_), ("P", yP_)):
            seq = blk[k]
            for j, ch in enumerate(seq):
                xx = x0 + j * cw
                inl = ltr_rng[0] <= j < ltr_rng[1]
                if inl and ch != "-":
                    ax.add_patch(Rectangle((xx, yy - 1.25), cw, 2.5, fc=MEX, ec="none", zorder=1))
                if k == "P" and ch != "-" and ch != blk["S"][j]:
                    ax.add_patch(Rectangle((xx, yy - 1.25), cw, 2.5, fc="#D0D0D0", ec="none", zorder=1))
                ax.text(xx + cw / 2, yy, ch if ch != "-" else "-", ha="center", va="center", fontsize=fs,
                        family="Liberation Mono", color="white" if (inl and ch != "-") else
                        ("#999999" if ch == "-" else "k"), zorder=2)
            # TSD box
        ax.add_patch(Rectangle((x0 + tsd0 * cw, yS_ - 1.45), 5 * cw, (yP_ if blk is left else yM_) - yS_ + 2.9,
                               fc="none", ec="k", lw=0.6, zorder=3))
        ax.text(x0 + (tsd0 + 2.5) * cw, yS_ - 1.7, "TSD", ha="center", va="bottom", fontsize=6)
        ax.text(x0 + (ltr_rng[0] + ltr_rng[1]) / 2 * cw, yS_ - 1.7, "LTR", ha="center", va="bottom", fontsize=6,
                color=MEX)
    mid = (xL + (n_fl + 5 + n_ltr) * cw + xR_) / 2
    hidden = L - 2 * n_ltr
    ax.text(mid, yS_, f"… {hidden:,} bp …", ha="center", va="center", fontsize=6)
    ax.text(mid, yM_, f"… {len(sD) - 2 * fl - 2 * n_ltr:,} bp …", ha="center", va="center", fontsize=6)
    ax.text(mid, yP_, "empty site", ha="center", va="center", fontsize=6, color=PAR)
    for k, yy, col, nm in (("S", yS_, MAIZE, "S  sweet orange B"), ("M", yM_, MEX, "M  mandarin Cr"),
                           ("P", yP_, PAR, "P  pummelo Cm")):
        ax.text(xL - 1.5, yy, nm, ha="right", va="center", fontsize=6.5, color=col)
    # connectors from the copies to the junction blocks
    ax.plot([Xa, xL + (n_fl + 5) * cw], [rows["M"] + 1.1, yS_ - 3.6], color="#999999", lw=0.4)
    ax.plot([Xb, xR_ + n_ltr * cw], [rows["M"] + 1.1, yS_ - 3.6], color="#999999", lw=0.4)
    ax.text(xL + (n_fl + 2.5) * cw, yP_ + 1.6, "one TSD copy", ha="center", va="top", fontsize=6, color=PAR)
    return dict(L=L, n_diff=len(pos), cm_ed=chk["cm_site_ed"], cm_region=chk["cm_region"])


# ---------------------------------------------------------------------------------------------------------------------
# panel D: the clock (every shared insertion, D by age stratum, controls)
# ---------------------------------------------------------------------------------------------------------------------
KMIN, KMAX = 6e-4, 0.4


def kx(k):
    return np.log10(np.clip(k, KMIN, KMAX))


def panel_D(fig, d, A, B, x, y):
    s = d["stats"]
    by = s[s.test == "D_ins_by_age"].copy()
    by["lab"] = by.stratum.str.replace("K2P ", "", regex=False)
    mids = {"0": None, "(0,0.002]": 0.001, "(0.002,0.005]": np.sqrt(0.002 * 0.005),
            "(0.005,0.01]": np.sqrt(0.005 * 0.01), "(0.01,0.02]": np.sqrt(0.01 * 0.02),
            "(0.02,0.05]": np.sqrt(0.02 * 0.05), "(0.05,0.1]": np.sqrt(0.05 * 0.1), ">0.1": 0.17}
    x0s, x0m, wst, wm = x + 13.0, x + 17.3, 3.0, 37.2   # stub (K2P = 0) and main log axis
    oo = read_orth(D_, S_)
    pm = oo[oo[S_] != "."].divergence.quantile([0.25, 0.75]).values   # P-M ortholog divergence IQR
    hs = 10.5
    rng = np.random.default_rng(7)
    # strips
    a0 = ax_mm(fig, x0s, y + 3.0, wst, hs)
    a1 = ax_mm(fig, x0m, y + 3.0, wm, hs)
    for a in (a0, a1):
        a.set_ylim(0, 2)
        a.axis("off")
    a0.set_xlim(-1, 1)
    a1.set_xlim(kx(KMIN), kx(KMAX))
    for X_, yc, col in ((A, 1.45, MEX), (B, 0.55, PAR)):
        k = X_.k2p.values
        jit = rng.uniform(-0.36, 0.36, len(k))
        z = k <= 1e-9
        a0.scatter(rng.uniform(-0.6, 0.6, z.sum()), yc + jit[z], s=1.2, color=col, lw=0, alpha=0.8)
        a1.scatter(kx(k[~z]), yc + jit[~z], s=1.2, color=col, lw=0, alpha=0.8)
    # counts per stratum (all strata, including those below ltrmix's 10-insertion minimum)
    for i, lab in enumerate(LABS):
        nA = int((A.stratum == i).sum())
        nB_ = int((B.stratum == i).sum())
        if lab == "0":
            a0.text(0, 2.05, f"{nA}", ha="center", va="bottom", fontsize=5.5, color=MEX)
            a0.text(0, -0.05, f"{nB_}", ha="center", va="top", fontsize=5.5, color=PAR)
        else:
            xm_ = kx(mids[lab])
            a1.text(xm_, 2.05, f"{nA}", ha="center", va="bottom", fontsize=5.5, color=MEX)
            a1.text(xm_, -0.05, f"{nB_}", ha="center", va="top", fontsize=5.5, color=PAR)
    for e_ in EDGES[2:]:
        a1.axvline(kx(e_), color="#CCCCCC", lw=0.4, ls=":", zorder=0)
    a1.axvspan(kx(pm[0]), kx(pm[1]), color="#EBEBEB", lw=0, zorder=-1)
    fig.text((x0s - 0.8) / W, 1 - (y + 3.0 + hs * 0.27) / H, "S + M\n(not P)", ha="right", va="center",
             fontsize=6, color=MEX, linespacing=0.95)
    fig.text((x0s - 0.8) / W, 1 - (y + 3.0 + hs * 0.73) / H, "P + M\n(not S)", ha="right", va="center",
             fontsize=6, color=PAR, linespacing=0.95)
    # D by stratum
    yd, hd = y + 3.0 + hs + 4.6, 31.0
    b0 = ax_mm(fig, x0s, yd, wst, hd)
    b1 = ax_mm(fig, x0m, yd, wm, hd)
    for b in (b0, b1):
        b.set_ylim(-0.75, 1.12)
        b.axhline(0, color="k", lw=0.5, zorder=1)
    b0.set_xlim(-1, 1)
    b1.set_xlim(kx(KMIN), kx(KMAX))
    b1.spines["left"].set_visible(False)
    b1.tick_params(axis="y", left=False, labelleft=False)
    b0.set_xticks([0])
    b0.set_xticklabels(["0"])
    tk = [0.001, 0.01, 0.1]
    b1.set_xticks(kx(np.array(tk)))
    b1.set_xticklabels(["0.001", "0.01", "0.1"])
    b1.set_xticks(kx(np.array([v * m for v in (0.001, 0.01, 0.1) for m in range(2, 10) if v * m <= KMAX])),
                  minor=True)
    for e_ in EDGES[2:]:
        b1.axvline(kx(e_), color="#CCCCCC", lw=0.4, ls=":", zorder=0)
    b1.axvspan(kx(pm[0]), kx(pm[1]), color="#EBEBEB", lw=0, zorder=-1)
    b1.text(kx(pm[0]) + 0.03, -0.72, "P–M\northologs", ha="left", va="bottom", fontsize=5.5,
            color="#777777", linespacing=0.9)
    b0.set_ylabel("excess sharing with the donor,\nD (± 2 SE)", fontsize=6.5, labelpad=1.5)
    b0.set_yticks([-0.5, 0, 0.5, 1])
    fig.text((x0m + wm / 2 - 2) / W, 1 - (yd + hd + 5.0) / H,
             "insertion age: LTR–LTR divergence\nof the donor copy (K2P)", ha="center", va="top", fontsize=6.5,
             linespacing=1.0)
    # controls (two sour-orange trios), then the CsB trio
    ctrl_mk = {"Cr_Cm_CaM": ("s", 0.92), "Cr_Cm_CaP": ("D", 1.09)}
    for t, (mk, f) in ctrl_mk.items():
        cs = d["ctrl_stats"][t]
        x_ = cs[cs.test == "D_ins_by_age"]
        for _, r in x_.iterrows():
            lab = r.stratum.replace("K2P ", "")
            if mids[lab] is None:
                continue
            xx = kx(mids[lab] * f)
            b1.errorbar([xx], [r.D], yerr=[[2 * r.SE]], fmt=mk, ms=2.3, mfc="white", mec="#888888", ecolor="#AAAAAA",
                        elinewidth=0.6, capsize=0, mew=0.6, zorder=2)
    for _, r in by.iterrows():
        lab = r.lab
        if mids[lab] is None:
            b0.errorbar([0], [r.D], yerr=[[2 * r.SE]], fmt="o", ms=2.8, color="k", elinewidth=0.7, capsize=0,
                        zorder=3)
            continue
        se2 = 2 * r.SE
        b1.errorbar([kx(mids[lab])], [r.D], yerr=[[min(se2, r.D + 0.75)], [min(se2, 1.12 - r.D)]], fmt="o", ms=2.8,
                    color="k", elinewidth=0.7, capsize=0, zorder=3)
    # direct labels
    b1.text(kx(0.0013), 0.97, "S vs P,\ndonor M", ha="center", va="top", fontsize=6, linespacing=0.95)
    b1.plot([kx(0.03)], [1.0], "s", ms=2.3, mfc="white", mec="#888888", mew=0.6)
    b1.plot([kx(0.038)], [1.0], "D", ms=2.3, mfc="white", mec="#888888", mew=0.6)
    b1.text(kx(0.047), 1.0, "controls", ha="left", va="center", fontsize=6, color="#777777")
    return dict(by=by)


# ---------------------------------------------------------------------------------------------------------------------
# panel E: the wild Zea exchange, per chromosome
# ---------------------------------------------------------------------------------------------------------------------
def panel_E(fig, z, x, y):
    a = ax_mm(fig, x + 11.5, y + 3.0, 44.0, 40.0)
    ch = z["chrom"]
    xs = {R: i for i, (R, S, _) in enumerate(ZEA)}
    for c in [f"chr{i}" for i in range(1, 11)]:
        pts = []
        for R, S, _ in ZEA:
            r = ch[(ch.R == R) & (ch.S == S) & (ch.chrom == c) & (ch.src == "whole")].iloc[0]
            pts.append((xs[R] - 0.13, r.D))
        a.plot([p[0] for p in pts], [p[1] for p in pts], color="#BBBBBB", lw=0.45, zorder=1)
    for R, S, _ in ZEA:
        w = ch[(ch.R == R) & (ch.S == S) & (ch.src == "whole")]
        l = ch[(ch.R == R) & (ch.S == S) & (ch.src == "library")]
        col = MAIZE if R != "TIL25" else "#888888"
        a.scatter(np.full(len(w), xs[R] - 0.13), w.D, s=9, marker="D", color=col, lw=0, zorder=3)
        a.scatter(np.full(len(l), xs[R] + 0.13), l.D, s=8, facecolors="white", edgecolors=col, lw=0.6, zorder=3)
    a.axhline(0, color="k", lw=0.5, zorder=0)
    a.set_xlim(-0.42, 2.42)
    a.set_ylim(-0.12, 0.30)
    a.set_xticks([0, 1, 2])
    a.set_xticklabels(["Zh\n" + it("huehuetenangensis"), "TIL01\n" + it("parviglumis"),
                       "TIL25\n" + it("mexicana")], fontsize=5.6, linespacing=1.15)
    a.set_ylabel("excess sharing with " + it("Z. nicaraguensis") + ",\nD per chromosome", fontsize=6.5,
                 labelpad=1.5)
    a.set_xlabel("each vs mexicana TIL18", fontsize=6.5, labelpad=1.5)
    a.text(2.0, 0.085, "control", ha="center", va="bottom", fontsize=6, color="#777777")
    a.scatter([1.16], [0.285], s=9, marker="D", color=MAIZE, lw=0)
    a.text(1.29, 0.285, "whole assemblies", va="center", fontsize=6)
    a.scatter([1.16], [0.262], s=8, facecolors="white", edgecolors=MAIZE, lw=0.6)
    a.text(1.29, 0.262, "EDTA LTR-RTs", va="center", fontsize=6)
    return a


# ---------------------------------------------------------------------------------------------------------------------
# panel F: every event and control
# ---------------------------------------------------------------------------------------------------------------------
def f_rows(d, z, m):
    tr = d["trios"]
    wg = z["wg"]
    rows = []
    D, se, Z = m["D_kmer"].D, m["D_kmer"].SE, m["D_kmer"].Z
    rows.append(dict(grp="maize ← mexicana", lab="B73 vs TIL01", D=D, SE=se, Z=Z, wD=m["wg"][0], wSE=m["wg"][1],
                     ctrl=False, lib="LTRquest", src=f"{MAIN}/stats.tsv (D_kmer); {BENCH}/wgk/wgk_all.TIL18.tsv (whole)"))
    for R, S, trio in ZEA:
        r = z[f"lib_{R}_{S}"]
        w = wg[(wg.R == R) & (wg.S == S)].iloc[0]
        rows.append(dict(grp=it("Z. mays") + " ← " + it("Z. nicaraguensis"), lab=f"{R} vs {S}", D=r.D, SE=r.SE, Z=r.Z,
                         wD=w.D_kmer, wSE=w.SE, ctrl=R == "TIL25", lib="EDTA",
                         src=f"{GEN}/out/{trio}/stats.tsv; {GEN}/wgk/wgk_trio.tsv"))
    for trio, lab, ctrl in ((TRIO, "CsB vs Cm ← Cr", False), ("CsA_Cr_Cm", "CsA vs Cr ← Cm", False),
                            ("Cr_Cm_CaM", "CaM vs Cr ← Cm", True), ("Cr_Cm_CaP", "Cm vs CaP ← Cr", True)):
        t = tr.loc[trio]
        rows.append(dict(grp="sweet and sour orange", lab=lab, D=t.D_kmer, SE=t.D_kmer / t.D_kmer_Z, Z=t.D_kmer_Z,
                         wD=np.nan, wSE=np.nan, ctrl=ctrl, lib="LTRquest", src=f"{L2}/eval/trios.tsv"))
    return pd.DataFrame(rows)


def panel_F(fig, d, z, m, x, y):
    fr = f_rows(d, z, m)
    a = ax_mm(fig, x + 25.5, y + 3.0, 25.0, 42.0)
    ypos, yy, last = [], 0.0, None
    heads = []
    for _, r in fr.iterrows():
        if r.grp != last:
            yy += 0.55 if last is not None else 0.0
            heads.append((r.grp, yy))
            yy += 1.0
            last = r.grp
        ypos.append(yy)
        yy += 1.0
    fr["y"] = ypos
    for _, r in fr.iterrows():
        col = "#888888" if r.ctrl else MAIZE
        edta = r.lib == "EDTA"
        a.errorbar([r.D], [r.y], xerr=[[2 * r.SE]], fmt="o", ms=2.8, mfc="white" if edta else col, mec=col,
                   ecolor=col, elinewidth=0.7, capsize=0, mew=0.7, zorder=3)
        if np.isfinite(r.wD):
            a.errorbar([r.wD], [r.y + 0.38], xerr=[[2 * r.wSE]], fmt="D", ms=2.3, color=col, elinewidth=0.6,
                       capsize=0, zorder=3)
        a.text(0.545, r.y, f"Z {r.Z:.1f}", ha="left", va="center", fontsize=5.5, color=col, clip_on=False)
        fig.text((x + 25.0) / W, 1 - (y + 3.0 + 42.0 * (r.y + 0.75) / (yy + 0.5)) / H, r.lab, ha="right",
                 va="center", fontsize=6, color=col)
    for g, hy in heads:
        fig.text((x + 0.5) / W, 1 - (y + 3.0 + 42.0 * (hy + 0.75) / (yy + 0.5)) / H, g, ha="left", va="center",
                 fontsize=6, fontweight="bold")
    a.axvline(0, color="k", lw=0.5, zorder=0)
    a.set_ylim(yy - 0.25, -0.75)
    a.set_xlim(-0.15, 0.52)
    a.set_xticks([0, 0.2, 0.4])
    a.spines["left"].set_visible(False)
    a.tick_params(axis="y", left=False, labelleft=False)
    a.set_xlabel("excess sharing with the donor,\n" + r"$D_\mathrm{kmer}$ (± 2 SE)", fontsize=6.5, labelpad=1.5)
    # key (one line above the panel): library annotator and whole assemblies
    ky = y + 1.2
    kx0 = x + 9.5
    for dx, mk, fc, lab in ((0.0, "o", MAIZE, "LTRquest"), (12.8, "o", "white", "EDTA"),
                            (21.6, "D", MAIZE, "whole assemblies")):
        k = fig.add_artist(matplotlib.lines.Line2D([(kx0 + dx) / W], [1 - ky / H], marker=mk, ms=2.6 if mk == "o"
                                                   else 2.3, mfc=fc, mec=MAIZE, mew=0.7, ls="none"))
        fig.text((kx0 + dx + 1.4) / W, 1 - ky / H, lab, ha="left", va="center", fontsize=6)
    return fr


# ---------------------------------------------------------------------------------------------------------------------
# numbers and legends
# ---------------------------------------------------------------------------------------------------------------------
def fmt_d(x, nd=3):
    return f"{x:+.{nd}f}".replace("-", "−")


def collect_numbers(d, z, m, sel, A, B, info):
    rows, v = [], {}

    def add(key, value, source):
        rows.append((key, value, source))
        v[key] = value
        return value
    T = f"{L2}/eval/trios.tsv"
    tr = d["trios"].loc[TRIO]
    add("CsB D_kmer", fmt_d(tr.D_kmer), T)
    add("CsB D_kmer Z", f"{tr.D_kmer_Z:.1f}", T)
    add("CsB D_ins", fmt_d(tr.D_ins), T)
    add("CsB D_ins Z", f"{tr.D_ins_Z:.1f}", T)
    add("CsB D_self", fmt_d(tr.D_self_outgroup), T)
    add("CsB D_self Z", f"{tr.D_self_outgroup_Z:.1f}", T)
    add("CsB element AUROC (recent)", f"{tr.auroc_recent:.3f}", T)
    add("CsB posterior inside published tracts (recent)", f"{tr.post_recent_in:.2f}", T)
    add("CsB posterior outside published tracts (recent)", f"{tr.post_recent_out:.2f}", T)
    add("CsB recent tracts", f"{int(tr.recent_tracts)}", T)
    add("CsB recent decoy tracts", f"{int(tr.recent_decoys)}", T)
    add("CsB recent tracts q<=0.05", f"{int(tr.recent_q05)}", T)
    et = d["eval_tracts"]
    r = et[(et.trio == TRIO) & (et["mode"] == "recent") & (et.set == "all")].iloc[0]
    TT = f"{L2}/eval/tracts.tsv"
    add("CsB called Mb (recent)", f"{r.called_Mb:.1f}", TT)
    add("CsB bp precision (recent)", f"{r.bp_precision:.2f}", TT)
    add("CsB bp recall (recent)", f"{r.bp_recall:.2f}", TT)
    eu = d["eval_truth"]
    u = eu[(eu.trio == TRIO) & (eu["mode"] == "recent") & (eu.set == "all")]
    TU = f"{L2}/eval/truth_tracts.tsv"
    big = u[u.Mb >= 1.7]
    v["_called_truth_chroms"] = sorted(set(u[u.called].chrom))
    small = u[u.Mb < 1.7]
    add("published tracts >= 1.7 Mb, all called", f"{bool(big.called.all())} ({len(big)})", TU)
    add("coverage of published tracts >= 1.7 Mb", f"{big.covered.min() * 100:.0f}-{big.covered.max() * 100:.0f}%", TU)
    add("published tracts <= 1.1 Mb missed", f"{int((~small.called).sum())} of {len(small)}; "
        f"{int(small.n_elements.min())}-{int(small.n_elements.max())} elements", TU)
    gl = float(d["fai"][R_].sum())
    tl = float((d["truth"].e - d["truth"].s).sum())
    add("published M tracts in S", f"{len(d['truth'])} tracts, {tl / 1e6:.1f} Mb = {100 * tl / gl:.1f}%",
        f"{L2}/truth/CsB.M.bed + inputs/CsB.fa.fai (computed here)")
    s = d["stats"]
    hr = stat(s, "hmm_recent")
    ST = f"{CIT}/{TRIO}/stats.tsv"
    add("posterior excess over decoy (recent)", fmt_d(float(hr.excess_over_decoy), 2), ST)
    add("near-identity threshold (K2P)", f"{float(hr.near_threshold):.4f}", ST)
    add("lowest tract q", f"{d['tracts'].q.min():.2f}", f"{CIT}/{TRIO}/tracts.CsB.bed")
    ids = s[(s.test == "identity_spectrum")]
    lo_ = ids[ids.stratum.isin(["d in [0,1e-09)", "d in [1e-09,0.00025)", "d in [0.00025,0.0005)",
                                "d in [0.0005,0.001)", "d in [0.001,0.002)"])]
    add("identity spectrum S-M vs P-M orthologs < 0.2%",
        f"{int(lo_.n_target.astype(float).sum())} vs {int(lo_.n_mirror.astype(float).sum())}", ST)
    e = d["e"]
    for c in INF:
        add(f"S elements {c}", f"{int((e['class'] == c).sum()):,}", f"{CIT}/{TRIO}/elements.CsB.tsv (computed here)")
    add("S elements total", f"{len(e):,}", f"{CIT}/{TRIO}/elements.CsB.tsv")
    oS, oD = ortholog_pairs(d, S_), ortholog_pairs(d, D_)
    add("S-P ortholog pairs drawn", f"{len(oS):,}", f"{CIT}/orthologs.CsB.Cm.tsv.gz (computed here)")
    add("S-M ortholog pairs drawn", f"{len(oD):,}", f"{CIT}/orthologs.CsB.Cr.tsv.gz (computed here)")
    hm = homolog_map(d)
    add("P homologs of S chr1-9", ", ".join(hm[S_][f"{R_}_{c}"][0].split("chr")[1] + ("*" if hm[S_][f"{R_}_{c}"][1] < 0
                                                                                      else "") for c in CHR9),
        f"{CIT}/blocks.tsv (computed here; * drawn inverted)")
    add("M homologs drawn inverted", ", ".join(c for c in CHR9 if hm[D_][f"{R_}_{c}"][1] < 0),
        f"{CIT}/blocks.tsv (computed here)")
    dm = decoy_map(d)
    add("decoy tracts opposite published M segments of S", f"{sum(dm.truth)} of {len(dm)} "
        f"({', '.join(sorted(set(dm[dm.truth].r_chrom.str.split('_').str[1])))})",
        f"{CIT}/{TRIO}/decoy_tracts.Cm.bed + orthologs.Cm.CsB.tsv.gz (computed here)")
    oo = read_orth(D_, S_)
    oo = oo[oo[S_] != "."]
    q = oo.divergence.quantile([0.25, 0.5, 0.75]).values
    add("P-M ortholog divergence median (IQR)", f"{q[1]:.3f} ({q[0]:.3f}-{q[2]:.3f})",
        f"{CIT}/orthologs.Cr.Cm.tsv.gz (computed here)")
    v["_pm_iqr"] = (q[0], q[2])
    # panel B
    bw = sel["B"]
    br = bw["row"]
    bt = sel["boundaries"]
    add("panel B window", f"{bw['chrom']}:{bw['lo']:,}-{bw['hi']:,}", "chosen boundary +- 1.5 Mb (computed here)")
    add("panel B boundary", f"{bw['chrom']}:{bw['pos']:,} ({bw['side']} of tract {br.tract_start0 + 1:,}-"
        f"{br.tract_end:,})", f"{CIT}/{TRIO}/tracts.CsB.bed (computed here)")
    add("internal tract boundaries", f"{len(bt)} (of tracts overlapping published segments: "
        f"{int(bt.overlaps_truth.sum())})", "computed here")
    add("chosen boundary flank posteriors in/out", f"{br.post_in:.2f} / {br.post_out:.2f}", "computed here")
    add("median flank posteriors in/out (all internal boundaries)", f"{bt.post_in.median():.2f} / "
        f"{bt.post_out.median():.2f}", "computed here")
    add("panel B S elements / P / M in window", f"{info['B']['nR']} / {info['B']['nS']} / {info['B']['nD']}",
        "computed here")
    add("panel B near-identical links to P / to M", f"{info['B']['n_linkS']} / {info['B']['n_linkD']}",
        "computed here")
    add("panel B P window", f"{bw['S_chrom']}:{bw['S_win'][0]:,.0f}-{bw['S_win'][1]:,.0f}", "computed here")
    add("panel B M window", f"{bw['D_chrom']}:{bw['D_win'][0]:,.0f}-{bw['D_win'][1]:,.0f} (drawn inverted)"
        if bw["D_sign"] < 0 else f"{bw['D_chrom']}:{bw['D_win'][0]:,.0f}-{bw['D_win'][1]:,.0f}", "computed here")
    tb = d["truth"][d["truth"].chrom == bw["chrom"]]
    tb = tb[(tb.e >= bw["lo"]) & (tb.s <= bw["hi"])].iloc[0]
    add("panel B published tract", f"{tb.s / 1e6:.2f}-{tb.e / 1e6:.2f} Mb", f"{L2}/truth/CsB.M.bed")
    tc = d["tracts"][(d["tracts"].chrom == bw["chrom"]) & (d["tracts"].start0 == br.tract_start0)].iloc[0]
    add("panel B called tract", f"{tc.start0 / 1e6:.2f}-{tc.end / 1e6:.2f} Mb, {int(tc.n_elements)} elements",
        f"{CIT}/{TRIO}/tracts.CsB.bed")
    cov = u[(u.chrom == bw["chrom"]) & (u.start0 == tb.s)].covered.iloc[0]
    add("panel B published tract covered", f"{cov * 100:.0f}%", TU)
    g1, g2 = (tc.start0 - tb.s) / 1e6, (tb.e - tc.end) / 1e6
    add("panel B uncovered ends of the published tract (Mb)", f"{g1:.2f} and {g2:.2f}", "computed here")
    eb = e[(e.chrom == bw["chrom"]) & (((e.start >= tb.s) & (e.end <= tc.start0 + 1)) |
                                       ((e.start >= tc.end) & (e.end <= tb.e)))]
    add("panel B elements in the uncovered ends (informative)", f"{len(eb)} ({int(eb['class'].isin(INF).sum())})",
        f"{CIT}/{TRIO}/elements.CsB.tsv (computed here)")
    thr = float(hr.near_threshold)
    ew = e[(e.chrom == bw["chrom"]) & (e.end >= bw["lo"]) & (e.start <= bw["hi"])]
    nS_ = ew[(ew[f"ortholog_{S_}"] != ".") & (ew[f"div_{S_}"] < thr)]
    nD_ = ew[(ew[f"ortholog_{D_}"] != ".") & (ew[f"div_{D_}"] < thr)]
    add("panel B near-identical P links: S positions (Mb)", f"{nS_.mid.min() / 1e6:.2f}-{nS_.mid.max() / 1e6:.2f}",
        "computed here")
    add("panel B near-identical M links: S positions (Mb)", f"{nD_.mid.min() / 1e6:.2f}-{nD_.mid.max() / 1e6:.2f}",
        "computed here")
    picks = []
    for n in (1, 3, 5, 10, 15, 20, 30):
        bb = boundary_table(d, n)
        cc = bb[bb.overlaps_truth].sort_values("dist").iloc[0]
        picks.append((n, cc.chrom.split("_")[1], cc.pos))
    v["_picks"] = picks
    add("boundary rule pick by flank size (elements: chromosome Mb)",
        "; ".join(f"{n}: {c} {p_ / 1e6:.2f}" for n, c, p_ in picks), "computed here")
    # called sequence outside the published segments, and how much of it lies in the first 5 Mb of chr5 and chr9
    outbp, startbp = 0, 0
    for _, t in d["tracts"].iterrows():
        cov_ = np.zeros(int(t.end - t.start0), bool)
        for _, q in d["truth"][d["truth"].chrom == t.chrom].iterrows():
            a_, b_ = max(q.s, t.start0), min(q.e, t.end)
            if b_ > a_:
                cov_[int(a_ - t.start0):int(b_ - t.start0)] = True
        o_ = ~cov_
        outbp += int(o_.sum())
        if t.chrom in (f"{R_}_chr5", f"{R_}_chr9"):
            pos_ = np.arange(int(t.start0), int(t.end))
            startbp += int((o_ & (pos_ < 5_000_000)).sum())
    add("called Mb outside published segments; share in the first 5 Mb of chr5 and chr9",
        f"{outbp / 1e6:.1f}; {100 * startbp / outbp:.0f}%", "computed here")
    # panel C
    c = sel["C"]
    ck = c["chk"]
    lr = d["lib"][R_].loc[c["name"]]
    add("panel C element", f"{c['chrom']}:{c['start']:,}-{c['end']:,} ({c['name'].split('#')[1]})",
        f"{CIT}/{TRIO}/elements.CsB.tsv")
    add("panel C M copy", c["row"][f"ortholog_{D_}"].split("#")[0], f"{CIT}/{TRIO}/elements.CsB.tsv")
    add("panel C length / family n / length percentile", f"{ck['len_R']:,} bp / {ck['family_n']} / "
        f"{100 * ck['family_len_pct']:.0f}th", f"{L2}/ltrquest_a/CsB_LTRs_depth*_clean_ltr.tsv (computed here)")
    add("panel C copy differences", f"{ck['copy_sub']} substitutions, {ck['copy_gapcols']} indel columns in "
        f"{ck['copy_alnlen']:,} aligned bp", "mafft of the two copies re-extracted with samtools faidx (computed here)")
    add("panel C TSD", f"{ck['tsd_R'][0]} (S), {ck['tsd_D'][0]} (M), annotator {ck['tsd_lib_R']}",
        "inputs/CsB.fa, inputs/Cr.fa + library TSD (computed here)")
    add("panel C self-LTR K2P realigned / annotated", f"{ck['k2p_realigned']:.4f} / {ck['k2p_lib']:.4f} +- "
        f"{ck['k2p_se']:.4f}", "mafft of the two LTRs (computed here); library k2p, k2p_se")
    add("panel C P empty site", f"{ck['cm_region']} ({ck['cm_strand']}), {ck['cm_site_ed']} edits in "
        f"{len(ck['seqs']['F5']) + len(ck['seqs']['F3'])} bp", "edlib infix search of inputs/Cm.fa (computed here)")
    add("panel C domains", ck["domains"], "library domains")
    add("panel C candidates", f"{sel['n_cand']} (median K2P {sel['cand_med_k2p']:.4f}, median length "
        f"{sel['cand_med_len']:,.0f} bp)", "computed here")
    sc = sel["screen"]
    add("panel C rank of chosen element", f"{len(sc)}", "computed here (work/example_screen.tsv)")
    hi_ = sc[sc.ok == False]  # noqa: E712
    why = hi_.why.fillna("")
    tally = dict(tsd=int(why.str.contains("tsd_ok|same_tsd").sum()),
                 site=int(why.str.contains("cm_single_tsd|Cm interval|flanking Cm").sum()),
                 ends=int(why.str.contains("tgca").sum()), colinear=int(why.str.contains("colinear").sum()),
                 other=int(why.str.contains("family_typical|domain_order|k2p_ok").sum()))
    add("higher-ranked candidates failing: TSD / empty site / ends / colinearity / family-domain-K2P",
        f"{tally['tsd']} / {tally['site']} / {tally['ends']} / {tally['colinear']} / {tally['other']} "
        f"(of {len(hi_)}; several fail more than one)", "computed here (work/example_screen.tsv)")
    nd_only = sc[(sc.ok == False) & (sc.why == "near_identical")]  # noqa: E712
    add("candidates failing only near-identity", f"{len(nd_only)}"
        + (f" ({nd_only.name.iloc[0].split('#')[0]}, copies {nd_only.div_Cr.iloc[0] * 100:.1f}% diverged)"
           if len(nd_only) else ""), "computed here")
    # panel D
    by = s[s.test == "D_ins_by_age"]
    yo = by[by.stratum.isin(["K2P (0.002,0.005]", "K2P (0.005,0.01]", "K2P (0.01,0.02]"])]
    ol = by[by.stratum.isin(["K2P (0.05,0.1]", "K2P >0.1"])]
    add("D_ins young strata (K2P <= 0.02)", f"{yo.D.min():.2f}-{yo.D.max():.2f} ({int(yo.nA.sum())} vs "
        f"{int(yo.nB.sum())})", ST)
    add("D_ins old strata (K2P > 0.05)", f"{ol.D.min():.2f}-{ol.D.max():.2f} ({int(ol.nA.sum())} vs "
        f"{int(ol.nB.sum())})", ST)
    add("shared insertions S+M (not P) / P+M (not S)", f"{len(A)} / {len(B)}",
        f"{CIT}/orthologs.*.tsv.gz (rebuilt as ltrmix; = stats.tsv D_ins nA/nB)")
    cs = pd.concat([d["ctrl_stats"][t][d["ctrl_stats"][t].test == "D_ins_by_age"] for t in CONTROLS])
    add("controls D_ins by age, max |D| / max |Z|", f"{cs.D.abs().max():.2f} / {cs.Z.abs().max():.1f}",
        f"{CIT}/Cr_Cm_CaM/stats.tsv, {CIT}/Cr_Cm_CaP/stats.tsv")
    # panel E
    ch = z["chrom"]
    for R, S, trio in ZEA:
        w = z["wg"][(z["wg"].R == R) & (z["wg"].S == S)].iloc[0]
        lb = z[f"lib_{R}_{S}"]
        add(f"Zea {R} vs {S} whole-assembly D (Z)", f"{fmt_d(w.D_kmer)} ({w.Z:.1f})", f"{GEN}/wgk/wgk_trio.tsv")
        add(f"Zea {R} vs {S} EDTA library D (Z)", f"{fmt_d(lb.D)} ({lb.Z:.1f})", f"{GEN}/out/{trio}/stats.tsv")
        cw = ch[(ch.R == R) & (ch.S == S) & (ch.src == "whole")]
        cl = ch[(ch.R == R) & (ch.S == S) & (ch.src == "library")]
        add(f"Zea {R} vs {S} per-chromosome D whole", f"{fmt_d(cw.D.min(), 2)} to {fmt_d(cw.D.max(), 2)}",
            f"{GEN}/wgk/wgk_trio.{R}_{S}_Zn.tsv (computed here, 5-Mb jackknife as wg_kmer_trio.py)")
        add(f"Zea {R} vs {S} per-chromosome D library", f"{fmt_d(cl.D.min(), 2)} to {fmt_d(cl.D.max(), 2)}",
            f"{GEN}/out/{trio}/stats.tsv D_kmer_by_chrom")
        rs = z[f"res_{R}_{S}"]
        add(f"Zea {R} vs {S} Zn elements in synteny with R / S / both",
            f"{float(rs.resolved_R):.2f} / {float(rs.resolved_S):.2f} / {float(rs.resolved_both):.2f}",
            f"{GEN}/out/{trio}/stats.tsv")
    w = z["wg"][(z["wg"].R == "Zh") & (z["wg"].S == "TIL01")].iloc[0]
    add("Zea Zh vs TIL01 whole-assembly D (Z)", f"{fmt_d(w.D_kmer)} ({w.Z:.1f})", f"{GEN}/wgk/wgk_trio.tsv")
    # panel F
    fr = info["F"]
    for _, r in fr.iterrows():
        add(f"F {r.lab.replace(chr(8592), '<-')} D_kmer (Z)", f"{fmt_d(r.D)} ({r.Z:.1f})", r.src)
        if np.isfinite(r.wD):
            add(f"F {r.lab.replace(chr(8592), '<-')} whole-assembly D (Z)", f"{fmt_d(r.wD)} ({r.wD / r.wSE:.1f})",
                r.src)
    ta = d["trios"].loc["CsA_Cr_Cm"]
    zs = [ta.D_kmer_Z, ta.D_ins_Z, ta.D3_triples_Z, ta.D_self_outgroup_Z]
    add("CsA max |Z| of the four tests", f"{max(abs(x) for x in zs):.1f}", T)
    ua = eu[(eu.trio == "CsA_Cr_Cm") & (eu["mode"] == "recent") & (eu.set == "all") & (eu.chrom == "CsA_chr2")]
    add("CsA chr2 published P tract covered (recent)", f"{ua.covered.iloc[0] * 100:.0f}% of {ua.Mb.iloc[0]:.1f} Mb",
        TU)
    ra = et[(et.trio == "CsA_Cr_Cm") & (et["mode"] == "recent") & (et.set == "all")].iloc[0]
    add("CsA recent tracts, precision / recall", f"{int(ra.n_called)}, {ra.bp_precision:.2f} / {ra.bp_recall:.2f}",
        TT)
    tl_a = float((d["truthA"].e - d["truthA"].s).sum())
    add("CsA published P tracts", f"{tl_a / 1e6:.1f} Mb = {100 * tl_a / float(fai('CsA').sum()):.1f}%",
        f"{L2}/truth/CsA.P.bed (computed here)")
    for t in CONTROLS:
        x = d["trios"].loc[t]
        zz = [x.D_kmer_Z, x.D_ins_Z, x.D3_triples_Z, x.D_self_outgroup_Z]
        add(f"control {t} max |Z|; tracts vs decoys (recent; ancestry)",
            f"{max(abs(y) for y in zz):.1f}; {int(x.recent_tracts)} vs {int(x.recent_decoys)}; "
            f"{int(x.ancestry_tracts)} vs {int(x.ancestry_decoys)}", T)
    rt = sum(int(d["trios"].loc[t].recent_tracts) for t in CONTROLS)
    rd_ = sum(int(d["trios"].loc[t].recent_decoys) for t in CONTROLS)
    add("control tracts vs decoys, both controls (recent)", f"{rt} vs {rd_}", T)
    add("maize whole-assembly D (computed)", f"{fmt_d(m['wg'][0])} ± {m['wg'][1]:.3f} (Z {m['wg'][0] / m['wg'][1]:.1f})",
        f"{BENCH}/wgk/wgk_all.TIL18.tsv (5-Mb jackknife; REPORT +0.107, Z 8.9)")
    return rows, v


def decoy_map(d):
    """Each decoy tract on P mapped to S through P's 1:1 orthologs in S; flags overlap with published M segments."""
    oc = read_orth(S_, R_)
    oc = oc[oc[R_] != "."].copy()
    pc = oc[R_].map(parse_id)
    oc["r_chrom"] = [p[0] for p in pc]
    oc["r_mid"] = [(p[1] + p[2]) / 2 for p in pc]
    rows = []
    for _, t in d["decoys"].iterrows():
        y = oc[(oc.chrom == t.chrom) & (oc.end >= t.start0 - 300_000) & (oc.start <= t.end + 300_000)]
        rc_ = y.r_chrom.value_counts().index[0]
        yy = y[y.r_chrom == rc_]
        lo, hi = yy.r_mid.min(), yy.r_mid.max()
        tt = d["truth"][(d["truth"].chrom == rc_) & (d["truth"].s < hi) & (d["truth"].e > lo)]
        rows.append(dict(chrom=t.chrom, start0=t.start0, end=t.end, r_chrom=rc_, r_lo=lo, r_hi=hi, truth=len(tt) > 0))
    return pd.DataFrame(rows)


def md_runs(text):
    out, pos = [], 0
    for mm in re.finditer(r"\*\*(.+?)\*\*|\*(.+?)\*", text):
        if mm.start() > pos:
            out.append((text[pos:mm.start()], "n"))
        out.append((mm.group(1), "b") if mm.group(1) is not None else (mm.group(2), "i"))
        pos = mm.end()
    if pos < len(text):
        out.append((text[pos:], "n"))
    return out


def legend_page(paras, fs=10.0):
    """A page as wide as the figure, height fitted to the text; ragged right, mixed italic/bold runs."""
    from matplotlib.font_manager import FontProperties
    props = {st: FontProperties(family="Liberation Sans", size=fs, style="italic" if st == "i" else "normal",
                                weight="bold" if st == "b" else "normal") for st in "nib"}
    MDPI = 2400
    tmp = plt.figure(figsize=(W / 25.4, 2), dpi=MDPI)
    rend = tmp.canvas.get_renderer()
    cache = {}

    def wmm(t, st):
        if (t, st) not in cache:
            w_, _, _ = rend.get_text_width_height_descent(t, props[st], ismath=False)
            cache[(t, st)] = w_ * 25.4 / MDPI
        return cache[(t, st)]

    space = wmm("a a", "n") - wmm("aa", "n")
    margin, width = 3.0, W - 6.0
    lh, gap = fs * 1.32 * 25.4 / 72, fs * 0.55 * 25.4 / 72
    laid = []
    for para in paras:
        words, cur = [], []
        for t, st in md_runs(para):
            for tok in re.split(r"(\s+)", t):
                if not tok:
                    continue
                if tok.isspace():
                    if cur:
                        words.append(cur)
                        cur = []
                else:
                    cur.append((tok, st))
        if cur:
            words.append(cur)
        lines, line, x = [], [], 0.0
        for wd in words:
            ww = sum(wmm(t, st) for t, st in wd)
            if line and x + space + ww > width:
                lines.append(line)
                line, x = [], 0.0
            if line:
                x += space
            xx = x
            for t, st in wd:
                line.append((xx, t, st))
                xx += wmm(t, st)
            x += ww
        if line:
            lines.append(line)
        laid.append(lines)
    plt.close(tmp)
    hh = 2 * margin + sum(len(L_) for L_ in laid) * lh + (len(laid) - 1) * gap + 1.0
    fig = plt.figure(figsize=(W / 25.4, hh / 25.4))
    y = margin + lh * 0.8
    for lines in laid:
        for line in lines:
            for xx, t, st in line:
                fig.text((margin + xx) / W, 1 - y / hh, t, fontproperties=props[st], va="baseline", ha="left")
            y += lh
        y += gap
    return fig


def rng(x):
    """'0.86-1.00' -> '0.86–1.00'; '+0.07 to +0.23' kept; hyphen-minus before digits -> minus sign."""
    import re as _re
    x = _re.sub(r"(?<=\d)-(?=\d)", "–", x)
    return _re.sub(r"(?<![\w.])-(?=\d)", "−", x)


def coords(c):
    """'Cr_chr1:21763985-21774761' -> 'chr1:21,763,985–21,774,761'."""
    ch, ab = c.split(":")
    a, b = ab.replace(",", "").split("-")
    return f"{ch.split('_')[1]}:{int(a):,}–{int(b):,}"


def legends(v):
    pm = v["_pm_iqr"]
    sh = v["shared insertions S+M (not P) / P+M (not S)"].split(" / ")
    yo, yon = v["D_ins young strata (K2P <= 0.02)"].split(" (")
    ol, oln = v["D_ins old strata (K2P > 0.05)"].split(" (")
    ctl = v["controls D_ins by age, max |D| / max |Z|"].split(" / ")
    lk = v["panel B near-identical links to P / to M"].split(" / ")
    fp = v["chosen boundary flank posteriors in/out"]
    mp = v["median flank posteriors in/out (all internal boundaries)"]
    win = v["panel B window"].split(":")[1].split("-")
    pc = v["panel C candidates"]
    fam = v["panel C length / family n / length percentile"].split(" / ")
    tl = v["higher-ranked candidates failing: TSD / empty site / ends / colinearity / family-domain-K2P"]
    tln = tl.split(" (")[0].split(" / ")
    nhi = tl.split("(of ")[1].split(";")[0]
    ndo = v["candidates failing only near-identity"]
    site = v["panel C P empty site"]
    rs = lambda k: v[k].split(" / ")
    gaps = v["panel B uncovered ends of the published tract (Mb)"].split(" and ")
    gmax = float(np.ceil(max(float(x) for x in gaps) * 10) / 10)
    nel, ninf = v["panel B elements in the uncovered ends (informative)"].rstrip(")").split(" (")
    pS_ = rng(v["panel B near-identical P links: S positions (Mb)"])
    pD_ = rng(v["panel B near-identical M links: S positions (Mb)"])
    chosen_c = v["panel B boundary"].split(":")[0].split("_")[1]
    groups = {}
    for n, c, _ in v["_picks"]:
        groups.setdefault(c, []).append(n)

    def nr(ns):
        return f"{ns[0]}" if len(ns) == 1 else f"{ns[0]}–{ns[-1]}"
    pick_txt = "; ".join(("single-element flanks pick " if ns == [1] else f"flanks of {nr(ns)} elements pick ")
                         + ("this tract" if c == chosen_c else f"the chromosome {c.replace('chr', '')} boundary")
                         for c, ns in sorted(groups.items(), key=lambda kv: -kv[1][-1]))
    outmb, share = v["called Mb outside published segments; share in the first 5 Mb of chr5 and chr9"].split("; ")
    tfrac = float(v["published M tracts in S"].split("= ")[1].rstrip("%")) / 100
    segs = sorted({c.split("_")[1].replace("chr", "") for c in v["_called_truth_chroms"]}, key=int)
    seg_chr = segs[0] if len(segs) == 1 else ", ".join(segs[:-1]) + " and " + segs[-1]
    cs2 = v["CsA chr2 published P tract covered (recent)"].split(" of ")
    short = [
        "**Fig. 5 | Transposon insertions mark gene flow in a wild grass exchange and in sweet orange.** "
        "Insertions that a genome shares nearly unchanged with one relative, but not with its own sister lineage, "
        "mark DNA received by gene flow; where admixture is a few generations old, they paint the introgressed "
        "chromosome segments.",
        "**A**, Sweet orange's pummelo-derived haplotype (S) between pummelo (P) and mandarin (M). Elements with "
        f"near-identical mandarin copies cluster on the published mandarin segments of chromosomes {seg_chr}, "
        "where the transposon painting calls tracts; the same painting of pure pummelo finds few.",
        "**B**, Across one introgressed segment, sweet-orange elements share near-identical copies with pummelo "
        f"outside and with mandarin inside; the switch falls within {gmax:.1f} Mb of the published boundaries.",
        "**C**, One such insertion is identical in sweet orange and mandarin over its whole length and sits in the "
        "same target-site duplication, while pummelo holds the empty site with a single copy: one insertion event, "
        "inherited through mandarin DNA.",
        "**D**, Insertions younger than the pummelo–mandarin divergence are shared almost only with mandarin, older "
        "ones much less, and unmixed sour-orange haplotypes show no excess at any age: the young shared insertions "
        "can only have arrived with mandarin DNA.",
        "**E**, In wild *Zea*, huehuetenangensis and parviglumis share more DNA with *Z. nicaraguensis* than "
        "mexicana does on every chromosome, read from whole assemblies or from transposons annotated by another "
        "program; two mexicana genomes do not differ.",
        "**F**, All three admixture events are detected from transposons alone, and every control stays near zero.",
    ]
    long = [
        "**Fig. 5 | Transposon insertions mark gene flow in a wild grass exchange and in sweet orange.** "
        "Genomes: S, sweet orange haplotype B (Valencia DVS_B, CsB; *Citrus sinensis*), pummelo-derived; P, pummelo "
        "Guanximiyou (Cm; *C. maxima*); M, mandarin Sun Chu Sha Kat haplotype 1 (Cr; *C. reticulata*); CsA, sweet "
        "orange's mandarin-derived haplotype; CaM and CaP, the two haplotypes of sour orange (*C. aurantium*), an F1 "
        "of unmixed parents. Truth: S's mandarin segments from SNPs (Wu B. et al. 2023, *Hortic Res*, Suppl. Table "
        f"4): {v['published M tracts in S'].replace(' tracts', ' segments')}. Elements: intact LTR retrotransposons "
        "annotated in each genome separately; orthologs from flanking synteny. Near-identical: closer than the 5th "
        f"percentile of P–M ortholog divergence ({v['near-identity threshold (K2P)']} substitutions per site). "
        "D = (nA − nB)/(nA + nB), with A and B the patterns joining the donor to the first genome or to its sister; "
        "± 2 SE by block jackknife (3-Mb blocks in citrus, 5-Mb in *Zea* and maize). Posterior: M-like state of the "
        "recent-sharing hidden Markov model; tract: a run with posterior > 0.5; decoy: the fitted model applied to "
        "the sister genome.",
        "**A**, S's nine chromosomes (white) at one bp scale between their P (left) and M (right) homologs (P "
        f"chromosomes {v['P homologs of S chr1-9'].replace('*', '')}; ▲, drawn inverted). Gray lines: "
        f"{v['S-P ortholog pairs drawn']} S–P and {v['S-M ortholog pairs drawn']} S–M 1:1 orthologs. Ticks: every "
        f"informative S element, near-identical to the M copy ({v['S elements near_donor']}) or shared with M only "
        f"({v['S elements donor_only']}), right; near-identical to the P copy ({v['S elements near_sister']}) or "
        f"shared with P only ({v['S elements sister_only']}), left (of {v['S elements total']}). Inside S, the "
        "posterior; beside it, published M segments (green) and LTR-RT tracts (black); beside P, decoy tracts. "
        f"Posterior {v['CsB posterior inside published tracts (recent)']} inside published segments, "
        f"{v['CsB posterior outside published tracts (recent)']} outside (element AUROC "
        f"{v['CsB element AUROC (recent)']}). The {v['CsB recent tracts']} tracts span {v['CsB called Mb (recent)']} "
        f"Mb (base-pair precision {v['CsB bp precision (recent)']}, recall {v['CsB bp recall (recent)']}): every "
        f"published segment ≥ 1.7 Mb is called ({rng(v['coverage of published tracts >= 1.7 Mb'])} covered), the "
        f"three ≤ 1.1 Mb ({rng(v['published tracts <= 1.1 Mb missed'].split('; ')[1])}) are missed; {share} of the "
        f"{outmb} Mb called outside the truth lies in the first 5 Mb of chromosomes 5 and 9. The decoy painting calls "
        f"{v['CsB recent decoy tracts']} tracts on P, "
        f"{v['decoy tracts opposite published M segments of S'].split(' of ')[0]} of them opposite S's mandarin "
        "segments (chromosomes 1, 2), where S is no pummelo sister to P. Posterior excess over the decoy "
        f"{v['posterior excess over decoy (recent)']} (truth {tfrac:.3f}); "
        f"{v['identity spectrum S-M vs P-M orthologs < 0.2%'].split(' vs ')[0]} S–M but "
        f"{v['identity spectrum S-M vs P-M orthologs < 0.2%'].split(' vs ')[1]} P–M ortholog pairs differ by < 0.2%.",
        f"**B**, S chromosome 9, {int(win[0].replace(',', '')) / 1e6:.2f}–{int(win[1].replace(',', '')) / 1e6:.2f} "
        "Mb, and the homologous P and M windows of equal length (M inverted): every element to size (rows where "
        "overlapping), S colored as in A, partners gray (dark if orthologous to an S element in view); lines join "
        f"orthologs, colored if near-identical: {lk[0]} to P (S elements at {pS_} Mb) and {lk[1]} to M ({pD_} Mb), "
        f"inside the published segment ({rng(v['panel B published tract'])}). The tract "
        f"({rng(v['panel B called tract'])}) covers {v['panel B published tract covered']} of it; the {gaps[0]} and "
        f"{gaps[1]} Mb left uncovered hold {nel} elements, {'none' if ninf == '0' else ninf} with informative "
        "orthologs, so element spacing limits resolution. Choice: among the "
        f"{v['internal tract boundaries'].split(' ')[0]} internal boundaries of the {v['CsB recent tracts']} tracts, "
        "those of the 5 tracts that overlap published segments (no unverified call as the example); the one whose "
        f"flank posteriors (10 nearest elements per side: {fp}) lie closest in percentile to the median of all "
        f"({mp}); {pick_txt}.",
        f"**C**, S {coords(v['panel C element'].split(' ')[0])} (Gypsy/Retand), inside the chromosome 1 mandarin "
        f"segment, and its M copy ({coords(v['panel C M copy'])}) to scale (LTRs dark; "
        f"{v['panel C domains'].replace('-', ', ')} darker); the band between them would mark every difference: "
        f"none in {v['panel C copy differences'].split(' in ')[1].replace(' aligned bp', '')} bp. Junctions: both "
        f"copies sit in the same target-site duplication (TSD, {v['panel C TSD'].split(' ')[0]}); at the syntenic P "
        f"site ({coords(site.split(' ')[0])}) the flanks join with one TSD copy "
        f"({site.split(', ')[1].replace('edits', 'differences')}, gray). LTR–LTR K2P "
        f"{float(v['panel C self-LTR K2P realigned / annotated'].split(' / ')[0]):.3f}, as annotated. Choice: of "
        f"{pc.split(' ')[0]} S elements inside published segments, near-identical to or shared only with M and "
        "absent from P, ranked by closeness to the medians of K2P "
        f"({float(pc.split('median K2P ')[1].split(',')[0]):.3f}) and length "
        f"({float(pc.split('median length ')[1].split(' bp')[0].replace(',', '')) / 1e3:.1f} kb), the first (rank "
        f"{v['panel C rank of chosen element']}) to pass every check: 5-bp TSD identical at both ends of both "
        "copies, called by the annotator, not a mononucleotide run; TG…CA ends; copies colinear (no indel > 50 bp) "
        f"and near-identical, as the panel shows; family-typical length ({fam[2]} percentile of {fam[1]} copies); "
        "canonical domain order; self-LTR K2P within 2 SE; an empty P site with one TSD copy. Of the "
        f"{nhi} ranked higher, {tln[0]} failed the TSD checks, {tln[1]} the empty site and {tln[2]} the TG…CA "
        f"ends (some several); one failed only near-identity (copies "
        f"{ndo.split(', copies ')[1].split(' ')[0]} diverged).",
        f"**D**, Every insertion shared by S and M but absent from P ({sh[0]}, vermillion) or by P and M but absent "
        f"from S ({sh[1]}, blue), placed by the LTR–LTR K2P of the M copy (log axis; identical LTRs at 0), with "
        f"counts per stratum. Below, D per stratum with ≥ 10 insertions: {rng(yo)} for K2P ≤ 0.02 "
        f"({yon.rstrip(')')}) and {rng(ol)} above 0.05 ({oln.rstrip(')')}). Open gray: sour-orange controls "
        "(squares, CaM vs M, donor P; diamonds, P vs CaP, donor M; their donor copy's K2P), "
        f"|D| ≤ {ctl[0]} and |Z| ≤ {ctl[1]} at every age. Gray band: interquartile range of P–M ortholog "
        f"divergence ({pm[0]:.3f}–{pm[1]:.3f}); younger insertions postdate most P–M coalescence and can reach S "
        "only with mandarin DNA; older ones include insertions sorted into the mandarin lineage before the split. "
        "No citrus substitution rate is assumed.",
        "**E**, The *Z. mays*–Luxuriantes exchange of Chen et al. 2022 (*Nat Genet* 54:1736): D per chromosome for "
        "huehuetenangensis Zh-RIMHU001, parviglumis TIL01 and, as control, mexicana TIL25, each against mexicana "
        "TIL18, with *Z. nicaraguensis* Zn-PI615697 as donor (standing in for the Luxuriantes; *Z. luxurians* "
        "lacks EDTA calls). Diamonds: single-copy 21-mers of whole assemblies on Zn's windows (per chromosome from "
        "the per-window tallies, which reproduce the genome-wide values exactly); circles: the same statistic on "
        "published EDTA intact LTR-RT libraries; lines join a chromosome's whole-assembly values. Genome-wide, "
        f"whole / LTR-RTs (Z): Zh {rng(v['Zea Zh vs TIL18 whole-assembly D (Z)'])} / "
        f"{rng(v['Zea Zh vs TIL18 EDTA library D (Z)'])}; TIL01 {rng(v['Zea TIL01 vs TIL18 whole-assembly D (Z)'])} / "
        f"{rng(v['Zea TIL01 vs TIL18 EDTA library D (Z)'])}; TIL25 {rng(v['Zea TIL25 vs TIL18 whole-assembly D (Z)'])} "
        f"/ {rng(v['Zea TIL25 vs TIL18 EDTA library D (Z)'])}. Per chromosome (whole): Zh "
        f"{v['Zea Zh vs TIL18 per-chromosome D whole']}, TIL01 {v['Zea TIL01 vs TIL18 per-chromosome D whole']}, "
        f"TIL25 {v['Zea TIL25 vs TIL18 per-chromosome D whole']}. Only k-mer tests are used: insertion tests need "
        "synteny with the donor, which covers only "
        f"{rs('Zea TIL25 vs TIL18 Zn elements in synteny with R / S / both')[0]}–"
        f"{rs('Zea Zh vs TIL18 Zn elements in synteny with R / S / both')[1]} of Zn's elements in mexicana.",
        "**F**, Genome-wide D ± 2 SE from single-copy k-mers: the first genome's excess sharing with the donor "
        "(after ←) over its sister; filled circles, LTRquest libraries; open circles, EDTA libraries; diamonds, "
        f"whole assemblies; Z in parentheses. Maize B73 vs parviglumis TIL01, donor mexicana TIL18: {rng(v['F B73 vs TIL01 D_kmer (Z)'])}; "
        f"whole {rng(v['F B73 vs TIL01 whole-assembly D (Z)'])} (Figs 1–2). CsB (= S) "
        f"{rng(v['F CsB vs Cm <- Cr D_kmer (Z)'])}, with insertions {v['CsB D_ins']} ({v['CsB D_ins Z']}) and "
        f"self-outgroup LTR sites {v['CsB D_self']} ({v['CsB D_self Z']}). CsA "
        f"({v['CsA published P tracts'].split(' = ')[1]} pummelo) {rng(v['F CsA vs Cr <- Cm D_kmer (Z)'])}, every "
        f"test |Z| ≤ {v['CsA max |Z| of the four tests']}, below genome-wide power, yet its "
        f"{cs2[1].replace(' Mb', '')}-Mb chromosome 2 pummelo segment is called ({cs2[0]} covered). "
        f"Sour-orange controls {rng(v['F CaM vs Cr <- Cm D_kmer (Z)'])} and "
        f"{rng(v['F Cm vs CaP <- Cr D_kmer (Z)'])}: |Z| ≤ 2.0 in every test, and no more tracts than decoys "
        f"({v['control tracts vs decoys, both controls (recent)']}).",
        "Limits: no citrus tract reaches q ≤ 0.05, as 15 tracts against 4 decoys cannot pass the +1 target-decoy "
        f"rule (lowest q {v['lowest tract q']}); the posteriors carry the information. The citrus truth is "
        "SNP-based and the two published truth sets disagree on phasing in places (chromosome 9 among them), so "
        "calls outside it are unverified rather than wrong. One genome per taxon.",
        f"Analysis: asc-oulab:/data2/chris/maize_introgression/benchmark · Script: {SCRIPT} · {DATE}",
    ]
    return short, long


PANEL_Y = dict(A=0.0, B=95.5, C=143.0, D=174.5)
PANEL_X = dict(D=0.0, E=58.5, F=118.0)


def draw_figure(d, z, m, sel, A, B):
    fig = plt.figure(figsize=(W / 25.4, H / 25.4))
    info = {}
    letter(fig, "A", 0.0, 0.2)
    info["A"] = panel_A(fig, d, sel)
    letter(fig, "B", 0.0, PANEL_Y["B"] + 0.2)
    info["B"] = panel_B(fig, d, sel, PANEL_Y["B"])
    letter(fig, "C", 0.0, PANEL_Y["C"] + 0.2)
    info["C"] = panel_C(fig, d, sel, PANEL_Y["C"])
    for k in "DEF":
        letter(fig, k, PANEL_X[k], PANEL_Y["D"] + 0.2)
    info["D"] = panel_D(fig, d, A, B, PANEL_X["D"], PANEL_Y["D"])
    info["E"] = panel_E(fig, z, PANEL_X["E"], PANEL_Y["D"])
    info["F"] = panel_F(fig, d, z, m, PANEL_X["F"], PANEL_Y["D"])
    return fig, info


def main():
    global VERBOSE
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-v", "--verbose", action="store_true", help="report per-step progress and checks")
    ap.add_argument("--rebuild", action="store_true", help="clear ./work caches (*.pkl, aln/) and recompute")
    ap.add_argument("--figure-only", action="store_true", help="write only the PNG (layout iterations)")
    a = ap.parse_args()
    VERBOSE = a.verbose
    if a.rebuild:
        for p in glob.glob(f"{WORK}/*.pkl") + glob.glob(f"{WORK}/aln/*"):
            os.remove(p)
    setup_style()
    log("loading citrus, wild Zea and maize results")
    d = load_citrus()
    z = load_zea()
    m = load_maize()
    sel = selections(d)
    A, B = cached("shared_CsB", lambda: shared_insertions(R_, S_, D_))
    fig, info = draw_figure(d, z, m, sel, A, B)
    fig.savefig(f"{HERE}/{STEM}.png", dpi=300)
    log(f"wrote {STEM}.png")
    if a.figure_only:
        return
    rows, v = collect_numbers(d, z, m, sel, A, B, info)
    with open(f"{HERE}/{STEM}_numbers.tsv", "w") as fo:
        fo.write("quantity\tvalue\tsource\n")
        for k, val, src in rows:
            fo.write(f"{k}\t{val}\t{src}\n")
    short, long = legends(v)
    with PdfPages(f"{HERE}/{STEM}.pdf") as pdf:
        pdf.savefig(fig)
        for paras in (short, long):
            f2 = legend_page(paras)
            pdf.savefig(f2)
            plt.close(f2)
    sel["screen"].to_csv(f"{WORK}/example_screen.tsv", sep="\t", index=False)
    log(f"wrote {STEM}.pdf and {STEM}_numbers.tsv ({len(rows)} numbers)")


if __name__ == "__main__":
    main()
