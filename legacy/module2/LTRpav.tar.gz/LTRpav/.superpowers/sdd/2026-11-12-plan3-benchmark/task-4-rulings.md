# Task 4: controller rulings (Task 3 approved at 7f5cedb)

These bind as much as task-4-brief.md, and override it where the two conflict.

## R1. No `site_lost` fate (Task 3 R1)
- Task 2 discards every event whose sequence is absent on a carrier's lineage. So a sample that inherited e always
  holds a copy of e, with some fate.
- For a sample that did not inherit e and whose empty-site window is broken: fate `"absent"`, `site = -1`, truth
  `D`.
- The brief's "`D` otherwise, `site_lost` included" reads "`D` otherwise".
- `test_truth_D_site_deleted` covers this case.

## R2. Conventions read from Tasks 2 and 3, never re-derived
- **Target bases** are `[pos - TSD_DEFAULT, pos)` of the host's system (popevents module docstring). The `O`
  target-overlap rule compares two insertions on the same chrom and the same host system: the insertions overlap when
  their target-base intervals overlap.
- **Copy records.** `inherited`, `site`, `fate` and the image coordinates come from Task 3's Copy records. Truth never
  recomputes what the builder decided.
- **Named simplifications** (popevents docstring rule 4): replacing sequence and simulated solo LTRs receive no
  insertions. Truth needs no rule for them.
- **Nested elements in a solo'd host's surviving LTR** keep their own copies (Task 2 C4a). Their truth follows the
  ordinary rules.

## R3. pair.py stays byte-identical
- `pair.py` is a sim module, not an engine module. Even so, `ltrpav-sim pair` must stay byte-identical on its tests,
  with the RNG draws in the same order.
- `test_pair_annotation_unchanged` compares against the outputs at BASE, not against a re-run of the new code.

## R4. Score join
- `test_score_joins` runs `ltrpav-sim score` from the repo's current tree.
- Plan 1's scorer reads `TRUTH_COLUMNS`. Add no column it does not know. Put extra information (`origin`,
  `events_x`, `events_y`) only in columns the scorer already has.
- Name any column that has to change.

## R5. Task 3's records, as built (Task 3 report; ledger "Task 3: Ruling")
- **Copy fields.**
  - `Copy` also carries `strand`, `family` and `superfamily`, with defaults. `annotate` reads them from the
    PopGenome alone.
  - `Copy.site` is the first target base, in genome order. It is set only for absent copies whose window is intact,
    and is -1 otherwise. -1 reads as D (R1).
  - A replaced copy's image is its replacing bases.
  - `Copy.tsd` is in genome orientation.
- **The lift map.** `PopGenome.lift` arrays also hold deleted pieces and an end entry (L, genome length). Map positions
  only through `popbuild.lift_pos`, never by reading the arrays.
- **Backbone elements** carry K2P = the source's K at the root plus 2*mu*T_root, accepted as intended. Annotations
  report `Copy.k2p` as is.
- **Nested site windows** are clipped to the host body.
