import math
from types import SimpleNamespace

import numpy as np
import pytest
from scipy.stats import chi2

from ltrpav.analysis.stats import (
    PART,
    STATS_COLUMNS,
    Findings,
    StatRow,
    block_ids,
    block_size,
    d_ratio,
    jackknife,
    read_stats,
    resolution,
    u95,
    write_stats,
)


def test_jackknife_matches_leave_one_out():
    rng = np.random.default_rng(0)
    a = rng.integers(0, 2, 200); b = 1 - a; blocks = rng.integers(0, 20, 200)
    jk = jackknife(d_ratio(a, b), blocks)
    loo = np.array([(a[blocks != x].sum() - b[blocks != x].sum()) / (blocks != x).sum() for x in range(20)])
    assert jk.est == pytest.approx((a.sum() - b.sum()) / 200) and jk.nblocks == 20
    assert jk.se == pytest.approx(math.sqrt(19 / 20 * ((loo - loo.mean()) ** 2).sum()))


def test_jackknife_two_blocks_has_no_se():
    jk = jackknife(d_ratio(np.array([1, 1, 0]), np.array([0, 0, 1])), np.array([0, 0, 1]))
    assert jk.est == pytest.approx(1 / 3) and jk.nblocks == 2 and math.isnan(jk.se) and math.isnan(jk.z)


def test_block_size():
    lens = lambda *t: SimpleNamespace(lengths={f"g{i}": np.array(x) for i, x in enumerate(t)})
    assert block_size(lens([600_000, 400_000], [2_000_000])) == 10_000
    assert block_size(lens([2_100_000_000])) == 5_000_000 and block_size(lens([300_000_000])) == 3_000_000
    assert block_size(lens([500_000])) == 10_000


def test_block_ids_split_by_seqid_and_size():
    ids = block_ids(np.array([0, 1, 0, 0, 0, 0]), np.array([5e3, 5e3, 19_999.5, 20_000.5, 21e3, 29e3]), 10_000)
    assert ids[0] != ids[1] and ids[2] != ids[3] and ids[3] == ids[4] == ids[5]


def test_u95():
    assert u95(np.array([0]), np.array([1000]))[0] == pytest.approx(0.0029957, rel=1e-4)
    assert u95(np.array([2]), np.array([500]))[0] == pytest.approx(chi2.ppf(0.95, 6) / 2 / 500)


def test_resolution_rows_and_warning():
    f = Findings()
    rows = resolution("resolution", "R,S;D", {"R": 0.85, "S": 0.40}, 1000, "disc=D", f, "Trio tests")
    assert [(r.statistic, r.value, r.n, r.loci) for r in rows] == [("resolved_R", 0.85, 1000, "disc=D"),
                                                                ("resolved_S", 0.40, 1000, "disc=D")]
    assert len(f.items()) == 1 and f.items()[0][1].startswith("WARNING:") and "heuristic" in f.items()[0][1]
    g = Findings()
    resolution("resolution", "R,S;D", {"R": 0.85, "S": 0.80}, 1000, "disc=D", g, "Trio tests")
    assert g.items() == []


def test_stats_roundtrip(tmp_path):
    rows = [StatRow("pav", "D_pav", "R,S;D", "all", "D", 0.123456789, 0.01, 12.3456789, 400, "disc=D", "."),
            StatRow("pav", "tree", "all", "all", "newick", "(A,B);")]
    write_stats(rows, tmp_path / "s.tsv")
    lines = (tmp_path / "s.tsv").read_text().splitlines()
    assert lines[0].split("\t") == list(STATS_COLUMNS) and len(lines) == 3
    assert lines[1].split("\t")[5:9] == ["0.123457", "0.01", "12.3457", "400"]
    assert lines[2].split("\t")[5:9] == ["(A,B);", ".", ".", "."]
    back = read_stats(tmp_path / "s.tsv")
    assert back[0].value == pytest.approx(0.123457) and math.isnan(back[1].se) and back[1].value == "(A,B);"


def test_findings_order():
    f = Findings()
    f.add("Painting", "p1"); f.warn("Run", "w1"); f.add("Run", "r1")
    assert f.items() == [("Painting", "p1"), ("Run", "WARNING: w1"), ("Run", "r1")]


def test_jackknife_identical_pseudovalues_have_no_se():
    # three blocks of 3 a and 2 b: every pseudovalue is 0.2, whose float mean is 0.20000000000000004
    a = np.array([1, 1, 1, 0, 0] * 3)
    jk = jackknife(d_ratio(a, 1 - a), np.repeat([0, 1, 2], 5))
    assert jk.est == pytest.approx(0.2) and jk.se == 0.0 and math.isnan(jk.z) and jk.nblocks == 3


def test_sentinel_value_stays_text(tmp_path):
    """A sentinel row (test PART) keeps its value as text, though a stage key may look like a number."""
    rows = [StatRow("run", PART, "stats", "all", "key", "1234e5", n=3, loci="none"),
            StatRow("run", "other", "stats", "all", "key", "1234e5")]
    write_stats(rows, tmp_path / "s.tsv")
    back = read_stats(tmp_path / "s.tsv")
    assert back[0].value == "1234e5" and back[0].n == 3 and back[1].value == 1.234e8


def test_jackknife_nan_estimate_short_circuits():
    """A nan estimate returns nan se and z at once, with no pseudovalue computed."""
    calls = []

    def stat(keep):
        calls.append(int(keep.sum()))
        return math.nan
    jk = jackknife(stat, np.repeat([0, 1, 2, 3], 2))
    assert math.isnan(jk.est) and math.isnan(jk.se) and math.isnan(jk.z) and jk.nblocks == 4 and calls == [8]


def test_jackknife_fewer_than_two_finite_pseudovalues():
    """With three blocks but one finite pseudovalue, se and z are nan; the estimate stands."""
    def stat(keep):     # finite with every block, or with block 0 deleted; nan otherwise
        return 3.0 if keep.all() else 1.0 if not keep[0] else math.nan
    jk = jackknife(stat, np.array([0, 1, 2]))
    assert jk.est == 3.0 and math.isnan(jk.se) and math.isnan(jk.z) and jk.nblocks == 3


def test_jackknife_drops_non_finite_pseudovalues():
    """A non-finite pseudovalue is dropped, the se taken over the m finite ones with (m - 1) / m."""
    v = np.array([1.0, 2.0, 4.0, 8.0])

    def stat(keep):     # the sum over the kept blocks; inf when block 3 is deleted
        return float(v[keep].sum()) if keep[3] else math.inf
    jk = jackknife(stat, np.arange(4))
    p = np.array([14.0, 13.0, 11.0])                          # the three finite pseudovalues
    se = math.sqrt(2 / 3 * ((p - p.mean()) ** 2).sum())
    assert jk.est == 15.0 and jk.nblocks == 4 and jk.se == pytest.approx(se) and jk.z == pytest.approx(15.0 / se)


def test_u95_elementwise():
    """u95 with an array of trials is elementwise."""
    got = u95(np.array([0, 2, 5]), np.array([1000, 500, 250]))
    want = [chi2.ppf(0.95, 2 * (d + 1)) / 2 / n for d, n in ((0, 1000), (2, 500), (5, 250))]
    assert got.shape == (3,) and np.allclose(got, want)
