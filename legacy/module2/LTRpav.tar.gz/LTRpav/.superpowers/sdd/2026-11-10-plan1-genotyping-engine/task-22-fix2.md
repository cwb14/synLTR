# Task 22 — fix round 2 (FIX_BASE 5e51e2d)

The re-review confirmed fixes 1, 1b, 1c and 2-9 and the n_same_site addition. The site test for an X-specific
element e read in Y (no X-only ancestor, not G) is still off in two ways:
- the re-reviewer's probe_offsets.py: Y insertions whose target lies 5-9 bp beside e's target give O;
- probe_xdel.py: a structural deletion in X inside e's flank window gives O.

Your "offsets 0-4" figure in the fix-1 report used the test's insertion-point gap, not the target offset. Probes:
/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/review22/
(read-only; reuse their cases).

## Final site rule (controller ruling; replaces the fix-1 wording)
W = [Lf, e's TSD ids, Rf] as now: shareable ids of X, each once.
1. **O** when a Y-lineage element y has a target that overlaps e's target (`y.tsd_ids` ∩ `e.tsd_ids` non-empty)
   and still spans sequence in Y (alive or dead). This is the same integration site within the TSD-length
   ambiguity, and it is how n_same_site places its insertions.
2. **E** when Y holds W's ids in order, forward or reversed (reversed adds inv). Between consecutive W ids, Y may
   hold only:
   - point noise;
   - ids X lacks, meaning Y-specific insertions at other, non-overlapping sites, or ancestral bases that X later
     deleted. Both leave Y's pre-insertion site intact.
3. **D** otherwise: an id of W missing in Y, out of order, or separated by ids X holds outside W (a rearrangement).

## Fixes
1. Implement the rule in `truth.py`, and update the module docstring (`truth.py:14` still says "inside a flank
   included").
2. Replace `test_insertion_in_site_window` with a target-offset test: offsets -12..+12, with both e in Y and y in X.
   Expected: O at |offset| <= 4, E otherwise.
3. Add a test that an X-side structural deletion of 2 bp and of 24 bp inside e's left flank window, and of 2 bp
   inside its right flank window, gives E.
4. Keep the other engineered expectations green.

## After the fix
Rerun the seed-1 simulation (scratchpad/simcheck) and report:
- truth counts per direction;
- whether any row changed compared with the fix-1 run, and why.

Full suite under -W error and ruff must be clean. Commit with a plain subject, the existing identity and no
trailers. Append a "Fix round 2" section to task-22-report.md.
