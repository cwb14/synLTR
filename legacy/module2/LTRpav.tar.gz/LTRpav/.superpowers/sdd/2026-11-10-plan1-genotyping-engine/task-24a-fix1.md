# Task 24 phase A: fix round 1 (bake-off scripts; there is no repo change)

The file review (`task-24a-review.md`, in this directory) gives Spec ✅ and Quality "Changes needed": 1 Important
and 9 Minor findings. Every number produced so far checks out, and no completed run needs a rerun. Read the review
first. Its probes are in `D/review24a/`, where `D = /data2/chris/maize_introgression/benchmark_pav/bakeoff`.

**Start only after both batches have ended**, that is, once `D/runs/batch.exit` and `D/chr10/batch.exit` exist and
`pgrep -af 'run_variant.py|02_run_sims.py|04_chr10.sh'` prints nothing. The chr10 batch re-imports `bakeoff.py` for
every run, so an edit made while it runs changes the harness mid-batch.

## Fixes (controller rulings)
1. **I1.** A measured run must start from an empty rundir. In `bakeoff.py measure` (and `--skip-done`), a rundir
   that exists without `status.json` is removed before measuring. Removal is confined to the run's own directory:
   resolve it and refuse anything outside `runs/` or `chr10/runs/`. Apply the same rule wherever `04_chr10.sh`
   measures a run.
2. **M1.** The status is `timeout` only on exit 124, or on exit 137 when the wall time is at least the limit. Any
   other signal death is `killed`, and anything else nonzero is `failed`.
3. **M2.** Each driver deletes its own `batch.done` and `batch.exit` when it starts. Before a driver starts any
   run, it checks that no `run_variant.py` process exists, and refuses with a clear message if one does.
4. **M3.** `--sims` takes only known sim names (`choices`). Also add the `is_relative_to` guard before any `rmtree`.
5. **M5.** Correct PARAMS.md §10 (sampling every 2 s), §4 (lastz's `--ydrop` default under this scoring, Y = 40 as
   `--show=defaults` reports) and §9.5. For §9.5, state the review's figure: about 1.5-1.7x on the genotype stage
   under the 2,000-window default. Add that the controller has ruled for adaptive chunking in the engine, so the
   default that ships will be close to what the bake-off measured.
6. **M8.** Name the AnchorWave-anchors run `awpaf_yardstick` in `chr10/runs.tsv` and add a `role` column:
   `candidate` or `yardstick`. Rename only the table entry and the variant label; do not rerun it.
7. **M9.** Add an assert that the window's `b_seqid` is the MAF's B seqid. Key the PAF/segments cache on the script's
   own checksum as well as the MAF's. Do not rerun the read-out: its outputs are unchanged.
8. **M4, M7.** Note both in `memo_bakeoff.md` (no re-measure: the whole bake-off reruns after Task 24F):
   - the sims' `status.json` files carry no `progress` field (older `bakeoff.py`);
   - `R1_s1/flank-mm2_2k` was first measured by hand.

9. **Not fixed here:** M6 (memory sampling). The controller has ruled that phase B judges memory on
   max(max_rss_kb, peak_tree_pss_kb) from the chr10 runs and gives the sims' tree peaks no weight.

10. **CHUNK_WINDOWS patch.** Task 24F makes the engine choose its own chunk size (adaptive: max(8, min(2000,
    ceil(n_windows / 256)))). Remove the `--chunk-windows` patch from `run_variant.py` and the batch drivers, so the
    reruns measure the shipped default. Update PARAMS.md 9.5 to match.
11. **Concurrency.** Task 24F edits the repo while you work, and the `ltrpav_bench` env imports `ltrpav` from the
    working tree. No probe of yours may run `ltrpav`, `ltrpav-sim` or anything that imports `ltrpav`. Measure
    dummy commands (for example `sleep`, or a python one-liner) to test the harness.

## Checks
- `bash -n` on the shell scripts, and `python -m py_compile` on the Python scripts.
- One tiny probe per fix, where a probe is possible: a scratch rundir without `status.json` is removed, a fake
  SIGKILL is classified `killed`, a stale marker is cleared, and a bad `--sims` value is refused.

  Use `D/review24a/` or your own scratch directory. Do not touch any finished run's directory, except the one
  re-measure in item 8.

Append a "Fix round 1" section to `task-24a-report.md` listing each fix, its probe result and the re-measured run's
timing. Return ONLY the status, one line per fix, and concerns.
