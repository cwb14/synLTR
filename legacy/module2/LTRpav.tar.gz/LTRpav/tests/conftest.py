import os
import shutil

import pytest

# test modules import numpy before ltrpav, so set the package's THP guard here, before numpy loads
os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")

needs_lastz = pytest.mark.skipif(shutil.which("lastz") is None, reason="lastz (the window aligner) not on PATH")


@pytest.fixture(scope="session")
def toy_fastas(tmp_path_factory):
    """One directory of N-only FASTAs shared by the session: catalog_toy.write_run writes
    <dir>/<layout>/<label>.fa once per seqid layout and reuses it after."""
    return tmp_path_factory.mktemp("toy_fastas")
