#!/usr/bin/env python3
"""Compare LTRquest element ends with published structurally intact LTR-RTs on chr1-10.

A pair matches when BOTH ends agree within the tolerance. Overlap alone would be
uninformative, since LTR-RTs fill most of a maize genome. As a null, the same test is
rerun with LTRquest coordinates shifted by a fixed distance, which keeps element
lengths and density but breaks any real correspondence.
Usage: python3 -I 08_boundary_concordance.py --run run/ --annot LABEL=te.gff3.gz [...]
"""
import argparse
import bisect
import collections
import glob
import gzip
import re
import sys

CHROMS = {f"chr{i}" for i in range(1, 11)}
INTACT_TYPES = {"LTR_retrotransposon", "Gypsy_LTR_retrotransposon", "Copia_LTR_retrotransposon"}
ID = re.compile(r"^(.+):(\d+)-(\d+)#")


def read_annotation(path):
    """Structural intact elements per chromosome, as sorted (start, end) lists."""
    out = collections.defaultdict(list)
    with gzip.open(path, "rt") as fh:
        for line in fh:
            if line.startswith("#"):
                continue
            f = line.rstrip("\n").split("\t")
            if f[0] in CHROMS and f[2] in INTACT_TYPES and "Method=structural" in f[8]:
                out[f[0]].append((int(f[3]), int(f[4])))
    return {chrom: sorted(set(v)) for chrom, v in out.items()}


def read_calls(run_dir, label):
    out = collections.defaultdict(list)
    prefix = f"{label}_"
    paths = glob.glob(f"{run_dir}/{label}_LTRs_depth*_clean_ltr.tsv")
    if not paths:
        sys.exit(f"ERROR: no clean depth tables for {label} in {run_dir}")
    for path in paths:
        with open(path) as fh:
            next(fh)
            for line in fh:
                m = ID.match(line)
                if m and m[1].startswith(prefix) and m[1][len(prefix):] in CHROMS:
                    out[m[1][len(prefix):]].append((int(m[2]), int(m[3])))
    return {chrom: sorted(set(v)) for chrom, v in out.items()}


def n_matched(queries, targets, tol, shift=0):
    """Count queries having a target with both ends within tol."""
    hits = 0
    for chrom, items in queries.items():
        pool = targets.get(chrom, [])
        starts = [t[0] for t in pool]
        for start, end in items:
            s, e = start + shift, end + shift
            i = bisect.bisect_left(starts, s - tol)
            while i < len(pool) and pool[i][0] <= s + tol:
                if abs(pool[i][1] - e) <= tol:
                    hits += 1
                    break
                i += 1
    return hits


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--run", required=True, help="finished run directory")
    ap.add_argument("--annot", nargs="+", required=True, metavar="LABEL=GFF", help="genome label and TE GFF3.gz")
    ap.add_argument("--tol", type=int, nargs="+", default=[0, 10, 100], help="end tolerances in bp")
    ap.add_argument("--shift", type=int, default=50_000, help="coordinate shift for the null, bp")
    args = ap.parse_args()
    print("genome\ttol_bp\tltrquest\tpublished\tltrquest_matched\tfrac_ltrquest\tpublished_matched\tfrac_published\tnull_frac_ltrquest")
    for spec in args.annot:
        label, gff = spec.split("=", 1)
        pub, calls = read_annotation(gff), read_calls(args.run, label)
        n_pub, n_calls = sum(map(len, pub.values())), sum(map(len, calls.values()))
        if not n_pub:
            sys.exit(f"ERROR: no structural intact elements on chr1-10 in {gff}")
        for tol in args.tol:
            a = n_matched(calls, pub, tol)
            b = n_matched(pub, calls, tol)
            null = n_matched(calls, pub, tol, args.shift)
            print(f"{label}\t{tol}\t{n_calls}\t{n_pub}\t{a}\t{a / n_calls:.3f}\t{b}\t{b / n_pub:.3f}\t{null / n_calls:.5f}", flush=True)


if __name__ == "__main__":
    main()
