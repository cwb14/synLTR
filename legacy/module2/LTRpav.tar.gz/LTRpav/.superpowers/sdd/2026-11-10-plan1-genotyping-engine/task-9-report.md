# Task 9 report
Implemented src/ltrpav/blocks.py (BLOCK_DTYPE, BATCH_LINES, read_paf, a_to_b, swap_blocks, save_blocks, load_blocks) and tests/test_blocks.py (5 tests).
TDD: RED = ImportError (cannot import name 'blocks') on `pytest tests/test_blocks.py`; GREEN = full suite passes (47 tests), ruff clean.
Self-review: batches of BATCH_LINES rows as tuples then structured arrays; swap handled at parse time; one warning for skipped records. Concern: per-line Python parsing is slow-ish for 20M lines (acceptable; could use pandas/pyarrow later).
