# Task 24 phase B: controller rulings
These bind as much as `task-24-brief.md` Steps 5-9 and `task-24-rulings.md` rules 13-16, and override them where
they conflict.

## What changed since phase A (read the ledger lines for Task 24, 24F and 24G in `progress.md`)
- **The engine changed after phase A's first batches.**
  - Task 24F (8dfc012) made the anchor net syntenic (diagnosis: `diag-breakpoints-report.md`) and the window
    chunking adaptive.
  - Task 24G (1cb1b34) added classifier rule 5a: a present call must be anchored at its site (inspection:
    `inspect-disputes-report.md`).
- **The whole bake-off was rerun on the final engine.** Its outputs are in `D/runs/`, `D/chr10/runs/` and
  `D/chr10/anchorwave_readout/`, where `D = /data2/chris/maize_introgression/benchmark_pav/bakeoff`.
- **The stock-engine (bfeeb55) outputs are kept** as an ablation baseline:
  - `D/runs_stocknet/`: all 78 sim runs;
  - `D/chr10/runs_stocknet/`: mm2, mm2_lastz, mm2_wfa, awpaf (that batch was stopped before the other routes);
  - `D/chr10/anchorwave_readout_stocknet/`.

  Both the net and rule 5a differ between the two engines; label the comparison "engine bfeeb55 vs 1cb1b34".

## Rulings
1. **Candidates.**
   - Routes, all with the mappy backend: mm2, mm2_N50, fastga, flank-mm2_2k/5k/10k/20k, flank-blast_10k, hybrid.
     hybrid is FastGA plus the flank fallback, because FastGA is on PATH.
   - Backends: lastz and wfa, chosen the same way with the winning route. The sims have them on mm2 and fastga;
     chr10 has them on mm2 for B73v5 -> TIL18.
   - Never candidates: the `awpaf_yardstick` run and the AnchorWave read-out.
2. **Scoring** (Step 5, `03_score_sims.py`): `ltrpav-sim score` for every run and both directions.
   - "Pooled" means tp and fp summed over the 6 sims and 2 directions. Pooled correct_resolved_frac is the sum of
     numerators over the sum of denominators, never a mean of fractions.
   - Give per-sim values beside the pooled ones. Write confusion tables for the winner and the runner-up.
   - Score the stock-engine sim runs the same way for the ablation.
3. **Cost** (Step 6, `05_chr10_metrics.py`).
   - Wall time comes from `time.txt`.
   - Memory is max(max_rss_kb, peak_tree_pss_kb) per chr10 run (ruling on review M6). The sims' tree peaks get no
     weight.
   - Whole-genome extrapolation per rule 11 uses the length ratio. Report anchoring and genotyping separately: the
     genotyping estimate is CPU time / threads, because adaptive chunking now ships.
   - Memory gets a per-stage estimate (stages whose memory grows with genome size scale by the ratio; per-worker
     memory bounded by chunk and window caps does not), shown beside rule 11's linear bound. The 250-GB bar is
     judged on the per-stage estimate and marked "confirm in Task 25" when the linear bound fails.
   - A route that timed out failed the cost bar. Report its progress.
   - Thread scaling: compare the 64-thread run with the B73v5/TIL18 part of the 32-thread mm2 run, by per-stage
     log times. Name machine load as a confound.
4. **Real-data metrics.** Per route, from `qc.tsv`: resolved_frac, high_frac, annot_agree, e_in_annot,
   reciprocity, and the window-status mix (breakpoint, span_cap, no anchor).
   - Interpret e_in_annot with the inspection's Q4: about 85% of sampled cases are correct nested E. In about 30%,
     the QC's ancestor link misses a host that B73 annotates; that is a QC bug, deferred to the final fix wave.
5. **AnchorWave comparison** (Step 7), per route, in both B73v5/TIL18 directions:
   - P/E agreement, separately from the missing states;
   - class agreement;
   - present/absent contradictions, high tier counted separately.

   State the inspection's findings: the read-out's O calls come from unaligned AnchorWave bubbles, and the read-out
   shares the engine's classifier, so it is not independent evidence for present calls.
6. **Inspections** (Step 7).
   - At least 20 dotplots of the final engine's remaining high-tier disagreements with the read-out. Contradictions
     come first.
   - 10 of FastGA's remaining breakpoint windows: under the syntenic net FastGA keeps about 619 on chr10 against
     mm2's about 167.
   - Reuse the inspection's code in `D/inspect_disputes/`. Load the `making-figures` skill before any figure; quick
     plots suffice for inspections.
7. **O precision caveat.** In the sims, truth O means the same target site. The engine's O also covers complex
   events (DESIGN 5.4; the controller kept rule 4g). Report O precision with that caveat; O and D are both missing
   class, so neither is a decision metric.
8. **Decision** (Step 8): rules 13-15 verbatim. No other metric enters. Report real-data metrics beside the
   decision, and say plainly if they would argue for another route.
9. **Write-ups.**
   - `D/REPORT.md` gets the tables, the decision, the ablation (engine bfeeb55 vs 1cb1b34: unresolved fraction,
     P/E high-tier precision and correct_resolved_frac on the sims; on chr10, mm2's window status and calls) and
     the misses.
   - Misses go briefly into `/data2/chris/maize_introgression/benchmark_pav/dead_ends.md`; create it if absent.
   - One overview figure for REPORT.md: per candidate, the pooled correct_resolved_frac against the extrapolated
     whole-genome wall time, with both bars drawn and real chr10 resolved_frac shown. It follows the
     `making-figures` skill and is never more convincing than the data.
10. **Step 9.**
    - In `src/ltrpav/constants.py`, set DEFAULT_ROUTE to the winner with a one-line reason. If the winning backend
      is not mappy, set the default backend the same way.
    - Add the outcome to DESIGN section 9 (a short paragraph and a pointer to REPORT.md). Check that ruling 16's
      two stale lines were fixed by 24F.
    - Then run pytest under `-W error` with the env's bin first on PATH, and ruff.
    - Commit once: "Set default anchoring route from bake-off". Use the existing identity, no trailers, no AI
      attribution; the user is the sole author. Do not push.
11. **Compute.** At most 32 threads; probes under `timeout 15m`; export `NUMPY_MADVISE_HUGEPAGE=0`. Launch nothing
    detached, and nothing that would take over 15 min.

## Phasing of phase B (controller ruling, 09:20)
The sims rerun finishes at about 09:25, but the chr10 rerun is still in its slow tail: flank-blast_10k (started 08:29),
then mm2_wfa (45m), fastga (2h), hybrid (2h) and the 64-thread mm2 run. It may run until about 15:00. So phase B is
done in two parts by the same agent.

### B1 (now)
- **Sims (Step 5):** score all 78 rerun sims and all 78 stock-engine sims, pooled per ruling 2.
- **chr10 (Step 6):** write `05_chr10_metrics.py` so that it reads whichever chr10 runs have a `status.json`, and run
  it on those.
- **AnchorWave and inspections (Step 7):** do the AnchorWave comparison and the inspections for the finished routes.
- **REPORT.md:** draft every section the finished data allow, with the slow routes marked pending.
- Stop before the decision (Step 8) and before any repo change (Step 9).
- Write a `phase-B1` section into `task-24b-report.md`.
- While the chr10 batch runs, use at most 8 threads. Touch nothing in chr10/runs/ and no batch marker.
- Never treat a run without `status.json` as finished.

### B2 (later, by resuming the same agent once chr10/batch.exit exists)
- Rerun `05_chr10_metrics.py` on every run.
- Finish the comparisons for the slow routes.
- Make the decision by rules 13-15.
- Finish REPORT.md and dead_ends.md.
- Then Step 9: constants, DESIGN section 9, the tests and the commit.

## Rulings for B2 (controller, 10:35, after B1's hand-back)
B2 starts now, without waiting for the chr10 batch's slow tail. On the pooled sims, flank-blast_10k (0.8847) and
fastga/hybrid (0.8075) fall below the 0.005 band of the best crf (0.8992), so their cost cannot change the route
decision. mm2_wfa's crf (0.8510) cannot win a backend choice against mappy or lastz either. Their chr10 rows and
mm2_t64's thread scaling go into a short B3 once chr10/batch.exit exists.

12. **"Cheaper" in rule 15's tie-break.**
    - The measure is the mean, over the three chr10 pairs, of the per-stage extrapolated whole-genome unordered-pair
      wall time (ruling 3's estimate). The bar exists for throughput over many pairs ("21 pairs in about a day"), so
      a typical pair's wall time is the cost. Memory is a constraint (the bar), not a cost to minimize.
    - Two costs that differ by less than the measured run-to-run noise on this server (20%: identical genotype
      work took 111 s and 133 s) count as tied. That tie goes back to the higher pooled crf.
    - This is fixed after B1's numbers, because rule 15 left it undefined. Say so in REPORT.md, and state the
      result under the alternative readings too (worst pair; no noise tolerance).
13. **Tier set of crf:** all tiers (`ltrpav-sim score`'s summary), with high tier beside it. B1 found the band
    identical under both, so this choice is moot.
14. **Backend follow-up** (rule 1's anticipated short follow-up). If the winning route is not mm2 or fastga:
    - Declare `<winner>_lastz` and `<winner>_wfa` in PARAMS.md before running.
    - Run them on the 6 sims through the harness: 32 threads, `timeout 30m` each, from empty rundirs under runs/.
    - Measure `<winner>_lastz` on chr10 B73v5->TIL18, genotype-only with the winner's anchors reused, `timeout 45m`,
      under chr10/runs/.
    - Skip wfa's chr10 run if its sims crf falls below the backend band, since it cannot win; quote the
      stock-engine wfa cost instead.
    - Then choose the backend by rules 13-15 with the winning route.
15. **Step 9 scope.**
    - Set DEFAULT_ROUTE so that the default run reproduces the winning variant exactly. If a flank route wins, set
      the default flank cap to the winner's cap, with a one-line reason; check how the engine's FLANK_CAP default
      and route.cap interact.
    - If a non-mappy backend wins, do not port it in this commit. Record the decision in DESIGN section 9 and
      REPORT.md; the controller dispatches the port as its own task, before Task 25.
    - Commit: "Set default anchoring route from bake-off".
16. **REPORT.md must state these real-data caveats plainly, beside the decision:**
    - false E calls from short flanks in segmental duplicates (2-5 kb caps);
    - mm2's high-tier P on a same-family copy in wide windows;
    - rule 5a's two loopholes (a one-sided run reaching a few bases into the element or running through a
      repetitive flank piece, and the TSD exception without flank continuity). The controller will tighten both in
      an engine task before Task 25.
    - the window-merge padding defect;
    - FastGA's loss under the syntenic net;
    - the sims missing segmental duplications.

    Each miss gets a `dead_ends.md` entry.
17. **Reports.**
    - Try to write `D/REPORT.md`, `D/../dead_ends.md` and the `task-24b-report.md` sections.
    - If the harness refuses a file again, do not work around it. Return its full final text in the hand-back
      under a heading naming the path, and the controller writes it.
    - B1's text, from your first hand-back, is superseded by the final REPORT.md, which must include all of it.
18. **Compute:** at most 32 threads, since the chr10 batch holds the other 32. Every measured run goes through
    `bakeoff.py measure`. Probes run under `timeout 15m`.
