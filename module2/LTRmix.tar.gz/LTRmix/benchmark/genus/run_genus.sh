#!/usr/bin/env bash
# Second admixture event within Zea (out-of-sample prediction from Chen et al. 2022: parviglumis/huehuetenangensis
# <-> nicaraguensis/luxurians). Published PanAnd EDTA intact LTR-RT calls -> ltrmix libraries -> five-genome ltrmix.
set -u
export NUMPY_MADVISE_HUGEPAGE=0
P=/data2/chris/maize_introgression
G=$P/benchmark/genus
RAW=$P/inputs/raw
BASE=https://download.maizegdb.org
UA='Mozilla/5.0 (X11; Linux x86_64)'
cd $G
get() { local a=$1 f=$2; mkdir -p "$RAW/$a"
  curl -sS -f -L -A "$UA" --retry 8 --retry-delay 20 --retry-all-errors -C - -o "$RAW/$a/$f" "$BASE/$a/$f" || echo "FAIL $a/$f"; }
for x in Zh:Zh-RIMHU001-REFERENCE-PanAnd-1.0 Zn:Zn-PI615697-REFERENCE-PanAnd-1.0; do
  a=${x#*:}; get $a $a.md5; get $a $a.fa.gz.fai; get $a $a.fa.gz; get $a ${a}_EDTA.gff3.gz
done
a=Zx-TIL25-REFERENCE-PanAnd-1.0; get $a ${a}_EDTA.gff3.gz
for x in Zh:Zh-RIMHU001-REFERENCE-PanAnd-1.0 Zn:Zn-PI615697-REFERENCE-PanAnd-1.0; do
  l=${x%%:*}; a=${x#*:}; d=$RAW/$a
  want=$(grep -F "$a.fa.gz" "$d/$a.md5" | grep -vE "$a\.fa\.gz\.[a-z]" | awk '{print $1}' | head -1)
  have=$(md5sum "$d/$a.fa.gz" | cut -d' ' -f1)
  [ "$want" = "$have" ] && echo "MD5_OK $a" || echo "MD5_BAD $a"
  [ -s $P/inputs/$l.fa ] || zcat "$d/$a.fa.gz" | awk -v p="${l}_" '/^>/{split(substr($0,2),q,/[ \t]/); print ">" p q[1]; next} {print}' > $P/inputs/$l.fa
done
source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix
S=$P/benchmark/scripts/edta_to_lib.py
[ -s Zh.edta.tsv ] || python $S $RAW/Zh-RIMHU001-REFERENCE-PanAnd-1.0/Zh-RIMHU001-REFERENCE-PanAnd-1.0_EDTA.gff3.gz $P/inputs/Zh.fa Zh Zh.edta
[ -s Zn.edta.tsv ] || python $S $RAW/Zn-PI615697-REFERENCE-PanAnd-1.0/Zn-PI615697-REFERENCE-PanAnd-1.0_EDTA.gff3.gz $P/inputs/Zn.fa Zn Zn.edta
[ -s TIL25.edta.tsv ] || python $S $RAW/Zx-TIL25-REFERENCE-PanAnd-1.0/Zx-TIL25-REFERENCE-PanAnd-1.0_EDTA.gff3.gz $P/inputs/TIL25.fa TIL25 TIL25.edta
E=$P/benchmark/edta
python $P/LTRmix/ltrmix.py --genome TIL01=$E/TIL01.edta.fa,$E/TIL01.edta.tsv --genome TIL18=$E/TIL18.edta.fa,$E/TIL18.edta.tsv \
  --genome TIL25=TIL25.edta.fa,TIL25.edta.tsv --genome Zh=Zh.edta.fa,Zh.edta.tsv --genome Zn=Zn.edta.fa,Zn.edta.tsv \
  --outdir out -t 16 -v > ltrmix.log 2>&1
echo "GENUS_DONE $?"
