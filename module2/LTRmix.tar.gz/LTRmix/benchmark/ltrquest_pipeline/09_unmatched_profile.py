#!/usr/bin/env python3
"""Profile LTRquest calls that match a published intact LTR-RT against those that do not.

Reports structural hallmarks per group on chr1-10: TG..CA ends, a TSD, protein domains,
confidence, nesting depth, LTR divergence and length. Hallmarks are evidence an element is
real; they do not prove it, and TSD and motif also feed LTRquest's own confidence labels.
Usage: python3 -I 09_unmatched_profile.py --run run/ --annot LABEL=te.gff3.gz [...] [--tol 10]
"""
import argparse
import bisect
import collections
import glob
import gzip
import re
import statistics as st
import sys

CHROMS = {f"chr{i}" for i in range(1, 11)}
INTACT_TYPES = {"LTR_retrotransposon", "Gypsy_LTR_retrotransposon", "Copia_LTR_retrotransposon"}
ID = re.compile(r"^(.+):(\d+)-(\d+)#")


def read_annotation(path):
    out = collections.defaultdict(list)
    with gzip.open(path, "rt") as fh:
        for line in fh:
            if line.startswith("#"):
                continue
            f = line.rstrip("\n").split("\t")
            if f[0] in CHROMS and f[2] in INTACT_TYPES and "Method=structural" in f[8]:
                out[f[0]].append((int(f[3]), int(f[4])))
    return {chrom: sorted(set(v)) for chrom, v in out.items()}


def matched(pool, starts, s, e, tol):
    i = bisect.bisect_left(starts, s - tol)
    while i < len(pool) and pool[i][0] <= s + tol:
        if abs(pool[i][1] - e) <= tol:
            return True
        i += 1
    return False


def present(value):
    return value not in ("NA", "", ".")


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--run", required=True, help="finished run directory")
    ap.add_argument("--annot", nargs="+", required=True, metavar="LABEL=GFF", help="genome label and TE GFF3.gz")
    ap.add_argument("--tol", type=int, default=10, help="end tolerance in bp")
    args = ap.parse_args()
    print("genome\tgroup\tn\tTGCA\tTSD\tdomains\tconf_high\tconf_low\tdepth0\tmedian_k2p\tmedian_len\tunknown_class")
    for spec in args.annot:
        label, gff = spec.split("=", 1)
        pub = read_annotation(gff)
        starts = {c: [t[0] for t in v] for c, v in pub.items()}
        groups = {True: collections.Counter(), False: collections.Counter()}
        k2p, length = {True: [], False: []}, {True: [], False: []}
        prefix = f"{label}_"
        paths = glob.glob(f"{args.run}/{label}_LTRs_depth*_clean_ltr.tsv")
        if not paths:
            sys.exit(f"ERROR: no clean depth tables for {label} in {args.run}")
        for path in paths:
            depth = int(re.search(r"depth(\d+)_", path).group(1))
            with open(path) as fh:
                col = {n.lstrip("#"): i for i, n in enumerate(fh.readline().rstrip("\n").split("\t"))}
                for line in fh:
                    f = line.rstrip("\n").split("\t")
                    m = ID.match(f[0])
                    if not m or not m[1].startswith(prefix) or m[1][len(prefix):] not in CHROMS:
                        continue
                    chrom = m[1][len(prefix):]
                    hit = matched(pub.get(chrom, []), starts.get(chrom, []), int(m[2]), int(m[3]), args.tol)
                    c = groups[hit]
                    c["n"] += 1
                    c["TGCA"] += f[col["motif"]].lower() == "tg...ca"
                    c["TSD"] += present(f[col["tsd"]])
                    c["domains"] += present(f[col["domains"]])
                    c["high"] += f[col["confidence"]] == "high"
                    c["low"] += f[col["confidence"]] == "low"
                    c["depth0"] += depth == 0
                    c["unknown"] += "/unknown" in f[0]
                    length[hit].append(int(f[col["seq_len"]]))
                    if present(f[col["k2p"]]):
                        k2p[hit].append(float(f[col["k2p"]]))
        for hit, name in ((True, "matched"), (False, "unmatched")):
            c, n = groups[hit], groups[hit]["n"]
            frac = [f"{c[k] / n:.3f}" for k in ("TGCA", "TSD", "domains", "high", "low", "depth0")]
            print("\t".join([label, name, str(n), *frac, f"{st.median(k2p[hit]):.4f}",
                             f"{st.median(length[hit]):.0f}", f"{c['unknown'] / n:.3f}"]), flush=True)


if __name__ == "__main__":
    main()
