#!/usr/bin/env bash
# Download the benchmark data into the working directory: the four haplotype assemblies (NCBI) and the two read
# sets (SRA). Needs `datasets` (ncbi-datasets-cli), `prefetch` and `fasterq-dump` (sra-tools), bgzip, samtools.
# usage: fetch_data.sh [threads]   -> data/<S>/<S>_hap{1,2}.fa(.fai), reads/<S>/<SRR>.fastq.gz   (~250 GB of reads)
set -euo pipefail
T=${1:-8}
asm() {  # species hap accession: the assembly FASTA as distributed (8 chromosomes each)
  local S=$1 h=$2 acc=$3 o=data/$1
  [[ -s $o/${S}_$h.fa.fai ]] && return 0
  mkdir -p $o/dl
  datasets download genome accession $acc --include genome --filename $o/dl/$acc.zip
  unzip -o -q $o/dl/$acc.zip -d $o/dl/$acc
  cat $o/dl/$acc/ncbi_dataset/data/$acc/*_genomic.fna > $o/${S}_$h.fa
  samtools faidx $o/${S}_$h.fa
}
reads() {  # species run
  local o=reads/$1
  [[ -s $o/$2.fastq.gz ]] && return 0
  mkdir -p $o
  prefetch --max-size u -O $o $2
  vdb-validate $o/$2
  fasterq-dump --threads $T --temp $o -O $o $o/$2
  bgzip -@ $T -l 3 $o/$2.fastq
  rm -rf $o/$2
}
asm Camara hap1 GCA_056512385.1      # C. amara subsp. amara C087_203 hap1 (hifiasm + Hi-C), 212 Mb
asm Camara hap2 GCA_056512305.1      # hap2, 212 Mb
asm Mfalcata hap1 GCA_062053299.1    # M. sativa subsp. falcata Kubanskaya Zheltaya, principal haplotype, 778 Mb
asm Mfalcata hap2 GCA_062053298.1    # alternate haplotype, 749 Mb
reads Camara SRR40190226             # PacBio Revio HiFi, 94 Gb
reads Mfalcata SRR39462928           # ONT PromethION, 151 Gb
