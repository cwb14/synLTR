#!/usr/bin/env python3
"""Where do ltrkin and the assembly truth disagree, and do the other haplotype's own reads side with the truth?

For confirmed truth at one condition: join ltrkin calls (eval calls.tsv.gz) with the read check of the truth
(<ref>_truth_readcheck.tsv: other-haplotype reads, primary MAPQ >= 20, at the flank points 200 bp outside the
element ends; present >= 5 reads, absent 0). A truth state that says the other haplotype lacks the site (Nr, Nd)
while its reads cover both flanks, or says it keeps the site (F, Fx, E, S) while no read does, is contradicted by
the reads. The reads are part of the genotyped set, so this is a sensitivity analysis, not a better truth.
usage: truth_sensitivity.py <S> <ref> <cond> [tool, default v02]   (run in the benchmark working directory)"""
import sys

import pandas as pd

S, ref, cond = sys.argv[1:4]
tool = sys.argv[4] if len(sys.argv) > 4 else "v02"
c = pd.read_csv(f"{S}/eval/diploid/{ref}_{cond}.calls.tsv.gz", sep="\t", low_memory=False)
c = c[(c.tool == tool) & (c.truth_source == "confirmed") & c.truth_gt.notna()]
r = pd.read_csv(f"{S}/truth/{ref}_truth_readcheck.tsv", sep="\t")[["element_id", "depth_min"]]
d = c.merge(r, on="element_id", how="left")
d["reads"] = pd.cut(d.depth_min, [-1, 0, 4, 1e9], labels=["absent", "1-4", "present"])
keeps = d.truth_state.isin(["F", "Fx", "Fn", "E", "S"])
lacks = d.truth_state.isin(["Nr", "Nd"])
d["contradicted"] = (lacks & (d.reads == "present")) | (keeps & (d.reads == "absent"))
d["correct"] = d.call == d.truth_gt
print(f"{S} {ref} {cond} {tool}: confirmed n {len(d)}, concordance {d.correct.mean():.4f}")
print(f"  truth contradicted by the other haplotype's reads: {d.contradicted.sum()} ({d.contradicted.mean():.3f}); "
      f"Nr/Nd with reads present {(lacks & (d.reads == 'present')).sum()} of {lacks.sum()}; "
      f"F/E/S with no read {(keeps & (d.reads == 'absent')).sum()} of {keeps.sum()}")
u = d[~d.contradicted]
print(f"  concordance where the reads do not contradict the truth: {u.correct.mean():.4f} (n {len(u)}); "
      f"where they do: {d[d.contradicted].correct.mean():.4f} (n {int(d.contradicted.sum())})")
e = d[~d.correct]
print(f"  errors {len(e)}; of these contradicted truth {e.contradicted.sum()} ({e.contradicted.mean():.3f})")
t = e.groupby(["truth_state", "call", "reads"], observed=True).size().rename("n").reset_index()
print(t.sort_values("n", ascending=False).head(12).to_string(index=False))
