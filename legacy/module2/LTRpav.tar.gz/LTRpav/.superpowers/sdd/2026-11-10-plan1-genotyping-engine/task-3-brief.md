### Task 3: FASTA access (`seqio.py`)

**Files:** Create `src/ltrpav/seqio.py`, `tests/test_seqio.py`

**Interfaces:**
- Produces: `class Fasta(path: str | Path, cache_dir: Path | None = None)` with `.lengths() -> dict[str, int]`
  (fai order), `.fetch(seqid: str, start: int, end: int) -> str` (0-based half-open, clipped to the sequence,
  uppercase), `.close()`; `revcomp(seq: str) -> str`; `n_runs(seq: str) -> list[tuple[int, int]]` (0-based
  half-open runs of N/n). Raises `ValueError` for plain-gzip (not bgzip) FASTA with the hint "recompress with bgzip".

- [ ] **Step 1: Write the failing tests**

```python
def test_fetch_plain_and_bgzip(tmp_path):
    fa = tmp_path / "g.fa"; fa.write_text(">s1\nACGTNNNNacgt\n>s2\nGGGG\n")
    gz = tmp_path / "g2.fa.gz"; pysam.tabix_compress(str(fa), str(gz))
    for p in (fa, gz):
        f = Fasta(p, cache_dir=tmp_path / "cache")
        assert f.lengths() == {"s1": 12, "s2": 4}
        assert f.fetch("s1", 0, 12) == "ACGTNNNNACGT"
        assert f.fetch("s1", 10, 99) == "GT"

def test_fetch_uppercases(tmp_path): ...       # soft-masked "acgt" -> "ACGT" (Review Focus 2)

def test_index_into_cache_when_dir_readonly(tmp_path):
    d = tmp_path / "ro"; d.mkdir(); fa = d / "g.fa"; fa.write_text(">s1\nACGT\n"); d.chmod(0o555)
    f = Fasta(fa, cache_dir=tmp_path / "cache")
    assert f.fetch("s1", 1, 3) == "CG" and any((tmp_path / "cache").glob("*.fai"))

def test_n_runs_and_revcomp():
    assert n_runs("ACNNNGTnA") == [(2, 5), (7, 8)]
    assert revcomp("ACGTN") == "NACGT"
```

- [ ] **Step 2: Run** `pytest tests/test_seqio.py -v`. Expected: FAIL (ImportError).
- [ ] **Step 3: Implement.** Use `pysam.FastaFile(path, filepath_index=..., filepath_index_compressed=...)`.
  - If `<path>.fai` exists (plus `.gzi` for bgzip), use it.
  - Else, if the directory is writable, let pysam build the index.
  - Else build it with `pysam.faidx(path, "--fai-idx", fai, "--gzi-idx", gzi)` into
    `cache_dir/<sha1(abs path)[:12]>.<name>.fai`.
  - Detect plain gzip by the magic bytes `1f8b` plus a `pysam` open failure, and raise the ValueError.
- [ ] **Step 4: Run** `pytest tests/test_seqio.py -v`. Expected: PASS.
- [ ] **Step 5: Commit** `git commit -am "Add FASTA random access with index fallback"` (add the new files first).

---

