# Task 13 report: six genomes (controls, direction, f4-ratio, PT loci, default trio view)

Status: DONE_WITH_CONCERNS. Every step ran on snapshot 2 and exited 0; the concerns are two rows of PRELIM's
compare_papers.py that misread a six-genome view (Task 16 owns its edits) and a narrow positive-control pass. No engine
or analysis-package defect was found. Date 2026-11-14, 15:52-16:22 EST.

Paths: P=/data2/chris/maize_introgression; S=$P/benchmark_pav/plan3/real/six.

## 1. Views (Step 1)

All from `$S/run_view.sh VIEW STEP [R,S,D]`, which exports SNAP_SHA=6282541, sources plan3/common/env.sh (asserting
ltrpav.__file__ inside snap/6282541; every step log's first line records it), sets OMP/OPENBLAS/MKL_NUM_THREADS=1, and
runs the step under /usr/bin/time -v with logs/VIEW.STEP.{log,time,exit}. view.sh links six/geno; nothing was written
in six/geno (no file there newer than the start snapshot).

```bash
cd $S
for v in main pos neg til25 hpc1 all; do bash run_view.sh $v view; done   # common/view.sh geno views/$v samples.tsv
timeout 15m bash run_view.sh main  stats B73,TIL01,TIL18   ; timeout 15m bash run_view.sh main  paint B73,TIL01,TIL18
timeout 15m bash run_view.sh pos   stats PT,B73,TIL18      ; timeout 15m bash run_view.sh pos   paint PT,B73,TIL18
timeout 15m bash run_view.sh neg   stats TIL11,TIL01,TIL18 ; timeout 15m bash run_view.sh neg   paint TIL11,TIL01,TIL18
timeout 15m bash run_view.sh til25 stats B73,TIL01,TIL25   ; timeout 15m bash run_view.sh til25 paint B73,TIL01,TIL25
timeout 15m bash run_view.sh hpc1  stats PT,TIL01,TIL25    ; timeout 15m bash run_view.sh hpc1  paint PT,TIL01,TIL25
timeout 15m bash run_view.sh all   stats                   ; timeout 15m bash run_view.sh all   paint   # 20 trios, roles from the data
```

| view | trio | stats wall | paint wall |
|---|---|---|---|
| main | B73,TIL01,TIL18 | 2:00.7 | 1:00.4 |
| pos | PT,B73,TIL18 | 2:05.1 | 1:05.1 |
| neg | TIL11,TIL01,TIL18 | 2:00.9 | 1:02.6 |
| til25 | B73,TIL01,TIL25 | 2:10.4 | 1:00.6 |
| hpc1 | PT,TIL01,TIL25 | 2:58.7 | 1:14.1 |
| all | every trio (20) | 2:45.4 | 4:22.5 |

Peak RSS 1.1-1.3 GB each; single-threaded; at most 13 threads of mine at once (5 analyses plus minimap2 at 8). All 18 steps exit 0; every view's stats.tsv holds
current stats and paint parts (sentinel rows "key", no "left out" line). Direction rows (DFOIL-alt, D_dir) are computed
in every view whatever --trio says: groups maize/mexicana/parviglumis each have two genomes, so maize>mexicana uses the
parviglumis genomes as the sister taxon and Zd as the outgroup, as the brief asks for view all.

## 2. compare_papers.py (Step 2)

- Copied `$P/benchmark_pav/main3_analyses/compare_papers.py` (post-final-wave; mtime 2026-11-12 11:54, the version that
  made PRELIM's 13:40 run), source sha256 **59635200e5a798abc8c736b17e5a5b195b70c3737e6d98c711ab3addc63b9462**, to
  `$P/benchmark_pav/plan3/real/common/compare_papers.py` (the Task 13 and Task 16 briefs say real/common; the plan's File
  Structure says plan3/common; I followed the briefs). Copy sha256
  **1e04f43ed8df53db7dab8c8b667726bdc90402da2fece7d7c20171ca490d334a**.
- The only change (`diff` shows it): `--prefix` (default `prelim`) names `<prefix>_papers.tsv` and `<prefix>_tables/`;
  a prefix with '/', a leading '.' or empty is refused; docstring lines say so. ltrmix_crosscheck.tsv keeps its name (it
  has no "prelim" in it and lands in --out). Ruff gives the same 38 findings on the source and the copy.
- Run: `SNAP_SHA=6282541 bash -c '. ../../common/env.sh; python ../common/compare_papers.py --run views/main --prefix
  six_main'` (from $S; 2:12.6, 1.2 GB). Output `views/main/six_main_papers.tsv` (144 rows: PASS (prelim) 19, MISS (prelim)
  5, reported 118, skipped 2), `views/main/six_main_tables/{chromosomes,windows}.tsv`, `views/main/ltrmix_crosscheck.tsv`
  (equal 58, different 1, as on main3).
- Against main3's prelim_papers.tsv: 98 shared rows, 0 with a different verdict. D_pav +0.2898 ± 0.0392, Z 7.39
  (1,313/723) against +0.2905, Z 7.42 (1,317/724); dD +0.398 (Z 3.14) against +0.397 (Z 3.13); window r and p, AUROC
  0.7118 against 0.7123, tracts 767 (q ≤ 0.05: 0). The 5 MISS (prelim) rows are main3's five (class share x2, ZmPRR37a,
  52 HF regions x2), already in dead_ends.md (2026-11-12); Task 16 owns the final 10.3 verdicts.
- Two rows misread a six-genome view (concern 1).

## 3. The 8 items (`$S/six_results.tsv`, 18 rows; columns item ltrpav ltrmix bar verdict note)

Null quantiles (ruling R2) read the per-run D_pav Z of `sim/runs/null_s*` (30, max |Z| 1.97) and `sim/runs/bn_null_s*`
(30, max |Z| 3.14) from eval.json; k = nulls with |Z| ≥ |Z_obs|, empirical p = (k+1)/31.

1. **Positive control, PASS.** D_pav(PT,B73;TIL18) = +0.1385 ± 0.0439, Z 3.16 (1,192/902); nulls reaching it 0/30
   default, 0/30 bottleneck (p 0.032). Strata: high_tier Z 2.75, nested_collapsed 2.66, no_outgroup_filter 3.30; dD
   +0.154 (Z 1.10). LTRmix (B73v5_TIL18_PT): D_kmer +0.068 (3.32), D_ins +0.132 (4.57), D3 +0.023 (2.65), D_self +0.074
   (1.52); SNP +0.112 (5.2). Beside: D_pav(PT,TIL01;TIL18) +0.4065 (Z 11.91; view all) and D_pav(B73,TIL01;TIL18)
   +0.2898 (Z 7.39; view main): PT 1.40x B73 (LTRmix 1.5x); PT > B73 in 4 of 4 matched sister/donor pairs.
2. **Negative control, MISS (explained).** D_pav(TIL11,TIL01;TIL18) = +0.1445 ± 0.0451, Z 3.20 (1,085/811); nulls 0/30,
   0/30. SNP D +0.052 (Z 3.0) and LTRmix D3 +0.026 (Z 3.23) agree in sign (all four LTRmix tests positive). Beside:
   D_pav(TIL11,TIL01;TIL25) +0.0445 (Z 1.11).
3. **TIL25 as donor, reported.** D_pav(B73,TIL01;TIL25) = +0.1131 ± 0.0405, Z 2.79 (1,220/972): Z > 3 no; nulls 0/30
   default, 2/30 bottleneck (p 0.097). dD +0.560 (Z 4.33; K=0 +0.610 on 33/8). LTRmix D_kmer Z 0.84, D_ins 0.98, D3 1.52,
   **D_self 4.39** (Z > 3 in 1 of 4); SNP +0.050 (Z 2.4).
4. **Direction, not estimable (not a miss).** DFOIL-alt (B73,PT;TIL25,TIL18): DFO +0.001 (Z 0.02), DIL −0.060 (−1.41),
   DFI −0.051 (−1.10), DOL −0.081 (−1.90); code 0000, signature none (the other two quartets also none). D_dir(maize>
   mexicana) +0.0641 ± 0.0710, Z 0.90 (307/270). ptlike: predicted 0000 (none), observed none in 3 of 3; posctl not
   confirmed (2 of 8, bars.tsv), rows note "not validated by simulation (Plan 3)" (R2). D_dir vs nulls: default −0.239 ±
   0.112 (0/30 at or above the real value), bottleneck −0.103 ± 0.155 (4/30), ptlike −0.477 ± 0.097. Simulated power
   optimistic (SIM_RESULTS 10) stated.
5. **f4-ratio of B73, not estimable.** No f4_ratio row in view main ("f4-ratio skipped: no second donor"): PAV distance
   TIL18~TIL25 0.3432 is not below TIL18~B73 0.3428 (also TIL25~B73 0.3453, TIL18~TIL01 0.3645, TIL25~TIL01 0.3568).
   ELAI 17.0% (0.1695) not compared. LTRmix not estimable either (NOTE_fratio.txt).
6. **HPC1 in PT, reported.** `hpc1/place_hpc1.sh`: B73v5_chr3:8,497,916-8,499,434 (loci.v5.tsv read as 1-based closed,
   1,519 bp, cut through the .fai) mapped with `minimap2 -x asm5 -c --cs -t 8` to the whole PT.fa: one hit,
   PT_chr3:9,088,384-9,089,905 (+), query 0-1519 aligned, 1,495 matches / 1,522 columns, NM 27, MAPQ 60, s1 1154, s2 149
   (68 s, 5.3 GB). Matches LTRmix's 9.088 Mb and its 27 B73-PT differences; LTRmix's gene_snp PT.paf (asm10, v5 gene
   +1 kb) puts Zm00001eb121780 at 9,087,119-9,091,256. View hpc1 (sister TIL01, donor TIL25): 8 loci within ±50 kb
   (missing 5, old 2, neither 1), 0 informative, max posterior 0.892; tract PT_chr3:8,965,957-9,449,986 (484 kb, 31
   loci, 1 RD, 0 RS), q 0.879; nearest informative left 1,206 kb (RS), right 101 kb (RD). Beside, B73 in view til25:
   7 loci, 1 informative (RS, 4 kb), max posterior 0.048, no tract. minimap2 choices are in real/memo.md (R3).
7. **Inv4m in PT, reported.** One B73~PT block: B73v5_chr4:172.84-188.14 Mb (679 loci, 44.4/Mb) ~ PT_chr4:173.46-187.00
   Mb (50.2/Mb); coverage of 172,883,881-188,131,462 1.000; left breakpoint interval 0.05 Mb from the reference left
   end, right one contains the right end; sparse on neither. B73~TIL18 (700 loci) and B73~TIL25 (651) same; B73~TIL11
   none; B73~TIL01 170.43-183.12 Mb. All blocks: 1,888 over 21 pairs; 25 sparse on the second genome (span_y/n_loci >
   1 Mb; the reading reproduces main3's 11 of 417), 0 on the first; 19 of the 25 involve Zd. Every block with its flags
   in `$S/inversions_flagged.tsv`; the caller's residual caveat is in the row's note and RESULTS.md.
8. **Decision 11, reported.** 0 of 20 trios (view all) with an unannotated donor; 0 with fallback discovery (every
   D_pav `disc=` is its donor); the 5 trio views likewise.

Verdict count: PASS 1, MISS 1, not estimable 2, reported 14 (rows).

## 4. The MISS and its investigation (negative control)

`$S/investigate_neg.py` (snapshot 2's catalog, discover and d_pav; read only) → `$S/investigate_neg.txt`; rerun with
the saved script gives identical output. Entry in `$P/benchmark_pav/dead_ends.md`, section "2026-11-14 Plan 3 six genomes
(Task 13)".
- Resolution symmetric: TIL11 0.714, TIL01 0.710 of 23,389 candidates.
- Strata hold: high_tier +0.155 (Z 3.24), nested_collapsed +0.130 (Z 2.92), no_outgroup_filter +0.112 (Z 3.01).
- Not maize-mediated (TIL11 is closer to maize: PAV distance to B73 0.313 vs TIL01 0.321; trio {B73,TIL11,TIL01} pairs
  TIL11+B73): at loci both maize genomes lack, D_pav +0.236 (Z 3.76; 319/197); where a maize genome is present +0.120
  (Z 1.90).
- TIL18-specific: TIL25 as donor +0.045 (Z 1.11); maize-absent +0.073 (Z 1.24).
- Young: 0<K<0.01 +0.348 (Z 4.06), K ≥ 0.01 +0.099 (Z 2.31); dD Z 1.16.
- Also: D_pav(TIL11,TIL01;B73) +0.120 (Z 2.82), (…;PT) +0.086 (Z 2.01); the main trio's excess does not depend on
  TIL11's state (TIL11 absent +0.289, present +0.273).
- Untested: why D_pav/SNP D is 2.8 here (1.2-2.3 in the other four trios with a SNP D).

## 5. Tests

`$S/test_score_six.py`, 12 tests on synthetic inputs (scope negation, null quantile, strict Z > 3, negative-control
explanation logic, LTRmix and SNP orientation, PAF primary hit 0→1-based, posterior/BED window edges, sparse flag at
exactly 1 Mb per locus, Inv4m block order and coverage, decision-11 counts, null loading guards, an end-to-end toy six
directory, one-line failure on a missing view). `PYTHONDONTWRITEBYTECODE=1 python -m pytest -v -p no:cacheprovider -W
error test_score_six.py`: 12 passed (`$S/test_score_six.out`). Ruff (E,F,W,I,B,SIM,RUF,EXE; line 120) clean on
score_six.py, test_score_six.py and investigate_neg.py. score_six.py needs only the standard library; rerunning it gives
byte-identical outputs.

## 6. Files written

- `$S/views/{all,main,pos,neg,til25,hpc1}/` (view.sh links, samples.tsv, work/, stats.tsv, findings.txt, inversions.tsv,
  mechanisms.tsv, posterior/tract/decoy files); `views/main/six_main_papers.tsv`, `six_main_tables/`,
  `ltrmix_crosscheck.tsv`.
- `$S/run_view.sh`, `$S/logs/` (VIEW.STEP.{log,time,exit}, main.compare_papers.*, investigate_neg.log).
- `$S/score_six.py`, `$S/test_score_six.py`, `$S/test_score_six.out`, `$S/six_results.tsv`, `$S/trios_all.tsv`,
  `$S/inversions_flagged.tsv`, `$S/RESULTS.md`.
- `$S/investigate_neg.py`, `$S/investigate_neg.txt`; `$S/hpc1/{place_hpc1.sh,HPC1.B73.fa,HPC1.PT.paf,HPC1.PT.log}`.
- `$S/fai.start.task13.tsv`, `$S/fai.end.task13.tsv`.
- `$P/benchmark_pav/plan3/real/common/compare_papers.py`.
- Appended: `$P/benchmark_pav/plan3/real/memo.md` ("Queue, 2026-11-14" per R4; "Task 13" entry with commands, minimap2
  choice, outputs, gotchas, `claude --resume 6b33811c-ca10-4dfe-94dc-c7d4becddd02`), `$P/benchmark_pav/dead_ends.md`.
- Removed: the `real/common/__pycache__` my `py_compile` check created.

## 7. fai check

`inputs/*.fai` (15 files: name, size, mtime, sha256) snapshotted at 15:53 before any job (`fai.start.task13.tsv`, equal to
the queue's fai.end.1794681574.tsv) and at 16:22 after every job (`fai.end.task13.tsv`): identical (`cmp`). Nothing under
six/geno, main3_analyses, benchmark/results/six, benchmark/gene_snp, sim/runs, sim/tables or snap/6282541 is newer than
the start snapshot.

## 8. Concerns

1. **compare_papers.py misreads two rows on a six-genome view** (PRELIM's logic assumes three ingroup genomes; Task 16
   owns its edits). Reproduce: `grep '^1 roles' $S/views/main/six_main_papers.tsv` reports "sisters TIL11 + TIL01
   ... DOES NOT match", while `awk -F'\t' '$2=="sharing" && $3=="B73,TIL18,TIL01"' $S/views/main/stats.tsv` gives
   sister_pair B73+TIL01 (5,406 vs 3,160 vs 1,828). Cause: `sh = {r["statistic"]: r for r in st.find("sharing")}` keys
   all 20 trios' sharing rows by statistic, so the last trio's win (its n_ counts are mixed too). Fix for Task 16: filter
   by the trio's sharing scope (its three genomes in sheet order). Row "14 direction" says "skipped" with main3's note
   while the view has 51 direction rows. Minor: the named-locus tract test includes a BED tract starting at end + flank
   (`start0 <= end + fl`, one base outside); score_six.py uses `start0 < end + fl`.
2. **The positive-control PASS is narrow:** Z 3.16 against the bar 3 and the largest bottleneck-null |Z| 3.14 (empirical
   p at its floor, 0.032); its high-tier and nested-collapsed strata are below 3 (2.75, 2.66). RESULTS.md says so.
3. **Brief detail:** "LTRmix's tests did not reach Z > 3" for B73,TIL01;TIL25 holds for 3 of its 4 tests; D_self reached
   Z 4.39 (trio_summary.tsv). Reported as such.
4. **Path:** compare_papers.py is at real/common/ (the Task 13/16 briefs), not plan3/common/ (the plan's File Structure).
5. **Queue not complete:** stability/mm2 and stability/cap5k (workers w4, w5) were still running at 16:20; not touched.
   The memo's "Queue, 2026-11-14" entry records that state.

## Fix round 1 (2026-11-14 16:45-17:00; review task-13-review.md)

No verdict changed (six_results.tsv: PASS 1, MISS 1, not estimable 2, reported 15; the 18 earlier rows keep their
verdicts, one reported row is new). trios_all.tsv and inversions_flagged.tsv are byte-identical to the first round.
S = benchmark_pav/plan3/real/six; PY = /home/chris/bin/mambaforge/envs/ltrpav/bin/python.

Recomputed (my own code, snapshot 2's functions; not copied from the reviewer):
```bash
cd $S && SNAP_SHA=6282541 bash -c '. ../../common/env.sh; python investigate_neg.py views/neg > investigate_neg.txt'   # 0:44, 1.0 GB
PYTHONDONTWRITEBYTECODE=1 $PY score_six.py          # 19 rows; reruns byte-identically
PYTHONDONTWRITEBYTECODE=1 $PY -m pytest -v -p no:cacheprovider -W error test_score_six.py > test_score_six.out   # 15 passed
```
- D(maize absent) − D(maize present), negative control: **+0.1162 ± 0.0854, Z 1.36** (418 blocks; one delete-one
  jackknife over the union of the two strata's blocks, as trio._gradient does for dD); excess 140 of 274 where a maize
  genome holds the insertion, 122 where both lack it, 12 neither-but-unresolved. TIL25 donor: +0.0723, Z 0.83.
- D(0<K<0.01) − D(K≥0.01), negative control: **+0.2489 ± 0.0783, Z 3.18** (426 blocks); with K=0 in the young bin
  +0.2478, Z 3.28; main trio +0.4101, Z 7.64.
- TIL25/TIL18 D_pav ratios over the parviglumis-sister pairs: 0.390, 0.518, 0.662, 0.392, 0.308 (0.31-0.66).
- D_pav against the gene-space SNP D over the 5 trios with both: Spearman **rho 0.90**, exact one-sided p **0.042** (5
  of 120 orderings) if independent, Pearson **r 0.958**; LTRmix D_ins against the SNP D: rho 1.00, r 0.998.
- PT-like runs observed codes 0000, 0000, 0000 (eval.json); their DFOIL locus counts 100-145 per statistic; the
  prediction's 264-368 (sim/direction_counts.tsv); the real 1,304-1,307.
- Inv4m right breakpoint interval 188,135,457-188,225,070 against the reference end 188,131,462: 3,995 bp (4.0 kb);
  left 47.2 kb. Positive-control margin over the bottleneck maximum: 3.1576 − 3.1434 = 0.014.

| item | change | file:line |
|---|---|---|
| I1 | the controls' equal D_pav (+0.1385 / +0.1445) and what the SNPs (0.112 / 0.052) and LTRmix D_ins (Z 4.57 / 1.19) show: summary, items 1-2, §1, §2 | RESULTS.md:13-15, 20-23, 29-31, 125-130, 144-148 |
| I1 | "size of the excess untested" moved into §2 (kept in dead_ends) | RESULTS.md:144-148 |
| I1 | headline: rho 0.90 with the non-independence caveat, the swap is the two controls, "small" dropped for D_pav | RESULTS.md:335-341 |
| I1 | rank row (new, reported) and both controls' notes | score_six.py:538-542, 567-584, 595-596; six_results.tsv row "1 beside: D_pav against the gene-space SNP D" |
| I2a | "not only through maize": excess remains where both lack it; strata differ at Z 1.36; 140 of 274 where maize holds it | RESULTS.md:152-159; dead_ends.md:415-423 |
| I2b | TIL25 contrast labeled untested, with the 0.31-0.66 shares and LTRmix's TIL25 note | RESULTS.md:160-164; dead_ends.md:424-429 |
| I2c | age contrast tested (Z 3.18), no simulated null; dD Z 1.16 explained | RESULTS.md:165-168; dead_ends.md:430-434 |
| I2 | both jackknife differences and the TIL25 ratios made durable | investigate_neg.py:46-66, 100-126; investigate_neg.txt |
| M1 | margin 0.01 (3.158 against 3.143) | RESULTS.md:122 |
| M2 | right breakpoint 4 kb outside (and left 47 kb); scorer prints kb | RESULTS.md:50, 246-248; score_six.py:448-455 |
| M3 | power wording: real loci ~10x the simulated runs', optimism per locus, "not estimable" rests on rule 7 | RESULTS.md:208-212, 327-329; score_six.py:652-663 |
| M4 | observed PT-like codes 0000 x3 in the row and the text | score_six.py:181-186, 654; RESULTS.md:197 |
| M5 | mechanism marked expected, with where it is and is not seen (4 of 20 trios dD < 0) | RESULTS.md:343-347 |
| M6 | Terms: PAV distance, f4-ratio, ELAI (Yang 2023, PMID 38033071 checked), gene-space SNP D, LTRmix's tests, MAPQ, chain score | RESULTS.md:81-96, 226-227 |
| M7 | 20-trio table gains the bottleneck-null count and p | RESULTS.md:285-310 |
| M8 | run globs → `<prefix><digits>` (null_s101.100Mb and fn0.2_null_s1 ignored); tests for the D_dir null counts (bottleneck 14 of 30), the f4 "reported" branch, ranks, breakpoint text, PT-like codes | score_six.py:152-178; test_score_six.py:173-176, 182-197, 273-283, 309-322, 341-350 |
| M9 | memo names env ltrpav's python | real/memo.md:151-153 |
| -N 50 | removed (memo and place_hpc1.sh header; not confirmable from 2.31's help); asm5's scoring confirmed instead by AS 991 = 1,495 − 24×19 − (39+3×3) | real/memo.md:155; hpc1/place_hpc1.sh:7 (sha256 now 640268c6…8073) |
| pause | memo's 12:17 kept, as instructed | real/memo.md:123 |

Tests: 15 passed (`$S/test_score_six.out`). Mutation check of the new tests in scratch copies: `>=`→`<=` in both D_dir
null counts, `if f4`→`if not f4`, `fullmatch`→`match` and `\d+`→`\S+` in the run pattern: all 5 killed. Ruff (E, F, W,
I, B, SIM, RUF, EXE; line 120) clean on the three scripts. inputs/*.fai re-snapshotted at 16:57: unchanged; nothing in
six/geno, sim/runs, sim/tables, snap/6282541, results/six or gene_snp newer than the start snapshot. Only my own Task 13
entries in real/memo.md and dead_ends.md were edited (lines before them unchanged).

Concern: none new. compare_papers.py's two six-genome misreads (concern 1) remain for Task 16.

## Re-review slips (2026-11-14 17:20; task-13-review.md, re-review N1, N2 and two more)

Text only; the touched sentences were re-wrapped, nothing else changed.
- N1, six/RESULTS.md:82-83: the PAV distance "decides the second donor and the DFOIL-alt order; the sister pair is
  instead the pair sharing the most insertions (DESIGN 7.2)" (was: it decides the sister pair too).
- N2, real/memo.md:159: "six_results.tsv (19 rows: PASS 1, MISS 1, not estimable 2, reported 15)" (was 18 and 14).
- N3, six/RESULTS.md:345-348: the young-insertion excess is listed for every trio where dD reaches Z 3: PT, TIL01;
  TIL18 (Z 5.10), B73, TIL01; TIL25 (Z 4.33), B73, TIL01; TIL18 (Z 3.14), plus the negative control's 0-1% contrast
  (Z 3.18). Source: `awk -F'\t' 'NR>1 && $9+0 >= 3' six/trios_all.tsv`.
- dead_ends.md:425: LTRmix's second control "all four |Z| <= 0.55 there, the largest D3's 0.546" (was "all |Z| <=
  0.5"); trio_summary.tsv row TIL01_TIL25_TIL11: D_kmer Z 0.216, D_ins −0.180, D3 0.546, D_self 0.357.
