# Changelog

## 0.2.1 (2026-11-13)
Input checks and fixes from a pre-release audit. Calls on valid inputs are unchanged: on the benchmark BAMs
(*C. amara* and *M. falcata*, 20x) the genotype tables are identical to 0.2.0.

`ltrkin genotype`:
- **Evidence cache.** `<out>.<sample>.evidence.json.gz` is keyed to every element's coordinates and TSD, the code
  and the options. 0.2.0 keyed it to the number of elements, so a rerun with the same prefix after changing the
  annotation could reuse other elements' evidence. An interrupted run no longer leaves a truncated cache.
- **Duplicate reads.** Reads flagged as duplicates or QC failures are left out of the depth model too, as they
  already were from the evidence (0.2.0 overestimated the depth of duplicate-marked BAMs: F/F became F/N).
- **Fails early with a message:** a BAM aligned to another assembly (sequence lengths differ from the FASTA); an
  element past the end of its sequence; repeated element IDs (0.2.0 merged their LTRs); any BAM without an index
  (checked before any work); a BAM without coverage; `-t` < 1; an unreadable FASTA or GFF3; an unwritable output
  directory. Warns when one BAM holds several samples (they are genotyped as one).
- **VCF:** IDs and INFO values percent-encoded; FT flags separated by semicolons; a no-call has one `.` per
  chromosome copy; tabix index written.

`ltrkin source`:
- Checks that the genotype tables match the annotation (shared IDs, same coordinates) and that minimap2 is on PATH.
- The alignment cache (`<out>.work/`) is keyed to family labels and sequences.
- No new or no fixed copy, no fixed relative in any family, or every pair a duplicated segment: empty tables with
  headers instead of an error or a crash. Annotation sequences missing from the reference are skipped with a
  warning; output paths may contain spaces.

Packaging and documentation:
- `mappy` is a declared dependency (`pip install` alone left `ltrkin source` unable to import it); the conda
  environments exclude Anaconda's commercial `defaults` channel.
- README reduced to what users need (what it does, how to run it, accuracy, outputs) with a workflow figure; every
  output column in `docs/outputs.md`.
- The v0.2 benchmark is rerunnable from the repository: `benchmark/assembly_truth/` (workflow, configuration, data
  download), steps in `benchmark/README.md`. Benchmark scripts no longer contain machine-specific paths.
- 12 regression tests for the fixes above (`tests/test_inputs.py`, `tests/test_source.py`).

## 0.2.0 (2026-11-13)
Benchmarked against haplotype-resolved assemblies of two outcrossing plants (*Cardamine amara*, PacBio HiFi;
*Medicago sativa* subsp. *falcata*, ONT): `docs/benchmark_v0.2.md`. Same command line as 0.1.0.

`ltrkin genotype`:
- **Read phasing.** Reads at an element are compared over 3 kb of unique flank on each side (bases of quality
  >= 20). Two distinct read groups that both carry an allele show it on two haplotypes; this lower bound on the
  allele's dosage enters the likelihood. Phasing uses at most 80 reads per element. It is off for reads without
  base qualities that diverge > 1% from the reference.
- **Depth model.** Depth per haplotype is fitted genome-wide as a mixture of 1..ploidy copies, then recalibrated at
  the sample's own sites with an empty or solo allele, where the number of full haplotypes is known. 0.1.0 took the
  genome-wide mode, which fails where much sequence is on one haplotype and depth is overdispersed (ONT).
- **Genotype prior.** The sample's genotype frequencies are learned from its own sites (empirical Bayes) and
  used as the prior. The prior stays flat with fewer than 5 called sites per genotype class.
- **Full alleles of another length.** A spanning read that carries both element ends counts as full whatever its
  internal length (new column `n_F_other`, flag `full_other_length`).
- **Junction rule.** A junction read must carry the element end: the junction base and the LTR end aligned, and
  >= 100 aligned bp in the first 300 bp of internal region.
- **Annotation boundary error** is learned per sample from reads at elements without a TSD, so imprecise element
  ends (e.g. +-50 bp) are tolerated without an option.
- **Ambiguous mapping.** Sites with no informative read but reads at the junctions with MAPQ below `--min-mapq`
  are no-calls (`./.`, GQ 0; new column `n_lowq`, flag `low_mapq`). 0.1.0 called them N/N.
- New columns: `n_F_other`, `n_lowq`, `hap_F`, `hap_S`, `hap_E` (haplotypes seen carrying each allele) and
  `phase_sites`.
- DANTE_LTR GFF3 (`transposable_element` with LTR children) is read.
- BAMs that share a read-group sample name get unique sample names. 0.1.0 merged them into one sample, which gave
  an invalid VCF.

`ltrkin source`: algorithm unchanged. It shares the GFF3 reader, so it also reads DANTE_LTR annotations.

## 0.1.0 (2026-11-10)
First version: `genotype` (F/S/E/N alleles from flank-anchored long reads) and `source` (nearest fixed relative of
each new copy, with two-parent and locality tests).
