#!/usr/bin/env python3
"""Benchmark presence/absence calls against each accession's own assembly (Poa annua C11, P3).

Truth (elements table `orth_<acc>`, assembly-vs-assembly orthology, independent of reads): `ortho` = the element is
present at the orthologous site of the accession's assembly; `empty` = empty site. Accessions are inbred, so truth
is homozygous: present -> full allele, empty -> E/E.
ltrkin calls (GQ >= 20): present = genotype with an F allele and no E; absent = E/E (or E/N); het = F/E; solo = S.
Baseline: the TIP caller of the LTR_RT project (refelements.genotypes; codes 1 present, 0 empty, S, H, O, .),
excluding calls with the `a` suffix (taken from the assembly itself, so circular).
Strata: element length, LTR divergence (K2P), nesting.
Usage: assembly_eval.py --genotypes annua.genotypes.tsv --elements annua.elements.tsv.gz --tips refelements.genotypes.tsv.gz
       --samples C11,P3 -o prefix
"""
import argparse

import numpy as np
import pandas as pd


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--genotypes", required=True)
    ap.add_argument("--elements", required=True)
    ap.add_argument("--tips", required=True)
    ap.add_argument("--samples", default="C11,P3")
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    g = pd.read_csv(a.genotypes, sep="\t", dtype={"element_id": str})
    g["key"] = g.chrom + ":" + g.start.astype(str) + "-" + g.end.astype(str)
    E = pd.read_csv(a.elements, sep="\t", usecols=["key", "k2p", "depth", "length"] + [f"orth_{s}" for s in a.samples.split(",")])
    E = E.drop_duplicates("key").set_index("key")
    tips = pd.read_csv(a.tips, sep="\t").drop_duplicates("key").set_index("key")
    lines = []
    allrows = []
    for s in a.samples.split(","):
        d = g[g["sample"].str.contains(s)].set_index("key")
        if d.empty:
            lines.append(f"{s}: no genotypes for this sample"); continue
        t = E[f"orth_{s}"].reindex(d.index)
        d = d.assign(truth=t.map({"ortho": "present", "empty": "absent"}), k2p=E.k2p.reindex(d.index),
                     nest=(d.n_inner > 0) | (d.n_outer > 0))
        alle = d.genotype.str.split("/")
        d["call"] = np.select([alle.apply(lambda x: "F" in x and "E" not in x and "S" not in x),
                               alle.apply(lambda x: set(x) <= {"E", "N"} and "E" in x),
                               alle.apply(lambda x: "F" in x and "E" in x),
                               alle.apply(lambda x: "S" in x)], ["present", "absent", "het", "solo"], "nocall")
        d.loc[d.gq < 20, "call"] = "lowq"
        if "pav" in d:
            d["pavcall"] = d.pav.map({"present": "present", "absent": "absent", "solo": "solo"}).fillna("uncertain")
        tc = tips[s].reindex(d.index).astype(str)
        d["tip"] = np.select([tc.str.contains("a"), tc.str[0] == "1", tc.str[0] == "0"], ["circular", "present", "absent"], "other")
        k = d[d.truth.notna()]
        lines.append(f"== {s}: elements {len(d)}, with assembly truth {len(k)} (present {(k.truth == 'present').sum()}, "
                     f"absent {(k.truth == 'absent').sum()})")
        lines.append("ltrkin call (rows) x truth (cols):\n" + pd.crosstab(k.call, k.truth).to_string())
        for who, col in (("ltrkin genotype (GQ>=20)", "call"), ("ltrkin pav (allele posterior >= 0.99)", "pavcall"),
                         ("TIP caller", "tip")):
            if col not in k:
                continue
            for st in ("absent", "present"):
                called = k[k[col] == st]
                prec = (called.truth == st).mean() if len(called) else np.nan
                rec = (k[k.truth == st][col] == st).mean()
                lines.append(f"{who} {st}: precision {prec:.4f} (n {len(called)}), recall {rec:.4f} (of {(k.truth == st).sum()})")
        k = k.assign(len_bin=pd.cut(k.length, [0, 5000, 10000, 17000, 1e9], labels=["<5kb", "5-10kb", "10-17kb", ">17kb"]),
                     age=np.where(k.k2p <= 0.005, "young", "old"))
        for strat in ("len_bin", "age", "nest"):
            rows = []
            for lv, x in k.groupby(strat, observed=True):
                ab = x[x.truth == "absent"]; pr = x[x.truth == "present"]
                cc = "pavcall" if "pavcall" in x else "call"
                rows.append(dict(stratum=f"{strat}={lv}", n=len(x),
                                 absent_recall=round((ab[cc] == "absent").mean(), 3) if len(ab) else np.nan,
                                 absent_precision=round((x[x[cc] == "absent"].truth == "absent").mean(), 4) if (x[cc] == "absent").any() else np.nan,
                                 present_recall=round((pr[cc] == "present").mean(), 3) if len(pr) else np.nan,
                                 uncertain=round((x[cc].isin(["uncertain", "lowq"])).mean(), 3)))
            lines.append(pd.DataFrame(rows).to_string(index=False))
        allrows.append(k.assign(sample=s))
    txt = "\n".join(lines)
    print(txt)
    open(a.out + ".summary.txt", "w").write(txt + "\n")
    pd.concat(allrows).reset_index().to_csv(a.out + ".elements.tsv.gz", sep="\t", index=False)


if __name__ == "__main__":
    main()
