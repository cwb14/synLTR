"""Painting of a recipient's genome and the youngest insertion per tract.

Classes (`classes`, PAINT_CLASSES). Along the recipient X's sequences, X's own loci, each classed from X's own
calls (`Catalog.pcls`, never loci.tsv's merged states), checked in this order: `old` (some
outgroup present: older than the ingroup split, set aside; a missing outgroup keeps the locus), `missing` (the
sister Y or the donor D unresolved), then `RD` (D present, Y E: donor-like), `RS` (Y present, D E:
sister-like), `both`, `neither`. Only RD and RS emit (codes 0 and 1); the rest are missing data, since emitted
private classes become fake states.

HMM (`forward_backward`, `fit_hmm`, `call_tracts`, `target_decoy`). Two states, 0 sister-like and 1
donor-like; one chain per X sequence (fai index), each starting at the stationary distribution (1 - pi, pi);
between loci d bp apart the state is redrawn from it with probability 1 - q, q = exp(-d / L), so p01 = pi (1 -
q) and p10 = (1 - pi)(1 - q); a missing emission is 1, so the chain is stationary across missing loci.
Positions are X's site starts (1-based; the insertion point), in idx order, so they never decrease along a
chain. `fit_hmm`: start at pi 0.1, L 1e5; each EM
round takes the L of the HMM_L_GRID that maximizes the log-likelihood, then e = (expected counts + 0.5),
normalized, and pi = the mean posterior of the emitting loci clipped to [1e-4, PI_MAX]; it stops when the
log-likelihood moves by < HMM_TOL of itself, or after HMM_ITERS rounds. Initial emissions: e0 = the
decoy's class frequencies + 1 (the target's own without a decoy), e1 = e0 * (5, 0.2) so that state 1 starts
RD-enriched and RS-depleted, both normalized. The fitted
state 1 is donor-like when e1[RD] > e0[RD] (`donor_state`); without it no tract is called.

Emissions: EM fits e0 and e1 (`fit_hmm`), as above. On sparse, class-segregated loci EM makes state 0 pure RS
and state 1 pure RD; the target-decoy q-values below are what separate that from real ancestry.

Lengths: L, the switch scale, is reported as `mean_tract_bp`;
the mean donor-like run under the model, L / (1 - pi) (the rate out of state 1 is (1 - pi) / L), as
`mean_donor_run_bp`.

Tracts (`call_tracts`): maximal runs of loci on one sequence with posterior > 0.5 and posterior odds >=
BF_TRACT x prior odds pi / (1 - pi). A tract runs from the start of its first locus to the largest end of
its loci (the last one's, unless a nested host reaches further), so the interval holds every locus. Its
score, sum_post, is the exactly rounded sum of its posteriors (math.fsum): the same posteriors give the same
score wherever they lie and in any order, so a true tie between a target and a decoy tract compares equal.

Decoy and q: the sister Y's loci (those Y discovers), classed by Y's own
calls with X and Y swapped, are painted with the fitted parameters unchanged, and their tracts called by
the same rule. Scores are each tract's sum of posteriors. `target_decoy` (q with the +1
correction): raw = ((#decoy >= x) * scale + 1) / (#target >= x), q = the smallest raw at or below the
tract's score, capped at 1; p = (1 + #decoy >= x) / (1 + #decoy). scale = n informative(X) / n informative(Y)
(informative loci, not all elements). There is no decoy when Y has no annotation
or no informative locus: q and p are written "none", with a WARNING.

Resolution: the spacing of consecutive informative loci on one sequence, and `shortest_callable` at its
median: the fewest consecutive RD loci whose middle locus passes the tract rule, alone (missing flanks change
nothing: the chain is stationary across them) and between CALLABLE_FLANK RS loci on each side (a heuristic
flank).

Per tract: youngest_k = the smallest K2P of X's copy (the annotation's) over its RD loci: the admixture is
younger than any insertion it transferred. youngest_u95 needs identity.tsv's self rows (`self_counts`): the
smallest u95(diffs, sites) (`stats.u95`) over its RD loci, from X's copy, else from D's copy of the same
insertion; "." without them (no K-based stand-in). n_identical = RD loci with K = 0; inv_frac = the share of
its loci inside an inverted block of X against Y or D (`inversions.inside`, keyed on X's fai indexes; the
posterior files flag each locus). Inverted blocks are flags only: the fit ignores them.

Files (`write_paintings`): tracts.<X>.bed and posterior.<X>.tsv per recipient, decoy_tracts.<Y>.bed and
decoy_posterior.<Y>.tsv per sister with a decoy, every trio in one file with its sister and donor columns
(in a decoy file, the sister is X), rows by trio scope then position. Sequence names come from
`Catalog.seqids` (output only). A posterior row's `tract` is its tract as seqid:start-end (1-based), "."
outside one; a decoy tract has q and p_decoy ".". A skipped painting writes nothing, so a recipient whose
every trio is skipped gets no file.
"""
from __future__ import annotations

import fnmatch
import math
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from numba import njit

from ..genotype import tsv_field
from .catalog import Catalog, age_bin
from .constants import (
    BF_TRACT,
    CALLABLE_FLANK,
    CALLABLE_MAX,
    HMM_ITERS,
    HMM_L_GRID,
    HMM_TOL,
    PI_MAX,
    Q_TRACT,
)
from .inversions import InvBlock, inside
from .stats import Findings, StatRow, resolution, u95
from .trio import Trio

# emissions: RD 0, RS 1, the rest -1 (missing data)
PAINT_CLASSES = ("RD", "RS", "both", "neither", "missing", "old")
POSTERIOR_COLUMNS = ("lid", "seqid", "start", "end", "sister", "donor", "class", "post", "tract", "inv")
# a genome's painting files, by its label: as the recipient (tracts, posterior) and as a decoy
PAINTING_FILES = ("tracts.{}.bed", "posterior.{}.tsv", "decoy_tracts.{}.bed", "decoy_posterior.{}.tsv")
TRACT_COLUMNS = ("#chrom", "start0", "end", "name", "score", "strand", "sister", "donor", "n_loci", "n_RD",
                 "n_RS", "mean_post", "sum_post", "q", "p_decoy", "youngest_k", "youngest_u95", "n_identical",
                 "inv_frac")
RD, RS, BOTH, NEITHER, MISSING, OLD = range(len(PAINT_CLASSES))
PAINTING, DATING = "Painting", "Dating"  # findings sections (stats.SECTIONS)
_INIT = np.array([5.0, 0.2])       # the initial state 1 is RD-enriched, RS-depleted
_PI0, _L0 = 0.1, 1e5               # EM's starting pi and L
_PI_MIN = 1e-4                     # pi's lower clip


@dataclass(eq=False)
class HmmFit:
    """A fitted painting HMM: pi (the donor-like fraction), L (the switch scale, bp), emissions e0 (state 0)
    and e1 (state 1) over (RD, RS), the posterior of state 1 per locus and the log-likelihood."""

    pi: float
    L: float
    e0: np.ndarray
    e1: np.ndarray
    post: np.ndarray
    loglik: float


@dataclass
class Tract:
    """A run of loci called donor-like: seq is X's fai index, start/end 1-based on X; first/last are positions
    in the painting's idx (inclusive)."""

    seq: int
    start: int
    end: int
    first: int
    last: int
    mean_post: float
    sum_post: float


@dataclass(eq=False)
class Painting:
    """One trio's painting of its recipient R (trio.R) and of the decoy, its sister S (trio.S). idx: R's loci
    as catalog indexes in R's (fai index, start) order, with their class (PAINT_CLASSES index), posterior and
    inverted-block flag; q and p per tract (None without a decoy). skipped: why nothing was painted (fit
    None, post nan)."""

    trio: Trio
    idx: np.ndarray
    cls: np.ndarray
    post: np.ndarray
    inv: np.ndarray
    fit: HmmFit | None
    donor_state: bool
    tracts: list[Tract]
    q: list[float | None]
    p: list[float | None]
    decoy_idx: np.ndarray
    decoy_cls: np.ndarray
    decoy_post: np.ndarray
    decoy_tracts: list[Tract]
    skipped: str | None
    # what the files and rows need besides the catalog
    decoy_inv: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=bool))
    scale: float | None = None                       # target-decoy scale; None: no decoy
    self_counts: dict[tuple[str, str], tuple[int, int]] | None = None

    @property
    def collapsed(self) -> bool:
        """The fit collapsed: pi at its floor and no tract. State 1 then holds no data, so its emissions, L
        and the donor-state rule come from the pseudocounts: no donor-like ancestry is detectable."""
        return self.fit is not None and self.fit.pi <= _PI_MIN and not self.tracts


# ---------------------------------------------------------------- classes


def classes(cat: Catalog, X: str, Y: str, D: str) -> tuple[np.ndarray, np.ndarray]:
    """(idx, cls): X's loci (module docstring) as int64 catalog indexes in X's (fai index, start) order, ties
    in catalog order, and their int8 class (PAINT_CLASSES index): X's members, every state from X's own calls."""
    _check(cat, X, Y, D)
    gx = cat.g(X)
    rows = cat.member[:, gx].copy()
    y, d = cat.pcls(X, Y), cat.pcls(X, D)
    out = [cat.pcls(X, o) for o in cat.outgroups]
    rows &= cat.seq[:, gx] >= 0  # a present site has coordinates
    idx = np.flatnonzero(rows)
    idx = idx[np.lexsort((cat.start[idx, gx], cat.seq[idx, gx]))].astype(np.int64)
    y, d = y[idx], d[idx]
    old = np.zeros(len(idx), dtype=bool)
    for o in out:
        old |= o[idx] == 1
    cls = np.select([old, (y < 0) | (d < 0), (d == 1) & (y == 0), (y == 1) & (d == 0), (y == 1) & (d == 1)],
                    [OLD, MISSING, RD, RS, BOTH], default=NEITHER).astype(np.int8)
    return idx, cls


def _check(cat: Catalog, X: str, Y: str, D: str) -> None:
    """Three distinct genomes of the run (an AnalysisError names an unknown one)."""
    for g in (X, Y, D):
        cat.g(g)
    if len({X, Y, D}) != 3:
        raise ValueError(f"painting needs three distinct genomes, not {X}, {Y}, {D}")


def _emit(cls: np.ndarray) -> np.ndarray:
    """int64 emission per class: RD 0, RS 1, the rest -1 (missing data)."""
    return np.where(cls <= RS, cls, -1).astype(np.int64)


def _sites(cat: Catalog, X: str, idx: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """(fai index, start, end) of X's site at each locus (1-based)."""
    g = cat.g(X)
    return cat.seq[idx, g].astype(np.int64), cat.start[idx, g], cat.end[idx, g]


def _starts(seq: np.ndarray) -> np.ndarray:
    """Each chain's (sequence's) first index, then a final len(seq) sentinel; seq sorted."""
    return np.r_[0, np.flatnonzero(np.diff(seq)) + 1, len(seq)].astype(np.int64)


# ---------------------------------------------------------------- the HMM


@njit(cache=True)
def forward_backward(pos, emit, starts, pi, lam, e0, e1):
    """Scaled forward-backward over chains [starts[c], starts[c + 1]): categorical
    emissions (emit < 0: missing, emission 1), the switch probability 1 - exp(-lam * d) over d bp, the chain
    starting at (1 - pi, pi). Returns the posterior of state 1, the log-likelihood and the expected emission
    counts under state 1 and under state 0."""
    n = len(pos)
    K = len(e0)
    post = np.zeros(n)
    c1 = np.zeros(K)
    c0 = np.zeros(K)
    ll = 0.0
    for c in range(len(starts) - 1):
        s0 = starts[c]
        m = starts[c + 1] - s0
        if m <= 0:
            continue
        fa = np.zeros((m, 2))
        for t in range(m):
            k = emit[s0 + t]
            if k >= K:
                raise ValueError("forward_backward: an emission code is out of range")
            em0 = e0[k] if k >= 0 else 1.0
            em1 = e1[k] if k >= 0 else 1.0
            if t == 0:
                a0 = 1.0 - pi
                a1 = pi
            else:
                q = math.exp(-lam * max(pos[s0 + t] - pos[s0 + t - 1], 0.0))
                p01 = pi * (1.0 - q)
                p10 = (1.0 - pi) * (1.0 - q)
                a0 = fa[t - 1, 0] * (1.0 - p01) + fa[t - 1, 1] * p10
                a1 = fa[t - 1, 0] * p01 + fa[t - 1, 1] * (1.0 - p10)
            f0 = a0 * em0
            f1 = a1 * em1
            sc = f0 + f1
            fa[t, 0] = f0 / sc
            fa[t, 1] = f1 / sc
            ll += math.log(sc)
        b0 = 1.0
        b1 = 1.0
        for t in range(m - 1, -1, -1):
            if t < m - 1:
                q = math.exp(-lam * max(pos[s0 + t + 1] - pos[s0 + t], 0.0))
                p01 = pi * (1.0 - q)
                p10 = (1.0 - pi) * (1.0 - q)
                k = emit[s0 + t + 1]
                em0 = e0[k] if k >= 0 else 1.0
                em1 = e1[k] if k >= 0 else 1.0
                nb0 = (1.0 - p01) * em0 * b0 + p01 * em1 * b1
                nb1 = p10 * em0 * b0 + (1.0 - p10) * em1 * b1
                ss = nb0 + nb1
                b0 = nb0 / ss
                b1 = nb1 / ss
            g0 = fa[t, 0] * b0
            g1 = fa[t, 1] * b1
            g = g1 / (g0 + g1)
            post[s0 + t] = g
            k = emit[s0 + t]
            if k >= 0:
                c1[k] += g
                c0[k] += 1.0 - g
    return post, ll, c1, c0


def fit_hmm(pos: np.ndarray, emit: np.ndarray, starts: np.ndarray, e0: np.ndarray, e1: np.ndarray) -> HmmFit:
    """EM for the painting HMM (module docstring), from the initial emissions e0, e1.
    A ValueError when no locus emits."""
    pos = np.ascontiguousarray(pos, dtype=np.float64)
    emit = np.ascontiguousarray(emit, dtype=np.int64)
    starts = np.ascontiguousarray(starts, dtype=np.int64)
    e0, e1 = np.asarray(e0, dtype=np.float64), np.asarray(e1, dtype=np.float64)
    informative = emit >= 0
    if not informative.any():
        raise ValueError("fit_hmm: no emitting locus (every emission is missing data)")
    grid = np.geomspace(*HMM_L_GRID)
    pi, L, ll_old = _PI0, _L0, -math.inf
    for _ in range(HMM_ITERS):
        best = None
        for lc in grid:
            post, ll, c1, c0 = forward_backward(pos, emit, starts, pi, 1.0 / lc, e0, e1)
            if best is None or ll > best[1]:
                best = (float(lc), ll, post, c1, c0)
        L, ll, post, c1, c0 = best
        e1 = (c1 + 0.5) / (c1 + 0.5).sum()
        e0 = (c0 + 0.5) / (c0 + 0.5).sum()
        pi = float(np.clip(post[informative].mean(), _PI_MIN, PI_MAX))
        if abs(ll - ll_old) < HMM_TOL * abs(ll):
            break
        ll_old = ll
    post, ll, _, _ = forward_backward(pos, emit, starts, pi, 1.0 / L, e0, e1)
    return HmmFit(pi=pi, L=L, e0=e0, e1=e1, post=post, loglik=float(ll))


def _called(post: np.ndarray, pi: float) -> np.ndarray:
    """The tract rule per locus: posterior > 0.5 and posterior odds >= BF_TRACT x prior odds."""
    post = np.asarray(post, dtype=np.float64)
    return (post > 0.5) & (post / np.maximum(1.0 - post, 1e-12) >= BF_TRACT * pi / (1.0 - pi))


def call_tracts(seq: np.ndarray, start: np.ndarray, end: np.ndarray, post: np.ndarray, pi: float
                ) -> list[Tract]:
    """Maximal runs, on one sequence, of loci passing the tract rule: from the
    first locus's start to the largest end of the run's loci; sum_post exactly rounded (math.fsum). Arrays in
    position order."""
    seq, start, end = np.asarray(seq), np.asarray(start), np.asarray(end)
    post = np.asarray(post, dtype=np.float64)
    on = _called(post, pi)
    if not on.any():
        return []
    same = seq[1:] == seq[:-1]
    head = on.copy()
    head[1:] &= ~(on[:-1] & same)
    tail = on.copy()
    tail[:-1] &= ~(on[1:] & same)
    out = []
    for a, b in zip(np.flatnonzero(head).tolist(), np.flatnonzero(tail).tolist(), strict=True):
        s = math.fsum(post[a:b + 1].tolist())  # exactly rounded: ties stay ties (module docstring)
        out.append(Tract(seq=int(seq[a]), start=int(start[a]), end=int(end[a:b + 1].max()), first=a, last=b,
                         mean_post=s / (b - a + 1), sum_post=s))
    return out


def target_decoy(target: np.ndarray, decoy: np.ndarray, scale: float) -> tuple[np.ndarray, np.ndarray]:
    """(q, p) per target score (module docstring): q from the decoy counts times `scale`
    with the +1 correction, so a lone target above every decoy is not significant; p the empirical p-value
    against the decoy scores."""
    target = np.asarray(target, dtype=np.float64)
    null = np.sort(np.asarray(decoy, dtype=np.float64))
    obs = np.sort(target)
    n_null = len(null) - np.searchsorted(null, target, side="left")   # decoy scores >= x
    n_obs = len(obs) - np.searchsorted(obs, target, side="left")      # target scores >= x
    raw = (n_null * scale + 1.0) / np.maximum(n_obs, 1)
    order = np.argsort(-target, kind="stable")
    q = np.empty(len(target))
    q[order] = np.minimum(1.0, np.minimum.accumulate(raw[order][::-1])[::-1])
    return q, (1.0 + n_null) / (1.0 + len(null))


def shortest_callable(fit: HmmFit, spacing: float
                      ) -> tuple[tuple[int | None, float | None], tuple[int | None, float | None]]:
    """((loci, bp) without flanks, (loci, bp) between CALLABLE_FLANK RS loci on each side): the fewest
    consecutive RD loci, `spacing` bp apart, whose middle locus (index k // 2 of the run) passes the tract
    rule under `fit`; bp = loci x spacing. (None, None) when no k up to CALLABLE_MAX does, or without a
    finite spacing."""
    if not (math.isfinite(spacing) and spacing >= 0):
        return (None, None), (None, None)
    e0, e1 = np.asarray(fit.e0, dtype=np.float64), np.asarray(fit.e1, dtype=np.float64)
    out = []
    for flank in (0, CALLABLE_FLANK):
        found: tuple[int | None, float | None] = (None, None)
        for k in range(1, CALLABLE_MAX + 1):
            emit = np.r_[np.full(flank, RS), np.full(k, RD), np.full(flank, RS)].astype(np.int64)
            pos = np.arange(len(emit), dtype=np.float64) * spacing
            post = forward_backward(pos, emit, np.array([0, len(emit)], dtype=np.int64), fit.pi, 1.0 / fit.L,
                                    e0, e1)[0]
            if _called(post[flank + k // 2:flank + k // 2 + 1], fit.pi)[0]:
                found = (k, k * float(spacing))
                break
        out.append(found)
    return out[0], out[1]


# ---------------------------------------------------------------- painting


def paint(cat: Catalog, trio: Trio, blocks: list[InvBlock],
          self_counts: dict[tuple[str, str], tuple[int, int]] | None = None) -> Painting:
    """Paint trio.R (module docstring): classes, the HMM fit, tracts, the
    decoy painting of trio.S with the fitted parameters, q and p, and the inverted-block flags (blocks:
    `inverted_blocks`). self_counts: (lid, genome) -> (sites, diffs) from identity.tsv's self rows, when that file
    exists. Skipped (Painting.skipped) when R has no annotation, or holds no RD or no RS locus."""
    X, Y, D = trio.R, trio.S, trio.D
    _check(cat, X, Y, D)
    none = np.zeros(0, dtype=np.int64)
    blank = {"decoy_idx": none, "decoy_cls": none.astype(np.int8), "decoy_post": np.zeros(0),
             "decoy_tracts": [], "fit": None, "donor_state": False, "tracts": [], "q": [], "p": [],
             "self_counts": self_counts}
    if not cat.annotated[X]:
        why = (f"{X} has no annotation, so it discovers no loci to paint (painting reads the "
               "loci the recipient discovers)")
        return Painting(trio=trio, idx=none, cls=none.astype(np.int8), post=np.zeros(0),
                        inv=np.zeros(0, dtype=bool), skipped=why, **blank)
    idx, cls = classes(cat, X, Y, D)
    inv = _inv(cat, blocks, X, {Y, D}, idx)
    meaning = {RD: f"{D} present, {Y} E", RS: f"{Y} present, {D} E"}
    lacking = [c for c in (RD, RS) if not np.count_nonzero(cls == c)]
    if lacking:
        why = " and no ".join(f"{PAINT_CLASSES[c]} locus ({meaning[c]})" for c in lacking)
        return Painting(trio=trio, idx=idx, cls=cls, post=np.full(len(idx), np.nan), inv=inv,
                        skipped=f"no {why} in {X}'s own calls at the {len(idx)} loci of {X}: the HMM needs both "
                                "classes", **blank)
    seq, start, end = _sites(cat, X, idx)
    emit = _emit(cls)
    decoy = None
    if cat.annotated[Y]:
        didx, dcls = classes(cat, Y, X, D)
        if np.count_nonzero(dcls <= RS):
            decoy = (didx, dcls, _emit(dcls))
    base = decoy[2] if decoy is not None else emit
    counts = np.bincount(base[base >= 0], minlength=2).astype(np.float64)
    e0 = counts + 1.0                         # initial e0: the class frequencies + 1
    e0 /= e0.sum()
    e1 = e0 * _INIT
    e1 /= e1.sum()
    fit = fit_hmm(start.astype(np.float64), emit, _starts(seq), e0, e1)
    donor_state = bool(fit.e1[RD] > fit.e0[RD])
    tracts = call_tracts(seq, start, end, fit.post, fit.pi) if donor_state else []
    if decoy is None:
        return Painting(trio=trio, idx=idx, cls=cls, post=fit.post, inv=inv, fit=fit, donor_state=donor_state,
                        tracts=tracts, q=[None] * len(tracts), p=[None] * len(tracts), decoy_idx=none,
                        decoy_cls=none.astype(np.int8), decoy_post=np.zeros(0), decoy_tracts=[], skipped=None,
                        self_counts=self_counts)
    didx, dcls, demit = decoy
    dseq, dstart, dend = _sites(cat, Y, didx)
    dpost = forward_backward(dstart.astype(np.float64), demit, _starts(dseq), fit.pi, 1.0 / fit.L, fit.e0,
                             fit.e1)[0]
    dtracts = call_tracts(dseq, dstart, dend, dpost, fit.pi) if donor_state else []
    scale = np.count_nonzero(emit >= 0) / np.count_nonzero(demit >= 0)
    q, p = target_decoy(np.array([t.sum_post for t in tracts]), np.array([t.sum_post for t in dtracts]),
                        scale)
    return Painting(trio=trio, idx=idx, cls=cls, post=fit.post, inv=inv, fit=fit, donor_state=donor_state,
                    tracts=tracts, q=q.tolist(), p=p.tolist(), decoy_idx=didx, decoy_cls=dcls,
                    decoy_post=dpost, decoy_tracts=dtracts, skipped=None,
                    decoy_inv=_inv(cat, blocks, Y, {X, D}, didx), scale=float(scale), self_counts=self_counts)


def _inv(cat: Catalog, blocks: list[InvBlock], x: str, partners: set[str], idx: np.ndarray) -> np.ndarray:
    """Whether each locus's site start on x lies inside an inverted block of x against a partner."""
    seq, start, _ = _sites(cat, x, idx)
    return inside(blocks, x, partners, seq, start)


# ---------------------------------------------------------------- per tract


def _tract_table(p: Painting, cat: Catalog, decoy: bool = False) -> list[dict]:
    """Per tract of the painting (or of its decoy): n_loci, n_RD, n_RS, youngest_k, youngest_u95, n_identical,
    inv_frac (module docstring; None where a value does not exist)."""
    X, D = (p.trio.S if decoy else p.trio.R), p.trio.D
    idx, cls, inv, tracts = ((p.decoy_idx, p.decoy_cls, p.decoy_inv, p.decoy_tracts) if decoy
                             else (p.idx, p.cls, p.inv, p.tracts))
    gx = cat.g(X)
    out = []
    for t in tracts:
        sl = slice(t.first, t.last + 1)
        c = cls[sl]
        rd = idx[sl][c == RD]
        k = cat.k[rd, gx]
        known = k[np.isfinite(k)]
        out.append({"n_loci": t.last - t.first + 1, "n_RD": len(rd), "n_RS": int(np.count_nonzero(c == RS)),
                    "youngest_k": float(known.min()) if known.size else None,
                    "youngest_u95": _youngest_u95(cat, p.self_counts, rd, X, D),
                    "n_identical": int(np.count_nonzero(age_bin(k) == 0)),
                    "inv_frac": float(np.count_nonzero(inv[sl])) / (t.last - t.first + 1)})
    return out


def _youngest_u95(cat: Catalog, counts: dict[tuple[str, str], tuple[int, int]] | None, rd: np.ndarray, X: str,
                  D: str) -> float | None:
    """The smallest u95(diffs, sites) over the RD loci `rd`, from X's self row, else D's; loci without a
    self row (with sites) are left out. None without self_counts or without any such row."""
    if counts is None:
        return None
    sites, diffs = [], []
    for lid in cat.lid[rd].tolist():
        for g in (X, D):
            c = counts.get((lid, g))
            if c is not None and c[0] > 0:
                sites.append(c[0])
                diffs.append(c[1])
                break
    return float(np.min(u95(np.array(diffs), np.array(sites)))) if sites else None


# ---------------------------------------------------------------- files


def write_paintings(paintings: list[Painting], cat: Catalog, outdir: Path, previous=()) -> list[Path]:
    """Remove the old painting files, then write tracts.<R>.bed and posterior.<R>.tsv per recipient and
    decoy_tracts.<S>.bed and decoy_posterior.<S>.tsv per sister with a decoy (module docstring); the paths
    written. Skipped paintings write nothing. Removed: the painting files named for the run's labels, and those
    in `outdir` that `previous` lists (the paths the paint stage's last marker listed: a painting of a genome no
    longer in the sheet), never another file, so a genome labeled "tracts" keeps the engine's tracts.pav.bed
    and a file of the user's own stays."""
    outdir = Path(outdir)
    old = {outdir / f.format(x) for x in cat.labels for f in PAINTING_FILES}
    old |= {Path(q) for q in previous if Path(q).resolve().parent == outdir.resolve()
            and any(fnmatch.fnmatchcase(Path(q).name, f.format("*")) for f in PAINTING_FILES)}
    for q in old:
        q.unlink(missing_ok=True)
    target: dict[str, list[Painting]] = {}
    mirror: dict[str, list[Painting]] = {}
    for p in sorted((p for p in paintings if p.skipped is None), key=lambda p: p.trio.scope):
        target.setdefault(p.trio.R, []).append(p)
        if p.scale is not None:
            mirror.setdefault(p.trio.S, []).append(p)
    paths = []
    for files, decoy in ((target, False), (mirror, True)):
        for x, ps in files.items():
            stem = "decoy_" if decoy else ""
            paths.append(_write_tracts(outdir / f"{stem}tracts.{x}.bed", ps, cat, decoy))
            paths.append(_write_posterior(outdir / f"{stem}posterior.{x}.tsv", ps, cat, decoy))
    return paths


def _sides(p: Painting, decoy: bool) -> tuple[str, str]:
    """(the painted genome, its sister): (R, S), or (S, R) for the decoy."""
    return (p.trio.S, p.trio.R) if decoy else (p.trio.R, p.trio.S)


def _write_tracts(path: Path, ps: list[Painting], cat: Catalog, decoy: bool) -> Path:
    with open(path, "w") as fh:
        fh.write("\t".join(TRACT_COLUMNS) + "\n")
        for p in ps:
            x, y = _sides(p, decoy)
            tracts = p.decoy_tracts if decoy else p.tracts
            for j, (t, v) in enumerate(zip(tracts, _tract_table(p, cat, decoy), strict=True)):
                if decoy:
                    q = pv = None                   # a decoy tract is the null, not a test
                elif p.scale is None:
                    q = pv = "none"                 # no decoy (WARNING in findings)
                else:
                    q, pv = p.q[j], p.p[j]
                row = (cat.seqids[x][t.seq], t.start - 1, t.end, f"{p.trio.D}-like",
                       min(1000, int(1000 * t.mean_post)), ".", y, p.trio.D, v["n_loci"], v["n_RD"],
                       v["n_RS"], t.mean_post, t.sum_post, q, pv, v["youngest_k"], v["youngest_u95"],
                       v["n_identical"], v["inv_frac"])
                fh.write("\t".join(tsv_field(c) for c in row) + "\n")
    return path


def _write_posterior(path: Path, ps: list[Painting], cat: Catalog, decoy: bool) -> Path:
    with open(path, "w") as fh:
        fh.write("\t".join(POSTERIOR_COLUMNS) + "\n")
        for p in ps:
            x, y = _sides(p, decoy)
            idx, cls, post, inv, tracts = (
                (p.decoy_idx, p.decoy_cls, p.decoy_post, p.decoy_inv, p.decoy_tracts) if decoy
                else (p.idx, p.cls, p.post, p.inv, p.tracts))
            names = cat.seqids[x]
            seq, start, end = _sites(cat, x, idx)
            label = np.full(len(idx), ".", dtype=object)
            for t in tracts:
                label[t.first:t.last + 1] = f"{names[t.seq]}:{t.start}-{t.end}"
            mid = f"\t{y}\t{p.trio.D}\t"
            cols = zip(cat.lid[idx].tolist(), seq.tolist(), start.tolist(), end.tolist(), cls.tolist(),
                       post.tolist(), label.tolist(), inv.tolist(), strict=True)
            fh.writelines(f"{lid}\t{names[s]}\t{a}\t{b}{mid}{PAINT_CLASSES[c]}\t{tsv_field(v)}\t{t}\t{int(i)}\n"
                          for lid, s, a, b, c, v, t, i in cols)
    return path


# ---------------------------------------------------------------- rows and findings


def _loci(p: Painting, x: str, rest: str) -> str:
    """A row's loci declaration (relations.py's grammar) for loci painted on x."""
    return f"disc={x};present={x};{rest}"


def _spacing(cat: Catalog, p: Painting) -> np.ndarray:
    """bp between consecutive informative (RD/RS) loci on one sequence of R (site starts)."""
    keep = p.cls <= RS
    seq, start, _ = _sites(cat, p.trio.R, p.idx[keep])
    gap = np.diff(start)
    return gap[seq[1:] == seq[:-1]].astype(np.float64)


def paint_rows(p: Painting, cat: Catalog) -> tuple[list[StatRow], Findings]:
    """Rows (layer pav; test paint, paint_resolution and paint_seqid; scope the trio) and findings (sections
    Painting and Dating) of one painting. A skipped painting gives its class counts and one WARNING."""
    f = Findings()
    X, Y, D, scope = p.trio.R, p.trio.S, p.trio.D, p.trio.scope
    inf_loci = _loci(p, X, f"res={Y},{D};outgroup=not_present")
    all_loci = _loci(p, X, "outgroup=none")
    n_all = len(p.idx)
    counts = {c: int(np.count_nonzero(p.cls == c)) for c in range(len(PAINT_CLASSES))}
    n_rd, n_rs = counts[RD], counts[RS]
    n_inf = n_rd + n_rs
    rows: list[StatRow] = []
    if p.skipped is not None:
        f.warn(PAINTING, f"Painting of {X} (sister {Y}, donor {D}) skipped: {p.skipped}")
        if n_all:
            rows += [StatRow("pav", "paint", scope, "all", s, v, n=n_all, loci=inf_loci, note=note)
                     for s, v, note in (("n_informative", n_inf, "RD and RS loci"),
                                        ("n_RD", n_rd, f"{D} present, {Y} E"),
                                        ("n_RS", n_rs, f"{Y} present, {D} E"))]
            rows += [StatRow("pav", "paint", scope, "all", s, v, n=n, loci=loci, note=note)
                     for s, v, n, loci, note in _emission_stats(p, True, n_inf, inf_loci,
                                                                "NA: the painting was skipped")]
            rows += _resolution(cat, p, scope, all_loci, f)
        return rows, f
    fit = p.fit
    decoy = p.scale is not None
    post_mean = float(p.post.mean())
    dec_mean = float(p.decoy_post.mean()) if decoy else math.nan
    excess = post_mean - dec_mean if decoy else math.nan
    n_q05 = sum(q is not None and q <= Q_TRACT for q in p.q) if decoy else math.nan
    gaps = _spacing(cat, p)
    sp_med, sp_mean = (float(np.median(gaps)), float(gaps.mean())) if gaps.size else (math.nan, math.nan)
    na = p.collapsed  # NA, never a pseudocount artifact (Painting.collapsed)
    (lo_k, lo_bp), (hi_k, hi_bp) = (shortest_callable(fit, sp_med) if p.donor_state and not na
                                    else ((None, None), (None, None)))
    n_inv = int(np.count_nonzero(p.inv))
    run_bp = math.nan if na else fit.L / (1.0 - fit.pi)
    em = (f"e1 (RD, RS) {fit.e1[RD]:.4g}, {fit.e1[RS]:.4g}; e0 {fit.e0[RD]:.4g}, {fit.e0[RS]:.4g}; state 1 "
          f"is {D}-like when e1[RD] > e0[RD]")
    na_note = (f"NA: the fit collapsed (pi at its floor {_PI_MIN:g}, no tract), so state 1 holds no data and "
               "this value would come from the pseudocounts")
    q_note = (f"tracts at q <= {Q_TRACT:g} (target-decoy against {Y}'s painting; scale = n informative {X} / n "
              f"informative {Y} = {p.scale:.4g})" if decoy else f"no decoy: {_no_decoy(cat, p)}")
    callable_note = (f"the fewest consecutive RD loci at the median spacing whose middle locus passes the "
                     f"tract rule; up to {CALLABLE_MAX} loci")
    spacing_note = "bp between consecutive informative loci on one sequence"
    stats = [
        ("pi", fit.pi, n_inf, inf_loci,
         f"the fitted {D}-like fraction (EM; clipped to [{_PI_MIN:g}, {PI_MAX:g}])"
         + ("; at its floor: the fit collapsed" if na else "")),
        ("mean_tract_bp", math.nan if na else fit.L, n_inf, inf_loci,
         na_note if na else
         ("L, the switch scale: between loci d bp apart the state is redrawn from (1 - pi, pi) with "
          "probability 1 - exp(-d / L)")),
        ("mean_donor_run_bp", run_bp, n_inf, inf_loci,
         na_note if na else f"L / (1 - pi): the mean {D}-like run under the model"),
        ("donor_state", math.nan if na else int(p.donor_state), n_inf, inf_loci,
         f"{na_note}; {em}" if na else em),
        *_emission_stats(p, na, n_inf, inf_loci, na_note),
        ("loglik", fit.loglik, n_inf, inf_loci, "log-likelihood of the fitted HMM"),
        ("n_informative", n_inf, n_all, inf_loci, "RD and RS loci: the emitting loci"),
        ("n_RD", n_rd, n_all, inf_loci, f"{D} present, {Y} E"),
        ("n_RS", n_rs, n_all, inf_loci, f"{Y} present, {D} E"),
        ("posterior_mean", post_mean, n_all, all_loci,
         f"mean posterior of the {D}-like state over {X}'s painted loci, unweighted"),
        ("decoy_posterior_mean", dec_mean, len(p.decoy_idx), _loci(p, Y, "outgroup=none"),
         f"the same over the decoy {Y}, painted with {X}'s fitted parameters" if decoy
         else f"no decoy: {_no_decoy(cat, p)}"),
        ("excess", excess, n_all, all_loci, "posterior_mean - decoy_posterior_mean"),
        ("n_tracts", len(p.tracts), n_inf, inf_loci,
         f"runs with posterior > 0.5 and posterior odds >= {BF_TRACT:g} x prior odds"),
        ("n_decoy_tracts", len(p.decoy_tracts) if decoy else math.nan, len(p.decoy_idx),
         _loci(p, Y, f"res={X},{D};outgroup=not_present"), "the same rule on the decoy"),
        ("n_tracts_q05", n_q05, n_inf, inf_loci, q_note),
        ("spacing_median", sp_med, n_inf, inf_loci, spacing_note),
        ("spacing_mean", sp_mean, n_inf, inf_loci, spacing_note),
        ("shortest_callable_loci_lo", _num(lo_k), n_inf, inf_loci,
         na_note if na else f"{callable_note}, without flanks"),
        ("shortest_callable_bp_lo", _num(lo_bp), n_inf, inf_loci,
         na_note if na else "shortest_callable_loci_lo x spacing_median"),
        ("shortest_callable_loci_hi", _num(hi_k), n_inf, inf_loci,
         na_note if na else
         f"{callable_note}, between {CALLABLE_FLANK} RS loci on each side (a heuristic flank)"),
        ("shortest_callable_bp_hi", _num(hi_bp), n_inf, inf_loci,
         na_note if na else "shortest_callable_loci_hi x spacing_median"),
        ("n_inv_loci", n_inv, n_all, all_loci,
         (f"painted loci inside an inverted block of {X} against {Y} or {D} (flags only; the fit ignores "
          "them)")),
    ]
    rows += [StatRow("pav", "paint", scope, "all", s, v, n=n, loci=loci, note=note)
             for s, v, n, loci, note in stats]
    rows += _resolution(cat, p, scope, all_loci, f)
    rows += _seqid_rows(cat, p, scope, inf_loci, all_loci)
    _painting_lines(cat, p, f, post_mean, dec_mean, excess, n_q05, counts, (sp_med, sp_mean),
                    ((lo_k, lo_bp), (hi_k, hi_bp)), n_inv, run_bp)
    _dating_lines(cat, p, f)
    return rows, f


def _num(v: float | None) -> float:
    return math.nan if v is None else v


def _no_decoy(cat: Catalog, p: Painting) -> str:
    """Why a painting has no decoy."""
    Y = p.trio.S
    if not cat.annotated[Y]:
        return f"{Y} has no annotation, so it discovers no loci to paint"
    return f"{Y}'s loci hold no informative (RD or RS) locus"


def _emission_stats(p: Painting, na: bool, n_inf: int, inf_loci: str, na_note: str) -> list[tuple]:
    """The emission row and the e0_RD, e0_RS, e1_RD, e1_RS rows (statistic, value, n, loci, note) of a painting:
    the fitted emissions; NA (with na_note) for a skipped or collapsed painting."""
    Y, D = p.trio.S, p.trio.D
    if p.fit is None:
        model = "emission model: nothing fitted (the painting was skipped)"
    else:
        model = "emission model: both states' emissions fitted by EM"
    rows = [("emission", "em", n_inf, inf_loci, model)]
    for state, k in (("e0", RD), ("e0", RS), ("e1", RD), ("e1", RS)):
        name = f"{state}_{PAINT_CLASSES[k]}"
        what = (f"state 0's ({Y}-like) emission probability of {PAINT_CLASSES[k]}" if state == "e0"
                else f"state 1's ({D}-like) emission probability of {PAINT_CLASSES[k]}")
        if na or p.fit is None:
            rows.append((name, math.nan, n_inf, inf_loci, na_note))
        else:
            rows.append((name, float(getattr(p.fit, state)[k]), n_inf, inf_loci, f"{what}, fitted by EM"))
    return rows


def _resolution(cat: Catalog, p: Painting, scope: str, loci: str, f: Findings) -> list[StatRow]:
    """paint_resolution rows: the share of R's painted loci where S and D are resolved, from R's own calls."""
    X, Y, D = p.trio.R, p.trio.S, p.trio.D
    if not len(p.idx):
        return []
    fracs = {}
    for g in (Y, D):
        fracs[g] = int(np.count_nonzero(cat.pcls(X, g)[p.idx] >= 0)) / len(p.idx)
    return resolution("paint_resolution", scope, fracs, len(p.idx), loci, f, PAINTING)


def _seqid_rows(cat: Catalog, p: Painting, scope: str, inf_loci: str, all_loci: str) -> list[StatRow]:
    """paint_seqid rows, one set per R sequence holding painted loci (fai order; stratum = its name)."""
    X = p.trio.R
    seq, _, _ = _sites(cat, X, p.idx)
    rows = []
    for s in np.unique(seq).tolist():
        m = seq == s
        c = p.cls[m]
        n_rd, n_rs = int(np.count_nonzero(c == RD)), int(np.count_nonzero(c == RS))
        name, n = cat.seqids[X][s], int(np.count_nonzero(m))
        share = n_rd / (n_rd + n_rs) if n_rd + n_rs else math.nan
        rows += [StatRow("pav", "paint_seqid", scope, name, "posterior_mean", float(p.post[m].mean()), n=n,
                         loci=all_loci, note="mean posterior over the sequence's painted loci"),
                 StatRow("pav", "paint_seqid", scope, name, "n_RD", n_rd, n=n, loci=inf_loci),
                 StatRow("pav", "paint_seqid", scope, name, "n_RS", n_rs, n=n, loci=inf_loci),
                 StatRow("pav", "paint_seqid", scope, name, "class_share", share, n=n_rd + n_rs,
                         loci=inf_loci, note="RD / (RD + RS)")]
    return rows


def _kb(v: float | None) -> str:
    return "nan" if v is None or not math.isfinite(v) else f"{v / 1e3:,.1f} kb"


def _n_loci(k: int) -> str:
    return f"{k} locus" if k == 1 else f"{k} loci"


def _floor_line(X: str, n_tracts: int, n_decoy: int) -> str | None:
    """The findings line on the +1 corrections' floors, naming each floor above Q_TRACT with its own reason:
    q >= 1/n_tracts (too few tracts), p_decoy >= 1/(1 + n_decoy) (too few decoy tracts). None when neither
    floor is above Q_TRACT, or without a tract."""
    if not n_tracts:
        return None
    parts = []
    if 1 / n_tracts > Q_TRACT:
        parts.append(f"q >= 1/{n_tracts} = {1 / n_tracts:.3g}: too few tracts for a target-decoy q to reach "
                     f"{Q_TRACT:g}")
    if 1 / (1 + n_decoy) > Q_TRACT:
        parts.append(f"p_decoy >= 1/{1 + n_decoy} = {1 / (1 + n_decoy):.3g}: too few decoy tracts for a "
                     f"per-tract p-value to reach {Q_TRACT:g}")
    if not parts:
        return None
    return (f"Painting of {X}: {n_tracts} tract(s) and {n_decoy} decoy tract(s), and the +1 corrections keep "
            + "; ".join(parts) + ", whatever the evidence")


def _painting_lines(cat: Catalog, p: Painting, f: Findings, post_mean: float, dec_mean: float, excess: float,
                    n_q05: float, counts: dict[int, int], spacing: tuple[float, float],
                    callable_: tuple[tuple[int | None, float | None], tuple[int | None, float | None]],
                    n_inv: int, run_bp: float) -> None:
    X, Y, D = p.trio.R, p.trio.S, p.trio.D
    fit, decoy = p.fit, p.scale is not None
    who = f"the {len(p.idx)} loci {X} discovers, each classed by {X}'s own calls"
    line = (f"Painting of {X} (sister {Y}, donor {D}; {who}; {counts[RD] + counts[RS]} informative: "
            f"{counts[RD]} RD with {D} present and {Y} E, {counts[RS]} RS with {Y} present and {D} E): "
            f"{D}-like posterior mean {post_mean:.3f}")
    if decoy:
        line += (f" against {dec_mean:.3f} in the decoy {Y} (excess {excess:+.3f}); {len(p.tracts)} "
                 f"tract(s), {len(p.decoy_tracts)} in the decoy, {n_q05} at q <= {Q_TRACT:g}")
    else:
        line += f"; {len(p.tracts)} tract(s), no q-values"
    if p.collapsed:
        line += f"; pi at its floor {_PI_MIN:g}"
    else:
        line += (f"; switch scale L (mean_tract_bp) {_kb(fit.L)}, mean {D}-like run L / (1 - pi) "
                 f"(mean_donor_run_bp) {_kb(run_bp)}, pi {fit.pi:.3f}")
    f.add(PAINTING, line)
    if p.collapsed:
        f.add(PAINTING, f"Painting of {X}: the fit collapsed (pi at its floor {_PI_MIN:g}, no tract): no "
                        f"{D}-like ancestry is detectable in this trio. donor_state, L (mean_tract_bp), "
                        "mean_donor_run_bp and the shortest callable tract are NA: state 1 holds no data, so "
                        "they would come from the pseudocounts")
    floor = _floor_line(X, len(p.tracts), len(p.decoy_tracts)) if decoy else None
    if floor:
        f.add(PAINTING, floor)
    if not p.donor_state and not p.collapsed:
        f.warn(PAINTING, f"Painting of {X}: no {D}-like state (the fitted second state is not enriched for "
                         f"RD loci: e1[RD] {fit.e1[RD]:.3g} <= e0[RD] {fit.e0[RD]:.3g}), so no tract is "
                         f"called and the posterior is not a {D}-like probability")
    if not decoy:
        f.warn(PAINTING, f"Painting of {X}: no decoy ({_no_decoy(cat, p)}), so tract q-values and decoy "
                         "p-values are written none and the excess over the decoy is not estimated")
    if fit.pi >= PI_MAX:
        f.add(PAINTING, f"Painting of {X}: the fitted {D}-like fraction pi reached its cap PI_MAX = "
                        f"{PI_MAX:g} (a recipient more {D}-like than {Y}-like would be {D}'s sister: check "
                        "the roles)")
    f.add(PAINTING, f"Painting of {X}: {counts[OLD]} loci an outgroup carries in {X}'s own call (class old: "
                    f"older than the ingroup split), {counts[MISSING]} with {Y} or {D} unresolved, "
                    f"{counts[BOTH]} both and {counts[NEITHER]} neither enter the HMM as missing data")
    (lo_k, lo_bp), (hi_k, hi_bp) = callable_

    def span(k: int | None, bp: float | None) -> str:
        return f"not callable within {CALLABLE_MAX} loci" if k is None else f"{_n_loci(k)} (about {_kb(bp)})"
    head = (f"Painting resolution of {X}: informative loci every {_kb(spacing[0])} along a sequence (median; "
            f"mean {_kb(spacing[1])}); ")
    if p.collapsed:
        tail = "shortest callable tract NA (the fit collapsed)"
    elif p.donor_state:
        tail = (f"shortest callable tract {span(lo_k, lo_bp)} without flanks, {span(hi_k, hi_bp)} between "
                f"{CALLABLE_FLANK} RS loci on each side ({CALLABLE_FLANK} is a heuristic flank)")
    else:
        tail = f"no shortest callable tract without a {D}-like state"
    f.add(PAINTING, head + tail)
    f.add(PAINTING, f"Painting of {X}: {n_inv} of the {len(p.idx)} painted loci lie inside inverted blocks "
                    f"of {X} against {Y} or {D} (posterior column inv; tract column inv_frac); the fit "
                    "ignores them (flags only)")


def _dating_lines(cat: Catalog, p: Painting, f: Findings) -> None:
    """The Dating lines: the median youngest K over tracts and the tracts holding an identical-LTR RD
    insertion, with their caveats; the youngest_u95 line only with identity.tsv's self rows."""
    X, D = p.trio.R, p.trio.D
    gx = cat.g(X)
    table = _tract_table(p, cat)
    if not np.isfinite(cat.k[p.idx[p.cls == RD], gx]).any():
        f.add(DATING, f"Painting of {X}: youngest insertion per tract skipped: no K2P for {X}'s copies at "
                      "its RD loci (an annotation without LTR identity)")
    elif not p.tracts:
        f.add(DATING, f"Painting of {X}: youngest insertion per tract: no tract called")
    else:
        ks = [v["youngest_k"] for v in table if v["youngest_k"] is not None]
        n_ident = sum(v["n_identical"] > 0 for v in table)
        med = f"median {np.median(ks):.4g} over the {len(ks)} of {len(table)} tracts with a K" if ks else (
            f"none of the {len(table)} tracts has a K at its RD loci")
        f.add(DATING, f"Youngest insertion per tract of {X} (donor {D}; the smallest K2P of {X}'s copy over "
                      f"each tract's RD loci, from the annotation): {med}; {n_ident} tract(s) hold an "
                      "identical-LTR (K = 0) RD insertion. The admixture is younger than any insertion it "
                      "transferred. Caveats: K = 0 is not age 0 (a few hundred LTR sites without a "
                      "difference bound the age only from above), and LTR-LTR gene conversion, frequent in "
                      "large plant genomes such as maize (Cossu et al. 2017, doi:10.1093/gbe/evx260), "
                      "makes K too young, so the bound can be too recent")
    if p.self_counts is not None:
        us = [v["youngest_u95"] for v in table if v["youngest_u95"] is not None]
        text = (f"median {np.median(us):.4g} over the {len(us)} of {len(table)} tracts with a self row"
                if us else f"no self row at the RD loci of the {len(table)} tract(s)")
        f.add(DATING, f"youngest_u95 per tract of {X} (identity.tsv's self rows, exact counts: the smallest "
                      "one-sided 95% Poisson upper bound of LTR-LTR divergence over each tract's RD loci, "
                      f"from {X}'s copy, else {D}'s): {text}")
