# Task 20 report
Implemented src/ltrpav/outputs/{__init__,tables,vcf,tracks,manifest}.py and tests/test_outputs.py (10 tests).
- write_tracks signature: (loci, samples, outdir, seq_order, seq_lengths) -- seq_lengths added for ##sequence-region.
- VCF: INFO DISC is Number=. (comma-joined list); FAM/SF/DISC percent-encode ; , = whitespace %. Unplaced reasons:
  ref_state_not_placeable, no_coordinates, seqid_not_in_reference, starts_at_base_1. Unplaced file: <stem>.unplaced.tsv
  (pav.vcf.gz -> pav.unplaced.tsv). K = median of member genomes' K; AA only when NE>0.
- GFF3 escaping: ; = & , % and control chars as %XX (also applied to each label in states=).
- Manifest deps via importlib.metadata and best-effort tool calls (10 s timeout; FastGA: first usage line).
TDD: RED = collection error (ModuleNotFoundError ltrpav.outputs.manifest); GREEN = 10 passed; full suite passes, ruff clean.
Test cmd: mamba run -n ltrpav pytest -q ; mamba run -n ltrpav ruff check src tests
bcftools view -H (exit 0):
chr1 100 L0000001 T <INS:ME:LTR> . . END=100;SVTYPE=INS;SVLEN=5000;FAM=RLG_1;SF=Gypsy;K=0.02;DISC=A;NE=1;AA=T GT:ST:TR 1:P:annot 0:E:high .:D:low
chr1 204 L0000002 T <INS:ME:LTR> . . END=204;...;FAM=A%3BB%2CC;...;DISC=B,C;NE=1;AA=T GT:ST:TR 0:E:high 1:S:medium 1:P:annot
bcftools query -f '%ID\t[%GT ]\n': "L0000001  1 0 ." / "L0000002  0 1 1"
Determinism test: every text output + vcf.gz byte-identical across two writes.
Concerns: none material; END=POS with SVLEN set (as ruled). Commit: Add TSV, VCF, GFF3/BED and manifest outputs.
