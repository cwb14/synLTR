#!/usr/bin/env python3
"""Score the whole-genome k-mer comparator (wg_kmer.py output) the same way as ltrmix's LTR-RT statistics:
D on donor (TIL18) windows with a 5-Mb block jackknife, recipient (B73) window share vs ELAI at several scales
(1000 circular shifts), and the chromosome ranking (Yang: chr5, 8, 9 depleted)."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import argparse
import sys

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

sys.path.insert(0, "/data2/chris/maize_introgression/benchmark/scripts")
from eval_real import load_truth, shift_test  # noqa: E402


def jack(a, b, blk):
    ub, inv = np.unique(blk, return_inverse=True)
    A, B = np.bincount(inv, a, len(ub)), np.bincount(inv, b, len(ub))
    D = (A.sum() - B.sum()) / (A.sum() + B.sum())
    jk = np.array([((A.sum() - A[i]) - (B.sum() - B[i])) / (A.sum() + B.sum() - A[i] - B[i]) for i in range(len(ub))])
    se = np.sqrt((len(jk) - 1) / len(jk) * ((jk - jk.mean()) ** 2).sum())
    return D, se


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("prefix")
    ap.add_argument("--nperm", type=int, default=1000)
    a = ap.parse_args()
    t = load_truth()
    d = pd.read_csv(f"{a.prefix}.TIL18.tsv", sep="\t")
    D, se = jack(d.with_B73v5.values.astype(float), d.with_TIL01.values.astype(float),
                 (d.chrom + ":" + (d.start // 5_000_000).astype(str)).values)
    print(f"D(single-copy k-mers; B73,TIL01;TIL18) on TIL18 windows = {D:+.4f} +- {se:.4f} (Z = {D / se:.1f})")
    b = pd.read_csv(f"{a.prefix}.B73v5.tsv", sep="\t")
    b["c"] = b.chrom.str.extract(r"_(chr\d+)$")[0]
    b["score"] = b.with_TIL18 / (b.with_TIL18 + b.with_TIL01).replace(0, np.nan)
    tt = t[t["B73.amp"] > -900]
    for win in (100_000, 500_000, 1_000_000, 2_000_000, 5_000_000, 10_000_000):
        rows = []
        for c, g in b.groupby("c", sort=False):
            wi = (g.start // win).values
            n = int(wi.max()) + 1
            s1 = np.bincount(wi, g.with_TIL18.values, n)
            s2 = np.bincount(wi, g.with_TIL01.values, n)
            gt = tt[tt.chrom == c]
            ti = (gt.pos // win).astype(int).values
            ti = ti[ti < n]
            tm = np.bincount(ti, gt["B73.amp"].values[: len(ti)], n)
            tn = np.bincount(ti, minlength=n)
            rows.append(pd.DataFrame(dict(c=c, score=np.where(s1 + s2 > 0, s1 / np.maximum(s1 + s2, 1), np.nan),
                                          truth=np.where(tn >= 5, tm / np.maximum(tn, 1), np.nan))))
        w = pd.concat(rows, ignore_index=True)
        r, p, n = shift_test(w, a.nperm)
        print(f"window {win / 1e6:g} Mb: share vs ELAI r={r:+.3f} p={p:.4f} n={n}")
    ch = b.groupby("c")[["with_TIL18", "with_TIL01"]].sum()
    ch["share"] = ch.with_TIL18 / (ch.with_TIL18 + ch.with_TIL01)
    ch["ELAI"] = tt.groupby("chrom")["B73.amp"].mean() / 2
    ch = ch.loc[sorted(ch.index, key=lambda x: int(x[3:]))]
    print(ch.round(4).to_string())
    print("three lowest by share:", sorted(ch.share.sort_values().index[:3], key=lambda x: int(x[3:])),
          " Spearman vs ELAI:", round(spearmanr(ch.share, ch.ELAI).correlation, 3))


if __name__ == "__main__":
    main()
