# Task 4 review (74c9fd8..aa89e7b): trio roles and tests

Scope: src/ltrpav/analysis/trio.py (470 lines, new) and tests/test_trio.py (271 lines, new). Outside the diff I
read only what the named risks needed:
- catalog.py: `pcls_by`, `ptier_by`, `proj_site`, `cluster_keys`, `age_bin` and the own-call join;
- relations.py: `discover`, `_first_member`, `eligible_fallback` and `sister_pair`;
- stats.py: `jackknife`, `d_ratio`, `block_ids` and `resolution`;
- loci.py's docstring (first member element, K2P);
- catalog_toy.py's simulator.

The checkout stayed read-only: git status is clean, and pytest ran with `--basetemp` outside the checkout and
no cache provider. Probes and their outputs are in /data2/chris/maize_introgression/benchmark_pav/plan2_reviews/task4/.
main3 is untouched:
- no file in it is newer after my runs than before (`find -newer`);
- the mtimes of loci.tsv and work/checksums.json are unchanged;
- my main3 recomputation never loads a Catalog, so it writes no cache.

I did not rerun the full suite.

## Spec Compliance: ✅

| Brief item | Status | How checked |
|---|---|---|
| Interfaces: `Trio` (frozen, `scope`), `d_pav`, `trios`, `trio_tests`, `second_donors`, `f4_ratio` | ✅ | Names, signatures and return shapes match the brief. |
| Counted loci = `discover(cat, R, S, D, dist, "E")`, every state from the discoverer's own calls | ✅ | Every state goes through `pcls_by`/`ptier_by` on `c.gstar`; main3 was reproduced from the raw pair files (below). |
| `d_pav`: a/b patterns, blocks from `proj_site(gstar, D)`, `jackknife(d_ratio)` on `c.rows & keep` | ✅ | trio.py:87-120; main3 gives 425 blocks, exact. |
| `trios`: fixed trio (distinct ingroup, else AnalysisError); sheet-order combinations; R by sign; nan keeps pair[0]; `roles`/`source`; fewer than three genomes skipped with the line | ✅ | The brief's tests, plus my four-ingroup probe (four trios, no error). |
| `trio_tests`: resolution over `cand`; outgroup filter (row plus a line to two decimals); strata all / K bins / high_tier / nested_collapsed / no_outgroup_filter; no rows for an empty stratum; the no-K line; skip with a WARNING when `discover` is None | ✅ | Tests, and every main3 row recomputed. |
| Gradient: dD = D(K=0) - D(K>=0.01), one jackknife over the union of blocks, row and stratum names, "Dating" | ✅ as specified | main3 matches exactly. I1 is about how this jackknife behaves at a degenerate bin. |
| f4-ratio: num/den on the D_pav rows with D2 resolved, f = Σnum/Σden on D's blocks, scope `R,S;D;D2`, resolution rows | ✅ as specified | The brief's toy gives (2, 4, 0.5, 1.0). I2 is a path the brief does not address. |
| `second_donors`: dist[D, g] < min of the four cross distances | ✅ | trio.py:406-420. A nan never qualifies, which is a fix the implementer found. |
| The brief's 12 tests | ✅ | An AST comparison with the brief's code block finds them identical, except `f` → `_` in `test_roles_from_sign` (RUF059). Every assertion is verbatim. |
| Global: DESIGN 7.1/7.3, plan review C1 and I2, conflict 4, missing never absent, every row declares `loci`, no tuned threshold, pytest -W error, ruff, no attribution | ✅ | 18 passed under -W error (19.3 s); ruff clean; commit aa89e7b is by cwb14 with the specified message and no trailers; no new constant. |

⚠️ notes:
- I1 is a weakness of the prescribed method, not a deviation. The brief's own test asserts `dD.z > 0` on the
  admixed toy, whose K=0 bin is 92/0, which is exactly the degenerate case.
- I2 is the f4-ratio under fallback when the second donor is also the discovering genome. The brief does not
  cover this path.
- The ten judgment calls the controller accepted are built as the report describes. I checked decisions 1, 2,
  3, 5 and 7 in the rows.

## Independent verification

### main3, the headline, recomputed without ltrpav (indep_main3.py)

**Inputs.** The script reads:
- loci.tsv's `TIL18_eid` (the first member element), seqid, start, end and k;
- the three pair files TIL18__{B73,TIL01,Zd}, joined by eid;
- TIL18's element table (parent links);
- TIL18.fa.fai (seqid order).

**Jackknife.** It is written separately: blocks keyed on (seqid, mid // 5 Mb), delete-one, non-finite
pseudovalues dropped, se = sqrt((m-1)/m Σ(p - p̄)²). The nested collapse walks the outermost ancestor from
the parent column itself.

| stratum | counted | n_RD / n_SD | D | se | Z | blocks |
|---|---|---|---|---|---|---|
| all | 14,067 | 1,317 / 724 | +0.2905 | 0.0392 | 7.42 | 425 |
| K=0 | 889 | 32 / 8 | +0.6000 | 0.1245 | 4.82 | 351 |
| 0<K<0.01 | 4,155 | 320 / 77 | +0.6121 | 0.0519 | 11.78 | 424 |
| K>=0.01 | 9,023 | 965 / 639 | +0.2032 | 0.0400 | 5.08 | 420 |
| high_tier | 12,581 | 1,162 / 619 | +0.3049 | 0.0423 | 7.21 | 420 |
| nested_collapsed | 1,776 | 1,136 / 640 | +0.2793 | 0.0382 | 7.30 | 370 |
| no_outgroup_filter | 42,722 | 2,840 / 1,543 | +0.2959 | 0.0330 | 8.96 | 501 |
| gradient dD | 1,644 informative | (32/8) − (965/639) | +0.3968 | 0.1268 | 3.13 | 421 |

Every row equals the implementer's stats rows to the printed digits. Other checks:
- **Outgroup filter:** 99,549 of 123,019 removed (0.8092): 9,957 with Zd present, 89,592 with Zd missing.
- **Resolution:** B73 0.7282 and TIL01 0.7102 over 23,470 candidates.
- **Member attributes:** at all 123,019 TIL18 loci, loci.tsv's TIL18 site and K equal its first member
  element's.

**Sensitivity to the multi-member rule.** I counted every TIL18 element (124,641, including 1,622 extra
members) instead of one per locus:
- all: D +0.2894 ± 0.0392, Z 7.38 (1,330 / 733);
- nested_collapsed: +0.2766, Z 7.21;
- dD: +0.4093, Z 3.30.

The rule moves nothing that matters.

**Conclusion.** D_pav(B73,TIL01;TIL18) = +0.29, Z 7.4 is computed exactly as specified: TIL18's own calls,
blocks on TIL18's own coordinates, and no merged state.

### Risk 1: the counted-loci rule
- **State reads.** Every state read in trio.py is `pcls_by` or `ptier_by` on `c.gstar`. trio.py reads only two
  catalog arrays directly:
  - `cat.k[i, gstar[i]]`, the discoverer's own K2P;
  - `cat.seq/start/end[i, gstar[i]]`, the discoverer's own element, used only for the collapse order.

  Both come from the discoverer's annotation.
- **Merged states.** They enter only through `sister_pair` (which picks the pair, DESIGN 7.2) and
  `pav_distances` (the second-donor rule, LTRmix).
- **The sisters' data.** Their membership, eids and tiers never enter.
- **gstar.** It is never R or S, because `eligible_fallback` excludes them.
- **Multi-member loci.** They use the first member's calls, consistently. The element-level count above shows
  no effect.
- **Fallback D_pav.** The implementer's `test_fallback_counts_from_the_fallback_calls` covers X's calls and X's
  K. The f4 path under fallback is I2.

### Risk 2: the jackknife
- **Blocks.** `proj_site(gstar, D)` gives D's member coordinates when D discovers, or X's call site in D under
  fallback. Block ids never span seqids. The exact 425-block match pins them to TIL18.
- **Pseudovalues.** Each is `d_ratio` over the kept rows. Blocks with no informative locus give pseudovalues
  equal to the estimate, which barely moves se. For example, on the outgroup-missing toy the nested_collapsed
  se is 0.0984 against 0.0986 for all.
- **Gradient.** One keep mask runs over the union of the two bins, so each pseudovalue drops a block from both
  bins. The implementer's hand-jackknife test and my main3 value agree. The degenerate case is I1.

### Risk 3: nested collapse
The code keeps the informative counted rows only, orders them by the discoverer's (seq, start, -end), and keeps
the first per (discoverer, outermost annotated ancestor). My version gives 1,136 / 640 on main3, the same.
A non-informative host hides no child: the brief's 10 + 1 test.

### Risk 4: roles and the null distribution of Z
- **Construction.** `discover` is symmetric in x and y, so the D_pav that `trio_tests` writes equals the value
  that decided R. D_pav >= 0 by construction.
- **Effect on Z.** The fold makes the primary Z half-normal under the null. The |Z| >= 3 bar keeps the two-sided
  size (about 0.0027), and the primary findings line says so.
- **Fresh seeds 26-75** (default toy, data roles): Z >= 3 in 0 of 50; mean Z 0.83 (half-normal 0.80); sd 0.63
  (half-normal 0.60); max 2.40; jackknife se / binomial se 0.98.
- **Unequal annotation** (members R 0.95 / S 0.5, p_missing 0.3, 3,000 per seqid), seeds 4-13: 0 of 10 with
  Z >= 3; mean 0.73; max 2.31.
- **Unequal resolution** (p_missing R 0.05 / S 0.5), seeds 1-10: 0 of 10; mean 0.97; max 2.93.
- **Gradient null.** No toy run reaches it: the toy draws informative loci at K=0 only inside tracts, so every
  null run skips the gradient, and no test covers its null. In my script only, I gave the toy's R+D and S+D
  patterns K 0 or 0.02 (164-246 informative K=0 loci per run) and ran 40 seeds:
  - fixed roles: mean Z +0.04, sd 1.05;
  - data roles: mean −0.00, sd 1.05;
  - none with |Z| >= 3.

  Data roles do not bias dD: under the null, Cov(dD, D_all) ≈ 0 to first order.

### Report claims and other checks
- **Toy claims reproduced:**
  - admixed seed 1: +0.2875 ± 0.0613, Z 4.69; K=0 +1.000 (n 92, se 0); dD +0.8712 ± 0.0636, Z 13.69;
  - resolution: 0.847 / 0.410 over 2,141;
  - outgroup filter: 0.848 of 3,387.
- **Edge configurations:** with no outgroup, two outgroups, or four ingroup genomes (four trios), `trios` and
  `trio_tests` run without error under -W error (probe_edges.py).
  - With no outgroup, the line reads "0.00 ... names no outgroup".
  - The fourth trio, D,D2;S, has no counted locus and correctly writes no D_pav rows. The StopIteration in
    probe_edges.out is my script's own lookup of that row.

## Strengths
- **The counted rule is exact.** It follows DESIGN 7.1, build decision 5 and plan review C1 to the letter, and
  the headline reproduces to the last digit from the raw files.
- **One code path.** Every stratum and the joint gradient go through `d_pav` with a keep mask, so the strata
  cannot drift from the primary count. The gradient is one statistic with one delete-one jackknife, as
  specified.
- **The fold is stated.** The findings line says D_pav >= 0 by construction and that |Z| is the test, and the
  calibration bears this out.
- **The outgroup filter is informative.** Its present/missing split shows on main3 that 89,592 of the 99,549
  removals are Zd being unresolved, not old insertions, and no_outgroup_filter (+0.296, Z 8.96) answers that
  concern directly.
- **Rows declare their loci.** Every row has `loci`, including `outgroup=none` on the unfiltered stratum.
- **Self-review caught a real bug.** Python's `min` is order-dependent with a nan, which let a second donor
  qualify with an unresolved distance.
- **Useful extra tests.** They include a hand jackknife of the gradient, fallback counting from X's own calls,
  and the medium-tier T call left out of high_tier.

## Issues

### Critical
None.

### Important

**I1. When the K=0 bin sits at D = ±1 or in one block, the gradient's Z leaves out that bin's sampling variance, so a single young locus gives Z ≈ 14.**
Location: trio.py:366-400 (`_gradient`; the jackknife is at :387).

- **What.** `jackknife(d_young - d_old)` runs over the union of blocks. The young bin can drop out of the
  variance in two ways:
  - every informative K=0 locus is R+D (or every one is S+D): d_young is ±1 in every pseudovalue;
  - all of them sit in one block: that block's pseudovalue is nan, and `stats.jackknife` drops it.

  Either way, se is the K>=0.01 bin's alone.
- **Evidence** (probe_gradient.py: one young R+D locus beside 60 old loci split 30/30):
  - dD = +1.000 ± 0.072, Z 13.81. The "Dating" line then says "an excess concentrated in young insertions is
    gene flow (DESIGN 7.3)".
  - With two and three young R+D loci: Z 13.78 and 13.76.
  - The admixed toy shows the same mechanism: its K=0 row is 92/0 with se 0 and z nan, while dD's se, 0.0636,
    equals the K>=0.01 row's se, giving Z 13.69.
- **Why it matters.**
  - Under the null, a K=0 bin with n informative loci sits at the boundary with probability 2^(1-n): 1 for
    n = 1, 0.25 for n = 3. Z is then about |±1 − D_old| / se_old, usually far above 3, so a sparse young bin
    makes a false "gene-flow gradient" at a high rate.
  - main3 is not affected. Its K=0 bin is 32/8 over many blocks, so the jackknife sees that bin's variance, and
    dD +0.397 (Z 3.13) stands as computed.
  - Sparse young bins are the expected case elsewhere: older introgression, low LTR activity, or small genomes
    such as the ~300-Mb citrus inputs for the second lineage (DESIGN 10.4). DESIGN 10.2's null bar would fail
    there.
  - The D_pav stratum rows themselves are safe: se 0 gives z nan.
- **Fix.**
  - In `_gradient`, detect a bin whose variance a delete-one jackknife cannot estimate: n_RD or n_SD is 0 in
    the bin, or its informative loci lie in fewer than 3 distinct blocks (the jackknife's own floor). In that
    case write se and z as nan, keep dD, and add a "Dating" line naming the bin and its counts. A variance that
    is not estimated is not zero, and the rule adds no tuned constant.
  - This conflicts with the brief's assertion at tests/test_trio.py:99 (`dD.z > 0` on the 92/0 admixed toy), so
    it needs a controller ruling. That assertion could compare the two bins' D values instead.
  - If the ruling keeps the Z, the minimum is a WARNING plus a row note saying that se and Z cover the other
    bin only and overstate the evidence.
  - Either way, add a test: one young R+D locus beside balanced old loci must not give a finite Z without the
    caveat.

**I2. Under fallback discovery, a second donor that is itself the discovering genome is present by construction, so the f4-ratio's den is a different statistic.**
Locations: trio.py:234 (`second_donors` in `trio_tests`), :430-465 (`_f4`; the rows are selected at :437) and
:423-427 (`f4_ratio`).

- **What.** When D has no annotation, gstar is the fallback genome X, and `pcls_by(gstar, X)` reads X's own
  column, which is P at every member. If X is also the second donor (D2 = X):
  - the den's term [S present, X E] is identically 0;
  - the count is restricted to the loci X carries;
  - the resolution row reports resolved_X = 1.0.
- **Evidence** (probe_f4_fallback.py: the same true insertions over R, S, D, X, O, written twice):
  - D annotated: disc D, second donor X; num 2, den 5, f 0.400.
  - D unannotated: disc X, second donor X; num 2, den 7, f 0.286, written as the admixture fraction with no
    warning.
- **Why it is likely.**
  - An eligible fallback genome splits with D from R and S by the four-point condition. A second donor is D's
    closest genome among the four. These are usually the same genome.
  - So whenever fallback discovery and the f4-ratio meet, this collision is the common case, not a corner.
  - main3 has neither: TIL18 is annotated and there is no second donor.
- **Fix.**
  - In `trio_tests` and `f4_ratio`, skip any D2 in `c.disc`, with a findings line such as: "f4-ratio with
    second donor X skipped: X discovers the counted loci (D has no annotation), so X is present at every one
    by construction".
  - The alternative, keeping only rows that other fallback genomes discover, would condition on X's annotation
    missing the copy. Skipping is the clean rule.
  - Add the probe as a test.

### Minor
- **M1. No test separates D's sites from the other genomes' sites.** tests/test_trio.py.
  - The toy places every genome at the same position unless `inversion` is set. Blocks taken from R's, S's or
    merged coordinates would therefore pass the suite.
  - Fallback blocks (X's call site in D) are untested too.
  - Only my main3 recomputation pins the blocks to TIL18.
  - Fix: add a small run with `inversion=("D", ...)` or distinct seqids, asserting nblocks and se against a hand
    jackknife on D's sites, plus one under fallback.
- **M2. No test covers the gradient's null**, since the toy draws no informative K=0 locus outside tracts. My
  patched-pattern probe shows the gradient is calibrated. A hand-built run with balanced R+D and S+D loci at
  K=0 and K>=0.01 would pin this, next to I1's guard.
- **M3. `f4_ratio` loses its WARNINGs.** trio.py:423-427. The public `f4_ratio` recomputes `discover` and
  discards its findings, so its den <= 0 and resolution WARNINGs are lost to any caller other than
  `trio_tests`. Its rows-only return follows the brief. Say so in its docstring.
- **M4. The roles row says "data" when sheet order decided.** trio.py:176. When D_pav is nan, the row's value
  is `data`, although sheet order chose the recipient (the note and the WARNING say so). A value of
  `sheet order` would be accurate. This is presentation only.
- **M5. nested_collapsed's `n` means something different.** Its `n_RD`/`n_SD` rows count informative loci
  only (1,776 on main3), under the same note as the other strata, "n: the counted loci". There, n includes the
  uninformative counted loci (14,067 for all). This is correct by the stratum's definition but misleading
  when n is compared across strata. Write "n: the informative loci kept" in that stratum's note.
- **M6. Private helpers are imported.** trio.py:58 imports `_check_trio` and `_fallback_reasons` from relations.
  The controller accepted this. Make them public when relations.py is next touched.

## Assessment
**Task quality: Needs fixes.** 0 Critical, 2 Important, 6 Minor.

**The headline is sound.** D_pav(B73,TIL01;TIL18) = +0.2905 ± 0.0392 (Z 7.42) and all six check strata and
the gradient reproduce exactly from the raw pair files, on TIL18's own calls and coordinates. The toy null holds
on 70 fresh seeds.

**Two paths are not sound:**
- the gradient's Z when the young bin is degenerate (I1), which reaches findings.txt with a gene-flow reading;
- the f4-ratio when the fallback discoverer is also the second donor (I2), which gives a wrong value silently.

Neither affects main3, but both are reachable in configurations the design supports. I1's principled fix
conflicts with one assertion in the brief, so it needs a ruling.

## Re-review (fix round 1: aa89e7b..f655060)

**Scope.** The fix diff only: trio.py, test_trio.py, constants.py and stats.py, checked against the controller's
rulings.
- **Read-only.** Probes and outputs are the `rr_*` files in
  /data2/chris/maize_introgression/benchmark_pav/plan2_reviews/task4/.
- **main3.** I read it through my own symlinked view (view/, with its own work/). main3 is unchanged: no new file,
  and the mtimes of loci.tsv and checksums.json are the same.

### Verdicts

| Finding | Verdict | Evidence |
|---|---|---|
| I1: the gradient's Z at a degenerate bin | ADDRESSED | `_why` and `_guard` cover every jackknifed ratio, as ruled: D_pav and its strata, dD per bin, and f on its four classes. My three sparse probes (one, two or three young R+D loci) now give dD +1.000 with se and z nan, where before they gave Z 13.8. The line reads "not testable by the block jackknife: K=0: no S+D locus (n_RD 1, n_SD 0)" and never mentions gene flow. My probe is now `test_gradient_sparse_young_bin_not_testable`. The 92/0 assertion was replaced as ruled. Sparse null below: 28 of 55 runs at \|Z\| >= 3 before, 0 after. |
| I2: f4 when the second donor discovers | ADDRESSED | `_f4`, used by `trio_tests` and `f4_ratio`, skips a D2 in `c.disc` with the line the ruling asks for. Rerunning my probe: D annotated still gives num 2, den 5, f 0.4; fallback now writes no f4 rows. Tested by `test_f4_second_donor_that_discovers`. |
| M1: blocks on D's sites untested | ADDRESSED | `test_blocks_on_d_sites` mirrors D's chr1 sites; its hand values check out (mirrored mids 419,926.5 − p give blocks 10, 9, 9, 8, 8, 7). I monkeypatched `_blocks` onto R's or S's sites in a scratch process: the test fails both mutants and passes the unmodified code, for D discovering and under fallback. |
| M2: gradient null untested | ADDRESSED | `test_gradient_balanced_bins`: by hand, the pseudovalues are −1, +1 and 0, so se = sqrt(4/3) and Z 0. It is testable and "not significant". |
| M3: f4_ratio loses its WARNINGs | ADDRESSED | The docstring states it returns rows only and discards its findings, and that it returns [] for a discovering D2. |
| M4: roles row says "data" | ADDRESSED | Source is `sheet order` for a nan D_pav, and also for an exact tie at 0, with a WARNING. The test covers both. |
| M5: nested_collapsed `n` | ADDRESSED | Its count rows now read "n: the informative loci kept, one per nested cluster". |
| M6: private helpers imported | NOT ADDRESSED (deferred by ruling) | relations.py is untouched. Acceptable. |

### Checks for new breakage
- **main3: every row is unchanged and finite.**
  - Under f655060, through my view, all seven D_pav strata and dD equal my independent values to the printed
    digits, with finite se and z (rr_main3.out). No line says "not testable".
  - Distance from the guard's limits (n_RD/n_SD over informative blocks):

    | stratum | n_RD / n_SD | informative blocks |
    |---|---|---|
    | K=0 | 32 / 8 | 33 |
    | 0<K<0.01 | 320 / 77 | 187 |
    | K>=0.01 | 965 / 639 | 352 |
    | all | 1,317 / 724 | 370 |

  - The Dating line now reads "significant at |Z| >= 3: ... gene flow" for dD's Z 3.13.
- **Toy null.**
  - calib_toy.py output is byte-identical to the pre-fix run over 70 runs (50 default seeds, 10 with unequal
    annotation, 10 with unequal resolution). The guard never fires there.
  - The gradient null with populated bins (40 seeds) is unchanged: mean Z +0.04, sd 1.05, none with |Z| >= 3.
- **Sparse young-bin null** (rr_sparse_null.py). Two extra toy patterns put R+D and S+D loci at K=0, each with
  probability eps, with no tracts. "Before" is the same joint jackknife without the guard, recomputed from the
  catalog.

  | eps | young informative loci, median (range) | before: \|Z\| >= 3 | after: NaN / finite / \|Z\| >= 3 |
  |---|---|---|---|
  | 0.0004 | 2 (0-8) | 28 of 55 | 33 / 22 / 0 (5 runs skipped: no young informative locus) |
  | 0.0015 | 10 (3-17) | 1 of 60 | 1 / 59 / 0 |
  | 0.005 | 32 (20-43) | 0 of 60 | 0 / 60 / 0 |

  The guard removes the false positives, about half of the sparsest runs before. It withholds Z only when the
  young bin holds a handful of loci; with about 10, it fires once in 60.
- **Could the guard suppress a statistic that is legitimately testable?**
  - **D_pav strata.** An empty class already gave se 0 and z nan before the fix. The only new loss is a stratum
    whose informative loci lie in fewer than 3 blocks: LTRmix's floor, now applied to the informative loci.
  - **dD.** It is withheld when either bin is degenerate. By the ruling, that includes the strongest possible
    young excess: the admixed toy's K=0 is 92/0, so dD +0.871 is "not testable". The jackknife truly cannot see
    that bin's variance. A count-based statement, such as an exact binomial bound on D(K=0) labeled as ignoring
    linkage, would let a report quantify such a case. That is a design point for the controller, not a defect of
    the fix.
  - **f.** The rule needs all four classes non-empty. Unlike D at ±1, an empty class does not fix f's
    pseudovalues, so the rule is conservative here. It was ruled; this is an observation only.
- **"Pseudovalues do not vary".** The test is exact equality (`jk.se == 0` in `_guard`), not within a
  floating-point tolerance, and floating-point rounding defeats it. See N1.

### New issues

**Critical:** none. **Important:** none.

**Minor**

**N1. The "pseudovalues do not vary" test is exact (`jk.se == 0`). When rounding makes the mean of identical pseudovalues inexact, a jackknife that saw no variation gives se ~4e-17 and Z ~5e15, reported as significant, and for the gradient as gene flow.**
Locations: trio.py `_guard` (its `jk.se` test); stats.py `jackknife` (se from `p.mean()`).

- **Evidence** (rr_float_equal.py, rr_float_dating.out):
  - Three blocks, each holding 3 R+D and 2 S+D: every pseudovalue is the same double 0.2. But
    `np.mean([0.2] * 3)` is 0.20000000000000004, so se = 3.9e-17 and Z = 5.1e15. The primary line reads
    "+0.2000 ± 0.0000 (Z 5095241338020618.00; significant, |Z| >= 3)".
  - The same uniform blocks in both age bins (3/2 young, 2/3 old) give dD +0.400 ± 0.000, Z 5.1e15, and the
    Dating line says "significant at |Z| >= 3: an excess concentrated in young insertions, which DESIGN 7.3
    reads as gene flow".
  - With 2 R+D and 1 S+D per block (D = 1/3), the float mean happens to be exact, se is 0, and the guard fires.
    So whether it fires depends on rounding, not on the data.
- **Why Minor.** It needs every informative block to hold the same R+D : S+D ratio. Genome-scale data will not
  produce that, though small strata and sparse bins can. It is not a regression (the pre-fix code gave the same
  Z), but the implementer's own added condition is meant to close exactly this case.
- **Fix.** In `stats.jackknife`, set se = 0 when the finite pseudovalues are all equal (`p.min() == p.max()`),
  and `_guard` then catches it. Pseudovalues are ratios of integer counts, so equal ratios are the same
  correctly rounded double, and the comparison is exact with no tolerance constant. Add the 3 × (3, 2) toy as a
  test.

### Tests and checks
- **Tests:**
  - tests/test_trio.py: 22 passed under -W error (20.1 s).
  - tests/test_stats_core.py and tests/test_checkpoint.py, the other tests that import the touched stats and
    constants modules: 40 passed.
  - ruff: clean on src/ltrpav/analysis and the test file.
- **AST.** The brief's tests are identical except `test_roles_from_sign` (lint) and `test_null_and_admixed` (the
  ruled replacement).
- **Commit.** f655060 is by cwb14, with no trailers, and touches four files.
- **The shared jackknife.** `stats.jackknife` now takes its floor from JK_MIN_BLOCKS = 3 instead of the literal 3;
  behavior is unchanged.
- **Wrapping.** The rewrap of trio.py to 110 columns changes no logic: the main3 rows and the 70-run toy
  calibration are identical.

### Re-review assessment
- **Verdicts:** 7 ADDRESSED (I1, I2, M1-M5), 0 PARTIAL, 1 NOT ADDRESSED (M6, deferred by ruling).
- **New issues:** no new Critical or Important; 1 new Minor (N1).

**Task quality: Approved.** I recommend fixing N1 now. It is two lines in `stats.jackknife` plus a test, and it
is the case that the round's own "pseudovalues do not vary" condition is meant to cover.
