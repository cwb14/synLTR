#!/usr/bin/env python3
"""Independent check of the assembly truth with reads of the other haplotype only (part/<ref>.other.bam).

At each element, depth of other-haplotype reads (primary, MAPQ >= 20) at the flank bases 200 bp outside each end.
Truth states where the other haplotype keeps the flanks (F, Fx, E, S) should show ~ per-haplotype depth; states
where it lacks or replaced them (Nd, Nr) should show ~0.
usage: truth_reads_check.py truth.tsv other.bam out.tsv
"""
import sys

import numpy as np
import pandas as pd
import pysam

t = pd.read_csv(sys.argv[1], sep="\t")
bam = pysam.AlignmentFile(sys.argv[2])


def depth(c, p):
    return sum(1 for x in bam.fetch(c, p, p + 1)
               if not (x.is_secondary or x.is_supplementary or x.is_unmapped) and x.mapping_quality >= 20)


rows = []
for r in t.itertuples():
    s0 = r.start - 1
    dl = depth(r.chrom, max(0, s0 - 200 - r.tsd_len))
    dr = depth(r.chrom, r.end + 200 + r.tsd_len)
    rows.append((r.element_id, r.state, dl, dr))
d = pd.DataFrame(rows, columns=["element_id", "state", "depth_left", "depth_right"])
d["depth_min"] = d[["depth_left", "depth_right"]].min(axis=1)
d.to_csv(sys.argv[3], sep="\t", index=False)
g = d.groupby("state").depth_min
print(pd.DataFrame({"n": g.size(), "median": g.median(), "q10": g.quantile(0.1), "q90": g.quantile(0.9),
                    "frac_zero": g.apply(lambda x: (x == 0).mean())}).to_string())
