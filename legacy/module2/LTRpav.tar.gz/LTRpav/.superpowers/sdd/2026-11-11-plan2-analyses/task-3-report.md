# Task 3 report: relationships (DESIGN 7.1, 7.2)

Status: DONE_WITH_CONCERNS (the concerns are judgment calls listed under "Decisions to check"; nothing is blocked)
Commit: 09fa5a5 "Add relationships: discovery, sharing, tree, sister pairs, outgroup conflicts" (on 6682dd3)
Files: src/ltrpav/analysis/relations.py (new, 648 lines), tests/test_relations.py (new, 246 lines). No other file
touched; no engine module edited.

## Tests
- TDD: tests written first; `pytest -W error tests/test_relations.py` failed on the import, then passed.
- tests/test_relations.py: 16 passed (the brief's 11 tests, plus 5 edge-case tests of mine).
- Full suite `NUMPY_MADVISE_HUGEPAGE=0 python -m pytest -W error -m "not slow"`: 918 passed, 1 deselected (76 s).
- `ruff check .`: clean.

## What was built (the brief's interfaces, names and signatures, unchanged)
- `Node` (frozen: name, children, length; `leaves()`, `newick()` with lengths to 6 significant digits via `.6g`,
  no length above the top, ";" at the end), `Counted`, `SisterCall`.
- `run_summary`: rows test `catalog` (n_loci; per genome `annotated` 1/0 and `resolved_frac`, merged cls >= 0
  over all loci); qc.tsv's `annot_sensitivity` and every `skipped_<reason>` quoted as written, in findings
  ("Run") and as rows; a missing, unreadable or foreign qc.tsv is one findings line.
- `pav_distances` (merged states, every locus, outgroups included; nan when a pair has no locus resolved in both;
  diagonal 0, its n is the genome's resolved loci), `shared_derived` (ingroup pairs; outgroup rows and columns
  and the diagonal 0).
- `neighbor_joining`: Saitou & Nei's Q-matrix; ties go to the first pair in sheet order, a joined node taking its
  first member's place; negative lengths become 0; the top has 3 children (2 for 2 leaves). A ValueError on a
  non-finite, non-square or non-symmetric matrix.
- `root_on`: (outgroup, rest), with the root at the midpoint of the outgroup's branch (every leaf-to-leaf path
  length is kept); a degree-2 node (an earlier root) is merged into its branch.
- `four_point_ok`, `eligible_fallback`, `discover`: exactly the brief's rules. gstar is z where z is a member; under
  fallback it is the first eligible member in sheet order. cand = z present in gstar's call plus the outgroup
  rule (E / not_present / none). rows = cand with x and y resolved. loci =
  `disc=..;present=z;res=x,y;outgroup=<rule>`. An empty disc returns None.
- `trio_sharing`, `sister_pair` (p_top, ambiguous, p_kksc on `discover(..., "not_present")` from z's own calls,
  kksc_loci or "none").
- `relations`: rows `distance`, `shared_derived`, `tree`, then per ingroup trio `sharing` (n_x+y x3,
  sister_pair, p_top, p_kksc) and `kksc_resolution`, then `outgroup_conflict` (frac_E, n, the brief's note).
  Every row has its `loci`; layer `pav`; stratum `all`.
- WARNINGs in "Relationships": an ambiguous sister pair (names it, e.g. "R+S"); a KKSC test with no discovery
  genome ("skipped", naming the excluded genomes and why: builder call 11). Plain lines: the tree or why it was
  skipped, each trio's call, each KKSC result with the anti-conservative note, outgroup conflicts, and "fewer
  than three ingroup genomes" / "No outgroup" when they apply.
- scipy's `binomtest` is imported inside `_binom_p` only (as `stats.u95` does); n = 0 returns nan without
  calling it (scipy >= 1.11 may raise there).

## Decisions to check (not fixed by the brief; most defensible choice taken)
1. **`kksc_resolution` rows (beyond the brief's enumerated `sharing` rows).** The Global Constraint "Every test
   reports the resolved fractions of its genomes, through stats.resolution", and Task 2's "Tasks 3, 4, 6, 7 and 9
   import them", led me to add one `resolution("kksc_resolution", trio, {x, y}, n_cand, loci, ...)` call per trio.
   It counts the KKSC candidates, from gstar's calls: `disc=D;present=D;outgroup=not_present`. It is not
   redundant with Task 4's D_pav resolution rows. On main3 the two candidate sets differ widely, because Zd is
   missing at most loci (D_pav: outgroup E; KKSC: outgroup not present). I added no resolution rows for the
   sister-pair pick: it is an any-discovery description (decision 13), and merged resolution mixes member status
   with genotyping. Drop the call if the controller prefers the brief's literal row list.
2. **A sister pair with p_top nan (no pair shares an insertion) is `ambiguous`.** The brief says "p_top >= P_WARN",
   which nan fails; an arbitrary first-in-sheet-order pair must not pass as resolved. It gets its own WARNING text.
3. **`relations` returns the unrooted NJ tree without an outgroup** (brief: "unrooted without one"), although the
   interface comment says "rooted tree". It returns None only when the tree is skipped. Task 8's Dollo placement
   must check `cat.outgroups` itself; its plan text already says it needs an outgroup.
4. **Root position**: the midpoint of the outgroup's branch (not identifiable from distances; it keeps the path
   lengths; ape and ete3 conventions differ). The topology, which Dollo uses, does not depend on it.
5. **Exclusion reasons name labels**: "groups with R" (not the literal "groups with x"). Equal alternative
   four-point sums (w's side is undetermined) and any nan sum both give "distance unresolved".
6. **Validation**: `discover`, `trio_sharing` and `sister_pair` raise AnalysisError (a ValueError) unless the labels
   are distinct ingroup genomes; an outgroup in a trio would make the outgroup rule contradict itself. An unknown
   outgroup rule is a ValueError.
7. **NJ tie tolerance**: Q values within 1e-12 (relative) of the minimum count as ties, so the sheet-order tie rule
   survives floating-point rounding. It is a private constant in relations.py, not analysis/constants.py: it is
   numerical precision, not a data threshold.
8. **No outgroup**: `discover(..., "E")` still writes `outgroup=E` (vacuous), per the brief's loci format. A
   "No outgroup" findings line says nothing was set aside.
9. Count rows (`shared_derived`, `n_x+y`): n is None for shared_derived; for `n_x+y` and `sister_pair`, n = the
   loci the sharing counts take; for `p_top`, n = n_top + n_second; for `p_kksc`, n = n_x+z + n_y+z. The KKSC counts
   go in p_kksc's note.
10. When p_kksc < P_WARN, the findings line says "the two counts differ at p < 0.05". It is not a WARNING and gives
    no interpretation, because the jackknifed D_pav is the test of record.

## Deviation from the verbatim tests
The brief's test code fails `ruff check` (3 findings). I made lint-only edits that leave behavior unchanged:
- `leaf_distances`: dropped the unused local `out` (`seen, todo = {a: 0.0}, [a]`).
- `test_sister_tie_warns`: `_, f, _, dist = relations(cat)` (`rows` and `tree` were unused).

Every assertion and expected value is verbatim.

## Extra tests (mine)
- `test_newick_and_nj_details`: newick text and `.6g`; two-leaf NJ; the all-ties star joins (a, b) first; a
  negative length set to 0; a nan matrix refused.
- `test_root_on_keeps_paths_and_merges_old_root`: re-rooting an already rooted tree keeps every path length and
  merges the old root; a two-leaf tree; an unknown outgroup.
- `test_fallback_discovery_reasons`: an eligible X; an excluded Y ("groups with R"); a nan distance ("distance
  unresolved"); discover then returns None; a bad outgroup rule.
- `test_relations_skips_and_rooting`: two ingroup genomes plus an outgroup (rooted three-leaf tree, no sharing
  rows, a findings line); no outgroup (an unrooted tree, no conflict rows, KKSC skipped with a WARNING, p_kksc nan,
  loci "none"); a pair never resolved together (no tree, "Tree skipped" line).
- `test_sister_without_informative_loci_is_ambiguous`: p_top nan means ambiguous; any input order gives sheet
  order; an outgroup in a trio is refused.

## Probe on real and simulated data (read-only)
Script: /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/probe/probe_relations.py.
It reads main3 through a symlinked view whose `work/` is its own, because `load_catalog` would otherwise write the
sheet's checksum into main3/work/checksums.json. main3 stayed untouched: that file's mtime is still 15:33:46.

```
NUMPY_MADVISE_HUGEPAGE=0 python probe_relations.py <view> benchmark_pav/main3/samples.tsv <sim dir>
```

**main3** (322,538 loci; B73, TIL18, TIL01, Zd outgroup):
- Cost: load 10.8 s; `run_summary` + `relations` 0.61 s; peak RSS 490 MB for the whole probe.
- Distances: B73~TIL18 0.464 (n 114,412), B73~TIL01 0.433 (124,520), TIL18~TIL01 0.492 (113,107); against Zd
  0.397-0.413 (about 64,000 loci each).
- Tree: `(Zd:0.0826371,((B73:0.208712,TIL01:0.22419):0.0299568,TIL18:0.231763):0.0826371);`
- Sharing, on 78,659 loci: B73+TIL18 3,097, B73+TIL01 5,392, TIL18+TIL01 1,828. So the sister pair is B73+TIL01 and
  the third genome is TIL18 (p_top 1.6e-138). These are the expected roles (Task 12 item 1).
- KKSC, from TIL18's own calls: n_B73+TIL18 2,763 against n_TIL01+TIL18 1,495, p 3.1e-85 (anti-conservative, no
  jackknife). kksc_resolution: B73 0.443, TIL01 0.425 over 113,062 candidates, with no warning. This is a sanity
  check only. The asymmetry runs in the direction *mexicana* gene flow into B73 would give; the test of record is
  Task 4's D_pav.
- Outgroup conflicts: B73 326 of 15,377 (0.021), TIL18 375 of 15,334 (0.024), TIL01 378 of 15,513 (0.024).
- Run: annot_sensitivity quoted (0.822579, 0.79286, 0.811683); main3's qc.tsv has no skipped_ rows.

**simulate_run** (seeds 1, 2), sister pair R+S and third genome D in all four runs; trees ((R,S),D),O:
- Null: p_kksc 0.64 and 0.19 (n_R+D 217 vs n_S+D 228; 238 vs 209).
- With TRACTS: p_kksc 2.8e-9 and 1.3e-13 (316 vs 183; 332 vs 167).
- A resolved_R == resolved_S tie in seed 1 (2,236 of 2,627 each) was checked: equal counts on different rows,
  not a bug.

## Notes for later tasks
- Task 4: `discover` returns None, not a Counted, when no genome may discover. The WARNING's reasons come from
  `eligible_fallback(cat, R, S, D, dist)[1]`, as `relations` does for KKSC.
- `SisterCall` is frozen but holds a dict, so it is unhashable. It is never hashed here.

## Fix round 1 (review task-3-review.md: Spec ✅, 1 Important, 4 Minor)
Commit: 74c9fd8 "Read the outgroup-conflict bound from discoverers' own calls; root on the outgroup clade" (on
09fa5a5). Tests: tests/test_relations.py 22 passed (6 added); full suite `-W error -m "not slow"` 924 passed,
1 deselected; ruff clean.

**I1, fixed per the controller ruling.** `outgroup_conflict` is now counted from the discoverers' own calls.
- Discoverers: the annotated ingroup genomes other than g. Per row, gstar is the first of them that is a member
  (sheet order), the same per-row rule as `discover`; the code is shared through `_first_member`.
- Counted loci: rows where gstar's own call puts some outgroup P/S/T and g resolved.
- frac_E: the fraction of those rows where gstar calls g E.
- `loci`: `disc=<the other annotated ingroup genomes>;res=<g>;outgroup=present`. It is `none` (n 0, nan) when
  g is the only annotated ingroup genome.
- g never discovers its own count: a locus only g discovered (P by construction) never enters. A locus another
  genome also discovered enters, with g's state read from that genome's call. This is the reviewer's
  computation. Dropping such loci would condition on g's annotation having missed the copy.
- One refinement of the ruling's "genomes other than G": an annotated outgroup never discovers here. An
  insertion private to the outgroup leaves every ingroup genome E without any error, so the locus must be one an
  ingroup genome carries. This changes nothing on main3, where Zd is unannotated.
- The brief's `test_outgroup_conflict` keeps its fixture. Its expected values follow the ruling: R 1 of 1 (its
  seven member loci no longer enter; the two U loci are U in S's call); S 0 of 7, discovered by R.
- New `test_outgroup_conflict_ignores_annotation_depth`: the same eight S-discovered loci, annotated in R
  shallowly or deeply (deep adds R memberships and eight R-only loci). The own-call bound is 1/8 of 8 in both
  runs. The merged-state rule it replaces drops from 1/8 to 1/16.
- **main3** (read-only, through the symlinked view; main3/work/checksums.json mtime unchanged), matching the
  reviewer's figures:

  | Genome | E / counted loci | frac_E |
  |---|---|---|
  | B73 | 321 / 11,990 | 0.0268 |
  | TIL18 | 368 / 11,385 | 0.0323 |
  | TIL01 | 376 / 11,957 | 0.0314 |

  The old merged-state values were 0.021 / 0.024 / 0.024. Every other row is unchanged: distances, tree,
  sharing, KKSC, kksc_resolution.
- Simulated runs: frac_E is still 0 (the toy makes no E errors at old loci). n falls from about 950 to about 700,
  because R-, S- and D-only member loci no longer enter.

**M1, fixed.** Every row now declares its loci (new `test_rows_declare_their_loci`: no "." left).
- `annotated` and `skipped_<reason>` use `none`, the module's one token for a row that counts no loci. It is
  also used for a skipped p_kksc, and is documented in the module docstring.
- `annot_sensitivity` is now `disc=any_but_<x>;present=<x>`, with the exact qc.tsv definition in its note: a
  high-tier P call into x from another genome's member.

**M2, fixed.** With several outgroups, the tree is rooted at the midpoint of the branch that splits the
outgroups' clade from the ingroup; the findings say "rooted between the outgroups (...) and the ingroup".
- When the outgroups form no clade, the tree is rooted on the first outgroup, with a WARNING to check their roles
  in the samples sheet.
- One outgroup gives the same tree as before.
- `root_on`'s signature and behavior are unchanged. It now calls the general private `_root_on_split`, so its
  tests pass as they were.
- Test: `test_two_outgroups` covers a clade and a non-clade.

**M3, fixed.** The four coverage gaps now have tests:
- `test_fallback_first_member_and_exclusions`: two eligible genomes; gstar X1 where both are members, X2 where
  only X2 is; X1's U call into D drops its row; Y "groups with S".
- `test_two_outgroups`: the conflict rule counts a locus where only O1 is present and one where only O2 is, and
  leaves out a locus with no outgroup present: R 1 of 2.
- `test_kksc_reads_a_member_as_the_discoverer_calls_it`: an annot_conflict, where R is merged P but D's call into
  R is E. Sharing counts R+D 3; KKSC stays binomtest(2, 3).

**M4, fixed.** When the fallback discovers, the KKSC findings line says so and names the genomes it excluded,
e.g. "on loci X discovers (D has no annotation; X split with it from R and S by the four-point condition; not
eligible: Y: groups with S)". Test: `test_kksc_line_names_the_fallback_exclusions`, on PAV distances computed
from the loci.

Plan text left for the controller: Task 12 item 11 (merged states, decision 18) and Task 3's "Outgroup
conflicts" and "Rooted on the first outgroup" lines now differ from the code, as ruled and reviewed.
