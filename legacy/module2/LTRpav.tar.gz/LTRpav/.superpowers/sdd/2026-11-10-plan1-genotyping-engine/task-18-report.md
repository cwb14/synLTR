# Task 18 report
Implemented src/ltrpav/anchor/flanks.py: Piece, flank_pieces, FlankMm2Route, FlankBlastRoute, HybridRoute, map_pieces
(shared mm2 index + hit conversion via new mm2.map_rows, extracted without behavior change), BLAST db helper.
get_route/KNOWN_ROUTES register flank-mm2, flank-blast, hybrid (primary FastGA if on PATH else mm2).
Tests (tests/test_flanks.py, 6 tests): pieces skip elements/Ns; nearest-first/capped; flank-mm2 through genotype_pair on
toy seed 7 -> ALL toy cases (P, E*, D*, S, T, O, G*, nested/host/adjacent) match expectations (no differences);
cache differs by cap; hybrid fills unanchored; flank-blast strand-correct (+/-) blocks.
RED: ModuleNotFoundError ltrpav.anchor.flanks. GREEN: 6 passed (each < 1 s). Full suite green, ruff clean.
Toy timings: flank-mm2 genotype 0.47 s, hybrid 0.59 s (incl. primary), blast 0.42 s.
Commits: refactor of mm2 (map_rows) + "Add flank-mapping routes and hybrid". Also updated test_routes.test_get_route regex
for the new KNOWN_ROUTES text.
Deviation: hybrid test drops all primary blocks left of the element and within 15 kb right of it (not just within 15 kb):
the toy's 20-kb spacers still anchor a window with a 15-kb gap (WINDOW_CAP 500 kb), so the window would stay ok.
Concerns: hybrid demotes non-target elements to level 1 internally only to cut them out of pieces (flank_pieces yields
pieces for level 0 only). No test for hybrid cache differing by primary. Hybrid raw blocks are cached only at the
anchor level (anchor_pair), primary raw cache reused.

## Fix report
flank_pieces gained `targets: set[str] | None`; HybridRoute passes the unresolved eids; level-demotion hack removed.
New tests: test_pieces_targets, test_hybrid_cache_differs_by_primary (params and anchor marker key differ by primary).
Full suite + ruff green.

## Fix report 2 (review round 1)
1. flank_pieces: per seqid spans sorted once with starts and running max-end; each flank region bisects to the spans
   that can intersect it (no scan of all spans). Timing, 40 Mb sequence with 20k elements: old ~6.5 s for 5000
   elements (quadratic, ~100 s extrapolated to 20k); new 6.2 s for 20k.
2. map_pieces: pieces fetched just before submission, pending deque bounded at mm2._QUEUED * threads; results in
   piece order (identical output).
Tests: test_pieces_match_reference_on_random_case (vs the old implementation, nested spans), test_pieces_many_elements
(20k elements, < 30 s assert; ~17 s incl. FASTA writing), test_map_pieces_bounds_in_flight (spy on submit; peak <= 2*threads).
Commands: pytest tests/test_flanks.py tests/test_routes.py; pytest (full) -> all pass; ruff clean.
