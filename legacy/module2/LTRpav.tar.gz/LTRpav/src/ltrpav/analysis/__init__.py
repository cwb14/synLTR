"""Analyses of a finished run: its outputs read as data, never an engine module. Its stages key on
the fingerprint of this package and of the engine modules the analyses run (report.ENGINE_MODULES), never on an
engine stage's, so no analysis edit invalidates genotyping. Imports nothing heavy."""
