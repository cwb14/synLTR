### Task 8: Simulation harness: snapshot, calibration, direction predictions, grid, pilot

**Files** (in `benchmark_pav/plan3/`):
- `snap/<sha>/`;
- `common/{env.sh,view.sh}`;
- `sim/`: `backbone.tsv`, `calibrate.sh`, `calibration.tsv`, `demography.json`, `probe_direction.py`,
  `direction_predictions.tsv`, `make_grid.py`, `grid.tsv`, `pilot.tsv`, `run_one.sh`, `run_grid.sh`, `gff3_to_ltrmix.py`,
  `test_gff3_to_ltrmix.py`, `pilot/`, `memo.md`;
- `sim/probes/` (already there: the drafting and review probes, copied 2026-11-12).

**Interfaces:**
- Consumes:
  - `ltrpav-sim pop` (Task 5);
  - `ltrpav-genotype`, `ltrpav-merge`;
  - `ltrpav-stats` and `ltrpav-paint` with Task 7's options;
  - LTRmix: `python $P/LTRmix/ltrmix.py --genome L=FA,TSV ... --outdir DIR -t 8 --no-figure`, in env `ltrmix`.
- Produces:
  - `view.sh RUN VIEW SHEET [PAIRS_FILTER]`. It makes VIEW with:
    - symlinks to RUN's `loci.tsv`, `manifest.json`, `pairs`, `qc.tsv` and `work/elements`;
    - SHEET written as `samples.tsv`, with its `fasta` and `annotation` columns made absolute (resolved against SHEET's
      directory). `read_samples` resolves relative paths against the sheet's own directory, so a plain copy would break
      every simulated view. Task 5's portable relative sheet stays as it is.

    With `PAIRS_FILTER` (a query label to leave out):
    - `pairs/` becomes a directory of links to every pair file whose query is not that label;
    - each linked file's `.calls.tsv.gz.done.json` marker is linked beside it, because `ltrpav-merge` reads the markers;
    - that label's annotation is set to `.` in the written sheet;
    - `loci.tsv`, `manifest.json` and `qc.tsv` are not linked, and the view runs `ltrpav-merge` itself.

    `view.sh` refuses an existing directory that is not a view.
  - `run_one.sh NAME [--from STEP] [--until STEP] [--rundir DIR]`. It reads NAME's grid row and runs the steps `sim`,
    `geno`, `views`, `ltrmix` and `eval` in DIR (default `runs/NAME`). A step is skipped when its marker exists.
  - `run_grid.sh TSV [--until STEP]` (Step 7).
  - `gff3_to_ltrmix.py GFF3 FASTA OUTPREFIX`. It writes an LTRmix generic library with `edta_to_lib.py`'s conventions.
    It fetches each element's span through the FASTA's `.fai` (pysam) and never reads the whole FASTA:
    - header `seqid:start-end#LTR/<superfamily or unknown>`;
    - minus-strand elements reverse-complemented;
    - table `seq_id k2p tsd strand ltr5_len ltr3_len`, where ltr5 is the genome-left LTR.

- [ ] **Step 1: Snapshot.**
  - `git archive <Task 7 head> src | tar -x -C snap/<sha>`, and write `snap/<sha>/SHA`.
  - `common/env.sh`:
    - exports `PYTHONPATH=snap/<sha>/src`, `NUMPY_MADVISE_HUGEPAGE=0` and `PYTHONDONTWRITEBYTECODE=1`;
    - asserts `ltrpav.__file__` is in the snapshot.

    Every script sources it.
- [ ] **Step 2: Backbone.** `backbone.tsv` lists the ten windows below.
  - They were drawn once at drafting with `numpy.random.default_rng(20261112)`: one 10-Mb start per B73 chromosome,
    uniform in [0, length - 10 Mb], redrawn above 1% N (none needed).
  - The element counts are the fully-inside elements of `run/B73v5_LTRs`.

  | region | elements | note |
  |---|---|---|
  | `B73v5_chr1:293751269-303751268` | 582 | 0.53% N |
  | `B73v5_chr2:204375545-214375544` | 555 | |
  | `B73v5_chr3:97859161-107859160` | 597 | pericentromeric |
  | `B73v5_chr4:23967460-33967459` | 594 | |
  | `B73v5_chr5:214711285-224711284` | 515 | |
  | `B73v5_chr6:58924490-68924489` | 658 | |
  | `B73v5_chr7:94584939-104584938` | 609 | pericentromeric |
  | `B73v5_chr8:18636237-28636236` | 586 | |
  | `B73v5_chr9:18667517-28667516` | 584 | |
  | `B73v5_chr10:12972514-22972513` | 612 | |

- [ ] **Step 3: Calibrate the simulator, before the pilot.** Simulator calibration, not method tuning (Global
  Constraints). `calibrate.sh` writes `calibration.tsv` (value, command, source) and `demography.json`:
  1. **Loss mix.** Take B73's top-level elements (`level` 0) that `B73__Zd` calls P, S or T. Join them by `eid` to
     `B73__TIL18` and `B73__TIL01`, and count the states S, T, D and O. Pool the two, normalize the four, and write
     `loss_split` in the order solo, del_flank, del_partial, replace = S, D, T, O.
     - Drafting values: 0.123, 0.164, 0.511, 0.202 (pooled S 646, D 861, T 2,685, O 1,063).
     - Reason: these elements are inherited by both sisters, so every S/T/D/O is a derived loss as the classifier reads
       it. E (2%) and U (7%) are not losses.
  2. **Replacement length.** `replace_mean` is the mean `b_ins` of those O calls, pooled over calls. Drafting value:
     13,538 bp.
  3. **Outgroup split.** For each candidate `t_o` in {120,000; 300,000; 600,000; 900,000; 1,200,000}, run
     `sim/probes/probe_outgroup.py`'s computation:
     - perfect genotypes, `popmodel.demography`, one 10-Mb chromosome, seed 11;
     - backbone 58 elements/Mb in the denominator.

     Take the smallest candidate whose outgroup conflict is at most 0.032 in A1, B1 and C1. 0.032 is main3's largest
     measured `outgroup_conflict frac_E`, an upper bound that includes errors. Drafting result: 900,000.
  4. Every other field stays the LTRmix default. `demography.json` holds calibrate.sh's exact values and governs every
     run: each grid row passes it with `--demography`. The `src` defaults (Task 1) are the drafting values. DESIGN 12
     records both (Task 16).
- [ ] **Step 4: Direction predictions, before any scoring.**
  - `sim/probe_direction.py` starts from `sim/probes/probe_direction.py` and runs in env `ltrpav` (msprime since Task 1).
    It reads
    `demography.json`, and imports the pattern pairs and `DFOIL_ALT_SIGNS` from `ltrpav.analysis.direction` rather than
    copying them.
  - Run it for every direction scenario of the grid (kinds `null`, `power`, `reverse`, `ptlike`, `bneck`, `posctl`),
    with perfect genotypes and 4 x 10 Mb (posctl 30 x 10 Mb). It writes `direction_predictions.tsv`: scenario, code,
    label.
  - About 29 scenarios take more than 15 minutes, so the run is detached (Global Constraints): at most 16 processes,
    with a done marker.
  - Expected codes, from the drafting probe:
    - `0000` ("none") for every population or PT-like pulse;
    - posctl `C1>A1` `+-+0` (P3=>P1), posctl `A1>C1` `+++-` (P1=>P3), posctl null `0000`.
  - If no posctl design orients, `RULES.md` says so, and direction power is reported as not estimable under this
    demography. That is not a miss.
- [ ] **Step 5: Grid.** `make_grid.py --bneck-nulls N` writes `grid.tsv` with the columns
  `name design per_taxon f ta pulse sub ne bottleneck dropout_A1 seed kind`. `ne` is 1000 for posctl (every
  population's Ne) and empty otherwise.
  - Every row uses `demography.json`. Base annotation: dropout 0.1, jitter 0.05.
  - Total: 88 + the bottleneck nulls on 7 genomes, and 26 trio rows.

  | kind | rows | design | values | seeds |
  |---|---|---|---|---|
  | null | `null_s101`..`null_s130` | 7g | f 0 | 101-130 |
  | power | `f{f}_Ta{ta}_r{1,2}` | 7g | f 0.02 0.05 0.10 0.18 0.25 0.50 x ta 50 500 5000, `C>A` | 1001-1036 |
  | reverse | `rev_f{f}_Ta{ta}_r{1,2}` | 7g | f 0.10 0.25 x ta 500 5000, `A>C` | 3001-3008 |
  | ptlike | `pt_r{1,2,3}` | 7g | `C>A1`, sub_a (6000, ne_a), f 0.18, ta 5000 | 5001-5003 |
  | bneck | `bn_null_s{1..30 or 1..10}`, `bn_f0.18_Ta5000_r{1,2,3}` | 7g | bottleneck 5000,2000; f 0 or 0.18 `C>A` | 4001-4033 |
  | posctl | `pc_C1A1_r{1,2,3}`, `pc_A1C1_r{1,2,3}`, `pc_null_r{1,2}` | 7g | every Ne 1,000; sub_a (2000, 1000), sub_c (30000, 1000); f 0.5, ta 500 | 6001-6008 |
  | dropout | `fn{0.2,0.4}_null_s{1..10}`, `fn{0.2,0.4}_f0.18_r{1,2,3}` | trio (per_taxon 1) | dropout_A1 0.2 or 0.4; ta 5000 | 2001-2026 |

  The number of bottleneck nulls (30 or 10) is set by the Step 11 gate, which regenerates `grid.tsv`.
- [ ] **Step 6: `run_one.sh`.**
  - Settings: `set -euo pipefail`; each step under `/usr/bin/time -v -o <step>.time`; `run.exit` on exit; `run.done`
    after `eval`.
  - **`sim`:**

    ```
    ltrpav-sim pop --fasta $P/inputs/B73v5.fa <--region x 10> --annotation $P/run/B73v5_LTRs --outdir sim
      --demography sim/row.json --seed S --f F --ta T --pulse P --per-taxon N [--bottleneck 5000,2000]
      [--dropout-genome A1=X] --threads 16
    ```

    `sim/row.json` is `demography.json` with the row's own fields merged over it: `sub` (sub_a, sub_c) and `ne` (every
    population's Ne). `row.json` records them.

  - **`geno`:** `ltrpav-genotype --samples sim/samples.tsv --outdir geno --threads 16`, then
    `ltrpav-merge --samples sim/samples.tsv --outdir geno`.
  - **`views`:**

    | view | commands |
    |---|---|
    | `main` | `ltrpav-stats --trio A1,B1,C1` (plus `--identity --threads 16` for kind null), then `ltrpav-paint --trio A1,B1,C1`: calibration and power |
    | `roles` | `ltrpav-stats` then `ltrpav-paint` (every trio, roles from the data): the head-to-head painting and the direction rows |
    | `any` | stats `--trio A1,B1,C1`, then paint `--trio A1,B1,C1 --discovery any` |
    | `decoy` | stats `--trio A1,B1,C1`, then paint `--trio A1,B1,C1 --emission decoy` |
    | `anydecoy` | stats `--trio A1,B1,C1`, then paint `--trio A1,B1,C1 --discovery any --emission decoy` |
    | `nodonor` | null and power rows only; `view.sh RUN nodonor sim/samples.tsv C1` (C1's annotation `.`, its own pair files and markers left out); `ltrpav-merge`, then `ltrpav-stats --trio A1,B1,C1`. Decision 11's default fallback on simulated truth; the rule is not changed |

  - **`ltrmix`:** convert A1, B1, C1 and C2's GFF3 (A1, B1, C1 in the trio design). With three libraries LTRmix writes the
    trio's files in `ltrmix/` itself, and with four in `ltrmix/A1_B1_C1/` (ltrmix.py L1615). Then in env `ltrmix` run
    `ltrmix.py --genome A1=lib/A1.fa,lib/A1.tsv ... --outdir ltrmix -t 8 --no-figure`.
    - For kind null, also run `$P/benchmark/scripts/rate_free_split.py --res ltrmix --donor C1=lib/C1.fa,lib/C1.tsv
      --sister B1=lib/B1.fa,lib/B1.tsv --recipient A1=lib/A1.fa,lib/A1.tsv -t 8 --out ltrmix/rate_free_split.tsv`,
      with stdout to `rate_free_split.txt`.
    - Its s line prints before the LTRquest-only section. With generic libraries the script then exits non-zero: record
      the exit and keep the line.
  - **`eval`:** Task 9's `eval_run.py runs/NAME` (env `ltrpav`) and `eval_ltrmix.py runs/NAME` (env `ltrmix`).
- [ ] **Step 7: `run_grid.sh TSV [--until STEP]`.**
  - Runs `xargs -P 2 -L 1 ./run_one.sh` over the names, passing `--until` on: two runs of 16 threads.
  - Writes `<TSV>.done` when every row's `run.exit` is 0 and the marker of its last requested step exists (`run.done`
    without `--until`).
  - Failures are listed in `<TSV>.failed` with their exit codes.
- [ ] **Step 8: Library converter test.** `test_gff3_to_ltrmix.py` builds a toy GFF3 and FASTA with one + and one -
  element.
  - Assert the exact headers, sequences and table row.
  - In env `ltrmix`, `ltrmix.load_library` reads the toy library (count 2).
- [ ] **Step 9: Pilot.**
  - `pilot.tsv` is two grid rows, `null_s101` and `f0.18_Ta5000_r1`. They are grid rows, and the grid later skips them
    by marker.
  - Run `setsid -f nohup ./run_grid.sh pilot.tsv --until ltrmix > pilot/pilot.log 2>&1 < /dev/null`. Scoring waits
    for `RULES.md` (Task 9).
  - Verify the PID, then wait on `pilot.tsv.done` or `pilot.tsv.failed`.
  - Record each step's wall time and peak RSS.
  - Check `nodonor`. If the catalog refuses the view, record the error and fix `view.sh` within the view's own files;
    the rule is untouched.
  - Compare the realized counts with the estimates: genome length ~177 Mb, ~13,900 elements per genome, 36 pair files.
- [ ] **Step 10: Realism check against the calibration.** Report the pilot's measured values against main3's:
  - per-pair state fractions and resolved fraction (`qc.tsv`);
  - outgroup conflict (`outgroup_conflict frac_E`);
  - D_pav counted and informative loci per Mb;
  - painting `n_informative` and `spacing_median`.

  Reported, not tuned. Write the numbers into `sim/memo.md`.
- [ ] **Step 11: Budget gate.** Apply the pre-registered formula (Compute budget) with the pilot's `h7` and the trio
  estimate.
  - Set the bottleneck null count to 30 or 10, or apply the 50-Mb fallback.
  - Regenerate `grid.tsv` with `make_grid.py --bneck-nulls N`.
  - Under the 50-Mb fallback, move the two pilot runs' directories aside (`runs/<name>.100Mb`), so that the grid reruns
    them on 50 Mb like every other row.
  - If the gate picks 30 bottleneck nulls, tell the user: about 12 h more than the expected 10.
  - Record the decision and its numbers in `sim/memo.md`.

---

