"""Checkpoint helpers: cached file checksums, stage keys and done markers."""
import hashlib
import json
import logging
import os
import shutil
from pathlib import Path

import pytest

from ltrpav import checkpoint
from ltrpav.checkpoint import clear_done, file_checksum, is_done, mark_done, stage_key


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def test_checkpoint_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setattr(checkpoint, "_BLOCK", 3)  # stream the file in several blocks
    fa = tmp_path / "a.fa"
    fa.write_bytes(b">a\nACGTACGT\n")
    sha = file_checksum(fa, tmp_path / "sums.json")
    assert sha == _sha(fa.read_bytes())

    params = {"chunk": 100_000, "preset": "asm20", "nested": {"x": 1, "y": [1, 2]}}
    key = stage_key("anchor", {"A": sha, "B": "b" * 64}, params)
    assert key == stage_key("anchor", {"B": "b" * 64, "A": sha}, dict(reversed(params.items())))  # canonical
    assert key != stage_key("anchor", {"A": "0" * 64, "B": "b" * 64}, params)  # an input checksum changed
    assert key != stage_key("anchor", {"A": sha, "B": "b" * 64}, {**params, "chunk": 50_000})  # a param
    assert key != stage_key("raw", {"A": sha, "B": "b" * 64}, params)  # another stage, the same modules
    assert key != stage_key("anchor", {"A": sha, "B": "b" * 64}, params, fingerprint="other code")
    monkeypatch.setattr(checkpoint, "__version__", "99.0")
    assert key != stage_key("anchor", {"A": sha, "B": "b" * 64}, params)  # another ltrpav version
    monkeypatch.undo()

    out = tmp_path / "x.npz"
    marker = tmp_path / "x.npz.done.json"
    assert not is_done(marker, key)
    out.write_bytes(b"12345")
    mark_done(marker, key, [out])
    assert is_done(marker, key)
    assert not is_done(marker, "another key")
    assert sorted(p.name for p in tmp_path.iterdir()) == ["a.fa", "sums.json", "x.npz", "x.npz.done.json"]
    out.write_bytes(b"123456")  # an output rewritten after its marker
    assert not is_done(marker, key)
    out.write_bytes(b"12345")
    assert is_done(marker, key)
    clear_done(marker)
    assert not marker.exists() and not is_done(marker, key)
    clear_done(marker)  # no marker: nothing to do
    mark_done(marker, key, [out])
    out.unlink()
    assert not is_done(marker, key)


def test_mark_done_needs_its_outputs(tmp_path):
    marker = tmp_path / "x.done.json"
    with pytest.raises(FileNotFoundError, match="missing.npz"):
        mark_done(marker, "k", [tmp_path / "missing.npz"])
    assert list(tmp_path.iterdir()) == []


def test_marker_survives_moving_the_directory(tmp_path):
    work = tmp_path / "work"
    work.mkdir()
    (work / "x.npz").write_bytes(b"abc")
    mark_done(work / "x.npz.done.json", "k", [work / "x.npz"])
    moved = tmp_path / "moved"
    work.rename(moved)
    assert is_done(moved / "x.npz.done.json", "k")


def test_file_checksum_cache_follows_size_and_mtime(tmp_path, caplog):
    f, cache = tmp_path / "a.fa", tmp_path / "sums.json"
    f.write_bytes(b"AAAA")
    st = f.stat()
    first = file_checksum(f, cache)
    assert list(json.loads(cache.read_text())) == [str(f.resolve())]  # keyed by absolute path
    f.write_bytes(b"CCCC")  # same size, mtime restored: the cache cannot tell, the old sum comes back
    os.utime(f, ns=(st.st_atime_ns, st.st_mtime_ns))
    assert file_checksum(f, cache) == first
    os.utime(f, ns=(st.st_atime_ns, st.st_mtime_ns + 1_000_000))  # a new mtime: the file is read again
    assert file_checksum(f, cache) == _sha(b"CCCC")
    f.write_bytes(b"GGGGG")  # a new size, same mtime as the cached entry
    os.utime(f, ns=(st.st_atime_ns, st.st_mtime_ns + 1_000_000))
    assert file_checksum(f, cache) == _sha(b"GGGGG")
    assert file_checksum(tmp_path / "." / "a.fa", cache) == _sha(b"GGGGG")  # same file, another spelling
    assert len(json.loads(cache.read_text())) == 1

    cache.write_text("{not json")  # a damaged cache is rebuilt, with a warning
    with caplog.at_level(logging.WARNING, logger="ltrpav.checkpoint"):
        assert file_checksum(f, cache) == _sha(b"GGGGG")
    assert "sums.json" in caplog.text
    assert json.loads(cache.read_text())[str(f.resolve())]["sha256"] == _sha(b"GGGGG")


# ---------------------------------------------------------------- code fingerprints per stage

# every stage the engine checkpoints: (stage, inputs, params)
_STAGES = [("elements", {"fasta": "f" * 64}, {"genome": "A"}), ("anchor", {"A": "a" * 64}, {"route": "flank-mm2"}),
           ("raw", {"A": "a" * 64}, {"route": "mm2"}), ("mm2_index", {"B": "b" * 64}, {"preset": "asm20"}),
           ("blastdb", {"B": "b" * 64}, {"dbtype": "nucl"}), ("genotype_pair", {"A": "a" * 64}, {"backend": "lastz"}),
           ("genotype_chunk", {"A": "a" * 64}, {"chunk": 0})]
# the module holding each stage's code: its declared set is that module's import closure
_ENTRY = {"elements": "ltrpav.annotation", "anchor": "ltrpav.anchor", "raw": "ltrpav.anchor",
          "blastdb": "ltrpav.anchor.flanks", "mm2_index": "ltrpav.anchor.mm2",
          "genotype_pair": "ltrpav.genotype", "genotype_chunk": "ltrpav.genotype"}
_CALLS = {"genotype_pair", "genotype_chunk"}
_ANCHORS = {"anchor", "raw", "blastdb"}


def _keys():
    return {s[0]: stage_key(*s) for s in _STAGES}


@pytest.fixture
def pkg(tmp_path, monkeypatch):
    """A copy of the ltrpav package that package_fingerprint reads instead of the installed one."""
    copy = tmp_path / "ltrpav"
    shutil.copytree(Path(checkpoint.__file__).parent, copy, ignore=shutil.ignore_patterns("__pycache__"))
    monkeypatch.setattr(checkpoint, "_ROOT", copy)
    return copy


def _edit(path: Path, text: bytes = b"\n# an edit\n") -> None:
    """Append to a source file of the copy; fingerprints are cached per process (sources never change in a
    run), so the cache is cleared."""
    path.write_bytes(path.read_bytes() + text)
    checkpoint._fingerprint.cache_clear()


@pytest.mark.parametrize("module, changed", [
    ("outputs/vcf.py", set()), ("outputs/manifest.py", set()), ("cli.py", set()), ("loci.py", set()),
    ("samples.py", set()), ("sim/genome.py", set()), ("checkpoint.py", set()), ("__init__.py", set()),
    ("classify.py", _CALLS), ("localign.py", _CALLS), ("junction.py", _CALLS), ("genotype.py", _CALLS),
    ("window.py", _ANCHORS | _CALLS),  # the hybrid route makes windows: window.py is in the anchor set
    ("anchor/flanks.py", _ANCHORS | _CALLS), ("chain.py", _ANCHORS | _CALLS),
    ("anchor/mm2.py", _ANCHORS | _CALLS | {"mm2_index"}), ("blocks.py", _ANCHORS | _CALLS | {"mm2_index"}),
    ("annotation/gff3.py", {"elements"}), ("annotation/records.py", {"elements"}),
    ("elements.py", {"elements"} | _ANCHORS | _CALLS), ("seqio.py", {"elements"} | _ANCHORS | _CALLS),
    ("constants.py", {s[0] for s in _STAGES}),
])
def test_stage_keys_follow_their_modules_only(pkg, module, changed):
    """An edit to a module in a stage's set changes that stage's
    key, an edit outside it never does. A comment in the outputs, the CLI, the locus catalog, the sheet
    reader, the simulator or the bookkeeping changes no key; classify.py, localign.py and window.py change the
    genotype keys, and the anchor keys only for window.py, which is in the anchor set; anchor/ and chain.py
    change the anchor and raw keys."""
    keys = _keys()
    _edit(pkg / module)
    new = _keys()
    assert {s for s in keys if keys[s] != new[s]} == changed


def test_stage_keys_are_unchanged_by_the_copy(pkg, monkeypatch):
    """The fixture's copy has the installed package's bytes: the same keys."""
    copied = _keys()
    monkeypatch.undo()
    assert _keys() == copied


def _closure(root: Path, name: str) -> set[str]:
    """Static import closure of module `name` under `root`, as STAGE_MODULES' sets are derived: imports
    anywhere in a module, TYPE_CHECKING blocks skipped, a parent package's __init__ counted only when imported
    from; ltrpav/__init__.py and checkpoint.py (bookkeeping) left out. Returns paths relative to `root`."""
    import ast

    def path_of(dotted):
        p = root.joinpath(*dotted.split(".")[1:])
        if p.is_dir() and (p / "__init__.py").is_file():
            return p / "__init__.py"
        return p.with_suffix(".py") if p.with_suffix(".py").is_file() else None

    def imports(path):
        rel = path.relative_to(root).with_suffix("").parts
        pkg = ["ltrpav", *rel[:-1]]  # the package a relative import starts from (an __init__'s own)
        out = set()

        def visit(node):
            for child in ast.iter_child_nodes(node):
                if isinstance(child, ast.If) and "TYPE_CHECKING" in ast.unparse(child.test):
                    for c in child.orelse:
                        visit(c)
                    continue
                if isinstance(child, ast.Import):
                    out.update(a.name for a in child.names if a.name.split(".")[0] == "ltrpav")
                elif isinstance(child, ast.ImportFrom):
                    start = pkg[:len(pkg) - child.level + 1] if child.level else []
                    base = ".".join(start + ([child.module] if child.module else []))
                    if base.split(".")[0] == "ltrpav":  # a name may be a submodule, or defined in base
                        out.update(f"{base}.{a.name}" if path_of(f"{base}.{a.name}") else base
                                   for a in child.names)
                visit(child)
        visit(ast.parse(path.read_text()))
        return out

    seen, todo = set(), [path_of(name)]
    while todo:
        p = todo.pop()
        if p is not None and p not in seen:
            seen.add(p)
            todo.extend(path_of(m) for m in imports(p))
    return {p.relative_to(root).as_posix() for p in seen} - {"__init__.py", "checkpoint.py"}


def test_stage_modules_are_each_stages_import_closure():
    """Each declared set is exactly the static import closure of the module holding the stage's code, so a
    new import in an engine module fails here until STAGE_MODULES follows it (no stale key)."""
    root = Path(checkpoint.__file__).parent
    assert set(checkpoint.STAGE_MODULES) == set(_ENTRY) == {s[0] for s in _STAGES}
    for stage, names in checkpoint.STAGE_MODULES.items():
        declared = {f.relative_to(root).as_posix() for n in names for f in checkpoint._source_files(root, n)}
        assert declared == _closure(root, _ENTRY[stage]), stage


def test_package_fingerprint(pkg):
    """package_fingerprint changes with a package's own source only; a package outside the engine (such as
    ltrpav.analysis) keys its stages with it and leaves the engine's keys alone."""
    (pkg / "analysis").mkdir(exist_ok=True)  # the copy holds the analysis package
    (pkg / "analysis" / "__init__.py").write_text("")
    (pkg / "analysis" / "stats.py").write_text("X = 1\n")
    checkpoint._fingerprint.cache_clear()
    anchors, analysis, keys = (checkpoint.package_fingerprint("ltrpav.anchor"),
                               checkpoint.package_fingerprint("ltrpav.analysis"), _keys())
    assert checkpoint.package_fingerprint("ltrpav.analysis", "ltrpav.analysis.stats") == analysis  # once each
    assert checkpoint.package_fingerprint("ltrpav.analysis.stats") != analysis
    own = stage_key("stats", {"loci": "l" * 64}, {}, fingerprint=analysis)
    _edit(pkg / "analysis" / "stats.py")
    now = checkpoint.package_fingerprint("ltrpav.analysis")
    assert now != analysis and stage_key("stats", {"loci": "l" * 64}, {}, fingerprint=now) != own
    assert checkpoint.package_fingerprint("ltrpav.anchor") == anchors and _keys() == keys
    _edit(pkg / "anchor" / "paf.py")
    assert checkpoint.package_fingerprint("ltrpav.anchor") != anchors  # every file of the package counts
    with pytest.raises(ValueError, match="no ltrpav module or package 'ltrpav.nope'"):
        checkpoint.package_fingerprint("ltrpav.nope")
    with pytest.raises(ValueError, match="stage 'stats' has no module set"):
        stage_key("stats", {}, {})


def test_marker_records_meta(tmp_path):
    out, marker = tmp_path / "x.tsv", tmp_path / "x.tsv.done.json"
    out.write_text("x\n")
    mark_done(marker, "k", [out], meta={"elements": "e1", "code": "c1"})
    assert checkpoint.done_meta(marker) == {"elements": "e1", "code": "c1"}
    mark_done(marker, "k", [out])
    assert checkpoint.done_meta(marker) == {}
    assert checkpoint.done_meta(tmp_path / "none.done.json") is None
    marker.write_text("[1]")
    assert checkpoint.done_meta(marker) is None


def _exe(d, name, body):
    p = d / name
    p.write_text(f"#!/bin/sh\n{body}\n")
    p.chmod(0o755)
    return p


def test_tool_version(tmp_path, monkeypatch):
    """The first line a tool prints for its version flag; a tool without one (FastGA) is identified by the
    sha256 of its binary, which changes with the binary; an absent tool is None."""
    d = tmp_path / "bin"
    d.mkdir()
    _exe(d, "lastz", 'echo "lastz (version 9.9)"; echo "built with gcc"')
    fastga = _exe(d, "FastGA", "echo usage")
    monkeypatch.setenv("PATH", str(d))
    assert checkpoint.tool_version("lastz") == "lastz (version 9.9)"
    first = checkpoint.tool_version("FastGA")
    assert first.startswith("sha256:") and len(first) == len("sha256:") + 16
    fastga.write_text("#!/bin/sh\necho usage, other build\n")
    assert checkpoint.tool_version("FastGA") not in (first, None)
    assert checkpoint.tool_version("minimap2") is None
    assert checkpoint.tool_version("tool-with-no-entry") is None  # not on PATH either


def test_checksum_cache_survives_concurrent_threads(tmp_path):
    """Threads of one process share a cold checksum cache; each writes through its own temp
    file (pid and thread id), so none fails on another's rename."""
    from concurrent.futures import ThreadPoolExecutor
    files = []
    for i in range(32):
        f = tmp_path / f"f{i}.fa"
        f.write_bytes(b"ACGT" * (i + 1))
        files.append(f)
    with ThreadPoolExecutor(8) as pool:
        sums = list(pool.map(lambda f: file_checksum(f, tmp_path / "sums.json"), files))
    assert sums == [_sha(f.read_bytes()) for f in files] and not list(tmp_path.glob(".*.tmp"))
