### Task 5: Element record and LTRquest loader

**Files:** Create `src/ltrpav/elements.py`, `src/ltrpav/annotation/__init__.py` (empty for now),
`src/ltrpav/annotation/ltrquest.py`, `tests/test_annot_ltrquest.py`

**Interfaces:**
- Produces:

```python
@dataclass(frozen=True, slots=True)
class Element:
    genome: str; eid: str; name: str; seqid: str
    start: int; end: int; strand: str                 # 1-based inclusive; strand '+', '-' or '.'
    ltr_left: tuple[int, int]; ltr_right: tuple[int, int]   # genome orientation, 1-based inclusive
    tsd: str | None; k: float | None
    family: str | None; superfamily: str | None; clade: str | None; confidence: str | None
    parent: str | None = None; level: int = 0         # filled by assign_nesting (Task 8); 0 = top-level
def make_eid(genome: str, seqid: str, start: int, end: int) -> str   # f"{genome}|{seqid}:{start}-{end}"
ELEMENT_COLUMNS: tuple[str, ...]                     # field order; tuples written "a-b", None written "."
def write_elements(elements: list[Element], path: Path) -> None
def read_elements(path: Path) -> list[Element]
def load_ltrquest(prefix: str, genome: str) -> tuple[list[Element], Counter]   # Counter of skip reasons
```

- [ ] **Step 1: Write the failing tests.** The fixture writes `X_depth0_clean_ltr.tsv` and `X_depth1_clean_ltr.tsv`
  with the real header (`#seq_id seq_len status ltr5_start ... nest_status`, 34 columns, copied from
  `run/B73v5_LTRs_depth0_clean_ltr.tsv`). Use the two real rows (`B73v5_chr1:60664-70130#LTR/Copia/SIRE` at depth 0,
  `B73v5_chr1:51712-70182#LTR/Copia/SIRE` at depth 1) plus one row with `status` = `fail`.

```python
def test_load_ltrquest(tmp_path):
    els, skipped = load_ltrquest(str(tmp_path / "X"), "B73")
    inner = next(e for e in els if e.start == 60664)
    assert (inner.seqid, inner.end, inner.strand) == ("B73v5_chr1", 70130, "-")
    assert inner.ltr_left == (60664, 61985) and inner.ltr_right == (68826, 70130)
    assert inner.tsd == "CACTC" and inner.k == 0.0 and inner.family == "merged_fam00001"
    assert (inner.superfamily, inner.clade, inner.confidence) == ("Copia", "SIRE", "high")
    assert inner.eid == "B73|B73v5_chr1:60664-70130" and inner.name == "B73v5_chr1:60664-70130#LTR/Copia/SIRE"
    host = next(e for e in els if e.start == 51712)
    assert host.ltr_left == (51712, 53005) and host.ltr_right == (59462, 70182)   # rLTR span includes the inner element
    assert skipped["status_not_pass"] == 1

def test_elements_tsv_round_trip(tmp_path): ...  # write_elements then read_elements returns equal objects
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - Glob `f"{prefix}_depth*_clean_ltr.tsv"` and sort by the depth integer.
  - Parse `seq_id` with `^(?P<seqid>.+):(?P<start>\d+)-(?P<end>\d+)#(?P<cls>.+)$`.
  - Absolute LTR bounds = `start + rel - 1`. The `ltr5_*` columns are the genome-left LTR and `ltr3_*` the right one
    (verified against the GFF3 for the real host).
  - `k` comes from `k2p` (`NA` -> None). Superfamily and clade are parts 2 and 3 of `cls` (`unknown` -> None).
  - Skip rows whose `status` is not `pass`.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add Element record and LTRquest loader"`.

---

