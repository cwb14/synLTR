"""The built-in LASTZ window backend (ltrpav.localign, backend "lastz", the engine's default): the toy
genotype cases (tests/toy.py) aligned by LASTZ and called by the classifier over the classifier's seeds;
its options, CIGAR parsing and failure handling."""
from __future__ import annotations

import gzip
import inspect
import logging
import os
import random
import signal
import subprocess
import sys
import time
from dataclasses import replace
from pathlib import Path

import pytest

import toy
from conftest import needs_lastz
from ltrpav import cli, genotype, localign
from ltrpav.anchor import PairContext, get_route
from ltrpav.classify import classify_window
from ltrpav.constants import DEFAULT_BACKEND, MIN_SEG, SCORE, WINDOW_PAD
from ltrpav.elements import Element, make_eid
from ltrpav.genotype import genotype_pair
from ltrpav.localign import align_window, lastz_args, parse_cigarx
from ltrpav.samples import Sample
from ltrpav.seqio import Fasta
from ltrpav.window import Window

SEEDS = (7, 0, 4, 6, 9, 11, 14)  # the classifier's seeds (tests/test_classify.py): chance microhomology
CUT = ("P", "E", "T", "O", "inv_site")  # also called on window-sized flanks (WINDOW_PAD bp: make_windows's cut)


def calls(c: toy.ToyCase) -> dict:
    """eid -> Call for toy case `c` aligned by LASTZ (asm20) over one window spanning the whole case."""
    win = Window(wid=0, a_seqid="a", a_start=0, a_end=len(c.a), b_seqid="b", b_start=0, b_end=len(c.b),
                 strand=1, eids=[e.eid for e in c.elements if e.parent is None], status="ok", left_anchor=0,
                 right_anchor=len(c.a) - 1, margin=1.0)
    children: dict[str, list[str]] = {}
    for e in c.elements:
        if e.parent is not None:
            children.setdefault(e.parent, []).append(e.eid)
    aln = align_window(c.a, c.b, "asm20", backend="lastz")
    return {x.eid: x for x in classify_window(win, aln, c.a, c.b, {e.eid: e for e in c.elements}, children)}


def cut(c: toy.ToyCase) -> toy.ToyCase:
    """The case with WINDOW_PAD bp of flank kept on each side of A and B (elements shifted; eids kept)."""
    k = toy.FLANK - WINDOW_PAD
    els = [replace(e, start=e.start - k, end=e.end - k, ltr_left=(e.ltr_left[0] - k, e.ltr_left[1] - k),
                   ltr_right=(e.ltr_right[0] - k, e.ltr_right[1] - k)) for e in c.elements]
    return replace(c, a=c.a[k:len(c.a) - k], b=c.b[k:len(c.b) - k], elements=els)


def check(c: toy.ToyCase, got: dict, where: tuple) -> None:
    """Every element's expected state, required and forbidden flags, tier and U reason."""
    for eid, state in c.expect.items():
        x = got[eid]
        assert x.state == state, (where, x)
        flags = set(x.flags)
        assert c.flags.get(eid, set()) <= flags and not c.noflags.get(eid, set()) & flags, (where, x)
        assert c.tiers.get(eid, x.tier) == x.tier, (where, x)
        assert c.reasons.get(eid, x.ev["reason"]) == x.ev["reason"], (where, x)


# ---------------------------------------------------------------- the toy cases


@needs_lastz
@pytest.mark.parametrize("name", toy.CASES)
def test_toy_case(name):
    """Each of the 21 toy cases, on every seed, over a window spanning it (3-kb flanks): the expected calls,
    P, E, D_left and D_both among them."""
    for seed in SEEDS:
        c = toy.case(name, random.Random(seed))
        check(c, calls(c), (name, seed))


@needs_lastz
@pytest.mark.parametrize("name", CUT)
def test_toy_case_on_window_sized_flanks(name):
    """P, E, T, O and inv_site with only WINDOW_PAD bp of flank on each side, as make_windows cuts a window: both
    flanks still seed and align around the element-sized indel, and the chained minus strand still reports the
    inverted site."""
    for seed in SEEDS:
        c = cut(toy.case(name, random.Random(seed)))
        check(c, calls(c), (name, seed))


# ---------------------------------------------------------------- close genome pairs


def close_pair(rng: random.Random, sites=("E", "P", "E", "P"), spacer=300_000, patch=1500, rate=0.05):
    """A close pair: per site L T e T R (3-kb
    flanks, a 5-kb element, a 5-bp TSD) between identical random spacers; B is A with each site's element and
    `patch` bp on each side (TSDs included) substituted at `rate`, and an E site's element and right TSD copy
    deleted. Returns (A, B, A's elements, eid -> true state). The spacers dominate the anchored divergence d
    (about 0.0007: preset_for_divergence picks asm5), though every site's window is 5% divergent: an
    introgressed tract inside a near-identical pair."""
    def seq(n):
        return "".join(rng.choices("ACGT", k=n))

    a_parts, b_parts, elements, truth = [seq(spacer)], [], [], {}
    b_parts.append(a_parts[0])
    for state in sites:
        left, right, tsd = seq(toy.FLANK), seq(toy.FLANK), seq(5)
        e, ltr, _ = toy.make_element(rng, 400, 4200)
        start = sum(map(len, a_parts)) + len(left) + len(tsd) + 1  # 1-based
        el = Element("A", make_eid("A", "chr1", start, start + len(e) - 1), f"{state}{len(elements)}", "chr1",
                     start, start + len(e) - 1, "+", (start, start + ltr - 1),
                     (start + len(e) - ltr, start + len(e) - 1), tsd, 0.0, None, None, None, None)
        elements.append(el)
        truth[el.eid] = state
        a_parts.append(left + tsd + e + tsd + right)
        kept = tsd + e + tsd if state == "P" else tsd  # B = L T R at an empty site
        b_parts.append(left[:-patch] + toy.mutate(left[-patch:] + kept + right[:patch], rate, rng) + right[patch:])
        a_parts.append(seq(spacer))
        b_parts.append(a_parts[-1])
    return "".join(a_parts), "".join(b_parts), elements, truth


@needs_lastz
def test_close_pair_with_divergent_patches(tmp_path, monkeypatch):
    """A near-identical pair (d <= 0.001, so the pair's preset is asm5) whose sites sit in 5%-divergent patches:
    each element is called right, E or P (under asm5 scoring LASTZ fragments these windows' alignments into
    D, O, T and S calls, some at high tier). LASTZ scores every window with asm20's
    scoring, whatever the pair's preset."""
    a, b, elements, truth = close_pair(random.Random(1))
    presets = []
    real = genotype.preset_for_divergence

    def spy(d):
        presets.append((d, real(d)))
        return presets[-1][1]

    monkeypatch.setattr(genotype, "preset_for_divergence", spy)
    d = tmp_path
    fa, fb = d / "A.fa", d / "B.fa"
    for path, s in ((fa, a), (fb, b)):
        toy.write_fasta(path, {"chr1": s})
    with Fasta(fa) as A, Fasta(fb) as B:
        ctx = PairContext(Sample("A", fa, None, None, None), Sample("B", fb, None, None, None), A, B, elements, None,
                          d / "out", 1)
        out = genotype_pair(ctx, get_route("mm2"))
    [(div, preset)] = presets
    assert div <= 0.001 and preset == "asm5", presets
    with gzip.open(out, "rt") as fh:
        head = fh.readline().rstrip("\n").split("\t")
        got = {r["eid"]: r for r in (dict(zip(head, line.rstrip("\n").split("\t"))) for line in fh)}
    assert {eid: got[eid]["state"] for eid in truth} == truth, [(got[e]["state"], got[e]["tier"]) for e in truth]


# ---------------------------------------------------------------- options, parsing, defaults and failures


def test_default_backend_is_lastz():
    assert DEFAULT_BACKEND == "lastz" and cli.BACKEND == "lastz"
    for fn in (align_window, genotype_pair):
        assert inspect.signature(fn).parameters["backend"].default == "lastz", fn


def test_lastz_args_are_asm20_for_every_pair():
    """asm20's scoring (the engine's SCORE), ydrop = the cost of a MIN_SEG-bp gap (166), gapped threshold MIN_SEG,
    every position seeded with the 12of19 transition seed, chained, IUPAC codes accepted: one option set,
    whatever the pair's preset."""
    match, mismatch, gap_open, gap_extend = SCORE
    assert SCORE == (1, 4, 6, 2)  # minimap2 asm20
    args = lastz_args()
    assert args[:5] == [f"--match={match},{mismatch}", f"--gap={gap_open},{gap_extend}", "--ydrop=166",
                        f"--gappedthresh={MIN_SEG}", "--step=1"], args
    assert gap_open + gap_extend * MIN_SEG == 166
    assert {"--seed=12of19", "--transition", "--chain", "--gapped", "--ambiguous=iupac"} <= set(args)
    assert not any(x.startswith("--strand") for x in args)  # set per run


@pytest.mark.parametrize("preset", ["asm5", "asm10", "asm20"])
def test_every_preset_runs_lastz_as_asm20(tmp_path, monkeypatch, preset):
    """The pair's preset (asm5 for d <= 0.001, asm10 for d <= 0.01) never reaches LASTZ: both strands run with
    lastz_args(), asm20's scoring; an unknown preset still fails before anything runs."""
    log = tmp_path / "argv.txt"
    monkeypatch.setenv("PATH", stub(tmp_path, f'echo "$@" >> {log}; exit 0'))
    align_window("ACGT" * 50, "ACGT" * 50, preset, backend="lastz")
    runs = [line.split()[3:] for line in log.read_text().splitlines()]  # after target, query and strand
    assert runs == [lastz_args(), lastz_args()]
    with pytest.raises(ValueError, match="preset"):
        align_window("ACGT", "ACGT", "asm2", backend="lastz")


def test_parse_cigarx():
    assert parse_cigarx("1001=12I3X=") == [(1001, 7), (12, 1), (3, 8), (1, 7)]  # a count of 1 has no digits
    assert parse_cigarx("X=") == [(1, 8), (1, 7)] and parse_cigarx("5M2D") == [(5, 0), (2, 2)]
    assert parse_cigarx("") == []
    for bad in ("12", "3Q", "=4"):
        with pytest.raises(ValueError, match="malformed"):
            parse_cigarx(bad)


@needs_lastz
def test_ambiguous_bases_align_through():
    """IUPAC codes and an N run in B are ambiguous bases (--ambiguous=iupac), never a failed window: the
    sequence aligns through them and the N bases count as mismatches."""
    rng = random.Random(5)
    a = toy.rand_seq(6000, rng)
    b = a[:2000] + "R" + a[2001:3000] + "N" * 20 + a[3020:4000] + "y" + a[4001:]
    m = align_window(a, b, backend="lastz")
    assert m.aligned_bp(0, 6000) >= 5900 and m.seg_mm.sum() >= 20


def stub(tmp_path, script: str | None):
    """PATH holding only a `lastz` running `script` (none if None)."""
    d = tmp_path / "bin"
    d.mkdir()
    if script is not None:
        exe = d / "lastz"
        exe.write_text(f"#!/bin/sh\n{script}\n")
        exe.chmod(0o755)
    return str(d)


def test_each_strand_runs_chained_on_its_own(tmp_path, monkeypatch):
    """Two LASTZ runs per window, plus then minus, both chained: the minus strand's chain is its own, so its
    hits (the inverted copies) reach `inv` (unchained, the minus strand of a
    satellite window runs for minutes)."""
    log = tmp_path / "argv.txt"
    monkeypatch.setenv("PATH", stub(tmp_path, f'echo "$@" >> {log}; '
                                              r"[ $3 = --strand=minus ] && printf '0\t50\t0\t50\t-\t50\t50=\n'"
                                              "; exit 0"))
    m = align_window("ACGT" * 50, "ACGT" * 50, backend="lastz")
    runs = [line.split() for line in log.read_text().splitlines()]
    assert [r[2] for r in runs] == ["--strand=plus", "--strand=minus"]
    assert all("--chain" in r for r in runs) and m.inv == [(0, 50, 0, 50)] and len(m.seg_a) == 0


def test_lastz_error_leaves_the_window_unaligned(tmp_path, monkeypatch, caplog):
    """A window LASTZ fails on gives an empty AlnMap (its elements are U) and one warning, not a failed
    pair."""
    monkeypatch.setenv("PATH", stub(tmp_path, "echo 'bad sequence' >&2; exit 3"))
    with caplog.at_level(logging.WARNING, logger="ltrpav.localign"):
        m = align_window("ACGT" * 50, "ACGT" * 50, backend="lastz")
    assert len(m.seg_a) == 0 and m.inv == []
    [rec] = caplog.records
    assert "left unaligned" in rec.getMessage() and "lastz exit 3: bad sequence" in rec.getMessage()


def test_lastz_malformed_cigar_leaves_the_window_unaligned(tmp_path, monkeypatch, caplog):
    monkeypatch.setenv("PATH", stub(tmp_path, r"printf '0\t10\t0\t10\t+\t10\t10Q\n'"))
    with caplog.at_level(logging.WARNING, logger="ltrpav.localign"):
        m = align_window("ACGT" * 50, "ACGT" * 50, backend="lastz")
    assert len(m.seg_a) == 0 and "malformed LASTZ cigar" in caplog.text


def test_lastz_missing_fails(tmp_path, monkeypatch):
    monkeypatch.setenv("PATH", stub(tmp_path, None))
    with pytest.raises(RuntimeError, match="needs lastz on PATH"):
        align_window("ACGT", "ACGT", backend="lastz")
    assert len(align_window("", "ACGT", backend="lastz").seg_a) == 0  # nothing to align: no binary needed


# ---------------------------------------------------------------- temp folders and children of dying workers


def test_sweep_removes_only_dead_processes_folders(tmp_path, monkeypatch):
    """A worker killed outright leaves its ltrpav_lastz.<pid>.* folder: the sweep removes those of dead pids
    only, never a live process's, an unrelated name's (such as ltrpav_lastz_<random>, which a
    running job may still use)."""
    monkeypatch.setattr(localign, "_SHM", str(tmp_path))
    gone = subprocess.run(["true"], check=True)  # a pid that no longer runs
    dead = subprocess.Popen(["true"])
    dead.wait()
    names = [f"ltrpav_lastz.{dead.pid}.x1", f"ltrpav_lastz.{os.getpid()}.x2", "ltrpav_lastz_12345_ab",
             "ltrpav_lastz.notapid.x3", "other.1.x"]
    for name in names:
        (tmp_path / name).mkdir()
        (tmp_path / name / "a.fa").write_text(">a\nACGT\n")
    assert gone.returncode == 0 and localign.sweep_lastz_tmp() == 1
    assert sorted(p.name for p in tmp_path.iterdir()) == sorted(names[1:])


_DYING_WORKER = r"""
import os, sys
from ltrpav import genotype, localign
localign._SHM = sys.argv[1]
genotype._die_with_parent(os.getppid())  # a genotype worker's setup: SIGTERM cleans up and exits
localign.align_window("ACGT" * 50, "ACGT" * 50, backend="lastz")
"""


@pytest.mark.skipif(not sys.platform.startswith("linux"), reason="lists processes through /proc")
def test_sigterm_kills_the_lastz_child_and_removes_its_folder(tmp_path):
    """A worker killed by SIGTERM (its parent died, or the pool terminated it) kills its
    running lastz child and removes its temp folder before it exits."""
    pidfile, shm = tmp_path / "lastz.pid", tmp_path / "shm"
    shm.mkdir()
    bin_dir = stub(tmp_path, f"echo $$ > {pidfile}; exec sleep 60")
    env = {**os.environ, "PATH": f"{bin_dir}{os.pathsep}{os.environ['PATH']}"}
    proc = subprocess.Popen([sys.executable, "-c", _DYING_WORKER, str(shm)], env=env)
    try:
        t0 = time.monotonic()
        while not (pidfile.exists() and pidfile.read_text().strip()):
            assert proc.poll() is None and time.monotonic() - t0 < 30
            time.sleep(0.05)
        child = int(pidfile.read_text())
        [folder] = shm.iterdir()
        assert folder.name.startswith(f"ltrpav_lastz.{proc.pid}.")
        proc.terminate()
        assert proc.wait(timeout=10) == 128 + signal.SIGTERM
        t0 = time.monotonic()
        while Path(f"/proc/{child}").exists() and time.monotonic() - t0 < 5:
            time.sleep(0.05)
        assert not Path(f"/proc/{child}").exists() and not folder.exists()
    finally:
        if proc.poll() is None:
            proc.kill()
