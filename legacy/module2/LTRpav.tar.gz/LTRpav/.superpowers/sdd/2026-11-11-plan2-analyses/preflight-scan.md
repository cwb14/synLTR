# Pre-flight conflict scan: Plan 2 (analyses)

Plan: docs/plans/2026-11-11-plan2-analyses.md (12 tasks). Engine: branch plan1-final-fixes (read via git show; `E:` = file:line there).
Recomputed by hand and found right: Task 2 jackknife formula, block_size (4 cases), block_ids; Task 3 NJ matrix (additive, splits ab|de),
p_top 0.0129, p_kksc 1.0, outgroup_conflict 1/8; Task 4 D 2/6, cand 7, f4 num 2 / den 4 / f 0.5, second_donors, resolved_R .85 / resolved_S .40,
removed_frac .85, merged-leak probe (0.804 vs 0.586 -> D +0.157); Task 5 all nine reversed_blocks cases (601 rows, [0],[1],[1],[2],[0,0],[29],[],[],[]);
Task 6 tract rule, target_decoy (q[:25]=1/25, q[25:]=2/30, p 0.5 and 1.0); Task 7 DFOIL-alt 0.6/-0.6, signature codes, 20 distinct table keys;
Task 8 o_kind/d_kind (w=10), fractions /10; Task 9 closed form of the isolation likelihood, AIC 12 vs 4, u95; Task 12 re-binned LTRmix counts
(122/40, 2001/850, 8795/6467 -> .506/.404/.153, dD .354), ELAI mean .1695, 1/120, LTRmix line numbers.

## 1. Task pairs sharing a file or an interface

| # | Tasks | Produces -> consumes | Finding |
|---|---|---|---|
| A1 | 1 -> 2 | `Catalog.lengths: dict[str, ndarray]`, `block_size(cat)` | consistent (test uses a SimpleNamespace with `.lengths` only) |
| A2 | 1 -> 2,4,7,9 | `Catalog.proj_site` -> `block_ids(seq, mid, size)` (no genome arg) | consistent: every caller passes one genome's coordinates (D, P1, first X+Y genome); `proj_site` gives -1/nan where no call, but callers pass only rows with the site (P/S/T always have one, loci.py:432-ish check) |
| A3 | 1 -> 3..9,11 | `Catalog` fields, `cls/pcls/pcls_by/ptier_by/mid`, `FLAGS`, `TIER_CODE`, `age_bin`, `cluster_keys` | consistent; `FLAG_BIT` is used by tests but only named in a comment, not in Produces |
| A4 | 1 -> 3..11 | `tests/catalog_toy.py` (`write_run`, `simulate_run`, `GENOMES`, `TRACTS`, `ToyLocus`) | conflict: `ToyLocus(... flags={}, evidence={}, calls={})` as dataclass defaults raises ValueError (unhashable default; needs default_factory) |
| A5 | 1 -> 4,6 | `simulate_run(n_per_seq=3000)` layout "1001 + j*(seq_len-2000)//n_per_seq, 500 bp each" | conflict: spacing at 3000 is 332 bp < 500 bp, so toy elements overlap (Tasks 4 admixed/leak tests, Task 6 use 3000) |
| A6 | 1 <-> 9 | both edit `constants.py` (T1 appends 12 names, T9 appends `MG_MAX`, `IDENT_MIN_SITES`) | consistent (no name collision with E: constants.py); but see C2 (constants.py is an engine file) |
| A7 | 1,10,11 | `pyproject.toml` (T1 dependencies; T10 two scripts; T11 `ltrpav-plot`) | consistent |
| A8 | 1,11,12 | `docs/DESIGN.md` (T1 sec 12 "Build decisions (plan 2)", T11 sec 6, T12 sec 12 outcome) | consistent (three different sections; "Build decisions (plan 1)" exists at DESIGN.md:561) |
| A9 | 2 -> 3,4,7,9 | `StatRow`, `Findings.add/warn/extend/items`, `jackknife`, `d_ratio`, `STATS_COLUMNS` | consistent (11 columns = builder call 3) |
| A10 | 2 -> 10 | `read_stats`/`write_stats` vs `assemble` "a header line with the version and the run directory" | unclear: if that header line goes into stats.tsv, `read_stats` (expects STATS_COLUMNS first) and Task 11/12 readers break; plan does not say it is findings.txt only |
| A11 | 3 -> 4 | `four_point_ok(dist, cat, r, s, x, d)`, `sister_pair`, `relations(...)[3]` = one (G,G) `dist` | consistent (`pav_distances` returns two arrays, `relations` passes on one) |
| A12 | 3 <-> 4 | p_kksc fallback discovery (T3) vs `eligible_fallback`/`counted` (T4) | conflict (duplication with a different rule): T3 counts "no outgroup present" (outgroup missing allowed), T4 `counted` requires outgroup E; same discoverer/fallback logic written twice |
| A13 | 3 -> 8 | `Node`, `root_on`, rooted tree from `relations` | consistent |
| A14 | 3 -> 7,10 | `dist`; `run_stats` order 1-6 | consistent |
| A15 | 4 -> 6 | `Trio`, "Resolution WARNING as in Task 4" | consistent interface; the resolved-fraction/`RESOLVE_WARN` block is specified twice with no shared helper (see D3) |
| A16 | 4 -> 9 | `counted(cat, R, S, D, dist)`, `Trio` | consistent |
| A17 | 4 -> 10 | `trios(cat, fixed, size, dist)` raises AnalysisError for non-distinct/outgroup labels; T10 `--trio` raises CliError | consistent (both ValueError, cli.py:62 `_HANDLED`) |
| A18 | 5 -> 6 | `InvBlock.seqid_x/seqid_y: str` vs `inside(blocks, label, partners, seq, pos)` with `seq` = "label's fai indexes" | conflict: `inside` gets fai indexes but blocks hold seqid names and no `cat`/name map is passed, so it cannot compare (and shared names like "chr2" collide across genomes) |
| A19 | 5 -> 10 | `inverted_blocks`, `write_inversions`, `inversion_rows` | gap: `run_stats` step 3 names only `inverted_blocks (writes inversions.tsv)`; `inversion_rows` is never called in the order list |
| A20 | 5 -> 8 | `inv_site` as U reason | consistent (`inv_site` is a `reason`, classify.py:183, counted by `U_<reason>`) |
| A21 | 6 -> 9 | `paint(... self_counts: lid -> (sites, diffs))` vs `IDENTITY_COLUMNS` (`self_sites`,`self_diffs` per pair row) | gap: identity.tsv has pair rows only for loci where D's call into Y is P, but self counts are also needed for every counted RD/SD locus; row kinds and a self-only row are not defined, so paint cannot rely on lid coverage |
| A22 | 6 <-> 9 | `youngest_u95` formula in paint vs `identity.u95` | consistent value (`chi2.ppf(.95, 2(d+1))/2/n`); written twice (T6 precedes T9; see D4) |
| A23 | 6 -> 10,11 | `tracts.<R>.bed`, `posterior.<R>.tsv`, `decoy_*.<S>`; `write_paintings`, `paint_rows` | consistent; several trios with one recipient share a file via the sister/donor columns |
| A24 | 6 -> 12 | LTRpav statistic `mean_tract_bp` = L/(1-pi) vs LTRmix column `mean_tract_bp` (ltrmix.py:1378, `mean_tract_bp=Lh`) | conflict: same name, different quantity; T12 item 7 calls LTRmix's 197 kb "its L" and compares `L` and `mean_tract_bp` to it, but LTRmix's `mean_tract_bp` is its L (the switch scale) |
| A25 | 7 -> 3 | `taxa(cat)` uses `cat.groups`; D_dir/DFOIL pair `dist` | consistent |
| A26 | 7 internal | `DFOIL_ALT` pairs vs `PAIR_DISC` pairs | consistent: each of the 6 patterns per statistic used once; DOL's pairs differ from positional pairing but all share a common genome |
| A27 | 8 -> 11 | stats rows tests `mechanisms` (frac_E, frac_D_inside, ...) read by panel F | consistent |
| A28 | 9 -> 10 | `identity(cat, trio, size, threads, dist)` vs `run_stats(cat, trio, identity: bool, threads)` | consistent |
| A29 | 9 -> engine | `align_window(x, y, "asm20", "mappy")` | see C5 |
| A30 | 10 -> 11 | `stage_inputs(cat, stage, identity)` extended with `plot`; `STAGES = ("stats","paint")` | gap: `plot` inputs are run files, `stage_inputs` takes a Catalog that has no sheet path and no `tsd`; T11 says only "gains the plot stage" |
| A31 | 10 internal -> 10,11 | stage marker outputs: `run_stats` returns `list[Path]` | unclear: if the stats marker lists stats.tsv/findings.txt, the paint stage's `assemble` changes their size and the stats stage never reports "done, skip" (test_run_includes_analyses); plan does not say which files the marker lists |
| A32 | 10 -> 1 | `stage_inputs` "checksums of the samples sheet" | conflict: `Catalog` (T1) holds `samples` and `outdir` but not the sheet path |
| A33 | 10 <-> 11 | `cli.py` (stage functions; `plot_main`; run ends with plot, figure error = warning) | consistent; T10's `ltrpav run` test then also renders the figure on `make_world` (needs the no-trio fallback) |
| A34 | 11 -> 6,5,2,1 | file columns read by overview (POSTERIOR/TRACT/INV columns, stats `source` keys) | consistent; `tsd` is not a Catalog field, so "R's TSD known" must come from loci.tsv/work/elements directly; `Fasta.fetch` is 0-based half-open (seqio.py:107) vs 1-based catalog |
| A35 | 12 -> 10,11 | `main3/samples.tsv` labels B73, TIL18, TIL01, Zd; `--identity --threads 32` | consistent; item 1 says "sisters B73v5 + TIL01, recipient B73v5" but the sheet label is `B73` (FASTA B73v5) |
| A36 | 12 -> LTRmix | bins "0<K<=0.01 / K>0.01" re-binned from LTRmix `stats.tsv` vs LTRpav "0<K<0.01 / K>=0.01" | conflict: counts at K = 0.01 exactly sit in LTRmix's middle bin and cannot be moved from its right-closed bins, so the expected 2,001/850 and 8,795/6,467 are LTRmix's bins, not "re-binned to LTRpav's" |
| A37 | 12 -> 3 | `outgroup_conflict` "must equal QC.md's outgroup estimate (same definition)" | unverifiable: engine qc.tsv (loci.py:315-324) has no outgroup metric; QC.md does not exist yet (`main3/QC.md` absent) |

## 2. Each task against itself

| # | Task | Agrees with itself? | Detail |
|---|---|---|---|
| B1 | 1 | mostly | Files list matches Steps; eleven builder calls = 11. Roundtrip test recomputed: cls S [0,1,-1,1], cls D [1,1,0,-1], `pcls_by` [-1,1,-1,-1], all consistent. Defects: dataclass mutable defaults (A4), overlapping toy elements at n_per_seq 3000 (A5); `len(cat.lid) > 4000` holds (about 5,800 loci); toy writes `skipped_bad_strand`, a reason the loaders never emit (real: malformed_columns, malformed_coordinates, no_ltrs, no_ltr_pair, status_not_pass, bad_seq_id, malformed_ltr_bounds, malformed_k2p); step 1 lock refresh contradicts the repo (C6) |
| B2 | 2 | yes | all five numeric tests recompute (est, se with 19/20, block sizes 10,000 / 5,000,000 / 3,000,000 / 10,000, block id splits) |
| B3 | 3 | one test unsound | `test_kksc_reads_the_third_genomes_calls`: with only R+D loci (x3) the sister pair is (R,D) and the donor S, so D's calls are not read and "n_R+D 2" cannot arise; the test needs R+S loci to make D the donor. Others recompute: 12/2/1, p_top .0129, p_kksc 1.0, tie warns, 1/8, shared_derived 3 |
| B4 | 4 | yes, with one spec departure | all expected values recompute (see header). `rows` vs `cand` vs `cand.sum()==7` consistent. Fallback discovery narrows DESIGN 7.1 ("any annotated genome other than R and S") to the four-point rule; disclosed as builder call 11, needs the user's confirmation |
| B5 | 5 | yes, one gap | all nine cases recompute. `test_block_found` lists blocks for R~S and S~D only; the outgroup genome O (resolved P/E, with coordinates) also gives S~O (and R~O, D~O collinear) blocks, so "exactly one block each" must be scoped to the genome pairs named. Pseudo-code `load_catalog(**simulate_run(...))` is not valid (ToyRun is not a mapping) |
| B6 | 6 | yes | tract rule, target-decoy, class order (RD, RS, both, neither, missing, old = PAINT_CLASSES order), u95 recompute. `shortest_callable` bound "k_hi <= 20" not derivable from the text (depends on the fit); `test_forward_backward` passes `starts=[0, 4]` with n=4, so `starts` includes a trailing sentinel; the signature does not say so |
| B7 | 7 | yes, one external dependency | `test_dfoil_alt_signatures_from_branch_lengths` gets its expected pattern counts from "the table in the review", not in the plan |
| B8 | 8 | yes | o_kind/d_kind (w=10 for TSD_DEFAULT 5), 4+1+2+1+2=10, Dollo cases consistent with the stated rules; MIN_SEG is used in the d_kind text but not in Consumes |
| B9 | 9 | yes | likelihood closed form re-derived and correct; 12 pair rows = 6 x 2; `test_ltr_counts_exact` (6 diffs in 800 sites) matches `make_element` (LTR 400, int 3000). Helpers `substitute`, `INT_POSITIONS_12` undefined |
| B10 | 10 | partly | Files vs steps match. Gaps A10, A19, A31, A32; test "exactly one stderr line" contradicts `_execute` (C4); Step 5 real-data paths do not exist (C9); `pytest -q` doubles addopts' -q (C7) |
| B11 | 11 | yes | files match steps; PNG `info["dpi"] >= 300` is likely false for a 300-dpi save (Pillow reports 299.9994) |
| B12 | 12 | partly | 14 items = "14 sections"; Step 1 precondition `main3/QC.md` currently absent; `analyses.done` not in the Files list; items A24, A35, A36 |

## 3. Engine assumptions contradicted by plan1-final-fixes

| # | Plan side | Engine side | Contradiction |
|---|---|---|---|
| C1 | File Structure adds `analysis/` and `plot/`; Task 10 stage keys use `stage_key(stage, inputs, params)` only | checkpoint.py:43 `NON_ENGINE = ("sim",)`; :11-13 "analysis or plotting packages get their own fingerprints ... each joins NON_ENGINE" | plan never adds `analysis`/`plot` to NON_ENGINE nor gives them a fingerprint: creating them changes `engine_fingerprint()` (checkpoint.py:67) and stales every engine stage; and analysis edits never invalidate analysis parts (stage_key :134 holds only the engine fingerprint) |
| C2 | Builder call 1 and Task 12: Plan 1 runs "stay valid without re-genotyping"; Tasks 1, 9, 10, 11 edit `constants.py`, `cli.py` | checkpoint.py:63-67 fingerprints every module except NON_ENGINE subpackages (constants.py and cli.py are engine); cli.py:351-362 `_check_pair_files` fails `merge`/`run` when a pair file's marker engine differs | any edit to constants.py or cli.py changes the fingerprint: `ltrpav run`/`ltrpav-merge` on main3 then refuse its pair files (or re-genotype for hours); only `ltrpav-stats/paint/plot` on a finished run are unaffected |
| C3 | Task 10 stage markers `work/analysis/<stage>.done.json` | checkpoint.py:127-137, :153-170 (marker carries engine fingerprint) | analysis markers carry the engine fingerprint, so any engine edit (C2) also reruns analyses; harmless but unplanned |
| C4 | Task 10 `test_cli_imports_without_scipy`: `ltrpav run` exits 1 with "exactly one stderr line" | cli.py:158-167 `_execute` adds a stderr handler at INFO (genome/pair/done lines) before the stage runs | the run logs many stderr lines before the CliError; the assertion must be "last line" |
| C5 | Builder call 2 / Task 9: "the engine's own `align_window` ... same aligner", called with backend "mappy" | constants.py:50 `DEFAULT_BACKEND = "lastz"`; cli.py:59 `BACKEND = DEFAULT_BACKEND`; DESIGN "Build decisions (plan 1)" #6 (mappy kept only for the API) | the engine's calls come from LASTZ; the identity layer would use another aligner, so "same aligner, one more pass" and comparability with the PAV calls are false |
| C6 | Task 1 Step 1: `mamba env export -n ltrpav > environment.lock.yml` | environment.lock.yml:107-110 (commit 84c8088) no `pip: ltrpav==`, no `prefix:`, ends with a comment | the export reintroduces the machine prefix and pip-pinned `ltrpav` that 84c8088 removed |
| C7 | Tasks 10-12 `pytest -q -m "not slow"` | pyproject.toml addopts `"-q --strict-markers"`; commit 84c8088 "CI's pytest at one -q" | `-q` doubles |
| C8 | Global Constraints: "Branch `plan2-analyses`, cut from `plan1-engine`" | `plan1-engine` is 21 commits behind `plan1-final-fixes` (git rev-list); it has no NON_ENGINE, no `RecordSkips`, old QC (reciprocity without resolved filter), no `_check_pair_files` | the plan's assumptions (loaders warn-and-skip counts, fingerprint scope, QC definitions quoted in Task 3/12) hold only on final-fixes; the cut point must be it (or plan1-engine fast-forwarded first) |
| C9 | Task 10 Step 5: copy `bakeoff/chr10/runs/<DEFAULT_ROUTE>/` with `qc.tsv` | constants.py:48 `DEFAULT_ROUTE = "flank-mm2"`; disk: runs hold `flank-mm2_2k` (and _5k/_10k/_20k), no `flank-mm2`; no run there has `qc.tsv` | path does not exist and `qc.tsv` cannot be copied (`run_summary` tolerates a missing qc.tsv, so only the copy step fails) |

Checked and consistent with the branch: `CALL_COLUMNS` (classify.py:69-72) and every pair-file column used; `loci.tsv` header (tables.py:13-14, 29); member = P/annot at the first member only, `extra` members not written (loci.py:13-15, 21-22); flag names (classify.py: inv, nestB, host_empty, inherit, tsd_match, solo_tsd, adjacent, small_ins, filler; loci.py: conflict, annot_conflict, no_call); `Element`/`ELEMENT_COLUMNS` (elements.py:9-30), `make_eid`, `read_elements`, `write_elements`; `Sample` fields and roles (samples.py:7-25); `Fasta(path, cache_dir).lengths()/fetch` (seqio.py:63,103,107); `file_checksum/stage_key/is_done/mark_done/clear_done` signatures; `cli._execute/_options/CliError`, `_HANDLED` covers ValueError; `write_loci_tsv/write_qc` signatures; qc.tsv columns scope,metric,value and genome-scope `annot_sensitivity`, `skipped_<reason>` (loci.py:280-310); P/S/T calls always carry a B site (loci.py check "a P/S/T call without a B site"); `SLOP_TSD_MULT`, `TSD_DEFAULT`, `WINDOW_PAD`, `MIN_SEG` names; dl/dr sign convention (classify.py:192-204). The final-fix changes to QC reciprocity/annot_agree (loci.py:53-60, 228-262) and the windows file (anchor positions) are not used by the plan; pair-file `anchor_left/right` are still distances (classify.py: `win.anchor_distances`) and the plan never reads them.

## 4. Defects a code reviewer would raise

| # | Task | Defect |
|---|---|---|
| D1 | 1 | `ToyLocus` mutable dict defaults in a dataclass (A4) |
| D2 | 3,4 | the fallback-discovery and "discoverer's own calls, x and y resolved, outgroup rule" block is specified in `p_kksc` (T3) and again in `counted`/`eligible_fallback` (T4) with different outgroup rules (A12); no shared helper named |
| D3 | 4,6 | "Resolution WARNING as in Task 4": the resolved-fraction computation and `RESOLVE_WARN` warning is specified in two modules, plus again in Task 7 ("resolution rows") |
| D4 | 6,9 | `chi2.ppf(.95, 2(d+1))/2/n` appears in `paint` (T6), `identity.u95` (T9) and in T6's test; T6 runs first so it cannot import T9's `u95`: put it in a shared module |
| D5 | 1-9 | many tests are a signature plus a comment only (`test_missing_or_mismatched_run`, `test_jackknife_two_blocks_has_no_se`, `test_stats_roundtrip`, `test_findings_order`, `test_root_on_outgroup`, `test_sister_tie_warns`, `test_distances_pairwise_complete`, `test_four_point`, `test_run_summary_quotes_qc`, ...); as written they assert nothing, and `test_null_and_admixed` has `for seed in range(1, 6): ...` with an ellipsis body |
| D6 | 4 | `test_null_and_admixed` asserts |Z| < 3 on five seeds with no stated tolerance or fallback; a failing seed invites tuning the toy (the plan's own rule: change rules only for independent reasons) |
| D7 | 5 | `test_block_found` body is pseudo-code and ignores the S~O pair (B5) |
| D8 | 6 | `test_paint_null` ("no tract with q <= 0.05") passes vacuously when no tract is called; `test_paint_many_scaffolds` ("every post finite") asserts nothing about tracts |
| D9 | 7 | `test_dfoil_alt_signatures_from_branch_lengths` takes its expected counts from an external review table; the test is not self-contained |
| D10 | 9 | with BED annotations (strand "." unless column 6, bed.py:66) every identity pair is skipped (strand 0), silently: no findings line is required for it, so the layer returns an empty result without saying why (Review Focus 2 covers K2P only) |
| D11 | 10 | stderr assertion contradicts `_execute` (C4); `stage_inputs` cannot reach the sheet (A32); stats-marker output list unspecified (A31) |
| D12 | 11 | PNG `>= 300` dpi assertion likely fails at exactly 300 dpi (299.9994) |
| D13 | 12 | `mean_tract_bp` compared with LTRmix's differently defined column of the same name (A24); "re-binned" bins not re-binnable (A36); label `B73v5` vs sheet `B73` (A35) |
| D14 | 1 | toy elements overlap at n_per_seq 3000 (A5), the layout the null and admixed tests rely on |
