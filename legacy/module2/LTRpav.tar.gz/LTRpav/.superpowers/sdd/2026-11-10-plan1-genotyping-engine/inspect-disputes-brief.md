# Inspection: who is right where the engine and AnchorWave disagree on real chr10

You are investigating, not fixing. Nothing in the repo changes.

## Context
LTRpav genotypes LTR-RT presence and absence between assemblies. For each element of genome A it builds a window
around the element and its flanks in A and in B. It aligns the two windows locally (mappy, strand-split), and a
classifier reads the alignment as P/S/T (present), E (absent: an empty site with one TSD copy), D (deleted with
flank), O (another insertion at the site), G (assembly gap) or U (unresolved). Tiers are high, medium or low.

Read `src/ltrpav/classify.py`'s module docstring (repo `/data2/chris/maize_introgression/LTRpav`) for the rules.

A diagnosis (`diag-breakpoints-report.md` in this directory) prototyped a syntenic anchor net on real chr10
(B73v5 -> TIL18). It resolved 790 more elements than the stock engine. These agree with an AnchorWave
whole-chromosome alignment read through the same classifier (the "read-out") less often:
- 95.0% class agreement, against 98.96% for calls the stock engine already resolved;
- 114 T against read-out O, all medium tier;
- 83 E against read-out O, 82 of them high tier;
- 25 P against read-out O;
- present-versus-absent contradictions rise from 34 (24 high tier) to 58 (37 high tier).

The same disputes mostly occur with AnchorWave's own anchors and the engine's window aligner (the `awpaf` run),
so they come from the window alignment or the classifier, not the anchors. Newly resolved elements sit in wide
windows: the B window's median is 101-171 kb, against 18 kb for the rest.

**A second signal.** On real chr10, about 20% of E calls have their empty site inside an element that TIL18's own
annotation contains (`e_in_annot` in qc.tsv). The rate is the same for every route and direction. In the 6-Mb sims
it is 2-9%.

Possible readings:
- correct biology: nested insertions into an older element that is annotated in TIL18 but not in B73;
- annotation asymmetry;
- an E error mode.

Neither the engine nor AnchorWave is truth. Its global alignment can align unrelated sequence: the read-out's
per-window identity has a 5th percentile of 0.87-0.89 and a minimum of 0.51.

## Data
Paths are under `D = /data2/chris/maize_introgression/benchmark_pav/bakeoff`; read `D/diag_breakpoints/memo.md`
first.
- **Syntenic-net calls** (B73v5 -> TIL18): `D/diag_breakpoints/run_syn_chr10/`, which holds a work dir with
  windows and calls. The per-element comparison with the read-out is in `D/diag_breakpoints/m3_detail.tsv`.
- **Read-out:** `D/chr10/anchorwave_readout/`, holding calls, windows and `segments.npz`.
- **awpaf run:** `D/chr10/runs/awpaf/`.
- **Stock mm2 run:** `D/chr10/runs/mm2/`.
- **Inputs:** FASTAs `D/chr10/fasta/`, annotations `D/chr10/annot/`, elements `D/chr10/runs/mm2/work/elements/`.
- **AnchorWave MAF:** `D/anchorwave/anchorwave.maf`. Never read it whole; use `segments.npz`.

## Questions
1. **High-tier E against read-out O.** Cover all 82, from evidence you can compute: B-window width, where A's
   flanks align in the B window (one place or several), TSD match, whether the B sequence at the read-out's site
   holds an insertion, and its identity to anything.
   - Inspect at least 15 by dotplot: A window against B window, with the engine's local hits and the AnchorWave
     segments drawn on it.
   - For each, decide who is right: engine, read-out, both wrong, or undecidable. Name the error mechanism, for
     example A's flanks aligned to a paralogous copy inside a wide B window, AnchorWave aligning unrelated
     sequence, or a nested structure.
   - Give counts by verdict and mechanism.
2. **Present-versus-absent contradictions,** high tier: all 37 in the syntenic run, by the same method, with at
   least 10 dotplots.
3. **T against O:** 10 of the 114, by dotplot.
4. **e_in_annot:** take 20 random E calls (seeded) from the stock mm2 run whose site lies inside a TIL18-annotated
   element. Classify each:
   - the containing TIL18 element is the ortholog of a B73 element or host that B73's annotation lacks (correct
     nested E);
   - the A element's site really lies inside the TIL18 element because A's element is nested in an ortholog the
     annotation missed in A;
   - an engine error;
   - something else.

   Use the qc definition in `src/ltrpav/loci.py` (`_annotation_agreement`). Then estimate the share of each class
   over all such E calls, with a binomial 95% interval.
5. **Verdict.** Is there an engine defect? If so, describe it precisely:
   - which rule or step;
   - which inputs trigger it;
   - how many calls it touches.

   Then propose a principled fix: reasoned from the biology or the alignment geometry, with no threshold tuned on
   these cases. Write the proposal into your report. Do not implement it. You may measure it once, cheaply, only
   if a scratch prototype takes under 30 minutes, and you must write the proposal before measuring. AnchorWave and
   any truth are yardsticks, never training data.

## Constraints
- **Read-only:** the repo; everything under `D` except your own directory `D/inspect_disputes/`.
- **The engine is being edited concurrently,** and `ltrpav_bench` imports it from the working tree. If you import
  `ltrpav`, use a snapshot of commit bfeeb55:
  `git -C /data2/chris/maize_introgression/LTRpav archive bfeeb55 src | tar -x -C D/inspect_disputes/snap`,
  then run Python with `PYTHONPATH=D/inspect_disputes/snap/src` (not `python -I`, which ignores PYTHONPATH).
  Verify that `ltrpav.__file__` points into the snapshot. Never import from the live tree.
- **Compute:** at most 4 threads, each probe under `timeout 15m` in the foreground. Export
  `NUMPY_MADVISE_HUGEPAGE=0` for every Python process. Use env `ltrpav_bench`.
- **Running jobs:** two bake-off batches may still be running (PIDs 3523920 and 662846). Never touch them or their
  outdirs.
- Load the `making-figures` skill before the first plot; its quick-plot rules suffice for diagnostic dotplots.
- No subagents. American English.

## Report
Write `inspect-disputes-report.md` in this directory:
- tables per question;
- one line per inspected dotplot (case id, verdict, mechanism, figure path);
- the defect and its proposal, if any;
- what would change your verdict.

Return ONLY:
- status;
- per-question verdict counts;
- the defect, if any, in 2-3 sentences, with the proposal in 2 sentences;
- concerns;
- the report path.
