# Task 24 — controller rulings (bind as much as the brief; override it where they conflict)

## Phasing (ledger ruling R12)
1. Phase A (one dispatch): brief Steps 1-4, the Step 6 setup and launch, and the Step 7 read-out *classification*.
   Long batches are launched detached and the dispatch returns with PIDs, logs and expected outputs; it never waits
   on a multi-hour job. Phase B (a later dispatch, after the controller has seen every job finish): Step 5, the
   Step 6 metrics, the Step 7 comparison and dotplots, Steps 8-9, plus any short follow-up runs Step 4 needs (the
   lastz/wfa backends on a top-two route that is not mm2 or fastga).

## Places and environments
2. Everything outside the repo lives in `/data2/chris/maize_introgression/benchmark_pav/bakeoff/`: `sims/`
   (simulated pairs), `runs/<sim>/<variant>/` (one `ltrpav run` outdir per sim and variant), `chr10/`
   (FASTAs, annotations, runs), `anchorwave/` (exists, finished, read-only now), plus the brief's scripts. Run in
   the `ltrpav_bench` env (it has the editable LTRpav, pywfa, lastz, samtools, anchorwave); record versions in
   PARAMS.md and a `memo_bakeoff.md` (CLAUDE.md memo format). `run/`, `inputs/` and LTRmix results are read-only.
3. Machine: 256 cores, ~1 TB RAM, shared (load ~80 from other users' jobs). At most 64 threads in total at any time
   (so at most two 32-thread runs at once), <= 250 GB RSS per job. Every batch over 15 min runs as
   `setsid -f nohup <cmd> > log 2>&1 < /dev/null`, PID verified with `pgrep -af` then `ps -o pid,ppid,sid,cmd -p
   <pid>` (SID = PID, PPID 1). Write a `done` marker (or exit-status file) per batch so completion is checkable.
   Note: `nproc` reports 8 in this shell (an environment variable caps it); pass thread counts explicitly.
   Every bake-off script and job exports `NUMPY_MADVISE_HUGEPAGE=0` (the package guard only works when ltrpav is
   imported before numpy; a probe that imported numpy first spent 390 s in kernel time instead of 46 s).

## Parameters (Step 1)
4. PARAMS.md is written before any run. For each parameter: what it does, its default, the choice, why. Choices
   come from reasoning about the use case (maize-like genomes, 1-30 kb insertions, 0-3% divergence, dense
   repeats), never from sim scores. Include the current LTRpav values (`src/ltrpav/constants.py`: MAPPY_BEST_N=5,
   PRESET_CUTS, MM2_CHUNK/OVERLAP, SPLIT_INDEL, FLANK_* etc.) and whether you would change them. Carry-forward
   questions to answer there: does `best_n`/`-N`/`-p` let rival paralogous copies (~2% divergent) appear as
   secondaries under asm20, which the anchoring margin depends on; chunk overlap overhead (2 x 10 kb context per
   100 kb chunk); window cost under strand-split mapping. Any sensitivity variant (e.g. mm2 with a larger -N) is
   declared in PARAMS.md before it runs and enters the winner rule as its own candidate.
5. The flank caps (2/5/10/20 kb) are run by a wrapper that sets the flank module's FLANK_CAP before `ltrpav run`
   (one outdir per cap); verify the cap took effect (e.g. maximum flank reach in the pieces or a debug line).
   Alternative backends are selected the same way (register from `backends.py`, then set the backend the CLI
   passes to genotype_pair). Whatever the wrapper patches is listed in PARAMS.md.

## Backends (Step 2)
6. `backends.py` registers `lastz` and `wfa` through `ltrpav.localign.register_backend(name, fn(a_seq, b_seq,
   preset) -> AlnMap)`; build the AlnMap with `ltrpav.localign.alnmap_from_hits` (hits need q_st, q_en, r_st,
   r_en, strand, mlen, cigar as (length, op) pairs; minus-strand hits go to `inv`). The `maf` read-out is NOT a
   registered backend (ruling R7): the read-out script builds windows and AlnMaps from the MAF itself and calls
   `classify_window` directly. Toy checks on P, E, D (tests/toy.py cases) for lastz and wfa in a scratch test
   under the bakeoff dir. Give wfa a per-window guard (e.g. skip windows whose span makes WFA's memory explode,
   returning an empty AlnMap so the call is U, counted and reported) rather than letting one window stall a run.

## Simulations and sim runs (Steps 3-4)
7. `01_sim.sh`: `ltrpav-sim pair` with the Task 22 defaults (including n_same_site), annotation
   `run/B73v5_LTRs` (LTRquest prefix), FASTA `inputs/B73v5.fa`, regions R1/R2/R3 of the brief, seeds 1 and 2
   (6 pairs) into `sims/R{1,2,3}_s{1,2}/`.
8. `02_run_sims.py`: variants mm2, fastga, flank-mm2 (caps 2/5/10/20 kb), flank-blast (10 kb), hybrid, all with
   the mappy backend; then lastz and wfa backends with the mm2 and fastga routes. 32 threads, `/usr/bin/time -v`
   per run (wall, peak RSS into a runs table), detached as one batch, resumable (skip variants whose outdir is
   complete). Each run under `timeout 30m` (an 8-Mb pair; a timeout is recorded as a failure, not retried).

## Real chr10 (Step 6)
9. Chr10-only inputs for B73v5, TIL18, TIL01: FASTAs by `samtools faidx` (seqids kept: B73v5_chr10, TIL18_chr10,
   TIL01_chr10); annotations in the same format the whole-genome run will use (the LTRquest prefix
   `run/<G>_LTRs`): the prefix's `_depth*_clean_ltr.tsv` tables filtered to the chr10 seqid under a new prefix in
   `chr10/annot/`. (The plan named the GFF3; the TSV prefix keeps the loader identical to the whole-genome run.)
   Check that the chr10 element count equals the chr10 subset of the whole-genome load.
10. Every route of rule 8 (mappy backend) on the three genomes (one `ltrpav run` per route: 3 unordered pairs,
    6 directions) at 32 threads, each under `timeout 2h` (about 4x the cost bar scaled to this input: 3 pairs x
    2.5 h / ~14); plus mm2 at 64 threads on B73 vs TIL18 only (thread scaling); plus the lastz and wfa backends on
    the mm2 route for B73 -> TIL18 only (`ltrpav-genotype --pair`, anchors reused from the mm2 run), each under
    `timeout 45m` (the bar for one chr10 direction is ~5 min). A timeout means the cost bar failed; record it with
    the progress made (windows done / total, from the logs or chunk files). Thread budget: all bake-off jobs
    together use at most 64 threads at any moment (e.g. the sims batch at 32 plus the chr10 batch at 32, the
    read-out inside one of those budgets or after).
11. Whole-genome extrapolation: per pair, wall and RSS scaled by (sum of the two genome lengths) / (sum of the two
    chr10 lengths); state that RSS of index-based routes may not scale linearly and say which way it errs.

## AnchorWave read-out (Step 7)
12. `06_anchorwave_readout.py`: MAF (check which of anchorwave.maf / anchorwave.f.maf is the one-to-one alignment
    with inversions under -IV, from AnchorWave's docs; say which you used and why) -> blocks (split at indels >=
    SPLIT_INDEL as `read_paf` does) -> the engine's chain/net and `make_windows` -> one AlnMap per window from the
    MAF segments inside it (no realignment) -> `classify_window` -> a calls file in CALL_COLUMNS for the B73 chr10
    elements in TIL18 (seqids were renamed to `chr10` for AnchorWave; map them back). Use the same chr10 element
    set as the route runs. The TIL18 -> B73 direction from the same MAF is welcome if it is a symmetric swap.
    Mirror `ltrpav.genotype._Genotyper.rows` (fetch window sequences, reverse-complement B for strand -1, then
    `classify_window` and `call_row`) with the MAF AlnMap in place of `align_window`. The MAF holds very long
    blocks (the first spans 123 Mb of chr10): stream it, never hold more than one block pair in memory.
    Also write the MAF as a PAF with a `cg:Z` =/X CIGAR (`read_paf` splits it at long indels) named
    `<B73 label>__<TIL18 label>.paf` (the chr10 samples sheet's labels) in a directory, and run the existing `paf:<dir>` route (mappy windows) on the B73/TIL18
    chr10 pair as one more candidate ("AnchorWave anchors"): it separates AnchorWave's anchoring from its
    base-level alignment. Label it as a yardstick, not a default candidate (AnchorWave is ~30 h per maize pair).

## Decision (Phase B; fixed now, before any result)
13. Cost bar ("about 2 h" for a maize-sized pair at 32 threads, DESIGN 3): met when the extrapolated whole-genome
    unordered pair (anchoring once, both directions) takes <= 2.5 h wall and <= 250 GB peak RSS. The 25% allowance
    is for timing noise on the shared server; the bar's purpose (21 pairs in about a day at 64 threads) still holds.
14. Precision bar: high-tier precision >= 0.95 for P and for E on the pooled sims (tp and fp summed over the 6 sims
    and both directions); per-sim values reported beside the pooled one.
15. Winner = best pooled `correct_resolved_frac` among candidates meeting both bars; ties within 0.005 go to the
    cheaper. The local backend is chosen the same way with the winning route. If no candidate meets both bars, do
    not stop: pick the best candidate meeting the precision bar, report the cost miss plainly in REPORT.md and
    dead_ends.md, and keep going (the user is away and asked for independent work).
16. Phase B also refreshes two stale DESIGN lines: 5.3 says "mappy with long join" (the engine maps strand-split
    without long join) and the flag list near line 217 names boundary_offset (no such flag).
