# Task 7 review: `--discovery`, `--emission`, `--block-size` and their stage keys

BASE c7ccacd, HEAD 4f3973e (3da735c, then 4f3973e). Branch plan3-benchmark. Reviewer scratch:
`$Q` = `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t7review/`.
Every probe ran from `git archive` snapshots (`$Q/snap/{b12,base,head}`), with `ltrpav.__file__` asserted inside the
snapshot, env ltrpav's bin on PATH, `NUMPY_MADVISE_HUGEPAGE=0`, at most 4 threads, under `timeout 15m`. Nothing in
the repo, main3/ or main3_analyses/ was written.

## Spec Compliance

| # | Requirement | Verdict | Evidence |
|---|---|---|---|
| 1 | `ltrpav-paint --discovery {recipient,any}`, `--emission {em,decoy}`, with defaults from `PAINT_DISCOVERY` and `PAINT_EMISSION` | ✅ | cli.py:128-135 take choices and defaults from constants.py:24-27. A bad choice exits 2 (probes B16 and B17: "invalid choice: 'EM' (choose from em, decoy)"). |
| 2 | `ltrpav-stats --block-size BP`: an integer of at least `BLOCK_MIN`, exit 2 below it, the rule without it | ✅ | `block_arg` cli.py:81-89 and the option cli.py:115-118. 9999, 0 and -5 exit 2 with one line naming `--block-size` (probes B11-B13). 5, 9999, "1e6" and "x" exit 2 in the test (test_cli_analysis.py:757-762). |
| 3 | `stats.block_size(cat, override=None) -> int` | ✅ | stats.py:71-82. An override is validated: bool and non-integer values and values below BLOCK_MIN raise ValueError. Otherwise the rule applies, unchanged. |
| 4 | Row `StatRow("pav","jackknife","all","all","block_bp", size, loci="none", note="rule" \| "--block-size")` | ✅ | report.py:447-448 matches it exactly. Toy rows: (40000, rule), (1000000, --block-size), and an explicit 40000 gives (40000, --block-size) (probes B1, B4, B9). main3 copy: `pav jackknife all all block_bp 1000000 . . . none --block-size` (implementer's probe_b.log). |
| 5 | D_pav's SE changes with `--block-size`; the estimate does not | ✅ | Toy: 0.267139 ± 0.0661 (rule, 40 kb) against ± 0.0841 (1 Mb) (probes B1 and B4). main3 copy: 0.290544 ± 0.0392 (425 blocks of 5 Mb) against ± 0.0345 (1,950 blocks of 1 Mb) (probe_b.log). The test checks the same: test_cli_analysis.py:765. |
| 6 | Each option is in its stage's key at every value, and in the marker's meta and params | ✅ | `OPTIONS` report.py:121-122. `stage_params` adds `stage_options(stage, options)` unconditionally (report.py:217), so the defaults are keyed too. The meta records `**opts` (report.py:268). The default markers hold `block_size: null`, `discovery: recipient` and `emission: em` in both meta and params (test_cli_analysis.py:774-777). The four painting variants give four distinct paint keys (f75df12c, 67653789, 2f8fb1be, ea48abfe; probe A). |
| 7 | Same options skip; a changed option reruns; `--block-size` reruns only stats | ✅ | Probe A: decoy runs, decoy again skips, the defaults run and the defaults again skip. Explicit defaults (`--emission em --discovery recipient`) also skip (A14). A default repaint after the variants reproduces the first painting byte for byte, with the same key (A12 = A2). Probe B: `--block-size 1000000` reruns stats and leaves the paint key unchanged (asserted). Paint then skips (B6), the same block size skips (B7), and 2 Mb, 40 kb or the rule reruns (B8-B10). |
| 8 | Paint key holds no `block_size`, and nothing paint reads depends on it | ✅ | See "Paint key without block_size" below. |
| 9 | Old markers read as the defaults with no KeyError, through `.get` | ✅ | `stage_options` uses `.get(name, default)` (report.py:197), and `_stale` reads it from the marker meta (report.py:307-308). `_changed` fills a missing option with its default before comparing (report.py:411). Real BASE-made markers read by HEAD (probes E1/E2) give stats and paint "the analysis code changed" only: no KeyError, and no option is named. The plot refuses, then a variant paint, stats and the plot all run. The implementer's main3 check0 shows the same on the Plan 2 markers. |
| 10 | `stale_parts` and the plot's refusal stay correct after a variant painting | ✅ | `plot_refusals` is unchanged (report.py:346-373). After `--emission decoy`, a default `ltrpav-plot` draws the decoy painting (A6: stale_parts {} and plot_refusals {}, a new overview), then skips (A7). After stats `--block-size`, the default plot draws (B5). After any+decoy plus `--block-size 1000000`, the plot draws (C3). A hand-edited marker whose meta disagrees with its key is refused (test_cli_analysis.py:784-793). |
| 11 | `ltrpav run` gains no option and runs at the defaults | ✅ | `git diff 12d3e6c 4f3973e -- src/ltrpav/cli.py` is empty, and `run_analyses` passes None (cli.py:164-171). Probe C: after `--block-size 1000000` and any+decoy, `ltrpav run` reruns stats, paint and plot at the defaults (C4). Run again, it skips all three (C5). After a decoy painting it reruns paint only (C7). `ltrpav run --emission/--discovery/--block-size` exits 2 (test_cli_analysis.py:697-700). |
| 12 | The CLI imports without scipy; DISCOVERY is in constants.py | ✅ | constants.py:24. cli.py:49-57 imports the analysis constants only. paint.py:89 re-exports DISCOVERY. test_cli_imports_without_scipy passes. |
| 13 | The help strings are concise | ✅ | stats has one new option line (3 wrapped lines), paint two (5 and 4 lines). test_help_is_short passes (< 40 lines each). The help is accurate against the code. |
| 14 | DESIGN 7.1, 7.3, 7.4, 8 and 10.4 | ✅ (⚠️ nit) | DESIGN.md:375-377, :391-395, :411-417, :484-490 and :635 each match the code (checked against cli.py, report.py:445-483 and paint.py:450, :870-874). DESIGN 12's decision 17 exists (DESIGN.md:794). One wording nit: Minor 3. |
| 15 | The brief's five tests | ✅ | test_cli_analysis.py:653, :675, :703, :735 and :767. They have teeth: a mutant that ignores the marker's options in `_stale` (report.py:308 → None) fails four of the five (`$Q/mut2`). |
| 16 | Task 6 minors in a first, separate commit | ✅ | 3da735c touches only paint.py and test_paint.py. See "Task 6 minors" below. |
| 17 | Engine isolation | ✅ | All 7 STAGE_MODULES fingerprints are byte-equal at 12d3e6c and 4f3973e (`$Q/fp/{b12,head}.tsv`: anchor, blastdb and raw ebbfd97f…; elements a78af75d…; genotype_chunk and genotype_pair 52071c27…; mm2_index 28f6fc79…). The engine constants.py and checkpoint.py are unchanged since 12d3e6c. |
| 18 | Authorship and commits | ✅ | Both commits are cwb14 as author and committer, with no trailers and no AI attribution. The subject of 4f3973e is the brief's exact text. |

### Paint key without block_size: sound

The paint stage calls `trios(cat, trio, block_size(cat), dist)` (report.py:510), always at the rule's size. Three
facts make its outputs independent of the block length:
- The roles come from `est < 0` (trio.py:164-168). `jackknife` computes `est = stat(all rows)` before it looks at
  any block (stats.py:101). `common.guard` keeps the estimate (common.py:47-54). `sister_pair` and `discover` take
  no size. With `--trio`, no estimate is used.
- paint.py never calls `block_size` or `jackknife`, and `run_paint` discards the role rows (report.py:510).
- The one stats-stage output paint reads is identity.tsv. Its rows are `tab.out(cat, scope, young)`
  (identity.py:434). `young` comes from the full-data split `s` (identity.py:693-696), not from the blocks.
  - Probe D on the sequence toy: `stats --identity`, then `--block-size 10000`, then the rule again. identity.tsv
    stays byte-identical (536d64473d22), `identity_usable` stays True, and paint skips twice.
  - `identity_usable` reads the stats marker's `block_size` (report.py:334 → :307-308), so a `--block-size` stats
    part does not make identity.tsv unusable.

### Default path unchanged

On toy seed 3, BASE and HEAD stats plus paint give byte-identical paint rows, paint findings, tracts, posterior,
decoy posterior, inversions.tsv, mechanisms.tsv and stats findings. stats.rows.tsv differs only by the new
`block_bp` row (`$Q/probe/w_F_*`). On the main3 copy, the implementer's probe found the default painting
byte-identical at BASE and HEAD (probe.log).

### Task 6 minors

- **m1 has teeth.** In `$Q/mut`, paint.py:450 was mutated to `classes(cat, Y, X, D)`, dropping the discovery rule.
  `test_decoy_e0_fixed` then fails: e0 [0.2824, 0.7176] against 0.28828 (test_paint.py:463). The test also asserts
  that the toy separates the two rules (test_paint.py:465).
- **m2** is plan-mandated: the test was kept and its docstring now says it is not null evidence
  (test_paint.py:544-546).
- **m3** is as ruled. On a collapsed decoy fit, the findings line keeps n_D, n_X and e0 and says "e1 NA: the fit
  collapsed…" (paint.py:875-882). test_paint.py:527-534 pins it.
- **m4** is as ruled:
  - `classes()` defaults to `PAINT_DISCOVERY` (paint.py:190);
  - the module docstring cites `classes(cat, Y, X, D, discovery)` (paint.py:28);
  - a fallback painting gives one WARNING, the no-decoy one extended (paint.py:870-874), pinned by test_paint.py:583.

## Strengths

- **The stage-key design is small and has one source of truth.**
  - `OPTIONS` plus `stage_options` (report.py:121-122, :190-197) feed the key, the meta, the stale-part
    recomputation and `_changed`.
  - The stale check rebuilds the key from the options the marker recorded. So a variant painting is current under
    its own options, and only a real file, code or tool change makes it stale. No option is ever blamed spuriously
    (probes E2 and A4-A15).
- **Options are validated before the marker is cleared** (`_check_options`, report.py:229-238, :249-250). A bad
  API call cannot destroy a finished stage.
- **The paint key's independence from the block size is argued in the code** (report.py:508-509) and in DESIGN
  (DESIGN.md:394-395), and it holds on inspection and in probe D.
- **The tests go beyond the brief.** They cover `ltrpav run` repainting at the defaults after a variant, exit 2 for
  the three options on `ltrpav run`, a stripped non-default marker reading as stale, and a hand-edited meta/key
  mismatch refused by the plot.
- **The start log line names any non-default option** (cli.py:209-214), for example "…, --discovery any,
  --emission decoy". That makes the variant visible in Task 8's job logs.

## Issues

### Critical

None.

### Important

None.

### Minor

1. **A `--block-size` stability check on an `--identity` run is destructive unless `--identity` is repeated.**
   This is Plan 2 behavior that Task 7 now exposes; it is a lead for Task 11.
   - `ltrpav-stats --block-size X` without `--identity` deletes identity.tsv (report.py:490-495).
   - That changes the paint stage's inputs, so the paint part is left out and `ltrpav-plot` refuses until paint
     reruns.
   - The implementer's own main3 copy shows it (`p3t7/m3/probe_b.log`): b_stats logs "deleting identity.tsv… paint:
     its part is left out… its inputs changed (identity.tsv)", and b_plot_before exits 1.
   - With `--identity`, the whole LASTZ layer is realigned for a jackknife-only change.
   - DESIGN 7.3 and 10.4 (DESIGN.md:392-394, :635) present `--block-size` as the stability check without this
     caveat.
   - Fix (docs only): Task 11's brief should run the block-size check in its own view, or with `--identity` at
     LASTZ's cost. Optionally, add one clause to DESIGN 7.3.
2. **The left-out advice drops a variant painting's options.**
   - The assembly WARNING and the `_LEFT_OUT` line say "rerun ltrpav-paint (or ltrpav run)" (report.py:128-129,
     :292-293).
   - For a stale `--emission decoy` or `--discovery any` part, following either command replaces the variant with
     the default painting.
   - This is harmless for Task 8, whose variants each live in their own view. For users, the message could name the
     options the marker recorded.
3. **DESIGN 7.4 says the e\* rows are "NA when the fit collapsed"** (DESIGN.md:415-416). paint.py:744-751 writes NA
   for a skipped painting too. A nit.
4. **paint.py:28, the m4 docstring edit, is 152 characters long** in a module wrapped at about 115. ruff's
   configured rules do not include E501, so it passes. Rewrap it.
5. **No test pins that `--block-size` reaches `direction` and the identity layer.**
   - The tests check D_pav's SE only (test_cli_analysis.py:735-765).
   - All three share the one `size` variable in `run_stats` (report.py:445, :453, :457, :467, :483), so the risk is
     low.

### Notes (no action)

- An explicit `--block-size` equal to the rule's value (`--block-size 40000` on the toy) has a different key from
  the rule (null) and reruns, with note `--block-size` (probe B9). This is consistent with DESIGN 8's "null: 7.3's
  rule".
- `block_arg` accepts `" 20000"` and `"1_000_000"`, because Python's `int()` does (probes B14 and B15). This is
  harmless.
- `test_old_marker_reads_defaults` builds its "old" marker synthetically: its key still holds the default options.
  Real BASE-made markers are covered by probe E2 and the implementer's main3 check0.

## Probes run by the reviewer

| probe | what | result |
|---|---|---|
| `$Q/fp` | STAGE_MODULES fingerprints at 12d3e6c and 4f3973e | all 7 equal |
| `$Q/mut` | m1 mutant (paint.py:450 without discovery) | test_decoy_e0_fixed FAILS |
| `$Q/mut2` | stale check ignores the marker options (report.py:308 → None) | 4 of the 5 Task 7 tests FAIL |
| `$Q/probe/A.log` | stats, paint, plot, decoy ×2, plot ×2, stats, any+decoy, any, defaults ×2, explicit defaults, plot | run/skip exactly as keyed; stale_parts and plot_refusals {} throughout; the default repaint is byte-identical |
| `$Q/probe/B.log` | stats, paint, plot, `--block-size` 1 Mb (paint key unchanged), plot, paint skip, block-size reruns, bad values | as keyed; exit 2 below BLOCK_MIN and for bad choices |
| `$Q/probe/C.log` | `--block-size` + any+decoy, plot, `ltrpav run` ×2, decoy, `ltrpav run` | run resets to the defaults, then skips; after decoy it reruns paint only |
| `$Q/probe/D.log` | sequence toy, `--identity` with 10 kb vs the rule | identity.tsv identical; paint skips; plot draws |
| `$Q/probe/E*.log` | BASE-made markers read by HEAD | no KeyError; "the analysis code changed" only; plot refuses, then reruns draw |
| `$Q/probe/w_F_*` | BASE vs HEAD default outputs (seed 3) | identical except the new block_bp row |
| focused pytest (`$Q/snap/head`) | the 5 Task 7 tests, help, imports, M14; test_paint m1-m4 tests | 8 + 4 passed |
| `ruff check --no-cache` (`$Q/snap/head`) | | All checks passed |

## Implementer's suite and probes (final state)

- **Suite** (`p3t7/suite/suite.log`, `suite.done`): exit 0. The log has 1,278 dots and no F, E, s or x mark (the
  quiet flags suppress the summary line). That is 1,273 at Task 6 plus Task 7's 5 tests. The tree was clean at
  4f3973e throughout.
- **Focused run** (`p3t7/focused.done`): exit 0.
- **main3 probes** (`p3t7/m3/probes.exit`: a=0, b=0; `probes.done` present):
  - probe.log:
    - BASE and HEAD default paintings are byte-identical (six files);
    - the Plan 2 markers read with no KeyError;
    - default, decoy and any+decoy rerun and skip as keyed;
    - the guards hold: fai unchanged, 0 files newer under main3 and main3_analyses.
  - probe_b.log:
    - `--block-size 1000000` stats gives the block_bp row and D_pav 0.290544 ± 0.0345 (1,950 blocks) against
      ± 0.0392 (425 blocks of 5 Mb);
    - it deleted the copy's identity.tsv, which left paint out, and the plot refused (Minor 1);
    - a decoy paint followed, then the plot drew; stale_parts and plot_refusals were {};
    - 0 files newer under main3 and main3_analyses.

## Assessment

**Approved.**
- Spec ✅. Quality: Approved, with 0 Critical, 0 Important and 5 Minor.
- The stage keys behave exactly as Task 8 needs. A variant painting is never skipped by another variant's marker,
  and a default `ltrpav-plot` after a variant neither draws a stale part nor refuses a current one.
- 4f3973e is fit to snapshot. Minor 1 belongs in Task 11's brief; the rest are polish.
