import warnings
import numpy as np
from scipy.optimize import minimize
from scipy.special import gammaincc

def nll(par, k, n):           # LTRmix verbatim
    s, m = np.exp(par)
    c = 1.0 + 1.0 / (n * m)
    q = gammaincc(k + 1, c * n * s)
    lp = s / m - np.log(m * n) - (k + 1) * np.log(c) + np.log(np.maximum(q, 1e-300))
    return -lp.sum()

def fit(k, n, start=(1e-3, 1e-2)):
    r = minimize(nll, np.log(start), args=(k, n), method="Nelder-Mead", options=dict(xatol=1e-6, fatol=1e-6, maxiter=4000))
    return np.exp(r.x), r

k = np.ones(6); n = np.full(6, 800.0)
with warnings.catch_warnings():
    warnings.simplefilter("error")
    try:
        (s, m), r = fit(k, n)
        print("verbatim:", s, m, r.fun, r.nit, r.message)
    except Exception as exc:
        print("verbatim raised:", type(exc).__name__, exc)
(s, m), r = fit(k, n)
print("verbatim (warnings on):", s, m, r.fun, r.nit, r.message)
for lm in (-5, -10, -13, -14, -20, -40):
    print(lm, nll(np.array([np.log(0.00125), lm]), k, n))
