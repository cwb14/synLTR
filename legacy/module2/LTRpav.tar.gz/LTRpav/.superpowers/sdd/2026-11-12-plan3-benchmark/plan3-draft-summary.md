# Plan 3 draft summary (revised after the science review and the pre-flight scan)

- Plan: `docs/plans/2026-11-12-plan3-benchmark.md`, 16 tasks, revised 2026-11-12.
- Branch base: `plan1-engine` at 12d3e6c (Plan 2 merged; `plan2-analyses` deleted).
- Pre-flight: `preflight-scan.md`; all 32 conflicts applied (`preflight-applied.md`).
- Review: `plan3-review.md`. Fixes and their plan lines: `plan3-applied.md`, where all 33 findings are applied.
- Drafting probes, in the session scratch `plan3draft/`:
  - `probe_msprime.py`;
  - `simpair20/`, `geno20*`;
  - `probe_direction.py`, `probe_outgroup_ext.py`;
  - `drafting_probes_v2.txt`.

## Tasks
1. Branch, msprime extra (env, lock, CI), and the population model: demography with lineage populations, ancestry,
   truth tracts, `--demography` JSON.
2. Events on the genealogy: insertions (with nesting), losses including replacement, SNPs, small indels; non-ACGT
   backbone bases handled.
3. One-pass genome builder (copy noise, backbone K2P with SNPs) and assembly gaps.
4. Truth: Plan 1's rules, plus O on replacement; SNPs and indels are noise. Annotations, and tracts in sample
   coordinates.
5. `ltrpav-sim pop`: orchestration (`PopResult`), outputs, command line.
6. Decoy-anchored emission model (an option, off by default), with e0/e1 rows.
7. `ltrpav-paint --discovery/--emission` and `ltrpav-stats --block-size`, with their stage keys.
8. Simulation harness: snapshot; backbone; simulator calibration from main3 before the pilot; direction predictions;
   grid; run driver with 6 views; LTRmix library converter; pilot; realism check; budget gate.
9. Scoring (both tools, recipients inferred for the head-to-head) and `RULES.md`, dated before any scoring:
   - null bar;
   - calibration reading;
   - genotype bar;
   - painting null;
   - variant adoption with a realized-FDR bar;
   - degeneracy;
   - direction;
   - D gap.
10. Grid launch, and 3 LTRquest-annotated runs from the pinned env.
11. Simulation results and decisions. A variant becomes the default only by rule.
12. Real inputs (EDTA prep, sheets) and the detached genotyping queue (mm2's first pair alone, with RSS sampling).
13. Six genomes: default trio view, PT positive control, negative control, TIL25 donor, direction (PT-like simulated
    power), f4-ratio, HPC1 and Inv4m in PT.
14. *Zea* genus event (EDTA, with Zd as the decision-11 case), sweet orange, EDTA portability.
15. Stability: `--anchor mm2`, a 5-kb flank cap, block sizes 1-20 Mb.
16. DESIGN 10.3 rerun at the end (final verdicts with the calibrated null), DESIGN 12 outcome, memo, hand-off.

## Compute estimate (32 threads in total; detached jobs; at most 250 GB)

**Measured:**
- msprime with 7 genomes: 9.6 s at 5 Mb and 157 s at 20 Mb (about length²).
- Simulated-pair genotyping: ~140 calls/s at 16 threads.
- main3: 14.6 min per maize directed pair at 32 threads.
- LTRmix on simulated libraries: 1.2 min.
- LTRquest on 0.9 Gb: 1.6 h.
- Insertions per genome: 146/Mb before losses at the calibrated t_o of 900k.

**Estimated:**
- One 7-genome run: 100-Mb backbone, ~177-Mb genomes, ~13,900 elements, 36 pairs. ~68 min at 16 threads, two at a time,
  so ~34 min effective.
- Grid: 88 + bottleneck nulls on 7 genomes, 26 trio runs, 3 LTRquest runs. ~77 h with 30 bottleneck nulls, ~65 h with
  10.
- Real benchmark: ~22 h. That is six 9 h, genus 3 h, citrus 0.5 h, portability 1 h, stability 7 h, analyses 1.5 h.
- **Total: ~87 h (3.6 days) with 10 bottleneck nulls**, which the gate is expected to choose. With 30 the total is
  ~99 h, past 96.

The pre-registered gate (Task 8) counts every run:

```
(N7 x h7 + 26 x h_trio) / 2 + 3 x 1.4 + 22, with N7 = 88 + bottleneck nulls
```

- It uses 30 bottleneck nulls if the total fits in 96 h, else 10.
- If 10 does not fit either, it applies the 50-Mb backbone fallback.
- No other null, f, Ta or dropout level is ever cut.

## Calls where DESIGN is silent (revised; one line each, with its reason)
1. **Backbone.** Ten 10-Mb B73 windows, one per chromosome (seed 20261112), each an independent chromosome. Hudson's
   cost is about length²; the grid fits the gate. LTRmix's middle-40% low-recombination rule is applied per window, as a
   named heuristic.
2. **Outgroup.** O is added at t_o = 900,000 generations, Ne 150,000. t_o is the smallest of {120k, 300k, 600k, 900k,
   1.2M} whose perfect-genotype outgroup conflict is at most main3's measured upper bound, 0.032. At 120k the conflict
   was 0.20-0.23. This is simulator calibration, not method tuning, and is recorded in DESIGN 12.
3. **Taxa** in `src/` are A, B, C and O, because Plan 2 forbids *Zea* names there.
4. **TE rates.** LTRmix's are kept (lam 1.2e-10, delta 1/900,000) for comparability, and the backbone replaces LTRmix's
   root stem. The densities after genotyping are reported against main3, and Z is projected by locus count, not
   length.
5. **Loss mix.** It is measured from main3's own calls: the derived states, in TIL18 and TIL01, of B73 elements Zd
   carries. Solo 0.123, flank deletion 0.164, partial 0.511, replacement 0.202 (pooled counts 646, 861, 2,685, 1,063).
   These are now also the `src` defaults. Replacement (unrelated sequence at the
   site, mean 13,538 bp pooled over main3's O calls) adds the O state the old 4:3:2 split lacked.
6. **Small indels.** At mu/10 on the backbone only. Inserted copies take substitutions only, plus LTRmix's 0.5% copy
   noise per insertion; LTRs stay identical at insertion.
7. **Nesting** in simulated insertions follows a subtree process at lam per bp of the element, depth at most 2.
8. **Truth.** Built from event records with Plan 1's rules, "inherited by Y" replacing "pre-split", and O on
   replacement. SNPs and small indels never break an empty-site window.
9. **Bottleneck variant.** Ne 5,000 for 2,000 generations after the A-B split (Nb/d ≈ 2.45, Eyre-Walker 1998; Wright
   2005). 30 bottleneck nulls if the gate allows, else 10.
10. **Direction scenarios.** 8 reverse runs, 3 PT-like runs (pulse into A1's lineage) and 8 positive-control runs. The
    positive control is the first pre-listed design the drafting probe found to orient both ways: every Ne 1,000, A1's
    lineage split at 2,000, C1's at 30,000, f 0.5 at 500 generations.
11. **Designs.** All 88 main runs use 7 genomes. The 26 dropout runs (10 nulls and 3 gene-flow runs per level) are
    trios.
12. **Annotation noise.** Base dropout 0.1 and jitter 0.05 (Plan 1). One-sided dropout in A1 at 0.2 and 0.4.
13. **Gaps.** 2.5 per Mb per genome (Plan 1), conservative against main3's real G rate.
14. **Pre-declared trio.** `--trio A1,B1,C1` for calibration and power. The head-to-head painting uses inferred
    recipients for both tools, with wrong recipients counted alike.
15. **Painting truth.** Scored only in C>A runs (A1 is the recipient).
16. **Decoy-anchored model.** e0 is fixed at the decoy's class frequencies; EM fits e1, pi and L. The fitted e0/e1 are
    reported, and degeneracy is tested.
17. **Adoption rules, fixed before scoring:**
    - painting null on 30 nulls, plus 20 one-sided dropout nulls judged alone;
    - realized FDR at most 0.05 (CP upper bound at most 0.10);
    - recall higher by a paired sign test (p < 0.05), precision not lower, NA pairs dropped and counted;
    - `anydecoy` for joint adoption.
18. **Direction rule.**
    - Predicted codes are written first: "none" for every maize-like pulse.
    - The implementation is confirmed by the positive control.
    - False calls are counted in the default and bottleneck nulls.
    - The real direction is "not estimable" if the PT-like runs read "none".
19. **Null bar** read as at most 1 of 30. **Calibration:** the chi-square interval of SD(null Z) includes 1, and the
    mean is within 2 SE of 0.
20. **LTRmix inputs.** 4 libraries (A1, B1, C1, C2). Its own recipient choice is scored like LTRpav's. Its
    presence/absence accuracy is scored against truth, and LTRpav's `no_outgroup_filter` D stands beside its D tests.
21. **Plan 2's gaps.** s from the identity layer on the nulls, against the true 0.36% and LTRmix's s. The D gap by rule
    8, whose expected outcome is stated first.
22. **LTRquest runs.** Three grid runs' genomes, as trios, from the pinned `ltrquest_<HEAD>` env. Cleanup, then
    `record check` must print `reuse`.
23. **Decision 11** is tested on the simulations: view `nodonor` (C1 unannotated, the merge rerun in the view). Zd is
    genotype-only in the genus run. The rule is unchanged.
24. **Positive control (six genomes).** D_pav(PT, B73; TIL18) > 0 with Z > 3: LTRmix's own positive-control trio.
25. **Citrus "called".** Tracts at any q cover >= 50% of a true tract (LTRmix 04_eval). Recall at q <= 0.05 is also
    reported.
26. **10.3 rerun.** It reads the six-genome run's B73/TIL01/TIL18 trio (`six/views/main`, made in Task 13). main3
    predates later engine commits.
27. **Stability.**
    - `--anchor mm2`: its first pair runs alone with RSS sampling; ~4.5 h.
    - 5-kb cap, through the bake-off's route patch.
    - `--block-size` 1-20 Mb.
28. **Frozen code.** Detached jobs import a `git archive` snapshot through PYTHONPATH. Envs are frozen while jobs run.
    Eval scripts are fingerprinted, and every run is rescored with the final code.
29. **Concurrency.** Two 16-thread simulated runs at a time.
30. **EDTA prep.** Keep `Method=structural`, prefix seqids, map Zn's `N` to `chrN`. Counts are cross-checked against
    `main3/qc_fixed/edta`.
31. **No inversions** are simulated, so the painting's inverted-block flags go untested on the sims.
32. **K2P sources.** Simulated copies take K2P from their LTRs. Backbone copies take the source p plus the sample's
    derived LTR SNPs.
33. **No figures** in Plan 3; Plan 4 draws them.

## Questions only the user can answer
- **None new.** The user decides decision 11 after Plan 3. Plan 3 measures and reports it: simulated truth
  (`nodonor`) and the genus `zd` case.
- **The calls easiest to revise** if the user disagrees:
  - the calibration targets (call 2's conflict bound, call 5's loss-mix source);
  - the bottleneck duration (9);
  - the positive-control design (10).

## Calls added at pre-flight
34. **Calibrated `src` defaults.** They are the exact pooled values (0.123, 0.164, 0.511, 0.202; 13,538 bp), not
    2-decimal rounding. 0.17 was not a rounding of 0.164, and 2-decimal values would not sum to 1. `demography.json`
    governs every run either way.
35. **Where an unconfirmed direction test is labeled.** If rule 7 does not confirm DFOIL-alt, Task 11 changes the
    `direction` rows' note in `analysis/direction.py` (with its test) to "not validated by simulation (Plan 3)". It is
    not done in the benchmark tables only.
36. **Parked items, folded in.**
    - Six-genome inversion blocks are reported with the caller's residual caveat: 11 main3 blocks were sparse on their
      pair's second genome.
    - The overview's limits with 20 trios (~264 mm page; scaffolds can be called chromosomes) are recorded for Plan 4.

