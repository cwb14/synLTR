#!/usr/bin/env python3
"""Real-genome spike-in: a parviglumis library (TIL11) with tracts replaced by the syntenic elements of a second
mexicana (TIL25), placed through TIL11-TIL25 library orthologs. Writes the spiked library (FASTA + table, ltrmix
generic input) and the truth BED (spiked intervals, TIL11 coordinates)."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import argparse
import os
import sys

import numpy as np

sys.path.insert(0, "/data2/chris/maize_introgression/LTRmix")
import ltrmix  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--base", required=True, help="LTRquest prefix of the recipient base (TIL11)")
    ap.add_argument("--source", required=True, help="LTRquest prefix of the tract source (TIL25)")
    ap.add_argument("--out", required=True)
    ap.add_argument("--frac", type=float, default=0.10, help="target fraction of the genome in tracts")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("-t", type=int, default=16)
    a = ap.parse_args()
    ltrmix.ARGS = ltrmix.argparse.Namespace(verbose=True, threads=a.t)
    ltrmix.ARGS_THREADS[0] = a.t
    rng = np.random.default_rng(a.seed)
    lb = ltrmix.load_library("BASE", a.base)
    ls = ltrmix.load_library("SRC", a.source)
    ib, isrc = ltrmix.Index(lb), ltrmix.Index(ls)
    ltrmix.set_block_size({"b": lb, "s": ls})
    po = ltrmix.orthology(lb, ls, ib, isrc)
    pb = np.where(po.orth_b >= 0)[0]
    ps = po.orth_b[pb]
    chroms = [c for c in sorted(set(lb.chrom), key=ltrmix._chrom_key) if c.split("_")[-1].startswith("chr")]
    ends = {c: int(lb.end[lb.chrom == c].max()) for c in chroms}
    total = sum(ends.values())
    tracts, used = [], 0
    tries = 0
    while used < a.frac * total and tries < 10000:
        tries += 1
        c = chroms[rng.integers(len(chroms))]
        L = int(np.exp(rng.uniform(np.log(1e5), np.log(1e7))))
        s = int(rng.integers(0, max(ends[c] - L, 1)))
        e = s + L
        if any(tc == c and not (e < ts or s > te) for tc, ts, te in tracts):
            continue
        anc = pb[(lb.chrom[pb] == c) & (lb.mid[pb] >= s) & (lb.mid[pb] <= e)]
        if len(anc) < 3:
            continue
        sc = set(ls.chrom[po.orth_b[anc]])
        if len(sc) != 1:
            continue
        tracts.append((c, s, e))
        used += L
    keep = np.ones(lb.n, bool)
    add = []
    for c, s, e in tracts:
        keep[(lb.chrom == c) & (lb.end >= s) & (lb.start <= e)] = False
        anc = pb[(lb.chrom[pb] == c) & (lb.mid[pb] >= s) & (lb.mid[pb] <= e)]
        xa, ya = lb.mid[anc].astype(float), ls.mid[po.orth_b[anc]].astype(float)
        cs = ls.chrom[po.orth_b[anc]][0]
        o = np.argsort(ya)
        xa, ya = xa[o], ya[o]
        sel = np.where((ls.chrom == cs) & (ls.mid >= ya.min()) & (ls.mid <= ya.max()))[0]
        for j in sel:
            k = np.clip(np.searchsorted(ya, ls.mid[j]), 1, len(ya) - 1)
            # local interpolation between the two nearest anchors (handles either orientation)
            y0, y1, x0, x1 = ya[k - 1], ya[k], xa[k - 1], xa[k]
            x = x0 + (ls.mid[j] - y0) * ((x1 - x0) / (y1 - y0) if y1 != y0 else 1.0)
            x = int(np.clip(x, s, e))
            add.append((c, x, j))
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    with open(a.out + ".fa", "w") as fa, open(a.out + ".tsv", "w") as tb:
        tb.write("seq_id\tk2p\ttsd\tstrand\tltr5_len\tltr3_len\torigin\n")
        recs = [(lb.chrom[i], int(lb.start[i]), "base", i) for i in np.where(keep)[0]]
        recs += [(c, x, "spike", j) for c, x, j in add]
        recs.sort(key=lambda r: (ltrmix._chrom_key(r[0]), r[1]))
        seen = set()
        for c, x, origin, i in recs:
            lib = lb if origin == "base" else ls
            seq = lib.seq[lib.offs[i]:lib.offs[i + 1]].tobytes().decode()
            st = x if origin == "base" else x - len(seq) // 2
            while (c, st) in seen:
                st += 1
            seen.add((c, st))
            name = f"SPK_{c.split('_', 1)[-1]}:{st}-{st + len(seq) - 1}#{lib.cls[i] or 'LTR'}"
            fa.write(f">{name}\n{seq}\n")
            tb.write(f"{name}\t{lib.k2p[i]:.6g}\t{lib.tsd[i] or '.'}\t{lib.strand[i]}\t{lib.l5[i]}\t{lib.l3[i]}\t"
                     f"{origin}\n")
    with open(a.out + ".truth.bed", "w") as f:
        for c, s, e in sorted(tracts, key=lambda t: (ltrmix._chrom_key(t[0]), t[1])):
            f.write(f"SPK_{c.split('_', 1)[-1]}\t{s}\t{e}\n")
    print(f"{len(tracts)} tracts, {used / 1e6:.1f} Mb ({used / total:.3f} of the genome); removed "
          f"{int((~keep).sum())} base elements, added {len(add)} source elements")


if __name__ == "__main__":
    main()
