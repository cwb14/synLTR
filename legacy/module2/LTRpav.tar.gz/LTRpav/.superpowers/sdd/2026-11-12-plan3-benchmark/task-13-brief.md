### Task 13: Six genomes: controls, direction, f4-ratio, PT loci, and the default trio view

**Files** (in `benchmark_pav/plan3/real/`):
- `six/views/{all,main,pos,neg,til25,hpc1}/`, `six/score_six.py`, `six/six_results.tsv`, `six/RESULTS.md`;
- `common/compare_papers.py`: PRELIM's logic plus an output-name prefix; Task 16 owns its final edits;
- `memo.md` (append), `benchmark_pav/dead_ends.md`.

- [ ] **Step 1: Views** (`view.sh`, snapshot 1 or 2).
  - `all`: `ltrpav-stats` then `ltrpav-paint` (every trio, roles from the data; direction rows for maize/mexicana, with
    parviglumis as the sister taxon and Zd as the outgroup).
  - `main`: `--trio B73,TIL01,TIL18`. This is the default trio view that Tasks 14-16 read; Task 16 adds `--identity` in
    its own copy.
  - `pos`: `--trio PT,B73,TIL18`.
  - `neg`: `--trio TIL11,TIL01,TIL18`.
  - `til25`: `--trio B73,TIL01,TIL25`.
  - `hpc1`: `--trio PT,TIL01,TIL25`.
- [ ] **Step 2: Copy `compare_papers.py`.** Copy `main3_analyses/compare_papers.py` (post-final-wave) to
  `common/compare_papers.py`.
  - Add only an output-name prefix, `--prefix`: its outputs `prelim_papers.tsv` and `prelim_tables/` are otherwise
    hard-coded.
  - The analysis directory is its existing `--run DIR`. The logic stays PRELIM's.
  - Record the source sha256.
  - Run it on view `main`: `--run six/views/main --prefix six_main`.
- [ ] **Step 3: `score_six.py` writes `six_results.tsv`** with columns `item ltrpav ltrmix bar verdict note`. Bars are
  DESIGN 10.4's; LTRmix's values come from `$P/benchmark/results/six/analysis/trio_summary.tsv`.
  1. **Positive control.** D_pav(PT, B73; TIL18) > 0 with Z > 3, PASS or MISS. This is LTRmix's own positive-control
     trio. D_pav(PT, TIL01; TIL18) and D_pav(B73, TIL01; TIL18) are reported beside it.
  2. **Negative control** {TIL11, TIL01; TIL18}: |Z| < 3 is PASS. Otherwise MISS, explained when the gene-space SNP D
     (+0.052, Z 3.0; `benchmark/gene_snp`) and LTRmix's D3 agree in sign.
  3. **TIL25 as donor:** reported, since DESIGN 10.4 sets no bar. Give D_pav(B73, TIL01; TIL25), its Z, and whether
     Z > 3. LTRmix's tests did not reach Z > 3 there; the SNPs give +0.050, Z 2.4.
  4. **Direction, mexicana <-> maize.** The DFOIL-alt signature and D_dir, read under `RULES.md` rule 7.
     - The simulated power is the `ptlike` runs': predicted and observed codes, and calls over 3 runs.
     - If they read "none", the row says that DFOIL-alt is not expected to orient a pulse into one maize lineage under
       this demography, and that direction is therefore not estimable here. Not a miss.
     - The posctl confirmation is cited, so a "none" is not read as an implementation fault.
  5. **f4-ratio of B73,** when TIL25 qualifies as the second donor. Reported against ELAI 17.0%.
  6. **HPC1 in PT** (Barnes; a 10.3 row).
     - Place B73's HPC1 gene (`loci.v5.tsv`: chr3:8,497,916-8,499,434) on PT with `minimap2 -x asm5`. LTRmix placed it
       at PT chr3:9.088 Mb.
     - Report PT's maximum posterior within +-50 kb in view `hpc1`, and any tract with its q.
  7. **Inv4m in PT:** a B73~PT inverted block overlapping chr4:172.9-188.1 Mb (`inversions.tsv`). Reported.
     - Every six-genome inversion block is reported with the caller's known residual (parked from Plan 2): on main3,
       11 blocks were sparse on their pair's second genome, where own-pair rows inside the y span are exempt.
     - A block sparse on its second genome is flagged as such.
  8. **Decision 11:** the count of trios with an unannotated donor; 0 is expected. The user decides decision 11 after
     Plan 3.
- [ ] **Step 4: `RESULTS.md`.** The table, each MISS with its investigation (also in `dead_ends.md`), and the caveat that
  PT is a Toronto Agreement release.
- [ ] **Step 5: Memo.** Append this task's dates, commands and outputs to `real/memo.md`, with the `claude --resume` name.

---

