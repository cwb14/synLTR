# Task 15 report: stability (anchoring route, flank cap, jackknife block length)

Status: DONE_WITH_CONCERNS. Every step ran on snapshot 2 and exited 0; no engine or analysis defect was found. The
concerns are scientific (two six-genome control verdicts depend on the jackknife block length) and one addition beyond
the brief (a genome-set control). Date 2026-11-14, analysis steps 17:33:14-17:48:01 EST, table, tests and writing to
18:15. P=/data2/chris/maize_introgression; S=$P/benchmark_pav/plan3/real/stability.

## 1. Views and copies made, with commands

All through `$S/run_step.sh NAME STEP ARGS` (exports SNAP_SHA=6282541, sources plan3/common/env.sh, sets
OMP/OPENBLAS/MKL/NUMBA_NUM_THREADS=1, runs the command under `/usr/bin/time -v` and `timeout 14m`, logs
`$S/logs/NAME.STEP.{log,time,exit}`; each log's first line records `ltrpav.__file__` = snap/6282541/src/ltrpav/
__init__.py, all 33 checked; every stats marker holds analysis code b30e7089..., snapshot 2's). One thread per
command, at most 5 at once (load average 74-177 at the steps' starts).

Step 1, route and flank cap (rulings R1):
```bash
cd $S
for v in mm2 cap5k; do bash run_step.sh $v view $v/geno $v/views/main $v/samples.tsv; done   # common/view.sh
timeout 15m bash run_step.sh mm2 stats mm2/views/main --trio B73,TIL01,TIL18     # 0:28; cap5k likewise
timeout 15m bash run_step.sh mm2 paint mm2/views/main --trio B73,TIL01,TIL18     # 0:22; cap5k likewise
timeout 15m bash run_step.sh mm2 compare mm2/views/main mm2                      # 1:20; cap5k: cap5k/views/main cap5k (1:19)
```
compare_papers.py = `real/common/compare_papers.py`, sha256 1e04f43e...334a (Task 13's copy, unedited; mtime 15:56:51;
Task 16A is working in `compare_papers.next.py` beside it). mm2: 102 rows (PASS 19, MISS 5, reported 76, skipped 2);
cap5k: 105 rows (19, 5, 79, 2).

Genome-set control, added (see concern 3): the variants genotyped 4 genomes, the baseline view 7. `make_default4.sh`
links the default route's own 9 pair files (and done markers) from `six/geno/pairs` into `default4/run/pairs/` and
copies the stability sheet; then the merge (snapshot 2's engine source equals snap/12d3e6c's, `diff -rq` shows only
analysis/ and sim/ differ; the merge's pair-file check passed on code 52071c27 and the element digests):
```bash
bash make_default4.sh
timeout 15m bash run_step.sh default4 merge default4/run default4/samples.tsv     # 1:57, 322,538 loci
bash run_step.sh default4 view default4/run default4/views/main default4/samples.tsv
timeout 15m bash run_step.sh default4 stats default4/views/main --trio B73,TIL01,TIL18   # 0:35
timeout 15m bash run_step.sh default4 paint default4/views/main --trio B73,TIL01,TIL18   # 0:25
timeout 15m bash run_step.sh default4 compare default4/views/main default4              # 1:30
```

Step 2, block lengths (ruling R2). `copy_view.sh SRC DEST` does `cp -a` (links stay links; no large input copied),
unlinks the 5 relative links, which break at the new depth (view.sh's links are relative: `../../geno/...`), and
remakes them with view.sh over the RUN and SHEET in SRC's `.view` marker (`six/geno`, `six/samples.tsv`; the marker is
reused), then checks samples.tsv equal to SRC's and every link resolving to SRC's target. The copied compare_papers
outputs (`six_main_papers.tsv`, `six_main_tables/`, `ltrmix_crosscheck.tsv`) were removed from `block/b*` (my copies) so
no stale 5-Mb table sits beside the new stats. Neither source holds identity.tsv, so `--block-size` without
`--identity` deleted nothing.
```bash
for b in 1 2 5 10 20; do bash copy_view.sh ../six/views/main block/b$b; bash copy_view.sh ../six/views/all block/all_b$b; done
for b in 1 2 5 10 20; do rm -r block/b$b/six_main_tables; rm block/b$b/six_main_papers.tsv block/b$b/ltrmix_crosscheck.tsv; done
for b in 1 2 5 10 20; do timeout 15m bash run_step.sh b$b stats block/b$b --trio B73,TIL01,TIL18 --block-size ${b}000000 & done; wait   # 1:29-1:31
for b in 1 2 5 10 20; do timeout 15m bash run_step.sh all_b$b stats block/all_b$b --block-size ${b}000000 & done; wait                  # 1:37-1:46
```
Checks: `block/b5` reproduces `six/views/main/stats.tsv` exactly but for the stats part key and the block_bp note
("--block-size" for "rule"), and `block/all_b5` reproduces `six/views/all` likewise; findings.txt differ only in the
header path. In all 10 copies the paint part's rows and marker key equal the source's (the paint key holds no block
size). Each copy's stats marker records its block size. Direction rows are identical in `block/b<N>` and
`block/all_b<N>` at every length (they do not depend on `--trio`).

Step 3: `stability_table.py --real .. --perrun ../../sim/probes/task11/perrun.tsv --out stability` (stdlib only; reruns
byte-identically) writes `stability.tsv`, `stability.md`, `stability_pairs.tsv`, `stability_trios.tsv`; RESULTS.md
carries `stability.md` verbatim (diffed). Null counts read `dpav_all_z` of `null_s<N>` (30, max |Z| 1.97) and
`bn_null_s<N>` (30, max |Z| 3.14); k = runs with |Z| >= |Z_obs|, p = (k + 1)/31.

## 2. The table (`$S/stability.md`; bold = verdict or reading differs from the baseline)

"same": the baseline's value (block length moves only SE and Z; painting untouched). "n/a": a row a 4-genome run cannot
have. "(a, b)": default and bottleneck null runs reaching |Z|.

| quantity | default route, 7 genomes (baseline) | default route, 4 genomes (control) | whole-genome anchors (--anchor mm2) | 5-kb flank cap | block 1 Mb | block 2 Mb | block 5 Mb (rule) | block 10 Mb | block 20 Mb |
|---|---|---|---|---|---|---|---|---|---|
| D_pav(B73,TIL01;TIL18) ± SE | +0.290 ± 0.039 | +0.291 ± 0.039 | +0.286 ± 0.042 | +0.295 ± 0.039 | +0.290 ± 0.035 | +0.290 ± 0.037 | +0.290 ± 0.039 | +0.290 ± 0.044 | +0.290 ± 0.048 |
| D_pav Z; bar D > 0 and Z > 3 (null runs reaching it: default, bottleneck) | 7.39 PASS (0, 0) | 7.42 PASS (0, 0) | 6.89 PASS (0, 0) | 7.49 PASS (0, 0) | 8.39 PASS (0, 0) | 7.87 PASS (0, 0) | 7.39 PASS (0, 0) | 6.63 PASS (0, 0) | 6.04 PASS (0, 0) |
| informative loci of D_pav: B73+TIL18 / TIL01+TIL18, of the loci counted | 1,313 / 723 of 14,011 | 1,317 / 724 of 14,067 | 1,140 / 633 of 12,216 | 1,322 / 720 of 13,996 | same | same | same | same | same |
| age gradient dD = D(K=0) - D(K>=0.01) ± SE | +0.398 ± 0.127 | +0.397 ± 0.127 | +0.397 ± 0.140 | +0.412 ± 0.129 | +0.398 ± 0.128 | +0.398 ± 0.128 | +0.398 ± 0.127 | +0.398 ± 0.128 | +0.398 ± 0.129 |
| dD Z; the tool's reading (significant at \|Z\| >= 3) | 3.14 significant | 3.13 significant | **2.83 not significant** | 3.20 significant | 3.11 significant | 3.12 significant | 3.14 significant | 3.10 significant | 3.09 significant |
| resolved fraction of D_pav's candidates (TIL18's calls): B73 / TIL01 | 0.728 / 0.710 | 0.728 / 0.710 | 0.709 / 0.686 | 0.733 / 0.716 | same | same | same | same | same |
| resolved fraction of B73's painted loci (B73's calls): TIL01 / TIL18 | 0.521 / 0.462 | 0.521 / 0.462 | 0.514 / 0.455 | 0.521 / 0.462 | same | same | same | same | same |
| genotype calls resolved (P, S, T or E) per directed pair: median (range) of the 9 | 0.460 (0.255-0.522) | 0.460 (0.255-0.522) | 0.444 (0.239-0.515) | 0.460 (0.251-0.522) | same | same | same | same | same |
| accuracy proxies (DESIGN 10.1, bar 0.95): reciprocity, lowest of 3 genome pairs; agreement with the target's own annotation, lowest of 6 pairs | 0.985; 0.968 (both >= 0.95) | 0.985; 0.968 (both >= 0.95) | 0.988; 0.964 (both >= 0.95) | 0.986; 0.975 (both >= 0.95) | same | same | same | same | same |
| painted informative loci, of all B73 loci; median (mean) spacing | 7,484 of 126,101; 85.1 kb (284.3 kb) | 7,515 of 126,853; 84.4 kb (283.1 kb) | 7,070 of 126,975; 89.1 kb (300.8 kb) | 7,509 of 126,828; 85.1 kb (283.8 kb) | same | same | same | same | same |
| window r with ELAI, posterior: 1 Mb / 10 Mb; bars (circular-shift p < 0.01) | 0.274 / 0.378; PASS, PASS | 0.274 / 0.380; PASS, PASS | 0.266 / 0.386; PASS, PASS | 0.277 / 0.391; PASS, PASS | same | same | same | same | same |
| window r with ELAI, class share: 1 Mb / 10 Mb; bars (circular-shift p < 0.01) | 0.258 / 0.372; PASS, PASS | 0.258 / 0.374; PASS, PASS | 0.256 / 0.384; PASS, PASS | 0.260 / 0.375; PASS, PASS | same | same | same | same | same |
| compare_papers' DESIGN 10.3 bars: PASS / MISS (the block length reaches only the D_pav bar) | 19 / 5 | 19 / 5; 0 of 99 shared rows changed | 19 / 5; 0 of 92 shared rows changed | 19 / 5; 0 of 93 shared rows changed | same | same | same | same | same |
| positive control D_pav(PT,B73;TIL18): Z; bar D > 0 and Z > 3 | 3.16 PASS (0, 0) | n/a | n/a | n/a | 3.78 PASS (0, 0) | 3.50 PASS (0, 0) | 3.16 PASS (0, 0) | **2.92 MISS (0, 1)** | **2.76 MISS (0, 2)** |
| negative control D_pav(TIL11,TIL01;TIL18): Z; bar \|Z\| < 3 | 3.20 MISS (0, 0) | n/a | n/a | n/a | 3.80 MISS (0, 0) | 3.54 MISS (0, 0) | 3.20 MISS (0, 0) | **2.80 PASS (0, 2)** | **2.79 PASS (0, 2)** |
| TIL25 as donor D_pav(B73,TIL01;TIL25): Z; Z > 3? (reported, no bar) | 2.79 no (0, 2) | n/a | n/a | n/a | **3.28 yes (0, 0)** | 2.99 no (0, 1) | 2.79 no (0, 2) | 2.80 no (0, 2) | 2.79 no (0, 2) |
| direction: DFOIL-alt (B73,PT;TIL25,TIL18) code, signature; largest \|Z\| | 0000 none; largest \|Z\| 1.90 | n/a | n/a | n/a | 0000 none; largest \|Z\| 2.10 | 0000 none; largest \|Z\| 1.98 | 0000 none; largest \|Z\| 1.90 | 0000 none; largest \|Z\| 1.78 | 0000 none; largest \|Z\| 1.57 |
| direction: D_dir(maize>mexicana) (Z), not read as direction | +0.064 (Z 0.90) | n/a | n/a | n/a | +0.064 (Z 1.03) | +0.064 (Z 0.95) | +0.064 (Z 0.90) | +0.064 (Z 0.92) | +0.064 (Z 0.87) |
| view all: trios whose D_pav has \|Z\| >= 3 | 9 of 20 | n/a | n/a | n/a | 11 of 20 | 10 of 20 | 9 of 20 | 7 of 20 | 6 of 20 |
| view all: D_pav's SE relative to the 5-Mb rule's, median (range) over the trios | 1.00 (1.00-1.00) | n/a | n/a | n/a | 0.85 (0.76-0.92) | 0.92 (0.84-0.96) | 1.00 (1.00-1.00) | 1.08 (1.00-1.14) | 1.15 (0.99-1.36) |
| genotyping the 9 directed pairs: sum of per-pair wall times (h:mm:ss); median (range) per pair, min | 2:54:24; 19.3 (11.8-31.8) | the baseline's pair files | 3:43:18; 24.7 (6.4-45.9) | 3:17:16; 20.9 (13.3-33.6) | - | - | - | - | - |
| step wall time (GNU time): genotype; merge | 4:03:44 (run 4: 14 of 36 pairs; runs 1-3 untimed); 0:02:50 | none; 0:01:57 | 3:43:57; 0:01:09 | 3:17:47; 0:01:02 | - | - | - | - | - |
| genotype step CPU time: user; kernel (system) share; all CPU (user + kernel) | 123,470 s; 64%; 346,692 s (run 4: 14 of 36 pairs) | none | 243,471 s; 25%; 322,727 s | 112,071 s; 47%; 209,873 s | - | - | - | - | - |
| genotyping peak memory: largest process (GNU max RSS); whole tree (sampled PSS); whole tree during the 9 pairs | 12.3 GB (run 4 only); 21.3 GB; 21.3 GB | merge only: 1.3 GB | 26.2 GB; 25.1 GB; 25.1 GB | 17.2 GB; 21.9 GB; 21.9 GB | - | - | - | - | - |

## 3. Every change of verdict or reading, with the variant that caused it

1. **`--anchor mm2`: the age-gradient reading flips** from "significant at |Z| >= 3 ... concentrated in young
   insertions, consistent with gene flow" to "not significant, |Z| < 3 ... no clear age profile" (findings.txt line
   30): dD +0.397 ± 0.140, Z 2.83, against +0.397 ± 0.127, Z 3.13 (default route, same 4 genomes) and 3.14 (baseline).
   Same estimate; SE +11% because mm2 resolves fewer calls (K = 0 informative loci 34 against 40; D_pav informative
   1,773 against 2,041). DESIGN 10.3 reports this row without a bar, and dD has no demonstrated null (SIM_RESULTS 1).
2. **Block 10 and 20 Mb: positive control D_pav(PT,B73;TIL18) PASS -> MISS** (Z 2.92, 2.76 against 3.16 at the rule's
   5 Mb). Bottleneck nulls reaching it: 1 and 2 of 30 (p 0.065, 0.097), so the bottleneck reading agrees.
3. **Block 10 and 20 Mb: negative control D_pav(TIL11,TIL01;TIL18) MISS -> PASS** (Z 2.80, 2.79 against 3.20); 2 of 30
   bottleneck nulls reach each (p 0.097).
4. **Block 1 Mb: TIL25 as donor D_pav(B73,TIL01;TIL25) crosses Z 3** (3.28; 2.79-2.99 at 2-20 Mb); reported, no bar.

Unchanged: compare_papers' 24 DESIGN 10.3 bars (19 PASS, 5 MISS) under default4, mm2 and cap5k (0 of 99, 92 and 93
shared rows change verdict); the main D_pav bar at every block length (Z 6.04-8.39, beyond all 60 nulls); dD
significant at every block length (Z 3.09-3.14); DFOIL-alt 0000 (no direction) for all three quartets at every block
length; window bars PASS under every route; accuracy proxies >= 0.95 everywhere. The genome set (default4 against the
baseline) changes no verdict or reading (D_pav Z 7.42 against 7.39; dD Z 3.13 against 3.14; estimates within 0.0012),
though counts move (counted loci 14,067 against 14,011; Inv4m's B73~TIL18 block 464 loci against 700, coverage 0.997
against 1.000), so the variants' changes of verdict or reading are the route's and the cap's.

What the route does (supporting rows): mm2 resolves fewer calls in 9 of 9 directed pairs (qc.tsv resolved_frac lower by
0.006-0.019; median 0.444 against 0.460), with fewer E and more U calls; the outgroup rule removes 82.6% of TIL18's
candidates against 80.9% (Zd neither present nor empty at 92,211 against 89,592), and B73/TIL01 resolve at 0.709/0.686
against 0.728/0.710; so D_pav counts 12,216 loci against 14,067 (-13%). The 5-kb cap stays within 0.004 of the default
in every pair. Reported aside (no bar): the 5-kb cap splits the B73~TIL18 Inv4m block in two at 179.42 Mb (197 + 251
loci, together covering 0.997); mm2 and default4 give one block (0.997).

## 4. Wall times and peak memory, with the load caveat

Per-block (GNU time; the queue's step files) and tree PSS (`*.mem.tsv`), as in the table. Per directed pair, minutes
for default / mm2 / cap5k, from each pair's own log line (`stability_pairs.tsv`; * reused the reverse direction's
whole-genome alignment): B73 vs TIL18 31.8 / 31.1 / 33.6; B73 vs TIL01 19.3 / 24.3 / 14.8; B73 vs Zd 21.0 / 24.7 /
13.3; TIL18 vs B73 12.0 / 9.1* / 14.2; TIL18 vs TIL01 23.4 / 45.9 / 29.7; TIL18 vs Zd 16.5 / 36.0 / 23.4; TIL01 vs B73
14.5 / 6.4* / 18.0; TIL01 vs TIL18 24.0 / 13.9* / 29.2; TIL01 vs Zd 11.8 / 32.1 / 20.9. Peak tree PSS per pair: default
11.2-21.3 GB, mm2 12.9-25.1 GB (24.9-25.1 GB in its three pairs into Zd), cap5k 13.7-21.9 GB.

Load (wall times are upper bounds; the routes did not run under the same load):
- default route, B73 pairs: six run 1, 2026-11-12 from 18:20, load average 175.85 at launch (`real/preflight.txt`);
- default route, TIL18/TIL01 pairs: six run 4 (w1), 2026-11-14 08:15-12:19, load 21-47 at launch (ledger), then this
  project ~160 threads plus the other project ~64-96 (combined ~225-255 at 12:20; the grid's genotyping slowed from
  ~1,100 to ~2,700 s per run; ledger);
- mm2 (w4, 13:40-17:25) and cap5k (w5, 13:40-16:59) side by side at 32 threads each (nice 10), with the rescore (~32)
  and the other project; load 77 at launch (ledger). The queue logs record no load; my step logs record
  /proc/loadavg at each analysis step (74-177), after the genotyping.
- CPU share of 32 threads: six run 4 2370%, mm2 2085% (first pair) and 2453%, cap5k 1768%; kernel time 25-64% of CPU
  time per block (mm2's two steps summed; its first pair alone 20%; 1.5-2.3e10 minor page faults), set by the load and
  by the route (mm2 25%, cap5k 47%, side by side). The fairest route comparison is mm2 against cap5k (same pairs, same
  hours): user CPU 2.17x (243,471 against 112,071 s), all CPU 1.54x (322,727 against 209,873 s), wall 1.13x; the
  bake-off's ~2x (0.39 against 0.19-0.22 h per pair) was a wall time. Most of mm2's extra wall time is in the three
  pairs into Zd (92.8 min against 49.2 default, 57.7 cap5k).
- The plan's estimates: mm2 ~4.5 h (measured 3:43:57 genotyping), the 5-kb cap ~2.5 h (3:17:47).
- Memory: mm2's largest process 26.2 GB, tree 25.1 GB; cap5k 17.2 / 21.9 GB; default route tree 21.3 GB (run 1, during
  B73 vs Zd), largest process 12.3 GB (run 4 only; runs 1-3 left empty GNU time files). All far below the 250-GB guard.
- This task's own steps: one thread each, at most 1:57 (the default4 merge) and 1.4 GB (block/all_b1 stats).

## 5. Tests

`$S/test_stability_table.py`, 6 tests on synthetic inputs (a toy real/ tree with stats tables, papers tables, genotype
logs, GNU time files, memory samples and qc.tsv): null counts and the non-null names ignored (`null_s101.100Mb`,
`bn_f0.18_*`); GNU time parsing (h:mm:ss and m:ss.ss, an empty file of a stopped run, user/system CPU); the log time
zone (2026-11-14 13:39:58 EST = epoch 1794681598, the queue's own fai snapshot name); per-pair parsing (an unfinished
pair, a "calls done, skip" line, the reuse line in sorted label order, the PSS window, a pair finished twice, a
missing pair); the full table with flagged cells (dD under mm2, both controls at 10 and 20 Mb, the accuracy flag) and
the markdown escaping; refusal of a copy with the wrong block length or a different D_pav; one-line errors.
`PYTHONDONTWRITEBYTECODE=1 python -m pytest -v -p no:cacheprovider -W error test_stability_table.py`: 6 passed
(`test_stability_table.out`). Mutation check of the final script in scratch copies: 12 of 12 mutants killed (null
count >= -> >, the original reuse bug below, time zone, max -> min PSS, flag comparison, the bar, the reading
threshold, the SE ratio, the D_pav equality check, the block-length check, the accuracy flag, the kernel share). Ruff (E, F, W, I, B, SIM, RUF, EXE; line
120) clean on both files; `bash -n` clean on the three shell scripts.

A bug of my own, found and fixed before the final outputs: mm2's reuse line names the pair in sorted label order
(`anchor._raw_blocks`), so during "TIL01 vs TIL18" it reads "TIL01 vs TIL18 (mm2): reusing ... raw blocks"; my first
parser looked only for the reverse name and missed that reuse. The test now covers it.

## 6. Files written

Under `$S` (`real/stability/`):
- `run_step.sh`, `copy_view.sh`, `make_default4.sh`; `logs/` (33 step logs with .time and .exit; `stability_table.log`).
- `mm2/views/main/`, `cap5k/views/main/` (view.sh links, samples.tsv, work/, stats.tsv, findings.txt, inversions.tsv,
  mechanisms.tsv, painting files, `<v>_papers.tsv`, `<v>_tables/`, `ltrmix_crosscheck.tsv`).
- `default4/samples.tsv`, `default4/run/` (pairs/ links; work/; the merge outputs; 139 MB), `default4/views/main/`.
- `block/b{1,2,5,10,20}/`, `block/all_b{1,2,5,10,20}/` (917 MB in all, mostly the copied paint files of view all).
- `stability_table.py`, `test_stability_table.py`, `test_stability_table.out`, `stability.tsv`, `stability.md`,
  `stability_pairs.tsv`, `stability_trios.tsv`, `RESULTS.md`, `fai.start.task15.tsv`, `fai.end.task15.tsv`.
- Appended: `$P/benchmark_pav/plan3/real/memo.md` ("## Task 15", 8,735 bytes; earlier lines untouched). No
  dead_ends.md entry (nothing failed; the changes are readings under variants, reported by design).
- Not written: any geno/, six/views/*, common/, papers/, snap/; compare_papers.py unedited.

## 7. fai check

`inputs/*.fai` (15 files: name, size, mtime, sha256) snapshotted at 17:32 before any step (`fai.start.task15.tsv`,
identical to Task 14's last snapshot `genus/fai.end.task14.fix1.tsv`) and at 18:08 after every step
(`fai.end.task15.tsv`): identical (`cmp`). Listings (path, size, mtime to the nanosecond, type) of `six/geno`
(18,695 entries), `stability/mm2/geno` (4,708), `stability/cap5k/geno` (4,701), `six/views/main` and `six/views/all`
taken before the first step and after the last: identical, so nothing was written through a link.

## 8. Concerns

1. **Two DESIGN 10.4 control verdicts depend on the jackknife block length** (changes 2-3). The two controls' Z track
   each other within 0.12 at every length, so no length passes both; at the rule's 5 Mb the positive passes and the
   negative misses, at 10-20 Mb the reverse. The SE rises from 5 to 10 Mb in 19 of 20 trios (median x1.08), so
   informative insertions are correlated beyond 5 Mb; the 10-to-20-Mb step (median x1.06, 17 of 20) is about a
   jackknife SE's own noise with 109-126 blocks, so a further rise is not settled. The simulated SE did not move with
   block length (SIM_RESULTS section 1), so real results near Z 3 are less secure than the null counts suggest. The
   rule is unchanged (varied, not tuned). Suggest Task 16 carries this beside Task 13's control verdicts and lists it as a Plan 4 lead (block length
   and the jackknife SE). The simulated nulls' Z used ~100 blocks of ~0.96 Mb, so the null quantiles at other lengths
   assume the null spread carries over.
2. **dD's reading depends on the route** (change 1): same estimate, Z 2.83 under mm2; dD rests on 34-40 young
   informative loci, so its Z sits near 3 under every choice tested (2.83-3.20).
3. **Added beyond the brief:** the default4 genome-set control (a re-merge of existing pair files: nothing genotyped,
   no geno/ written, 1:57 merge), per-pair QC rows from qc.tsv and view-all summary rows. They make the attribution to
   the route clean (the genome set changes no verdict or reading); drop them if unwanted.
4. **Direction from the all copies is redundant:** the main copies carry identical direction rows. The all copies
   were still needed for the six-genome controls' Z under each block length.
5. **compare_papers.py's known issues** (rulings R3) do not affect these views: the 4-genome views read rows "1 roles"
   (sisters B73 + TIL01, matching LTRmix) and "14 direction" (skipped: one genome per taxon) correctly; the baseline
   table's misread rows are not used; each view keeps its own unprefixed `ltrmix_crosscheck.tsv` (equal 58, different
   1, as Task 13's).

## Fix round 1 (2026-11-14; review task-15-review.md M1-M9; ruling "Ruling (Task 15 review)")

No verdict and no number of the table changed. `stability_table.py` reruns on the real outputs with every earlier
cell unchanged; two cells gained text: the CPU row adds all CPU (user + kernel) and the baseline's largest-process
memory reads "(run 4 only)" (`stability.tsv`, `stability.md`, rows 24-25; `stability_pairs.tsv` and
`stability_trios.tsv` byte-identical). The new copy checks pass on all 10 copies: every stats row keeps its source's
value, n and loci, and each main copy's qc.tsv and four painting files equal the baseline's bytes. S =
`real/stability`.

| item | change | file:line |
|---|---|---|
| M1 | cost metric: user CPU 2.17x, all CPU 1.54x (322,727 against 209,873 s), wall 1.13x; the bake-off's ~2x was a wall time | S/RESULTS.md:27-29, 194-201; report:142-147; memo.md:289 |
| M2 | SE steps with their noise: 5->10 Mb x1.08 in 19 of 20 trios; 10->20 Mb x1.06 in 17 of 20, about a jackknife SE's own sampling error with 109-126 blocks (roughly 6-7%); 1->5 Mb x1.18 in 20 of 20; SIM_RESULTS section 1 (simulated SE 0.061-0.063 at 0.25-5 Mb), so real results near Z 3 are less secure than the null counts suggest | S/RESULTS.md:153-166, 223-225, 249-252; report:196-202 |
| M3 | the untested causes in general terms: the rise is largest in TIL11,TIL01;PT (x1.36), with neither B73 nor a *mexicana* genome; candidates: long ancestry tracts in any genome, inversions, low-recombination regions, regional genotyping resolution | S/RESULTS.md:177-180 |
| M4 | `check_copy` (every row's value, n, loci; exempt: the stats part key, block_bp, DFOIL-alt's Z-derived signature) and `same_file` (qc.tsv, 4 painting files) replace the asserted "same"; `over_bar()` for TIL25; tests: thresholds at their edges, unequal max RSS and tree PSS across mm2's steps, skewed pair durations (median != mean), the informative-loci cell, the copy checks (value, n, loci, a missing row, a same-size painting edit, a missing qc.tsv, an all-copy row); the old test that locked in an unchecked main copy now expects the error | S/stability_table.py:80-83, 225-258, 335-337, 369-373, 469, 537, 543; S/test_stability_table.py:116-158, 220-227, 229-282, 283-338 |
| M5 | "changes no verdict or reading", with the counts that move: counted loci 14,067 against 14,011, painted informative 7,515 against 7,484, Inv4m's B73~TIL18 block 464 loci against 700 (coverage 0.997 against 1.000); estimates within 0.0012 (0.02 SE or less), Z within 0.035 | S/RESULTS.md:125-132; report:113-116, 209 |
| M6 | memo: this run used compare_papers.py sha256 1e04f43e..., now real/common/compare_papers.py.task13; the installed file is Task 16A's 47d2c20d..., with the command to reproduce; the listing commands; listings kept in S/logs/trees/ (before, after, after_fix1) | memo.md:240, 243, 254-256 |
| M7 | intervals 5-41 s (was 5-26); page faults 1.5-2.3e10 with mm2's two steps summed (was 1.3); kernel share 25-64% per block in the memo (was 20-64%; mm2's first pair alone 20%); "up to 0.12 of its SE" (was "at most a tenth"); mm2's D_pav difference 0.12 SE (was "about a tenth"); "(run 4 only)" on the baseline's 12.3 GB; the cap's "within the noise" replaced by its measures (D_pav and dD within 0.12 SE, resolved shares within 0.004) | S/RESULTS.md:121, 140, 148-151, 194, 213, 246; memo.md:298 |
| M8 | kernel time depends on load and on route (mm2 25%, cap5k 47%, side by side); "as much as the route" dropped | S/RESULTS.md:194-196; report:142-144 |
| M9 | terms: D_dir, user CPU, kernel time, minor page fault; "worker" -> "queue copy", "nice 10" -> "low priority (nice 10)" | S/RESULTS.md:77-86, 187-192 |
| cross-reference (ruling) | one sentence under items 1-2 of Task 13's file: at 10- and 20-Mb blocks the positive control falls to Z 2.92 and 2.76 and the negative control to Z 2.80 and 2.79, so both verdicts depend on block length (`real/stability/RESULTS.md`); nothing else in that file changed (diff: 2 added lines) | real/six/RESULTS.md:33-34 |
| Plan 4 leads | block-length dependence of near-threshold verdicts; the simulated nulls' missing long-range dependence; Task 13's negative-control age contrast (Z 3.18, 5-Mb rule) untested at other block lengths | S/RESULTS.md:231-240 |

Numbers changed in text only, each as M7 specifies: 5-26 -> 5-41 s, 1.3 -> 1.5 x 10^10, 20-64% -> 25-64% (memo),
"a tenth" -> 0.12 SE (twice). New numbers, each computed from the existing outputs: 1.54x and 322,727 / 209,873 s (GNU
time), the SE step ratios (block/all_b* stats.tsv), 109-126 blocks (their D_pav notes), 0.0012 and 0.035 (default4
against six/views/main stats.tsv).

Tests: `PYTHONDONTWRITEBYTECODE=1 python -m pytest -v -p no:cacheprovider -W error test_stability_table.py`: 8 passed
(S/test_stability_table.out). The review's 8 mutant changes (p3t15-review/mut_*), applied to the new script: 8 of 8
killed, the 7 survivors among them. My own set on the final script: 24 of 24 killed (the review's 7, the copy checks
skipped or narrowed, a size-only file check, the signature exemption, and the earlier 12). Ruff (E, F, W, I, B, SIM,
RUF, EXE; line 120) clean on both files.

Checks after the round: listings of six/geno, stability/mm2/geno, stability/cap5k/geno, six/views/main and
six/views/all equal the start's (S/logs/trees/tree.after_fix1.*); `inputs/*.fai` unchanged
(S/fai.end_fix1.task15.tsv = S/fai.start.task15.tsv); memo.md lines 1-235 unchanged (only the Task 15 entry edited).
No ltrpav step ran in this round.

Files changed: S/stability_table.py, S/test_stability_table.py, S/test_stability_table.out, S/stability.tsv,
S/stability.md, S/RESULTS.md, real/memo.md (Task 15 entry), real/six/RESULTS.md (2 lines), this report. Added:
S/logs/trees/ (15 listings), S/fai.end_fix1.task15.tsv.
