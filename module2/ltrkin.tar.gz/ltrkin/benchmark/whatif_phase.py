#!/usr/bin/env python3
"""What-if: re-call genotypes from a genotypes TSV (counts, rates, phase columns) under alternative phase models,
without re-reading BAMs, and score them against hap_truth.py truth (confirmed sites by default).

Models
  nophase        v0.1 likelihood (depth + class mix)
  pen:<err>      + one-directional phase term: h distinct F/S/E haplotypes need >= h copies (spurious rate err)
  abs:<err>      pen:<err> + absence term: at sites with >= MIN_F full reads, no heterozygous site seen means one
                 haplotype; P(no het site | >= 2 haplotypes present) = 1 - pi, pi estimated in the sample from
                 confident F/E calls (share with >= 2 phase sites)
usage: whatif_phase.py genotypes.tsv truth.tsv [--all] model [model ...]
"""
import argparse
import math
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, __file__.rsplit("/benchmark/", 1)[0] + "/src")
from ltrkin.model import genotypes, _nb_logpmf, MU_MIN  # noqa: E402

CL = "FSE"
MIN_F = 6


def base_ll(c, gt, rates, d_hap, eps, k):
    alle = gt.split("/")
    lam = {a: alle.count(a) * rates[a] for a in CL}
    tot = sum(lam.values())
    T = sum(c[a] for a in CL)
    ll = _nb_logpmf(T, max(d_hap * tot, MU_MIN), k)
    if T:
        for x in CL:
            if c[x]:
                p = sum((lam[a] / tot) * ((1 - eps) if x == a else eps / 2) for a in CL) if tot > 0 else 1 / 3
                ll += c[x] * math.log(p)
    return ll


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tsv")
    ap.add_argument("truth")
    ap.add_argument("models", nargs="+")
    ap.add_argument("--all", action="store_true", help="score every scored truth state, not only confirmed")
    ap.add_argument("--d-hap", type=float, required=True, help="per-haplotype depth from the ltrkin log")
    ap.add_argument("--k", type=float, required=True, help="NB size from the ltrkin log")
    ap.add_argument("--eps", type=float, default=0.0012)
    ap.add_argument("--calib", action="store_true", help="scale and NB size of full-read counts from confident F/E, F/S calls")
    ap.add_argument("--eb", action="store_true", help="empirical-Bayes genotype prior (EM over all sites of the TSV)")
    a = ap.parse_args()
    g = pd.read_csv(a.tsv, sep="\t").set_index("element_id")
    t = pd.read_csv(a.truth, sep="\t").set_index("element_id")
    tg = {"F": "F/F", "Fx": "F/F", "Fn": "F/F", "E": "F/E", "S": "F/S", "Nd": "F/N", "Nr": "F/N"}
    t = t[t.state.isin(list(tg))]
    if not a.all:
        t = t[t.truth_source == "confirmed"]
    d = g.join(t[["state"]], how="inner")
    d["truth"] = d.state.map(tg)
    gts = genotypes(2)
    conf_fe = g[(g.genotype == "F/E") & (g.gq >= 20)]
    pi = float((conf_fe.phase_sites >= 2).mean())
    print(f"sites {len(d)}; pi (confident F/E with >= 2 phase sites) = {pi:.3f} (n={len(conf_fe)})", file=sys.stderr)
    if a.calib:
        cs = g[g.genotype.isin(["F/E", "F/S"]) & (g.gq >= 20) & (g["flags"] == "PASS")]
        mu1 = a.d_hap * cs.r_F
        ratio = cs.n_F / mu1
        scale = float(np.median(ratio))
        mu = scale * mu1
        inv_k = float(np.mean(((cs.n_F - mu) ** 2 - mu) / mu ** 2))
        k_site = 1 / inv_k if inv_k > 1e-3 else 1000.0
        print(f"calibration from {len(cs)} F/E,F/S sites: scale {scale:.3f}, site NB size {k_site:.1f} "
              f"(depth-model k {a.k})", file=sys.stderr)
        a.d_hap *= scale
        a.k = k_site
    out = []
    for m in a.models:
        kind, _, err = m.partition(":")
        err = float(err) if err else 0
        # log-likelihoods for every site of the TSV (the prior is learned from all of them)
        LL = []
        for r in g.itertuples():
            c = {"F": r.n_F, "S": r.n_S, "E": r.n_E}
            rates = {"F": r.r_F, "S": r.r_S, "E": r.r_E}
            row = []
            for gt in gts:
                ll = base_ll(c, gt, rates, a.d_hap, a.eps, a.k)
                al = gt.split("/")
                if kind in ("pen", "abs"):
                    for x, h in (("F", r.hap_F), ("S", r.hap_S), ("E", r.hap_E)):
                        if h > al.count(x):
                            ll += (h - al.count(x)) * math.log(err)
                row.append(ll)
            LL.append(row)
        LL = pd.DataFrame(np.array(LL), index=g.index, columns=gts)
        logprior = np.zeros(len(gts))
        if a.eb:
            pi = np.full(len(gts), 1.0 / len(gts))
            for _ in range(20):
                P = np.exp(LL.values - LL.values.max(1, keepdims=True)) * pi
                P /= P.sum(1, keepdims=True)
                pi = (P.sum(0) + 1.0) / (P.sum() + len(gts))     # add-one smoothing
            logprior = np.log(pi)
            print(f"{m}: prior " + ", ".join(f"{gt} {p:.3f}" for gt, p in zip(gts, pi) if p > 0.01), file=sys.stderr)
        best_all = pd.Series(np.array(gts)[np.argmax(LL.values + logprior, 1)], index=g.index)
        d["call"] = best_all.reindex(d.index).values
        if True:
            ok = d.call == d.truth
            row = dict(model=m + (" +EB" if a.eb else ""), n=len(d), concordance=round(ok.mean(), 4))
            for x in ("F/F", "F/E", "F/S", "F/N"):
                sel = d.truth == x
                row[f"rec_{x}"] = round(ok[sel].mean(), 4) if sel.any() else np.nan
            out.append(row)
            continue
        calls = []
        for r in d.itertuples():
            c = {"F": r.n_F, "S": r.n_S, "E": r.n_E}
            rates = {"F": r.r_F, "S": r.r_S, "E": r.r_E}
            best, bl = None, -1e300
            for gt in gts:
                ll = base_ll(c, gt, rates, a.d_hap, a.eps, a.k)
                al = gt.split("/")
                if kind in ("pen", "abs"):
                    for x, h in (("F", r.hap_F), ("S", r.hap_S), ("E", r.hap_E)):
                        if h > al.count(x):
                            ll += (h - al.count(x)) * math.log(err)
                if kind == "abs" and r.n_F >= MIN_F and r.n_E == 0 and r.n_S == 0 and r.phase_sites < 2:
                    if al.count("F") >= 2:
                        ll += math.log(max(1e-3, 1 - pi))
                if ll > bl:
                    best, bl = gt, ll
            calls.append(best)
        d["call"] = calls
        ok = d.call == d.truth
        row = dict(model=m, n=len(d), concordance=round(ok.mean(), 4))
        for x in ("F/F", "F/E", "F/S", "F/N"):
            sel = d.truth == x
            row[f"rec_{x}"] = round(ok[sel].mean(), 4) if sel.any() else np.nan
        out.append(row)
    print(pd.DataFrame(out).to_string(index=False))


if __name__ == "__main__":
    main()
