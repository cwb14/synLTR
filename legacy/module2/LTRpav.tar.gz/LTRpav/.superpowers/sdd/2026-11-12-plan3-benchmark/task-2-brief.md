### Task 2: Events on the genealogy

**Files:**
- Create: `src/ltrpav/sim/popevents.py`, `tests/test_popevents.py`.
- Modify: `tests/poptoy.py`.
  - `toy_ts`: a hand-built tskit tree sequence from a nested-tuple topology with node times.
  - `toy_backbone`: random bases with planted SimElements.

**Interfaces:**
- Consumes:
  - `Rates` (Task 1);
  - `SimElement` (`sim/genome.py`, the backbone's elements, origin "backbone");
  - `Donor` (`sim/pair.py`);
  - `TSD_DEFAULT`, `SLOP_TSD_MULT` and `MIN_SEG` (engine constants, read only);
  - `pair.FLANK_DEL`, `PARTIAL` and `PARTIAL_MIN`.
- Produces:

```python
@dataclass(frozen=True)
class Ins:          # one LTR-RT insertion event
    iid: str        # "i<chrom:02d><n:06d>"
    host: str | None  # None: before backbone base `pos`; else the iid of the simulated insertion it landed in
    pos: int        # backbone position, or offset in the host's donor body
    node: int; time: float; donor: int; strand: str
    depth: int      # 0 primary, 1-2 nested in a simulated insertion
    carriers: frozenset[int]   # sample indices below the event, before any loss
@dataclass(frozen=True)
class Loss:         # one structural loss of an element on a lineage
    element: str    # iid or backbone eid
    node: int; time: float
    kind: str       # "solo" | "del_flank" | "del_partial" | "replace"
    a: int; b: int  # solo: crossover offset, 0; del_flank: bp beyond left end, beyond right end; del_partial: start
                    # offset in the internal region, length; replace: length of the replacing sequence, 0
    carriers: frozenset[int]
@dataclass
class ChromEvents:
    ins: list[Ins]; losses: list[Loss]
    snp_pos: np.ndarray; snp_base: np.ndarray        # (m,), (m, n_samples) uint8 base codes per sample
    indel_pos: np.ndarray; indel_len: np.ndarray; indel_ins: np.ndarray; indel_carriers: list[frozenset[int]]
    dropped: Counter                                  # ins_n, ins_end, snp_n, nested_after_loss
def draw_events(ts, backbone: bytes, elements: list[SimElement], donors: list[Donor], rates: Rates,
                rng: np.random.Generator) -> ChromEvents
```

- Rules, in this order. `W = SLOP_TSD_MULT * TSD_DEFAULT`. The backbone is upper-cased on load. A non-ACGT base (N or an
  IUPAC code) is never a SNP site, and never inside an insertion's 5 target bases.
  1. **Primary insertions.**
     - `sim_mutations(ts, rate=lam, model=BinaryMutationModel(), discrete_genome=False)`; `pos = floor(position)`.
     - An insertion within `W + TSD_DEFAULT` of a chromosome end is dropped (counted `ins_end`), as is one whose 5
       target bases hold a non-ACGT base (`ins_n`).
     - Donor uniform; strand + or - with probability 1/2.
     - Carriers: the samples below the mutation's node.
     - Positions inside backbone elements are nested in them by position, with host None.
  2. **Losses.** Backbone elements are read on the tree at their start; insertions on the tree at their position, and
     nested ones on their host's.
     - Along every branch below the element's origin (for a backbone element, every branch), draw a Poisson process at
       `delta`, with mechanism probabilities `loss_split`.
     - `solo`, `del_flank` and `replace` end the element on that lineage: no further event is drawn below them.
       `del_partial` does not end it, and needs `PARTIAL_MIN` of internal region.
     - Parameters follow Plan 1's pair simulator:
       - solo: crossover uniform in `1..min(LTR)-1`;
       - del_flank: 50-2,000 bp beyond the left end, the right end, or both (1/3 each);
       - del_partial: 20-60% of the internal region.
     - `replace` length: exponential with mean `replace_mean`, at least `MIN_SEG + 1`. The shape is a named heuristic;
       the mean is measured.
  3. **Nested insertions in simulated insertions,** depth at most 2. For each insertion X, after its losses are drawn:
     - Draw a Poisson count with mean `lam * len(X) * B_X`, where `B_X` is the branch length of X's subtree below its
       event, without the parts below a solo, del_flank or replace of X.
     - Each nested insertion takes a point uniform by length on that subtree and an offset uniform in X's donor body.
       Its carriers are the samples below the point.
     - Then draw the nested insertion's own losses. Depth 2 repeats once.
  4. **SNPs.**
     - `sim_mutations(ts, rate=mu, model=JC69(), discrete_genome=True)`.
     - At each site, relabel the alleles by the permutation of ACGT that sends msprime's ancestral state to the
       backbone base and keeps the order of the other three. JC69 is symmetric, so the law is unchanged.
     - Non-ACGT sites are dropped (`snp_n`). `snp_base` is each sample's base, from `ts.variants()`.
  5. **Small indels.**
     - `sim_mutations(ts, rate=indel, BinaryMutationModel(), discrete_genome=True)`.
     - Each event is an insertion of random bases or a deletion, with probability 1/2 each.
     - Lengths are geometric with mean 3 (`_INDEL_P` in `sim/genome.py`).
     - Carriers are the samples below.

  Inserted bodies take substitutions only (Task 3); small indels touch backbone sequence only.

  Two more rules:
  - **Separate mutation calls.** Each `sim_mutations` call takes the mutation-free tree sequence, never another call's
    output; msprime rejects JC69 and binary alleles on one site.
  - **`dropped["nested_after_loss"]`** counts the nested insertions whose offset falls in host sequence that an earlier
    del_partial of the host already removed on that lineage. They are discarded.

- [ ] **Step 1: Write the failing tests** (toy backbones of 200-500 kb, `toy_ts` for exact genealogies).

```python
def test_carriers_match_genotypes():   # primary insertions: carriers == samples with genotype 1 in the msprime ts
def test_no_insertion_target_on_n():   # 50-kb N block: no target overlaps it; dropped["ins_n"] > 0
def test_backbone_case_and_iupac():    # lowercase backbone -> same events as uppercase; an R/Y block: no SNP there, no
                                       # target across it
def test_snp_ancestral_is_backbone():  # every SNP site: a sample on no mutated lineage reads the backbone base
def test_loss_split():                 # delta=1e-4 toy, every element with >= PARTIAL_MIN internal region: drawn kinds
                                       # within 3 SE of loss_split
def test_loss_ends_lineage():          # no Loss below an earlier solo/del_flank/replace of the same element
def test_replace_length():             # all replace lengths >= MIN_SEG + 1; mean within 3 SE of replace_mean
def test_nested_carriers_and_offsets():  # nested.carriers <= host.carriers; never below an ending loss of the host;
                                          # 0 <= pos < len(donor body)
def test_insertion_count_poisson():    # toy_ts with total branch length T on 1 Mb: n primary in lam*L*T +- 3 sqrt
def test_seed_determinism():           # same rng seed -> identical ChromEvents
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement** `draw_events` as the rules state.
- [ ] **Step 4: Run.** Expected: PASS; then the suite.
- [ ] **Step 5: Commit:** `"Draw insertions, losses, SNPs and indels on simulated genealogies"`.

---

