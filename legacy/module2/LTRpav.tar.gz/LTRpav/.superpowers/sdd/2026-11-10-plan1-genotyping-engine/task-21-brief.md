### Task 21: Command-line interface and QC metrics

**Files:** Create `src/ltrpav/cli.py`, `tests/test_cli.py`; Modify `src/ltrpav/loci.py` (QC metrics below)

**Interfaces:**
- Produces: `main()` (`ltrpav run ...`), `anchor_main()`, `genotype_main()`, `merge_main()`. Shared options:
  `--samples SHEET --outdir DIR [--threads N (default 8)] [--anchor ROUTE (default constants.DEFAULT_ROUTE)] [-v]`.
  Single-stage commands also take `[--pair A,B]`; run and merge take `[--vcf-ref LABEL (default: first sheet row)]`.
  Pairs genotyped = (annotated A, any other B). Outputs land in `--outdir`, cache in `--outdir/work`.
- QC metrics added to `build_loci`, all as QcRows:
  - **Per ordered pair:** `frac_<state>`, `resolved_frac` (P/S/T/E), `high_frac`, `annot_agree` (calls whose B
    coordinates overlap a B element not linked to an ancestor of the A element: fraction P/S/T), `e_in_annot`
    (E calls inside such an element / all E calls).
  - **Per annotated unordered pair:** `reciprocity` (links seen in both directions / links seen in either).
  - **Per genome:** `annot_sensitivity` (loci projected P/high here that have a member here), `gap_rate`, and
    `skipped_<reason>` counts from annotation loading (DESIGN 8: warn-and-skip counts are reported).

- [ ] **Step 1: Write the failing tests**

```python
def test_run_toy_three_genomes(tmp_path):   # A, B annotated + C genotype-only: every output file exists; manifest has
                                            # version, argv, sha256 of each input; qc.tsv has reciprocity for A~B
def test_run_shared_seqids(tmp_path):       # all three genomes use "chr1": loci and VCF correct (Review Focus 1)
def test_rerun_skips(tmp_path, caplog):     # second identical run logs "skip" for every stage, outputs unchanged
def test_help_is_short(capsys):             # `ltrpav --help` < 40 lines
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - Logging: `logging` at INFO, DEBUG with `-v`.
  - Fail fast: SampleSheetError, AnnotationError, a missing external binary for the chosen route.
  - Every `Fasta` is opened with `cache_dir=outdir/work/fai`, so FASTAs without an index (Zd) work in place.
  - Normalized elements go to `work/elements/<label>.tsv`; stages are checkpointed.
  - On a pair with `resolved_frac < 0.01`, log a warning ("no orthologous alignment between A and B?").
- [ ] **Step 4: Run.** Expected: PASS. Then run `pytest -q && ruff check .`; everything passes.
- [ ] **Step 5: Commit** `"Add CLI, QC metrics and end-to-end run"`.

---

