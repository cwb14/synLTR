import logging
from collections import Counter
from dataclasses import replace

import pytest

import ltrpav.annotation as ann
from ltrpav.annotation import AnnotationError, assign_nesting, infer_tsd, load_annotation
from ltrpav.annotation.gff3 import write_gff3
from ltrpav.elements import Element, make_eid
from ltrpav.seqio import Fasta


def _el(name, start, end, seqid="chr1", tsd=None, genome="G"):
    return Element(genome=genome, eid=make_eid(genome, seqid, start, end), name=name, seqid=seqid,
                   start=start, end=end, strand="+", ltr_left=(start, start + 9),
                   ltr_right=(end - 9, end), tsd=tsd, k=None, family=None, superfamily=None,
                   clade=None, confidence=None)


def _fasta(tmp_path, seqs):
    fa = tmp_path / "g.fa"
    fa.write_text("".join(f">{k}\n{v}\n" for k, v in seqs.items()))
    return Fasta(fa)


def test_nesting_and_levels():
    e1, e2, e3 = _el("e1", 100, 10000), _el("e2", 2000, 5000), _el("e3", 2500, 3000)
    out = {e.name: e for e in assign_nesting([e3, e1, e2])}
    assert out["e1"].parent is None
    assert out["e2"].parent == out["e1"].eid and out["e3"].parent == out["e2"].eid
    assert [out[n].level for n in ("e1", "e2", "e3")] == [0, 1, 2]


def test_nesting_partial_overlap():
    out = {e.name: e for e in assign_nesting([_el("e1", 100, 10000), _el("e4", 9000, 12000)])}
    assert out["e4"].parent is None and out["e4"].level == 0
    # e5 lies inside both e1 and e4; the topmost containing stack entry (e4) is its parent
    out = {e.name: e for e in assign_nesting(
        [_el("e1", 100, 10000), _el("e4", 9000, 12000), _el("e5", 9100, 9500)])}
    assert out["e5"].parent == out["e4"].eid and out["e5"].level == 1


def test_nesting_separate_seqids_and_siblings():
    out = {e.name: e for e in assign_nesting(
        [_el("a", 100, 1000), _el("b", 2000, 3000), _el("c", 100, 1000, seqid="chr2")])}
    assert all(e.parent is None and e.level == 0 for e in out.values())


def test_infer_tsd(tmp_path):
    fa = _fasta(tmp_path, {"chr1": "GG" + "ACGTA" + "TTTTTTTTTT" + "ACGTA" + "CC",
                           "chr2": "GGCATG" + "TTTTTTTTTT" + "AAAAAC"})
    assert infer_tsd(fa, _el("x", 8, 17)) == "ACGTA"
    assert infer_tsd(fa, _el("y", 7, 16, seqid="chr2")) is None


def test_infer_tsd_tries_5_then_4_then_6(tmp_path):
    fa = _fasta(tmp_path, {"chr1": "AAAAAA" + "TTTTTTTTTT" + "AAAAAA" + "G"})
    assert infer_tsd(fa, _el("x", 7, 16)) == "AAAAA"  # 5 and 6 both match; 5 wins
    fa = _fasta(tmp_path, {"chr1": "CTGACT" + "TTTTTTTTTT" + "CTGACT" + "G"})
    assert infer_tsd(fa, _el("x", 7, 16)) == "CTGACT"  # only 6 matches
    fa2 = _fasta(tmp_path, {"chr1": "AAAC" + "TTTTTTTTTT" + "AAACG"})
    assert infer_tsd(fa2, _el("x", 5, 14)) == "AAAC"  # L=5 runs off the start; L=4 matches


def test_infer_tsd_at_sequence_start(tmp_path):
    fa = _fasta(tmp_path, {"chr1": "A" + "TTTTTTTTTT" + "ACGTA"})
    assert infer_tsd(fa, _el("x", 2, 11)) is None
    fa = _fasta(tmp_path, {"chr1": "ACGTA" + "TTTTTTTTTT" + "ACG"})  # right flank too short
    assert infer_tsd(fa, _el("x", 6, 15)) is None


def test_infer_tsd_rejects_n(tmp_path):
    fa = _fasta(tmp_path, {"chr1": "NNNNN" + "TTTTTTTTTT" + "NNNNN"})
    assert infer_tsd(fa, _el("x", 6, 15)) is None


def _gff(tmp_path, elements, name="a.gff3"):
    p = tmp_path / name
    write_gff3(elements, p)
    return str(p)


def test_unknown_seqid_fails_fast(tmp_path):
    fa = _fasta(tmp_path, {"chr1": "A" * 100})
    spec = _gff(tmp_path, [_el("x", 10, 50, seqid="chrZ"), _el("y", 10, 50, seqid="chrY")])
    with pytest.raises(AnnotationError, match=r"chrZ.*2|2.*chrZ"):
        load_annotation(spec, "G", fa)


def test_end_beyond_sequence_fails(tmp_path):
    fa = _fasta(tmp_path, {"chr1": "A" * 100})
    spec = _gff(tmp_path, [_el("x", 10, 150)])
    with pytest.raises(AnnotationError, match=r"element x \(chr1:10-150\) ends beyond its sequence length 100"):
        load_annotation(spec, "G", fa)


def test_many_unknown_seqids_are_truncated(tmp_path):
    """The error names 5 unknown seqids and says there are more."""
    fa = _fasta(tmp_path, {"chr1": "A" * 100})
    spec = _gff(tmp_path, [_el(f"x{i}", 10, 50, seqid=f"chrU{i}") for i in range(7)])
    with pytest.raises(AnnotationError, match=r"7 annotation seqid\(s\) absent from the FASTA: chrU0, chrU1, "
                                              r"chrU2, chrU3, chrU4 \.\.\."):
        load_annotation(spec, "G", fa)


def test_nesting_past_a_buried_stale_entry():
    """An element that ended (e2) stays on the stack under a long-lived partial overlap (e3)
    until popped; a later element (e4) still finds its true container (e1), never the stale entry."""
    els = [_el("e1", 100, 10_000), _el("e2", 200, 300), _el("e3", 250, 9_000), _el("e4", 5_000, 5_100)]
    out = {e.name: e for e in assign_nesting(els)}
    assert out["e2"].parent == out["e1"].eid and out["e3"].parent == out["e1"].eid
    assert out["e4"].parent == out["e3"].eid and out["e4"].level == 2


def test_skip_counts_without_a_counter(tmp_path, caplog):
    """Skip reasons are logged even when the caller passes no counter."""
    fa = _fasta(tmp_path, {"chr1": "A" * 200})
    spec = _gff(tmp_path, [_el("x", 10, 50), replace(_el("x2", 10, 50), eid="G|dup")])
    with caplog.at_level(logging.WARNING):
        assert len(load_annotation(spec, "G", fa)) == 1
    assert "G: skipped 1 annotation records (duplicate=1)" in caplog.text


def test_duplicates_dropped(tmp_path, caplog):
    fa = _fasta(tmp_path, {"chr1": "A" * 200})
    spec = _gff(tmp_path, [_el("x", 10, 50), replace(_el("x2", 10, 50), eid="G|dup"), _el("z", 60, 90)])
    skipped = Counter()
    with caplog.at_level(logging.WARNING):
        out = load_annotation(spec, "G", fa, skipped)
    assert [(e.start, e.end) for e in out] == [(10, 50), (60, 90)]
    assert skipped["duplicate"] == 1
    assert any("G: skipped 1 annotation records (duplicate=1)" in r.getMessage() for r in caplog.records)


def test_sorted_in_fai_order_with_nesting(tmp_path):
    fa = _fasta(tmp_path, {"chr2": "A" * 300, "chr1": "A" * 300})
    spec = _gff(tmp_path, [_el("a", 20, 100, seqid="chr1"), _el("b", 20, 200, seqid="chr1"),
                           _el("c", 50, 60, seqid="chr2")])
    out = load_annotation(spec, "G", fa)
    assert [e.name for e in out] == ["c", "b", "a"]
    assert out[1].level == 0 and out[2].parent == out[1].eid and out[2].level == 1


def test_tsd_filled_only_when_missing(tmp_path):
    fa = _fasta(tmp_path, {"chr1": "GG" + "ACGTA" + "T" * 10 + "ACGTA" + "CC"})
    spec = _gff(tmp_path, [_el("x", 8, 17)])
    assert load_annotation(spec, "G", fa)[0].tsd == "ACGTA"
    spec = _gff(tmp_path, [_el("y", 8, 17, tsd="GGGGG")], "b.gff3")
    assert load_annotation(spec, "G", fa)[0].tsd == "GGGGG"


def test_dispatch_by_format(tmp_path, monkeypatch):
    fa = _fasta(tmp_path, {"chr1": "A" * 200})
    e = _el("x", 10, 50)
    gz = _gff(tmp_path, [e], "a.gff3.gz")
    assert len(load_annotation(gz, "G", fa)) == 1
    assert len(load_annotation(_gff(tmp_path, [e], "a.gff"), "G", fa)) == 1
    bed = tmp_path / "a.bed"
    bed.write_text("chr1\t9\t50\n")
    seen = {}

    def fake_bed(path, genome, fasta):
        seen["bed"] = str(path)
        return [e], Counter({"no_ltr_pair": 2})

    def fake_lq(prefix, genome):
        seen["lq"] = prefix
        return [e], Counter()

    monkeypatch.setattr(ann, "load_bed", fake_bed)
    monkeypatch.setattr(ann, "load_ltrquest", fake_lq)
    skipped = Counter()
    load_annotation(str(bed), "G", fa, skipped)
    assert seen["bed"] == str(bed) and skipped["no_ltr_pair"] == 2
    prefix = tmp_path / "run"
    (tmp_path / "run_depth1_clean_ltr.tsv").write_text("x\n")
    load_annotation(str(prefix), "G", fa)
    assert seen["lq"] == str(prefix)
    with pytest.raises(AnnotationError, match="cannot detect annotation format"):
        load_annotation(str(tmp_path / "nothing"), "G", fa)
    with pytest.raises(AnnotationError, match="missing.gff3"):
        load_annotation(str(tmp_path / "missing.gff3"), "G", fa)
    with pytest.raises(AnnotationError, match="missing.bed"):
        load_annotation(str(tmp_path / "missing.bed"), "G", fa)


def test_annotation_files(tmp_path):
    """The files a spec names, as load_annotation reads them (they key the CLI's elements checkpoint)."""
    gff = tmp_path / "a.gff3.gz"
    gff.write_bytes(b"")
    assert ann.annotation_files(str(gff)) == [gff]
    assert ann.annotation_files(str(tmp_path / "missing.bed")) == []
    for depth in (1, 0):
        (tmp_path / f"run_depth{depth}_clean_ltr.tsv").write_text("x\n")
    assert ann.annotation_files(str(tmp_path / "run")) == [tmp_path / "run_depth0_clean_ltr.tsv",
                                                           tmp_path / "run_depth1_clean_ltr.tsv"]
    assert ann.annotation_files(str(tmp_path / "nothing")) == []


def test_loader_errors_wrapped(tmp_path):
    fa = _fasta(tmp_path, {"chr1": "A" * 200})
    bed = tmp_path / "bad.bed"
    bed.write_text("chrQ\t1\t50\n")
    with pytest.raises(AnnotationError, match="chrQ") as ei:
        load_annotation(str(bed), "G", fa)
    assert isinstance(ei.value.__cause__, ValueError)


def test_no_usable_record_fails(tmp_path):
    """An annotation without one usable LTR-RT record (a wrong file, every record malformed or
    without its LTRs) fails with one line naming the genome, the file and the skip counts."""
    fa = _fasta(tmp_path, {"chr1": "A" * 200})
    gff = tmp_path / "genes.gff3"
    gff.write_text("##gff-version 3\nchr1\tX\tgene\t1\t100\t.\t+\t.\tID=g\n"
                   "chr1\tX\tLTR_retrotransposon\t1\t1OO\t.\t+\t.\tID=e\n")
    with pytest.raises(AnnotationError, match=r"G: annotation .*genes\.gff3 holds no usable LTR-RT record "
                                              r"\(malformed_coordinates=1\)"):
        load_annotation(str(gff), "G", fa)
    gff.write_text("##gff-version 3\n")
    with pytest.raises(AnnotationError, match="no LTR-RT record in it"):
        load_annotation(str(gff), "G", fa)


def test_unreadable_annotation_fails_with_one_line(tmp_path):
    """A truncated gzip GFF3 (EOFError) or a gzip GFF3 that is not gzip (BadGzipFile) is an AnnotationError naming
    the genome and the file, never a traceback."""
    fa = _fasta(tmp_path, {"chr1": "A" * 200})
    good = tmp_path / "a.gff3.gz"
    write_gff3([_el("x", 10, 50)], good)
    cut = tmp_path / "cut.gff3.gz"
    cut.write_bytes(good.read_bytes()[:-12])
    with pytest.raises(AnnotationError, match=r"G: cannot read annotation .*cut\.gff3\.gz: EOFError"):
        load_annotation(str(cut), "G", fa)
    fake = tmp_path / "fake.gff3.gz"
    fake.write_text("not gzip\n")
    with pytest.raises(AnnotationError, match=r"fake\.gff3\.gz: BadGzipFile"):
        load_annotation(str(fake), "G", fa)


def test_seqid_mismatch_error_names_genome_and_file(tmp_path):
    fa = _fasta(tmp_path, {"chr1": "A" * 100})
    spec = _gff(tmp_path, [_el("x", 10, 50, seqid="scaf1")])
    with pytest.raises(AnnotationError) as exc:
        load_annotation(spec, "B73", fa)
    want = f"B73: annotation {spec}: 1 annotation seqid(s) absent from the FASTA: scaf1"
    assert str(exc.value).startswith(want)
