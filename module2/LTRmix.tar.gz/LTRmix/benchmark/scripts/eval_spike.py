#!/usr/bin/env python3
"""Score the real-genome spike-in: TIL11 (parviglumis) library with TIL25 (mexicana) tracts at known positions,
analyzed with TIL01 (sister) and TIL18 (donor). Truth = spiked intervals (SPK_chrN, TIL11 coordinates).
Calls outside them are compared with the unspiked TIL11 painting (six-genome trio TIL18_TIL01_TIL11), since TIL11
may carry natural mexicana ancestry."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import os
import sys

import numpy as np
import pandas as pd

SP = sys.argv[1] if len(sys.argv) > 1 else "/data2/chris/maize_introgression/benchmark/spike"
SIX = sys.argv[2] if len(sys.argv) > 2 else "/data2/chris/maize_introgression/benchmark/results/six"


def merge(iv):
    out = []
    for s, e in sorted(iv):
        if out and s <= out[-1][1]:
            out[-1][1] = max(out[-1][1], e)
        else:
            out.append([s, e])
    return out


def ov(a, b):
    s = 0
    for x0, x1 in a:
        for y0, y1 in b:
            s += max(0, min(x1, y1) - max(x0, y0))
    return s


def main():
    truth = pd.read_csv(os.path.join(SP, "SPK.truth.bed"), sep="\t", header=None, names=["chrom", "s", "e"])
    T = {c: merge(list(zip(g.s, g.e))) for c, g in truth.groupby("chrom")}
    st = pd.read_csv(os.path.join(SP, "out", "stats.tsv"), sep="\t")
    f = open(os.path.join(SP, "out", "findings.txt")).read()
    print(f.split("\n")[0])
    for t, s in (("D_kmer", "all"), ("D_ins", "all"), ("D3_triples", "all"), ("D_self_outgroup", "LTR sites")):
        x = st[(st.test == t) & (st.stratum == s)].iloc[0]
        print(f"{t}: D {x.D:+.4f} Z {x.Z:.1f}")
    base = os.path.join(SIX, "TIL18_TIL01_TIL11")
    if os.path.exists(os.path.join(base, "stats.tsv")):
        b = pd.read_csv(os.path.join(base, "stats.tsv"), sep="\t")
        for t, s in (("D_kmer", "all"), ("D_ins", "all"), ("D_self_outgroup", "LTR sites")):
            x = b[(b.test == t) & (b.stratum == s)].iloc[0]
            print(f"  unspiked baseline {t}: D {x.D:+.4f} Z {x.Z:.1f}")
    rows = []
    for mode, fn in (("recent", "tracts.SPK.bed"), ("ancestry", "ancestry.SPK.bed")):
        p = os.path.join(SP, "out", fn)
        if not os.path.exists(p):
            print(f"{fn} missing (SPK not the recipient?)")
            continue
        bed = pd.read_csv(p, sep="\t")
        bed.columns = [c.lstrip("#") for c in bed.columns]
        for tag, sel in (("q<=0.05", bed.q <= 0.05), ("p<=0.01", bed.p_decoy <= 0.01), ("all", bed.q <= 1.01)):
            bb = bed[sel]
            C = {c: merge(list(zip(g.start0, g.end))) for c, g in bb.groupby("chrom")}
            tp = sum(ov(C.get(c, []), T.get(c, [])) for c in set(C) | set(T))
            cl = sum(e - s for v in C.values() for s, e in v)
            tt = sum(e - s for v in T.values() for s, e in v)
            r = dict(mode=mode, set=tag, n_called=sum(len(v) for v in C.values()), called_Mb=cl / 1e6,
                     bp_precision=tp / cl if cl else np.nan, bp_recall=tp / tt if tt else np.nan)
            for lo, hi, nm in ((0, 3e5, "<0.3Mb"), (3e5, 1e6, "0.3-1Mb"), (1e6, 3e6, "1-3Mb"), (3e6, 1e9, ">=3Mb")):
                tot = got = 0
                for c, v in T.items():
                    for s, e in v:
                        if lo <= e - s < hi:
                            tot += 1
                            got += ov([[s, e]], C.get(c, [])) >= 0.5 * (e - s)
                r[f"recall_{nm}"] = got / tot if tot else np.nan
                r[f"n_{nm}"] = tot
            rows.append(r)
    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(SP, "spike_eval.tsv"), sep="\t", index=False)
    with pd.option_context("display.width", 250):
        print(out.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
