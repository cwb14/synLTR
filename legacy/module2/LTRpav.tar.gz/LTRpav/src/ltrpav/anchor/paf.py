"""Route "paf:<dir>": raw blocks read from an external whole-genome PAF per genome pair."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

from ..blocks import read_paf
from ..checkpoint import CHECKSUM_CACHE, file_checksum
from ..constants import SPLIT_INDEL

if TYPE_CHECKING:
    from . import PairContext

log = logging.getLogger("ltrpav.anchor")


class PafRoute:
    """Reads <dir>/<A>__<B>.paf[.gz] (A = query, PAF column 1), else <dir>/<B>__<A>.paf[.gz] (swapped)."""

    name = "paf"
    whole_genome = False  # each PAF already holds the pair's raw blocks: no shared cache needed
    reads_elements = False

    def __init__(self, dirpath: Path):
        self.dirpath = Path(dirpath)

    def find(self, ctx: PairContext) -> tuple[Path, bool]:
        """The pair's PAF and whether its query is B (read swapped); .paf before .paf.gz, A__B before B__A."""
        a, b = ctx.a.label, ctx.b.label
        for query, target, swap in ((a, b, False), (b, a, True)):
            for ext in (".paf", ".paf.gz"):
                path = self.dirpath / f"{query}__{target}{ext}"
                if path.is_file():
                    return path, swap
        raise FileNotFoundError(f"no PAF for {a} vs {b}: neither {self.dirpath / f'{a}__{b}.paf[.gz]'} "
                                f"nor {self.dirpath / f'{b}__{a}.paf[.gz]'} exists")

    def params(self, ctx: PairContext) -> dict:
        path, _ = self.find(ctx)
        return {"paf": path.name, "sha256": file_checksum(path, ctx.workdir / CHECKSUM_CACHE),
                "split_indel": SPLIT_INDEL}

    def raw_blocks(self, ctx: PairContext) -> np.ndarray:
        path, swap = self.find(ctx)
        log.info("%s vs %s (paf): reading %s%s", ctx.a.label, ctx.b.label, path, " as B vs A" if swap else "")
        a_index = {name: i for i, name in enumerate(ctx.a_fa.lengths())}
        b_index = {name: i for i, name in enumerate(ctx.b_fa.lengths())}
        return read_paf(path, a_index, b_index, swap=swap, split_indel=SPLIT_INDEL)
