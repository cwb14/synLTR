# Task 10 report: stages, assembly and commands

Status: DONE_WITH_CONCERNS (concerns at the end; none blocks Task 11 or 12)
Branch plan2-analyses, base 28faca2. Commits:
- 5bf48e7 Print the absence bounds to 3 significant digits so a small fraction never shows as 0 (ruling 8, Task 8 N1)
- 12465a8 Add analysis stages, report assembly, ltrpav-stats and ltrpav-paint

Tests: `python -m pytest -W error -m "not slow"`: 1080 passed, 2 deselected (156 s); `ruff check .` clean.
tests/test_cli_analysis.py: 38 tests (the brief's 10, AST-equal except ruff-only edits: `l` -> `ln`, the
`norm` lambda -> def, `check=False` on subprocess.run; plus 28 below). Every pre-existing test passes unchanged
(test_cli's `ltrpav run` tests now also run the analyses).

## What was built

- `src/ltrpav/analysis/report.py`
  - `STAGES = ("stats", "paint")`; `ENGINE_MODULES` (13 names: anchor, blocks, chain, checkpoint, classify,
    constants, elements, genotype, junction, localign, samples, seqio, window).
  - `analysis_fingerprint(stage)` = `package_fingerprint("ltrpav.analysis", *ENGINE_MODULES)`, plus
    `"ltrpav.plot"` for stage "plot" (Task 11 hook); ValueError for any other stage.
  - `stage_inputs(cat, stage, identity)`: "samples" (cat.sheet_sha), "loci.tsv", "qc.tsv" ("absent" without
    one), every "work/elements/<A>.tsv" and "pairs/<A>__<B>.calls.tsv.gz" (file_checksum, cache
    work/checksums.json), "fai:<label>" (sha256 of the names and lengths in fai order), "fasta:<label>" for
    stats with --identity, "identity.tsv" for paint when present.
  - `stage_params`: {"trio": null or [R,S,D], "identity": bool}; stats with --identity adds "backend" and
    "backend_version" (`localign.backend_version(DEFAULT_BACKEND)`, ruling 2). Paint's "identity" is whether
    identity.tsv exists (paint has no --identity flag).
  - `run_stage(cat, stage, trio, identity, threads)`: key = stage_key(stage, inputs, params,
    fingerprint=analysis_fingerprint(stage)); is_done -> "<stage>: done, skip" (logger ltrpav.analysis);
    else clear_done, run, mark_done(listing exactly the files written, meta trio/identity/identity_tsv).
  - `run_stats` in the brief's order (run_summary, relations; trios, trio_tests; inverted_blocks,
    write_inversions, inversion_rows; direction; mechanisms, write_mechanisms; identity per trio +
    write_identity, or delete a stale identity.tsv + one "Dating" line naming --identity), then the part.
  - `run_paint`: trios (dist from `pav_distances`), inverted_blocks, `read_self_counts(identity.tsv)` when
    present, paint per trio, write_paintings, paint_rows, then the part.
  - `write_part`: work/analysis/<stage>.rows.tsv (write_stats) and <stage>.findings.tsv ("section\tline").
  - `assemble(outdir)`: stats.tsv = STATS_COLUMNS header + parts' rows (bytes) in STAGES order;
    findings.txt (UTF-8) = "ltrpav <version> findings for the run in <abs outdir>", sections in SECTIONS
    order under their names ("- " per line), closing "Warnings" ("- <section>: WARNING: ..." or "- none").
    Both atomic.
- `src/ltrpav/analysis/cli.py`: `stats_main`, `paint_main`, `run_analyses`, plus `check_trio`, `trio_arg`,
  `add_options`, `MissingDependency(CliError)`. Parsers from `ltrpav.cli._options`, run by `_execute`.
  scipy/matplotlib imported only in the stage function (`_modules`); ImportError -> MissingDependency with the
  brief's exact message. Fail fast: sheet -> --trio (labels, distinct, no outgroup) -> manifest.json (the
  brief's exact message) -> scipy/matplotlib -> lastz on PATH with --identity -> catalog.
- `src/ltrpav/cli.py` (the one engine edit): `ltrpav run` gets `--trio`/`--identity` (via
  `analysis.cli.add_options`, imported inside `main()`); `_run` imports `ltrpav.analysis.cli` and checks
  --trio right after reading the sheet (before any genotyping), and calls `run_analyses(...)` after `_merge`.
  MissingDependency propagates (one error line, exit 1, outputs kept); any other exception is one WARNING
  (traceback with -v), exit 0 (ruling 4, decision 7). Docstring, run description and epilog updated.
- pyproject: `ltrpav-stats`, `ltrpav-paint`; `pip install -e . --no-deps` done in env ltrpav.
- docs/DESIGN.md: section 8 checkpointing item (resume after an older engine recomputes changed stages,
  genotyping included; analysis commands read runs as data, own fingerprint, never check engine
  fingerprints); build decision 12 rewritten for the closure; new build decision 13 (hook behavior, assembly
  of finished stages, paint set aside when identity.tsv changes).
- catalog.py: docstring only (keys now cover ENGINE_MODULES, not READER_MODULES alone).

Engine keys: all 7 engine stage fingerprints of the working tree equal those of 28faca2 (computed from a
`git archive 28faca2` copy): this task invalidates no genotyping.

## Decisions (made under the rulings; please check)

1. Closure boundary (ruling 1). The static import closure of the analysis (and plot) packages' engine imports,
   less two files: ltrpav/__init__.py (the version, already a key field; package_fingerprint cannot name it
   alone) and ltrpav/cli.py. analysis/cli.py must import `_execute`, `_options`, `CliError` from ltrpav.cli,
   whose closure is the whole engine (annotation, loci, outputs...). Following it would make every engine edit
   rerun the analyses, against the plan's "an engine edit reruns an analysis only when those outputs change";
   no analysis output depends on the CLI (parsing, logging, exit status), and the engine leaves its own CLI out
   of every stage set. checkpoint.py is kept (READER_MODULES has it). Test
   `test_engine_modules_are_the_import_closure` walks the closure (test_checkpoint's rule, not following
   ltrpav.cli); `test_analysis_keys_follow_their_modules` (18 cases): analysis/plot edits change analysis keys
   and leave all 7 engine keys; genotype/localign/constants/classify/window/anchor/checkpoint/samples edits
   change analysis keys; cli.py, loci.py, outputs, annotation, sim, __init__ edits do not; plot/ only the plot key.
2. "FASTA indexes" input (ruling 3) is a digest of each genome's sequence names and lengths, the content the
   analyses read; the .fai's location (beside the FASTA or work/fai) and offsets do not matter.
3. Paint's "identity" param = identity.tsv present, so `ltrpav run --identity` followed by `ltrpav-paint` does
   not rerun paint needlessly; the file's checksum is an input anyway.
4. run_paint takes dist from `pav_distances` (the array relations returns) instead of calling relations and
   discarding everything: same values, no discarded work. Paint discards trios' rows and findings (the stats
   part has them); it adds one "Painting skipped: no trio" line when there is none.
5. The --trio check runs at the start of `_run` (fail fast: a typo is not found after hours of genotyping);
   run_analyses is still called after `_merge`. So the hook has two call sites in `_run`.
6. Beyond the brief, so assembled files never mix stale parts:
   - assemble takes only parts whose marker exists (a stage being rewritten or failed is left out); a failed
     stage reassembles before the error propagates;
   - a stats run that writes or deletes identity.tsv clears the paint marker when the painting read another
     identity.tsv (meta identity_tsv), until paint reruns;
   - parts made with different --trio options are joined with a WARNING in "Run".
7. Findings parts replace a newline inside a finding with a space; a section outside SECTIONS is a ValueError.
8. analysis/cli.py also imports `_backend` (lastz check for --identity) and `_positive` (--threads) from
   ltrpav.cli, not only the three names the brief lists.

## Tests beyond the brief (tests/test_cli_analysis.py)

markers list exactly the stage's files (A30-A32); stale identity.tsv deleted + paint set aside + paint reruns;
--identity end to end through the commands (LASTZ on a real-sequence toy: identity.tsv listed in the stats
marker, 12 self rows, identity rows in stats.tsv, paint reruns after identity.tsv appears, stats skip, a stats
rerun without --identity deletes it); the --identity key holds the LASTZ version and the FASTA checksums;
engine checks (`_check_pair_files`, `_pair_files`, `checkpoint.stage_fingerprint`) monkeypatched to fail and
never called; assemble unit test (order, sections, Warnings, trio mismatch, part without marker, relative
outdir named absolute, tab and newline in a finding); `ltrpav run --trio` fails fast with nothing written
(and "A,B" is exit 2); an analysis error in `ltrpav run` is one WARNING, exit 0, outputs kept; a failed stage
leaves stats.tsv without its part; closure and fingerprint tests (decision 1). Mutation checks: removing the
paint set-aside fails 2 tests; narrowing the hook's except fails the warning test; the N1 test fails on the old
".3f" format.

## N1 carry-over (5bf48e7)

mechanisms' absence findings line prints every fraction with 3 significant digits (`_g3`), so a nonzero term
never prints as 0: main3 B73>TIL18 now reads "frac_D_inside + frac_O_inside = 0.0126 + 0.000314 = 0.0129".
Three test strings updated; regression test `test_bounds_line_keeps_small_fractions`.

## Smoke test, chr10 (Step 5; ruling 7)

Scratch copy /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/chr10
(loci.tsv, qc.tsv, manifest.json, pairs/, work/elements/ of bakeoff/chr10/runs/flank-mm2_2k; sheet with absolute
paths; all three .fai present, FASTAs not copied). Nothing written under bakeoff/.
- ltrpav-stats: 2.5 s wall, 189 MB peak RSS; ltrpav-paint: 2.3 s, 215 MB.
- Roles from the data: sisters B73v5 + TIL01 (sharing 350 vs B73v5+TIL18 192, TIL18+TIL01 134), donor TIL18,
  recipient B73v5. D_pav(B73v5,TIL01;TIL18) = +0.224 +- 0.136, Z 1.64 (n_RD 164, n_SD 104; 2,767 loci; 100
  blocks of 1.45 Mb). One chromosome, no outgroup: a smoke test, not a result. The pair files' done markers
  (bake-off engine) are ignored, as intended.

## main3 end to end (ruling 9)

View /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/main3_view:
real work/ dir; symlinks to main3's loci.tsv, qc.tsv (the run's own, pre-I1), manifest.json, pairs/,
work/elements; copied samples.tsv. No --identity (Task 12 runs it detached). `timeout 15m` per command; the
stages are single-threaded.
- ltrpav-stats: 25.7 s wall (catalog 10.5 s, mechanisms 12.2 s), 641 MB peak RSS. ltrpav-paint: 21.5 s, 567 MB.
  Second runs: "stats: done, skip", "paint: done, skip" (about 12 s each: the catalog load).
- main3 untouched: sizes and mtimes of its 234 entries (depth 3) and inputs/*.fai identical before and after.
- stats.tsv: 2,982 rows, all 11 columns, read back by read_stats. Every value below equals the Task 3/4/6/8 probes.

Headline rows (stats.tsv):
- Tree (Zd:0.0826,((B73:0.209,TIL01:0.224):0.0300,TIL18:0.232):0.0826).
- Sharing (78,659 loci): B73+TIL01 5,392, B73+TIL18 3,097, TIL18+TIL01 1,828; sister pair B73+TIL01,
  p_top 1.6e-138. KKSC p_kksc 3.1e-85 (anti-conservative; resolved B73 0.443, TIL01 0.425).
- Roles: B73,TIL01;TIL18, source data (recipient B73).
- D_pav primary: +0.2905 +- 0.0392, Z 7.42 (n_RD 1,317, n_SD 724; 14,067 counted loci); resolution B73 0.728,
  TIL01 0.710; outgroup filter removed 0.809 of 123,019 candidates.
- Strata: K=0 +0.600 (Z 4.82; 32/8); 0<K<0.01 +0.612 (Z 11.78; 320/77); K>=0.01 +0.203 (Z 5.08; 965/639);
  high_tier +0.305 (Z 7.21); nested_collapsed +0.279 (Z 7.30); no_outgroup_filter +0.296 (Z 8.96).
- Gradient dD = +0.397 +- 0.127, Z 3.13 (421 blocks).
- Outgroup conflicts frac_E: B73 0.0268 (n 11,990), TIL18 0.0323 (11,385), TIL01 0.0314 (11,957).
- Inversions n_blocks: B73~TIL18 67, B73~TIL01 59, TIL18~TIL01 160, B73~Zd 69, TIL18~Zd 81, TIL01~Zd 87.
- Mechanisms B73>TIL18: 76,418 absences; upper bound 0.651, lower 0.0129.
- Direction skipped (one genome per taxon). findings.txt Warnings: one (branches_resolution: Zd resolved 0.25
  against 0.58-0.63).

Painting summary (B73; sister TIL01, donor TIL18): pi 0.359; L (mean_tract_bp) 301.7 kb; mean_donor_run_bp
470.7 kb; 7,515 informative (2,699 RD, 4,816 RS) of 126,853 loci; posterior mean 0.370 against decoy 0.317
(excess +0.053); 770 tracts, 599 decoy tracts, 0 at q <= 0.05; median informative spacing 84.4 kb; 14,527
loci inside inverted blocks; youngest K median 0.01665, 35 tracts with an identical-LTR RD insertion.
Files: tracts.B73.bed (770), posterior.B73.tsv, decoy_tracts.TIL01.bed (599), decoy_posterior.TIL01.tsv.

## Concerns

1. N3 by design: in an env without scipy/matplotlib (ltrpav_bench), `ltrpav run` now exits 1 after a complete
   genotyping run, and in the ltrpav env every `ltrpav run` also runs the analyses (about 45 s on main3
   without --identity). bakeoff/02_run_sims.py and 04_chr10.sh call `ltrpav run`; Plan 3's benchmark loops
   should run `ltrpav-genotype` + `ltrpav-merge`, or accept the analyses' time.
2. Ruling 4 makes an analysis error in `ltrpav run` a WARNING with exit 0: a pipeline that checks only the exit
   status will not notice. stats.tsv and findings.txt then hold the finished stages only.
3. The plan text (gitignored) still reads `package_fingerprint("ltrpav.analysis", *READER_MODULES)` in builder
   call 12 and Task 10's interface comment; DESIGN 12 now states the closure. Decision 1 (ltrpav/cli.py left
   out of the closure) departs from the literal ruling text; it is the one call here I would most want
   confirmed.
4. Painting's shortest callable tract on main3 is 1 locus (84.4 kb) for both bounds: a consequence of Task 6's
   known degenerate EM emissions on real data (the Plan 3 lead), not new here.

## Fix round 1 (review task-10-review.md: 2 Important, 3 Minor)

Commit 84c909e "Exit 3 when ltrpav run's analyses fail; assemble only parts whose key is current".

- I1 (exit 3 ruling): fixed. `ltrpav run`'s hook keeps MissingDependency at exit 1. Any other stats or paint
  failure logs one ERROR on logger ltrpav, naming the failure and how to rerun. It then raises
  `AnalysesFailed(RuntimeError)` from the exception. `_execute` catches that before `_HANDLED`, prints one line
  "error: analyses failed: <Type>: <message>" (a traceback only with -v) and returns 3. The genotyping
  outputs are kept. For a plot-stage error (Task 11), run_analyses' docstring states that the stage catches it
  and logs a WARNING, so the run exits 0.
  - Docs: the cli.py docstring (analyses text; exit status 3 added) and DESIGN decision 13 are updated.
  - Test: `test_analysis_error_in_run_is_a_warning` is replaced by `test_analysis_error_in_run_exits_3`,
    parametrized over run_stats and run_paint. It asserts exit 3, one ERROR record, exactly one `error:` line
    (the last), no traceback, the outputs kept, and stats.tsv holding only the finished stages.
- I2 (stale parts): fixed. Each marker's meta now records trio, identity, inputs, params and code.
  - `report.stale_parts(cat)` recomputes each marked stage's key from the options its marker recorded. It logs
    one WARNING per stale part, naming the stage and why: changed inputs by name ("the samples sheet",
    identity.tsv, ...), "the analysis code changed", "LASTZ's version differs (lastz is not on PATH...)", or
    "made by an earlier version".
  - `assemble(outdir, stale)` leaves those parts out and adds the same WARNING to findings.txt's Run section.
    Both `_analyses` paths use it: the normal one and the failure one.
  - `_set_paint_aside` is removed: paint's key already holds identity.tsv.
  - New tests: `test_sheet_change_leaves_the_stale_painting_out` (sheet changed, only ltrpav-stats rerun) and
    `test_code_change_leaves_the_stale_stats_out` (analysis code edited in a fingerprint copy, only
    ltrpav-paint rerun).
  - Updated tests: the identity.tsv test, which now leaves the painting out instead of clearing its marker, and
    the --identity end-to-end test, which adds the no-lastz stale case.
  - Mutation check: disabling the key comparison fails all four tests.
- M1: fixed (`IDENTITY_SECTION` from identity.py instead of SECTIONS[8]).
- M2: fixed. A findings-part row without a tab, or with an unknown section, is an AnalysisError naming the file
  and line, ending "rerun the <stage> stage". It is tested in test_assemble.
- M3: fixed. The docstrings of analysis/__init__.py and checkpoint.py (docstring only) now name
  ENGINE_MODULES.
- Review notes (a)-(c) were not counted and are not acted on. Note (b) is in Task 6's paint.py, outside this
  diff.

Checks:
- Engine keys: all 7 engine stage keys from a `git archive 28faca2` snapshot equal the working tree's (the
  checkpoint.py and cli.py edits are in no engine stage set).
- Suite: 1083 passed, 2 deselected (172 s); ruff clean. test_cli_analysis.py has 41 tests.
- main3 view, read-only:
  - ltrpav-stats reran on the code change and named the old paint part stale ("made by an earlier version;
    the analysis code changed"); ltrpav-paint reran; a second ltrpav-stats skipped, with nothing left out.
  - D_pav is unchanged (+0.290544 +- 0.0391529, Z 7.42).
  - main3 and inputs/*.fai are byte-for-byte unchanged against the first snapshot.
