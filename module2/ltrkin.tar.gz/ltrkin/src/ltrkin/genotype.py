"""ltrkin genotype: call full / solo / empty / null alleles of annotated LTR-RTs from long reads."""
import gzip
import hashlib
import math
import json
import os
import re
import sys
import time
from multiprocessing import Pool
from statistics import median

import pysam

from . import __version__
from .annot import read_gff3, infer_tsd
from .constants import (EPS_INIT, DEPTH_LOW, DEPTH_HIGH, FLAG_FRAC, FLAG_MIN, LOWQ_FRAC, RES_WIN, BOUND_MIN_SITES,
                        BOUND_K, PH_MAX_DIV_NOQUAL)
from .model import (ReadModel, sample_points, depth_and_spans, read_profile, call, estimate_eps, allele_posteriors,
                    pav_call, site_calibration, genotype_prior, genotypes, CLASSES)
from .reads import Site, evidence
from .phase import haplotypes

FLANK_POINTS = (6000, 3000)   # bp outside the element where local (flank) depth is measured
COUNT_KEYS = ["F", "F_span", "F_other", "F_left", "F_right", "S", "S_split", "E", "E_split", "P", "O", "U", "lowq"]
PHASE_KEYS = ["hap_F", "hap_S", "hap_E", "phase_sites"]
VCF_IDX = {"F": "0", "E": "1", "S": "2", "N": ".", ".": "."}

_W = {}


def log(msg, verbose=True):
    if verbose:
        print(f"[ltrkin {time.strftime('%H:%M:%S')}] {msg}", file=sys.stderr, flush=True)


def _init_worker(bam_path, fasta_path, min_mapq, ref_path, ploidy):
    _W["bam"] = pysam.AlignmentFile(bam_path, reference_filename=ref_path)
    _W["fa"] = pysam.FastaFile(fasta_path)
    _W["q"] = min_mapq
    _W["ploidy"] = ploidy


def _point_depth(bam, chrom, p, q):
    return sum(1 for x in bam.fetch(chrom, p, p + 1)
               if not (x.is_unmapped or x.is_secondary or x.is_supplementary or x.is_duplicate or x.is_qcfail)
               and x.mapping_quality >= q)


def _work(chunk):
    bam, fa, q = _W["bam"], _W["fa"], _W["q"]
    out = []
    for i, el, t in chunk:
        rd = []
        c = evidence(bam, fa, el, t, q, reads_out=rd)
        h, nsites = haplotypes(rd, fa, el.chrom, el.start, el.end, _W["ploidy"])
        c.update({f"hap_{a}": h[a] for a in CLASSES}, phase_sites=nsites)
        L = fa.get_reference_length(el.chrom)
        pts = [el.start - d for d in FLANK_POINTS] + [el.end + d for d in FLANK_POINTS]
        fd = [_point_depth(bam, el.chrom, p, q) for p in pts if 0 <= p < L]
        c["flank_depth"] = median(fd) if fd else -1
        out.append((i, c))
    return out


def _fingerprint(*paths, **kw):
    h = hashlib.sha1()
    for p in paths:
        st = os.stat(p)
        h.update(f"{os.path.abspath(p)}:{st.st_size}:{int(st.st_mtime)}".encode())
    h.update(json.dumps(kw, sort_keys=True).encode())
    return h.hexdigest()[:16]


def _stem(bam_path):
    base = os.path.basename(bam_path)
    for ext in (".bam", ".cram"):
        if base.endswith(ext):
            base = base[: -len(ext)]
    return base


def _sample_name(bam_path, bam):
    sm = {rg.get("SM") for rg in bam.header.to_dict().get("RG", []) if rg.get("SM")}
    if len(sm) == 1:
        return sm.pop()
    if len(sm) > 1:
        log(f"warning: {bam_path} has read groups of {len(sm)} samples {sorted(sm)[:3]}: genotyped as ONE sample "
            f"'{_stem(bam_path)}' (give one BAM per sample)")
    return _stem(bam_path)


def check_bams(bam_paths, ref, fa, chroms):
    """Fail before any work: every BAM indexed and aligned to this reference (same length for each element
    sequence it holds)."""
    for bp in bam_paths:
        with pysam.AlignmentFile(bp, reference_filename=ref) as bam:
            if not bam.has_index():
                sys.exit(f"ltrkin: {bp} has no index (samtools index it)")
            refs = set(bam.references)
            held = [c for c in chroms if c in refs]
            if not held:
                sys.exit(f"ltrkin: no element sequence is in {bp} (sequence names differ from the reference?)")
            diff = [c for c in held if bam.get_reference_length(c) != fa.get_reference_length(c)]
            if diff:
                c = diff[0]
                sys.exit(f"ltrkin: {bp} was aligned to another reference: {len(diff)} sequence(s) differ in length, "
                         f"e.g. {c} {bam.get_reference_length(c)} bp in the BAM, {fa.get_reference_length(c)} in "
                         f"the FASTA")
            if len(held) < len(chroms):
                log(f"warning: {bp} lacks {len(chroms) - len(held)} element sequence(s); their elements are not "
                    f"genotyped in this sample")


def sample_names(bam_paths, ref):
    """One unique name per BAM: read-group SM, else the file name; SM names shared by several BAMs (e.g. read sets
    of one plant) fall back to file names, with a warning."""
    names = []
    for bp in bam_paths:
        with pysam.AlignmentFile(bp, reference_filename=ref) as bam:
            names.append(_sample_name(bp, bam))
    dup = {n for n in names if names.count(n) > 1}
    if dup:
        log(f"warning: sample name(s) {sorted(dup)} shared by several BAMs; using file names for those")
        names = [_stem(bp) if n in dup else n for n, bp in zip(names, bam_paths)]
    if len(set(names)) < len(names):
        names = [f"{n}_{i + 1}" for i, n in enumerate(names)]
    return names


def collect_sample(bam_path, ref, els, tsds, threads, min_mapq, prefix, verbose, ploidy, name):
    """Evidence for every element in one sample (cached by input fingerprint) and its read model."""
    bam = pysam.AlignmentFile(bam_path, reference_filename=ref)
    if not bam.has_index():
        sys.exit(f"ltrkin: {bam_path} has no index (samtools index it)")
    bam_refs = set(bam.references)
    use = [i for i, el in enumerate(els) if el.chrom in bam_refs]
    if not use:
        sys.exit(f"ltrkin: no element chromosome is in {bam_path} (reference mismatch?)")
    here = os.path.dirname(__file__)
    code = hashlib.sha1(b"".join(open(os.path.join(here, f), "rb").read() for f in (
        "reads.py", "phase.py", "constants.py", "model.py", "genotype.py"))).hexdigest()[:12]
    # the evidence is indexed by element: key it to every element's geometry and TSD, not just their number
    geom = hashlib.sha1("".join(f"{e.id}\t{e.chrom}\t{e.start}\t{e.end}\t{e.lltr}\t{e.rltr}\t{t}\n"
                                for e, t in zip(els, tsds)).encode()).hexdigest()[:16]
    fp = _fingerprint(bam_path, ref, min_mapq=min_mapq, elements=geom, version=__version__, evidence_code=code,
                      ploidy=ploidy)
    cache = f"{prefix}.{name}.evidence.json.gz"
    if os.path.exists(cache):
        try:
            with gzip.open(cache, "rt") as fh:
                d = json.load(fh)
        except (OSError, EOFError, ValueError):
            d = {}
            log(f"warning: {cache} is unreadable (interrupted run?); rescanning")
        if d.get("fingerprint") == fp:
            log(f"{name}: evidence reused from {cache}", verbose)
            return name, {int(k): v for k, v in d["evidence"].items()}, d["depths"], d["spans"]
    chroms = {c: bam.get_reference_length(c) for c in sorted({els[i].chrom for i in use})}  # sorted: reproducible
    pts = sample_points(chroms)
    depths, spans = depth_and_spans(bam, pts, min_mapq)
    try:
        ReadModel(depths, spans, ploidy)              # fail before the evidence scan, not after it
    except ValueError as err:
        sys.exit(f"ltrkin: {name} ({bam_path}): {err}")
    qfrac, div = read_profile(bam, pts, min_mapq)
    phase_ploidy = ploidy
    if qfrac < 0.9 and not (div <= PH_MAX_DIV_NOQUAL):
        phase_ploidy = 1                          # haplotypes() is off for ploidy 1
        log(f"warning: {name}: reads lack base qualities and diverge {div:.3f} from the reference: read phasing "
            "off (sequencing errors would look like haplotype differences)")
    log(f"{name}: reads with base qualities {qfrac:.2f}, median divergence {div:.4f}", verbose)
    work = [(i, els[i], tsds[i]) for i in use]
    chunks = [work[j:j + 200] for j in range(0, len(work), 200)]
    ev = {}
    t0 = time.time()
    with Pool(threads, initializer=_init_worker, initargs=(bam_path, ref, min_mapq, ref, phase_ploidy)) as pool:
        for k, res in enumerate(pool.imap_unordered(_work, chunks), 1):
            for i, c in res:
                ev[i] = c
            if verbose and (k % 20 == 0 or k == len(chunks)):
                log(f"{name}: {len(ev)}/{len(work)} elements ({time.time() - t0:.0f} s)")
    with gzip.open(cache + ".tmp", "wt") as fh:      # atomic: a killed run leaves no truncated cache
        json.dump({"fingerprint": fp, "depths": depths, "spans": spans, "evidence": ev}, fh)
    os.replace(cache + ".tmp", cache)
    return name, ev, depths, spans


def boundary_tolerance(ev, sites):
    """Annotation boundary error, learned from the sample: at elements whose ends no TSD confirms, the median offset
    of empty-site and other-length spanning reads from the expected empty length (within RES_WIN bp; >= 2 reads
    per element). Returns (extra tolerance = BOUND_K x median |offset| over elements, elements used); 0 with fewer
    than BOUND_MIN_SITES elements (too little evidence: ends taken as exact)."""
    meds = []
    for i, c in ev.items():
        st = sites[i]
        if st.tsd_found:
            continue
        exp = st.delta["E"]
        r = [d - exp for d in c.get("other_delta", [])] + [d - exp for lab, d in c.get("es_delta", []) if lab == "E"]
        r = [x for x in r if abs(x) <= RES_WIN]
        if len(r) >= 2:
            meds.append(abs(median(r)))
    if len(meds) < BOUND_MIN_SITES:
        return 0.0, len(meds)
    return BOUND_K * float(median(meds)), len(meds)


def relabel_other(ev, sites, extra):
    """Other-length spanning reads at elements without a TSD that fit the empty or solo length within the widened
    tolerance are relabeled (counts updated in place). Returns the number of reads relabeled."""
    n = 0
    if extra <= 0:
        return 0
    for i, c in ev.items():
        st = sites[i]
        if st.tsd_found or not c.get("other_delta"):
            continue
        keep = []
        for d in c["other_delta"]:
            lab = st.classify_delta(d, extra)
            if lab in ("E", "S"):
                c[lab] += 1
                c["O"] -= 1
                n += 1
            else:
                keep.append(d)
        c["other_delta"] = keep
    return n


def run(args):
    v = args.verbose
    try:
        fa = pysam.FastaFile(args.reference)          # builds the .fai if needed
    except (OSError, ValueError) as err:
        sys.exit(f"ltrkin: cannot index {args.reference} ({err}): plain or bgzip-compressed FASTA in a writable "
                 f"directory, or run samtools faidx on it first")
    try:
        els = read_gff3(args.annotation)
    except ValueError as err:
        sys.exit(f"ltrkin: {err}")
    if not els:
        sys.exit(f"ltrkin: no LTR retrotransposon with two LTRs in {args.annotation}")
    missing = {e.chrom for e in els} - set(fa.references)
    if missing:
        log(f"warning: {len(missing)} annotation sequence(s) not in the reference, skipped: {sorted(missing)[:5]}")
        els = [e for e in els if e.chrom not in missing]
    if not els:
        sys.exit(f"ltrkin: no annotated element is on a sequence of {args.reference}")
    past = [e for e in els if e.end > fa.get_reference_length(e.chrom)]
    if past:
        sys.exit(f"ltrkin: {len(past)} element(s) end past their reference sequence, e.g. {past[0].id} "
                 f"(annotation of another assembly?)")
    log(f"{len(els)} elements ({read_gff3.skipped} skipped: fewer than two LTRs)", v)
    check_bams(args.bams, args.reference, fa, sorted({e.chrom for e in els}))
    out_dir = os.path.dirname(os.path.abspath(args.output))
    os.makedirs(out_dir, exist_ok=True)
    if not os.access(out_dir, os.W_OK):
        sys.exit(f"ltrkin: cannot write to {out_dir}")
    tsds = []
    for el in els:
        el.tsd = infer_tsd(fa, el)
        tsds.append(el.tsd_len)
    samples = []
    for bp, sname in zip(args.bams, sample_names(args.bams, args.reference)):
        name, ev, depths, spans = collect_sample(bp, args.reference, els, tsds, args.threads, args.min_mapq,
                                                    args.output, v, args.ploidy, sname)
        model = ReadModel(depths, spans, args.ploidy)
        sites = {i: Site(els[i], tsds[i]) for i in ev}
        tol, nb = boundary_tolerance(ev, sites)
        moved = relabel_other(ev, sites, tol)
        log(f"{name}: boundary error of TSD-less element ends: tolerance +{tol:.0f} bp ({nb} elements); "
            f"{moved} other-length reads relabeled empty/solo", v)
        rates = {i: model.rates(sites[i]) for i in ev}
        log(f"{name}: genome-wide depth: per haplotype {model.d_hap:.1f}, copy weights "
            f"{','.join(f'{w:.2f}' for w in model.copy_weights)}, NB size {model.k:.0f}", v)
        calls = {i: call(ev[i], rates[i], model, EPS_INIT) for i in ev}
        eps = estimate_eps((ev[i], calls[i][0], calls[i][1]) for i in ev) or EPS_INIT
        cal = site_calibration(((ev[i], rates[i], calls[i][0], calls[i][1]) for i in ev), model)
        if cal is not None:
            model.d_hap, model.k = cal[0], cal[1]
            model.depth = model.d_hap * model.ploidy
            log(f"{name}: depth at element sites from {cal[2]} sites with an empty/solo allele: per haplotype "
                f"{cal[0]:.1f}, NB size {cal[1]:.0f}", v)
        else:
            log(f"{name}: too few sites with an empty/solo allele to calibrate depth at element sites "
                f"(genome-wide depth kept)", v)
        calls = {i: call(ev[i], rates[i], model, eps) for i in ev}
        gts = genotypes(model.ploidy)
        prior = genotype_prior([calls[i][2] for i in ev if not calls[i][0].startswith(".")], gts)
        if prior is not None:
            calls = {i: call(ev[i], rates[i], model, eps, prior) for i in ev}
        log(f"{name}: depth {model.depth:.1f} (per haplotype {model.d_hap:.1f}), NB size {model.k:.0f}, "
            f"mean read span {model.mean_span:.0f} bp, error {eps:.4f}", v)
        if prior is None:
            log(f"{name}: too few called sites to learn a genotype prior (flat prior)", v)
        else:
            log(f"{name}: genotype prior (EM over sites): " + ", ".join(
                f"{g} {math.exp(p):.3f}" for g, p in sorted(prior.items(), key=lambda kv: -kv[1])
                if math.exp(p) >= 0.01), v)
        samples.append((name, ev, rates, calls, model, eps))
    write_tsv(args.output + ".genotypes.tsv", els, samples)
    write_vcf(args.output + ".vcf", els, samples, fa, args)
    for name, ev, rates, calls, model, eps in samples:
        gts = {}
        for i in ev:
            gts[calls[i][0]] = gts.get(calls[i][0], 0) + 1
        log(f"{name}: " + ", ".join(f"{g} {n}" for g, n in sorted(gts.items(), key=lambda x: -x[1])), v)
    log("done", True)


def flags_for(c, gt, mu, flank_ratio, ploidy):
    f = []
    T = sum(c[k] for k in CLASSES)
    if mu > 0 and T < DEPTH_LOW * mu:
        f.append("low_depth")
    if mu > 0 and T > DEPTH_HIGH * mu:
        f.append("high_depth")
    # other allele lengths are only visible in reads that span the site: compare with those
    spanning = c["F_span"] + c["S"] + c["E"] + c["O"]
    if c["O"] >= FLAG_MIN and c["O"] >= FLAG_FRAC * spanning:
        f.append("other_allele")
    if c.get("F_other", 0) >= FLAG_MIN and c.get("F_other", 0) >= FLAG_FRAC * spanning:
        f.append("full_other_length")      # a full allele whose internal region differs in length (indel, nesting)
    if c["U"] >= FLAG_MIN and c["U"] >= FLAG_FRAC * (T + c["U"]):
        f.append("unexplained_clips")
    if 0 <= flank_ratio < (ploidy - 0.5) / ploidy:
        f.append("flank_depth_low")
    lq = c.get("lowq", 0)
    if lq >= FLAG_MIN and lq >= LOWQ_FRAC * (lq + c.get("highq", 0)):
        f.append("low_mapq")               # many reads here map ambiguously: depth-based dosage is unreliable
    if T == 0:
        f.append("no_reads")
    return f


def write_tsv(path, els, samples):
    cols = ["element_id", "chrom", "start", "end", "strand", "family", "clade", "length", "ltr5_len", "ltr3_len",
            "tsd", "n_inner", "n_outer", "sample"] + [f"n_{k}" for k in COUNT_KEYS] + PHASE_KEYS + [
            "other_delta_median", "r_F", "r_S", "r_E", "exp_reads", "flank_depth", "flank_ratio", "genotype", "gq",
            "vcf_gt", "p_F", "p_E", "p_S", "pav", "flags"]
    with open(path, "w") as fh:
        fh.write("\t".join(cols) + "\n")
        for name, ev, rates, calls, model, eps in samples:
            for i in sorted(ev):
                el, c, r = els[i], ev[i], rates[i]
                gt, gq, lls, mu = calls[i]
                fr = c["flank_depth"] / model.depth if c["flank_depth"] >= 0 else -1
                od = c["other_delta"]
                row = [el.id, el.chrom, el.start + 1, el.end, el.strand, el.family, el.clade, el.length,
                       el.lltr[1] - el.lltr[0], el.rltr[1] - el.rltr[0], el.tsd or ".", el.n_inner, el.n_outer, name]
                row += [c.get(k, 0) for k in COUNT_KEYS] + [c.get(k, 0) for k in PHASE_KEYS]
                pa = allele_posteriors(lls)
                row += [int(median(od)) if od else ".", f"{r['F']:.3f}", f"{r['S']:.3f}", f"{r['E']:.3f}",
                        f"{mu:.1f}", c["flank_depth"], f"{fr:.2f}", gt, gq,
                        "/".join(VCF_IDX[a] for a in gt.split("/")),
                        f"{pa['F']:.4f}", f"{pa['E']:.4f}", f"{pa['S']:.4f}", pav_call(pa),
                        ",".join(flags_for(c, gt, mu, fr, model.ploidy)) or "PASS"]
                fh.write("\t".join(map(str, row)) + "\n")


def _vcf_str(v):
    """Percent-encode characters with a meaning in VCF ID / INFO values (VCF 4.3, 1.2), and whitespace."""
    return re.sub(r"[%;=,\s]", lambda m: f"%{ord(m.group()):02X}", str(v))


def write_vcf(path, els, samples, fa, args):
    names = [s[0] for s in samples]
    hdr = ["##fileformat=VCFv4.3", f"##source=ltrkin {__version__}", f"##reference={os.path.abspath(args.reference)}"]
    for c in sorted({e.chrom for e in els}):
        hdr.append(f"##contig=<ID={c},length={fa.get_reference_length(c)}>")
    hdr += ['##ALT=<ID=DEL:ME:LTR,Description="Empty site: the element and one TSD copy absent (pre-insertion allele)">',
            '##ALT=<ID=DEL:ME:SOLO,Description="Solo LTR: internal region and one LTR absent">',
            '##INFO=<ID=SVTYPE,Number=1,Type=String,Description="Structural variant type">',
            '##INFO=<ID=END,Number=1,Type=Integer,Description="Last base of the element">',
            '##INFO=<ID=SVLEN,Number=A,Type=Integer,Description="Length change of each ALT allele">',
            '##INFO=<ID=ELEMENT,Number=1,Type=String,Description="Element ID from the annotation">',
            '##INFO=<ID=FAMILY,Number=1,Type=String,Description="Family">',
            '##INFO=<ID=CLADE,Number=1,Type=String,Description="Clade">',
            '##FORMAT=<ID=GT,Number=1,Type=String,Description="Genotype: 0 full, 1 empty site, 2 solo LTR, . null (haplotype without the site)">',
            '##FORMAT=<ID=GQ,Number=1,Type=Integer,Description="Genotype quality (phred)">',
            '##FORMAT=<ID=AD,Number=R,Type=Integer,Description="Informative reads per allele (full, empty, solo)">',
            '##FORMAT=<ID=FT,Number=1,Type=String,Description="Per-sample flags">',
            "#" + "\t".join(["CHROM", "POS", "ID", "REF", "ALT", "QUAL", "FILTER", "INFO", "FORMAT"] + names)]
    with open(path, "w") as fh:
        fh.write("\n".join(hdr) + "\n")
        for i, el in enumerate(els):
            if not any(i in s[1] for s in samples):
                continue
            pos = max(1, el.start)       # 1-based position of the base before the element
            ref = fa.fetch(el.chrom, pos - 1, pos).upper() or "N"
            solo = -int(el.length - el.ltr_mean)
            info = (f"SVTYPE=DEL;END={el.end};SVLEN={-(el.length + el.tsd_len)},{solo};ELEMENT={_vcf_str(el.id)};"
                    f"FAMILY={_vcf_str(el.family)};CLADE={_vcf_str(el.clade)}")
            gtcols = []
            for name, ev, rates, calls, model, eps in samples:
                if i not in ev:
                    gtcols.append("/".join("." * model.ploidy) + ":0:0,0,0:no_data")
                    continue
                c = ev[i]
                gt, gq, lls, mu = calls[i]
                fr = c["flank_depth"] / model.depth if c["flank_depth"] >= 0 else -1
                fl = ";".join(flags_for(c, gt, mu, fr, model.ploidy)) or "PASS"     # FT: semicolon-separated
                gtcols.append(f"{'/'.join(VCF_IDX[a] for a in gt.split('/'))}:{gq}:{c['F']},{c['E']},{c['S']}:{fl}")
            fh.write("\t".join([el.chrom, str(pos), _vcf_str(el.id), ref, "<DEL:ME:LTR>,<DEL:ME:SOLO>", ".", ".",
                                info, "GT:GQ:AD:FT"] + gtcols) + "\n")
    pysam.tabix_compress(path, path + ".gz", force=True)
    pysam.tabix_index(path + ".gz", preset="vcf", force=True)       # records are sorted by (chrom, start)
    os.remove(path)
