# Plan 2 final fix wave: report (brief final-fix-brief.md; review final-review.md)

Implementer: final-wave fixer. Date: 2026-11-12. Branch `plan2-analyses`, base 4b73977, head 3eae543 (18 commits).
Commits use the existing git identity (cwb14); nothing set, no trailers, no AI attribution; nothing pushed.

Before starting: `pgrep -af 'ltrpav|run_variant|bakeoff|lastz'` listed no job. Baseline suite at 4b73977: 1121 passed,
2 deselected; ruff clean. A network cut interrupted the session after c581ad1; the uncommitted I2 work was checked
against its intent and finished (c4865a8).

How each commit was tested: targeted test files before the commit, then the full suite
(`python -m pytest -W error -m "not slow"`) and `ruff check .` in env `ltrpav` (NUMPY_MADVISE_HUGEPAGE=0) on a detached
worktree snapshot of that commit (PYTHONPATH=<snapshot>/src, so subprocess tests import the snapshot too), launched
with `setsid -f nohup`. Results per commit are in the table at the end.

## Per finding

| Finding | Status | Commit | Tests |
|---|---|---|---|
| C1 inversion caller | fixed | 073b155 | test_inversions.py: test_translocated_handful_is_no_block, test_scattered_misplacements_in_a_homologous_pair, test_reciprocal_translocation_keeps_both_partners, test_scaffold_spread_along_a_chromosome_is_no_block |
| I1 gradient sign | fixed | c581ad1 | test_trio.py: test_gradient_reads_the_excess_direction (both role orders); test_overview.py: test_gradient_text_follows_the_excess |
| I2 plot without a current stats part | fixed | c4865a8 | test_overview.py: test_plot_refuses_without_the_stats_stage, test_plot_refuses_after_a_failed_stats_rerun, test_plot_reads_no_findings_txt, test_plot_refuses_a_stats_tsv_without_sentinels; test_stats_core.py: test_sentinel_value_stays_text; test_cli_analysis.py: test_assemble (sentinels) |
| M13 findings.txt guard fails open | fixed (with I2) | c4865a8 | test_plot_reads_no_findings_txt |
| I3 panel H scale | fixed | 07fb58a | test_overview.py: test_panel_h_twenty_trios (bounding boxes), test_panel_h_84_trios |
| I4 headline wording | fixed | 784e5f9 | test_headline_says_consistent_with |
| M10 short legend statistics | fixed | 784e5f9 | test_short_legend_gives_no_statistic (3 probe paths) |
| M5 headline caveats | fixed | 784e5f9 | test_headline_names_the_lead_among_several_trios, test_headline_states_an_uncertain_sister_pair |
| M2 stale identity.tsv | fixed | 114ac2b | test_cli_analysis.py: test_paint_reads_identity_tsv_only_when_current |
| M8 identity.tsv deleted silently | fixed | cd4b76e | test_resume_without_identity_warns |
| M14 KeyError on a hand-edited marker | fixed | b43fd2a | test_hand_edited_marker_reads_as_stale |
| M1 genotype-only sister/recipient text | fixed | f5d3be2 | test_genotype_only_sister_text, test_genotype_only_recipient_text |
| M6 "chromosomes" | fixed | f5d3be2 | test_sequences_or_chromosomes |
| M4 glob deletion of paintings | fixed | 7076474 | test_paint.py: test_write_paintings_removes_only_painting_files; test_rows_and_files updated |
| M7 direction block ids | fixed | c1533b0 | test_direction.py: test_fallback_blocks_carry_the_genome |
| M3 stale figure stays | fixed | 5a50fea | test_overview.py: test_refused_or_failed_plot_leaves_no_figure |
| M12 PNG nondeterminism, no Liberation font | fixed (no conda-forge package: warning + DESIGN note) | b18c2ce | test_png_is_byte_deterministic, test_font_fallback_is_one_warning |
| M11 script path | fixed | 68261b9 | test_last_line_gives_the_script_path |
| M15 statistics core leftovers | partly, as ruled | b2111c4 | test_stats_core.py: test_jackknife_nan_estimate_short_circuits, test_jackknife_fewer_than_two_finite_pseudovalues, test_jackknife_drops_non_finite_pseudovalues, test_u95_elementwise |
| M16 private helper imports | fixed | 0a63410 | the existing suite; the fingerprint closure test stays green |
| M9 test gaps | fixed | c5ff376 (+ the I1, I2, I3 tests in their commits) | test_cli_imports_without_scipy (no LASTZ), test_run_without_scipy_exits_1 (LASTZ); legend tests without pdftotext |

Counts: 20 fixed, 1 partly fixed (M15, as the controller ruled), 0 skipped.

### C1 (073b155): syntenic partners, then contiguity
- One shared function, `inversions.syntenic_pairs(cat, x, y)`: the loci both genomes place (merged sites, any
  discovery) counted per (x sequence, y sequence) by fai index; t is s's dominant partner when it holds most of the
  loci both place on s (ties to the lower index), and alike from y's side; (s, t) are syntenic partners when t is s's
  dominant partner or s is t's. The caller groups only those pairs. `overview._partners` now picks each drawn
  recipient sequence's counterpart among its syntenic partners by the same function (each sister sequence used once,
  as before), so the figure and the caller share one definition.
- `n_discordant` keeps its meaning within a block. The rows' n is now the loci searched (on partner pairs); findings
  give, per pair, the loci left unsearched off partner pairs and the reversed runs dropped for contiguity, and state
  the rule and its cost.
- Another rule was needed, by the brief's test. On main3, reciprocal dominance alone left sparse blocks: unplaced or
  alt scaffolds whose dominant partner is a chromosome, their few loci spread along tens of Mb of it (for example
  TIL18_chr3:1.9-209.4 Mb against Zd_alt-scaf_41, 5 loci). The toy `test_scaffold_spread_along_a_chromosome_is_no_block`
  reproduces it: a 100-kb scaffold whose 10 loci lie spread along R's chr1 is a syntenic partner of chr1, and its 5
  reversed loci made a 160-kb block among 40 collinear loci (the test fails without the rule).
- The added rule is contiguity on both genomes: inside a block's extent on x and on y, the loci placed on another
  sequence pair must be fewer than the block's loci outside its discordant ones. `INV_FOREIGN_MAX = 1.0` in
  constants.py, with its reason: the merge rule's own tolerance (an interruption shorter than what it interrupts),
  final review C1. It is not a density and not tuned to main3. Loci of the block's own sequence pair never count: an
  inversion over most of a pair makes the collinear remainder the block, and its y extent spans the inverted rows
  (test_dominant_flip_finding failed on the first draft that counted them; fixed before the commit).
- Tests (expected blocks exact):
  - translocated handful: 11 loci of R chr1 together on S chr3, 6 in order and 5 reversed: no block (the old
    grouping gives a 5-locus block: asserted on `reversed_blocks` as the trap, and a mutant run of the old grouping
    fails the test); the real inversion on chr2 is the one block (302,001-698,150, 100 loci, 0 discordant);
  - scattered misplacements within a homologous pair: no block (shows that single misplacements need no rule);
  - reciprocal translocation: R chr1 holds 70 of S chr1's 100 loci and 60 of S chr2's: both are its partners, and an
    inversion in each piece is found (20 loci each). R chr2's share of S chr1 (30) is the smaller of both sequences'
    shares, so its 10-locus inversion is missed. That is the rule's stated cost, written in DESIGN 7.7, the module
    docstring and findings.txt.
- DESIGN 7.7, build decision 8 and DESIGN 6's panel A text updated. The toy writer gained `at` (a locus placed at
  another seqid and position in one genome: a translocation the engine can write).

### I1 (c581ad1)
- trio.py's Dating verdict reads dD in the direction of the overall excess: sign(D_pav all) x dD, naming the owner
  ("the excess, S's (S shares more insertions with D than R does: D_pav -0.231)"). The verdict register is I4's:
  "consistent with gene flow from D-like donors into S rather than lineage sorting alone". With D_pav 0 or nan no
  direction is read.
- overview.py: `facts()` reads the gradient relative to the excess; panel F's long legend says "read in the direction
  of the excess, S's: concentrated in young insertions"; the "down" headline and panel F's short text give S's age
  profile.
- Test: the reviewer's probe_gradient.py as a toy, both role orders (R,S,D gives D -0.231, dD -0.60; S,R,D the
  mirror); both name the genome labeled S; the legend test checks panel F and the headline.

### I2 and M13 (c4865a8)
- `assemble` writes one sentinel row per stage before its part's rows, within STATS_COLUMNS: layer "run", test
  `stats.PART` ("part"), scope the stage, statistic "key" (value: the stage key its marker records, n: the part's row
  count) or "left_out" (value: why, for a stale part). `read_stats` keeps a sentinel's value as text.
- `report.plot_refusals` (replacing `left_out_parts`) reads only the markers and stats.tsv's sentinels: the stats part
  must be finished, current (stale_parts with recorded tool versions) and in stats.tsv under its marker's key; the paint
  part likewise once its stage has finished (or whenever stats.tsv holds a painting). A stats.tsv without sentinels
  (older code) gets the same one-line refusal; `ltrpav-stats` (its stage skipped) reassembles it.
- Tests: paint-only then plot: refused; failed stats rerun: refused; findings.txt deleted: a current run draws, and a
  left-out stats part is still refused with its reason read from stats.tsv; no sentinels: refused, then drawn after
  ltrpav-stats.
- compare_papers.py reads stats.tsv by test name, so the new rows are harmless there.

### I3 (07fb58a)
- Panel H: one row per trio, sorted by D_pav (nan last): its 95% interval and point (open when not testable), the
  youngest (K = 0, dark) and oldest (K >= 0.01, light) D as small dots, one shared D axis; the lead trio's label bold;
  "no result" for a trio without D_pav. Columns of at most H_ROWS = 10 rows while each keeps H_FOREST_MIN = 16 mm of
  axis beside its widest label (display limits, named in the code); row pitch H_PITCH = 2.6 mm (6-pt labels never
  touch).
- Rendered and inspected at full resolution: 20 trios in 2 columns, 84 trios in 6 columns of 14, 120 trios (10 genomes,
  "G10,G11;G12"-length labels) in 5 columns of 24; no clipping or collision.
- Panel H's legends now count the trios with a significant excess and with a young-concentrated one (short legend
  without thresholds).
- Tests: 6 ingroup genomes (20 trios): every trio a labeled row, no text box of the panel overlaps another or leaves
  the figure (window extents after an Agg draw); 9 genomes (84 trios): `ltrpav-plot` exits 0 (it exited 1 before).
- Concern: at 120 trios with a full panel A (24 sequences), the page reaches about 300 mm, beyond the skill's ~240 mm
  (A4 is 297 mm). The toy 120-trio page is 206 mm. Panel H is already at its narrowest readable form; shrinking panel A
  for large runs would be the next step if the controller wants it.

### I4, M10, M5 (784e5f9)
- Headline: "consistent with gene flow from D-like donors into R rather than incomplete lineage sorting alone"; the
  other verdicts say "more than lineage sorting alone is expected to give".
- Short legend: no thresholds, q, Z or D values. "not significant (|Z| < 3)" -> "not significant"; panel A says
  "none of R's stands out from the control's tracts"; panel F drops "D +0.60 at K = 0 against +0.20"; panel G drops
  the signed excess (its two means show it). The numbers stay on the long legend.
- M5: several trios: "This is the strongest of the run's n trios; panel H shows them all" (or "This trio was named by
  the user"); an ambiguous sister pair (p_top >= P_WARN): "Which two of R, S and D are sisters is uncertain: R and S
  share 144 insertions, R and D 120, a difference within chance, so the roles may be swapped."

### M2 (114ac2b), M8 (cd4b76e), M14 (b43fd2a)
- M2: `report.identity_usable(cat)`: identity.tsv is read only when the stats part that wrote it is finished and current
  by files, options and code (tool versions not probed: LASTZ's version renumbers no locus). The paint key's
  "identity" parameter is now "identity.tsv is used", so the painting reruns once the stats part is current again.
  Ignored: a WARNING in the log and in findings.txt. The stats part's left-out WARNING (log and findings) names its
  side files: "inversions.tsv, mechanisms.tsv and identity.tsv, written with that part, are stale too".
- M8: "stats: deleting identity.tsv, the sequence-identity layer of an earlier run with --identity: this run is
  without it (rerun ltrpav-stats, or ltrpav run, with --identity to keep it)".
- M14: `_changed` reads backend_version with `.get` and gives the LASTZ message only when the current key has it; a
  hand-edited marker reads "its parameters differ (backend_version)".

### M1, M6 (f5d3be2)
- Genotype-only sister: panel A's long legend says "fitted on R" and "with no decoy painting (S discovers no
  insertions to paint), no tract has a q-value"; a collapsed fit (paint donor_state NA) is said in both legends ("No
  D-like ancestry is detectable along R's genome").
- Genotype-only recipient: no "painted the same way"; "R has no annotation, so it holds no insertions of its own to
  class or paint"; the numbers row no_painting says why; panel E names only the panels that exist ("panel A").
- M6 rule (`_chromosome_scale`): a drawn sequence is chromosome-scale by the drawing rule when its genome's sequences
  of at least MIN_FRAC of its longest number at most MAX_ROWS (the rule could draw them all) and it is one of them;
  the recipient's rows and the sister's counterparts are both checked. Otherwise "sequences". No name is read. main3:
  B73 has 10 such sequences, TIL01 14, every drawn one among them: "chromosomes". 300 toy scaffolds: "sequences".

### M4 (7076474), M7 (c1533b0), M3 (5a50fea)
- M4: `write_paintings` removes the painting files named for the run's labels (`paint.PAINTING_FILES`) and the painting
  files the last paint marker listed (`run_stage` reads them before clearing it); a genome labeled `tracts` keeps
  `tracts.pav.bed`, a user's `tracts.mine.bed` stays. The old test that expected an unlisted `tracts.Old.bed` to go now
  lists it as the last marker's output.
- M7: `direction.coord_blocks`: block ids per (genome, sequence, mid // size), dense, for D_dir and DFOIL.
- M3: `run_plot` deletes overview.png, .pdf and _numbers.tsv first, checks stats.tsv (the "no stats.tsv" refusal moved
  here from the CLI) and the parts, and deletes any file written if drawing fails. Tested standalone (refusal,
  half-written failure, no stats.tsv) and inside `ltrpav run` (a WARNING, no figure left).

### M12 (b18c2ce), M11 (68261b9)
- `mamba search -c conda-forge '*liberation*'`: only `r-fontliberation` 0.1.0, an R package pinned to r-base 3.4.1;
  `font-ttf-*` has no Liberation font. So no package was added: one WARNING names the fallbacks (DejaVu Sans and/or
  DejaVu Sans Mono), and DESIGN 6 notes it. environment.yml and the lock are unchanged.
- Font files are registered sorted, newest version first (the name table's version string; this host has Liberation
  1.07.4 and 2.1.5), then by path. Test: renders in two fresh interpreters with PYTHONHASHSEED 0 and 1 (which order the
  two files oppositely) give byte-identical PNGs; the unsorted mutant fails it.
- M11: "Script: <absolute path of overview.py>" (inspect.getsourcefile).

### M15 (b2111c4), M16 (0a63410), M9 (c5ff376)
- M15: `jackknife` returns nan se and z at once on a nan estimate (no pseudovalue computed). Tests for fewer than 2
  finite pseudovalues, the dropping of non-finite ones (se from the 3 finite with (m - 1) / m), and u95 elementwise.
  read_stats' coercion and block_size's bare ValueError are documented in their docstrings, not changed (as ruled).
- M16: `analysis/common.py` holds check_trio, fallback_reasons, first_member, fmt, guard, why, blocks, patterns
  (public); relations, trio, direction and identity call them module-qualified (`common.blocks(...)`), as several
  names are common local words. The fingerprint closure test is green (no new engine import).
- M9: the scipy-blocked import check runs without LASTZ (`test_run_without_scipy_exits_1` keeps the LASTZ half). An
  autouse fixture records each legend page's text as `_text_page` receives it; the legend tests read pdftotext's text
  when it is installed and the generator's otherwise, so their poppler skips are gone (20), except the PDF's own
  text-recovery test. Run with pdftotext hidden from PATH: 55 passed, 1 skipped.

## Engine stage keys
`checkpoint.STAGE_MODULES` fingerprints computed at 4b73977 (before any edit) and at HEAD: all seven stages
(elements, anchor, raw, blastdb, mm2_index, genotype_pair, genotype_chunk) identical, with identical module sets.
Files changed in src/ltrpav since 4b73977: analysis/{cli,common,constants,direction,identity,inversions,paint,relations,
report,stats,trio}.py and plot/overview.py only; no engine module.

## Real-data refresh (benchmark_pav/main3_analyses)
- Pre-wave copies in `prelim_tables/*.pre_wave`: stats.tsv, findings.txt, inversions.tsv, prelim_papers.tsv, PRELIM.md,
  overview.{png,pdf}, overview_numbers.tsv, plus chromosomes/windows.tsv, ltrmix_crosscheck.tsv, compare_papers.log,
  investigate_misses.txt, mechanisms.tsv, tracts.B73.bed, compare_papers.py and the analyses.{log,done,exit}.
- `run_analyses.sh` (stats --identity at 32 threads, paint, plot) launched from the view with
  `setsid -f nohup mamba run -n ltrpav bash run_analyses.sh > analyses.log 2>&1 < /dev/null`; leader 3536808, PPID 1,
  SID = PID. 11:53-12:23, exit 0: stats 1,639 s (alignment 1,294 s, 39 pairs/s; host load 180-245), paint 16 s, plot
  23 s. The code was c5ff376's analysis package (3eae543 only changed the figure spec and panel H's short sentence,
  committed before the plot stage started).
- `compare_papers.py` (124 s) and `investigate_misses.py` reran. compare_papers.py changes (outside the repo): every
  recall cell gives "k of n" and a one-sided binomial p against its bin's chance rate (Task 12 N5; row 57 now reads
  "q <= 0.05 0.200 (2 of 10; chance 0.051, 3.9x, binomial p 0.089)"); ruling 7's median sparse flag is dropped (the
  caller is fixed), and the item-10 summary rows give the final review's measure instead.
- Snapshots: main3 (226 entries, depth 3) and inputs/*.fai (sizes, mtimes, sha256) identical before and after; nothing
  newer than the start marker in main3, inputs, run, benchmark or LTRmix.

### What changed, and why
- stats.tsv: 19 values, no row added or removed besides the 2 sentinel rows. The 18 inversion rows (6 pairs x n_blocks,
  n_blocks_1Mb, bp_inverted_x; and their n, now the loci searched) and paint `n_inv_loci` 14,527 -> 14,352 (fewer loci
  inside blocks). D_pav (+0.2905, Z 7.42), every stratum, the gradient, KKSC, the painting, mechanisms and the identity
  layer are unchanged to the printed digit (the identity realignment reproduced its rows).
- findings.txt: the painting's inverted-locus line; the Dating line's verdict (now read in the direction of the
  excess, B73's, with "consistent with gene flow from TIL18-like donors into B73 rather than lineage sorting alone");
  the inversion lines (block counts, largest blocks, loci off partner pairs, runs dropped for contiguity, the rule).
- prelim_papers.tsv: 109 rows, 17 changed, verdicts unchanged (19 PASS, 5 MISS, 84 reported, 1 skipped; the LTRmix
  cross-check 58 equal, 1 different, as before):
  - 4 tract-recall rows (item 7, < 10 kb to >= 500 kb): counts and binomial p added to each cell (N5); values equal;
  - 13 item-10 rows: ruling 7's flag text and note removed; the two summary rows' notes give "0 of all 402 blocks
    span more than 1 Mb per locus". The blocks near Inv4m and Inv1n, their loci, breakpoints and coverage are
    identical to before: the artifacts lay elsewhere.
  - No other row changed. The figure's legend wording is not in prelim_papers.tsv; it changed in the PDF (below).
- investigate_misses.txt: the class share with inverted-block loci set aside moved in the third decimal on chr5-chr7
  (fewer such loci); the three lowest stay chr4, chr5, chr9.
- overview_numbers.tsv: A_inv_sparse (49) and A_inv_sparse_largest ("278 Mb on 6 loci") are gone, A_inv_drawn 296 -> 261,
  n_inv_loci 14,527 -> 14,352.

### Item 10 now
- 402 inverted blocks over the six pairs (523 before); none spans more than 1 Mb per locus (28 before, 27 of them
  between differently numbered chromosomes). Per pair, blocks (Mb on x): B73~TIL18 60 (118.7; 67, 122.7 before),
  B73~TIL01 55 (134.9; 59, 138.8), B73~Zd 60 (99.4; 69, 351.8), TIL18~TIL01 91 (245.5; 160, 1,686.6), TIL18~Zd 68
  (237.0; 81, 732.2), TIL01~Zd 68 (150.3; 87, 945.5). Loci off partner pairs (not searched): 418-1,883 per pair;
  reversed runs dropped for contiguity: 0-28 per pair.
- The largest block of every pair is now dense (hundreds of loci). The "largest" findings lines no longer name 5-8-locus
  blocks across chromosomes (B73~Zd now leads with chr9:32.18-59.01 Mb, 991 loci).
- Inv4m: one B73~TIL18 block, chr4:172.81-188.08 Mb, 464 loci, 0.997 of the reference interval, left breakpoint
  0.07 Mb from the reference end, right breakpoint interval containing it. Inv1n: three B73~TIL01 blocks cover 0.979 of
  65-115 Mb, ends 0.43 and 0.72 Mb from the approximate reference ends. Both unchanged; verdict "reported: both found".
- PRELIM.md: a refresh note at the top; section 1's register ("Consistent with gene flow rather than lineage sorting
  alone"); row 7 gains LTRmix's 2-of-10 count and p; row 10 rewritten with the new totals; the ruling-7 caveat replaced
  by one on the caller's rule and its cost; section 6 rewritten for the new figure. The memo's Plan 2 section gained
  the rerun (memo_ltrpav.md).

## Figure check (PRELIM.md section 6)
On the refreshed main3 overview (180 x 221 mm, 2125 x 2605 px, 3-page PDF, Liberation fonts embedded, no fallback
warning), full-resolution crops and the legend pages rendered with pdftoppm: lines 1-7 yes. Panel A draws 261 inverted
intervals and no longer leaves 49 sparse blocks undrawn; the short legend (284 words) has no threshold, q, Z or D value
and its headline says "consistent with gene flow from TIL18-like donors into B73 rather than incomplete lineage sorting
alone"; panel F reads the gradient in B73's direction; the last line gives the script path. I changed the figure code,
so this is not an independent check.

## Suite per commit
`python -m pytest -W error -m "not slow"` and `ruff check .` (env ltrpav), on a detached worktree snapshot of each commit:

| Commit | Finding(s) | Suite | ruff |
|---|---|---|---|
| 073b155 | C1 | 1125 passed, 2 deselected | clean |
| c581ad1 | I1 | 1128 passed, 2 deselected | clean |
| c4865a8 | I2, M13 | 1133 passed, 2 deselected | clean |
| 07fb58a | I3 | 1135 passed, 2 deselected | clean |
| 784e5f9 | I4, M10, M5 | 1141 passed, 2 deselected | clean |
| 114ac2b | M2 | 1142 passed, 2 deselected | clean |
| cd4b76e | M8 | 1143 passed, 2 deselected | clean |
| b43fd2a | M14 | 1144 passed, 2 deselected | clean |
| f5d3be2 | M1, M6 | 1147 passed, 2 deselected | clean |
| 7076474 | M4 | 1148 passed, 2 deselected | clean |
| c1533b0 | M7 | 1149 passed, 2 deselected | clean |
| 5a50fea | M3 | 1150 passed, 2 deselected | clean |
| b18c2ce | M12 | 1152 passed, 2 deselected | clean |
| 68261b9 | M11 | 1153 passed, 2 deselected | clean |
| b2111c4 | M15 | 1157 passed, 2 deselected | clean |
| 0a63410 | M16 | 1157 passed, 2 deselected | clean |
| c5ff376 | M9 | 1158 passed, 2 deselected | clean |
| 3eae543 | panel H spec text, I3's short sentence | 1158 passed, 2 deselected | clean |

Process notes: one commit (7076474, M4) first went in with an old test still expecting the glob deletion (my command
chained the commit on a piped test run); the test was updated to the new rule and the commit amended before anything
followed it. The last commit was amended once (a wording fix) before its suite ran. Queued suite chains were lost once
(their waiting wrappers matched their own command lines) and rerun in three lanes; every commit above has its own run.

## Concerns
- C1's rule misses an inversion inside a translocated piece that is the smaller share of both its sequences (for
  example both short arms of a balanced reciprocal translocation); the test pins it and DESIGN 7.7 states it. A
  contiguity rule beyond reciprocal dominance was added (INV_FOREIGN_MAX), as the brief allowed once a toy showed the
  remaining sparse artifact; the controller may want to rule on it.
- I3: with 120 trios and a full panel A (24 sequences), the page reaches about 300 mm, beyond the skill's ~240 mm
  (A4 297 mm). Fixing it would mean shrinking panel A for large runs.
- M12: conda-forge has no Liberation font package (only `r-fontliberation`, an R package pinned to R 3.4); a host
  without the fonts gets DejaVu with one warning. environment.yml and the lock are unchanged.
- M6's rule ("chromosome-scale by the drawing rule") is my reading of the brief: a genome's sequences of at least 2% of
  its longest number at most 24 and every drawn sequence is one of them. It calls large unplaced scaffolds (e.g.
  TIL01's two 14-17 Mb scaffolds, were TIL01 the recipient) chromosomes too; no name is read.
- The figure check in PRELIM section 6 was answered by me, who changed the figure code; it is not independent.

## Follow-up N1 (re-review N1, controller ruling)
- **Commit 12d3e6c** "Contiguity: loci on another syntenic partner of a mutually dominant pair's sequences do not count
  against a block". When a block's sequence pair (s, t) is mutually dominant, loci inside its extent placed on any
  other syntenic partner of s (on x) or of t (on y) are not foreign; on a pair kept from one side only, every other
  sequence still counts (`inversions._search`, `_dominance`, `_by_sequence`, `_count`). The stated cost (DESIGN 7.7, the
  constants.py reason line, the module docstring, findings.txt): a real inversion whose region's second copy lies on a
  non-partner sequence, or on a pair kept from one side only with more loci of other sequences in its extent than its
  own, is still dropped.
- **Tests.** New `test_alt_haplotig_does_not_break_a_block`: R chr1's 300-700 kb region lies twice in S, inverted on
  chr1 (33 loci) and collinear on the alternate haplotig alt1 (67 loci, a syntenic partner of R chr1); the inversion is
  kept (64 alt1 loci inside its extent). With the previous rule the test fails (block dropped). The scaffold artifact
  toy (a one-sided pair) is still dropped. Suite at 12d3e6c: 1159 passed, 2 deselected; ruff clean.
- **Engine keys:** all seven `checkpoint.STAGE_MODULES` fingerprints identical to 4b73977; no file outside
  src/ltrpav/{analysis,plot} changed since 4b73977.
- **Refresh** (benchmark_pav/main3_analyses; pre-N1 copies `prelim_tables/*.pre_n1`): run_analyses.sh detached
  (leader 1488367, PPID 1, SID = PID), 13:08-13:43, exit 0 (stats 1,835 s with the identity layer, paint 14 s, plot
  16 s); compare_papers.py and investigate_misses.py reran. main3 and inputs/*.fai identical before and after; nothing
  newer than the start marker in main3, inputs, run, benchmark or LTRmix.
- **Blocks:** 402 -> 417 (15 added, none removed); reversed runs dropped for contiguity 63 -> 48; none spans more than
  1 Mb per locus on its first genome. Per pair: B73~TIL18 60 -> 61, B73~TIL01 55, B73~Zd 60 -> 62, TIL18~TIL01 91 -> 93,
  TIL18~Zd 68 -> 71, TIL01~Zd 68 -> 75.
- **Zd chr10:49-51 Mb: reported** against all three: B73 (24 loci, 17 strand-inverted), TIL18 (30, 21), TIL01 (32, 23).
  **Zd chr1:130-135 Mb: reported**: TIL01 chr1:129.0-133.7 Mb against Zd chr1:130.5-135.4 Mb (53 loci, 45
  strand-inverted), and B73 (12 loci) and TIL18 (11) against Zd chr1:130.5-131.0 Mb.
- **Changed rows:** stats.tsv: 13 inversion rows of the five pairs that gained blocks, paint `n_inv_loci` 14,352 ->
  14,374 (B73's loci inside the added B73~TIL18 chr7 block) and the 2 sentinel keys; no other value. prelim_papers.tsv: 2 rows, the Inv4m
  and Inv1n summary rows (their note's block count, 402 -> 417); the Inv4m and Inv1n blocks and every verdict unchanged
  (19 PASS, 5 MISS, 84 reported, 1 skipped; cross-check unchanged). investigate_misses: chr7's share with inverted loci
  set aside 0.5000 -> 0.4993 (three lowest unchanged). Figure numbers: A_inv_drawn 261 -> 262, and 2 sparser blocks
  counted, not drawn (the largest 28 Mb on 23 loci).
- PRELIM.md (refresh note, row 10 with the Zd reversals, the inversion caveat, section 6 line 1), the memo and this
  report are updated.
- **Concern:** the final review's "more than 1 Mb per locus" measure reads only the first genome. On the second, 11
  blocks exceed it (7 before N1, 63 before the wave), e.g. B73 chr4:93.4-96.1 Mb against Zd chr4:91.9-234.8 Mb (31 loci,
  25 strand-inverted) and TIL18 chr4:23.5-24.4 Mb against TIL01 chr4:32.6-60.2 Mb (23 loci). They pass because rows of
  the block's own pair inside its y extent never count (kept for an inversion covering most of a pair, whose remainder
  block's y extent spans the inverted rows). Counting them unless the block is such a remainder (dominant direction
  -1) would be the next step; no ruling covers it, so it is reported, not changed.
