# Task 10 review: stages, assembly and commands (28faca2..12465a8)

Reviewer: task-scoped gate, 2026-11-12. Spec: ❌ (one gap: the exit-3 ruling made after implementation).
Task quality: **Needs fixes** (0 Critical, 2 Important, 3 Minor).
Scratch: /data2/chris/maize_introgression/benchmark_pav/plan2_reviews/task10/ (below: `$S`).

## Spec Compliance

| Requirement | | Evidence |
|---|---|---|
| Files: report.py, analysis/cli.py, tests/test_cli_analysis.py; cli.py hook; pyproject scripts installed; DESIGN 8 | ✅ | diff; `envs/ltrpav/bin/ltrpav-{stats,paint}` call `ltrpav.analysis.cli:{stats,paint}_main` |
| Interfaces (STAGES, stage_inputs, analysis_fingerprint, write_part, assemble, run_stats, run_paint, stats_main, paint_main, run_analyses) | ✅ | signatures as briefed |
| Ruling 1: key = stage_key(..., fingerprint=package_fingerprint("ltrpav.analysis", *closure)); closure tested against a walk; cli.py and `__init__.py` as the boundary | ✅ | my own AST walker (`$S/closure.py`) gives exactly ENGINE_MODULES (13 modules) |
| Ruling 1: an analysis edit leaves every engine stage key unchanged | ✅ | all 7 engine fingerprints and keys are byte-identical at 28faca2, 12465a8 and the working tree (`git archive` snapshots, `$S/engine_keys.py`) |
| Ruling 2: the --identity key holds LASTZ's version | ✅ | stage_params backend + backend_version; test_identity_key_holds_the_aligner_version |
| Ruling 3: inputs = checksums of the engine outputs read + the sheet; each marker lists exactly the files its stage writes; "done, skip" works | ✅ | main3 markers: stats = inversions, mechanisms, 2 parts; paint = 4 painting files, 2 parts; reruns log "done, skip" |
| Ruling 4: never `_check_pair_files` or any engine fingerprint check; works on an older engine's run | ✅ | main3 (engine 7d71073; its pair markers have no `meta`, so `_check_pair_files` would refuse all 9): both commands exit 0 with the checks patched to raise and 0 reads of pair markers |
| Ruling 4: one cli.py hook; missing scipy/matplotlib → one-line CliError, exit 1 | ✅ ⚠️ | test_cli_imports_without_scipy passes. ⚠️ The hook has three touch points in cli.py (options in `main()`, `check_trio` before genotyping, `run_analyses` after the merge). The early check is a fail-fast gain and stays inside cli.py, so I accept it |
| Ruling 5: inversion_rows in run_stats's order; the version header only in findings.txt | ✅ | report.py run_stats; main3 stats.tsv has one header row (STATS_COLUMNS) and no version line |
| Ruling 6: stderr ends with exactly one `error:` line, no traceback | ✅ | trio, missing-merge and missing-scipy tests; AnalysisError and CliError are ValueErrors handled by `_execute` |
| Ruling 7: the chr10 smoke uses a scratch copy | ✅ | the bakeoff chr10 run has no analysis outputs and no file newer than the brief; the implementer's copy contains no symlinks |
| Brief tests (10) present and passing; the N1 wording fix | ✅ | AST-equal apart from the noted ruff edits; `_g3` lines on main3 read "0.0126 + 0.000314 = 0.0129" |
| run_paint recomputes relations for `dist` | ⚠️ | it uses `pav_distances(cat)[0]`, which is exactly the `dist` that `relations` returns (relations.py:569, 585). Equivalent, so accepted |
| **Post-implementation ruling: an analysis error inside `ltrpav run` exits 3 (outputs kept, ERROR logged); a figure error stays WARNING, exit 0** | ❌ | **I1**: it exits 0 with a WARNING (probe `$S/probe4/hook.py`: `WARNING analyses stopped (KeyError ...)`, `EXIT 0`) |

## Strengths

- Engine isolation holds. The diff changes no engine stage key, and the analysis closure is exact. The `cli.py` boundary excludes only `annotation/*`, `loci.py`, `outputs/*` and `cli.py`. I found no dynamic imports, and from `cli.py` the analysis uses only `CliError`, `_backend`, `_execute`, `_options` and `_positive` (parsing, PATH check, exit status). So no result-affecting engine code escapes the key.
- The data-only reading is real. On main3 an audit hook saw 0 opens of pair done markers and 0 writes, renames or removes inside main3. A 5,016-entry snapshot of main3 (FASTAs and .fai included) is identical before and after.
- The numbers reproduce. Stats took 25.7 s / 642 MB and paint 21.2 s / 566 MB; second runs skip. D_pav = +0.290544 ± 0.0391529, Z 7.42 (1,317 / 724; 14,067 loci); sharing 5,392 / 3,097 / 1,828; the tree and the bounds line equal the report.
- The marker protocol follows checkpoint.py's (clear, write, mark last; outputs listed relative to the marker). Parts and assembled files are written atomically. A failed stage is reassembled out.
- The tests reach beyond the brief and are meaningful: engine-check booby traps, a closure walk, 18 fingerprint-sensitivity cases, marker contents, an --identity round trip through LASTZ, and a trio-mismatch WARNING.
- `--trio` is checked before any genotyping in `ltrpav run`. `write_paintings` clears old painting files, so a changed trio leaves no stale tracts.

## Issues

### Critical

None.

### Important

**I1. An analysis error in `ltrpav run` exits 0 (required change: exit 3).** src/ltrpav/cli.py:215-222.
- What: `except Exception` logs one WARNING and `_run` returns, so `_execute` returns 0 (probe: a planted KeyError gives `WARNING analyses stopped ...`, `EXIT 0`). The controller ruled after implementation that this must exit 3, keep the genotyping outputs and log at ERROR.
- Why: a pipeline that checks only the exit status cannot tell a complete run from one whose stats.tsv and findings.txt are missing or partial. The implementer's own concern 2 says the same.
- Fix:
  - Keep `MissingDependency` at exit 1 (ruling 4; test_cli_imports_without_scipy).
  - For any other exception from the stats or paint stage: log at ERROR (logger `ltrpav`) that the analyses failed and the genotyping outputs are complete, with how to rerun. End stderr with exactly one `error:` line (ruling 6), traceback only with -v, and exit 3. For example, the hook raises a dedicated exception (`AnalysesFailed`, exit status 3) `from exc`, and `_execute` catches it before `_HANDLED` and returns 3.
  - Leave room for Task 11: a plot-stage error must stay a WARNING with exit 0. Catch it inside `run_analyses`, or have the hook tell stages apart.
  - Update the cli.py docstring (lines 11-17: the analyses stage text and the "Exit status" list, adding 3), DESIGN.md:667-672 (decision 13), and tests/test_cli_analysis.py:317-329. The test should assert exit 3, one ERROR record, a last stderr line starting `error:`, the outputs kept, and stats.tsv holding only finished parts.
  - cli.py is in no engine stage set, so this changes no engine key. Recheck with `$S/engine_keys.py`.

**I2. Stale parts are assembled: a stage's marker is trusted by presence, not by key.** src/ltrpav/analysis/report.py:356-357 (`assemble`), called from analysis/cli.py:150-154.
- What: `assemble` includes any part whose marker exists, even when the marker's key no longer matches the run. Probe `$S/probe3/probe_markers.py` and `probe_stale.py`:
  - Run stats and paint, change the sheet (O becomes ingroup), and rerun only `ltrpav-stats`. The paint marker is STALE, yet its painting (made with O as outgroup) stays in stats.tsv and findings.txt beside a stats part made with O as ingroup. The Warnings section says nothing about it.
  - The same happens after an analysis-code edit (fingerprint changed) with only `ltrpav-paint` rerun: the old stats part is assembled.
  - In `ltrpav run`, the failure path (one stage raises; the except branch reassembles) can likewise keep a stale part of the other stage.
- Why: findings.txt is the run's scientific summary. Here it silently joins results from different sheets, engine outputs or analysis code. That contradicts named risk 3 ("stale parts are never assembled"), the implementer's decision 6 ("so assembled files never mix stale parts") and DESIGN 13.
- Fix:
  - Assemble a part only when its marker is current. In `_analyses`, which holds the catalog, compute for each stage with a marker `is_done(marker, report.current_key(cat, stage, meta trio, meta identity))`, using the options its meta records. My probe's `fresh()` does exactly this with existing functions.
  - Pass the current set to `assemble`. Leave a stale part out with one log line ("paint: made from other inputs or code than the run's now; left out of stats.tsv and findings.txt until ltrpav-paint reruns"), or keep it under a findings WARNING. Do this in both the normal path and the except path.
  - This subsumes `_set_paint_aside` (report.py:184-195), because paint's key already holds identity.tsv's presence and checksum, so that special case can go.
  - Caveat: a stats marker recorded with identity=True needs LASTZ's version to recompute. Without LASTZ on PATH it reads as stale, which errs conservative; say so in the log line.
  - Test: the sheet-change scenario above (the other stage's part left out and the log line present), plus the code-edit variant through a monkeypatched `analysis_fingerprint`.

### Minor

**M1.** report.py:253: `f.add(SECTIONS[8], ...)` uses a magic index. The Dating line beside it uses the section's name; use the name (or a named constant) here too.

**M2.** report.py:367, 377: a findings-part row without a tab passes the header check, then fails as `error: not enough values to unpack (expected 2, got 1)`. Validate each row as `read_self_counts` does: an AnalysisError naming the file and line, ending "rerun the <stage> stage".

**M3.** Two docstrings still describe the analysis key as the package alone:
- analysis/__init__.py:1-2 ("keys its stages on its own fingerprint");
- checkpoint.py:17-18 (the example `package_fingerprint("ltrpav.analysis")`, without ENGINE_MODULES).

checkpoint.py is in no engine stage set, so this doc fix changes no engine key. It reruns the analyses once.

Notes, not counted:
- (a) By the brief's design, the fingerprint covers the whole analysis package. Any analysis edit, even to paint.py or analysis/cli.py help text, therefore reruns the stats stage, and with --identity that includes the hours-long identity layer. Per-stage module sets would avoid this if Task 12's detached --identity run makes it bite.
- (b) Outside this diff (Task 6): paint.py:500-502 deletes every `tracts.*.bed` in the outdir. A genome labeled `tracts` has the engine track `tracts.pav.bed`, which paint would delete. The label is unlikely; limiting the globs to the sheet's labels fixes it.
- (c) Under ruling 4, "scipy missing after complete genotyping" stays exit 1 in `ltrpav run`. The controller may want 3 there too, so that pipelines can tell genotyping failures from analyses that could not run.

## Verification performed

- Engine keys: `git archive` of 28faca2 and 12465a8 into `$S/snap/`, then `$S/engine_keys.py` per snapshot (`ltrpav.__file__` confirmed from the snapshot). 7/7 fingerprints and keys are equal, and the working tree equals 12465a8.
- Closure: `$S/closure.py` (an independent walker): declared == walked; it also lists what the cli.py boundary excludes. A grep found no importlib or `__import__` into the engine.
- Markers and skip (toy runs, `$S/probe3/`):
  - baseline: stats, paint, then both skip;
  - `--trio` changed: only stats reruns, paint skips, and the trio-mismatch WARNING appears;
  - sheet changed with one command rerun: I2;
  - analysis code "edited" (monkeypatched fingerprint) with only paint rerun: I2.
- Hook (`$S/probe4/hook.py`): a planted analysis KeyError gives WARNING and exit 0 (I1). Fail-fast `--trio` and missing scipy are covered by passing tests.
- main3, read-only:
  - view at `$S/main3_view`: symlinks for loci.tsv, qc.tsv, manifest.json, pairs/ and work/elements; a real work/; a copied sheet;
  - guard `$S/guard_run.py`: `_check_pair_files`, `_pair_files` and `stage_fingerprint` patched to raise, plus an audit hook;
  - results as under Strengths; before/after snapshots at `$S/main3_{before,after}.tsv`.
- Tests: `pytest -W error -p no:cacheprovider tests/test_cli_analysis.py tests/test_mechanisms.py` gave 64 passed (31 s). `ruff check --no-cache .` is clean, and the checkout is unchanged (`git status` empty).

## Assessment

Task quality: **Needs fixes.** The core work is sound. The engine is isolated (verified at key level), the closure is exact and tested, the commands read an older engine's run as data without touching it, and the main3 numbers reproduce. Two changes are needed before Task 11 builds on the hook and the assembly:
- I1: the ruled exit code 3 for analysis failures in `ltrpav run`, with docs and test updated;
- I2: assemble only current parts. This also removes the identity-specific `_set_paint_aside` special case.

## Re-review (fix round 1: 12465a8..84c909e)

Date: 2026-11-12. Scope: the five findings, plus new breakage in the fix diff. Scratch: `$S/rr/`.

Verdicts: 5 ADDRESSED, 0 PARTIAL, 0 NOT ADDRESSED. New: 0 Critical, 0 Important, 1 Minor (N1).
Task quality: **Approved**.

| Finding | Verdict | Evidence |
|---|---|---|
| I1 exit 3 | ADDRESSED | See "I1 detail" below the table. |
| I2 stale parts | ADDRESSED | See "I2 detail" below the table. |
| M1 | ADDRESSED | `IDENTITY_SECTION`, which is identity.SECTION (== SECTIONS[8]) |
| M2 | ADDRESSED | each findings-part row is checked for a tab and a known section; an AnalysisError names the file and line; tested in test_assemble |
| M3 | ADDRESSED | the analysis/__init__.py and checkpoint.py docstrings name ENGINE_MODULES; the checkpoint.py edit touches the docstring only |

I1 detail:
- Mechanism: the hook logs one ERROR, then raises `AnalysesFailed` (a RuntimeError) from the exception. `_execute` catches it before `_HANDLED`, prints one `error:` line and returns 3. The traceback appears only with -v.
- Probe `$S/rr/hook3.py` ran through the real `sys.exit` path with:
  - a KeyError;
  - a multi-line ValueError (collapsed to one line);
  - a paint-stage failure.
- Each case gave exit 3, one `error:` line (the last), one ERROR record, no traceback, and manifest.json and loci.tsv kept.
- With -v the traceback is printed and the `error:` line is still last.
- Missing scipy or matplotlib still exits 1 (test_cli_imports_without_scipy passes).
- Plot errors: there is no plot stage yet. run_analyses' docstring sets the WARNING/exit 0 contract for Task 11.
- Docs updated: the cli.py docstring (exit status 3) and DESIGN 13.

I2 detail:
- `stale_parts` recomputes each key from the trio and identity its marker recorded. Both `_analyses` paths leave stale parts out, each with one WARNING in the log and in findings.txt's Run section. `_set_paint_aside` is gone, since paint's key already holds identity.tsv.
- Toy probe `$S/rr/probe_stale_markers.py`. These markers all degrade to stale, with the part left out and the reason named:
  - the 12465a8 format;
  - meta `{}`, or no meta at all;
  - junk inputs, params or code;
  - malformed outputs, or a deleted output;
  - a 2-label trio, or a trio naming no label;
  - identity recorded as a string.
- Malformed JSON and a non-dict meta degrade to "no part".
- main3 test: the view's markers were written by 12465a8.
  - ltrpav-stats reran stats and left the old painting out ("its marker records no inputs (made by an earlier version); the analysis code changed").
  - ltrpav-paint reran; afterwards both commands skip and nothing is left out.
  - D_pav is unchanged (0.290544 ± 0.0391529, Z 7.42075).
- One hand-made marker shape crashes: N1.

Named checks:
- `stale_parts` on old or partial markers: it degrades to "stale" for every marker the code writes, in any version, and for damaged ones. One hand-made shape raises (N1).
- Exit 3: one `error:` line and no traceback, as above.
- Engine keys: in an 84c909e snapshot, all 7 fingerprints and keys equal 28faca2's and the working tree's. The closure is still exact (`$S/closure.py`).

Also checked:
- main3 and the inputs are identical to the first-review snapshot (5,016 entries).
- Guard: 0 pair-marker reads, 0 writes into main3.
- Stats took 26.7 s / 642 MB, so `stale_parts` adds no measurable time.
- Tests: test_cli_analysis.py (41) + test_cli.py + test_checkpoint.py gave 105 passed (47 s) with -W error. test_cli's `ltrpav run` worlds still exit 0, so exit 3 exposes no hidden analysis failure in them.
- `ruff check --no-cache .` is clean, and the checkout is unchanged.

### New issue

**N1 (Minor). `_changed` can raise on a hand-made marker.** src/ltrpav/analysis/report.py:224.
- What: `now = params["backend_version"]` runs when the recorded params differ from the current ones only in `backend_version`. If the current params lack that key (the marker records identity False), it raises KeyError.
  - Probe `$S/rr/probe_keyerror.py`: a paint marker with `backend_version` added to its params makes `ltrpav-stats` exit 1 with a traceback ending `KeyError: 'backend_version'`.
  - In `_analyses`' failure path the same error is suppressed, and the reassembly is skipped.
- Why it is Minor: run_stage writes `backend` and `backend_version` together, and only with identity, so no genuine marker of any version triggers this. It still breaks the "degrade to stale, never crash" contract and ruling 6's one-line error.
- Fix: use `params.get("backend_version")`. Optionally, wrap each stage's body in `stale_parts` in `try/except Exception`, so that any unexpected marker shape counts as stale ("its marker could not be compared: <Type>").

Carry-forward to Task 11: run_analyses must catch plot-stage errors itself (WARNING, exit 0), because the hook turns anything it raises into exit 3.
