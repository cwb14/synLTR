# Task 9: controller rulings

These bind as much as task-9-brief.md, and override it where the two conflict.

## R1. Two dispatches
Task 9 is large, and recent implementers were cut off mid-task. It runs as two parts, each with its own review.
- **Part A:**
  - `common/evalib.py` and `common/test_evalib.py` (Steps 1-2);
  - `sim/RULES.md`, written and dated before any run is scored (Step 3);
  - `sim/eval_run.py`, built and checked on Task 8's toy runs.
- **Part B:**
  - `sim/eval_ltrmix.py` and `sim/summarize.py`;
  - scoring the pilot (Step 4);
  - the `sim/memo.md` entries.

Part A may run while Task 8 Part B runs the pilot. Part A never edits `sim/memo.md`, `run_one.sh`, `run_grid.sh` or
`common/env.sh`; those belong to Task 8 Part B.

## R2. RULES.md
- Write it verbatim from the brief's list, then date it (2026-11-13) and record its sha256 in the report.
- Add one sentence under rule 7, from Task 8 Part A's review m5: only the label of each prediction is predicted. A
  code with chance signs (`00+0`, `0-0-` in `direction_predictions.tsv`) still predicts "none".
- After this file is written, no rule changes. A rule the pilot cannot apply is reported as NA with its reason.

## R3. Inputs for development
- **Toy runs.** Task 8 Part A made two complete toy runs through `--until ltrmix`, on 5 x 1.5-Mb windows:
  `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/toy2/runs/{null_s101,fn0.2_f0.18_r1}`.
  - `null_s101` is a 7-genome null.
  - `fn0.2_f0.18_r1` is a trio with gene flow and A1 dropout 0.2.
  - Copy them into your scratch before running eval. eval writes `eval/` inside a run directory, and the originals
    stay as they are.
  - Toy scale has known artifacts: few loci per block, and LTRmix with few chromosomes. Report them as such; never
    tune to them.
- **rate_free_split.** Its output, `rate_free_split.txt` and `rate_free_split.exit`, sits in the run directory, not
  in `ltrmix/` (Task 8 Part A).
  - Kind null only.
  - A missing s line is NA with a reason, never an error (Part A review m6). Part B reads it.

## R4. Reuse, not copies
- **Block rule.** Take it from the snapshot (`ltrpav.analysis.stats`). If the brief's rule
  `min(5 Mb, max(smallest // 100, 10 kb))` and `stats.block_size` differ, say so in the report and use the brief's
  rule for truth D.
- **jackknife and block_ids** come from the snapshot (brief).
- **Score parity.** The genotype join must equal `ltrpav-sim score`'s pooled totals (brief). A mismatch stops the
  run with an error naming the state.

## R5. Environment and rules
- Every script sources `common/env.sh`, which carries snapshot 4f3973e and the env bin on PATH.
  - Never use `python -I` or `-E`.
  - Never install into env `ltrpav` or env `ltrmix`.
- **Probes.** At most 16 threads, each under `timeout 15m`. The pilot uses the 32 job threads.
- **Inputs are read-only.** These must stay untouched: `plan3/real/`, `main3/`, `main3_analyses/` and the pilot run
  directories `plan3/sim/runs/`. Score the pilot only in Part B.
