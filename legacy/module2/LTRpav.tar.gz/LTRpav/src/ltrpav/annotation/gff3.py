"""Read and write LTR-RT GFF3 (LTRquest and EDTA conventions). Coordinates are 1-based inclusive."""
from __future__ import annotations

import gzip
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from urllib.parse import unquote

from ltrpav.annotation.records import RecordSkips
from ltrpav.elements import Element, make_eid

_UNKNOWN = {"", ".", "unknown", "NA"}
_ESC = re.compile(r"[;=&,%\t\n]")
_SEQID_ESC = re.compile(r"[^a-zA-Z0-9.:^*$@!+_?|-]")  # GFF3: seqid characters outside this set are %XX
_LTR = "long_terminal_repeat"
_HOST = "LTR_retrotransposon"  # a type ending in it is an LTR-RT (EDTA: Copia_LTR_retrotransposon, ...)


def _open(path: Path, mode: str):
    if str(path).endswith(".gz"):
        return gzip.open(path, mode + "t")
    return open(path, mode)


def _attrs(col9: str) -> tuple[dict[str, str], list[str]]:
    """Column 9 as (attribute -> value, the Parent ids), percent-decoded; Parent is split on its raw commas,
    then each id decoded."""
    out, parents = {}, []
    for part in col9.strip().split(";"):
        if "=" in part:
            key, val = part.split("=", 1)
            key = key.strip()
            out[key] = unquote(val)
            if key == "Parent":
                parents = [unquote(x) for x in val.split(",") if x]
    return out, parents


def _clean(v: str | None) -> str | None:
    return None if v is None or v in _UNKNOWN else v


def _classify(a: dict[str, str]) -> tuple[str | None, str | None]:
    sf, clade = _clean(a.get("superfamily")), _clean(a.get("clade"))
    cls = a.get("classification") or a.get("Classification")
    if cls and (sf is None or clade is None):
        parts = cls.split("/")
        if sf is None and len(parts) > 1:
            sf = _clean(parts[1])
        if clade is None and len(parts) > 2:
            clade = _clean(parts[2])
    return sf, clade


def _kimura(a: dict[str, str]) -> float | None:
    """K2P from K2P_d, else the JC69 distance from ltr_identity; None if absent, unreadable or not finite."""
    if "K2P_d" in a:
        try:
            k = float(a["K2P_d"])
        except ValueError:
            return None
        return k if math.isfinite(k) else None
    if "ltr_identity" in a:  # JC69 distance from LTR identity
        try:
            p = 1.0 - float(a["ltr_identity"])
        except ValueError:
            return None
        if p < 0 or 4 * p / 3 >= 1:
            return None
        return -0.75 * math.log(1 - 4 * p / 3) + 0.0
    return None


def load_gff3(path: Path, genome: str) -> tuple[list[Element], Counter]:
    """Return (elements, skip counts).

    Only LTR-RT lines (type ending in LTR_retrotransposon) and long_terminal_repeat lines are parsed: a line of
    any other feature type, however malformed, is never read. One of these with fewer than 9 columns
    (malformed_columns) or a start and end that are not integers with 1 <= start <= end
    (malformed_coordinates) is skipped with a warning naming the file and line (RecordSkips). An LTR-RT
    without exactly two LTRs is no_ltr_pair. A record with a Classification and no `family` attribute is
    EDTA's: its Name is the family and its ID the element name. Seqids and attribute values are
    percent-decoded.
    """
    path = Path(path)
    skips = RecordSkips()
    hosts: list[tuple[str, int, int, str, dict, str | None]] = []
    ltrs_by_parent: dict[tuple[str, str], list[tuple[int, int]]] = defaultdict(list)
    with _open(path, "r") as fh:
        for n, line in enumerate(fh, 1):
            if line.startswith("##FASTA"):
                break
            if line.startswith("#") or not line.strip():
                continue
            f = line.rstrip("\r\n").split("\t")
            ftype = f[2] if len(f) > 2 else ""
            if ftype != _LTR and not ftype.endswith(_HOST):
                continue  # a feature type the loader does not use
            if len(f) < 9:
                skips.malformed(path, n, "malformed_columns", f"{ftype} line with {len(f)} tab-separated columns, "
                                "not 9")
                continue
            try:
                start, end = int(f[3]), int(f[4])
            except ValueError:
                start = end = 0
            if not 1 <= start <= end:
                skips.malformed(path, n, "malformed_coordinates", f"{ftype} start {f[3]!r} and end {f[4]!r} are "
                                "not integers with 1 <= start <= end")
                continue
            seqid = unquote(f[0])
            a, parents = _attrs(f[8])
            if ftype == _LTR:
                for p in parents:
                    ltrs_by_parent[(seqid, p)].append((start, end))
            else:
                hosts.append((seqid, start, end, f[6], a, parents[0] if parents else None))
    elements: list[Element] = []
    for seqid, start, end, strand, a, parent in hosts:
        eid_attr = a.get("ID")
        ltrs = list(ltrs_by_parent.get((seqid, eid_attr), [])) if eid_attr else []
        if not ltrs and parent is not None:  # EDTA: LTRs are siblings under the repeat_region
            ltrs = [x for x in ltrs_by_parent.get((seqid, parent), []) if x[0] >= start and x[1] <= end]
        if len(ltrs) != 2:
            skips.filtered("no_ltr_pair")
            continue
        left, right = sorted(ltrs)
        tsd = _clean(a.get("tsd"))
        sf, clade = _classify(a)
        name, family = a.get("Name"), _clean(a.get("family"))
        if "family" not in a and "Classification" in a:
            # EDTA: Name is the family (TE_00000123) and ID the unique element
            name, family = eid_attr, _clean(a.get("Name"))
        elements.append(Element(
            genome=genome, eid=make_eid(genome, seqid, start, end),
            name=name or eid_attr or make_eid(genome, seqid, start, end),
            seqid=seqid, start=start, end=end,
            strand=strand if strand in ("+", "-") else ".",
            ltr_left=left, ltr_right=right,
            tsd=tsd.upper() if tsd else None,
            k=_kimura(a), family=family, superfamily=sf, clade=clade,
            confidence=_clean(a.get("confidence")),
        ))
    return elements, skips.counts


def _esc(v: str) -> str:
    return _ESC.sub(lambda m: f"%{ord(m.group()):02X}", v)


def _esc_seqid(v: str) -> str:
    return _SEQID_ESC.sub(lambda m: "".join(f"%{b:02X}" for b in m.group().encode()), v)


def write_gff3(elements: list[Element], path: Path) -> None:
    """Write LTRquest-convention GFF3 (gzip if the path ends in .gz)."""
    lines = ["##gff-version 3\n"]
    for e in elements:
        eid = _esc(e.eid)
        opt = [("Name", e.name), ("tsd", e.tsd), ("K2P_d", None if e.k is None else repr(e.k)),
               ("family", e.family), ("superfamily", e.superfamily), ("clade", e.clade),
               ("confidence", e.confidence)]
        attrs = f"ID={eid}" + "".join(f";{k}={_esc(v)}" for k, v in opt if v is not None)
        head = f"{_esc_seqid(e.seqid)}\tLTRpav\t"
        tail = f"\t.\t{e.strand}\t.\t"
        lines.append(f"{head}LTR_retrotransposon\t{e.start}\t{e.end}{tail}{attrs}\n")
        for tag, (s, t) in (("lLTR", e.ltr_left), ("rLTR", e.ltr_right)):
            lines.append(f"{head}long_terminal_repeat\t{s}\t{t}{tail}ID={eid}.{tag};Parent={eid}\n")
    p = Path(path)
    if str(p).endswith(".gz"):
        with open(p, "wb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", mtime=0, filename="") as gz:
            gz.write("".join(lines).encode())
    else:
        p.write_text("".join(lines))
