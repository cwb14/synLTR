# memo: LTRmix workflow diagram

date: 2026-11-10 | purpose: one diagrammatic overview of the LTRmix method for the repo README
env: ltrmix (matplotlib) | inputs: none (schematic; drawn from the method in ../ltrmix.py, not from data)
outputs: workflow.png (figure, 400 dpi), workflow.pdf (figure + short and long legend pages)

```bash
cd LTRmix/docs && python workflow.py          # rebuilds workflow.png and workflow.pdf
```

## Layouts considered
1. One row, six steps left to right: too wide and short for a page (ratio > 3:1). Rejected.
2. Hub: orthology in the center, tests and painting as spokes. Hides the order of steps. Rejected.
3. Chosen: three rows. Row 1 = inputs -> sister pair -> orthology (what every analysis needs); row 2 = the two
   things done with it, side by side (genome-wide tests | local ancestry); row 3 = output files. Reads top-left to
   bottom-right, and the colors for recipient (dark gray), sister (blue) and donor (vermillion) are assigned in
   step 2 and kept throughout, so the roles read without a key after that.

## Rules followed
- Words only as labels (step titles, roles, glyph names, file names); sentences go to the legend pages.
- Flat schematic style (no data marks, no gradients); the age panel is marked as a schematic trend, not data.
- Colors: Okabe-Ito blue #0072B2 (sister), vermillion #D55E00 (donor), dark gray (recipient), gray (context).

## Figure check (schematic; data-figure items 1-4 do not apply)
5. On-figure text only labels and keys: yes.
6. Nothing clipped or colliding at full resolution: checked on 400-dpi crops.
7. Each step answers a different question; legend pages follow the skill (short, long, analysis line): yes.
