### Task 3: One-pass genome builder and assembly gaps

**Files:**
- Create: `src/ltrpav/sim/popbuild.py`, `tests/test_popbuild.py`.

**Interfaces:**
- Consumes:
  - `ChromEvents`, `Ins`, `Loss` (Task 2);
  - `Rates`, `SimElement`, `Donor`; `SLOP_TSD_MULT`, `TSD_DEFAULT` (engine constants, read only);
  - `pair.GAP_LEN`, `GAP_NEAR`;
  - `genome.revcomp_bytes`, `substitute`.
- Produces:

```python
@dataclass
class Copy:              # one element (backbone eid or iid) as it stands in one built genome
    eid: str; chrom: int; inherited: bool  # sample below the element's origin (backbone: always)
    fate: str            # "intact" | "solo" | "partial" | "deleted" | "replaced" | "absent" | "site_lost"
    start: int; end: int  # image in the genome (0-based half-open, chromosome coordinates), -1 if none
    ltr_left: tuple[int, int]; ltr_right: tuple[int, int]
    own: int; own_kept: int; ltr_own: tuple[int, int]; ltr_kept: tuple[int, int]
    site: int            # chromosome coordinate of the target site when not inherited and its empty-site window is
                         # intact (rule below), else -1
    target: tuple[int, str | None, int]   # (chrom, host, pos) of an insertion's target; backbone (chrom, None, -1)
    host: str | None; tsd: str; k2p: float | None; events: list[str]
@dataclass
class PopGenome:
    label: str; group: str; seqids: list[str]; seqs: list[bytes]
    copies: dict[str, Copy]; gaps: list[tuple[int, int, int]]      # (chrom, start, end)
    lift: list["Lift"]                             # per chromosome
Lift = tuple[np.ndarray, np.ndarray]   # start of every kept backbone piece, in backbone and in genome coordinates
                                       # (int64, ascending)
def build_chrom(chrom: int, backbone: bytes, elements: list[SimElement], ts, ev: ChromEvents, donors: list[Donor],
                rates: Rates, rng: np.random.Generator) -> list[tuple[bytes, dict[str, Copy], Lift]]   # per sample
def lift_pos(lift: Lift, pos: int) -> int     # genome coordinate of backbone position pos; a deleted position maps
                                              # to the next kept base
def add_gaps(genomes: list[PopGenome], per_mb: float, rngs: list[np.random.Generator]) -> None   # one stream/genome
```

- **Event order.** For each sample, the events it carries (insertions, losses, indels) are applied in time order, oldest
  first, in backbone or host coordinates.
  - A deletion removes everything present in its interval at that time, nested elements included.
  - An insertion whose target was deleted earlier on the sample's lineage does not happen there: fate `"site_lost"`.
- **One pass.** The sample's sequence is emitted as pieces in coordinate order and joined once. Pieces are backbone
  slices with the sample's SNP bases, indel insertions and payloads.
  - Element and site coordinates are cumulative piece lengths.
  - The lift map records each kept backbone piece's start in both coordinates (`PopGenome.lift`, `lift_pos`). Task 4's
    `tract_bed` reads it.
  - No per-event array copy is made; that was Plan 1's 7.8-minute cost.
- **The empty-site window** sets `Copy.site`, and Task 4 reads it.
  - It is the w = `SLOP_TSD_MULT * TSD_DEFAULT` bases on each side of the target, plus the TSD.
  - Only losses or deletions that remove window bases break it.
  - SNPs, small indels and insertions at other sites inside the window never break it. This is Plan 1's truth:
    point mutations and Y-specific insertions at other sites are transparent.
- **Payloads.**
  - Each insertion's body is its donor body with fresh `copy_noise` substitutions (LTRmix's 0.5%, one draw per
    insertion). Its left LTR is then copied over its right LTR, so the LTRs are identical at insertion.
  - The body is oriented by strand.
  - The TSD is the sample's 5 target bases at the insertion time: the left copy stays in place, and the right copy
    follows the element as part of the payload.
  - Payload substitutions: each base changes at `mu` per generation along the path from the event point to the sample
    (`genome.substitute`). Branches are shared, so orthologous copies share mutations (LTRmix's recursion).
  - Nested payloads are spliced in at their offsets after their own mutation.
- **Losses.**
  - `solo` keeps the left LTR's first `a` bases and the rest of the right LTR, with both TSD copies. Everything between
    is deleted, nested insertions included.
  - `del_flank` removes the element plus `a` and `b` flank bases in its host.
  - `del_partial` removes `b` internal bases from offset `a`.
  - `replace` deletes the element (and anything nested) and puts `a` random bases in its place, with no TSD change.
    Its fate is `replaced`.
- **Counts and divergence.**
  - `own` counts the element's bases outside anything nested in it; `*_kept` counts those still present.
  - `k2p` is the Kimura 2-parameter distance between the copy's two LTRs.
    - Simulated insertions: compared position by position (equal length, substitution only).
    - Backbone elements: p is the source annotation's p-distance, from its K, plus the sample's derived SNPs in either
      LTR per mean LTR length. It is converted back to K2P with transitions and transversions in the source's ratio
      (JC if unknown).
- **Gaps (`add_gaps`).** `per_mb` 100-bp N runs per Mb per genome. A third start or end within `GAP_NEAR` of an element
  end or an absent element's site; the rest are uniform. They are recorded in `gaps`.
  - Plan 1's density of 2.5 per Mb is conservative against real `G`, 0.02-0.08% of main3's calls.

- [ ] **Step 1: Write the failing tests** (`toy_ts` trees, 200-kb backbones, explicit `ChromEvents`).

```python
def test_tsd_both_sides():          # mu=0: carrier holds TSD, body, TSD at copy coords; non-carrier one TSD at `site`
def test_identical_ltrs_and_k2p():  # mu=0 -> k2p 0 (copy noise leaves LTRs identical); mu=1e-6, age 1e4, 2 leaves:
                                    # mean k2p within 3 SE of 2*mu*age
def test_copy_noise():              # copy_noise 0.005, mu=0: body differs from donor at 0.005 +- 3 SE; LTRs identical
def test_solo_structure():          # one LTR-length segment between the two TSD copies; fate "solo"
def test_flank_deletion():          # del_flank a=300 b=0: element and 300 left bases gone; fate "deleted"
def test_partial_deletion():        # own_kept == own - b; fate "partial"
def test_replace():                 # element gone, `a` new bases between the intact flanks; fate "replaced"
def test_deletion_takes_nested():   # host deleted after a nested insertion: nested fate "deleted" in that lineage
def test_site_lost():               # insertion below an older del_flank covering its target: fate "site_lost"
def test_snp_bases_applied():       # derived sites hold the derived base in carriers only
def test_copy_coordinates_hold_payload():  # seq[start:end] == the copy's payload for every intact copy
def test_lift_pos():                 # positions before and after an insertion, and inside a deletion, map as stated
def test_site_window_ignores_other_insertion():  # another insertion 4 bp from the target in Y: site stays >= 0
def test_backbone_k2p_adds_snps():  # backbone element with source K 0.02 and 3 derived SNPs in one 300-bp LTR:
                                    # k2p > 0.02
def test_gap_rate_and_near_share(): # 1-Mb toy, per_mb=50: 50 gaps; near share within 3 SE of 1/3
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement** `build_chrom` and `add_gaps`.
- [ ] **Step 4: Run.** Expected: PASS; then the suite.
- [ ] **Step 5: Commit:** `"Build simulated genomes in one pass with per-element copy records"`.

---

