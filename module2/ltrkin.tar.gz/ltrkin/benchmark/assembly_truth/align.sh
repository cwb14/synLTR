#!/usr/bin/env bash
# Subsample reads and align them to hap1 and to hap2 separately (sorted, indexed BAMs in <S>/aln/).
# usage: align.sh <S> <map-hifi|map-ont> <keep fraction> <threads> <reads.fastq[.gz]>
# References: data/<S>/<S>_hap1.fa and _hap2.fa (relative to the working directory). Each step resumes.
set -euo pipefail
S=$1; PRESET=$2; FRAC=$3; T=$4; FQ=$(readlink -f "$5")
H1=$(readlink -f data/$S/${S}_hap1.fa); H2=$(readlink -f data/$S/${S}_hap2.fa)
OUT=$S/aln; mkdir -p $OUT; cd $OUT
log() { echo "[$(date +%F' '%T)] $*"; }
minimap2 --version > minimap2.version; samtools --version | head -1 > samtools.version
# 1. subsample (independent Bernoulli per read, fixed seed)
if [[ ! -s reads.fastq.gz ]]; then
  log "subsample $FRAC"
  if [[ $FQ == *.gz ]]; then rd="bgzip -dc -@4 $FQ"; else rd="cat $FQ"; fi
  $rd | awk -v f="$FRAC" 'BEGIN{srand(11)} NR%4==1{k=(rand()<f)} k' | bgzip -@8 -l 3 > reads.fastq.gz.tmp
  mv reads.fastq.gz.tmp reads.fastq.gz
fi
# 2. alignments (secondary off, supplementary kept)
for ref in hap1 hap2; do
  [[ -s $ref.bam.bai ]] && continue
  fa=$H1; [[ $ref == hap2 ]] && fa=$H2
  log "align $ref"
  minimap2 -ax $PRESET --secondary=no -t $T -R "@RG\tID:$S\tSM:$S" $fa reads.fastq.gz 2> $ref.mm2.log \
    | samtools sort -@8 -m 3G -O bam -T $ref.tmp -o $ref.bam.tmp -
  mv $ref.bam.tmp $ref.bam
  samtools index -@8 $ref.bam
  log "done $ref"
done
log "all done"
