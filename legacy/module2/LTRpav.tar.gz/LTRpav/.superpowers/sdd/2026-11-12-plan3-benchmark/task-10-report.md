# Task 10 Step 4: lq/run_lq.sh (written and dry-checked; nothing launched)

Script: `$P/benchmark_pav/plan3/sim/lq/run_lq.sh`. Dry-run output: `sim/lq/dryrun.out`. Layout check: `sim/lq/layout_check.out`.

## Design
- Names run one at a time (default null_s101 null_s102 f0.18_Ta5000_r1). Markers in `lq/<name>/`: layout, inputs, ltrquest, ann, cleanup `.done`, then run_one.sh's own markers and `run.done`, then `lq.done`. A rerun resumes. flock on `lq/.lock`.
- Refuses a source run without `run.done` (dry-run reports it). Refuses to run without `sim/grid.tsv.done` unless `--ignore-grid`.
- Checks the clone `code/LTRquest` is at 5042a1e (it is what the env was installed from) and that `command -v ltrquest` after `conda activate ltrquest_5042a1e` is the env's binary. The PATH `ltrquest` is never called. The conda subshell unsets PYTHONPATH.
- layout: copies `sim.done` (run_one.sh checks it for `--from geno`), symlinks every file of the source `sim/` (FASTAs, .fai, truth/, GFF3s, params.json) except `samples.tsv`. `sim/samples.tsv` has A1 B1 C1 with annotation `lq/<name>/ann/<label>_LTRs`, and O1 with `.`.
- inputs: **deviation from the brief.** A1/B1/C1 all use ids c01..c05, and LTRquest requires ids unique across genomes. So `in/<label>.fa` is the same sequence with ids `<label>_c01` (as the real-data pipeline did), length-checked against the .fai.
- ltrquest: the brief's command, `--threads 32`, `OMP_NUM_THREADS=8`, run as a session leader (`setsid --wait /usr/bin/time -v`). A sampler runs `ps -L -s <sid>` every 10 s into `threads.tsv`; peak LWPs and peak running threads go to `threads_peak.txt`. It samples every run, not only the first. `--threads N` is an option: if the peak is well above 32, rerun with a lower N.
- ann: because the LTRquest seq_ids carry the `<label>_` prefix, `ann/<label>_LTRs_depth*_clean_ltr.tsv` are copies with the prefix removed. This matches the sheet's FASTAs and `truth/`. ltrpav reads a prefix's `*_depth*_clean_ltr.tsv`.
- cleanup: deletes only the six TEsorter scratch patterns inside `*.work`. Then `python -m ltrquest.record check` runs for A1, B1, C1 in the env, with the settings taken from each `.detect.json`. Each must print `reuse`, or the script stops. Output in `record_check.txt`.
- run_one: `./run_one.sh <name> --rundir lq/<name> --from geno --windows 5` (without `--from` on a rerun after geno.done).
- `lq.done` holds the date, commit, threads peak and record-check lines.
- LTRquest detection is not reached in the dry-run, so the ltrquest, ann and cleanup stages are untested: the sampler and the prefix-stripping awk were tested on synthetic data, and the conda activation and `ltrquest.record check --help` were run.

## Eval trigger
`eval_run.py` marks a genome as `coords` when `Path(s.annotation).resolve() != run/sim/<label>.gff3`. The lq sheet's annotation is an LTRquest prefix, so `read_samples` + that test give False for A1, B1, C1. This was run on the built layout. They therefore go through `match_by_coords` at 10 bp.

## Dry-run
`bash lq/run_lq.sh --dry-run`: prints the layout, inputs, ltrquest, ann, cleanup and run_one commands for null_s101 and f0.18_Ta5000_r1. For null_s102 it prints "no run.done: a real run refuses it". It builds only `lq/<name>/sim`, `sim.done` and `ann/` for the two finished runs (the layout is needed for the check), and nothing outside `lq/`.

## Layout check
`./run_one.sh null_s101 --rundir lq/null_s101 --from geno --windows 5 --dry-run` exits 0 and prints geno, views, ltrmix and eval. The first attempt failed because `sim.done` was missing at the run root. The script now copies it.

## Controller, after `grid.tsv.done`
```
cd /data2/chris/maize_introgression/benchmark_pav/plan3/sim
setsid -f nohup bash lq/run_lq.sh > lq/run_lq.log 2>&1 < /dev/null
pgrep -af run_lq.sh; ps -o pid,ppid,sid,cmd -p <pid>     # SID == PID, PPID 1
```
Afterwards check `lq/<name>/threads_peak.txt`, `record_check.txt`, `lq.done`, `eval/`.

## Concerns
- run_one.sh's ltrmix step builds its libraries from the truth GFF3s (`sim/*.gff3` links), not from the LTRquest prefixes. So LTRmix and eval_ltrmix results in `lq/` repeat the grid's, and only geno, the views and eval_run test LTRquest. Its cost is small.
- `eval_run.py` still reads `sim/<label>.gff3` for the truth elements of annotated genomes, so the symlinks are needed.
- The ltrquest, ann and cleanup stages and the `record check` settings plumbing run for the first time on the real data.

## Update: LTRmix on the LTRquest annotations (controller ruling)
- run_lq.sh now runs per name: `run_one.sh --from geno --until views --windows 5`; its own ltrmix step; `run_one.sh --from eval --windows 5`.
- LTRmix form: `ltrmix.py --genome A1=<lq>/ann/A1_LTRs --genome B1=... --genome C1=... --outdir ltrmix -t 8 --no-figure` (LTRmix/README.md line 30 and ltrmix.py's `--genome LABEL=LIB`; the README example passes `run/B73v5_LTRs` prefixes). It reads `PREFIX_depth*_clean_ltr.{fa,tsv}`, so the ann step now strips the `<label>_` id prefix from the .fa headers too, not only the tsv.
- rate_free_split (kind null) uses the same prefixes as `--donor/--sister/--recipient`; exit status goes to rate_free_split.exit. ltrmix.time covers ltrmix.py; rate_free_split has ltrmix.rfs.time. ltrmix.done is written after success.
- eval_ltrmix.py's record_names already joins by coordinates (match_by_coords, 10 bp) when a library record is not a GFF3 element, so it reads these outputs.
- NOT verified: the dry-run of the new chain was refused by the permission classifier after the edit (`bash -n` passes). It has to be rerun.
