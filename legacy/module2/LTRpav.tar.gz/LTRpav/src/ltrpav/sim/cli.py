"""`ltrpav-sim pop`: a population of genomes evolved on real backbone regions, with the truth of every annotated
genome's elements in every other genome (ltrpav.sim.pop). `ltrpav-sim score`: one ordered pair's calls against
truth. Exit status as for ltrpav: 0 done; 1 a handled error, one line
"error: <message>" on stderr; 2 a usage error."""
from __future__ import annotations

import argparse
import csv
import logging
import math
import re
import textwrap
import time
from dataclasses import replace
from pathlib import Path

from .. import __version__
from ..cli import _execute, positive_int
from ..constants import WINDOW_PAD
from .donors import MAX_DONORS
from .pop import CACHE, MAX_CHROMS, MAX_SEED, PopParams, check_outdir, check_regions, simulate_pop, write_pop
from .popmodel import PULSES, Demog, Rates, demog_from_json
from .score import CONFUSION_COLUMNS, SCORE_COLUMNS, confusion, score

log = logging.getLogger("ltrpav.sim")

_REGION = re.compile(r"^(?P<seqid>.+):(?P<start>[0-9][0-9,]*)-(?P<end>[0-9][0-9,]*)$")
_DEMOG, _RATES = Demog(), Rates()  # the defaults the pop options and epilog name


class _Lines(argparse.HelpFormatter):
    """Keeps a description's or epilog's line breaks and fills each line to the width on its own; an indented line
    ("  label  text") continues under its text."""

    def _fill_text(self, text: str, width: int, indent: str) -> str:
        out = []
        for line in text.splitlines():
            label = re.match(r" +\S+ +", line)
            out.append(textwrap.fill(line, width, initial_indent=indent, break_on_hyphens=False,
                                     subsequent_indent=indent + " " * (label.end() if label else 0)))
        return "\n".join(out)


def _show(*names: str, of=_DEMOG) -> str:
    """Each field with its default, as the --demography JSON writes it: a number, [a list] or none (null)."""
    def value(v) -> str:
        if v is None:
            return "none"
        if isinstance(v, tuple):
            return f"[{', '.join(f'{x:g}' for x in v)}]"
        return v if isinstance(v, str) else f"{v:g}"
    return ", ".join(f"{n} {value(getattr(of, n))}" for n in names)


_POP_EPILOG = "\n".join([
    ("defaults: the demography and rates below, small indels at mu/10, and three values measured on real "
     "genomes: t_o from their outgroup conflict, loss_split and replace_mean from their element "
     "losses. A --demography JSON object sets any of these fields by name (a list as a JSON array, none as null)."),
    (f"  Ne          diploid effective sizes: {_show('ne_a', 'ne_b', 'ne_c')}, {_show('ne_bc')} (the ancestor of B "
     f"and C), {_show('ne_o')}, {_show('ne_root')} (the ancestor of BC and O)"),
    (f"  splits      generations ago: {_show('t_ab')} (A from B), {_show('t_bc')} (B from C), {_show('t_o')} "
     "(O from BC)"),
    (f"  pulse       {_show('f')} (the share of the recipient's lineages it moves), {_show('ta')} generations ago, "
     f"{_show('pulse')} (donor>recipient); {_show('per_taxon')} genomes per taxon"),
    (f"  lineages    {_show('sub_a', 'sub_c')}, else [split generations, Ne] of A1's or C1's own population: pulse "
     "C>A1 needs sub_a, C1>A1 and A1>C1 need sub_a and sub_c, and ta must lie below their splits when f > 0"),
    f"  bottleneck  {_show('bottleneck')}, else [Ne, generations] of A right after its split from B",
    (f"  rates       per generation: {_show('mu', of=_RATES)} substitutions per bp; {_show('r', of=_RATES)} and "
     f"{_show('r_low', of=_RATES)} crossovers per bp, r_low between the fractions {_show('low', of=_RATES)} of "
     f"each region; {_show('lam', of=_RATES)} insertions per bp; {_show('delta', of=_RATES)} (1/{1 / _RATES.delta:g}) "
     f"losses per element; {_show('indel', of=_RATES)} small indels per bp; {_show('copy_noise', of=_RATES)} "
     "substitutions per base of a new copy"),
    (f"  losses      {_show('loss_split', of=_RATES)}, the shares of solo, del_flank, del_partial and replace; "
     f"{_show('replace_mean', of=_RATES)}, the mean replacement length in bp"),
    "",
    ("truth/insertions.tsv: pos is 0-based, as in BED: the copy goes before base pos of its chromosome's backbone "
     "(0 at its region's START) when host is \".\", else of its host insertion's donor body, so pos is a coordinate "
     "of no output genome; time is in generations ago."),
    "params.json lists the simplifications the simulation makes.",
])


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="ltrpav-sim",
                                     description="Simulate genomes with known LTR-RT truth.")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True, metavar="COMMAND")
    p = sub.add_parser(
        "pop", help="a population of genomes evolved on real backbone regions, with truth",
        formatter_class=_Lines, epilog=_POP_EPILOG,
        description="Evolve haploid genomes A1..An, B1..Bn, C1..Cn (n = --per-taxon) and the outgroup O1 on real "
                    "backbone regions, each region one chromosome (c01, c02, ...) with its annotated elements: an "
                    "msprime genealogy per chromosome (taxa A, B and C, outgroup O, a pulse of gene flow), LTR-RT "
                    "insertions of annotated donors (nested up to two deep), solo-LTRs, flank and partial "
                    "deletions, replacements, SNPs, small indels and assembly gaps. Writes <label>.fa, "
                    "<label>.gff3 for A, B and C (dropout, jitter), samples.tsv (ready for ltrpav), truth/ "
                    "(<X>__<Y>.tsv for every annotated X and other Y, insertions.tsv, tracts.<label>.bed of the "
                    "recipient taxon, fractions.tsv) and params.json.")
    p.add_argument("--fasta", required=True, type=Path, metavar="FA", help="FASTA holding the backbone regions")
    p.add_argument("--region", required=True, action="append", metavar="SEQ:START-END",
                   help="a backbone region, 1-based inclusive; repeat it for more chromosomes (disjoint, at most "
                        f"{MAX_CHROMS}, each at least 2 x {WINDOW_PAD} bp plus the longest donor)")
    p.add_argument("--annotation", required=True, metavar="ANNOT",
                   help="the FASTA's LTR-RT annotation (GFF3, BED or LTRquest prefix): the backbone elements (those "
                        f"wholly inside a region) and up to {MAX_DONORS} donors (top-level, childless, "
                        "high-confidence where the annotation rates confidence)")
    p.add_argument("--outdir", required=True, type=Path, metavar="DIR",
                   help=f"output directory: new, or empty but for its own FASTA index cache {CACHE}/")
    p.add_argument("--demography", type=Path, metavar="FILE.json",
                   help="a JSON object of population (Demog) and rate (Rates) fields; a field left out keeps its "
                        "default, and the options below override the file")
    p.add_argument("--seed", type=_seed, default=1, metavar="N", help=f"random seed, 0 to {MAX_SEED} (default: 1)")
    p.add_argument("--f", type=_real, metavar="F",
                   help=f"fraction of the recipient's lineages the pulse moves (default: {_DEMOG.f:g}, "
                        "no gene flow)")
    p.add_argument("--ta", type=_real, metavar="GEN", help=f"pulse time, generations ago (default: {_DEMOG.ta:g})")
    p.add_argument("--pulse", choices=list(PULSES), metavar="CODE",
                   help=f"donor>recipient: {', '.join(PULSES)} (A1, C1: their own lineage populations; default: "
                        f"{_DEMOG.pulse})")
    p.add_argument("--per-taxon", type=positive_int, metavar="N",
                   help=f"genomes of each of A, B and C (default: {_DEMOG.per_taxon})")
    p.add_argument("--bottleneck", type=_ne_gen, metavar="NE,GEN",
                   help="A at effective size NE for GEN generations right after its split from B (default: none)")
    p.add_argument("--dropout", type=_below_one, default=0.1, metavar="X",
                   help="chance an alive element is missing from its genome's annotation, in [0, 1) (default: 0.1)")
    p.add_argument("--dropout-genome", type=_genome_dropout, action="extend", nargs="+", default=[],
                   metavar="LABEL=X", help="an annotated genome's own dropout, in place of --dropout")
    p.add_argument("--jitter", type=_unit, default=0.05, metavar="X",
                   help="chance an annotated element's ends move by up to 3 bp, in [0, 1] (default: 0.05)")
    p.add_argument("--threads", type=positive_int, default=1, metavar="N",
                   help="worker processes, one chromosome each (default: 1); the outputs do not depend on it")
    p.add_argument("-v", "--verbose", action="store_true", help="debug log; tracebacks on errors")
    p.set_defaults(func=_pop)
    s = sub.add_parser(
        "score", help="score one ordered pair's calls against its truth file",
        description="Score `ltrpav run`'s calls for X in Y against the simulator's truth: per-state and "
                    "present/absent precision and recall (all calls and high tier), flag agreement, summary "
                    "fractions, and a truth-by-call confusion table. Writes PREFIX.score.tsv and "
                    "PREFIX.confusion.tsv.")
    s.add_argument("--calls", required=True, type=Path, metavar="FILE",
                   help="<outdir>/pairs/<X>__<Y>.calls.tsv.gz (or plain TSV)")
    s.add_argument("--elements", required=True, type=Path, metavar="FILE",
                   help="X's elements, <outdir>/work/elements/<X>.tsv")
    s.add_argument("--truth", required=True, type=Path, metavar="FILE",
                   help="the simulation's truth/<X>__<Y>.tsv, for the same ordered pair X, Y")
    s.add_argument("--out", required=True, type=Path, metavar="PREFIX", help="output prefix")
    s.add_argument("-v", "--verbose", action="store_true", help="debug log; tracebacks on errors")
    s.set_defaults(func=_score)
    return _execute(parser, argv, "ltrpav-sim", lambda a, c: a.func(a, c))


def _seed(text: str) -> int:
    try:
        n = int(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"not an integer: {text!r}") from None
    if not 0 <= n <= MAX_SEED:
        raise argparse.ArgumentTypeError(f"must be in [0, {MAX_SEED}] (one 32-bit word): {n}")
    return n


def _real(text: str) -> float:
    try:
        v = float(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"not a number: {text!r}") from None
    if not math.isfinite(v):
        raise argparse.ArgumentTypeError(f"not a finite number: {text!r}")
    return v


def _ne_gen(text: str) -> tuple[float, float]:
    parts = text.split(",")
    if len(parts) != 2:
        raise argparse.ArgumentTypeError(f"expected NE,GEN: {text!r}")
    return _real(parts[0]), _real(parts[1])


def _below_one(text: str) -> float:
    v = _real(text)
    if not 0 <= v < 1:
        raise argparse.ArgumentTypeError(f"must be in [0, 1): {text!r}")
    return v


def _unit(text: str) -> float:
    v = _real(text)
    if not 0 <= v <= 1:
        raise argparse.ArgumentTypeError(f"must be in [0, 1]: {text!r}")
    return v


def _genome_dropout(text: str) -> tuple[str, float]:
    label, eq, value = text.partition("=")
    if not eq or not label:
        raise argparse.ArgumentTypeError(f"expected LABEL=X: {text!r}")
    try:
        return label, _below_one(value)
    except argparse.ArgumentTypeError as e:
        raise argparse.ArgumentTypeError(f"{label}: {e}") from None


def _parse_region(text: str) -> tuple[str, int, int]:
    """(seqid, start, end) of SEQ:START-END, 1-based inclusive (not yet checked against a FASTA)."""
    m = _REGION.match(text)
    if not m:
        raise ValueError(f"bad region {text!r}: expected SEQ:START-END (1-based inclusive)")
    return m["seqid"], int(m["start"].replace(",", "")), int(m["end"].replace(",", ""))


def _pop(args: argparse.Namespace, command: list[str]) -> None:
    t0 = time.perf_counter()
    demog, rates = demog_from_json(args.demography) if args.demography is not None else (Demog(), Rates())
    given = {"f": args.f, "ta": args.ta, "pulse": args.pulse, "per_taxon": args.per_taxon,
             "bottleneck": args.bottleneck}
    demog = replace(demog, **{k: v for k, v in given.items() if v is not None})  # Demog checks the combination
    params = PopParams(demog, rates, dropout=args.dropout, jitter=args.jitter,
                       dropout_genome=tuple(args.dropout_genome))
    regions = [_parse_region(r) for r in args.region]
    check_regions(regions)
    check_outdir(args.outdir)  # before anything is simulated; write_pop checks again
    result = simulate_pop(regions, args.fasta, args.annotation, params, args.seed, args.threads,
                          cache_dir=args.outdir / CACHE)
    write_pop(args.outdir, result)
    log.info("done in %.1f s -> %s", time.perf_counter() - t0, args.outdir)


def _cell(v) -> str:
    return "NA" if v is None else f"{v:.4f}" if isinstance(v, float) else str(v)


def _write(path: Path, columns: tuple[str, ...], rows: list[dict]) -> None:
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh, delimiter="\t", lineterminator="\n")
        w.writerow(columns)
        w.writerows([_cell(r[c]) for c in columns] for r in rows)


def _score(args: argparse.Namespace, command: list[str]) -> None:
    log.info("ltrpav-sim score: %s against %s", args.calls, args.truth)
    paths = (args.calls, args.elements, args.truth)
    rows, conf = score(*paths), confusion(*paths)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    _write(Path(f"{args.out}.score.tsv"), SCORE_COLUMNS, rows)
    _write(Path(f"{args.out}.confusion.tsv"), CONFUSION_COLUMNS, conf)
    log.info("done -> %s.score.tsv, %s.confusion.tsv", args.out, args.out)
