#!/usr/bin/env bash
# Wait until whole-server CPU use is below THRESH busy threads, then run the real ltrquest job.
# Busy threads = ncpu * (non-idle jiffies / all jiffies) over a 60 s window, from /proc/stat; iowait counts
# as idle. The 60 s average is the only smoothing (NEED=1), matching the request "once it drops below 100". No timeout.
set -u
HERE=$(dirname "$(readlink -f "$0")")
. "$HERE/run.env"
THRESH=100; NEED=1; WIN=60
S=$PROJECT/state; R=$PROJECT/run; L=$PROJECT/logs; mkdir -p "$S" "$R" "$L"
ev() { echo "$(date '+%F %T') $*" >> "$L/events.log"; }
[[ -e $S/job.started ]] && { ev "LAUNCHER_ABORT job already started; remove state/job.started to rerun"; exit 1; }
echo $$ > "$S/launcher.pid"
NCPU=$(grep -c ^processor /proc/cpuinfo)
sample() { awk '/^cpu /{print $2+$3+$4+$7+$8+$9, $2+$3+$4+$5+$6+$7+$8+$9; exit}' /proc/stat; }
ev "WATCHER_START threshold=<$THRESH busy threads of $NCPU, $NEED consecutive ${WIN}s windows"
read -r b0 t0 < <(sample); n=0; warned=0
while :; do
  sleep "$WIN"
  read -r b1 t1 < <(sample)
  busy=$(awk -v b=$((b1-b0)) -v t=$((t1-t0)) -v c="$NCPU" 'BEGIN{printf "%.0f", (t>0)?c*b/t:c}')
  b0=$b1; t0=$t1
  if (( busy < THRESH )); then n=$((n+1)); else n=0; fi
  echo "$(date '+%F %T') busy_threads=$busy consecutive_below=$n" > "$S/cpu_now"
  echo -e "$(date '+%F %T')\t$busy\t$(cut -d' ' -f1 /proc/loadavg)" >> "$L/cpu_samples.tsv"
  (( n == 1 )) && ev "BELOW_THRESHOLD busy_threads=$busy (window 1 of $NEED)"
  if (( n >= NEED )); then
    . "$HERE/run.env"                       # pick up a re-pin made while waiting
    [[ -e $S/preflight_ok.$COMMIT ]] && break
    (( warned )) || { ev "THRESHOLD_MET_NO_PREFLIGHT holding: state/preflight_ok.$COMMIT absent"; warned=1; }
  fi
done
activate
head=$(timeout 30 git ls-remote https://github.com/cwb14/LTRquest.git HEAD 2>/dev/null | cut -c1-7)
[[ $head == "$COMMIT" ]] || ev "HEAD_CHECK origin=${head:-unreachable} pinned=$COMMIT (running the pinned, preflighted build)"
touch "$S/job.started"; cd "$R" || { ev "LAUNCH_FAIL cannot cd $R"; exit 1; }
ev "LAUNCH busy_threads=$busy commit=$COMMIT threads=120 MemAvailable_GB=$(awk '/MemAvailable/{printf "%.0f",$2/1048576}' /proc/meminfo)"
rc=0
/usr/bin/time -v -o "$L/time.txt" ltrquest \
  --genome "$PROJECT/inputs/B73v5.fa" "$PROJECT/inputs/TIL18.fa" "$PROJECT/inputs/TIL01.fa" \
  --proteins "$PROJECT/inputs/B73v5.proteins.fa.gz" \
  --threads 120 "${EXTRA_FLAGS[@]}" > ltrquest.log 2>&1 || rc=$?
echo "$rc" > "$S/job.exit"
ev "JOB_EXIT rc=$rc"
