"""Direction of transfer, exploratory: n(X->Y), DFOIL-alt and the 4-LIST pattern counts between
taxa (sheet groups with at least two ingroup genomes each).

Skipped, with one findings line naming the reason, without an outgroup ("skipped: no outgroup") or without
two taxa of at least two genomes ("skipped: needs two genomes per taxon"). A run with one genome per
taxon skips it.

For each pair of taxa X, Y (order of first sheet appearance), Z = the ingroup genomes outside X and Y:
  n(X->Y), n(Y->X), D_dir  merged states (any discovery). Counted loci: every genome of X, Y, Z and the
        outgroups resolved, Z and the outgroups all E. n(X->Y): all X present, some but not all Y present;
        n(Y->X) the mirror; D_dir = (n(X->Y) - n(Y->X)) / sum. Strata: all, and the age bins of the median
        member K. Jackknife over the counted loci, blocks on the first X+Y genome's merged coordinates (the
        next genome with coordinates where it has none). D_dir is not a direction statistic: with taxa of
        unequal Ne it has a non-zero null, so it is reported with that caveat.
  DFOIL-alt  per quartet (two genomes of X, two of Y; P1, P2 the pair with the smaller PAV distance, DFOIL
        needs the more recent split there). Each statistic reads the left/right pattern pairs of `DFOIL_ALT`;
        a pair's patterns are read from the calls of the first genome of `PAIR_DISC` that is a member at the
        row (the pair's discoverer), on rows where that genome's calls resolve the quartet, Z and the
        outgroups, with Z and the outgroups E. Jackknife on P1's site as the row's first quartet member
        reads it (`proj_site`; one block id per row even where two pairs have different discoverers).
        Signature: `signature` of the four Z values; a nan Z (an empty class, or loci in fewer than
        JK_MIN_BLOCKS blocks) gives "none" in the row, never a direction.
  4-LIST     the ten patterns with two or three of the four present, merged states, on the loci resolved in
        the quartet, Z and the outgroups with Z and the outgroups E.
Every row's note, and the section's first findings line, say it is not validated by simulation: a simulated
positive control did not confirm it. Findings go in the section "Direction (exploratory)".
"""
from __future__ import annotations

import itertools
import math

import numpy as np

from . import common
from .catalog import AGE_LABELS, Catalog, age_bin
from .constants import Z_SIG
from .stats import Findings, StatRow, block_ids, d_ratio, jackknife, resolution
from .trio import NOT_TESTABLE

SECTION = "Direction (exploratory)"
NOTE = "not validated by simulation"   # a simulated positive control did not confirm it
DDIR_NOTE = ("not read as direction: unequal Ne alone drives it without gene flow, and "
             "drift in a small recipient fixes transferred insertions. DFOIL-alt is the direction statistic.")
FOUR_LIST_NOTE = ("three present genomes nearly saturate discovery")
STATS = ("DFO", "DIL", "DFI", "DOL")
FOUR_LIST = ("1100", "1010", "1001", "0110", "0101", "0011", "1110", "1101", "1011", "0111")

DFOIL_ALT = {   # (left, right) patterns: presence in P1 P2 P3 P4, outgroup absent. Pease & Hahn 2015; dfoil.py weights,
                # single-derived (terminal) patterns dropped (DFOIL-alt)
    "DFO": (("1010", "1110", "0101"), ("1001", "1101", "0110")),
    "DIL": (("0110", "1001", "1110"), ("0101", "1010", "1101")),
    "DFI": (("1010", "1011", "0101"), ("0110", "0111", "1001")),
    "DOL": (("0110", "1001", "1011"), ("0101", "0111", "1010")),
}
DFOIL_ALT_SIGNS = {   # DFOIL-alt codes over DFO DIL DFI DOL: infinite-sites expectations without the single-derived
                      # patterns (tests/test_direction.py checks each code against branch-length
                      # expectations). Each directional entry has one branch-length slot:
                      # deep root (Troot - T12 > T12 - t, Troot - T34 > T34 - t) gives the first code, a non-significant
                      # slot the second, the opposite sign one of the two ambiguous classes at the end.
    "+++-": "P1=>P3", "+0+-": "P1=>P3", "---+": "P1=>P4", "-0-+": "P1=>P4",
    "++-+": "P2=>P3", "0+-+": "P2=>P3", "--+-": "P2=>P4", "0-+-": "P2=>P4",
    "+-++": "P3=>P1", "+-+0": "P3=>P1", "-+++": "P4=>P1", "-+0+": "P4=>P1",
    "-+--": "P3=>P2", "-+-0": "P3=>P2", "+---": "P4=>P2", "+-0-": "P4=>P2",
    "++00": "P1+P2<=>P3", "--00": "P1+P2<=>P4",
    "+-+-": "P1<=>P3 or P2<=>P4 (direction unresolved)", "-+-+": "P1<=>P4 or P2<=>P3 (direction unresolved)",
}
PAIR_DISC = {   # each left|right pattern pair: genomes present in both patterns that may discover it, in order of use
    "DFO": {("1010", "1001"): ("P1",), ("1110", "1101"): ("P1", "P2"), ("0101", "0110"): ("P2",)},
    "DIL": {("0110", "0101"): ("P2",), ("1110", "1101"): ("P1", "P2"), ("1001", "1010"): ("P1",)},
    "DFI": {("1010", "0110"): ("P3",), ("1011", "0111"): ("P3", "P4"), ("0101", "1001"): ("P4",)},
    "DOL": {("1001", "0101"): ("P4",), ("1011", "0111"): ("P3", "P4"), ("0110", "1010"): ("P3",)},
}


def taxa(cat: Catalog) -> dict[str, tuple[str, ...]]:
    """group -> its ingroup genomes (sheet order), the groups with at least two genomes, in order of first
    sheet appearance. Genomes without a group belong to none."""
    out: dict[str, list[str]] = {}
    for g in cat.ingroup:
        grp = cat.groups[g]
        if grp is not None:
            out.setdefault(grp, []).append(g)
    return {k: tuple(v) for k, v in out.items() if len(v) >= 2}


def signature(z: dict[str, float]) -> str:
    """Sign code over DFO DIL DFI DOL: "+" / "-" when |z| >= Z_SIG, else "0" (nan too); the DFOIL_ALT_SIGNS
    label, else "none"."""
    code = "".join("+" if v >= Z_SIG else "-" if v <= -Z_SIG else "0" for v in (z[s] for s in STATS))
    return DFOIL_ALT_SIGNS.get(code, "none")


def _pair_masks(cat: Catalog, quartet: tuple[str, str, str, str], z: tuple[str, ...]
                ) -> dict[str, dict[str, np.ndarray]]:
    """statistic -> pattern -> (n,) bool: the rows each pattern is counted at, by its pair's discoverer rule."""
    absent = (*z, *cat.outgroups)
    cache: dict[tuple[str, ...], tuple[np.ndarray, np.ndarray]] = {}
    out: dict[str, dict[str, np.ndarray]] = {}
    for stat, pairs in PAIR_DISC.items():
        out[stat] = {}
        for (left, right), disc in pairs.items():
            if disc not in cache:
                gstar = common.first_member(cat, [quartet[int(p[1]) - 1] for p in disc])
                ok = gstar >= 0
                code = np.zeros(len(cat.lid), dtype=np.int8)
                for q in quartet:
                    pc = cat.pcls_by(gstar, q)
                    ok &= pc >= 0
                    code = code * 2 + (pc == 1)
                for w in absent:
                    ok &= cat.pcls_by(gstar, w) == 0
                cache[disc] = (ok, code)
            ok, code = cache[disc]
            for pat in (left, right):
                out[stat][pat] = ok & (code == int(pat, 2))
    return out


def direction(cat: Catalog, size: int, dist: np.ndarray) -> tuple[list[StatRow], Findings]:
    """Direction rows (module docstring) and findings; ([], findings) when skipped."""
    f = Findings()
    if not cat.outgroups:
        f.add(SECTION, "direction skipped: no outgroup (n(X->Y) and DFOIL-alt need the ancestral state)")
        return [], f
    tx = taxa(cat)
    if len(tx) < 2:
        f.add(SECTION, "direction skipped: needs two genomes per taxon, in at least two taxa (groups with "
                       f"two or more ingroup genomes: {', '.join(tx) or 'none'})")
        return [], f
    f.add(SECTION, f"direction is exploratory: {NOTE}")
    rows: list[StatRow] = []
    for (xn, xs), (yn, ys) in itertools.combinations(tx.items(), 2):
        z = tuple(g for g in cat.ingroup if g not in xs and g not in ys)
        rows += _n_xy(cat, xn, xs, yn, ys, z, size, f)
        for qx in itertools.combinations(xs, 2):
            for qy in itertools.combinations(ys, 2):
                dx, dy = dist[cat.g(qx[0]), cat.g(qx[1])], dist[cat.g(qy[0]), cat.g(qy[1])]
                swap = math.isfinite(dy) and (not math.isfinite(dx) or dy < dx)
                a, b = (qy, qx) if swap else (qx, qy)
                rows += _dfoil(cat, (*a, *b), z, size, f)
    for r in rows:
        r.note = NOTE if r.note in (".", "") else f"{NOTE}; {r.note}"
    return rows, f


def _absent_ok(cat: Catalog, z: tuple[str, ...]) -> np.ndarray:
    """(n,) bool, merged states: z and every outgroup resolved and E."""
    ok = np.ones(len(cat.lid), dtype=bool)
    for w in (*z, *cat.outgroups):
        ok &= cat.cls(w) == 0
    return ok


def _first_coords(cat: Catalog, genomes: tuple[str, ...]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """(seq, mid, genome): the first of `genomes` with merged coordinates at each row, and that genome's index
    (-1 where none has any)."""
    seq = np.full(len(cat.lid), -1, dtype=np.int64)
    mid = np.full(len(cat.lid), np.nan)
    src = np.full(len(cat.lid), -1, dtype=np.int64)
    for g in genomes:
        take = (seq < 0) & (cat.seq[:, cat.g(g)] >= 0)
        seq[take] = cat.seq[take, cat.g(g)]
        mid[take] = cat.mid(g)[take]
        src[take] = cat.g(g)
    return seq, mid, src


def coord_blocks(genome: np.ndarray, seq: np.ndarray, mid: np.ndarray, size: int) -> np.ndarray:
    """Jackknife block ids for rows read in different genomes' coordinates (a fallback where the first genome has
    no site): one id per (genome, sequence, mid // size), so two genomes' sequences of the same fai index never
    share a block. Dense int64 ids, in (genome, block_ids) order."""
    key = np.stack([np.asarray(genome, dtype=np.int64), block_ids(seq, mid, size)], axis=1)
    if not len(key):
        return np.zeros(0, dtype=np.int64)
    return np.unique(key, axis=0, return_inverse=True)[1].astype(np.int64).ravel()


def _median_k(cat: Catalog, genomes: tuple[str, ...]) -> np.ndarray:
    """(n,) the median over `genomes` of the member K2P (cat.k, nan where not a member or no K); nan if none."""
    k = np.sort(cat.k[:, [cat.g(g) for g in genomes]], axis=1)   # nan sorts last
    cnt = np.isfinite(k).sum(axis=1)
    idx = np.arange(len(k))
    lo, hi = np.maximum(cnt - 1, 0) // 2, np.maximum(cnt, 1) // 2
    med = (k[idx, lo] + k[idx, hi]) / 2
    return np.where(cnt > 0, med, np.nan)


def _n_xy(cat: Catalog, xn: str, xs: tuple[str, ...], yn: str, ys: tuple[str, ...], z: tuple[str, ...],
          size: int, f: Findings) -> list[StatRow]:
    scope = f"{xn}>{yn}"
    genomes = (*xs, *ys)
    res = np.ones(len(cat.lid), dtype=bool)
    for w in (*genomes, *z, *cat.outgroups):
        res &= cat.cls(w) >= 0
    rows = res & _absent_ok(cat, z)
    nx = sum((cat.cls(g) == 1).astype(int) for g in xs)
    ny = sum((cat.cls(g) == 1).astype(int) for g in ys)
    a = (nx == len(xs)) & (ny >= 1) & (ny <= len(ys) - 1)
    b = (ny == len(ys)) & (nx >= 1) & (nx <= len(xs) - 1)
    seq, mid, src = _first_coords(cat, genomes)
    loci = (f"disc=any;present={'+'.join(xs)}|{'+'.join(ys)};res={','.join((*genomes, *z, *cat.outgroups))};"
            f"outgroup=E;merged states")
    age = age_bin(_median_k(cat, genomes))
    strata = [("all", rows)]
    if (rows & (age >= 0)).any():
        strata += [(lab, rows & (age == i)) for i, lab in enumerate(AGE_LABELS) if (rows & (age == i)).any()]
    else:
        f.add(SECTION, f"n({xn}->{yn}) age strata skipped: no K2P")
    out: list[StatRow] = []
    for name, keep in strata:
        n_xy, n_yx = int(np.count_nonzero(a & keep)), int(np.count_nonzero(b & keep))
        if (seq[keep] < 0).any():
            raise ValueError(f"direction: {np.count_nonzero(seq[keep] < 0)} counted locus/loci have no site in "
                             f"any genome of {xn} or {yn}")
        blocks = coord_blocks(src[keep], seq[keep], mid[keep], size)
        inf = (a | b)[keep]
        why = common.why({f"n({xn}->{yn})": n_xy, f"n({yn}->{xn})": n_yx}, blocks[inf])
        jk, why = common.guard(jackknife(d_ratio(a[keep], b[keep]), blocks), why)
        text = f"{jk.nblocks} jackknife blocks of {size:,} bp on {genomes[0]}'s sites"
        if why:
            text += f"; {NOT_TESTABLE}: {why}"
        n_all = int(np.count_nonzero(keep))
        out += [StatRow("pav", "direction", scope, name, "D_dir", jk.est, jk.se, jk.z, n=n_xy + n_yx, loci=loci,
                        note=f"{DDIR_NOTE}; {text}"),
                StatRow("pav", "direction", scope, name, "n_XY", n_xy, n=n_all, loci=loci,
                        note=f"all {xn} present, some but not all {yn} present"),
                StatRow("pav", "direction", scope, name, "n_YX", n_yx, n=n_all, loci=loci,
                        note=f"all {yn} present, some but not all {xn} present")]
        if name == "all":
            val = ("not testable: " + why) if why else (f"Z {common.fmt(jk.z, '.2f')}")
            f.add(SECTION, f"D_dir({scope}) = {common.fmt(jk.est, '+.4f')} ({val}): n({xn}->{yn}) {n_xy}, "
                           f"n({yn}->{xn}) {n_yx}, merged states. {DDIR_NOTE}")
    present = np.zeros(len(cat.lid), dtype=bool)
    for g in genomes:
        present |= cat.cls(g) == 1
    n_pres = int(np.count_nonzero(present))
    if n_pres:
        fr = {g: int(np.count_nonzero(present & (cat.cls(g) >= 0))) / n_pres
              for g in (*genomes, *z, *cat.outgroups)}
        out += resolution("resolution", scope, fr, n_pres, f"disc=any;present=any of {','.join(genomes)};merged "
                          "states", f, SECTION)
    return out


def _dfoil(cat: Catalog, quartet: tuple[str, str, str, str], z: tuple[str, ...], size: int, f: Findings
           ) -> list[StatRow]:
    scope = f"{quartet[0]},{quartet[1]};{quartet[2]},{quartet[3]}"
    masks = _pair_masks(cat, quartet, z)
    gb = common.first_member(cat, quartet)
    seq, mid = cat.proj_site(gb, quartet[0])
    src = np.where(seq >= 0, cat.g(quartet[0]), -1)
    for q in quartet[1:]:   # no P1 site in the call: the next quartet genome's site there
        miss = seq < 0
        if not miss.any():
            break
        s2, m2 = cat.proj_site(gb, q)
        seq, mid = np.where(miss, s2, seq), np.where(miss, m2, mid)
        src = np.where(miss & (s2 >= 0), cat.g(q), src)
    loci = f"disc=per pair (PAIR_DISC);res={','.join((*quartet, *z, *cat.outgroups))};outgroup=E"
    rows: list[StatRow] = []
    zs: dict[str, float] = {}
    for stat in STATS:
        left, right = DFOIL_ALT[stat]
        a = sum(masks[stat][p].astype(np.int64) for p in left)
        b = sum(masks[stat][p].astype(np.int64) for p in right)
        inf = (a + b) > 0
        lost = inf & (seq < 0)
        if lost.any():   # no quartet genome has a site: out of the jackknife (and of its estimate)
            f.add(SECTION, f"DFOIL-alt ({scope}) {stat}: {int(np.count_nonzero(lost))} informative loci have "
                           "no site in any quartet genome's call and are dropped")
            a, b, inf = np.where(lost, 0, a), np.where(lost, 0, b), inf & ~lost
        blocks = coord_blocks(src[inf], seq[inf], mid[inf], size)
        na, nb = int(a.sum()), int(b.sum())
        why = common.why({f"{stat} left": na, f"{stat} right": nb}, blocks)
        jk, why = common.guard(jackknife(d_ratio(a[inf], b[inf]), blocks), why)
        zs[stat] = jk.z
        text = f"{jk.nblocks} jackknife blocks of {size:,} bp on {quartet[0]}'s sites; left {na}, right {nb}"
        if why:
            text += f"; {NOT_TESTABLE}: {why}"
        rows.append(StatRow("pav", "dfoil", scope, "all", stat, jk.est, jk.se, jk.z, n=na + nb, loci=loci,
                            note=text))
    sig = signature(zs)
    bad = [s for s in STATS if math.isnan(zs[s])]
    if bad:
        note = f"{NOT_TESTABLE} for {', '.join(bad)}; no direction named"
        sig = "none"
    else:
        note = "DFOIL-alt sign code " + "".join("+" if zs[s] >= Z_SIG else "-" if zs[s] <= -Z_SIG else "0"
                                                  for s in STATS)
    rows.append(StatRow("pav", "dfoil", scope, "all", "signature", sig, loci=loci, note=note))
    f.add(SECTION, f"DFOIL-alt ({scope}): "
          + ", ".join(f"{s} {common.fmt(r.value, '+.3f')} (Z {common.fmt(r.z, '.2f')})" for s, r in zip(STATS, rows))
          + f"; signature {sig}")
    cand = gb >= 0
    for w in (*z, *cat.outgroups):
        cand &= cat.pcls_by(gb, w) == 0
    n_c = int(np.count_nonzero(cand))
    if n_c:
        fr = {q: int(np.count_nonzero(cand & (cat.pcls_by(gb, q) >= 0))) / n_c for q in quartet}
        rows += resolution("resolution", scope, fr, n_c, "disc=first quartet member;outgroup=E", f, SECTION)
        for r in rows[-len(fr):]:
            r.note = "read in the first quartet member's calls (not each pair's discoverer)"
    # 4-LIST: merged states, Z and the outgroups E
    ok = _absent_ok(cat, z)
    code = np.zeros(len(cat.lid), dtype=np.int8)
    for q in quartet:
        c = cat.cls(q)
        ok &= c >= 0
        code = code * 2 + (c == 1)
    counts = {p: int(np.count_nonzero(ok & (code == int(p, 2)))) for p in FOUR_LIST}
    f.add(SECTION, f"4-LIST ({scope}): {FOUR_LIST_NOTE}")
    for p, n in counts.items():
        rows.append(StatRow("pav", "four_list", scope, "all", p, n, n=sum(counts.values()),
                            loci=f"disc=any;res={','.join((*quartet, *z, *cat.outgroups))};outgroup=E;merged states",
                            note=FOUR_LIST_NOTE))
    return rows
