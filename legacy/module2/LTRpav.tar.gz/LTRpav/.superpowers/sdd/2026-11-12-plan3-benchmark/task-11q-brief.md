# Task 11 Part Q: score a painting LTRpav skipped (eval_run.py)

Plan 3's simulation grid scores each run with `sim/eval_run.py` (then `sim/eval_ltrmix.py`). Two posctl null runs,
`runs/pc_null_r1` and `runs/pc_null_r2` (kind posctl, f = 0), failed their eval step:

```
eval_run.py: error: missing input .../runs/pc_null_r1/views/roles/posterior.A1.tsv
```

The cause is not a broken run. In these runs no genome shares insertions with C1, so D_pav(A1,B1;C1) is nan and the
roles come from sheet order. LTRpav then skipped every painting and recorded it:
- `views/roles/findings.txt`: "WARNING: Painting of A1 (sister B1, donor C1) skipped: no RD locus (C1 present, B1 E)
  in A1's own calls at the N loci of A1: the HMM needs both classes";
- `stats.tsv`'s paint rows for the scope: `n_RD` 0, and `e0_*`/`e1_*` written as `.`.

`paint_section` (eval_run.py, around line 607) nevertheless requires `posterior.<R>.tsv` and `tracts.<R>.bed`. It is
called for the roles view (head_to_head_section) and for each model view (around line 1072).

## Controller's ruling (binding)
- A painting that LTRpav records as skipped for the scored scope is scored as **zero tracts called**: n_tracts 0,
  n_tracts_q05 0, tract FDR 0 of 0. accuracy, AUROC and every posterior-based field are NA with the reason "painting
  skipped by LTRpav: <its reason>". The stats rows are kept as they are.
- "Records as skipped" means a findings.txt line for exactly that recipient, sister and donor, in the form "Painting
  of <R> (sister <S>, donor <D>) skipped: <reason>". Read the exact wording from the run files and from the
  snapshot's code (`benchmark_pav/plan3/snap/4f3973e/src/ltrpav/analysis/`), and match it robustly.
- A missing posterior or tracts file without that record is still a fail-fast `missing input` error.
- Why: the method's documented output is "no painting", which calls no tract. Failing the run would drop it from
  every table.

## Do
1. Tests first, in `sim/test_eval_run.py`, with small synthetic views like the file's existing fixtures. Each must
   fail before the fix:
   - a skip record and no painting files gives 0 tracts and accuracy NA with the reason, for the roles view and for a
     model view;
   - no skip record and no files raises the missing-input error;
   - a skip record for a different scope does not excuse a missing file.
2. Fix eval_run.py, the smallest change at `paint_section`, or where it reads the two files.
3. Run the sim tests with -W error.
4. Read-only real check: copy only what eval needs from `runs/pc_null_r1` into your scratch directory (or symlink the
   large inputs). Run the fixed eval_run.py and then eval_ltrmix.py against the copy, and show both exit 0. Report the
   fields that read the skip. Never write in `runs/`.
5. Install by atomic move: write beside the target, check the live file's sha256 still equals the one in sim/memo.md
   (refuse if not), then `mv`. Append to sim/memo.md's "Scoring fixes" entry the change, a one-line reason, and the
   old and new sha256s.
6. Write the review package `task-11q-review-package.diff` (in this directory): `diff -u` from the old to the new
   eval_run.py and test_eval_run.py, with sha256s in a header.

## Constraints
- The grid is still running and calls eval_run.py fresh for each run, so install only by atomic move.
- Never edit run_one.sh, run_grid.sh, lq/run_lq.sh, common/env.sh or RULES.md.
- Env ltrpav via `. /data2/chris/maize_introgression/benchmark_pav/plan3/common/env.sh`, with
  `NUMPY_MADVISE_HUGEPAGE=0 OMP_NUM_THREADS=1`. Never run python with -I or -E.
- At most 4 threads and 15 minutes per probe; never kill a process.
- American English; no AI attribution.
