# Task 14 review: *Zea* genus, sweet orange, EDTA portability

## Re-review (fix round 1)

Reviewer, 2026-11-14 ~17:20. Scope: the fixes listed in task-14-report.md "Fix round 1" and the controller rulings
"Task 14 C1" and "Task 14 I1, M1-M8" (progress.md:263-264). Read-only. Recomputations ran in the scratch directory,
under `fix1/` and `rereview_fix1.py`.

### Independent recomputation (once, from my own code)
- **c2_any.** Merged tracts against CsA.P.bed (BED, half-open) give coverage **0.9512** of CsA_chr2 (chr8 0.7497).
  bp called 8,056,005, truth 8,714,296, shared 8,036,225: precision **0.9975**, recall **0.9222**. Matches the report.
- **age_mix.** Each stratum's D is recomputed from n_RD and n_SD in six/views/main and edta/views/main stats.tsv:
  - Totals from the strata: +0.2898 and +0.3054, equal to the primary counts.
  - EDTA strata at LTRquest's age mix: **+0.2457**. LTRquest strata at EDTA's age mix: **+0.3344**. Matches.
- **View c2_any.**
  - Made on snapshot 2: the paint log's line 1 names snap/6282541, both steps exit 0, and the paint marker carries
    code b30e7089… with `discovery any`.
  - Its tracts, posterior and decoy files are byte-identical to my first-round scratch repaint (made with stats first),
    so running paint alone did no harm.
- **Genotypes and fai.** Nothing in citrus/geno changed: 0 files newer than block.done, and 0 newer than my 16:39
  stamp. The same holds for genus/geno and edta/geno. The fix1 fai snapshots are identical and equal the original
  start.
- **Reproducibility.** All four suites pass on scratch copies with `-W error`: 8, 10, 2 and 2. The committed
  outputs reproduce exactly from the new scripts: investigate_c2.txt, age_mix.txt and the five result tables. The
  original and new scripts' tables differ only in the added orientation text; every verdict and number is the same.

### Per-finding verdicts
- **C1 ADDRESSED.** The cause now reads the same in all five places: the default's own-annotation, own-call discovery,
  plus one unresolved own call; not a lack of informative loci, and not presence/absence-only painting. Locations:
  - citrus/RESULTS.md verdict 1: :21-26.
  - citrus/RESULTS.md MISS section: :119-148.
  - citrus headline: :185-198.
  - dead_ends_entry_task14.md: :19-49.
  - memo_entry_task14.md: :47, :54.
  - task-14-report.md: :91-107, concern 3 at :136-137.

  No old wording remains: a grep for identity class, "nothing to paint", "not a genotyping", "orthologs found in
  both" and "resolution limit" finds only the corrected line citrus/RESULTS.md:135-136. I checked every
  per-discoverer Cr call cited, against the pair files:
  - L0003433: Cm→Cr E (high).
  - L0003449: CsA→Cr U (flank_unaligned); CsB, Cm and CaP→Cr E (high).
  - L0003502: CsB→Cr E (high); Cm and CaP→Cr E (medium).
  - L0003373, L0003446, L0003477: every discoverer's call into Cr P (high).

  The MISS stands and the `any` painting is scored nowhere as a bar (citrus_results.tsv: 6 PASS, 1 MISS).
- **I1 ADDRESSED.** edta/RESULTS.md result 1, "In short", the two bullets of "Where the difference comes from" and the
  headline. age_mix.py is correct; its test pins the reweighting on a hand-checked example.
- **M1 ADDRESSED.** genus/RESULTS.md:100-103 defines dD from 4 loci at K=0, and the strata contrast is shown apart.
- **M2 ADDRESSED.** genus/RESULTS.md:95-97 and :197-200.
- **M3 ADDRESSED.** genus/RESULTS.md:176-179. The q score is sum_post (paint.py:478). I checked the counts:
  - p1: 15 of 142 tracts above the best decoy (121.2).
  - p2: 13 of 106.
  - ctrl and zd: 0.
  - Best q: 0.067, 0.077, 0.741, 0.736.
- **M4 ADDRESSED.** citrus/RESULTS.md:155-157 gives f 0.0179 ± 0.0090 and 0.0176 ± 0.0076, the values in k1's
  stats.tsv.
- **M5 ADDRESSED.** genus/RESULTS.md:25-28, :67; citrus/RESULTS.md:78, :89-90, :158-159. The code is
  score_genus.py:199-210 and score_citrus.py:298-309; it flips only when the donor matches and R and S are swapped. The
  tests assert both the flip and the no-flip case.
- **M6 ADDRESSED.** memo_entry_task14.md has one heading with inline labels; its commands match the logs.
- **M7 ADDRESSED.** edta/RESULTS.md:73-77 and memo :9.
- **M8 ADDRESSED.** investigate_c2.py computes every claim (:70-77). It uses the midpoint rule (:30-31), and its
  output reproduces.

### New issues (Minor; none touches a number or verdict)
- **N1.** dead_ends_entry_task14.md:25-26 says "each with Cr E at tier high in the discoverers' calls". At L0003502,
  Cm's and CaP's calls are E at tier *medium*, and at L0003449 CsA's own call is U. Write "merged Cr E at tier high",
  or use citrus/RESULTS.md:126's "every discoverer's call into Cr reads E".
- **N2.** edta/RESULTS.md:92, "The same shifts raise dD". dD is a difference of stratum D values (K=0 is +0.600 on
  both), so the age mix cannot move it; only the lower old-stratum D does.
- **N3.** memo_entry_task14.md:44, "−0.307 in this orientation, Z 3.26". In that orientation Z is −3.26.
- **N4.** Cosmetic: broken hard wraps at genus/RESULTS.md:97, :103 and citrus/RESULTS.md:57.

### Out of scope
- six/ (score_six.py 16:51, six_results.tsv 16:52, …), real/memo.md (17:05) and benchmark_pav/dead_ends.md (17:06)
  changed during this window. That fits Task 13's parallel fix round. Neither shared file holds a Task 14 entry yet, so
  the controller should append the *current* staged files, after N1 and N3.

### Assessment (fix round 1)
**Approved.** C1, I1 and M1-M8 are addressed, and the numbers reproduce independently. N1-N3 are one-line wording
fixes, best made before the staged entries are appended.

---

## Original review (round 0)

Reviewer, 2026-11-14. Read-only on benchmark_pav and the repo. Probes ran in
/tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3t14-review
(env ltrpav, SNAP_SHA=6282541, 1 thread, each under 1 min). After the probes no file in citrus/geno was newer than
the probe's start stamp. R = benchmark_pav/plan3/real.

## Spec compliance

- ✅ Step 1 views all, p1, p2, ctrl, zd: genus/views/*; 31 step logs, all exit 0, each naming snap/6282541; 20 stage
  markers all carry code b30e7089...; no geno/ file newer than its block.done; fai start = end (15 files).
- ✅ P1 and control bars, each PASS or MISS (genus/RESULTS.md:20-27, genus_results.tsv). ✅ P2 reported (:28-29).
- ✅ Resolved fractions in R and S for every trio (genus/RESULTS.md:68-74; p1, p2, ctrl, zd).
- ✅ zd. The discovery genome is from findings.txt (Zn; zd/findings.txt line 59). The unnarrowed wording would add
  TIL01 and TIL25 (score_genus.py checks this against findings.txt). D and Z sit beside nodonor (0/30 nulls, 7/36 hits,
  2 of them with A2: genus/RESULTS.md:144-152). The 0.009 margin for TIL18 in TIL01,TIL25;Zd is reported (:153-159).
  The rule is unchanged (:160).
- ✅ Step 2 views c1, c2, k1, k2. Called-tract bar per true tract of at least 1.7 Mb. Recall at q <= 0.05, C1, the
  controls and the bp rows are all reported (citrus_results.tsv, citrus_truth_tracts.tsv, citrus_bp.tsv).
- ❌ R4, "each MISS is investigated": the investigation exists, but its stated cause is wrong (Critical C1).
- ✅ Step 3: view, stats, paint and compare_papers.py with --prefix edta_main. The rows D_pav, dD, chromosome ranking,
  window r at 1 and 10 Mb, AUROC, spacing and Inv4m sit beside six/views/main (edta/RESULTS.md:56-69).
- ✅ Step 4: memo and dead_ends entries staged, not appended (R2). The memo's format is off (Minor M6).
- ✅ R3: null quantiles given for every D_pav Z. "Simulated power is optimistic" is stated where nodonor is compared
  (genus/RESULTS.md:150). The default painting is named. ✅ R4: the Zn limitation is named (genus/RESULTS.md:10-14), no
  figures are made, and LTRmix's sources are named (one path is outside $P/benchmark: Minor M7).
- ⚠️ Not re-derived: compare_papers.py's window r, AUROC, chromosome ranking and Inv4m from the posterior files. That is
  Task 13's script, used unchanged. I checked that every EDTA and LTRquest value matches edta_main_papers.tsv,
  six_main_papers.tsv and benchmark/edta/out/benchmark_real.tsv.

## Bar table (re-read from the views' stats.tsv, tracts BEDs, the truth BEDs and perrun.tsv)

| Bar | Reported | My re-read | Agree |
|---|---|---|---|
| P1 D_pav(Zh,TIL18;Zn) > 0, Z > 3 | +0.4804 ± 0.0755, Z 6.36; 245/86 of 7,129; nulls 0/30, 0/30 | same (p1/stats.tsv); null counts recomputed: 0/30 default, 0/30 bottleneck, p 0.032 | yes, PASS |
| Control D_pav(TIL18,TIL25;Zn) \|Z\| < 3 | −0.0701 ± 0.1024, Z −0.68; 73/84 of 7,244; 9/30, 22/30 | same; 95% interval −0.271 to +0.131 | yes, PASS |
| CsB chr1 23.83 Mb, cover >= 0.5 at any q | 0.991 | 0.9913 (merged tracts, BED half-open) | yes, PASS |
| CsB chr2 3.56 Mb | 0.513 | 0.5133 (one tract 18,909-1,844,072, 2 RD; borderline, flagged in RESULTS) | yes, PASS |
| CsB chr3 7.22 Mb | 0.753 | 0.7528 | yes, PASS |
| CsB chr9 1.74 Mb | 0.820 | 0.8202 | yes, PASS |
| CsA chr2 7.46 Mb | 0.340 | 0.3395 (one tract 25,761,548-28,293,788, q 0.5) | yes, MISS (but the cause is wrong: C1) |
| Control k1 D_pav(CaM,Cr;Cm): \|Z\| < 3, no tract at q <= 0.05 | +0.448 ± 0.172, Z 2.61 (21/8); 0 at q <= 0.05 (3 at any q); 0/30, 2/30 | same; the 3 tracts have q 0.333 | yes, PASS |
| Control k2 D_pav(CaP,Cm;Cr) | −0.118 ± 0.218, Z −0.54 (15/19); 0 (8 at any q); 12/30, 24/30 | same; tracts q 1 | yes, PASS |

The reported items, re-read, all agree:
- P2 +0.417 Z 5.22; zd −0.217 Z −0.57 (9/14 of 351, 671 candidates).
- C1 +0.855 Z 16.85; C2 +0.297 Z 0.95.
- f4 0.139, 0.145, 0.015, 0.015.
- bp precision/recall: CsB 0.8208/0.8790, CsA 0.7168/0.3126.
- AUROC 0.9933 and 0.9951; 158 of 187 RD inside the truth.
- Every no-outgroup null count; nodonor 0/30 (mean −0.256, SD 0.898, 177.4 loci) and 7/36 (210.0 loci).
- Four-point sums; EDTA D, strata and resolution.

LTRmix values match their files: trio_summary.tsv, donor_resolved, lineage2/eval/*.tsv, benchmark_real.tsv, and
REPORT.md 6b/6c (46 vs 6, 11 vs 4, +0.101). I ran all three test suites on copies with -W error: 8, 10 and 2 passed.

## Strengths

- Every bar number traces to a view file, and the coverage arithmetic is right (merged tracts, 0-based half-open,
  q "none" kept at any q only).
- score_citrus.py's tests pin the 50% rule on both sides of the boundary. They also cover the q filter, the I4 note,
  the selection of the null runs and failing fast on bad input.
- score_genus.py fails if findings.txt's excluded genomes differ from the unnarrowed list, and if perrun's nodonor
  disagrees with decision11.tsv.
- Careful calibration elsewhere:
  - TIL25,TIL18;TIL01 (Z 3.23) is kept as a lead because its sister pair is ambiguous.
  - The k1 lean is a lead, and the zd value "says nothing about gene flow".
  - dD is called descriptive, and CsB chr2's PASS on 2 informative loci is stated.

## Issues

### Critical

**C1. The CsA chr2 MISS has the wrong cause, and RESULTS calls that cause tested.**
Where:
- citrus/RESULTS.md:20-23, 115-126, 160-169
- genus/dead_ends_entry_task14.md:26-42
- task-14-report.md:97-101, 130
- genus/memo_entry_task14.md:46

The documents say four things: that the last 5.56 Mb "hold not one informative insertion, so presence/absence has
nothing to paint there"; that LTRmix's extra coverage is "sequence identity"; "not a genotyping error"; and, under
"Cause tested", that the miss is "a resolution limit of presence/absence painting", which an identity class would fix.
The investigation's output shows only that the *default painting's* loci hold no informative locus there.
LTRpav's own data refute the rest:
- **Merged genotypes** (citrus/geno/loci.tsv) hold 12 RD loci inside the true tract (CsA present, Cm P, Cr E). Three of
  them are in the "empty" stretch, each with Cr E at high tier:
  - L0003433 at 28,948,751: CsA S, high tier; discovered only in Cm.
  - L0003449 at 29,247,698: CsA P.
  - L0003502 at 32,578,262: CsA S, high tier; discovered by CsB, Cm and CaP.
  Genome-wide, CsA has only 25 such loci.
- **Why the default misses them.** The default painting (`--discovery recipient`) uses "every state from X's own calls"
  (snap paint.py, classes()), so it cannot see these loci:
  - Two are solo LTRs in CsA, which CsA's annotation of intact elements does not report.
  - L0003449 is nested in L0003447. CsA's own call into Cr is U (flank_unaligned, inherited from that host), while
    other genomes' calls give Cr E.
- **Probe.** I repainted c2 with the implemented presence/absence-only variant `ltrpav-paint --discovery any --trio
  CsA,Cr,Cm` (scratch view `c2any/`; scripts `merged_c2.py` and `cov_any.py`).
  - It calls CsA_chr2:25,464,219-32,578,552 (82 loci, 12 RD, 0 RS), covering **0.951** of the true tract.
  - CsA bp precision is 0.998 and recall 0.922, against 0.717/0.313 for the default and 0.808/0.604 for LTRmix recent.
  - The fitted L is 4.81 Mb against 1.34 Mb.
- **LTRmix's `near_donor` is not an identity-only class.** ltrmix.py categories() (lines 1303-1326) counts absent as
  resolved, so the class includes donor-present, sister-absent copies.
  - Of the 17 `near_donor` copies in the tract, 13 have in_Cr absent. Line 116 ("orthologs found in both other genomes")
    is false for those 13.
  - Of the 6 past the last LTRpav RD locus, 4 are Cm-present, Cr-absent (28.28, 29.21, 29.25 and 30.64 Mb).
  - LTRpav calls Cr P at high tier at L0003446 (29,207,276) and L0003477 (30,639,028), and also at L0003373
    (26,751,696). Those are untested genotype disagreements, not an identity effect.

Why it matters: the verdict stands (MISS; `any` was not adopted, so the bar does not change). But four things rest on
the false cause:
- the citrus headline's mechanism and prediction ("identity-based classes should fill them");
- the dead_ends "Cause tested";
- report Concern 3;
- the Plan 4 lead.
The cause the data show is the default discovery rule. That is SIM_RESULTS Plan 4 leads 1-2 seen in real data.

Fix:
- Keep the MISS.
- Rerun the repaint as a logged investigation view (for example citrus/views/c2any: `common/view.sh citrus/geno …`,
  then `ltrpav-stats`, then `ltrpav-paint --discovery any`; genotypes stay read-only), and score it with
  tract_cover.
- Rewrite the cause in all five places: 2 of the 3 informative insertions in the last 5.56 Mb are CsA solo LTRs outside
  its annotation, and CsA's own call is unresolved at the third; with merged states the tract is covered 0.951.
- Correct the `near_donor` description, and name the three Cr presence disagreements as untested.
- Drop "not genotyping"; label the identity class untested or drop it.
- Replace the citrus headline's mechanism and prediction accordingly.

### Important

**I1. The EDTA headline's mechanism contradicts the step's own numbers** (edta/RESULTS.md:100-101, against 78-82).
"Dropping loci at random leaves its expected value unchanged". Yet EDTA keeps 56% of young informative loci and only
32% of old ones, so the loss is not random. Reweighting each run's strata to the other's age mix gives 0.246 (EDTA
strata, LTRquest mix) and 0.334 (LTRquest strata, EDTA mix). The agreement (0.305 against 0.290) therefore comes from a
higher young share offsetting a lower old-stratum D (0.128 against 0.202, about one SE apart).
Fix: state that mechanism, or label "random loss" as assumed and contradicted in part. Keep "agrees within SE".

### Minor

- **M1** genus/RESULTS.md:98-102. dD (+0.031) is D(K=0) − D(K>=0.01), computed on 4 loci with K = 0. It is printed right
  after the K < 0.01 against K >= 0.01 contrast (+0.54 against +0.47), so a reader takes it for 0.07. Define dD at that
  point.
- **M2** genus/RESULTS.md:95, 192 overstate.
  - "With equal resolution, unequal observation cannot move D": equal marginal rates do not exclude resolution that
    depends on the state.
  - "makes the observation rates equal": the rates are measured equal here, not guaranteed by the rule.
  - Fix: soften both.
- **M3** genus/RESULTS.md:172, "too sparse for the target-decoy rule". p1 has 142 tracts, so the 1/n floor does not bind
  (its best q is 0.067). Decoy tracts score as high as target tracts. Reword.
- **M4** citrus/RESULTS.md:24-28, 130-134. The k1 lead omits its f4: 0.018 ± 0.009 (Z 2.0, D2 CsB) and 0.018 ± 0.008
  (Z 2.3, D2 CaP), a second, non-independent reading in the same direction.
- **M5** citrus/RESULTS.md:72 and genus/RESULTS.md:25-27: give LTRmix in LTRpav's orientation.
  - k2: LTRmix's +0.130 is −0.130 in LTRpav's orientation, the same sign as LTRpav's −0.118.
  - Genus control: LTRpav's −0.070 has the same sign as LTRmix's −0.307, and the interval excludes −0.307 by only 0.036.
- **M6** memo_entry_task14.md:13, 22, 43, 51. The `##` sub-headings would read as top-level sections of real/memo.md
  (Task 13's entry uses inline labels). Use `###` or inline labels. Line 46 also needs C1's cause.
- **M7** edta/RESULTS.md:71-72. LTRmix's LTRquest values come from $P/LTRmix/benchmark/results/main3 (what
  compare_papers.py reads), not from $P/benchmark/ as R4 asks, and the two main3 copies hold different file sets. Name
  the path actually read.
- **M8** investigate_c2.py:60 prints "none informative" as a literal; compute it. The script decides "inside" by the
  locus start, while score_citrus.py uses the midpoint; both give 40 here.

## Assessment

**Needs fixes.** Every bar number and verdict is correct: genus 2 PASS; citrus 6 PASS, 1 MISS. The verdict counts in
the report hold, and all R1-R3 provenance checks pass. Fix C1 (the MISS cause, refuted by a 20-s presence/absence
repaint that covers 0.951) and I1 before the controller appends the staged entries. The Minor items can be fixed in the
same pass.
