# Task 3: controller rulings (Task 2 final at its approved head; see the ledger)

These bind as much as task-3-brief.md, and override it where the two conflict.

## R1. Existence is decided upstream (Task 2's concern-1 ruling)
- **What `draw_events` emits.** It emits only events that exist: an event exists only on sequence that is present
  on its lineage at its time. Discarded events are counted in `dropped` as `ins_after_loss`, `nested_after_loss` and
  `loss_after_loss`.
- **One definition of removed intervals.**
  - `popevents.removed(loss, elements, ins, donors, length) -> list[(system, start, end)]` is the only definition of
    what each loss kind removes. Import it, and read popevents.py's module docstring ("Coordinates, for the
    builder"; "Existence at a point q") and removed()'s docstring before writing any code. Systems: None is the
    backbone; an iid is that insertion's donor body [0, len) plus its second TSD copy [len, len + TSD_DEFAULT).
    The junction rule decides whether an anchored copy survives a removal. Nested elements in the sequence a host's
    solo leaves stay. A flank that runs past a body continues into its host.
  - Never re-derive an interval convention in popbuild.py. That covers solo, del_flank, del_partial, replace and the
    del_flank flanks of a host-None insertion.
  - The brief's "Losses" paragraph describes the same conventions. Where the two differ, `removed()` wins; report the
    difference.
- **Fate `site_lost` goes.**
  - An insertion handed to `build_chrom` whose target bases were removed above its point on the lineage can come only
    from hand-built events.
    - The builder checks this by calling `popevents.thin_events(ev.ins, ev.losses, elements, donors, len(backbone))`
      once per chromosome. If anything would be dropped, it raises `ValueError` naming Task 2's existence rule.
    - It never re-implements the rule, and it never marks such an insertion.
  - `test_site_lost` becomes two checks:
    - the same toy through `draw_events`: `dropped["ins_after_loss"] >= 1`, and no Copy for that insertion;
    - hand-built events: `ValueError`.
  - A sample that did not inherit e and lost its target window keeps fate `"absent"` with `site = -1`. Task 4 reads
    that as D, as it reads `site_lost` now; Task 4's brief will say so.
- **Every kept event exists in all its carriers.** Task 2 discards an event when any one carrier's lineage lacks its
  sequence (ruling C2), so the builder never removes a kept event from some of its carriers.
- **Target bases are `[pos - TSD_DEFAULT, pos)`** (ruling C3). The copy sits before base `pos` of its host's system,
  and the left TSD copy is those bases, in place. The body runs in the host's order: forward on +,
  reverse-complemented on -.
- **Two named simplifications from Task 2** (docstring rule 4) need nothing from the builder, but must not be "fixed"
  there:
  - replacing sequence receives no insertions;
  - simulated solo LTRs receive no insertions.
- **A nested insertion in sequence its host's solo leaves stays,** with its own younger events (ruling C4a, Task 2
  fix round 1).
- **A nested element's del_flank is one contiguous deletion** (ruling C4c). It can continue into its host's host, as
  `removed()` gives it.
- Cost if wrong: one fate restored.

## R2. Choices from Task 2 that bind the builder (Task 2 report, concern 3)
- **`chrom` and iids.** `draw_events` takes a keyword `chrom`, and iids are `"i<chrom:02d><n:06d>"`.
- **The donor body is the left LTR twice.** Draw `copy_noise` over the whole body, then copy the left LTR over the
  right, so the LTRs are identical at insertion (brief).
- **`del_partial`.**
  - `(a, b)` are in the element's own original coordinates.
  - Two del_partials on one lineage may overlap. The removed sequence is their union, as `removed()` gives it.
  - `own_kept` counts the union once.
- **Indel inserted bases are drawn by the builder.**
  - Draw them once per indel event, from the chromosome's rng, in event order, before any sample is built. Every
    carrier then holds identical bases.
  - The result must not depend on the order samples are built.
  - Test: two orders give identical genomes.
- **Indels against removed sequence.**
  - An indel that overlaps an interval removed above it on the lineage does not happen there.
  - An indel older than a removal goes with the sequence the removal takes.
  - Element and LTR images in genome coordinates include indel length changes. `test_copy_coordinates_hold_payload`
    covers a copy with an indel in its flank.
- Cost if wrong: one builder rule revisited in Task 3's review.

## R3. Determinism and cost
- `build_chrom` returns identical bytes for identical inputs and rng seed (test).
- **One pass.** A 5-Mb probe at the default demography reports wall time and peak RSS per sample. Run it under
  `timeout 15m`, with at most 16 threads.
- No per-event array copy (brief).
