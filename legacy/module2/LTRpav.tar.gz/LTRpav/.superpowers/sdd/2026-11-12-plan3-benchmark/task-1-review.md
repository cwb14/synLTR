# Task 1 review: branch, msprime extra and the population model (12d3e6c..3bf2833)

Reviewer date: 2026-11-12. Read the brief, the plan's Global Constraints and Review Focus, DESIGN 10.2 and 12, the report
and the diff. Checked the code against them and ran independent probes (scripts in
`/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t1review/`).
Focused tests: `tests/test_popmodel.py` (all 12 selected by -k) pass under `-W error`. `ruff check` on the four
new or changed Python files: clean.

## Spec Compliance

Interfaces and rules (brief)
- ✅ `MSPRIME_HELP` verbatim (src/ltrpav/sim/popmodel.py:37). `Demog` and `Rates` have the brief's fields and
  defaults verbatim (:60-79, :120-134). Calibrated defaults carry "measured in the benchmark (DESIGN 12, Plan 3
  calibration)", as the Global Constraints require.
- ✅ `sample_labels`: A1..An, B.., C.., O1, with the taxon as the group (:168).
- ✅ Populations: A, B, C and O are extant with `initially_active=True` (:180). Lineage populations are extant and
  derived (:185-186).
- ✅ Splits are exactly as the brief gives them (:193-195, :186). A1 is sampled from A1p and C1 from C1p when set
  (:158-165). The test confirms the sample-node order matches the labels.
- ✅ Pulse: `add_mass_migration(ta, source=recipient, dest=donor, proportion=f)` (:189), with
  PULSES = code -> (donor, recipient) (:40). This follows msprime's convention. The msprime 1.4.2 docstring reads:
  "lineages in the source population are moved to the dest population ... Forwards-in-time ... **from** dest **to**
  source". It is the same mapping as LTRmix's sim_ltr_admix.py: source="B" (B73, the recipient), dest="M" (the
  donor). The LTRmix Ne values and times map one-to-one onto ne_a, ne_b, ne_c, ne_bc, t_ab and t_bc.
- ✅ Bottleneck: `add_population_parameters_change(t_ab - gens, "A", ne)` (:192). A bottleneck exactly as long as
  t_ab (an event at time 0) builds and simulates (probe).
- ✅ Recombination: RateMap with r outside and r_low on [round(low0 L), round(low1 L)) (:200-211). Empty
  intervals are dropped.
- ✅ Ancestry: `SampleSet(n, pop, ploidy=1)`, `ploidy=2`, `record_migrations=True` (:214-225). This is LTRmix's
  convention: diploid Ne, coalescent time scale 2N.
- ✅ Tracts: pulse records filtered by time ta, source recipient and dest donor (:241). Each record is clipped
  to every tree it spans, and `tree.samples(node)` is taken per tree (:250-260). The pieces are merged into
  sorted, disjoint, non-adjacent int intervals. Verified independently; see Strengths.
- ✅ Fail-fast cases from the brief, each a ValueError (:81-116): f outside [0, 1]; ta >= t_ab when f > 0; a
  lineage pulse without its sub_*; ta not below the lineage split; an unknown code; per_taxon < 1; a bottleneck
  longer than t_ab.
- ✅ `demog_from_json`: flat keys, an unknown key raises ValueError naming it, and the round trip of every field
  is tested (:275-294; tests/test_popmodel.py:148).

Step 1 (branch and environment)
- ✅ Branch `plan3-benchmark`. Commit 3bf2833 has parent 12d3e6c. Author and committer are the user's identity,
  the message is the brief's, and there are no trailers (read from the loose commit object).
- ✅ pyproject.toml:37 has `sim = ["msprime>=1.3"]`; environment.yml:12 has `- msprime`; ci.yml:34 has
  `pip install -e ".[dev,sim]"`.
- ✅ PyPI wheels: confirmed msprime-1.4.0 cp310 and msprime-1.4.5 cp313 manylinux wheels exist (`pip download
  --only-binary`). No GSL step is needed.
- ✅ Lock: has `^  - msprime=1.4.2`, and neither `prefix:` nor `ltrpav==`. The lock's 172 entries equal the
  env's `conda-meta` exactly, name by name, including version and build.
- ⚠️ Deviation, justified: environment.yml:18 pins bcftools 1.24, not 1.25. Verified from conda-meta that
  bcftools 1.24 h487d631_1 and msprime 1.4.2 both depend on `gsl >=2.7,<2.8`. The env runs: `bcftools --version`
  gives 1.24 (htslib 1.24), and `import msprime, tskit` gives 1.4.2 and 1.0.4. bcftools enters no stage key: only
  `TOOL_VERSION_ARGS`, read by outputs/manifest.py for provenance. pysam bundles its own htslib (no `libhts`
  link), so the htslib downgrade cannot break it.
- ✅ DESIGN 12, "### Build decisions (plan 3)" (docs/DESIGN.md:724). The lead is "Simulator calibration is not
  method tuning". Items 1-36 follow, one per call in plan3-draft-summary.md, in its numbering; I spot-checked 1-12
  against the summary.

Step 2 (tests)
- ✅ All 12 tests are present, and the module starts with `pytest.importorskip("msprime")` (tests/test_popmodel.py:8).
  The toy model makes one 200-kb ancestry run well under a second.
- ⚠️ test_tract_through_ancestor scans seeds from 3, not the brief's fixed seed 3. Ruled acceptable (focus 2,
  below).

Global Constraints
- ✅ Engine isolation. `src/` changes only in `sim/__init__.py` and `sim/popmodel.py`. STAGE_MODULES
  (checkpoint.py:47-60) names only annotation, anchor, blocks, chain, classify, constants, elements, genotype,
  junction, localign, seqio and window. Every fingerprint hashes those files' bytes, so the fingerprints cannot
  have changed. I did not recompute them from the base commit; the structural argument settles it.
- ✅ No maize names in `src/ltrpav/sim/` (grep for zea, maize, B73, TIL, mexicana, parviglumis).
- ✅ Import isolation. `ltrpav.sim.__init__` imports popmodel, which imports msprime and tskit only under
  TYPE_CHECKING or inside `_msprime()`, with `from __future__ import annotations`.
  `test_import_without_msprime` passes. It blocks msprime and tskit in a fresh interpreter, then imports
  ltrpav, ltrpav.sim, ltrpav.cli, ltrpav.sim.cli and ltrpav.analysis.cli. Only test_popmodel.py imports
  msprime-dependent code; poptoy.py imports only `Demog`.
- ⚠️ I did not rerun the full suite (1171 passed, per the report), as instructed.

## Strengths

- **The tracer is right, and that is confirmed independently on two routes.**
  - Route (a) uses the plain tree sequences `ancestry()` returns and no migration records. Each recipient
    sample's lineage at ta is the edge above its highest node younger than ta. When that edge's parent coalesced
    before t_bc, the parent's population shows which side of the pulse the lineage took.
    - Compared with `tracts()`: 0 disagreements in 91,480 decidable (tree, sample) pairs.
    - That covers 8 scenarios × 5 seeds: every pulse code (C>A, A>C, C>A1, C1>A1, A1>C1), per_taxon 3 with a
      bottleneck, ne_a = 5 (the ancestor case), and the default Demog.
    - Non-recipient samples never received a tract.
  - Route (b) re-simulates with msprime MIGRANT nodes and walks each sample's path to a migrant node at ta in the
    donor population. `tracts()` agreed in all 36 cases (9 scenarios × 4 seeds).
- The source and dest semantics follow msprime's documentation and LTRmix. Every test with an f = 1 pulse checks
  the direction by sample index. A reversed tracer fails 5 of the 6 tract tests (mutant probe).
- The fail-fast is thorough and gives clear messages. `__post_init__` coerces JSON lists to tuples, so equality
  and hashing survive the JSON round trip.
- The environment repair was conservative and fully documented (env.yml comment, commit message, report). The
  lock matches the live env exactly.
- The subprocess import test avoids leaving duplicate module objects behind and proves that this tree's ltrpav
  was imported.

## Focus rulings

1. **Population genetics.** Correct. The demography matches the brief and LTRmix. The pulse runs recipient to
   donor backward in time, as msprime defines it. Truth tracts are the donor-derived intervals with exact
   coordinates (independent checks above). The recombination-map boundaries are tested at 0.3 L - 1, 0.3 L,
   0.7 L - 1 and 0.7 L.
2. **The seed scan in test_tract_through_ancestor.** It is acceptable: a test of correctness given the event, not
   selection.
   - I confirmed the claim. With ne_a = 5, ta = 1000 and f = 0.5, seeds 1-3 give no pulse record and seeds 4-8
     give one (msprime 1.4.2; toy and default Demog alike). The brief's seed 3 could never pass.
   - The scan conditions on the event, which the test's own `pulse_records` detects independently of `tracts()`.
     It asserts `tracts == {}` for each skipped seed. If no seed in 3-22 moves a lineage, `t[0]` raises
     KeyError, so it cannot pass vacuously. It is deterministic for a given msprime version.
   - A broken tracer does not pass. A samples-only tracer (which ignores ancestors) passes every other test and
     fails only this one (mutant probe). This test is the one that guards the "through an ancestor" rule, and
     the scan keeps it live.
3. **Environment.** bcftools 1.24 and msprime 1.4.2 both run. The lock has no `prefix:` and no `ltrpav==`, and
   holds msprime. The pin is justified by the gsl conflict, which I verified in conda-meta.
4. **Import isolation.** Holds; tested in a fresh interpreter.
5. **Engine isolation.** Holds by construction (STAGE_MODULES excludes `sim`, and the diff touches only `sim`).
6. **The implementer's choices.**
   - **All extant populations active:** sound and needed. With sub_a or sub_c set, A or C is the ancestral side
     of a split, and msprime would start it inactive, so sampling A2 or C2 would fail.
   - **Extra fail-fast checks:** sound, with one asymmetry (Minor 1).
   - **Public `recombination_map`:** sound. `round()` differs from LTRmix's `int()` by at most 1 bp.
   - **Flat JSON:** sound; no field names collide (Minor 4).
   - **Subprocess import test:** sound.

## Issues

### Critical
None.

### Important
None.

### Minor

1. **Fail-fast asymmetry at f = 0.**
   - Where: popmodel.py:107-116.
   - What: `ta < t_ab` is enforced only when f > 0 (:107), but `ta < lineage split` is enforced at f = 0 too
     (:114). `Demog(pulse="C>A1", sub_a=(2000, 1000), f=0)` raises on the default ta of 5000, while
     `Demog(ta=9000, f=0)` is accepted.
   - Why: ta has no meaning at f = 0. A lineage-code null row that keeps the default ta would fail although no
     pulse happens. The current grid is safe: its posctl nulls carry ta 500, and its other nulls use C>A.
   - Fix: keep the sub_* presence check strict at f = 0, as the brief says; apply the ta-versus-split check only
     when f > 0, as :107 does.
2. **Test gap: a record spanning trees with changing descendant sets.**
   - Where: tests/test_popmodel.py; the tract tests use per_taxon <= 2.
   - What: with at most two samples per taxon, the recipient-side sample set under a record's node is constant
     along the record, so a tracer that read only the record's first tree passes all 12 tests. With per_taxon 3,
     such a tracer is wrong in 3 of 10 seeds (probe).
   - The shipped per-tree clipping is correct (route (a) above includes per_taxon 3: 0 disagreements). But
     `--per-taxon N` will be a CLI option (Task 5), so a regression would go unseen.
   - Fix: add a per_taxon = 3 test that compares `tracts()` with an independent truth, such as the
     parent-population rule of route (a) or a MIGRANT-node walk.
3. **test_tract_through_ancestor does not check coordinates.**
   - Where: tests/test_popmodel.py:112.
   - What: it asserts `t[0] == t[1] != []` but not the intervals, so a tracer that returns [0, L) for any moved
     node passes it. Only test_fraction_matches_f catches that tracer.
   - Fix: also assert that `t[0]` equals the merged union of the pulse records' [left, right) (all of them hold
     the shared ancestor here).
4. **No guard against a future field-name collision in the flat JSON.**
   - Where: popmodel.py:275-294.
   - What: a field added to both Demog and Rates would silently feed both.
   - Fix: a module-level `assert not {f.name for f in fields(Demog)} & {f.name for f in fields(Rates)}`, or a
     test of that.
5. **The bcftools 1.24 pin is not among DESIGN 12's build decisions.**
   - Where: docs/DESIGN.md:724.
   - What: the pin is recorded in environment.yml:18 and the commit message only.
   - Why: bcftools' version appears in every new run manifest (outputs/manifest.py), so main3 (1.25) and Plan 3
     runs (1.24) will differ there.
   - Fix: the controller ratifies the pin, and a one-line DESIGN 12 note records it, for provenance.

## Assessment

**Spec compliance: ✅.** Two deviations, both justified and documented: bcftools 1.24 (forced by the gsl
conflict) and the seed scan (the brief's seed 3 can never produce a tract).

**Task quality: Approved.** The demography, pulse direction, sampling and truth tracts are correct. Two
independent methods confirm the tracts with zero disagreements. The environment is consistent, and the engine is
untouched. The five Minor items are hardening, not blockers.
