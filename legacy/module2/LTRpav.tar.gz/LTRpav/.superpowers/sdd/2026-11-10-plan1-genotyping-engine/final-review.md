# Final whole-branch review: LTRpav Plan 1 (b3f0c8f..7d71073, branch plan1-engine)

Date: 2026-11-11. Range: 57 commits, 68 files, about 15k lines. Reviewer: read-only. Snapshot of 7d71073 exported to
`/data2/chris/maize_introgression/benchmark_pav/final_review/snap`; all probes ran from it, with PYTHONPATH set,
the ltrpav_bench env, at most 8 threads, `timeout 15m` and NUMPY_MADVISE_HUGEPAGE=0. Probe scripts and outputs:
`/data2/chris/maize_introgression/benchmark_pav/final_review/{scripts,frag,close,close5,badinput}`. I only read the
main3 run's `run.log` and `mem.tsv`; I did not touch the run, its outputs or its processes.

**Passes.**
1. Spec, plan (Global Constraints, Review Focus), the 24F/24G/24H briefs, the ledger and REPORT.md sections 0, 7
   and 8.
2. Foundation modules: constants, seqio, samples, elements, annotation/*.
3. blocks, chain (chaining DP, syntenic net).
4. anchor/* (routes, the anchor cache), checkpoint.
5. window, localign (mappy and LASTZ), junction, classify.
6. genotype (chunks, workers, merge).
7. loci (catalog, QC), outputs/*, cli.
8. sim/* (skimmed; reviewed in depth in Task 22).
9. Tests and CI; packaging and authorship.

**Suite.** Run once from the snapshot: `pytest -W error`, nothing deselected: **784 passed in 139 s**, exit 0. ruff
0.17.4: all checks passed.

## Strengths

- **Architecture follows DESIGN 5.**
  - The anchoring is pluggable behind a small `Route` protocol, and every route goes through the same chain and
    net.
  - Windows, the local aligner and the classifier are fixed, so routes differ only in their anchors.
  - Nested elements resolve inside their host's window, with the inheritance rules of 5.2.
  - Seqids are namespaced per genome. The Review Focus 1 test compares whole outputs, renamed, byte for byte.
- **The syntenic net (24F) is principled.** It follows UCSC's chain/net hierarchy with no new parameter, its
  complexity is stated in the docstring, and it has targeted tests, including brute-force checks from earlier
  rounds. On whole genomes (B73 vs TIL18) it netted 480k raw blocks in about 9 s.
  - My probe of a minus-strand parent, a case with no test, behaves correctly: syn and inv fills in its gap are
    kept, and out-of-place fills are dropped.
- **The classifier is careful and documented.** The rules are listed in order in the module docstring. Junction
  refinement is exact and left-normalized, with an equal-score slide range. Rule 5a, with 24H's tightening,
  closes paralog routing in wide windows. P/E precision on the sims is at least 0.99 at high tier.
- **Engineering is unusually solid.**
  - Every output is written atomically; gzip output is deterministic (mtime 0); done markers are written last;
    resume works per chunk.
  - The worker pool fails fast on a dead worker and uses PDEATHSIG, so no worker is orphaned.
  - Memory stays bounded: chunked mapping, bounded pieces in flight, and no genome is ever loaded whole.
  - Errors in the common paths are one line.
- **Real-scale behavior (read-only, from main3's log).** B73 vs TIL18 on whole genomes took **24 min at 32
  threads**: index 85 s, anchoring 4 min, genotyping 20 min, for 127,636 calls. Peak tree PSS so far is 16.9 GB.
  The cost bar is about 2 h and 250 GB.
- **Robustness I probed.**
  - *Fragmented target.* I cut sim R1_s1's B into 41 shuffled 200-kb contigs, half of them reverse-complemented.
    P/E precision stays 1.0 and recall drops only near the cuts (unresolved 2.5% -> 9.4%). This was never tested
    before. Data: `final_review/frag/`.
  - *All three presets on the toy cases.* The 21 toy cases x 7 seeds (175 runs) are exact under asm20, asm10 and
    asm5, with both backends.
  - *VCF.* It passes `bcftools norm -c e` with 0 mismatches.
  - *Security.* There is no `shell=True`; subprocess arguments are lists; temp files sit in owned directories;
    LASTZ's scratch is a private `TemporaryDirectory`.
- **Authorship is clean.** All 57 commits carry the user's global identity (cwb14), with no trailers. There is no
  AI attribution in any tracked file, and pyproject names the plan's author. Spelling is American English (one
  nit below).
- **Process.** Every deviation was recorded as a ruling with its cost, and the deferred items were tracked, which
  made this review tractable.

## Issues

### Critical

**C1. The LASTZ window backend gives wrong calls, some at high tier, for close genome pairs (asm5 scoring).**
- **Where.**
  - `src/ltrpav/genotype.py:78` picks the preset from the pair's genome-wide d.
  - `src/ltrpav/constants.py:33` sets the cuts (`PRESET_CUTS`: d <= 0.001 -> asm5, d <= 0.01 -> asm10).
  - `src/ltrpav/localign.py:291, 312-331` turns the preset into LASTZ scoring (`LASTZ_SCORING`, `lastz_args`).
  - `tests/test_lastz.py:36` tests asm20 only.
- **What is wrong.** The bake-off measured LASTZ only under asm20:
  - every sim had d of 0.015-0.016, and chr10 had d = 0.034;
  - the suite's LASTZ tests also run asm20 only.

  The engine nevertheless switches LASTZ to asm10 or asm5 scoring for closer pairs. Under asm5 scoring
  (`--match=1,19 --gap=39,3`), LASTZ fragments its alignments in locally divergent sequence instead of losing them,
  and the classifier reads the fragments as D, O, T or S. mappy under the same presets fails safe (U).
- **Evidence.**
  - *End to end* (`final_review/close5/`, `scripts/make_close_pair_asm5.py`). In 6 close pairs (d = 0.0007-0.0009,
    so the default `ltrpav run` chose asm5), elements inside 5%-divergent patches:
    - of 12 true E sites: E 2, **D 4 (2 at high tier)**, O 3, U 3;
    - of 12 true P sites: P 2, **T 8**, U 2.
  - *The same design at d = 0.0018 (asm10, `final_review/close/`):* 9 of 9 correct.
  - *Toy sweep* (`scripts/probe_divergence_sweep.py`), with LASTZ:
    - asm5 miscalls from 4% local divergence: E -> D high or O medium; at 6%, P -> S high, T or U;
    - asm10 holds to about 6-8%;
    - asm20 holds to 12%;
    - mappy under asm5 or asm10 degrades to U only (`scripts/probe_divergence_sweep_mappy.py`).
- **Why it matters.**
  - An introgressed segment from a divergent donor, inside an otherwise near-identical pair (near-isogenic lines,
    cultivars with wild introgressions), is exactly this tool's target.
  - There it produces confident, wrong mechanism calls: high-tier D, so the derived-absence counts of DESIGN 7.8
    are wrong. It also turns informative E into missing, a bias against donor-derived tracts.
  - This contradicts the anti-goal "a forced call: every locus gets unresolved when evidence is weak".
- **Scope.** main3 (maize, d about 0.033, asm20) and the bake-off decision are **unaffected**, so the fix can wait
  for `main3/run.exit` like the rest of the fix wave. Fix it before any non-maize run or Plan 3's simulation grid.
- **How to fix.** Simplest and principled: run LASTZ with asm20 scoring for every pair. That is the only measured
  configuration, and its 80%-identity floor is the classifier's own Wicker rule. Then update DESIGN 5.3 and the
  `lastz_args` docstring.
  - If per-divergence scoring stays, validate asm10 and asm5 on sims at d <= 0.01 and <= 0.001, with divergent
    tracts, before enabling them.
  - Either way, add a regression test: a close pair with a 5%-divergent patch gives E or P, or U, and never a
    high-tier D.

### Important

**I1. The QC metrics do not compute DESIGN 10.1's bars. Two of the three expected real-data "misses" are largely
the definitions.**
- **Where.**
  - `src/ltrpav/loci.py:257-262` (`_reciprocity`) and `:222-254` (`_annotation_agreement`); docstring at `:41-51`.
  - The definitions come from Task 21 ruling 6, a deviation from the spec that was never recorded as one.
  - `task-25-rulings.md` already plans to report reciprocity (0.84-0.91 on chr10) and annot_agree (about 0.80)
    "plainly as misses".
- **What is wrong: reciprocity.**
  - DESIGN 10.1: "A->B and B->A agree ... >= 0.95 among loci resolved both ways".
  - The code divides links seen both ways by links seen either way. So it counts as disagreement:
    - a link whose reverse call is unresolved (D/O/G/U: 3-5% of links);
    - a pair called present both ways whose reciprocal-overlap link fails in one direction (boundary
      differences: about 120 per pair).
  - On the bake-off's chr10 flank-mm2_2k run, recomputed per DESIGN (`scripts/probe_reciprocity.py`):

    | pair | implemented | per DESIGN 10.1 |
    |---|---|---|
    | B73~TIL18 | 0.875 | **0.988** |
    | B73~TIL01 | 0.900 | **0.994** |
    | TIL18~TIL01 | 0.840 | **0.986** |

    The mm2 run gives 0.991-0.996. **The bar passes; the QC would report a miss.**
- **What is wrong: annot_agree.**
  - Its denominator counts every call whose site overlaps a B element by 1 bp or more. DESIGN asks about "a B
    annotated element at the projected site".
  - In the same run, 73-80% of the disagreeing calls are E or D sites lying more than 1 kb inside a B element
    (`scripts/probe_annot_agree.py`). These are B elements spanning the site, mostly hosts annotated only in B.
    That is the e_in_annot story, which DESIGN already calls an upper bound.
  - With those set aside, annot_agree is 0.93-0.96. The 1-kb cut is only my probe's yardstick, so treat this as
    indicative.
  - e_in_annot also counts E sites "inside" a B element, where DESIGN says "overlapping".
- **Why it matters.** Task 25's QC.md, and any paper built on it, would understate genotype concordance and send
  the investigation after an artifact of the metric.
- **How to fix.**
  - Add a reciprocity metric that matches DESIGN: among links whose two calls are both resolved (P/S/T/E), the
    fraction where both are present. Keep the current number under a name such as `link_symmetry`.
  - Restrict annot_agree's denominator to B elements at the site, or label it an upper bound next to e_in_annot
    in DESIGN 10.1.
  - Task 25's QC.md should report the DESIGN definitions, plus the decomposition.

**I2. Rerunning into an existing outdir can silently keep stale calls, and the manifest does not record LASTZ.**
- **Where.**
  - `src/ltrpav/genotype.py:82-88`: the pair key holds the anchors, both FASTAs, the elements, the backend name and
    the preset.
  - `src/ltrpav/checkpoint.py:53`: the only code identity in a key is `__version__`, which has been "0.1.0.dev0"
    across every engine change in this range.
  - `src/ltrpav/outputs/manifest.py:19`: `_TOOLS` lacks lastz (and makeblastdb).
  - `src/ltrpav/anchor/mm2.py:167`: the index key carries no minimap2 version.
- **What is wrong.**
  - The pair key omits the windows, the window and classifier constants, the LASTZ options and version, and the
    classifier code. The pair-level `is_done` check runs before the windows are rebuilt.
  - So a rerun after any classifier or window change keeps the old calls: rule 5a (24G), 24H's tightening, the
    merge fix, and this review's fix wave. So does a rerun after a LASTZ upgrade.
  - The manifest cannot say which LASTZ produced the calls.
- **Why it matters.**
  - DESIGN 6 requires dependency versions; DESIGN 8 requires resumes keyed by parameters.
  - Practically: if the final fix wave changes calls and main3 is rerun in place, its pair files are reused
    unchanged.
- **How to fix.**
  - Add an engine signature to the genotype stage keys: a hash of the classifier, window and localign constants,
    `lastz_args(preset)`, the lastz version string, and an explicit `CALLS_REV` integer bumped with any rule
    change.
  - Add the windows file checksum to the pair key, and lastz (plus makeblastdb) to the manifest.
  - Until then, rerun into a fresh outdir, or delete `pairs/` and `work/calls/`, after any engine change.
  - This folds in deferred minors 24H(1), T15 (index key) and T17 (FastGA version).

**I3. One malformed annotation record aborts the run with no context, and sometimes with a traceback. DESIGN 8
says warn and skip.**
- **Where.**
  - `src/ltrpav/annotation/gff3.py:81` parses the coordinates of *every* line before checking its type.
  - `annotation/bed.py:53`; `annotation/ltrquest.py:37, 57-58`.
  - `annotation/__init__.py:109` wraps only ValueError and FileNotFoundError; `cli.py:54` handles only ValueError,
    RuntimeError and OSError.
  - `blocks.py:78` is the PAF route's equivalent.
- **Evidence** (`final_review/badinput/`).
  - One `gene` line with coordinate `2O100` in a GFF3, a feature the loader never uses, gives `error: invalid
    literal for int() with base 10: '2O100'`: no file name, no line, exit 1.
  - BED behaves the same way.
  - An LTRquest table missing `ltr3_end` exits with a raw Python traceback (TypeError), which breaks the CLI's
    one-line-error contract.
- **Why it matters.** EDTA GFF3s run to millions of lines across every TE type. The user can neither find the
  record nor run past it. DESIGN 8 says "warn and skip minor issues (one malformed record), with counts".
- **How to fix.**
  - Parse coordinates only for the LTR-RT and LTR features.
  - Wrap each record in a try block: warn and skip it, count it in `skipped_<reason>` (it already reaches QC), and
    name the file and line in the first warnings.
  - Validate the LTRquest header once, with an AnnotationError naming the missing columns.
  - Folds in deferred minors T5, T6 and T7 (malformed-record parts) and T9.

### Minor

- **M1. The `inv` flag means the contig's orientation, not an inversion, on unoriented scaffold assemblies.**
  - Where: `src/ltrpav/classify.py:403`; DESIGN.md:241 ("window inside an inverted block").
  - Evidence: on fragmented B (half the contigs reversed), 177 of 477 calls carry `inv`, against 18 for the real
    300-kb inversion unsplit.
  - Plan 2's inversion analysis (7.7) and the sims' inv-flag scoring must not read it as biology.
  - Fix: document it as orientation relative to A, or derive inversions from the net's `inv` place (inverted fill
    in a parent's gap).
- **M2. VCF POS is 1 bp right for E sites without a readable TSD copy.**
  - Where: `src/ltrpav/outputs/vcf.py:77` (`POS = end`); the site is the two junction bases from
    `classify.py:253, 258-261`.
  - The insertion lies between `start` and `end`, so POS should be `start`. This affects 13 of 115 E calls on R1_s1.
- **M3. Thresholds outside `constants.py`** (Global Constraint):
  - `localign.py:291-292` (LASTZ_SCORING, LASTZ_SEED; deferred 24H(3));
  - `window.py:17` NCAND; `anchor/mm2.py:38` PRESET; `annotation/bed.py:18-19`;
  - `anchor/flanks.py:44-45`: BLAST_MAX_TARGETS and BLAST_MAX_HSPS, with no reason given.
- **M4. DESIGN.md is stale or deviates in places.**
  - §9, lines 443-451: still claims the LASTZ port is byte-identical (no longer true since 7d71073), and lists
    "caveats to address before Task 25", two of which are fixed (deferred 24H(4)).
  - §5.1, lines 178-183: "adaptive" k-mer-unique flanks "capped at ~10-20 kb" (deferred M11). In fact cap =
    target = 2 kb, so the flanks are not adaptive, and build decision 3 dropped the k-mers. The same lines say
    "multi-mapping locus is U", but the code only lowers the tier: about 1% of resolved chr10 calls, never at high
    tier.
  - Lines 172-175 and `chain.py:286-289`: the named costs omit the mirror cost (deferred 24F).
  - §5.4, lines 258-259: "other tolerances come from each genome pair's own data". The code uses fixed Wicker
    constants, which is principled, but the deviation should be recorded.
  - §5.6, line 295: "calibrated".
  - Lines 81, 94, 104, 415 and 518 cite "CLAUDE.md", in a file headed for GitHub. These predate this range.
- **M5. CI never runs the default window aligner.**
  - Where: `.github/workflows/ci.yml:34-37` installs with pip only, so there is no lastz, minimap2 or bcftools.
  - Every `needs_lastz` test is skipped silently, including the default end-to-end run.
  - Deferred to Plan 4 by ruling; it must land (setup-miniconda with bioconda) before the first push.
- **M6. `ltrpav-sim pair` needs LTRquest's `confidence == "high"` donors.**
  - Where: `src/ltrpav/sim/cli.py:112` and `sim/pair.py:128-129`.
  - It therefore fails on EDTA or BED annotations, which hampers species-portable benchmarking (Plan 3).
  - Fix: fall back to every top-level childless element when no element has a confidence value.
- **M7. One straggler chunk nearly doubled the pair's genotyping wall time.**
  - In main3, 254 of 256 chunks had finished 8.5 min into genotyping; the last, chunk 249, finished 11.5 min
    later.
  - Where: `genotype.py:274-290`, chunks in A order.
  - It is within the cost bar. Consider submitting large-span windows first, splitting them out of their chunks,
    or logging windows that take more than about 60 s.
- **M8. American English.** "cancelled" in docstrings (`genotype.py:9, 260`) should be "canceled". The method name
  `cancelled()` is the library's.

## Deferred minors re-checked (progress.md line: status)

- L74 T1 lock file (`ltrpav==` pip line, machine `prefix:`): **still applies** (environment.lock.yml:111, 113).
- L75 T1 smoke test spacing and env assert: **still applies** (tests/test_smoke.py:8-9).
- L76 T1 `-q` twice; old license style: **still applies** (pyproject.toml:10, 56; ci.yml:37).
- L81 T2 run.sh and README (outside the repo): **moot**; the yardstick finished.
- L86 T3 seqio re-raise decided by string match: **still applies** (seqio.py:80).
- L87 T3 tests miss the bgzip cache branch, close() and others: **still applies**.
- L88 T3 stale cached .fai trusted; concurrent writers race: **still applies** (seqio.py:55, 71).
- L93 T4 FASTA path `.resolve()` follows symlinks: **still applies** (samples.py:80).
- L94 T4 empty fasta field, BOM, test gaps: **still applies**.
- L99 T5 LTRquest missing column, malformed numeric, `\r`, glob.escape, depth-sort test: **still applies**; the
  error-handling part is folded into I3 (ltrquest.py:21, 37, 57).
- L104 T6 GFF3 parses every line, malformed coordinate, NaN K2P, seqid escaping, negative tests:
  - **still applies**; folded into I3;
  - NaN K2P is now harmless (`tsd_allowance` ignores NaN).
- L107 T6 `_attrs` type hint and `_parents` key collision: **still applies** (gff3.py:23, 31).
- L113 T7 BED `\r` strand, non-integer coordinates, tests: **still applies**; folded into I3.
- L119 T8 stale nesting stack entries, tests, no start < 1 / start > end check: **still applies**
  (annotation/__init__.py:86-98).
- L124 T9 `a_to_b` divides by zero on an empty block, malformed PAF aborts, concatenate memory: **still applies**;
  folded into I3 (blocks.py:78, 101, 205).
- L133 T10 one base lost at a trimmed piece's end: **still applies** (inherent; chain.py:449-466).
- L138 T10 DP terms untested, CHAIN_INDEL_COST reason, strand > 0 vs >= 0: **still applies** (constants.py:15).
- L145 T10 conftest makes the THP assertion unfalsifiable; constants nits: **still applies**
  (tests/conftest.py:4; constants.py:11, 17).
- L159 T11 untested window branches, missing `_try_merge` guard, bare KeyError: **still applies** (window.py:81,
  123).
- L170 T12:
  - U toy cases pinned in test_localign: **fixed** (test_localign.py:262-333);
  - loose `match="CIGAR"` and the duplicated INTh split: **still apply**.
- L183 T13 refinement windows clipped independently, `_slide` untested, throughput: **still applies**
  (junction.py:56-64).
- L203 T14:
  - DESIGN's boundary_offset: **fixed**;
  - 1-bp TSD read, undeduplicated visit loop, reimplemented AlnMap lookups, no tsd_b/tsd_mm on S calls: **still
    apply**.
- L220 T15 corrupt same-size npz, index key without tool version, Protocol vs getattr, thread scaling:
  **still applies**; the key part is folded into I2.
- L224 T15 blocks docstring "every column kept once", stale MM2_OVERLAP reason: **still applies** (blocks.py:141;
  constants.py:23).
- L225 T15 pieces under ANCHOR_MIN lost at a core cut: **still applies** (mm2 route only, not the default).
- L236 T16:
  - DESIGN's "long join": **fixed**;
  - ALL_CHAINS cost: **moot** (strand-split mapping, then LASTZ).
- L241 T16:
  - pool error path: **fixed** (tested);
  - chunk granularity: **fixed** (24F adaptive chunks);
  - hard-coded column positions, no fai-order test, stale files, npz timestamps in keys: **still apply**
    (genotype.py:358, 375-376).
- L246 T16:
  - MAPPY_BEST_N reason: **fixed**;
  - "stops at once" (genotype.py:8), the initializer omits SamtoolsError, merge temp files not swept: **still
    apply**.
- L251 T16 PDEATHSIG fires when the forking thread exits: **still applies**, and is undocumented in
  `genotype_pair`.
- L259 T17:
  - `_link` FileExistsError: **fixed** (atomic `os.replace`);
  - FastGA version not in params (folded into I2), helper defined after use, readlink: **still apply**.
- L261 T17 checksum cache temp file named per pid only: **still applies** (checkpoint.py:125).
- L264 T17 .lock files and old indexes accumulate; flock on NFS: **still applies**.
- L274 T18 flank-mm2 toy test checks only P/E/D, no sequence-end cases: **still applies** (test_flanks.py:77-84).
  test_cli's default-configuration world run mitigates it.
- L278 T18 `test_pieces_many_elements` (14.7 s here) with a wall-clock assert: **still applies**.
- L288 T19 malformed B sites accepted, "not 29" message, untested branches: **still applies** (loci.py:412-417,
  677-678).
- L296 T20 no fai-vs-lexicographic test, tracks KeyError, BED escaping, manifest's local import and no stdin:
  **still applies** (tracks.py:40, 51; manifest.py:35, 45).
- L302 T21 label "all" not reserved, merge can't detect stale pair files, `.fai` race, checksum timing: **still
  applies**.
- L305 T21 INFO volume, duplicate warnings, `_open` mislabels outdir errors, no stages module: **still applies**
  (cli.py:194, 260-263; genotype.py:120-122).
- L331 T22 O decided by shared target ids (about 1e-5): **still applies** (simulator).
- L338 T23 duplicate truth keys overwrite, unknown states, gz detected by suffix: **still applies**
  (sim/score.py:31-58).
- L373 T24F:
  - mirror cost unnamed (M4), loose test (b) wording, perf test: **still apply**;
  - minus-strand parent untested: **still applies**, but my probe shows the behavior is right;
  - INFO line without the pair label: **still applies** (chain.py:384).
- L376 T24G missing-binary test depended on PATH: **fixed** (the test sets PATH itself).
- L379 T24G:
  - `_solo_tsd` computed twice: **still applies** (classify.py:288-292, 310);
  - the 5a inheritance test covers only an unanchored host: **still applies**;
  - TSD exception without position: **fixed** (3781931; classify.py:291-292).
- L417 T24H:
  - (1) keys: **still applies**, folded into I2;
  - (2) merged windows report outer anchors for interior elements: **still applies** (window.py:89-92);
  - (3) LASTZ constants outside constants.py: **still applies** (M3);
  - (4) DESIGN §9 stale: **still applies** (M4);
  - (5) /dev/shm folder and orphaned lastz on kill: **still applies**;
  - (6) no LASTZ inv_site test on window-sized flanks: **still applies** (test_lastz.py:23);
  - (7) "95 kb" docstring: **still applies** (classify.py:279);
  - M11's DESIGN 5.1 text: **still applies** (M4).

## Declined to judge

- **The bake-off's decisions** (route, cap, LASTZ over mappy, the readings of "cheaper"): decided under fixed Task
  24 rules and reviewed. I checked the port and its unmeasured presets (C1), not the decision.
- **The 2-kb flanks' false E in segmental duplicates:** a known caveat, measured by Task 25's audit.
- **Task 25 and main3's results and QC.md:** the run is still in progress, so out of scope here.
- **Plan 2 analyses** (stats, painting, inversions, direction, figures): not in Plan 1.
- **Plan 4 packaging** (Dockerfile, recipe, CITATION.cff, CHANGELOG, a README for biologists): DESIGN 8 items
  that the plan defers.
- **The simulator's event model and truth rules:** reviewed in depth in Task 22. I did not trace the one
  precise-deletion truth D on R1_s1 (bb0230, whose E call 4 children inherit).
- **FastGA's loss under the syntenic net and CHAIN_LOOKBACK's density dependence:** a non-default route, logged as
  a deferred lead.
- **flank-blast's cost and `-max_target_seqs` on scaffold-rich genomes:** a non-default route that fails the cost
  bar.
- **Real-data U, D and O levels** (B73->TIL18: U 15%, D+O 39%): biology and assembly, for Task 25 to interpret.
- **Whether per-pair, data-derived tolerances would beat the fixed Wicker constants** (DESIGN 5.4): I flagged
  only the documentation gap (M4).
- **Pangenome scale (30+ genomes), non-Linux platforms and Python 3.14's start methods:** v2 or outside the CI
  matrix.
- **Unannotated repeats inside flank pieces** (no k-mer uniqueness test): build decision 3, approved by the user.
- **The bake-off scripts' own deferred minors:** outside the repo.

## Recommendations

1. **Fix C1 first.** Pin LASTZ to asm20 scoring, or validate asm10 and asm5, and add the close-pair regression
   test. main3 needs no rerun for it (asm20).
2. **Fix I2's keys before the fix wave reaches any finished outdir**, so reruns cannot reuse stale calls. Rerun
   main3 into a fresh outdir if any fix changes calls.
3. **Have Task 25 report reciprocity as DESIGN defines it (I1)**, with the current metric as link symmetry, so a
   passing bar is not written up as a miss. Treat annot_agree as an upper bound.
4. **Make annotation loading warn and skip, with file:line context (I3).** This is cheap, and EDTA inputs at
   genome scale need it.
5. **Minor wave:** M1-M8; refresh DESIGN.md (§5.1, §5.4, §9, the CLAUDE.md mentions); give CI bioconda tools
   before the first push.

## Assessment

**Ready to merge: With fixes.** The engine is well built, heavily tested (784 passing under `-W error`) and fast
on whole maize genomes. But the default LASTZ backend gives wrong high-tier calls for close genome pairs (C1).
The QC definitions also misreport a passing DESIGN bar (I1), and stale-call reuse (I2) and malformed-input
handling (I3) need fixing before results leave maize.

## Re-review (fix wave): 7d71073..0ff06eb (21 commits, 54 files)

Date: 2026-11-11. This is a scoped re-review of branch plan1-final-fixes.
- **Code tested.** Snapshot of 0ff06eb (`git archive`) at `benchmark_pav/final_review/snap_ff`, imported through
  PYTHONPATH. I never used the worktree or the main tree; the main tree is untouched (HEAD 7d71073, clean).
- **Suite.** Run once from the snapshot under `-W error`, nothing deselected: **864 passed in 96 s**. ruff is clean.
- **Probes.** Scripts, data and logs are under `benchmark_pav/final_review/{scripts,calls,close5,badinput,fp_probe}`;
  8 threads at most.
- **Inputs read.** The diff, the fixer's report with its Follow-up, and the controller's brief.

### Verdicts on the review's findings

| finding | verdict | evidence |
|---|---|---|
| C1 asm5/asm10 LASTZ scoring | **ADDRESSED** | See note 1 below. |
| I1 QC definitions | **ADDRESSED** | See note 2 below. |
| I2 stale checkpoints, manifest | **ADDRESSED**, with a new problem (N1 below) | See note 3 below. |
| I3 malformed annotation records | **ADDRESSED** | See note 4 below. |
| M1 `inv` is orientation | **ADDRESSED** (docs) | The classify docstring and DESIGN 5.4 say it is orientation relative to A, and that inversions come from the net's inverted fills. |
| M2 VCF POS of junction-sited E | **PARTIAL**, documentation only (accepted by the controller) | POS is still 1 bp right. The `##LTRpav_POS` header line, the vcf docstring and DESIGN 6 now say so. |
| M3 thresholds outside constants.py | **ADDRESSED** | LASTZ_SEED, NCAND, MM2_PRESET, BED_LTR_EDGE/MAX and the BLAST limits are in constants.py, with reasons. |
| M4 DESIGN.md stale | **ADDRESSED** | See note 5 below. |
| M5 CI never runs lastz | **NOT ADDRESSED** (deferred to Plan 4 packaging by ruling) | CI is still pip-only, so every `needs_lastz` test skips there, the new C1 regression test included. |
| M6 sim donors need confidence | **ADDRESSED** | An unrated annotation gives every top-level, childless element (`sim/cli.py` `_donors`). |
| M7 straggler chunk | **ADDRESSED** | Chunks are submitted largest first (summed window spans; calls unchanged, below). A single slow window still bounds its chunk; the effect on whole genomes is unmeasured. |
| M8 "cancelled" | **ADDRESSED** | |

Notes to the table:
1. **C1.** `lastz_args()` takes no preset and always uses SCORE (asm20; `localign.py`). mappy keeps PRESET_CUTS.
   - My six close pairs (d 0.0007-0.0009, so the pair preset is asm5) now give **24 of 24 right** (E 12, P 12),
     against 4 of 24 at 7d71073.
   - Test `test_close_pair_with_divergent_patches` uses a preset spy to prove the pair really selects asm5.
2. **I1.**
   - Definitions, all as DESIGN 10.1 states them:
     - `reciprocity`: among links with both calls resolved, the share with both present;
     - `link_symmetry`: the old quantity, renamed;
     - `annot_agree`: sets aside B elements reaching more than w (two TSD lengths, an existing tolerance) past
       both site ends;
     - `e_in_annot`: now overlap, not inside.
   - Running the head's `build_loci` on the bake-off's six chr10 flank-mm2_2k pair files:
     - reciprocity 0.9878, 0.9942, 0.9859, which equals my independent probe;
     - link_symmetry 0.875, 0.900, 0.840, the old numbers;
     - annot_agree 0.979-0.989; e_in_annot 0.142-0.161.
   - The tests use hand-computed values. The bars are unchanged.
3. **I2.** `stage_key` holds `engine_fingerprint()`, and every stage's params hold its tools' versions: lastz for
   genotyping; minimap2 and mappy for the index and the mm2/flank routes; FastGA's binary hash.
   - The manifest records the engine fingerprint and all tool versions, lastz included. `ltrpav-merge` refuses
     pair files from another engine or annotation.
   - Probes: the fingerprint is deterministic across processes. A `classify.py` edit changes every key; a `sim/`
     edit changes none.
4. **I3.** Probes from my first review, rerun on the head:
   - a malformed `gene` line: the run completes with no warning;
   - a malformed LTR-RT line: `file:5: record skipped, malformed_coordinates: ...`, a skip-count line, and the
     run completes;
   - an LTRquest table without `ltr3_end`: one error line naming the file and the column, with no traceback;
   - BED: a `file:line` warning, then the "no usable record" one-liner (my BED's only other record has no LTRs).
5. **M4.** DESIGN 5.1, 5.4, 5.6, 9 and 10.1 are refreshed.
   - DESIGN 9's new claim, "17 sim calls (all six sims)" changed state after Task 24H, is exact. My count over
     all six sims, both directions, against the bake-off's flank-mm2_2k_lastz: 17 (U->E 6, U->D 4, T->U 4, U->O 2,
     E->U 1).
   - "CLAUDE.md" no longer appears in DESIGN.md. Commit 1817fda's *message* still names it; the controller left
     that for the user.

### Deferred minors the fixer marked fixed: spot-checks
Every item I checked holds:
- **L74** lock file: no `prefix:`, no pip line, a comment instead.
- **L75 / L145** THP guard: checked in a fresh interpreter, both default and user-set.
- **L76** `-q` once in CI. The license style stays partly fixed, as reported.
- **L86 / L88** plain gzip rejected up front; cache index named by size and mtime; built atomically.
- **L93 / L94** abspath keeps symlinks; BOM, empty fasta field and reserved "all" handled.
- **L107** `_attrs` returns the parents apart.
- **L138** reasons fixed; strands compare as > 0 everywhere. Blocks only carry ±1, so nothing changes.
- **L159** merge guard added; KeyError replaced by ValueError.
- **L170** INT_SPLIT; exact match strings.
- **L224** docstring and MM2_OVERLAP reason.
- **L241** column positions now come from CALL_COLUMNS. The npz timestamps are moot: netted anchors are
  byte-identical across the two engines, verified on R1_s1 and chr10.
- **L246 / L251** docstrings, PDEATHSIG note, temp-file sweeps.
- **L261** temp names carry the pid and thread.
- **L278** the test now takes 4.1 s.
- **L288** site validation. The six real chr10 pair files pass it.
- **L296** tracks raise ValueError; BED columns escaped; manifest goes through `tool_version` with stdin
  DEVNULL.
- **L379** `_ltr_image` is computed once.
- **L417 (24H):**
  - (2) each element's own anchor distances: unmerged top-level calls are unchanged;
  - (3) constants moved; (4) DESIGN 9 refreshed;
  - (5) SIGTERM cleanup: code read, but no kill was exercised;
  - (6) `inv_site` added to CUT; (7) 88 kb.

### Calls: 0ff06eb against 7d71073
Default runs with both snapshots, in fresh outdirs:
- `ltrpav run` on sim R1_s1, both directions;
- `ltrpav-genotype --pair B73v5,TIL18` on chr10 (default route; each engine recomputed its anchors).

Script: `scripts/compare_calls.py`. Results:

| data | calls | columns other than anchor_left/right | anchor-column differences | netted anchors |
|---|---|---|---|---|
| R1_s1 A->B | 477 | none | 250: nested 172, merged-window 78 | byte-identical |
| R1_s1 B->A | 466 | none | 246: nested 179, merged-window 67 | byte-identical |
| chr10 B73v5->TIL18 | 9,064 | none | 6,410: nested 2,522, merged-window 3,888 | byte-identical |

- **The fixer's claim is confirmed.** No state, tier, flag, reason, site or evidence value changed. Every
  anchor-column difference is a nested element or a top-level element of a merged window. The counts match the
  fixer's.
- **Merged outputs (R1_s1).** loci.tsv, pav_matrix.tsv, the tracks and pav.unplaced.tsv are identical, and so is
  the VCF apart from its one new `##LTRpav_POS` line. qc.tsv differs only in the I1 metrics:
  - reciprocity 0.879 -> 1;
  - link_symmetry added;
  - annot_agree 0.986 -> 1 and 0.946 -> 0.990.

### New problems in the fix diff

**N1 (Important): the engine fingerprint covers modules that no checkpointed stage depends on. An edit there
recomputes all genotyping and blocks `ltrpav-merge`.**
- **Where.** `src/ltrpav/checkpoint.py` (`engine_fingerprint`, `NON_ENGINE = ("sim",)`) and `cli.py`
  (`_check_pair_files`).
- **Evidence** (`fp_probe/`).
  - Appending one comment line to `outputs/vcf.py`, `loci.py`, `cli.py` or `constants.py` changes the fingerprint
    and every stage key (a `sim/` edit changes none).
  - End to end, after a comment added to the VCF writer only:
    - `ltrpav-merge` refuses the pair files ("2 pair file(s) written by another engine");
    - `ltrpav run` re-indexes, re-anchors and re-genotypes both pairs.
  - `outputs/` and `loci.py` feed only the merge, which is never checkpointed, so including them protects nothing.
- **Why it matters.**
  - On main3 that is about 25 min per maize pair at 32 threads x 9 pairs, about 3.5-4 h, for edits that cannot
    change a call.
  - Plan 2 (docs/plans/2026-11-11-plan2-analyses.md) edits `constants.py` (Task 1 appends MG_MAX and
    IDENT_MIN_SITES) and `cli.py` (Task 10 adds stats_main, paint_main and plot_main). Each edit invalidates
    main3's genotyping and makes `ltrpav-merge` refuse its pair files. The follow-up's stated goal, "an analysis
    edit never recomputes hours of genotyping", therefore fails for the very next plan.
  - Separately, `stage_key` has no hook for a non-engine package's own fingerprint. An analysis package that
    joins NON_ENGINE, as the docstring instructs, would have stage keys blind to its own code: I2's stale-result
    bug again, for Plan 2's stages.
  - Correctness of genotype calls is not affected (this only over-invalidates).
- **How to fix** (small; no call changes):
  - (a) Add `outputs` to NON_ENGINE, and exclude `loci.py`, perhaps moved into a merge subpackage.
  - (b) Keep the elements stage's code in an engine module and leave the CLI glue out, or fingerprint each stage
    over its own import closure.
  - (c) Keep Plan 2's constants and commands in its own package (`analysis/constants.py`, `analysis/cli.py`,
    with console scripts pointing there), or hash the values of the constants the engine imports rather than
    `constants.py`'s bytes.
  - (d) Give `stage_key` a package fingerprint argument for non-engine stages.
  - Do this before Plan 2 Task 1, or amend Plan 2 so its edits stay outside the fingerprinted modules.

Nothing else found. The worker SIGTERM cleanup, the dead-pid temp sweeps and the stale-chunk removal look sound:
they skip live pids and other users' folders, and stale chunks are judged by index. So do the LPT ordering, the
loader rewrites, the seqio changes (atomic index builds; FASTA symlinks kept) and the merge-time pair-file
checks.

### Assessment (fix wave)

**Ready to merge: With fixes.** C1, I1, I2 and I3 are addressed, the calls are unchanged as claimed, and the
suite and ruff are clean. Fix N1's scope before Plan 2 begins, so Plan 2's planned edits to constants.py and
cli.py do not invalidate and block main3's genotyping. M2 (documentation only) and M5 (Plan 4) stand as the
controller ruled.

## N1 check: commit 12279a1 ("Key each stage on the modules it depends on")

Date: 2026-11-11.
- **Code tested.** Snapshot of 12279a1 (`git archive`) at `benchmark_pav/final_review/snap_n1`, imported through
  PYTHONPATH. The main tree is untouched.
- **Suite.** Run once from the snapshot under `-W error`, nothing deselected: **886 passed in 96 s**. It includes
  the new tests:
  - `test_stage_keys_follow_their_modules_only`, over 22 edited modules;
  - `test_stage_modules_are_each_stages_import_closure`;
  - `test_package_fingerprint`.
- **Probes.** `scripts/n1_probe.sh` and `n1check/`.

**R1 holds.** STAGE_MODULES declares each cached stage's set: elements, anchor, raw, blastdb, mm2_index,
genotype_pair and genotype_chunk.
- The closure test checks each set against the static import closure of the module holding that stage's code, and
  my own reading of the imports agrees.
- Nothing hides from the closure:
  - There are no dynamic imports (no importlib, `__import__` or entry points) in any engine module.
  - The only function-level import, `flanks.HybridRoute.raw_blocks`'s `from . import _raw_blocks`, stays inside the
    anchor package. The rest are TYPE_CHECKING imports, used for types only.
  - The route registry (`get_route`) instantiates classes of the anchor package only.
  - The built-in window backends are a literal dict in localign.py, which is in the genotype set.
  - The numba-compiled functions live in chain.py and junction.py, both in their stages' sets.
- R1_s1 rerun under 12279a1 is byte-identical to the 0ff06eb run: pair files, windows, netted anchors, elements,
  loci.tsv, pav_matrix, qc.tsv, VCF and tracks. Only the manifest changes, where `code` now holds every stage's
  fingerprint in place of `engine`.

**R2 holds.** My probe ran on copies of a finished R1_s1 outdir:

| comment added to | `ltrpav-merge` | `ltrpav run` |
|---|---|---|
| `outputs/vcf.py` | accepts the pair files | skips every stage (elements, anchors, calls) |
| `cli.py` | accepts the pair files | skips every stage (elements, anchors, calls) |
| `classify.py` | refuses them ("written by other genotyping code") | reuses elements and anchors, recomputes only the calls |

**R3 holds.**
- `package_fingerprint(*modules)` exists and hashes every file of a named package. `stage_key(...,
  fingerprint=...)` takes a non-engine package's fingerprint.
- A stage outside STAGE_MODULES that passes no fingerprint is a ValueError. A later analysis package therefore
  cannot accidentally key its stages without its own code: the trap N1 raised is closed.

**R4 holds.** `_check_pair_files` compares the pair marker's `code` with `stage_fingerprint("genotype_pair")`, and
nothing else of the code (shown by the probe above).

**Dependencies the static closures cannot see** (Minor, API-only, not reachable from the CLI):
- **External window backends.** A window backend registered from outside the package through
  `localign.register_backend` has code in no set, and `backend_version` returns None for any name it does not
  know.
  - Swapping a registered backend's code leaves the genotype keys unchanged (probe).
  - Re-registering a built-in name is worse. The bake-off's `backends.py` registers its own `"lastz"`, and the keys
    then still carry the lastz binary's version, so its calls are indistinguishable from the built-in's.
  - Fix: `register_backend(name, fn, version)` that refuses built-in names, with `backend_version` returning that
    version.
- **The index stage's FASTA object.** The mm2_index stage calls `Fasta.lengths()` (seqio, outside its set) for
  `minimap2 -I` and a name check. This cannot change the index's bytes: any `-I` above the genome size gives the
  same single-part index. Negligible.

**Residual planning note** (not a missed dependency). constants.py is rightly in every set, since every stage reads
thresholds from it. So Plan 2 Task 1's planned append of MG_MAX and IDENT_MIN_SITES to constants.py would still
recompute all genotyping and make `ltrpav-merge` refuse main3's pair files. Plan 2 should keep its constants in
its own package, e.g. `ltrpav/analysis/constants.py`.

**Merge verdict for plan1-final-fixes (12279a1): Yes.** N1 is fixed: R1-R4 hold and outputs are unchanged. The
external-backend gap is a Minor API follow-up, and the constants note belongs in Plan 2.
