# Task 11, fix round 2 of 5 (re-review: task-11-review.md, section "Re-review (fix round 1)": Approved, 5 new Minor)

Fix these. They are small, and Task 12 renders this figure as the preliminary result.

1. **N1.** In the |Z| < Z_SIG branch, the headline must follow the statistic, not claim equality. Write "R carries
   a, S b; the difference is not significant (|Z| < 3): no evidence of gene flow". Take the threshold's printed value
   from Z_SIG. Add a test at Z just below Z_SIG with unequal counts.
2. **N2.** E's short-legend clause "..., which makes B73 the recipient" attributes the role to E's merged counts.
   - The recipient is set by the sign of D_pav on the donor's loci. stats.tsv's roles row says: "recipient B73 by the
     sign of D_pav(B73,TIL01;TIL18) = +0.291".
   - Point to panel F, for example "...; the donor-sharing test (F) makes B73 the recipient", or drop the clause.
   - Check the definitions sentence ("roles from the data: ...") for the same misattribution. It should say the
     recipient is the sister with more donor-shared insertions in the donor-sharing test.
   - Add a test.
3. **N3.** The unreadable-FASTA test must not fail as root. Skip it when `os.geteuid() == 0`, or make the file
   unreadable another way.
4. **N4.** Restore the duplicate-key guard. Registering a key again with a *different* text raises; the same text is
   allowed. Add a test.
5. **N5.** Fix the two sources: B_pct_length and B_tract_length must cite real columns or "display/derived: end -
   start".
6. **Out-of-scope observation 1, in this task's code: the plot stage never checks that stats.tsv is current.**
   - In the plot stage, run `report.stale_parts(cat)` on the loaded catalog before drawing.
   - Standalone `ltrpav-plot`: if any part is stale, exit 1 with one `error:` line naming the stale part and saying
     to rerun the analyses, in the CLI's usual error style.
   - Inside `ltrpav run`: the plot stage runs right after stats and paint, so nothing should be stale. If something
     is, a figure error stays one WARNING with exit 0 (decision 7).
   - Add a test: a stats.tsv made before a catalog change is refused.
   - If `stale_parts` cannot recompute a part's key without options that only the stats command knows (for example
     `--identity`), do not invent a mechanism. Stop and report it; the controller moves it to the final wave.
7. **Out-of-scope observation 2: memo.md.** Remove or mark as superseded the old two-key example rule (line ~68) and
   the old phrase "plateaus near 1 arise without gene flow too" (line ~130). The run record must read as current.

## Process
- Re-render on the main3 view. Confirm the short legend's E sentence changed, and that nothing else changed in the
  numbers table except the deliberate text.
- Run the full suite (`python -m pytest -W error -m "not slow"`) and ruff.
- Commit with plain subjects. No trailers, nothing set.
- Append "Fix round 2" to task-11-report.md.
- Return only:
  - the commits;
  - the test line;
  - one line per item;
  - anything not done.
