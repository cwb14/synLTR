# Plan 2 draft: summary (revised after review, 2026-11-11)

**Plan:** `/data2/chris/maize_introgression/LTRpav/docs/plans/2026-11-11-plan2-analyses.md`
- 12 tasks, 1795 lines, about 16.2k words (DESIGN: 6.6k words). The growth over the first draft is the review's
  replacement texts and tables.
- **Review:** `plan2-review.md` (3 Critical, 11 Important, 15 Minor), applied under the controller's rulings. The
  writing-plans self-review was rerun after the edits: spec coverage, step scan, name and type consistency across
  Interfaces blocks, Review Focus, proportion.

## Tasks

1. **Foundations.** Adds scipy and matplotlib and the analysis constants.
   - The `Catalog` holds `loci.tsv`'s merged states plus each annotated genome's own calls from the pair files (`proj`,
     `ptier`, `pseq`, `pstart`, `pend`, `pstrand`; `pcls`, `pcls_by`, `ptier_by`, `proj_site`).
   - Toy run directories model the engine's per-call resolution and its `loci.tsv` merge, with per-genome `p_missing`
     and `p_member` and per-call overrides.
   - DESIGN section 12 records eleven build decisions, including the controller's fallback ruling.
2. **Statistics core.** `StatRow` and the long-format `stats.tsv`; block size; `block_ids` on explicit coordinates; the
   generic delete-one-block jackknife (LTRmix's unweighted form, its 3-block rule spelled out); `Findings`.
3. **Relationships.**
   - Run summary; pairwise shared-derived counts; PAV distances; the NJ tree rooted on the outgroup.
   - Sharing counts, which only pick the sister pair (binomial check).
   - KKSC symmetry p on loci the third genome discovers, read from its own calls.
   - `four_point_ok`; outgroup-conflict upper bound.
4. **Trio roles and tests.**
   - `counted` reads each row's discoverer's own calls (`gstar`). Fallback is limited to four-point-eligible genomes.
   - D_pav with blocks on D's coordinates as the discoverer reads them; strata by age, high tier (call tiers),
     informative-only nested collapse and no outgroup filter.
   - Gradient; resolution and outgroup-filter rows; f4-ratio with `resolved_D2`.
   - A null toy with unequal sister annotation checks that D_pav stays at about 0, while merged states would leak.
5. **Inversions.** Reversed runs merged across a few discordant loci (`n_discordant`), with `INV_MIN_LOCI` = 5 named
   a heuristic; breakpoint intervals; `inversions.tsv`.
6. **Painting.**
   - Classes from the recipient's own calls (the decoy from the sister's); a numba port of LTRmix's forward-backward and
     EM; both `L` and `mean_tract_bp` = L/(1 - pi).
   - Tract rule, decoy and +1 target-decoy q.
   - Shortest callable tract as lower and upper bounds; `youngest_k` and `youngest_u95` per tract; inversion flags.
7. **Direction (exploratory).**
   - n(X->Y) (disc=any), reported but not read as direction (unequal Ne).
   - DFOIL-alt with its own sign table; each pattern pair counted on loci discovered by a genome present in both
     patterns.
   - 4-LIST counts; resolution rows.
8. **Mechanisms.**
   - Per pair: states by family and age, with O split by `o_kind` and D by `d_kind` (D inside the element against
     beyond it).
   - Absences: E shown ancestral, D inside shown derived, the rest undetermined, with upper and lower bounds.
   - Absence events; Dollo placement with "missing" defined per event type; missingness.
9. **Identity layer (optional, `--identity`).**
   - Ortholog LTR divergence read through D's own calls, realigned with the engine's aligner; 200-site minimum.
   - Isolation split fit with a jackknife SE; LTRmix's mixture fit as the guard; the fit checked at LTRmix's five CDF
     points.
   - u95 and younger-than-split counts on the D_pav counted rows; fractions below the split.
10. **Stages and commands.**
    - Checkpointed stats and paint stages; the paint stage's key includes the pair files and `identity.tsv`.
    - Parts assembled into `stats.tsv` and `findings.txt`.
    - `ltrpav-stats`, `ltrpav-paint`; `ltrpav run` gains `--trio` and `--identity`; lazy imports keep
      `import ltrpav.cli` free of scipy and matplotlib.
    - A chr10 smoke test.
11. **Overview figure.** The making-figures skill is loaded first. Spec (story reworded per M11), layouts, the 3-page
    PDF, PNG, `overview_numbers.tsv`, `ltrpav-plot`, and the plot stage in `ltrpav run`.
12. **Preliminary main3 run and comparison.**
    - One scoring code for LTRpav and for LTRmix's own files: same weights, 1000 shifts, seeds; both weightings
      reported.
    - LTRmix's age counts re-binned; isolation and mixture split values quoted separately.
    - Verdicts "PASS (prelim)" or "MISS (prelim)"; the headline labeled a hypothesis.
    - Hand-off: Plan 3 simulations must include unequal Ne between taxa; the user is to confirm builder call 11.

## Decisions DESIGN does not settle (decision — reason — what changes if wrong)

Entries marked **[revised after review]** changed under the review and the controller's rulings. 53-60 are new.

**Inputs, outputs and stages**

1. **[revised after review]** Analyses read the run's files (`loci.tsv`, pair files, `work/elements`, `qc.tsv`, FASTA
   indexes) and never change the engine's formats. The catalog also reads each discoverer's own calls from the pair
   files — Plan 1's whole-genome runs stay valid; DESIGN 7.1 needs the discoverer's calls (review C1) — if engine-side
   evidence is later needed, a format change and a re-genotype follow.
2. **[revised after review]** The catalog is two-pass `loci.tsv` arrays plus every pair file streamed once into
   per-discoverer call arrays; mechanisms streams the pair files again for the evidence columns — merged states serve the
   any-discovery descriptions, the discoverer's calls every discovery rule — about 100 MB for main3; chunked reads would
   be needed for many more genomes.
3. Nesting comes from `work/elements/<label>.tsv` parent links, joined by member eid. Extra members of multi-member loci
   stay unmapped — `loci.tsv` writes only the first member — those elements are not collapsed into their clusters
   (`n_multi_member` bounds it).
4. `stats.tsv` is long format, with the `loci` column — one schema for every module, and DESIGN 7.1's declaration made
   machine-readable — presentation only.
5. Descriptive rates and counts carry n, but no SE or Z — SE and Z belong to test statistics — add jackknife SEs if
   wanted.
6. **[revised after review]** One checkpoint per command (stats, paint, plot). The paint key adds every pair file and
   `identity.tsv` when present — DESIGN 8, and painting now reads the pair files and the identity counts — a stage may
   rerun or skip needlessly.
7. `ltrpav run` runs stats, paint and plot after the merge; a figure error is only a warning — DESIGN "run =
   everything" (LTRmix) — n/a.
8. **[revised after review]** New CLI options: `--trio`, `--identity`, and `--threads` on stats. `cli.py` imports the
   analysis and plot modules inside the stage functions — few options; `ltrpav_bench` imports this tree without scipy or
   matplotlib (M14) — if the bench env must run analyses, install them there.
9. `--trio R,S,D` restricts every trio analysis to that trio, with no role inference — DESIGN "--trio fixes them" —
   users may have expected all trios plus one fixed one.
10. Any number of outgroups. Rules require all outgroups E (or none present, for set-asides), and the tree is rooted on
    the first — the sheet allows several — n/a.
11. Painting files are one per recipient (long format, `sister`/`donor` columns), plus the decoy files. Old painting
    files are removed before writing — several trios can share a recipient; the decoy is the figure's control — naming
    only.
12. Identity results: layer `identity` rows, a separate findings section, and `identity.tsv`; opt-in — "optional ...
    reported separately" — trivial to split later.

**Relationships and roles**

13. **[revised after review]** Sharing counts (merged states, any discovery, complete cases, no outgroup present) only
    pick the sister pair — complete cases avoid imputation, and DESIGN 7.2 sets old loci aside — depth can tilt a
    near-tie; the binomial warning covers it.
14. The sister-pair warning fires at a two-sided binomial p(n_top against n_second) >= 0.05 — conventional level — more
    or fewer warnings; roles unchanged.
15. **[revised after review]** `p_kksc` is `binomtest(n_x+z, n_x+z + n_y+z)` on loci the third genome z discovers, read
    from z's own calls. The fallback is four-point-eligible genomes, else `none`, and a note marks it
    anti-conservative. 4-LIST is reported as its ten pattern counts only — any-discovery counts let depth tilt the
    minorities (I1); DESIGN asks for counts as cross-checks — a full KKSC/4-LIST likelihood would add model selection.
16. PAV distance = the share of present-against-E loci among loci resolved in both genomes (merged, every locus,
    outgroups included). NJ breaks ties in sheet order and sets negative branch lengths to 0 — the simplest metric; the
    outgroup roots the tree — branch lengths change; the topology is robust.
17. Shared-derived pairwise counts: present in both, no outgroup present, E in another ingroup genome — "derived" means
    not fixed — counts shift with how fixed insertions are treated.
18. **[revised after review]** Ingroup E calls at loci an outgroup carries give an upper bound on the combined rate of
    ingroup false E and outgroup false presence — deep lineage sorting and parallel insertions also make them (M3) — if
    they are mostly errors, the bound is the estimate.
19. **[revised after review]** R = pair[0] if D >= 0, pair[1] if D < 0. A nan D keeps pair[0] (sheet order); LTRmix
    sends nan to pair[1] (M5) — a defined, documented tie rule — n/a.

**Trio tests and dating**

20. **[revised after review]** D must be present in the discoverer's own call. Fallback genomes (D unannotated) are only
    annotated ingroup genomes outside the trio that pass the four-point condition `d(R,S) + d(X,D) < min(d(R,X) +
    d(S,D), d(R,D) + d(S,X))`; with none eligible, the test is skipped with a WARNING naming the excluded genomes — a
    discovery genome inside the sisters' clade biases the null D_pav (+0.35, Z +6.7; C3). This is a controller ruling,
    recorded in DESIGN section 12; the user is to confirm — fewer fallback loci, or a skip.
21. **[revised after review]** The primary D_pav counts every call tier. `high_tier` = the discoverer's call tiers into R
    and S are high; a member's "annot" never enters — maximize loci while keeping robustness visible — medium and low
    calls add noise to the primary.
22. **[revised after review]** A locus's age is the K of its discovering copy (row `gstar`). Direction uses the median
    member K; tracts use R's copy — the discoverer always has K — copies differ only by sampling.
23. Age gradient = D(K=0) - D(K>=0.01), with a joint jackknife — one number for "excess concentrated in young
    insertions" — a three-bin trend test is the alternative.
24. **[revised after review]** Nested collapse keeps, per cluster key, the first *informative* counted row (I2) — an
    uninformative host must not hide its independent RD or SD children — undercollapses where the host is an extra or
    unannotated member.
25. The resolution warning fires when resolved fractions differ by > 0.1 (LTRmix's level, a named heuristic); joint
    coverage gets no warning — with 15-25% U per genome, joint coverage < 0.8 is normal — a smaller asymmetry passes
    unwarned; the fractions are always reported.
26. **[revised after review]** Block size comes from fai totals (smallest genome, LTRmix's 10-kb floor). Block coordinates
    are D's site as each row's discoverer reads it (`proj_site`) — DESIGN's "D's coordinates" also under fallback, in
    one genome's frame — scaffold-heavy assemblies get somewhat larger blocks.
27. The outgroup filter's removed fraction is always reported, with no warning threshold (read from D's calls) — Review
    Focus 3, and no principled threshold exists — a heavy loss could be overlooked.
28. **[revised after review]** The second-donor rule is unchanged (PAV distances). The f4-ratio uses the discoverer's
    calls and reports `resolved_D2` (M6) — LTRmix's rule on LTRpav's distances — an admixed sister-lineage member could
    qualify.

**Painting**

29. **[revised after review]** Painting reads the recipient's own calls: loci its call shows the outgroup carrying are set
    aside; missing is kept. The decoy reads the sister's calls (C1) — merged states would let S's and D's annotation into
    the classes — slightly more noise, or lost resolution.
30. The HMM runs over all recipient-discovered loci, with non-informative ones as missing — LTRmix; posteriors for every
    locus — n/a.
31. The target-decoy scale is the informative-locus ratio — robust to one-sided annotation depth (the review agrees) —
    q shifts by the ratio of scales.
32. **[revised after review]** Shortest callable tract:
    - lower bound: the fewest RD loci with no flanks (equivalent to missing flanks, since the chain is stationary);
    - upper bound: the same with 20 RS loci on each side;
    - middle locus index k // 2; bp = k × median spacing.

    — exact under the model, bracketing the answer (M7) — still model-bound.
33. Genome-wide posterior means in the tool are over loci, unweighted. Task 12 reports both weightings for both tools —
    DESIGN sets no weighting; the comparison must match LTRmix's length weighting (I8) — n/a.
34. Per-seqid painting rows (posterior mean, class share) — needed for the chromosome ranking — n/a.
35. Loci in inverted blocks are flagged; the fit is unchanged — DESIGN 7.7 — a masked fit is a later change.
36. **[revised after review]** The "any discovery" variant is a function parameter only, and keeps `loci.tsv`'s merged
    states, saying so in its `loci` — it is the variant Plan 3 tests under one-sided dropout — n/a.
37. **[revised after review]** Per tract:
    - `youngest_k`;
    - `youngest_u95`, with n = `ltr_len` and d = round(K n), replaced by exact donor self counts from `identity.tsv`
      when present;
    - findings caveats: K = 0 is not age 0, and gene conversion makes K too young (M2).

    — bounds that state their limits — may be too recent where conversion is common.

**Inversions, direction, mechanisms**

38. **[revised after review; corrected after re-review N1]** Inverted blocks: runs of >= 2 reversed rows are merged left
    to right. For each pair, the merge trims the fewest boundary rows u (end of A) and v (start of B) until A's last and
    B's first remaining rows are in reversed order, with u + v + rows between < min(|A|, |B|). Trimmed and between rows
    are `n_discordant`, and `INV_MIN_LOCI` = 5 (a named heuristic) counts distinct rows outside `n_discordant`. The
    1/5! argument was dropped (I6) — one or two misplaced loci must not split Inv4m — a real nested inversion inside a
    block is absorbed, but reported in `n_discordant` (29 for a 30-locus re-inversion).
39. **[revised after review]** Direction:
    - "sister taxon" = every ingroup genome outside X and Y;
    - n(X->Y), n(Y->X) and 4-LIST are complete cases on merged states, declared disc=any;
    - D_dir is reported but not read as direction (unequal Ne alone gives +0.93; I11);
    - each DFOIL pattern pair is counted on loci discovered by a genome present in both patterns, with its own calls
      (I9).

    — DESIGN leaves "sister taxon" open; three present genomes nearly saturate discovery — Plan 3's unequal-Ne and
    dropout runs decide.
40. **[revised after review]** DFOIL-alt (single-derived patterns dropped) with its own sign table (`DFOIL_ALT_SIGNS`,
    from the review's derivation and coalescent check), |Z| >= 3, nan read as 0 — the full-DFOIL table does not hold
    without single-derived patterns, and dfoil.py's dfoilalt mode reuses it (C2) — full DFOIL adds terminal patterns.
41. **[revised after review]** Absences: E is shown ancestral. D is split by `d_kind`: D inside the element is shown
    derived; D beyond it is undetermined. O at the site and complex O are undetermined. Findings give 1 - frac_E as an
    upper bound on derived absences and frac_D_inside as a lower bound (I3) — DESIGN 5.4: D and O do not say whether the
    insertion happened; D can be an A-only insertion of an unannotated unit — n/a.
42. Mechanism tables per ordered pair from the pair files; age and family from A's element — the evidence lives per
    pair — n/a.
43. Absence events from parent links and flags; `adjacent` calls are grouped per window. A multi-element D's origin stays
    open — no gap ids in pair files — two clusters in one window count as one.
44. **[revised after review]** Dollo:
    - the insertion goes above the MRCA of present genomes;
    - an E inside that clade makes the locus incongruent;
    - S, T and D losses are placed on maximal subclades;
    - "missing" is D/O/G/U for S and T events, O/G/U for D events; a D genome outside the clade is missing (I4).

    — no precise excision; D is not proof of presence — branch counts.

**Identity layer**

45. **[revised after review]** Orthologous LTR divergence: D's element is realigned against Y's site ± 500 bp with
    `align_window`, and Y's site comes from D's own call (C1). Substitutions are counted exactly in D's LTR columns,
    skipping N — no LTR counts in pair files; same aligner — placements may differ slightly.
46. **[revised after review]** Only P copies (per D's call) are compared, with >= 200 aligned LTR sites (`IDENT_MIN_SITES`,
    LTRmix's validated `--min-sites`; controller ruling on I7) — intact copies hold both LTRs; 200 matches LTRmix —
    fewer pairs than at 80.
47. Insertion ages for u95 come from aligning D's own two LTRs — exact, annotation-agnostic — very short LTRs drop out.
48. **[revised after review]** The split:
    - isolation fit with a jackknife SE;
    - LTRmix's mixture fit (`fit_mix`: isolation + gene flow with mean <= `MG_MAX` + tail, 18 starts) as the guard
      against gene-flow bias, with weights and AIC;
    - the fit checked at LTRmix's five CDF points (`pred_cdf`) (I7).

    — post-split gene flow pulls the isolation s down (LTRmix: 0.024% against a true 0.18%) — n/a.

**Figure, tests, final run**

49. Overview selection rules:
    - the lead trio is `--trio`, else the largest D_pav Z, and all trios are drawn as small multiples;
    - the example tract and locus are nearest the medians, after structural checks.

    — one figure per run; typical, never dramatic — display only.
50. The figure spec lives in the module docstring; the layouts go in the task handback — tool code — n/a.
51. **[revised after review]** Toy runs model the engine:
    - each member's call into each genome resolves independently (`p_missing` per genome);
    - `loci.tsv` merges like `loci.py`: a member is P/annot, a non-member takes the first resolved member call;
    - `p_member` is per genome; `ToyLocus.calls` overrides single calls (C1, I10).

    — tests must be able to show the merged-state leak and the rule that avoids it — toy tests may still miss
    real-catalog behavior (the Task 10 chr10 smoke test covers part of it).
52. **[revised after review]** Task 12:
    - one scoring code for both tools (same weights, 1000 shifts, seeds), with LTRmix's files rescored;
    - LTRmix's age counts re-binned to LTRpav's bins;
    - LTRmix's isolation (0.048%) and mixture (0.070%) splits quoted separately;
    - verdicts "PASS (prelim)" and "MISS (prelim)"; the headline labeled "hypothesis: one trio, no simulated null"
      (I8, I7, M13).

    — a fair head-to-head — n/a.
53. **New.** `Catalog.pcls_by`, `ptier_by` and `proj_site` gather each row's discoverer's call. `block_ids` takes
    explicit coordinates — fallback discovery mixes discoverers across rows, while blocks need one genome's frame —
    mechanics only.
54. **New.** The paint stage reads `identity.tsv`'s exact self counts when present, instead of recomputing them (M2's
    "exact self_counts with --identity") — no cross-stage recomputation — without `--identity`, u95 falls back to the
    K-based estimate.
55. **New.** The C2 branch-length test puts the two ancestral scenarios' migration at t = 3. Ancestral flow needs
    T12 < t < T34, and the review's shared t = 1 fits only the directional scenarios — test only.
56. **New.** I10's expected resolved fractions were recomputed for C1: about 0.85 for R and 0.40 for S, from D's own
    calls. The review's 0.94/0.74 were computed on merged states — C1 changes what is counted — test only.
57. **New.** The review's `s_200` row is not added, because the split fit itself now uses the 200-site minimum
    (controller ruling) — it would duplicate `s` — n/a.
58. **New.** M14 takes the review's second option: `ltrpav_bench` stays untouched (it lives under `benchmark_pav/bakeoff/`,
    never written), analyses run only in `ltrpav`, and cli imports lazily (test `test_cli_imports_without_scipy`) — if
    the bench env must run analyses, install scipy and matplotlib there.
59. **New.** DFOIL's "P1, else P2" is read per locus: the first listed genome that is a member there. Both are present in
    both patterns, so either discoverer is symmetric — if read per run instead, fewer loci.
60. **New.** The `fit_mix` test asserts 0.01 < w_flow < 0.1, because softmax weights make `w_flow > 0` vacuous — test
    only.

## Conflicts found and how they were resolved

1. **DESIGN 7.5 against the engine's outputs.** DESIGN calls ortholog divergence "free from the local alignment", but the
   pair files keep only `ident` over the element ± 1 kb; adding columns would force re-genotyping. Resolved: realign with
   the engine's `align_window`; formats unchanged.
2. **DESIGN 6 painting file names against multiple trios.** Several trios can share a recipient. Resolved: one file per
   recipient with `sister`/`donor` columns, plus decoy files (not listed in DESIGN 6).
3. **DESIGN 7.2's "impossible" outgroup patterns.** Deep lineage sorting (Zea's large Ne) also produces them. Resolved:
   reported as an upper bound on the combined rate of ingroup false E and outgroup false presence.
4. **DESIGN 7.1/7.3's "outgroup must be E" against a distant genotype-only outgroup.** Resolved: followed as written (now
   read from D's own call); the removed fraction is reported, with the `no_outgroup_filter` stratum beside it.
5. **`loci.tsv` omits the per-genome U reason and extra members.** Resolved: U reasons are read from the pair files;
   extra members stay unmapped (small).
6. **The brief swaps the taxa** (TIL18 parviglumis, TIL01 mexicana). DESIGN, Plan 1's sheet and the data say TIL18 =
   mexicana and TIL01 = parviglumis. Resolved: the plan follows DESIGN; roles are inferred and checked against the sheet
   (the review confirmed this).
7. **LTRmix code against DESIGN's "as LTRmix" ports.** Deliberate changes:
   - target-decoy scale on informative loci;
   - block size from fai totals;
   - second-donor rule on PAV distances;
   - split uncertainty by jackknife;
   - unweighted posterior means in the tool (both weightings in Task 12);
   - the nan role tie-break (pair[0]; LTRmix pair[1]).

   Now aligned with LTRmix after the review: the 200-site minimum and the five-point CDF fit check.
8. **DESIGN 8 commands against pyproject.** The `ltrpav-stats`, `ltrpav-paint` and `ltrpav-plot` entry points were
   missing. Resolved: added in Tasks 10-11.
9. **DESIGN 7.1's "the sisters' annotation never enters" against the engine's merged `loci.tsv` states (C1).** A member is
   P/annot whatever the discoverer's call says, and members' calls give other genomes extra chances to be resolved.
   Resolved: every discovery-ruled statistic reads the discoverer's own calls from the pair files; no format change.
10. **DESIGN 7.1's fallback ("any annotated genome other than R and S") against lineage sorting (C3).** A discovery genome
    inside the sisters' clade biases the null. Resolved: narrowed to four-point-eligible genomes (controller ruling;
    user to confirm).
11. **DESIGN 7.6's n(X->Y) against unequal Ne (I11).** Its null is non-zero whenever the taxa differ in Ne. Resolved:
    reported, not read as direction; DFOIL-alt is the direction statistic; Plan 3 simulates unequal Ne.
12. **DESIGN 7.8's "how often an absence is not ancestral" against DESIGN 5.4's D/O semantics (I3).** Resolved: shown
    ancestral (E) and shown derived (D inside) with bounds; the rest undetermined.
13. **dfoil.py's dfoilalt mode against the DFOIL-alt statistic (C2).** It decodes with the full-DFOIL sign table.
    Resolved: DFOIL-alt's own table.

## Review fixes applied

29 findings: 29 applied, 0 skipped. Three were applied with adjustments, each recorded above: I7 (decision 57), I10
(decision 56), M14 (decision 58).

The re-review (`plan2-review.md`, "Re-review" section) found 28 of the 29 addressed and I6 partial. It accepted the three
adjustments and the three additions (decisions 55, 60 and the five-point fit check) and raised N1-N5. All five are
applied:

| Re-review | Where it landed |
|---|---|
| N1 merge rule could not merge across a displaced locus (I6 partial) | Task 5: the reviewer's corrected rule (candidates of >= 2 rows; trim the fewest boundary rows; merge across short runs; `INV_MIN_LOCI` counted outside `n_discordant`, still a named heuristic); new `reversed_blocks(y)` helper; parametrized `test_reversed_blocks_cases` with the review's nine cases and the expected `n_discordant` per block: clean [0]; one locus moved +50 kb [1] and -50 kb [1]; two adjacent moved [2]; two separate inversions [0, 0]; 30-locus nested re-inversion [29]; collinear, wholly reversed seqid, 4 reversed loci []. Checked by rerunning `rr_inv_fix.py` (read-only). Decision 38 updated. |
| N2 merged-state expectation and bar | Task 4 `test_null_with_unequal_annotation`: "expected about +0.15", bar D > 0.05 |
| N3 `ltrpav run` without scipy/matplotlib | Global Constraints; Task 10 Imports rule: ImportError becomes `CliError("analyses need scipy and matplotlib: run ltrpav-stats and ltrpav-paint in the ltrpav env")` (one line, exit 1, outputs kept, in `ltrpav run` too); `test_cli_imports_without_scipy` extended (run on `make_world` exits 1 with that line, `loci.tsv` exists); Task 11 note (a missing matplotlib is that CliError, not a figure warning) |
| N4 slow `fit_mix` test | Task 9: `@pytest.mark.slow`, run once in Task 9 Step 4; CI's `pytest -m "not slow"` deselects it; later full-suite runs (Tasks 10-12) use `-m "not slow"` |
| N5 youngest_u95 counts from another copy | Task 6 per-tract rule: the exact counts are the donor copy's own LTR-LTR counts, the same insertion as X's copy, and exist only where D is a member of the locus |

| Finding | Where it landed |
|---|---|
| C1 discovery rules read merged states | Global Constraints bullet; builder calls 1, 5, 6; Task 1 `Catalog` call arrays and `load_catalog`, `ToyLocus.calls`, per-call toy model; Task 3 `p_kksc`; Task 4 `counted`/`d_pav`/strata/f4 and tests `test_counted_reads_discoverer_calls`, `test_null_with_unequal_annotation`; Task 6 classes and decoy; Task 7 DFOIL pairs; Task 9 sites; Task 10 paint inputs |
| C2 DFOIL-alt sign table | Builder call 9; Task 7 `DFOIL_ALT_SIGNS`, `signature()`, tests (verbatim, plus the branch-length test) |
| C3 fallback inside the sisters' clade | Builder call 11 and Task 1 Step 7 (DESIGN entry with the controller's wording); Task 3 `four_point_ok`; Task 4 `eligible_fallback`, `counted`/`trios` gain `dist`, test |
| I1 KKSC on any discovery | Task 3 `p_kksc` rule, `kksc_loci`, the anti-conservative note, tests |
| I2 nested collapse | Task 4 strata rule and test |
| I3 ancestral vs derived absences | Task 8 `d_kind`, states and absence tables, findings bounds, tests; Task 11 panel F; Task 12 item 12 |
| I4 Dollo test | Task 8 rule ("missing" per event type) and test |
| I5 sister test | Task 3 `test_sharing_and_sister` |
| I6 inverted runs | Builder call 8; Task 1 `INV_MIN_LOCI` comment; Task 5 merge rule, `n_discordant`, test; Task 12 item 10 |
| I7 identity guard and sites | Task 9: `fit_mix`, `MG_MAX`, `IDENT_MIN_SITES` = 200, `pred_cdf` check, test; Task 12 item 13 (0.048% isolation, 0.070% mixture) |
| I8 unlike comparisons | Task 12 Step 4: one scoring code, both weightings, LTRmix modes named, items 2-3 (re-binned table) |
| I9 direction discovery | Global Constraints; Task 7 `PAIR_DISC`, rules, `test_pair_discovery` |
| I10 toy interfaces | Task 1 `simulate_run` (`p_missing`/`p_member` dicts), `ToyLocus.calls`; Task 4 tests (0.85 / 0.40, removed_frac 0.85) |
| I11 D_dir null | Builder call 9; Task 7 note; Task 12 Step 8 hand-off (unequal Ne in Plan 3) |
| M1 tract length | Task 6 `L` and `mean_tract_bp`; Task 12 item 7 |
| M2 youngest_u95 | Task 6 tract column, rule, caveats, test; Task 10 `run_paint` |
| M3 outgroup wording | Builder call 10; Task 3 note |
| M4 jackknife definition | Task 2 |
| M5 tie-break attribution | Task 4 `trios` |
| M6 resolved fractions | Task 4 `resolved_D2`; Task 7 resolution rows |
| M7 shortest callable | Task 6 lower and upper bounds, middle index, test |
| M8 toy margin | Task 4 admixed assertion at `n_per_seq=3000` |
| M9 detached check | Task 12 Step 2 |
| M10 chromosome ranking | Task 12 item 5 |
| M11 figure story | Task 11 Step 2 |
| M12 interface types | File Structure array conventions; `classes`, `Counted`, `inside`, `block_ids` signatures |
| M13 preliminary labels | Task 12 verdicts and the closing headline |
| M14 environments | Global Constraints; Task 1 Step 1; Task 10 lazy imports and test |
| M15 younger-than-split rows | Task 9 rows on the D_pav counted rows; Task 10 findings line without `--identity` |
