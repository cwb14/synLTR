# Task 11, first commit (ruling R2): Task 7's review minors

Plan 3 Task 11 records the simulation outcomes in DESIGN and, if the results say so, changes a painting default or the
direction note. Before that decision commit, one separate commit clears Task 7's review minors. The simulation grid
and the real-genome queue run from frozen snapshots under `benchmark_pav/plan3/snap/`, so repo edits cannot affect
them.

- Repo: `/data2/chris/maize_introgression/LTRpav`, branch `plan3-benchmark`, BASE 4f3973e. Commit on this branch;
  never push, never create branches or worktrees.
- The findings, with file:line references: `.superpowers/sdd/2026-11-12-plan3-benchmark/task-7-review.md`, section
  "### Minor", items 1-5. Read them first.

## Do

1. **m2, the left-out advice keeps a variant.** The assembly WARNING and the `_LEFT_OUT` line in
   `src/ltrpav/analysis/report.py` (review: report.py:128-129 and :292-293) say "rerun ltrpav-paint (or ltrpav run)".
   For a stale painting part made with non-default options (`--emission decoy`, `--discovery any`, or both), the
   advice must name the options the paint marker recorded, so that following it remakes the same variant (for
   example `rerun ltrpav-paint --emission decoy`). Advice for a default painting is unchanged. Say plainly that
   `ltrpav run` repaints at the defaults when it applies. Tests: a stale variant part's advice names its options; a
   default part's advice does not.
2. **m3, DESIGN 7.4 wording.** The e\* rows are NA "when the fit collapsed" (DESIGN.md, review :415-416); paint.py
   (:744-751) also writes NA when the painting was skipped. Make the sentence cover both.
3. **m4, wrap paint.py:28** (152 characters) to the module's width (about 115). Same words.
4. **m5, a test that `--block-size` reaches `direction` and the identity layer.** Today the tests check D_pav's SE
   only (test_cli_analysis.py:735-765). All three read one `size` in `run_stats` (report.py:445-483). The test must
   fail if either `direction` or the identity layer ignored the option.
5. **m1, documentation only.** DESIGN 7.3 (and 10.4, where it presents `--block-size` as the stability check): one
   clause saying that `ltrpav-stats --block-size` without `--identity` removes identity.tsv, so the painting part is
   left out until paint reruns; run a block-size check in its own copy of the run directory, or repeat `--identity`.

## Constraints

- Engine modules stay untouched: `checkpoint.STAGE_MODULES` and `src/ltrpav/constants.py`. After the commit, print
  every STAGE_MODULES fingerprint with `PYTHONPATH` set to the repo's `src` and to
  `/data2/chris/maize_introgression/benchmark_pav/plan3/snap/12d3e6c/src`, and show they are equal:
  `python -c 'from ltrpav.checkpoint import STAGE_MODULES, stage_fingerprint; [print(s, stage_fingerprint(s)) for s in STAGE_MODULES]'`
- Env `ltrpav` (`/home/chris/bin/mambaforge/envs/ltrpav/bin`); `export NUMPY_MADVISE_HUGEPAGE=0`. Never install,
  update or remove packages in env `ltrpav` (detached jobs depend on it). Never run python with `-I` or `-E`.
- Suite: `python -m pytest -W error -m "not slow"` and `ruff check .`. Run focused tests while working. The full
  suite runs longer than a tool call may wait, so launch it once, detached, after committing:
  `setsid -f nohup bash -c 'cd /data2/chris/maize_introgression/LTRpav && NUMPY_MADVISE_HUGEPAGE=0 /home/chris/bin/mambaforge/envs/ltrpav/bin/python -m pytest -W error -m "not slow" -q > SUITE_DIR/suite.log 2>&1; echo $? > SUITE_DIR/suite.exit' < /dev/null > /dev/null 2>&1`
  with SUITE_DIR given in your dispatch. Do not wait for it; the controller reads suite.exit.
- Probes: at most 16 threads and 15 minutes each. The server is busy with detached jobs; never kill any process.
- Package code only in `src/ltrpav/analysis/` (and tests); no maize-specific names in `src/`.
- Commit with the global git identity; no AI attribution anywhere (no Co-Authored-By or similar trailers). Suggested
  message: "Clear Task 7 review minors: variant rerun advice, DESIGN 7.3/7.4 wording, a block-size test".
- American English.
- Touch nothing outside the repo except SUITE_DIR and your report file.
