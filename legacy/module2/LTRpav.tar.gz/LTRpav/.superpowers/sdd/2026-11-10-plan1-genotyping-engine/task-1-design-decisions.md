**Builder calls made here (Task 1 records them in DESIGN.md section 12):**
1. Engine before bake-off: the bake-off scores routes through the full pipeline, so it needs the engine first.
2. W-minimap2 runs in-process (mappy) on 100-kb query chunks. That bounds memory (the 545-GB run aligned whole
   chromosomes as queries) and removes the chromosome-pair pass.
3. Flank uniqueness: flank pieces exclude annotated LTR-RTs and N runs; placement uniqueness comes from the mapper
   plus the 1:1 net margin. This replaces genome-wide k-mer counting.
4. E's TSD allowance adds the local A-B divergence d: `max(1, floor(L*(K + d) + 0.5))`. This reduces to DESIGN's
   `max(1, round(5K))` when d is about 0, and covers mismatches the A-B split adds.
5. VCF `INFO/AA` holds the REF base where an empty site is observed. VCF 4.3 defines AA as an allele sequence,
   so the design's `AA=0` would not be valid.
6. The alternative local aligners (LASTZ, WFA2, AnchorWave MAF) live in the bake-off code, through a
   `register_backend` hook. The package ships only the winner (DESIGN: the local step is fixed).

