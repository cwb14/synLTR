# Task 5 report: Inversions
Status: DONE_WITH_CONCERNS. Commit 1164d33 "Add inverted blocks from chains of resolved loci".
Files: src/ltrpav/analysis/inversions.py, tests/test_inversions.py. Full suite (-W error, not slow) and ruff pass.
Merge rule implemented as written (trim fewest rows, t = u+v ascending; discordant mask tracks trimmed and between rows; INV_MIN_LOCI counted on distinct mid_y outside the mask). All nine reversed_blocks cases pass.
Choices:
- n_loci = all block rows (discordant included); n_strand over all block rows.
- y breakpoints: bounded by the rows bounding the block's y extent, not rows a-1/a (which would span the whole block when reversed): dominant +1: left_y=(a-1,b), right_y=(a,b+1); dominant -1: left_y=(b+1,a), right_y=(b,a-1); low-high; None at a group end.
- A candidate run needs >= 1 reversed step (a stretch of only equal-y rows is not a candidate).
- inversion_rows emits all pairs (0 blocks included); n = loci resolved with coordinates in both.
Deviation: test_block_found uses seed=1, not 2. With seed 2, D is unresolved at the locus near 300,400, so D's first block locus is 301,066 (1065 bp from the breakpoint > spacing 665); no block definition can satisfy that assertion on that data. Seeds 1, 4, 6, 7 pass; 3, 5 fail the same way. Comment in the test.
Not probed on main3.

## Follow-up: containment test
Seed restored to 2. test_block_found now asserts each true breakpoint lies inside the reported interval (x or low/high-y bounding; right bound allows the 150-bp element) and that the interval is no wider than the gap between flanking loci resolved in both genomes. Passes on seeds 1-7 (run parametrized ad hoc, about 10 s total, over the 5 s budget), so the suite keeps seed 2 only.

## Fix round 1
- I1 fixed: y extent from non-discordant rows only (internal _find returns them); InvBlock gains trailing `dominant: int = 1`. Test: block with a locus displaced 5 Mb on y keeps its y extent and inside() membership.
- S axis: test_block_found asserts both axes of each pair (seeds 1-7 pass).
- 150 slack: named TOY_LENGTH with reason; still needed (a locus starting at the breakpoint ends past it).
- Dominant flip: findings line when any block has dominant -1; tested with an 80% inversion and absent in the 60%-free case.
- Semicolon style: left.
