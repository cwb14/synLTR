# Post-pilot dispatch: finish Task 8 Steps 10-11 and Task 9 Step 4

The 50-Mb pilot has ended. Its exit is in `sim/pilot.tsv.exit` and `pilot.tsv.done`.

Every step below is short: none waits on a job longer than 15 minutes. Run each in the foreground under `timeout 15m`,
or detached with a done marker when it may take longer. All paths are relative to
`/data2/chris/maize_introgression/benchmark_pav/plan3/`.

## Background (read first)
- `task-8-brief.md`, Steps 9-11.
- `task-8-rulings.md`, R4, R5 and R9.
- `task-9-brief.md`, Step 4.
- `task-9-rulings.md`.
- The progress.md lines beginning "- Task 8" and "- Task 9", including the gate ruling (rule 3 is measured at 50 Mb)
  and the conflict ruling (the trio view, labeled not like-for-like).
- `task-8-report.md`, Part B's Resume section and its PENDING sections.
- `task-9-report.md`, Part B.

## State
- **100-Mb pilot.** Its runs are in `sim/runs/{null_s101,f0.18_Ta5000_r1}.100Mb`. Its gate output is
  `sim/pilot/gate_100Mb.tsv`: h7 1.318 h, h_trio 0.587 h, projection 111.6 / 98.4 h, so the 50-Mb fallback applies.
  Its log is `sim/pilot/pilot_100Mb.log`.
- **50-Mb pilot.** Its runs are in `sim/runs/{null_s101,f0.18_Ta5000_r1}`, run with `--windows 5`. Its log is
  `sim/pilot/pilot_50Mb.log`.
- **Real-genome queue.** It is stopped at 20 of 36 pairs. Leave `plan3/real/` alone.

## Steps
1. **Gate at 50 Mb.**
   - Run `python sim/gate.py sim/runs/null_s101 sim/runs/f0.18_Ta5000_r1 > sim/pilot/gate_50Mb.tsv`.
   - Apply rules 1 and 2 to choose 30 or 10 bottleneck nulls. Make no other cut.
   - Regenerate `sim/grid.tsv` with `make_grid.py --bneck-nulls N`, and record its row count.
   - The grid runs at `--windows 5`, and the two 50-Mb pilot rows are its first two runs. The grid skips them by marker.
2. **Realism, Step 10, with R4's additions.**
   - Run `sim/realism.py` on the 50-Mb runs. Its views exist through `--until ltrmix`. Report the 100-Mb runs beside
     them.
   - The table covers, against main3:
     - per-pair state fractions and resolved fraction;
     - outgroup conflict, from the trio view (main, `--trio A1,B1,C1`), labeled with its discovery-set size and "not
       like-for-like" where it applies;
     - D_pav loci per Mb, counted and informative;
     - the painting's n_informative and spacing;
     - elements per Mb;
     - genome length;
     - the K distribution of shared elements against main3's B73-Zd shared median of 0.060;
     - the named deficit, `deficit_replay.py` on the 50-Mb null run with at most 10 workers.
   - Report these values. Never tune anything to them.
3. **Score the pilot, Task 9 Step 4.**
   - For each pilot row, run `run_one.sh NAME --from eval --windows 5` from `sim/`. Pass the same flags the grid uses,
     so its directory check accepts them.
   - Then run `python sim/summarize.py`.
   - Every field is filled, or NA with its reason. The pilot changes no rule.
   - Report the eval_run and eval_ltrmix headline per run:
     - D_pav Z and truth D Z;
     - roles;
     - genotype high-tier precision for P and E;
     - painting AUROC and recall where they are defined;
     - LTRmix's D tests and its recipient.
4. **Memo.** Fill these sections of `sim/memo.md`:
   - Steps 10-11, with the gate inputs, formula, both measurements and the decision;
   - RULES.md's date (2026-11-13) and sha256 (`4111826d6374508d9ffcd285a5f5ca5d3ffa9ece970290869caced3d0290a293`);
   - the named bins: length 0-50k, 50k-200k, 200k-1M, 1M-inf; informative loci [0,1), [1,3), [3,10), [10,30),
     [30,inf);
   - the script hashes;
   - the scoring commands.

   Use the CLAUDE.md memo format: key:value lines and exact commands.
5. **Report.** Fill the PENDING sections of `task-8-report.md`'s Part B, and append "Step 4 (pilot scoring)" to
   `task-9-report.md`.

## Rules
- **Thread budget.** Stay within 32 threads. Nothing else of this project is running now.
- **Environments.** Source `common/env.sh`. Never use `python -I` or `-E`. Never install into env `ltrpav` or env
  `ltrmix`.
- **RULES.md** stays byte-identical. No new rule or threshold.
- **Read-only:** main3, main3_analyses, inputs, run, LTRmix, benchmark and plan3/real.
- **No subagents.** American English. The user is the sole author: no AI attribution anywhere.
- **Return ONLY:**
  - status;
  - h7 and h_trio at 50 Mb;
  - the gate decision and the grid row count;
  - the realism headline (5-8 numbers against main3);
  - the pilot score headline per run;
  - concerns.

## Addition: one test (from Task 9 Part B's re-review, m1)
- Add tests to `sim/test_summarize.py` that pin rule 4's excess half and the 2-SE multiplier of rules 2 and 4, with
  exact verdicts on both sides of each boundary.
- They must kill the reviewer's surviving mutants: `within_2se` always passing, SD used for SE, 2.5 SE, and rule 2's
  line at 2.2 SE. Those mutants are in `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t9breview/`.
- This is a test-only change: summarize.py stays as it is. Do it before scoring, so that the scored hashes are final.
