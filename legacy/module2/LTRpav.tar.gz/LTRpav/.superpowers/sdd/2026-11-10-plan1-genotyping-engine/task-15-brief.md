### Task 15: Route interface, in-process minimap2 route, external PAF route

**Files:** Create `src/ltrpav/anchor/__init__.py`, `src/ltrpav/anchor/mm2.py`, `src/ltrpav/anchor/paf.py`,
`src/ltrpav/checkpoint.py`, `tests/test_routes.py`, `tests/test_checkpoint.py`

**Interfaces:**
- Produces:

```python
@dataclass
class PairContext:
    a: Sample; b: Sample; a_fa: Fasta; b_fa: Fasta
    a_elements: list[Element]; b_elements: list[Element] | None
    workdir: Path; threads: int
class Route(Protocol):
    name: str
    def raw_blocks(self, ctx: PairContext) -> np.ndarray     # unchained blocks, A indices = ctx.a_fa fai order
def get_route(spec: str) -> Route        # "mm2" | "fastga" | "flank-mm2" | "flank-blast" | "hybrid" | "paf:<dir>"
class Mm2Route: name = "mm2"             # anchor/mm2.py
class PafRoute:                          # anchor/paf.py; PafRoute(dirpath: Path), name = "paf"
    # reads <dir>/<A>__<B>.paf[.gz] (A = column 1) or <dir>/<B>__<A>.paf[.gz] (swapped)
def anchor_pair(ctx: PairContext, route: Route) -> tuple[np.ndarray, list[str], list[str], float]
    # netted blocks, a_names, b_names, divergence d; cached at workdir/anchors/<A>__<B>.<route>.npz
# checkpoint.py
def file_checksum(path: Path, cache: Path) -> str     # sha256, cached by (abs path, size, mtime_ns) in a JSON file
def stage_key(stage: str, inputs: dict[str, str], params: dict) -> str
def is_done(marker: Path, key: str) -> bool
def mark_done(marker: Path, key: str, outputs: list[Path]) -> None   # writes .done.json last
```

- [ ] **Step 1: Write the failing tests**

```python
def test_checkpoint_roundtrip(tmp_path): ...   # key changes when an input checksum or a param changes
def test_mm2_route_covers_shared_sequence(tmp_path):
    # toy genomes A, B: 300 kb shared random backbone, B mutated 1%, 10 element insertions in A only
    bl, an, bn, d = anchor_pair(ctx, get_route("mm2"))
    assert covered_fraction(bl, shared_intervals) >= 0.95 and 0.005 < d < 0.02
def test_paf_route(tmp_path):            # <dir>/A__B.paf read; <dir>/B__A.paf read with swap
def test_w_route_reused_both_directions(tmp_path):  # second direction loads the raw cache (no new mapping; spy)
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - **`Mm2Route`:**
    - Index B once. If `shutil.which("minimap2")`, run `minimap2 -x asm20 -t T -d <B>.asm20.mmi` (cached by the
      FASTA checksum); otherwise use `mappy.Aligner(fn_idx_in=fasta)`. Load with
      `mappy.Aligner(fn_idx_in=mmi, preset="asm20", best_n=5)`.
    - Map A in chunks of `MM2_CHUNK + MM2_OVERLAP` stepping `MM2_CHUNK`, skipping chunks that are >50% N, with a
      `ThreadPoolExecutor(T)` and one `mappy.ThreadBuffer` per thread.
    - Each hit becomes a block (`matches = mlen`, `alen = blen`).
  - **Raw-block cache:** W routes cache raw blocks for the unordered pair (labels in sheet order); the reverse
    direction loads them and runs `swap_blocks`.
  - **`anchor_pair`:** `chain_blocks` then `net_blocks`. Divergence `d = 1 - sum(matches)/sum(alen)` over the
    netted blocks. Save with a checkpoint marker.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add route interface, mm2 and PAF routes, checkpoints"`.

---

