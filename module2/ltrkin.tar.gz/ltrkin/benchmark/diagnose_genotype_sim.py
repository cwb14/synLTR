#!/usr/bin/env python3
"""Why was a planted site genotyped wrongly? Follows the reads that truly carry each allele's informative span.

For every planted site (default: those the run got wrong), the reads whose true origin (badread header: haplotype,
start-end) covers an allele-informative span are found:
  full allele (hap1, and hap2 for F and O sites): flank anchor (100 bp) to 100 bp into the internal region, either side
  empty allele (hap2, E):  100 bp on both sides of the junction
  solo allele (hap2, S):   100 bp on both sides of the solo LTR
Then their alignments in the run's BAM are classified: at the site (within the element +- 20 kb) with MAPQ >= 20, at the
site with MAPQ < 20, elsewhere only, or unmapped; reads absent from a subsampled BAM are not counted.
Usage: diagnose_genotype_sim.py -d BENCHDIR --run hifi_d20.full [--all] -o out.tsv
"""
import argparse
import bisect
import gzip
import os
import re
import sys

import pandas as pd
import pysam

A = 100
HDR = re.compile(r"(hap[12]),([+-])strand,(\d+)-(\d+)")


def read_origins(paths, hap_len):
    """read name -> list of (hap, start, end) fragments in forward coordinates (chimeras have several); junk and
    random reads skipped. Badread reports a minus-strand fragment in reverse-complement coordinates."""
    orig = {}
    for p in paths:
        with gzip.open(p, "rt") as fh:
            for i, ln in enumerate(fh):
                if i % 4:
                    continue
                name, _, rest = ln[1:].rstrip("\n").partition(" ")
                fr = []
                for m in HDR.finditer(rest):
                    h, a, b = m.group(1), int(m.group(3)), int(m.group(4))
                    fr.append((h, a, b) if m.group(2) == "+" else (h, hap_len[h] - b, hap_len[h] - a))
                if fr:
                    orig[name] = fr
    return orig


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-d", "--dir", required=True, help="benchmark directory")
    ap.add_argument("--run", required=True, help="run name, e.g. hifi_d20.full")
    ap.add_argument("--all", action="store_true", help="all planted sites, not only wrong calls")
    ap.add_argument("-o", "--out", required=True, help="output TSV")
    a = ap.parse_args()
    tech = a.run.split("_")[0]
    truth = pd.read_csv(os.path.join(a.dir, "truth", "truth.tsv"), sep="\t", dtype=str)
    ev = pd.read_csv(os.path.join(a.dir, "truth", "events.tsv"), sep="\t")
    g = pd.read_csv(os.path.join(a.dir, "ltrkin", a.run + ".genotypes.tsv"), sep="\t", dtype={"genotype": str})
    pl = truth[truth.category == "planted"].merge(g, on="element_id", suffixes=("", "_g"))
    allowed = {"F/F": {"F/F"}, "F/E": {"F/E"}, "F/S": {"F/S"}, "F/N": {"F/N"}, "F/N|F/F": {"F/N", "F/F"}}
    pl["correct"] = [c in allowed[t] for c, t in zip(pl.genotype, pl.truth)]
    sites = pl if a.all else pl[~pl.correct]
    print(f"[diagnose] {a.run}: {len(sites)} sites", file=sys.stderr)
    # region offset (reference = hap1 + off); events.tsv has both coordinates
    off = int(ev.del_start.iloc[0]) - 1 - int(ev.hap1_start.iloc[0])
    dels = sorted(zip(ev.hap1_start, ev.hap1_end))
    cum = [0]
    for d0, d1 in dels:
        cum.append(cum[-1] + d1 - d0)
    starts = [d0 for d0, _ in dels]

    def h2(x):                      # hap1 region coordinate -> hap2 coordinate (x outside deletions)
        k = bisect.bisect_right(starts, x)
        return x - cum[k]

    reads = sorted(f for f in os.listdir(os.path.join(a.dir, "reads")) if f.startswith(tech + ".") and f.endswith(".fq.gz"))
    hap_len = {h: pysam.FastaFile(os.path.join(a.dir, "truth", h + ".fa")).get_reference_length(h)
               for h in ("hap1", "hap2")}
    orig = read_origins([os.path.join(a.dir, "reads", f) for f in reads], hap_len)
    by_hap = {"hap1": [], "hap2": []}
    for name, frs in orig.items():
        for hap, s, e in frs:
            by_hap[hap].append((s, e, name, len(frs) > 1))
    for v in by_hap.values():
        v.sort()
    st_idx = {h: [x[0] for x in v] for h, v in by_hap.items()}

    def covering(hap, x0, x1, maxlen=400000):
        v, idx = by_hap[hap], st_idx[hap]
        lo = bisect.bisect_left(idx, x0 - maxlen)
        hi = bisect.bisect_right(idx, x0)
        return {name for s, e, name, chim in v[lo:hi] if s <= x0 and e >= x1}

    need = {}
    for _, r in sites.iterrows():
        s, e = int(r.start) - 1 - off, int(r.end) - off            # hap1 region coordinates
        la, rb = s + int(r.ltr5_len), e - int(r.ltr3_len)
        spans = {"hap1_F": [("hap1", s - A, la + A), ("hap1", rb - A, e + A)]}
        st = r.state
        if st in ("F", "O"):         # h2() also removes an O site's own internal deletion
            spans["hap2_F"] = [("hap2", h2(s) - A, h2(la) + A), ("hap2", h2(rb) - A, h2(e) + A)]
        elif st == "E":
            j = int(r.hap2_junction) - 1
            spans["hap2_E"] = [("hap2", j - A, j + A)]
        elif st == "S":
            j = int(r.hap2_junction) - 1                          # first base after the solo LTR + TSD
            spans["hap2_S"] = [("hap2", j - (la - s) - A, j + A)]
        sets = {}
        for k, lst in spans.items():
            names = set()
            for hap, x0, x1 in lst:
                names |= covering(hap, x0, x1)
            sets[k] = names
        need[r.element_id] = (s + off, e + off, sets)
    targets = set().union(*[x for _, _, ss in need.values() for x in ss.values()]) if need else set()
    bam = pysam.AlignmentFile(os.path.join(a.dir, "bam", a.run + ".bam"))
    alns = {}
    present = set()
    for x in bam.fetch(until_eof=True):
        if x.query_name in targets:
            present.add(x.query_name)
            if not x.is_unmapped:
                alns.setdefault(x.query_name, []).append((x.reference_name, x.reference_start, x.reference_end,
                                                          x.mapping_quality, x.is_secondary, x.is_supplementary))
    rows = []
    for _, r in sites.iterrows():
        S, E, sets = need[r.element_id]
        row = dict(element_id=r.element_id, state=r.state, truth=r.truth, call=r.genotype, gq=r.gq, length=r.length,
                   ltr5=r.ltr5_len, k2p=r.K2P_d, nn_dist=r.nn_dist, flank_te=r.flank_te_frac, n_F=r.n_F, n_E=r.n_E,
                   n_S=r.n_S, n_O=r.n_O, n_U=r.n_U, n_P=r.n_P, exp_reads=r.exp_reads, flags=r.flags)
        for k, names in sets.items():
            names = names & present
            near_q, near_l, elsew, unm = 0, 0, 0, 0
            for n in names:
                al = [x for x in alns.get(n, []) if not x[4]]
                near = [x for x in al if x[0] == r.chrom and x[1] < E + 20000 and x[2] > S - 20000]
                if any(x[3] >= 20 for x in near):
                    near_q += 1
                elif near:
                    near_l += 1
                elif al:
                    elsew += 1
                else:
                    unm += 1
            row.update({f"{k}_true": len(names), f"{k}_q20": near_q, f"{k}_lowq": near_l, f"{k}_elsewhere": elsew,
                        f"{k}_unmapped": unm})
        rows.append(row)
    out = pd.DataFrame(rows)
    out.to_csv(a.out, sep="\t", index=False)
    print(f"[diagnose] wrote {a.out}", file=sys.stderr)


if __name__ == "__main__":
    main()
