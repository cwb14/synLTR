### Task 9: Alignment blocks and PAF reader

**Files:** Create `src/ltrpav/blocks.py`, `tests/test_blocks.py`

**Interfaces:**
- Produces:

```python
BLOCK_DTYPE = np.dtype([("a_chrom", "i4"), ("a_start", "i8"), ("a_end", "i8"), ("b_chrom", "i4"),
    ("b_start", "i8"), ("b_end", "i8"), ("strand", "i1"), ("matches", "i4"), ("alen", "i4"),
    ("chain", "i4"), ("chain_score", "f8"), ("margin", "f4")])     # 0-based half-open; chain=-1, margin=nan until set
def read_paf(path: Path, a_index: dict[str, int], b_index: dict[str, int], swap: bool = False) -> np.ndarray
def a_to_b(block: np.void, apos: int) -> int
def swap_blocks(blocks: np.ndarray) -> np.ndarray     # exchange A and B roles (minus-strand coords stay valid)
def save_blocks(path: Path, blocks: np.ndarray, a_names: list[str], b_names: list[str]) -> None
def load_blocks(path: Path) -> tuple[np.ndarray, list[str], list[str]]
```

- [ ] **Step 1: Write the failing tests**

```python
def test_read_paf_and_map(tmp_path):
    # PAF query = A (col 1); line: a1 1000 100 200 + b1 5000 1000 1100 95 100 60
    bl = read_paf(p, {"a1": 0}, {"b1": 0})
    assert a_to_b(bl[0], 150) == 1050
def test_minus_strand_mapping():
    # block A[100,200) -> B[1000,1100) on '-': a_to_b(100) == 1099, a_to_b(199) == 1000
def test_swap_and_unknown_names(tmp_path): ...   # swap=True puts target in A; unknown seqids skipped and counted (logged)
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - Stream the PAF (gzip aware).
  - `a_to_b` scales by `r = (b_end-b_start)/(a_end-a_start)`. Plus strand: `b_start + round((apos-a_start)*r)`.
    Minus strand: `b_end - 1 - round((apos-a_start)*r)`.
  - `.npz` stores the blocks plus both name lists.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add alignment block model and PAF reader"`.

---

