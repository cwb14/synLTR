# Task 16 — controller rulings (bind as much as the brief; override it where they conflict)

1. Signature `genotype_pair(ctx: PairContext, route: Route, backend: str = "mappy") -> Path`; outputs:
   ctx.outdir/pairs/<A>__<B>.calls.tsv.gz, windows at ctx.workdir/windows/<A>__<B>.tsv.gz, chunks at
   ctx.workdir/calls/<A>__<B>/chunk_<n>.tsv.gz each with a checkpoint marker. Every gzip output is written with mtime=0
   (deterministic bytes; R11).
2. Steps: anchor_pair -> make_windows(ctx.a_elements, blocks, a_names, b_names, b_lengths=ctx.b_fa.lengths(),
   a_lengths=ctx.a_fa.lengths()) -> preset = preset_for_divergence(d) (asm20 if d is nan) -> chunks of CHUNK_WINDOWS
   windows in A fai order -> multiprocessing.get_context("fork").Pool(ctx.threads) with an initializer that opens both
   Fasta objects (same paths and cache_dir as the parent's) in each worker and receives the elements dict
   (eid -> Element) and the children map (eid -> child eids, A order) -> per window: a_seq = A.fetch(...),
   b_seq = B.fetch(...) reverse-complemented when strand == -1 ("" for non-ok windows), aln = align_window(a_seq,
   b_seq, preset, backend) only for ok windows else None, calls = classify_window(...), rows = call_row(...) ->
   chunk TSV + marker -> concatenate chunks in order -> pair file + marker. With threads == 1 run in-process (no Pool).
3. Every element of ctx.a_elements (all levels) appears exactly once in the pair file; assert this before writing.
4. TSV formatting (also used by later readers): header = CALL_COLUMNS; None and float nan -> "."; bool -> "1"/"0";
   float -> format(x, ".6g"); int -> str; strings as is. Rows sorted by (A fai order, a_start, -a_end, level).
5. Checkpoint keys: chunk = stage_key("genotype_chunk", {anchors npz checksum, windows file checksum}, {pair, chunk
   index, backend, preset}); pair = stage_key("genotype_pair", {anchors npz checksum}, {pair, backend, preset, route}).
   A completed pair is skipped entirely on rerun (logged "skip").
6. Logging: one INFO milestone per pair (windows, chunks, calls written); a WARNING when more than 99% of calls are U
   ("no orthologous alignment between <A> and <B>?").
7. Tests use tests/toy.py `build_pair` (default cases exclude U_flank, R9) written to FASTA (seqid "chr1") with the toy
   elements; the route is get_route("mm2"); threads = 2. Expectations: every element's state equals build_pair's
   `expect` exactly. The decoy test pastes the E case's 6-kb site region WITH the element into B 100 kb away (out of
   collinear order) — the call must stay E. The unrelated-genomes test uses a random B. The resume test deletes
   chunk_0's output and marker, reruns, checks only chunk_0 was recomputed (mtimes) and the pair file is byte-identical.
