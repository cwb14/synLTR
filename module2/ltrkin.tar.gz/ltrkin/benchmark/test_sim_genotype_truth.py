"""Tests for sim_genotype_truth.py on a small synthetic genome (run: pytest benchmark/test_sim_genotype_truth.py)."""
import argparse
import csv
import os
import random
import sys

import pysam
import pytest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sim_genotype_truth as sgt  # noqa: E402


def rand_seq(rng, n):
    return "".join(rng.choice("ACGT") for _ in range(n))


@pytest.fixture(scope="module")
def built(tmp_path_factory):
    """Ancestral random sequence with 60 inserted elements (5-bp TSD; LTRs differ at a few sites), plus one nested
    pair and one partially overlapping pair. GFF3 in LTRquest style, bgzipped and tabix-indexed."""
    rng = random.Random(3)
    d = tmp_path_factory.mktemp("sgt")
    seq, ann, cur = [], [], 0
    anc = rand_seq(rng, 4_000_000)
    pos = 100_000
    k = 0
    while pos < 3_800_000:
        ltr = "TG" + rand_seq(rng, rng.randint(300, 1500)) + "CA"
        ltr2 = list(ltr)
        for i in rng.sample(range(2, len(ltr) - 2), 3):
            ltr2[i] = "A" if ltr2[i] != "A" else "C"
        ltr2 = "".join(ltr2)
        internal = rand_seq(rng, rng.randint(1500, 8000))
        tsd = anc[pos:pos + 5]
        seq.append(anc[cur:pos + 5])
        n = sum(map(len, seq))
        el = ltr + internal + ltr2
        ann.append(dict(id=f"el{k}", s=n, e=n + len(el), l5=(n, n + len(ltr)), l3=(n + len(el) - len(ltr2), n + len(el)),
                        depth=0))
        seq.append(el + tsd)
        cur = pos + 5
        k += 1
        pos += rng.randint(40_000, 80_000)
    seq.append(anc[cur:])
    s = "".join(seq)
    # a nested pair (outer depth=1 contains inner depth=0) and a partially overlapping pair, in fresh sequence
    s += rand_seq(rng, 200_000)
    n0 = len(s) - 150_000
    ann.append(dict(id="outer", s=n0, e=n0 + 9000, l5=(n0, n0 + 500), l3=(n0 + 8500, n0 + 9000), depth=1))
    ann.append(dict(id="inner", s=n0 + 3000, e=n0 + 6000, l5=(n0 + 3000, n0 + 3400), l3=(n0 + 5600, n0 + 6000), depth=0))
    n1 = len(s) - 80_000
    ann.append(dict(id="ovA", s=n1, e=n1 + 6000, l5=(n1, n1 + 400), l3=(n1 + 5600, n1 + 6000), depth=0))
    ann.append(dict(id="ovB", s=n1 + 5600, e=n1 + 11000, l5=(n1 + 5600, n1 + 6000), l3=(n1 + 10600, n1 + 11000), depth=0))
    fa = d / "g.fa"
    fa.write_text(">chrT\n" + "\n".join(s[i:i + 80] for i in range(0, len(s), 80)) + "\n")
    pysam.faidx(str(fa))
    gff = d / "g.gff3"
    lines = []
    for a in ann:
        lines.append((a["s"], 0, f"chrT\tt\tLTR_retrotransposon\t{a['s'] + 1}\t{a['e']}\t.\t+\t.\tID={a['id']};"
                                 f"depth={a['depth']};K2P_d=0.002\n"))
        for tag, (x, y) in (("lLTR", a["l5"]), ("rLTR", a["l3"])):
            lines.append((x, 1, f"chrT\tt\tlong_terminal_repeat\t{x + 1}\t{y}\t.\t+\t.\tID={a['id']}.{tag};"
                                f"Parent={a['id']}\n"))
    with open(gff, "w") as fh:          # tabix needs lines sorted by start
        fh.write("##gff-version 3\n" + "".join(ln for _, _, ln in sorted(lines)))
    gz = pysam.tabix_index(str(gff), preset="gff", force=True)
    out = d / "out"
    args = argparse.Namespace(fasta=str(fa), gff=gz, region=f"chrT:1-{len(s)}", outdir=str(out), seed=5,
                              min_gap=25000, edge=50000, check=True)
    seqr, hap2, planted, junction, r0 = sgt.build(args)
    sgt.check_junctions(str(out / "check_junctions.tsv"), seqr, hap2, planted, junction, r0)
    truth = {r["element_id"]: r for r in csv.DictReader(open(out / "truth.tsv"), delimiter="\t")}
    return dict(seq=s, hap2=hap2, truth=truth, out=out, ann={a["id"]: a for a in ann})


def test_categories(built):
    t = built["truth"]
    assert t["outer"]["category"] == "context_nested" and t["inner"]["category"] == "context_nested"
    assert t["ovA"]["category"] == "context_overlap" and t["ovB"]["category"] == "context_overlap"
    planted = [r for r in t.values() if r["category"] == "planted"]
    assert len(planted) >= 50
    assert {r["state"] for r in planted} == {"F", "E", "S", "H", "O"}


def test_tsd_inferred(built):
    for r in built["truth"].values():
        if r["element_id"].startswith("el"):
            assert r["tsd_len"] == "5", r


def test_states_on_hap2(built):
    s, h2 = built["seq"], built["hap2"]
    for r in built["truth"].values():
        if r["category"] != "planted" or r["state"] == "F":
            continue
        a = built["ann"][r["element_id"]]
        d0, d1, j = int(r["del_start"]) - 1, int(r["del_end"]), int(r["hap2_junction"]) - 1
        assert h2[j - 300:j] + h2[j:j + 300] == s[d0 - 300:d0] + s[d1:d1 + 300]
        st = r["state"]
        if st == "E":     # element and one TSD copy gone: flank + TSD + flank
            assert (d0, d1) == (a["s"], a["e"] + 5)
            assert h2[j - 5:j] == s[a["s"] - 5:a["s"]] and h2[j:j + 20] == s[a["e"] + 5:a["e"] + 25]
        elif st == "S":   # left LTR between the two TSD copies
            assert (d0, d1) == (a["l5"][1], a["e"])
            ltr = s[a["l5"][0]:a["l5"][1]]
            assert h2[j - len(ltr) - 5:j + 5] == s[a["s"] - 5:a["s"]] + ltr + s[a["e"]:a["e"] + 5]
        elif st == "H":
            assert 3000 <= a["s"] - d0 <= 15000 and 3000 <= d1 - a["e"] <= 15000
        elif st == "O":
            assert a["l5"][1] < d0 < d1 < a["l3"][0] and 500 <= d1 - d0 <= 2000


def test_spacing(built):
    rows = sorted((r for r in built["truth"].values() if r["category"] == "planted"), key=lambda r: int(r["start"]))
    fp = []
    for r in rows:
        if r["state"] == "H":
            fp.append((int(r["del_start"]) - 1, int(r["del_end"])))
        else:
            t = int(r["tsd_len"])
            fp.append((int(r["start"]) - 1 - t, int(r["end"]) + t))
    for (a0, a1), (b0, b1) in zip(fp, fp[1:]):
        assert b0 - a1 >= 25000


def test_vcf_and_junction_check(built):
    out = built["out"]
    recs = [ln.rstrip("\n").split("\t") for ln in open(out / "planted_sv.vcf") if not ln.startswith("#")]
    planted = [r for r in built["truth"].values() if r["category"] == "planted"]
    assert len(recs) == 2 * len(planted)
    for x in recs:
        info = dict(kv.split("=") for kv in x[7].split(";"))
        assert int(info["END"]) - int(x[1]) == -int(info["SVLEN"])
        a = built["ann"][info["ELEMENT"]]
        if info["ALLELE"] == "empty":
            assert int(x[1]) == a["s"] and int(info["END"]) == a["e"] + 5
        else:
            assert int(x[1]) == a["l5"][1] and int(info["END"]) == a["e"]
    rows = list(csv.DictReader(open(out / "check_junctions.tsv"), delimiter="\t"))
    assert rows and all(r["status"] == "OK" or (r["state"] == "S" and r["status"] == "SHIFTED") for r in rows)
