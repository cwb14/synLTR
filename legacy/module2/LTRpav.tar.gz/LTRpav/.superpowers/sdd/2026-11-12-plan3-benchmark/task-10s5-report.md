# Task 10 Step 5 report

Appended one section "## Task 10: grid (144 runs) and LTRquest runs (Steps 4-5)" to
/data2/chris/maize_introgression/benchmark_pav/plan3/sim/memo.md (lines ~357-458; pre-edit copy in the scratchpad p3t10s5/memo.md.before). Read the file for the quoted text.

Derivations
- Times: grid.tsv.done/.exit, grid_rev.tsv.exit, grid.log/grid_rev.log first and last lines, run_lq.log, after_grid.log, after_grid2.log. Grid wall 04:12:16 (11-13) to 13:37:39 (11-14) = 33 h 25 min 23 s.
- Peak PSS: "peak summed PSS" lines in grid.log (11.95 GB) and grid_rev.log (11.23 GB).
- Per-kind table: scratchpad p3t10s5/walltimes.py parses runs/<name>/run.log for the 144 grid.tsv rows (last "<step>: done in N s" per step; total = sum of 5 steps; kind/design from grid.tsv). 7-genome median 0.591 h vs pilot 0.673 h vs plan 1.133 h; trio 0.236 h vs 0.320 h vs 0.433 h.
- Lock collisions (3): grep 'in use by another' (grid.log 1439, 1440; grid_rev.log 409); finishers from the run.done lines.
- LTRquest: ltrquest.time, threads_peak.txt, threads.tsv (share >32 running computed with awk), lq.done, record_check.txt, run_lq.log step lines, ltrmix.time. Defect text from ledger entry "Task 10 Step 4" and lq/run_lq.sh in_lq_env; attempt1_pathbug contents listed.
- Launch lines: runner 1/2 and LTRquest are reconstructed from the ledger and task-10-report.md (the logs do not hold the command line); after_grid2 from its script header.

Concerns
- The brief lists a kind "nodonor"; grid.tsv has no such kind (seven kinds: null, power, reverse, ptlike, bneck, posctl, dropout). Noted in the memo.
- Launch lines for runners 1/2 and run_lq.sh are not recorded verbatim anywhere I found; marked "(ledger)". after_grid.sh's launch args not found.
- "Before the final pass" failures: after_grid2's pass never ran (grid.tsv.done existed), so before = after; grid.tsv.failed is absent.
- walltimes.py lives in the scratchpad, not the repo; the memo says so. Its eval column would change if the rescore appends eval lines to run.log (not checked, I did not read the rescore).
- Pilot runs null_s101 and f0.18_Ta5000_r1 are included in null/power medians.

## Fix (reviewer's four items)
1. grid_rev.tsv construction command added to the memo's command block. 2. Narration and ledger pointers removed ("expected and harmless", "reading:", "(ledger)"); the other-project load stated as a fact. 3. Runner 2 start is 08:15:53 (first grid_rev.log line) everywhere, including the before/after split label. 4. sim/tables_walltimes.tsv written from the script (split cutoff 08:15:53; values identical to the earlier table, eval lines unchanged after the rescore began); memo gotcha replaced.
