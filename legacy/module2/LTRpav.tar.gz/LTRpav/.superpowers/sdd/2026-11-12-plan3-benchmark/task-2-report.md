# Task 2 report: events on the genealogy (and Task 1's review minors)

Status: DONE_WITH_CONCERNS. Concern 1 was ruled and is applied in 41f70b6 (see "Concern 1 ruling" at the end).

Commits (branch plan3-benchmark, local, user identity, no trailers):
- a91987a Population model review minors: f = 0 reads no ta, stronger tract tests, JSON field guard
- 7bcdb96 Draw insertions, losses, SNPs and indels on simulated genealogies
- 41f70b6 Thin simulated events on sequence an older loss removed (controller ruling on concern 1)
- 42607ad Thinning reads whether sequence is present; junction rule for anchors (fix round 1)

## 1. Review minors (a91987a)

- M1 `Demog`: the ta-versus-lineage-split check now runs only when f > 0, like ta < t_ab; the sub_* presence check
  stays strict at f = 0. Test: test_bad_demog_fails accepts `Demog(pulse="C>A1", sub_a=(2000, 1000), f=0)` (default
  ta 5,000 above the split) and the A1>C1 case with ta above C1p's split at f = 0; the f > 0 counterparts still raise.
- M2 test_tracts_three_per_taxon: per_taxon 3, small_demog(f=0.3, ta=2000), 2 Mb, seeds 1-10, simulated with
  `additional_nodes=MIGRANT, coalescing_segments_only=False`; `tracts()` must equal an independent truth that walks
  each sample's path tree by tree to a MIGRANT node of the pulse (time ta, donor population), reading no migration
  records. Every A sample has a tract in some seed, no other sample ever does. The reviewer's first-tree-only tracer
  is wrong in 10 of 10 seeds here (probe), so the test fails it.
- M3 test_tract_through_ancestor: asserts the coordinates. In every scanned seed whose trees all have
  tmrca(A1, A2) < ta, `tracts()` must equal {0: U, 1: U} with U the merged union of the pulse records' intervals
  ({} when none). With the old ne_a = 5 every move covered [0, L), so a tracer returning [0, L) for any moved node
  passed; the test now uses ne_a 100 on 1 Mb (recombination spreads A's ancestry over a few lineages) and stops at
  the first seed whose pulse moves part of the sequence, not all (seed 3, coverage 0.12, msprime 1.4.2). Seed search
  is conditioned on the event and every scanned seed is checked against the independent union.
- M4 `flat_fields(*classes)` (popmodel, public): field-name sets, ValueError naming a shared field; called on import
  (`_JSON_FIELDS = flat_fields(Demog, Rates)`) and used by demog_from_json. Test test_flat_fields_disjoint (a dummy
  dataclass sharing `mu` with Rates raises).
- M5 DESIGN 12: an "Environment (Task 1)" line after item 36 records the bcftools 1.24 pin and its reason (gsl),
  that no stage key reads it and that run manifests differ from main3's there. Unnumbered, since items 1-36 follow
  Plan 3's call numbering.

RED (old popmodel plus a `flat_fields` shim without the check): `FAILED test_flat_fields_disjoint - DID NOT RAISE`,
`FAILED test_bad_demog_fails - ValueError: pulse C>A1: ...` (without the shim, collection fails on the import).
M2/M3 harden tests of correct code; their evidence is the mutant probe (reviewer's mutants patched into the test
module): first_tree_only, no_clip, samples_only and reversed all FAIL test_tracts_three_per_taxon; no_clip,
samples_only and reversed FAIL test_tract_through_ancestor (first_tree_only passes that one; M2 catches it).
GREEN: `tests/test_popmodel.py tests/test_sim.py` 82 passed; ruff clean.

## 2. Task 2 (7bcdb96)

### What was built

`src/ltrpav/sim/popevents.py` (no msprime/tskit import at module level; `_msprime()` from popmodel):
- `Ins`, `Loss` (frozen), `ChromEvents`: the brief's fields verbatim. `KINDS`, `MAX_DEPTH = 2`.
- `donor_body(d)`: what a copy inserts before mutation: left LTR + internal + left LTR, upper-cased, donor
  orientation (Plan 1's young copy; DESIGN 12 item 6, LTRs identical at insertion). len(X) and nested offsets are
  defined on it; public so that Task 3 uses the same body.
- `draw_events(ts, backbone, elements, donors, rates, rng, *, chrom=0)`:
  - seeds for the three msprime calls drawn first (distinct), each call `keep=False` on the input ts;
  - 1 primary insertions: BinaryMutationModel, continuous genome, pos = floor; ins_end, ins_n; donor uniform,
    strand 1/2; carriers = samples below the mutation's node; numbered i<chrom:02d><n:06d> in position order;
  - 2 losses: backbone elements (sorted (start, -end, eid)) on the tree at their start, every branch; insertions on
    the tree at their position, below their own event; per branch, top-down, Poisson(delta * length), times sorted
    oldest first, kinds by loss_split (inverse CDF, so a split summing to 1 +- 1e-6 is accepted); ending kinds stop
    the lineage; lineage state carries what the internal region still holds for del_partial;
  - 3 nested: per insertion after its losses, Poisson(lam * len(body) * B_X) on the alive segments that step 2
    returns (X's subtree minus parts below its ending losses), point uniform by length, offset U{0..len-1};
    nested_after_loss; own losses; depth 2 once (recursion stops at MAX_DEPTH);
  - 4 SNPs: JC69 discrete; `genotype_matrix(alleles=ACGT)` relabeled through a 4x4x4 permutation table
    (_PERM[anc, backbone, allele]); non-ACGT sites dropped (snp_n); snp_base ASCII codes, (m, n_samples) uint8;
  - 5 indels: BinaryMutationModel discrete, one event per mutation (msprime order), carriers per mutation from the
    tree, insertion/deletion 1/2, length geometric(_INDEL_P).
  - The trees are read in one pass over `ts.trees()`; each queried marginal tree becomes a small Python `_Tree`
    (parent, time, children, samples below).
  - Fail fast (ValueError): backbone length != ts length; chrom not an int 0-99; duplicate eid; LTRs not in order
    inside an element or outside the backbone; a donor without internal region; lam > 0 and no donors.
- Module docstring: the rules in order, and the coordinates the builder needs (Ins.pos; Loss a, b per kind), and
  which events stand on removed sequence (Concern 1).

`tests/poptoy.py`: module docstring; `toy_ts(nested tuple, length)` (one tree, leaves = sample indices,
internal = (time, child, ...), time units generations), `tree_length`, `rand_bases`, `toy_element` (coordinates
only), `toy_backbone(length, spans, seed)` (random ACGT, planted LTR + internal + LTR with a 5-bp TSD, eids
bb0001.. in (start, -end) order, parent by containment), `toy_donors(n, seed, ltr, internal)`.

`tests/test_popevents.py` (importorskip msprime; 15 tests, ~2.5 s together): the brief's ten, plus
test_target_boundaries, test_loss_parameters, test_nested_target_not_on_n, test_indels, test_bad_input_fails.
- Independent references: msprime's genotypes (`variants()`) of the captured insertion call; tskit's
  `tree.samples` and `is_descendant`; exact toy genealogies (TREE7 total 128,000 generations, TREE16 218,000); a
  spy on `msprime.sim_mutations` that also asserts each call gets a mutation-free ts, keep=False and its own seed.
- test_target_boundaries plants one insertion mutation at every x.5 of a 200-bp toy (monkeypatched call) with N,
  R, Y and lowercase k: kept positions must equal exactly {15 <= p <= 185 with [p - 5, p) ACGT}.
- test_loss_parameters checks every loss: carriers, time within its branch, below its insertion's event; solo
  1..min(LTR)-1; del_flank left/right/both patterns in FLANK_DEL; del_partial in own coordinates: both end bases
  still held on the lineage, the bases it removes are 20-60% (+-1) of what the lineage held, which is >= PARTIAL_MIN;
  replace >= 81.
- test_popmodel's no-msprime import test also imports `ltrpav.sim.popevents`.

### RED / GREEN

RED (`python -m pytest -W error -p no:cacheprovider tests/test_popevents.py`, module absent):
`E ModuleNotFoundError: No module named 'ltrpav.sim.popevents'` / `ERROR tests/test_popevents.py`.

First GREEN run: 12 passed, 1 failed: test_replace_length `assert (405 > 500)`: the test's own sizing (150 elements
gave 405 replace events); now 400 elements (> 800 events). Then all passed; durations 0.07-0.45 s per test.

Mutation check (scratch copies of the module imported through PYTHONPATH; script
`.../scratchpad/p3t2/mutate.py`), 22 mutants, all caught:

| mutant | caught by |
|---|---|
| primary carriers from the parent node | carriers_match_genotypes |
| target window shifted by 1 bp | target_boundaries (no_insertion_target_on_n missed it: a 1-bp edge is rarely hit at random; hence the extra test) |
| end rule `<=` on the left / `- 1` on the right | target_boundaries |
| no upper-casing | backbone_case_and_iupac |
| SNP permutation of the other three reversed | snp_ancestral_is_backbone |
| SNP sites on IUPAC not counted in snp_n | backbone_case_and_iupac |
| kinds uniform, not loss_split | loss_split, replace_length |
| no stop after an ending loss | loss_ends_lineage, nested_carriers_and_offsets |
| replace without the MIN_SEG + 1 floor | loss_parameters, replace_length |
| del_flank always both sides | loss_parameters |
| del_partial in current, not own, coordinates | loss_parameters |
| del_partial a fraction of the whole internal region | loss_parameters, loss_split |
| nested points below ending losses of the host | nested_carriers_and_offsets |
| no nested_after_loss check | nested_carriers_and_offsets |
| depth 3 allowed | nested_carriers_and_offsets |
| nested offset past the body | nested_carriers_and_offsets |
| no non-ACGT check at nested targets | nested_target_not_on_n |
| insertion rate doubled | carriers_match_genotypes, insertion_count_poisson |
| SNP call reuses the insertion seed / one seed for all | carriers_match_genotypes |
| indel carriers from the root | indels |

### Scale probe (default Demog f 0.18, 5 Mb, 321 elements covering 71%, 50 donors 3.6-13 kb)

`.../scratchpad/p3t2/scale_probe.py`: ancestry 32.7 s (57,794 trees); draw_events 3.3 s; max RSS 0.38 GB. Per 5 Mb:
2,085 primary insertions, 971 depth 1, 367 depth 2; 2,813 losses (del_partial 1,435, replace 585, del_flank 469,
solo 324); 476,015 SNP sites; 50,247 indels; nested_after_loss 103. iid example `i03000001`.

## Fingerprints

`fingerprints.sh 12d3e6c 7bcdb96` (scratch): each commit's `src/` from `git archive`, imported alone (`python -I`,
`ltrpav.__file__` asserted inside the snapshot), `{s: checkpoint.stage_fingerprint(s) for s in STAGE_MODULES}`
compared by diff: IDENTICAL (elements a78af75d..., anchor/raw/blastdb ebbfd97f..., mm2_index 28f6fc79...,
genotype_pair/genotype_chunk 52071c27...). `git diff --stat 12d3e6c HEAD -- src/ltrpav` touches only
`sim/__init__.py`, `sim/popmodel.py` and `sim/popevents.py`. No maize names in popevents (word grep: 0).

## Suite

Detached on the staged tree (tree d1dab9a6 at launch = tree of commit 7bcdb96, checked before committing):
`setsid -f nohup env PATH=<ltrpav bin>:$PATH NUMPY_MADVISE_HUGEPAGE=0 bash -c 'python -m pytest -W error -m "not
slow" -p no:cacheprovider > LOG 2>&1; echo "exit $?" >> LOG'`; leader bash 3853713, PPID 1, SID 3853713; waited
with a Monitor until-loop.

```
1188 passed, 2 deselected in 1363.09s (0:22:43)
exit 0
```

(1171 at Task 1 + 2 popmodel + 15 popevents.) `ruff check .`: All checks passed!

## Self-review: choices where the brief left room (conservative; controller to rule)

1. `chrom` is a keyword-only argument (default 0, 0-99): the iid format "i<chrom:02d><n:06d>" needs it and the
   brief's signature has none. Task 5 must pass it per chromosome.
2. Target site: an insertion before backbone base pos takes target [pos - 5, pos) (Plan 1's insert_element keeps the
   target bases left of the copy). End rule "within W + TSD_DEFAULT of an end": kept iff 15 <= pos <= L - 15
   (symmetric; Plan 1 allowed up to L - W on the right).
3. len(X) and nested offsets use `donor_body` (left LTR twice), the inserted length, not len(donor.seq).
4. del_partial (a, b) are in the element's own coordinates (offsets from the end of its left LTR: backbone bases, or
   donor-body bases), a stretch [a, a + b) that is contiguous in what the lineage still held (Plan 1's law: a
   PARTIAL fraction of the current internal region, uniform start). After an earlier del_partial on the lineage it
   may span removed bases, so b is a span, not always the bases removed. Own coordinates make the losses of one
   lineage order-free (a union) and directly comparable with nested offsets; a builder that replays them in time
   order on current coordinates would be wrong. The alternative (current coordinates, replayed oldest first) is a
   one-line change; the mutant check shows the tests pin the choice.
5. A mechanism an element cannot take is not drawn (thinning, not renormalized): solo when an LTR is under 2 bp;
   del_partial when the lineage holds under PARTIAL_MIN of the internal region (also after earlier del_partials).
   Not counted in `dropped` (its keys stay the brief's four).
6. replace length = max(MIN_SEG + 1, round(Exp(replace_mean))): the floor raises the mean by under 1 bp at 13,538.
7. nested_after_loss uses strict inclusion: an offset at a removed stretch's edge lies at the junction, which still
   exists, and is kept.
8. The brief's "never inside an insertion's 5 target bases" is applied to nested insertions too: one with a
   non-ACGT host-body base within 5 bp on either side of its offset (orientation-free, covering the target on either
   strand) is dropped and counted in ins_n with the primary ones. No real effect for N-free donors.
9. snp_base holds ASCII codes (b"A"[0], ...), ready to write into a sequence. A site where back mutation leaves
   every sample on the backbone base is kept.
10. Indels: each msprime mutation is one event (recurrent mutations at one site are separate events, msprime order:
    by site, older first); a deletion is clipped at the chromosome end; the inserted bases are not drawn here (the
    interface has no field for them), so the builder must draw them once per event, not per sample.
11. Draw order: seeds; primary donors/strands; backbone losses; then per primary insertion its losses and its
    nested ones depth-first. Nested iids follow the primaries in creation order.
12. Elements that cross each other are not rejected (only per-element LTR order and bounds are checked).

## Concerns

1. Events on sequence that is already gone, kept as the brief's rules draw them. Only a nested insertion's own host
   is read when it is placed, and only an element's own ending losses stop it. So these stand, and Task 3's builder
   (and Task 4's truth and insertion table) must treat their sequence as absent:
   - primary insertions into backbone sequence that an earlier loss of a backbone element removed on their lineage
     (solo, del_flank, del_partial or replace above the insertion's point): 231 of 2,085 (11.1%) in the 5-Mb probe;
   - depth-2 insertions below an ending loss of their host's host: 59 of 367 (16%);
   - losses of nested insertions below an ending loss of their host: 84 of 615.
   Alternative for the controller: thin these at draw time in Task 2, extending the brief's own rule for nested
   hosts (B_X, nested_after_loss) to backbone hosts and host chains. It needs the removed backbone interval of each
   loss kind, which is the builder's convention (solo [ltr_left0 + x, ltr_right0 + x), del_flank [start - a, end + b),
   replace [start, end)), so I did not pre-empt it.
2. Nesting is frequent at the default rates: 46% as many depth-1 as primary insertions, and depth 2 at 38% of
   depth 1, because most tree length lies on the long outgroup and root branches (B_X up to ~900,000 generations)
   and bodies are ~8 kb. This is DESIGN 12 item 7's subtree process as written; reported for density comparisons
   with main3.
3. The del_partial coordinate convention (choice 4) and the indel bases (choice 10) bind Task 3.
4. test_tract_through_ancestor's case seed (3) and the MIGRANT test depend on msprime's random streams; CI's PyPI
   msprime 1.4.0/1.4.5 may pick another case seed (the scan allows 3-22), and every scanned seed is checked.

## Files

- New: `src/ltrpav/sim/popevents.py`, `tests/test_popevents.py`.
- Changed: `tests/poptoy.py`, `tests/test_popmodel.py` (minors; popevents in the import test),
  `src/ltrpav/sim/popmodel.py`, `docs/DESIGN.md` (minors).
- Probes (scratch): `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t2/`
  (mutants.py, mutate.py, scale_probe.py, fingerprints.sh, suite.log).

## Concern 1 ruling (controller, task-2-concern-ruling.md): thinning at draw time

Commit 41f70b6 "Thin simulated events on sequence an older loss removed" (on 7bcdb96; user identity, no trailers).

### What changed in `sim/popevents.py`

- **del_partial law** (ruling 1): drawn on the element's original internal region (PARTIAL fraction of it, uniform
  start), only for an element whose original internal region is >= PARTIAL_MIN; two that overlap on a lineage
  remove their union. The lineage state of 7bcdb96 (`_span`, `_cut`, "what the lineage still held") is gone.
- **`removed(loss, elements, ins, donors, length) -> list[(system, start, end)]`**, public: the only definition of
  what each loss kind removes. A system is None (backbone, genome orientation) or an iid: that insertion's donor body
  [0, len) in donor orientation, then [len, len + 5) its second TSD copy, counted from the body outward.
  - solo `[ltr_left0 + a, ltr_right0 + a)` (an insertion: `[a, len - ltr + a)` of its body);
  - del_partial `[ltr_left1 + a, ltr_left1 + a + b)` (an insertion: `[ltr + a, ...)`);
  - replace `[start, end)`: a backbone element's span, an insertion's body `[0, len)` (no backbone sequence, its
    TSDs stay);
  - del_flank of a backbone element: `[start - a, end + b)` clipped to the backbone (Plan 1's pair simulator;
    its TSDs are backbone bases);
  - del_flank of an insertion X at pos p of its host's system (Plan 1: `delete(e.start - left, e.end + right)`
    around the body, with the TSD copies where insert_element puts them): X's body and, when b > 0, its second TSD
    copy, `(X, 0, len + 5)`; the start-side flank `[p - a, p)` of the host (X's target bases first, then outward);
    the end-side flank `[p, p + b - 5)` of the host (after the 5-bp TSD copy). For a host-None X that is
    `(None, p - a, p)` and `(None, p, p + b - 5)`.
  - A flank of a nested insertion that runs past its host's body start or end goes on into the host's own system
    (past the end side in the host's order through the host's second TSD copy), as a Plan 1 deletion acts on
    the whole genome; strand - maps the body's donor end to its host's start side.
  - Interval semantics (stated in the docstring, for the builder): removing [lo, hi) of a system takes its bases
    lo..hi-1 and every insertion placed strictly inside (lo < pos < hi), with its body, nested contents and second
    TSD copy; one at pos == lo or hi stays (at the junction).
- **`thin_events(ins, losses, elements, donors, length) -> (ins, losses, Counter)`**, public, called by
  draw_events as rule 4 after the brief's draws (B_X kept): all events sorted oldest first; each decided against
  the older kept losses only; a discarded event removes nothing.
  - An insertion is kept when its host exists at its point and none of its target bases [pos - 5, pos) lies in a
    kept older removal of its host's system.
  - A loss is kept when its element exists at its point. A simulated insertion exists below its own event while no
    older kept ending loss of its own lies above, its position is not strictly inside an older kept removal of
    its host's system, and its host exists there (recursively). A backbone element exists unless older kept
    removals cover its whole span.
  - Counters: `ins_after_loss` (primary), `nested_after_loss` (nested, any depth and cause; it replaces the
    draw-time del_partial check of 7bcdb96), `loss_after_loss`. The iids of discarded insertions are not reused.
  - Implementation: one sorted interval index per coordinate system (`_Removals`: start-sorted, queried with the
    longest kept interval as the look-back), ending losses per element, the kept insertion set.
- **Carriers, not paths.** A loss's carriers are fixed on its own tree (a backbone element's at its start), and
  the builder applies a loss to its carriers. So existence is read per carrier: "above q" is "an older kept loss
  whose carriers meet the event's carriers". On one tree this is exactly the path from q up (an older event's
  carriers contain the younger's or are disjoint), so the ruling's tests are unaffected. Across the trees of
  different positions, an event is discarded when the lineage of any one of its carriers lacks its sequence, so
  every kept event exists on the lineage of each of its carriers (choice A below).
- Nested ins_n now reads the nested insertion's target bases [pos - 5, pos) of its host's body. Before, it read a
  +-5-bp window in either orientation; the coordinate convention now fixes the target.

### Counts before and after (5-Mb probe: default Demog f 0.18, seed 11; 321 elements covering 71%; 50 donors)

Same seeds and inputs. scale_probe.py ran on 7bcdb96 and scale_probe2.py on this commit (scratch p3t2/).

| | before (7bcdb96) | after: drawn | after: kept | dropped |
|---|---|---|---|---|
| primary insertions | 2,085 | 2,085 | 1,462 | ins_after_loss 623 |
| nested insertions | 1,338 (971 d1, 367 d2) + 103 nested_after_loss | 1,626 | 902 (686 d1, 216 d2) | nested_after_loss 724 |
| losses | 2,813 | 2,919 | 2,007 | loss_after_loss 912 |
| del_partial / replace / del_flank / solo (kept) | 1,435 / 585 / 469 / 324 | | 1,008 / 406 / 331 / 262 | |

- The drawn nested and loss counts differ from 7bcdb96's because the draw-time nested_after_loss check no longer
  ends a candidate before its donor and strand draws, so the random stream diverges.
- Before, events on removed sequence (concern 1): 231 primaries (11.1%; read on each insertion's own tree, against
  the losses of the elements beside it), 59 of 367 depth-2 insertions, 84 of 615 losses of nested insertions.
- After, audit of the kept events on carriers (scale_probe2.py): 0 insertions with a target base in an older kept
  removal; 0 nested insertions below an ending loss of a host in their chain; 0 losses of insertions below a host's
  ending loss; 0 losses of insertions whose position was removed. On each primary's own tree, 1 kept primary lies
  below a backbone loss that removed a target base. That loss's carriers, fixed on the element's tree, miss the
  insertion's carriers (see the carriers reading above).
- Every discard is justified: each discarded primary has an older kept loss that removed one of its target bases
  on a carrier's lineage (0 unjustified).
  - nested_after_loss: 413 have a discarded host, and 311 a host gone there or a target removed.
  - loss_after_loss: 570 belong to discarded insertions and 342 to insertions gone there; none belong to backbone
    elements (no element in this landscape is nested in another).
- draw_events at 5 Mb: 3.0 s (was 3.3 s); max RSS 0.38 GB; thin_events 0.2 s.

Why 30% of primaries go, not 11%: the earlier estimate read each loss on the insertion's own tree. The builder
applies a loss to its carriers, fixed on the element's tree. A deep loss (most tree length lies on the long root
and outgroup branches) removes its element in every sample below it there, and a younger insertion into that
element in those samples cannot exist. First level only (primaries against backbone-element losses):

| reading | primaries thinned |
|---|---|
| any carrier lacks the sequence (this commit) | 615 |
| all carriers lack it | 549 |
| loss node above the insertion on the insertion's own tree | 229 |

323 primaries count under "all" but not under the own-tree reading. Their carriers all lie inside the loss's
carriers, so the builder would remove the insertion from every carrier. The own-tree reading is not consistent
with how losses are applied.

### Tests (tests/test_popevents.py; 25 tests, about 3.8 s)

The ruling's tests use TREE7 by its internal nodes (01 at 3,000, 23 at 5,000, 45 at 8,000, 0123 at 12,000, 456 at
20,000, root at 40,000), events built by hand (`ins_at`, `loss_at`; carriers from the tree) and `thin_events`
directly, with exact expected lists and counters.
- test_thin_primary_below_solo: E1's solo on 0123 at 20,000 removes `[(None, 10,100, 14,400)]`.
  - Discarded: an insertion at 12,000 below the solo; one at 14,404, whose target touches 14,399.
  - Kept: the same insertion on 45; one on 0123 at 30,000 (above the solo); one at 14,405 (target just past).
  - Counters: ins_after_loss 2.
- test_thin_older_insertion_younger_solo: an insertion at 12,000, older than the solo, is kept.
  - Discarded: its replace below the solo on 01, and its solo on sample 2.
  - Kept: its del_partial above the solo.
  - Insertions at exactly 10,100 and 14,400 (the stretch's edges) and their losses below the solo are kept.
  - removed(solo) covers 12,000. Counters: loss_after_loss 2.
- test_thin_depth2_below_host_of_host: x's del_flank on 01; y nested in x above it.
  - Discarded: a depth-2 z below the del_flank (nested_after_loss 1).
  - Kept: z on 23.
- test_thin_nested_loss_below_host_loss: y's solo on sample 0 (below x's del_flank) is discarded; on sample 2 it
  is kept.
- test_thin_nested_in_solo_ltr: y sits in x's left LTR at 50; x's solo at crossover 300 removes `(x, 300, 4,800)`,
  so 50 survives.
  - Discarded: y's younger loss below the solo, and a depth-2 insertion there (the host must exist).
  - Kept: y's loss on sample 2.
- test_thin_del_flank_flanks: x at 100,000 with del_flank (1,000, 500) removes
  `[(x, 0, 5,005), (None, 99,000, 100,000), (None, 100,000, 100,495)]`.
  - Discarded: insertions in the left flank (99,500) and the right flank (100,300) below it.
  - Kept: the same left one above the loss; one at 100,500 (target [100,495, 100,500)); one at 99,000.
- test_removed_flank_runs_into_host: a nested y 100 bp from its host's body end, del_flank (0, 500).
  - On +: y's body and TSD copy, the host's [4,900, 5,000), the host's TSD copy, and backbone [100,000, 100,390).
  - On -: backbone [99,605, 100,000).
  - Also: a backbone del_flank clipped at 0, and solo, del_partial and replace of an insertion in its body.
- test_thin_overlapping_del_partials: removed() gives [10,800, 12,300) and [11,500, 13,100); their union on samples
  0-1 is [10,800, 13,100).
  - Discarded: insertions below both at 12,800 and at 13,102 (whose target reaches into the second del_partial).
  - Kept: 12,800 below the first only; 13,105.
- test_thin_backbone_element_inside_removed_one:
  - The inner element's loss below the outer one's solo is discarded (its whole span is removed).
  - Its loss below a del_partial that takes 1,000 of its 1,400 bp is kept.
- test_thin_density: draw_events without losses on TREE7, 1 Mb, lam 1e-8. Then two fixed replaces:
  - 400,000 bp above samples 0-3 from 39,000 generations (59,000 generations of branch below);
  - 100,000 bp above sample 4 from 6,000.
  - Kept primaries 1,009 against lam x sum(present positions x branch length) = 1,038.0 (SD 32.2; within 3 SD).
  - Without the thinning: 1,280 (7 SD above).
- Changed: test_loss_split now uses 80 non-overlapping elements on a 64-leaf tree (its earlier elements, 40 kb
  long and 2 kb apart, removed each other's whole spans; loss_after_loss must be 0 there).
- Also changed:
  - test_loss_parameters reads del_partial against the original internal region, and adds an 800-bp-internal
    element that takes no del_partial.
  - test_nested_carriers_and_offsets checks kept nested insertions against removed() and the host chain.

Mutation check (p3t2/mutate.py, mutate2.log): 38 mutants of the draws, removed() and thin_events; 37 caught, 1
survives:
- `not_older`: drops the `t > time` filter in `_Removals.hits`. It is equivalent, because events are decided oldest
  first, so every kept removal is at least as old; only exact time ties differ.
- Four were caught only after these were added: no PARTIAL_MIN check, inclusive edges, no host recursion and no
  own-ending check. The additions are the 800-bp element, the edge insertions and test_thin_nested_in_solo_ltr.
- The ruling's tests were written after the code. Their evidence is the mutation check plus exact expected values,
  not a RED run. Against 7bcdb96 they fail on import (no removed or thin_events).

### Fingerprints and suite

`fingerprints.sh 12d3e6c 41f70b6`: STAGE_MODULES fingerprints IDENTICAL (elements a78af75d..., anchor/raw/blastdb
ebbfd97f..., mm2_index 28f6fc79..., genotype_pair/genotype_chunk 52071c27...). `git diff --stat 12d3e6c HEAD --
src/ltrpav` touches only sim/__init__.py, sim/popmodel.py and sim/popevents.py.

Suite: detached on the staged tree (b98ebb01 at launch = tree of 41f70b6), leader bash 2226427 with PPID 1 and SID
2226427, waited with a Monitor until-loop: `1198 passed, 2 deselected in 1123.73s (0:18:43)`, `exit 0` (1188 + 10 new
tests). `ruff check .`: All checks passed!

### Choices (the ruling left room; controller to rule)

A. **Per-carrier reading, "any".** An event goes when any one of its carriers' lineages lacks its sequence, so every
   kept event exists on all its carriers' lineages and Task 4 can read carriers as recipients. "All" would keep 159
   more primaries in the probe (464 against 623 thinned); the builder would then remove them from some carriers.
B. **Target bases.** The target bases stay [pos - TSD_DEFAULT, pos): the brief puts the copy "before base pos", and
   ins_n has read that window since 7bcdb96. The ruling writes `[pos, pos + TSD_DEFAULT)`, which would hold if pos
   were the target's start; I kept one convention throughout.
C. **A host must exist.** A nested insertion that a host's solo leaves in place (in the left LTR before the
   crossover) stays in the genome (removed() keeps it, so the builder keeps it). Its younger events below the solo
   are discarded, by the ruling's "its host exists" (test_thin_nested_in_solo_ltr).
D. **Backbone elements** are gone on a lineage only when older kept removals cover their whole span, a named
   heuristic. The alternative would be Plan 1's COV_PRESENT LTR rule (gone when an LTR keeps < 80%). A partly
   removed element keeps its later losses, and the builder applies the union.
E. **Nested flanks.** A nested insertion's del_flank runs on past its host's body into the host's host (Plan 1
   deletes in the whole genome) instead of stopping at the body's edge.

### Concerns

1. Thinning removes 30% of drawn primaries, 45% of drawn nested insertions and 31% of drawn losses in the probe
   (much of it cascade). Inserted-element densities against main3 (DESIGN 12 item 4) should be read on kept
   counts. The rate per present bp per generation stays lam on each carrier's lineage.
2. Choice A against "all" (159 primaries in the probe) is a modeling call forced by fixing loss carriers on one
   tree; the brief reads backbone elements on the tree at their start.
3. Choice B conflicts with the ruling's literal target interval; one line changes it (the mutant
   `target_after_pos` is caught by 3 tests).

## Fix round 1 (task-2-review.md; rulings task-2-fix-1.md)

Commit 42607ad "Thinning reads whether sequence is present; junction rule for anchors" on 41f70b6 (user identity, no trailers, not pushed).

### Findings

- **C4a (existence reads presence).**
  - `thin_events` now has `present(x)`: x is below its event, its anchor survives the older kept removals of its
    host's system (junction rule), and its host is present, up the chain.
  - `exists(x)` = present(x) and no older kept ending loss of x's own. A host's ending loss no longer ends a nested
    element whose anchor it leaves.
  - A new nested insertion still needs its direct host to exist (own ending included). For drawn events this is
    the same thing, because B_X stops at the host's ending losses.
  - Docstring: rule 4 and the existence paragraph are rewritten. B_X stopping at X's ending losses (no insertions
    in a simulated solo LTR) is named as a simplification.
  - removed()'s docstring states the convention that a nested del_flank is measured in its host's original
    coordinates, so for y in x's solo LTR the flank runs into x's removed stretch and stops short of the far part.
  - Tests:
    - test_thin_nested_in_solo_ltr flipped: y at 50 keeps its losses and a depth-2 insertion below x's solo. y2 at
      1,000, in the removed stretch, loses its loss there. A new insertion into x below its solo is discarded.
    - test_nested_carriers_and_offsets is narrowed to the direct host.
    - test_thin_older_insertion_younger_solo gains y nested in x: y goes with x below E1's solo although its own
      anchor in x is intact (host presence).
- **I1 (stale nested-target test).** test_nested_target_not_on_n is rewritten with two donors of a 7-bp period:
  `"ACGTACN"` and `"ACGTACr"`, LTRs 700, body 6,300. It asserts the code's window [pos - 5, pos) and offsets = 5 or
  6 (mod 7), and that some kept offset is 6 (mod 7), whose next base is the N. This holds for any seed. The comment
  is fixed.
- **I2 (replacing sequence gets no insertions).** Named, not modeled:
  - The module docstring's rule 4 no longer says "exactly". Insertions arrive at lam per present bp per generation,
    except on two named simplifications that receive none: the replacing sequence of a replace, and the solo LTR of
    a simulated insertion.
  - DESIGN 12 item 7 says the same, with the probe's numbers.
  - Expected missing insertions at 5 Mb (replace_deficit.py, sum of lam x a x B_R over kept replaces): **460.3**,
    31.6% of the 1,458 kept primaries. Simulated solo LTRs: **8.9**.
- **M1 (nested rate).** test_nested_rate: TREE16, delta 0, five seeds. The donors have LTRs of 3,000 and 100, so a
  body of 8,000 against a seq of 5,100.
  - depth 1: 2,610 observed against 2,684.4 expected (z -1.44);
  - depth 2: 1,982 against 1,993.1 (z -0.25);
  - each within 3 SD, with expected = sum of lam x (len(body) - 5) x B_X;
  - a len(seq) rate would expect 1,711.
- **M2 (carriers approximation).** One docstring paragraph calls the "any carrier" reading the approximation that
  reading each element on one tree forces. It names both effects: discarded insertions present on some carriers,
  and a discarded ending loss still truncating the draw below it.
  - Oracle counts at 5 Mb: 79 such insertions, 13 ending losses and 17 del_partials.
- **M3 (junction rule).**
  - An insertion anchored before base s of its host's system is removed where bases s - 1 and s are both removed by
    the union of kept removals there, and with its host.
  - Nested offsets are drawn in [TSD_DEFAULT, len(body)), with the count Poisson(lam x (len - 5) x B_X), so the
    rate stays lam per eligible bp.
  - Both rules are stated in removed()'s docstring for Task 3.
  - test_thin_same_position_del_flank: w at x's position goes with x's two-sided del_flank. It stays under a
    one-sided del_flank (end side, a = 0; start side, b = 0) and under x's replace.
- **M4.** test_loss_split's comment now says that the elements are kept by the whole-span rule, not distance.
- **M5.** Nested `Ins.time` is a Python float. test_nested_carriers_and_offsets asserts `type(time) is float` for
  every insertion and loss.

### Evidence

- RED: the fix-round tests against 41f70b6's `src/` (git archive, PYTHONPATH; `ltrpav.__file__` checked) give
  `4 failed, 23 passed`:
  - test_nested_carriers_and_offsets (offsets under 5);
  - test_nested_target_not_on_n;
  - test_thin_nested_in_solo_ltr (C4a);
  - test_thin_same_position_del_flank (junction).
  - test_nested_rate passes there too: the old rate differs by 5 bp in 8,000. Its evidence is the mutants below.
- Mutation check (p3t2/mutate.py, fix1/mutate4.log): 46 mutants, 45 caught. Added this round:
  - offsets from 0;
  - the nested rate with len(seq) and with 2 lam;
  - the nested target read after pos;
  - a numpy time;
  - the strict-inside rule (as at 41f70b6);
  - one base enough;
  - the host's ending check back in the chain (as at 41f70b6);
  - no host presence;
  - no own-ending check;
  - a new insertion needing only host presence.
  - The survivor is `not_older`, which stays equivalent (oldest-first order).
- Oracle (the reviewer's oracle_c4a.py copied to fix1/oracle_fix1.py; C4a host chain; junction rule on the
  per-sample union; a new insertion's direct host must exist): 0 disagreements at 2 Mb (897 insertions, 762 losses
  kept) and at 5 Mb (2,325 insertions, 1,926 losses kept). The order of the elements list does not change the
  events.
  - Drawn: 0 nested offsets under 5, and 0 (host, pos) shared.

### New counts (5-Mb probe, fix1/scale_probe3.py, same seeds)

| | 41f70b6 kept | now drawn | now kept | dropped |
|---|---|---|---|---|
| primary insertions | 1,462 | 2,085 | 1,458 | ins_after_loss 627 |
| nested insertions | 902 (686 d1, 216 d2) | 1,588 | 867 (669 d1, 198 d2) | nested_after_loss 721 |
| losses | 2,007 | 2,867 | 1,926 | loss_after_loss 941 |
| del_partial / replace / del_flank / solo (kept) | 1,008 / 406 / 331 / 262 | | 962 / 386 / 331 / 247 | |

- The draws after the first nested insertion differ from 41f70b6 (new offset range and rate), so the counts move.
  Backbone losses are drawn before that and are unchanged.
- Audit of the kept events, on carriers (replaces the earlier line; C4a narrows the host check to the direct host):
  - 0 insertions with a target base in an older kept removal;
  - 0 nested insertions below an ending loss of their direct host;
  - 0 losses below an ending loss of their own;
  - 0 events of insertions whose anchor, or a host's, was removed (junction rule).
  - Read on each primary's own tree instead, 1 kept primary lies below a backbone loss whose fixed carriers miss it,
    as before.
- draw_events 3.3 s at 5 Mb; max RSS 0.38 GB.

### Fingerprints and suite

`fingerprints.sh 12d3e6c 42607ad`: STAGE_MODULES fingerprints IDENTICAL. The diff touches only
sim/popevents.py, tests/test_popevents.py and docs/DESIGN.md.

Suite: detached on the staged tree (de51ecca at launch = tree of 42607ad), leader bash 185396 with PPID 1 and SID
185396, waited with a Monitor until-loop: `1200 passed, 2 deselected in 666.68s (0:11:06)`, `exit 0` (1198 + 2 new
tests). `ruff check .`: All checks passed!

### Concerns

1. The replacing sequence gets no insertions: 460 expected insertions per 5 Mb against 1,458 kept primaries. It is
   named (docstring, DESIGN 12 item 7, here) for the Task 6/7 density readout. It is not modeled.
2. A new nested insertion needs its direct host to exist, own ending loss included; a host's host only needs to be
   present. For drawn events this changes nothing, since B_X never places one below its host's ending loss. For
   hand-built events a direct host's ending loss discards it (test_thin_nested_in_solo_ltr).
