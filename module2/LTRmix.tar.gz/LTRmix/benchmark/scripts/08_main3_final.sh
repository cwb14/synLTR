#!/usr/bin/env bash
B=/data2/chris/maize_introgression/benchmark
source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix
export NUMPY_MADVISE_HUGEPAGE=0
cd $B/results && rm -rf main3 && ./run_main3.sh > main3.log 2>&1
python $B/scripts/eval_real.py main3 --nperm 1000 > main3/benchmark_real.stdout 2>&1
python $B/scripts/sim_summary.py $B/sim > $B/sim/sim_summary.txt 2>&1
echo "$(date '+%F %T') FINAL_RERUN_DONE" >> $B/logs/final_rerun.log
