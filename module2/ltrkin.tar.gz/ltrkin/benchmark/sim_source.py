#!/usr/bin/env python3
"""Forward simulation of LTR-RT family genealogies with known parents, planted in a synthetic genome, to benchmark
`ltrkin source` (ancestry). No read simulation: statuses are written as genotype calls.

Model (per family, discrete time steps):
  - every living copy gains point mutations at rate MU per base per step (internal and both LTRs, independently);
  - every living ACTIVE copy transposes with probability BIRTH per step; the new copy inherits the parent's internal
    region with reverse-transcription errors (RT_ERR per base); both of its LTRs = U3 from the parent's 3' LTR
    (first 80%) + U5 from the parent's 5' LTR (last 20%), the reverse-transcription template rule; a new copy is
    active with probability P_ACTIVE;
  - every copy is lost with probability LOSS per step (its descendants survive: unsampled parents);
  - at the end a copy of age a (steps) is still polymorphic ("new") with probability exp(-a / TAU), else "fixed".
Truth: each copy's parent and birth time. Output: genome.fa, elements.gff3, genotypes.tsv (ltrkin format), truth.tsv.
"""
import argparse
import math
import os
import random

import numpy as np

B = np.frombuffer(b"ACGT", dtype=np.uint8)


def mutate(rng, a, rate):
    n = rng.binomial(len(a), rate)
    if n:
        pos = rng.choice(len(a), n, replace=False)
        a[pos] = (a[pos] + rng.integers(1, 4, n)) % 4
    return a


def simulate_family(rng, fam, ltr_len, int_len, steps, mu, birth, rt_err, loss, p_active, max_copies, p_rec=0.0):
    ltr = rng.integers(0, 4, ltr_len).astype(np.uint8)
    copies = [dict(id=f"{fam}_c0", parent=None, born=0, ltr5=ltr.copy(), ltr3=ltr.copy(),
                   internal=rng.integers(0, 4, int_len).astype(np.uint8), active=True, alive=True, partner=None, bp=-1)]
    u3 = int(0.8 * ltr_len)
    for t in range(1, steps + 1):
        living = [c for c in copies if c["alive"]]
        for c in living:
            for k in ("ltr5", "ltr3", "internal"):
                mutate(rng, c[k], mu)
        new = []
        actives = [c for c in living if c["active"]]
        for c in living:
            if c["active"] and rng.random() < birth and len(copies) + len(new) < max_copies:
                lt = np.concatenate([c["ltr3"][:u3], c["ltr5"][u3:]])
                lt = mutate(rng, lt.copy(), rt_err)
                internal, partner, bp = c["internal"].copy(), None, -1
                others = [o for o in actives if o is not c]
                if p_rec > 0 and others and rng.random() < p_rec:   # template switch to a co-packaged RNA
                    o = others[int(rng.integers(len(others)))]
                    bp = int(rng.integers(int(0.1 * len(internal)), int(0.9 * len(internal))))
                    internal = np.concatenate([internal[:bp], o["internal"][bp:]])
                    partner = o["id"]
                new.append(dict(id=f"{fam}_c{len(copies) + len(new)}", parent=c["id"], born=t, ltr5=lt.copy(),
                                ltr3=lt.copy(), internal=mutate(rng, internal, rt_err),
                                active=rng.random() < p_active, alive=True, partner=partner, bp=bp))
        copies += new
        for c in living:
            if rng.random() < loss:
                c["alive"] = False
    return copies


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-o", "--outdir", required=True)
    ap.add_argument("--families", type=int, default=6)
    ap.add_argument("--steps", type=int, default=600)
    ap.add_argument("--mu", type=float, default=1e-5, help="point mutations per base per step [1e-5]")
    ap.add_argument("--birth", type=float, default=0.006)
    ap.add_argument("--rt-err", type=float, default=5e-5)
    ap.add_argument("--loss", type=float, default=0.001)
    ap.add_argument("--p-active", type=float, default=0.5)
    ap.add_argument("--tau", type=float, default=60.0, help="steps over which insertions become fixed [60]")
    ap.add_argument("--max-copies", type=int, default=400)
    ap.add_argument("--p-rec", type=float, default=0.0, help="probability a new copy is a two-parent mosaic [0]")
    ap.add_argument("--chroms", type=int, default=4)
    ap.add_argument("--seed", type=int, default=1)
    a = ap.parse_args()
    rng = np.random.default_rng(a.seed)
    prng = random.Random(a.seed)
    os.makedirs(a.outdir, exist_ok=True)
    all_copies, genealogy = [], []
    for f in range(a.families):
        cps = simulate_family(rng, f"fam{f}", int(rng.integers(400, 1500)), int(rng.integers(4000, 9000)), a.steps,
                              a.mu, a.birth, a.rt_err, a.loss, a.p_active, a.max_copies, a.p_rec)
        for c in cps:
            c["family"] = f"fam{f}"
            genealogy.append((c["id"], c["family"], c["parent"] or ".", c["born"], int(c["alive"]), c["partner"] or ".", c["bp"]))
        all_copies += [c for c in cps if c["alive"]]
    prng.shuffle(all_copies)
    # plant on chromosomes with random spacers and 5-bp TSDs
    chroms = {f"chr{i + 1}": [] for i in range(a.chroms)}
    names = list(chroms)
    for c in all_copies:
        chroms[prng.choice(names)].append(c)
    gff, gt, truth = [], [], []
    with open(f"{a.outdir}/genome.fa", "w") as fa:
        for ch, lst in chroms.items():
            parts, pos = [], 0
            for c in lst:
                sp = rng.integers(0, 4, int(rng.integers(3000, 12000))).astype(np.uint8)
                tsd = rng.integers(0, 4, 5).astype(np.uint8)
                el = np.concatenate([c["ltr5"], c["internal"], c["ltr3"]])
                parts += [sp, tsd, el, tsd]
                s = pos + len(sp) + 5
                e = s + len(el)
                l5, l3 = len(c["ltr5"]), len(c["ltr3"])
                gff.append(f"{ch}\tsim\tLTR_retrotransposon\t{s + 1}\t{e}\t.\t+\t.\tID={c['id']};family={c['family']};clade=sim")
                gff.append(f"{ch}\tsim\tlong_terminal_repeat\t{s + 1}\t{s + l5}\t.\t+\t.\tID={c['id']}.l;Parent={c['id']}")
                gff.append(f"{ch}\tsim\tlong_terminal_repeat\t{e - l3 + 1}\t{e}\t.\t+\t.\tID={c['id']}.r;Parent={c['id']}")
                pos = e + 5
                c["chrom"], c["start"] = ch, s + 1
            parts.append(rng.integers(0, 4, 5000).astype(np.uint8))
            seq = B[np.concatenate(parts)].tobytes().decode()
            fa.write(f">{ch}\n" + "\n".join(seq[i:i + 80] for i in range(0, len(seq), 80)) + "\n")
    for c in all_copies:
        age = a.steps - c["born"]
        status = "new" if prng.random() < math.exp(-age / a.tau) else "fixed"
        c["status"] = status
        gt.append(f"{c['id']}\tsim\t{'F/E' if status == 'new' else 'F/F'}\t99\tPASS")
        truth.append(f"{c['id']}\t{c['family']}\t{c['parent'] or '.'}\t{c['born']}\t{age}\t{status}\t{c['chrom']}\t{c['start']}")
    with open(f"{a.outdir}/elements.gff3", "w") as fh:
        fh.write("##gff-version 3\n" + "\n".join(gff) + "\n")
    with open(f"{a.outdir}/genotypes.tsv", "w") as fh:
        fh.write("element_id\tsample\tgenotype\tgq\tflags\n" + "\n".join(gt) + "\n")
    alive = {c["id"] for c in all_copies}
    with open(f"{a.outdir}/genealogy.tsv", "w") as fh:
        fh.write("copy_id\tfamily\tparent\tborn\talive\tpartner\tbreakpoint\n" + "".join("\t".join(map(str, g)) + "\n" for g in genealogy))
    with open(f"{a.outdir}/truth.tsv", "w") as fh:
        fh.write("element_id\tfamily\tparent\tborn\tage\tstatus\tchrom\tstart\n" + "\n".join(truth) + "\n")
    n_new = sum(c["status"] == "new" for c in all_copies)
    n_par_alive = sum(1 for c in all_copies if c["parent"] in alive)
    print(f"copies alive {len(all_copies)}; new {n_new}; parent alive {n_par_alive}")


if __name__ == "__main__":
    main()
