#!/usr/bin/env bash
# Robustness of one ltrkin version on one species and reference (run after the main matrix):
#  1. primary-only BAMs (20x, 60x)   2. annotation boundaries jittered by +-5, 20, 50 bp (seed 1)
#  3. one multi-sample run (diploid 20x + other-haplotype 10x) against the single-sample runs
# usage: robustness.sh <version tag> <ltrkin src dir> [S=Camara] [ref=hap1] [threads=8]; config.yaml in the working dir
set -euo pipefail
V=$1; SRC=$(readlink -f "$2"); S=${3:-Camara}; ref=${4:-hap1}; T=${5:-8}
W=$(dirname "$(readlink -f "$0")")
REF=data/$S/${S}_$ref.fa
GFF=$(python -c "import yaml; print(yaml.safe_load(open('config.yaml'))['gff'].format(S='$S', ref='$ref'))")
O=$S/robust/$V; mkdir -p $O $S/jitter
run() {  # prefix gff bam...
  local pre=$1 g=$2; shift 2
  [[ -s $pre.genotypes.tsv ]] && return 0
  PYTHONPATH=$SRC /usr/bin/time -v -o $pre.time python -m ltrkin.cli genotype -r $REF -a $g -o $pre -t $T -v "$@" > $pre.log 2>&1
}
snakemake -s $W/Snakefile --configfile config.yaml --cores $T $S/sub/${ref}_d20_s1.prim.bam $S/sub/${ref}_d60_s1.prim.bam $S/part/${ref}_h10.bam > $O/snake_inputs.log 2>&1
for J in 5 20 50; do [[ -s $S/jitter/${ref}_J$J.gff3 ]] || python $W/../jitter_gff.py $GFF $J 1 > $S/jitter/${ref}_J$J.gff3; done
for d in 20 60; do
  run $O/prim_d$d $GFF $S/sub/${ref}_d${d}_s1.prim.bam
  for J in 5 20 50; do run $O/jit${J}_d$d $S/jitter/${ref}_J$J.gff3 $S/sub/${ref}_d${d}_s1.bam; done
done
run $O/multi $GFF $S/sub/${ref}_d20_s1.bam $S/part/${ref}_h10.bam
