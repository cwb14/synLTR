"""Commands ltrpav-stats, ltrpav-paint and ltrpav-plot, and run_analyses, which `ltrpav run` ends with.

  ltrpav-stats  the stats stage: run summary, relationships and roles, trio tests, inversions, direction,
                mechanisms and, with --identity, the sequence-identity layer; --block-size sets the jackknife
                block length (default: the rule of stats.block_size)
  ltrpav-paint  the paint stage: each trio's recipient painted, with its decoy
  ltrpav-plot   the plot stage: the overview figure (overview.png, overview.pdf, overview_numbers.tsv) of the
                finished stages; --trio picks the lead trio
Each reads a finished run (after ltrpav run or ltrpav-merge) as data and runs its checkpointed stage
(report.py); stats and paint then rebuild stats.tsv and findings.txt from the parts of the finished stages whose
key is still current (a stale part is left out, with a WARNING naming why: report.stale_parts). Each option is
in its stage's key (report.OPTIONS): a stage run with other options reruns, and the same options skip it; `ltrpav
run` runs every stage at the defaults and has none of these options. None runs an
engine-fingerprint check (ltrpav-merge's `_check_pair_files`, or any stage fingerprint): a run finished by an
older engine is read as it stands, and only a change in the outputs read or in the code the analyses run
reruns them. Inside `ltrpav run` a figure error is a WARNING (the analyses' outputs are complete; exit 0); in
ltrpav-plot it is an error.

Fail fast, one error line (exit 1): a Python module that cannot be imported (scipy, matplotlib or the analysis
package: checked first by `import_analysis_modules`, and by `ltrpav run` before any genotyping); a bad samples
sheet; a --trio that is not three distinct labels of the sheet
or names an outgroup (checked before the run is read, and by `ltrpav run` before any genotyping); a run
without manifest.json (no finished merge); --identity without the engine's aligner on PATH; ltrpav-plot
without stats.tsv, or with a stats part that is unfinished, stale (the run or the analysis code changed since
that stage ran) or not in stats.tsv, or a finished paint part likewise (report.plot_refusals, from the markers
and stats.tsv's sentinel rows). A run directory whose files do not match the sheet or each other
fails in the catalog (catalog.AnalysisError). A --trio that is not three comma-separated labels, a --block-size
that is not an integer of at least BLOCK_MIN is a usage error (exit 2).

Imports: the parsers and the exit status are the engine's (`ltrpav.cli._options`, `_execute`: 0 done; 1 one
line "error: ..."; 2 usage). scipy, matplotlib, the analysis modules and ltrpav.plot are imported inside the
stage functions only, so `import ltrpav.analysis.cli`, and `ltrpav.cli`, which imports it to run the analyses,
need neither scipy nor matplotlib to import.
"""
from __future__ import annotations

import argparse
import contextlib
import importlib
import logging
import time
from collections.abc import Sequence
from pathlib import Path

from .. import __version__
from ..cli import CliError, _backend, _execute, _options, positive_int
from ..constants import DEFAULT_BACKEND
from ..samples import Sample, read_samples
from .constants import (
    BLOCK_BP,
    BLOCK_FRAC,
    BLOCK_MIN,
)

log = logging.getLogger("ltrpav.analysis")

_INPUT = ("Reads a finished run (ltrpav run or ltrpav-merge) as data and rebuilds stats.tsv and findings.txt "
          "from the finished stages; a finished stage is skipped.")


def import_analysis_modules() -> None:
    """Import the modules of every analysis stage at once, the figure's included (scipy, matplotlib, the
    analysis package, the overview plot), whichever stage a command runs, so a broken environment fails at
    once with ltrpav.cli's one-line ImportError report, not partway through a run."""
    for name in ("scipy.optimize", "scipy.special", "scipy.stats", "matplotlib", "ltrpav.analysis.report",
                 "ltrpav.plot.overview"):
        importlib.import_module(name)


def trio_arg(text: str) -> tuple[str, str, str]:
    """--trio R,S,D: three labels (checked against the sheet by check_trio)."""
    parts = tuple(text.split(","))
    if len(parts) != 3 or not all(parts):
        raise argparse.ArgumentTypeError(f"expected three labels R,S,D (recipient, sister, donor): {text!r}")
    return parts


def block_arg(text: str) -> int:
    """--block-size BP: an integer of at least BLOCK_MIN."""
    try:
        n = int(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"not an integer: {text!r}") from None
    if n < BLOCK_MIN:
        raise argparse.ArgumentTypeError(f"must be at least {BLOCK_MIN} bp: {n}")
    return n


def add_options(p: argparse.ArgumentParser, identity: bool = False, threads: bool = False
                ) -> argparse.ArgumentParser:
    """The analyses' options: --trio; --identity and --threads where asked (ltrpav run has its own --threads)."""
    p.add_argument("--trio", type=trio_arg, metavar="R,S,D",
                   help="the trio's roles: recipient, sister, donor (default: every trio of ingroup genomes, roles "
                        "from the data)")
    if identity:
        p.add_argument("--identity", action="store_true",
                       help="add the sequence-identity layer: LTR divergence of shared insertions, realigned "
                            "with LASTZ (slow)")
    if threads:
        p.add_argument("--threads", type=positive_int, default=8, metavar="N",
                       help="threads of the identity layer (default: 8)")
    return p


def stats_main(argv: list[str] | None = None) -> int:
    """`ltrpav-stats`: the stats stage."""
    parser = add_options(_options(argparse.ArgumentParser(
        prog="ltrpav-stats", epilog="Painting: ltrpav-paint (same --trio).",
        description="Relationships and roles, trio tests (D_pav, age strata, f4-ratio), inversions, direction "
                    "and mechanisms of a finished run: stats.tsv, findings.txt, inversions.tsv, mechanisms.tsv "
                    "(identity.tsv with --identity). " + _INPUT)), identity=True, threads=True)
    parser.add_argument("--block-size", type=block_arg, metavar="BP",
                        help=f"jackknife block length, at least {BLOCK_MIN:,} bp (default: {BLOCK_BP:,} bp, or "
                             f"1/{BLOCK_FRAC} of the smallest genome when shorter, at least {BLOCK_MIN:,})")
    return _execute(parser, argv, "ltrpav-stats", _stats)


def paint_main(argv: list[str] | None = None) -> int:
    """`ltrpav-paint`: the paint stage."""
    parser = add_options(_options(argparse.ArgumentParser(
        prog="ltrpav-paint", epilog="Statistics: ltrpav-stats (run it first; same --trio).",
        description="Paint each trio's recipient along its genome, with the sister as decoy: tracts.<R>.bed, "
                    "posterior.<R>.tsv, decoy_tracts.<S>.bed, decoy_posterior.<S>.tsv. " + _INPUT)))
    return _execute(parser, argv, "ltrpav-paint", _paint)


def plot_main(argv: list[str] | None = None) -> int:
    """`ltrpav-plot`: the plot stage."""
    parser = add_options(_options(argparse.ArgumentParser(
        prog="ltrpav-plot", epilog="Run ltrpav-stats and ltrpav-paint first; the figure is redrawn only when "
                                   "they or the run change, and refused while their results are out of date.",
        description="Draw the overview figure of a finished run's analyses: overview.png (300 dpi), overview.pdf "
                    "(figure, short and long legend) and overview_numbers.tsv (every legend number with its "
                    "source file). The lead trio: --trio, else the trio with the largest D_pav |Z|.")))
    return _execute(parser, argv, "ltrpav-plot", _plot)


def _stats(args: argparse.Namespace, command: list[str]) -> None:
    _analyses(args.samples, args.outdir, args.trio, args.identity, args.threads, ("stats",),
              {"block_size": args.block_size})


def _paint(args: argparse.Namespace, command: list[str]) -> None:
    _analyses(args.samples, args.outdir, args.trio, False, 1, ("paint",))


def _plot(args: argparse.Namespace, command: list[str]) -> None:
    _analyses(args.samples, args.outdir, args.trio, False, 1, ("plot",))


def run_analyses(samples_path: Path, outdir: Path, trio: tuple[str, str, str] | None, identity: bool,
                 threads: int) -> None:
    """The analysis stages of a finished run, in order (report.STAGES: stats, paint), each skipped when done;
    then stats.tsv and findings.txt; then the plot stage (the overview figure). Every stage option is at its
    default (report.OPTIONS). `ltrpav run` calls this after its merge and exits 3 on any error it raises; a plot-stage
    error is caught here and logged as a WARNING, so a figure error leaves `ltrpav run` at exit 0."""
    _analyses(samples_path, outdir, trio, identity, threads, None)


def check_trio(samples: list[Sample], trio: tuple[str, str, str] | None, sheet: Path) -> None:
    """CliError unless --trio names three distinct labels of the sheet, none an outgroup (None: nothing to
    check)."""
    if trio is None:
        return
    labels = [s.label for s in samples]
    spec = ",".join(trio)
    unknown = [x for x in trio if x not in labels]
    if unknown:
        raise CliError(f"--trio {spec}: {unknown[0]!r} is not a label of {sheet} ({', '.join(labels)})")
    if len(set(trio)) != 3:
        raise CliError(f"--trio {spec}: the recipient, sister and donor must be three different genomes")
    out = [s.label for s in samples if s.label in trio and s.role == "outgroup"]
    if out:
        raise CliError(f"--trio {spec}: {', '.join(out)} has role outgroup in {sheet}; a trio is three ingroup "
                       "genomes")


def _analyses(samples_path: Path, outdir: Path, trio: tuple[str, str, str] | None, identity: bool, threads: int,
              stages: Sequence[str] | None, options: dict | None = None) -> None:
    """Check the inputs (module docstring), load the catalog once, run `stages` (None: every stage) with `options`
    (report.stage_options; None: the defaults) and assemble."""
    import_analysis_modules()
    t0 = time.perf_counter()
    samples_path, outdir = Path(samples_path), Path(outdir)
    samples = read_samples(samples_path)
    check_trio(samples, trio, samples_path)
    if not (outdir / "manifest.json").is_file():
        raise CliError(f"no finished merge in {outdir} (manifest.json missing): run ltrpav run or ltrpav-merge "
                       "first")
    from . import report  # imported here: the commands' --help and parsing stay fast
    from .catalog import load_catalog

    soft = stages is None  # ltrpav run: a figure error is a warning
    stages = (*report.STAGES, report.PLOT) if stages is None else tuple(stages)
    analysis = [s for s in stages if s in report.STAGES]
    if identity and "stats" in stages:
        _backend(DEFAULT_BACKEND)  # the identity layer realigns with the engine's aligner
    given = "".join(f", --{name.replace('_', '-')} {value}" for stage in analysis
                    for name, value in report.stage_options(stage, options).items()
                    if value != report.OPTIONS[stage][name])
    log.info("ltrpav %s analyses (%s) of %s: %d genomes, %s%s%s", __version__, ", ".join(stages), outdir.absolute(),
             len(samples), "roles from the data" if trio is None else f"--trio {','.join(trio)}",
             ", with the identity layer" if identity and "stats" in stages else "", given)
    t1 = time.perf_counter()
    cat = load_catalog(outdir, samples, samples_path)
    log.info("catalog: %d loci, %d genomes (%.1f s)", len(cat.lid), len(cat.labels), time.perf_counter() - t1)
    try:
        for stage in analysis:
            report.run_stage(cat, stage, trio, identity, threads, options)
    except BaseException:
        with contextlib.suppress(Exception):  # the assembled files then hold the current finished stages only
            report.assemble(outdir, report.stale_parts(cat))
        raise
    if analysis:
        stats, findings = report.assemble(outdir, report.stale_parts(cat))
        log.info("analyses done in %.1f s -> %s, %s", time.perf_counter() - t0, stats.name, findings.name)
    if report.PLOT in stages:   # run_plot refuses a run without stats.tsv, its previous figure deleted
        try:
            report.run_stage(cat, report.PLOT, trio, identity, threads)
        except Exception as exc:
            if not soft:
                raise
            what = " ".join(f"{type(exc).__name__}: {exc}".split())
            log.warning("figure failed (%s); the analyses' outputs in %s are complete: rerun ltrpav-plot "
                        "(-v for the traceback)", what, outdir)
            log.debug("figure traceback", exc_info=True)
