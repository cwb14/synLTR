#!/usr/bin/env bash
# LTRquest 5042a1e on the extra benchmark genomes (PT, TIL25, TIL11) with the flags of the main run, in
# benchmark/ltrquest_extra/ (run/ is never touched). Waits for the prepared FASTAs, then for < THRESH busy threads
# over a 60 s window (rule copied from scripts/05_wait_and_launch.sh), then runs.
set -u
PROJECT=/data2/chris/maize_introgression
COMMIT=5042a1e
R=$PROJECT/benchmark/ltrquest_extra; L=$PROJECT/benchmark/logs; mkdir -p "$R" "$L"
THRESH=100; WIN=60
ev() { echo "$(date '+%F %T') $*" >> "$L/ltrquest_extra_events.log"; }
[[ -e $R/job.started ]] && { ev "ABORT already started"; exit 1; }
G=("$PROJECT/inputs/PT.fa" "$PROJECT/inputs/TIL25.fa" "$PROJECT/inputs/TIL11.fa")
ev "WAIT_INPUTS"
until [[ -s ${G[0]} && -s ${G[1]} && -s ${G[2]} ]]; do sleep 60; done
ev "INPUTS_READY"
NCPU=$(grep -c ^processor /proc/cpuinfo)
sample() { awk '/^cpu /{print $2+$3+$4+$7+$8+$9, $2+$3+$4+$5+$6+$7+$8+$9; exit}' /proc/stat; }
read -r b0 t0 < <(sample)
while :; do
  sleep "$WIN"; read -r b1 t1 < <(sample)
  busy=$(awk -v b=$((b1-b0)) -v t=$((t1-t0)) -v c="$NCPU" 'BEGIN{printf "%.0f", (t>0)?c*b/t:c}'); b0=$b1; t0=$t1
  echo -e "$(date '+%F %T')\t$busy\t$(cut -d' ' -f1 /proc/loadavg)" >> "$L/ltrquest_extra_cpu.tsv"
  (( busy < THRESH )) && break
done
set +u; source /home/chris/bin/etc/profile.d/conda.sh; conda activate "ltrquest_$COMMIT"; set -u
export LTRQUEST_TOOLS_DIR=$PROJECT/code/tools OMP_NUM_THREADS=8
head=$(timeout 30 git ls-remote https://github.com/cwb14/LTRquest.git HEAD 2>/dev/null | cut -c1-7)
[[ $head == "$COMMIT" ]] || ev "HEAD_CHECK origin=${head:-unreachable} pinned=$COMMIT (running pinned)"
touch "$R/job.started"; cd "$R" || exit 1
ev "LAUNCH busy_threads=$busy commit=$COMMIT threads=120"
rc=0
/usr/bin/time -v -o "$L/ltrquest_extra_time.txt" ltrquest --genome "${G[@]}" \
  --proteins "$PROJECT/inputs/B73v5.proteins.fa.gz" --threads 120 \
  --max-rounds 3 --detect-args "ltr-timeout=300" --run-sdust --no-plots --reboundary > ltrquest.log 2>&1 || rc=$?
echo "$rc" > "$R/job.exit"; ev "JOB_EXIT rc=$rc"
