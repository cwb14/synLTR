# Task 12 report: preliminary run on B73, TIL18, TIL01 + Zd and the comparison with the papers

Status: DONE_WITH_CONCERNS (concerns at the end; none blocks the record)
Branch plan2-analyses, base 2c2e639. Commit: 88e07b2 "Record Plan 2 analyses outcome" (docs/DESIGN.md
section 12 only, 8 lines added).
Tests: `python -m pytest -W error -m "not slow"` after the DESIGN edit: 1121 passed, 2 deselected in 441 s, exit 0. Before
the launch, at 2c2e639: exit 0, 1121 passed. The commit uses the existing identity (cwb14), with no trailers; nothing was
pushed.

## What I ran

View (ruling 1), V = /data2/chris/maize_introgression/benchmark_pav/main3_analyses, M = .../benchmark_pav/main3:
```
mkdir -p $V/work $V/snapshots && cd $V
for f in loci.tsv manifest.json pairs; do ln -sfn $M/$f $f; done
ln -sfn $M/qc_fixed/qc.tsv qc.tsv; ln -sfn $M/work/elements work/elements; cp $M/samples.tsv samples.tsv
touch snapshots/start.marker
find $M -maxdepth 3 -printf '%P\t%y\t%s\t%T@\n' | LC_ALL=C sort > snapshots/main3.before.tsv
stat --printf '%n\t%s\t%Y\n' /data2/chris/maize_introgression/inputs/*.fai > snapshots/fai.before.tsv
sha256sum /data2/chris/maize_introgression/inputs/*.fai > snapshots/fai.before.sha256
```
The annot_sensitivity rows (the qc.tsv rows the analyses read) are identical in M/qc.tsv and M/qc_fixed/qc.tsv;
neither file has skipped_* rows.

Preconditions (Step 1):
- M/manifest.json exists.
- samples.tsv has B73 maize, TIL18 mexicana, TIL01 parviglumis, Zd diploperennis (role outgroup).
- `pgrep -af "ltrpav|lastz"` showed no job (only the probe's own shell); load 98-102, 541 GB free.
- `python -m pytest -W error -m "not slow"` at 2c2e639: exit 0 in 364 s, 1121 tests passed. An extra -q on top of
  the pyproject's -q hid the summary line; I counted 1121 dots and no F or E.

run_analyses.sh. It has `set -euo pipefail`, `trap 'echo $? > analyses.exit' EXIT` and
`export NUMPY_MADVISE_HUGEPAGE=0`. The brief's three commands run in order, each wrapped in
`/usr/bin/time -v -o time.<stage>.txt`, with a date line before each. Then `touch analyses.done`:
```
ltrpav-stats --samples samples.tsv --outdir . --identity --threads 32
ltrpav-paint --samples samples.tsv --outdir .
ltrpav-plot --samples samples.tsv --outdir .
```
Launch from V at 06:59:41: `setsid -f nohup mamba run -n ltrpav bash run_analyses.sh > analyses.log 2>&1 < /dev/null`.

PID check (`pgrep -af run_analyses.sh`, `ps -o pid,ppid,sid,pgid,cmd`):
- leader 2607351 `mamba run -n ltrpav bash run_analyses.sh`: PPID 1, SID 2607351 = PID;
- child 2608089 `bash run_analyses.sh`: PPID 2607351, SID 2607351.

Timings (time.*.txt; host load 100-137):
- stats: 20:36 wall, 0.73 GiB peak RSS. The identity alignment of 50,836 pairs and 86,972 self copies at 44,695 loci
  took 954 s at 32 threads (53 pairs/s); the fits and outputs took 3.7 min, serially.
- paint: 23 s, 0.57 GB. plot: 25 s, 1.1 GB.
- Done at 07:21:06: analyses.exit 0, analyses.done present.

I waited with Monitor until-loops, never a foreground sleep. Then:
```
export NUMPY_MADVISE_HUGEPAGE=0 && mamba run -n ltrpav python compare_papers.py > compare_papers.log 2>&1   # 80-95 s, timeout 15m
python investigate_misses.py > investigate_misses.txt                                                      # 8 s
```

Step 3 checks:
- analyses.done exists.
- findings.txt's Run, Relationships and Trio tests sections are present and as expected: roles from the data; D_pav
  +0.2905 ± 0.0392, Z 7.42; the strata; the f4-ratio skipped with no second donor; one warning (branches_resolution:
  Zd resolved at 0.25).
- stats.tsv holds every row compare_papers.py reads (it fails fast otherwise).
- The painting, inversion and mechanism files are byte-identical to Task 11's view. The tracts differ only in
  youngest_u95, now filled from identity.tsv. overview_numbers.tsv is byte-identical to Task 11's final render.

## compare_papers.py (V/compare_papers.py)

- Imports: numpy, scipy (spearmanr, rankdata, hypergeom), csv and gzip, plus the ltrpav package:
  - `load_catalog` and `discover`, as the brief names;
  - `pav_distances` (discover's dist argument);
  - `stats.block_ids`, `block_size`, `d_ratio` and `jackknife` (the re-binned Z);
  - `samples.read_samples` (to load the catalog);
  - the constants Q_TRACT and Z_SIG.

  No new environment.
- One scoring code: windows, shift_test, element_truth, auc, tract_snps, elai_runs, tract_recall, named_locus and
  hf_test are numpy ports of eval_real.py.
  - Both tools' per-locus tables go through them with the same weights, 1,000 shifts and seeds (1 for windows, 2 for
    the high-frequency regions).
  - Every window, chromosome and high-frequency mean is computed unweighted and weighted by span (end - start + 1).
  - LTRmix rows use its ancestry posterior; tracts use both modes.
- Outputs:
  - prelim_papers.tsv: 103 rows, columns section, item, ltrpav, ltrmix, bar, verdict, note;
  - ltrmix_crosscheck.tsv;
  - prelim_tables/{chromosomes,windows}.tsv.
- Verdicts: PASS (prelim) 19, MISS (prelim) 5, reported 78, skipped 1. A rerun gives identical rows: the script is
  deterministic.

## The 14 sections (source: V/prelim_papers.tsv unless named)

1. **Roles**, reported (stats.tsv sharing and roles rows):
   - sisters B73 + TIL01 (maize + parviglumis), donor TIL18 (mexicana), recipient B73 by the sign of D_pav; matches
     the sheet's groups;
   - shared counts 5,392 / 3,097 / 1,828; p_top 1.6e-138;
   - LTRmix the same (k-mers).
2. **Admixture in B73**:
   - D_pav +0.2905 ± 0.0392, Z 7.42 (1,317/724; 425 blocks): **PASS (prelim)**.
   - Checks, reported: high_tier +0.3049 (Z 7.21), nested_collapsed +0.2793 (Z 7.30), no_outgroup_filter +0.2959
     (Z 8.96).
   - LTRmix D_ins +0.1949 ± 0.0269 (Z 7.24), beside no_outgroup_filter, with the completeness-ratio note (1.081 ±
     0.018).
   - The outgroup filter removed 0.809 of 123,019 candidates; resolution B73 0.728, TIL01 0.710.
3. **Gene flow vs lineage sorting**, reported:
   - The catalog recount equals stats.tsv exactly (D, se, n_RD, n_SD; all three own bins; dD and its se).
   - D +0.600 (32/8), +0.612 (320/77), +0.203 (965/639); dD +0.3968 ± 0.1268 (Z 3.13).
   - In LTRmix's right-closed bins the counts are identical, since no counted locus has K = 0.01 exactly (0 loci).
   - LTRmix: +0.506 (122/40), +0.404 (2,001/850), +0.153 (8,795/6,467); dD +0.354.
4. **Amount**, reported:
   - posterior_mean 0.3696, decoy 0.3165, excess +0.0531; span-weighted 0.3699 / 0.3161 / +0.0538.
   - LTRmix 0.3836 unweighted, 0.3833 span-weighted (= its stats.tsv posterior_mean); decoy 0.3414, excess +0.0419.
   - ELAI dosage/2 0.1695; Yang 15-25% (mean 18%, from the PDF). Not an estimate.
5. **Chromosomes 5, 8, 9** (chr1-10 only):
   - Posterior: chr5, chr8, chr9 unweighted (paint_seqid; the recount equals it) and span-weighted: **PASS (prelim)**
     ×2; Spearman with ELAI +0.59 / +0.59.
   - Class share: chr4, chr5, chr9 in both weightings: **MISS (prelim)** ×2; P(>= 2/3 by chance) 0.183.
   - LTRmix: chr5, chr8, chr9 in all four.
6. **Windows** (0.1-10 Mb; posterior and class share × two weightings; 1,000 circular shifts, seed 1): every ≥ 1-Mb
   row has p 0.000999 (the floor). r 0.256-0.384: **PASS (prelim)** ×16. Below 1 Mb r 0.203-0.278, reported. LTRmix:
   r 0.268-0.399 at ≥ 1 Mb, p at the floor.
7. **Tract scale**, reported:
   - AUROC 0.7123 / 0.7675 (LTRmix 0.7217 / 0.7822).
   - Recall of ELAI > 1 runs by any tract: 0.310, 0.419, 0.486, 0.500 (n 1,807, 523, 218, 10); none at q <= 0.05.
     LTRmix ancestry: 0.374, 0.488, 0.601, 0.800.
   - ELAI dosage in tracts: 0.215 vs 0.170 genome-wide; dosage ≥ 1 at 0.091 vs 0.049 (764 tracts on chr1-10, 469 Mb).
   - Spacing 84.4 kb median / 283.1 kb mean; the recount gives the same (LTRmix 24.4 / 67.4 kb, 31,395 informative
     elements).
   - Shortest callable: 1 locus (84.4 kb) at both bounds.
   - L: 301.7 kb (LTRmix ancestry 197.1, recent 571.5); mean_donor_run_bp 470.7 kb.
   - 770 tracts, 599 decoy tracts, 0 at q <= 0.05 (smallest q 0.20).
   - Emissions: e1[RD] 0.9993.
8. **Named loci** (±50 and ±200 kb). Rule: "called" = a B73 tract with q <= Q_TRACT (0.05) overlapping the flank.
   - ZmPRR37a ±50 kb: **MISS (prelim)**. 6 loci (5 missing, 1 old), none informative; max posterior 0.160; no tract.
     The nearest informative loci are RS, 188 and 510 kb away.
   - ±200 kb, reported: 20 loci (1 RS, 1 both, no RD).
   - HPC1: not called, reported; no informative locus within ±50 kb; the nearest RS at 303 and 668 kb.
   - ZmLPCAT1: not called at q <= 0.05, reported. An uncalibrated tract (q 0.855) covers it; max posterior 0.905.
   - Cob-weight locus: reported, no hit/miss rule (see concern 4).
9. **52 high-frequency regions** (1,000 shifts, seed 2): posterior 0.386 vs 0.369, p 0.3427 unweighted; 0.388 vs
   0.369, p 0.3297 span-weighted: **MISS (prelim)** ×2. LTRmix 0.399 vs 0.383, p 0.3686 and 0.3497.
10. **Inversions**, reported. Every block of a B73 pair within 10 Mb of a published end is listed (7 for Inv4m, 4 for
    Inv1n), with loci, n_discordant, n_strand, the span on both genomes and the breakpoint distances.
    - Inv4m: B73~TIL18 block chr4:172.81-188.08 Mb, 464 loci, 43 discordant. Its left breakpoint interval is 0.07 Mb
      from 172,883,881; its right breakpoint interval contains 188,131,462; it covers 0.997 of the interval.
    - Inv1n: three B73~TIL01 blocks cover 0.979 of 65-115 Mb. The closest ends are 0.43 Mb (left) and 0.72 Mb (right)
      away.
    - LTRmix's own rows (from benchmark_real.tsv) are quoted beside them. The sparse flags follow ruling 7 (concern 2).
11. **Outgroup bound**, reported. B73 0.0268 (321/11,990), TIL18 0.0323 (368/11,385), TIL01 0.0314 (376/11,957),
    recounted from the catalog (Task 3's construction). The recount equals stats.tsv outgroup_conflict in value and n.
12. **Mechanisms**, reported (stats.tsv mechanisms and absence_events rows).
    - B73>TIL18 by age: frac_E 0.460, 0.384 and 0.315 (all: 0.349). The derived share lies between 0.0129 and 0.651
      overall, and between 0.0155 and 0.685 at K >= 0.01, as the brief quotes.
    - The other five ingroup pairs: frac_E falls with age in each.
    - Multi-element absences: 0.407 (B73>TIL18) and 0.384 (B73>TIL01); pooled 0.391 of 314,059. Nested clusters are
      0.436 of the multi-element ones, against Munasinghe's 85.9% read as deletions (a lead).
13. **Identity layer**, reported.
    - s 0.0742% ± 0.0094% (23,779 pairs, 510 blocks); LTRmix 0.0482% (0.0336-0.0628%; its rate_free_split.tsv).
    - s_mix 0.0822%, with the ruling's note ("unstable (Task 9: moved 0.00248 -> 0.00082 with small count changes;
      gene-flow weight 0)"); weights 0.941 / 0.0000 / 0.059; AIC 206817 vs 206813. LTRmix's mixture: 0.0698%.
    - Young: R+D 0 of 1,315, S+D 0 of 722; D_young undefined; sites_needed 4,036 (LTRmix 0 vs 0, ~6,200).
    - Below s: B73-TIL18 8.2% (27,029), TIL01-TIL18 3.2% (23,779); LTRmix 7.6% vs 3.5%.
14. **Direction**: skipped (findings: needs two genomes per taxon).

### LTRmix cross-check (ruling 4; V/ltrmix_crosscheck.tsv)
There are 59 checks against 57 rows of benchmark_real.tsv; the two chromosome rows are checked on the ranking and on
the Spearman r.
- Equal (58), string for string: the truth mean 0.1695; D_ins; the 8 age strata; the HMM ancestry excess; the
  chromosome rankings and Spearman r; the 12 window rows (r, p 0.0010, n); the 4 AUROC (both modes); the 16 tract
  recall rows; the 3 tract dosage rows; the 8 named-locus rows (counts, class dicts, maximum posteriors).
- Different (1): the high-frequency mean, "0.399 vs 0.383 outside; shift p=0.413" there against p=0.369 here. The
  reason: eval_real.py used 200 shifts, and the brief requires 1,000 with the same seed. The means are equal.

## Misses and their investigation (V/investigate_misses.txt; dead_ends.md section "2026-11-12 Plan 2 Task 12")

1. **Chromosomes by class share** (×2: unweighted and span-weighted): chr4 0.294 ranks below chr8 0.321.
   - The gap is about 1.1 combined SE.
   - In a 5-Mb block bootstrap, the exact set {5, 8, 9} comes out in 15.1% of replicates and chr8 is among the lowest
     three in 32.9%.
   - There are 570-937 informative loci per chromosome (LTRmix 2,253-4,037).
   - Inv4m's interval holds 2 RD against 35 RS, but setting inverted-block loci aside keeps chr4, chr5, chr9.
   - No rule was changed.
2. **ZmPRR37a**: ELAI's run across the gene spans 41.8 kb.
   - The 6 B73 insertions within ±50 kb are D or O in both TIL01 and TIL18 (5 of them) or older than the split (1).
     The nearest informative loci are RS, 188 and 510 kb away.
   - At the mean density, about 0.15 informative loci fall per 42 kb.
   - LTRmix missed it too.
3. **High-frequency regions** (×2):
   - The regions' median length is 486 kb; 17 of 52 have no informative locus within 50 kb.
   - Post hoc and not pre-specified, the class-share reading gives 0.440 vs 0.356, p 0.14 (LTRmix p 0.23). It misses
     as well.
   - LTRmix also misses.

## Figure check (ruling 10; PRELIM.md section 6)
Lines 1-6: yes. Line 7: no, in part.
- The short legend states thresholds and test statistics ("none of B73's reach q ≤ 0.05"; "D +0.60 at K = 0 against
  +0.20 at K ≥ 0.01").
- Its headline asserts "gene flow ..., not incomplete lineage sorting" without "preliminary".
- Minor: the closing line names a module, not a script path.

I checked crops at full resolution: the panel A key and rows, B with its right column, C, D, E-G, and the "B" and "C"
labels. Panel C's bases were re-extracted from the FASTAs with pysam and match:
- B73 and TIL18: TCTATAGTTG ATTAC TGATAGTCGC ... TTCCCTTTCA ATTAC TTTGTAATGG;
- TIL01: TCTATAGTTG ATTAC TTTGTAATGG.

## main3 unchanged
- main3: the 226 entries at depth 3 have identical sizes and mtimes before and after (snapshots/main3.{before,after}.tsv).
- inputs/*.fai: identical sizes, mtimes and sha256.
- `find -L ... -newer snapshots/start.marker` finds nothing in main3, inputs, run, benchmark/truth, LTRmix or
  benchmark/analysis.
- The run and the scripts wrote only in V: its work/ is a real directory, and work/elements is a read-only symlink.
- Repeated after the commit, the last command (snapshots/main3.final.tsv, fai.final.tsv): still identical, and nothing
  newer than the start marker.

## Files written
- V: run_analyses.sh, analyses.log, analyses.exit, analyses.done, time.{stats,paint,plot}.txt, and the analysis
  outputs:
  - stats.tsv, findings.txt, identity.tsv, inversions.tsv, mechanisms.tsv;
  - posterior.B73.tsv, tracts.B73.bed, decoy_posterior.TIL01.tsv, decoy_tracts.TIL01.bed;
  - overview.png, overview.pdf, overview_numbers.tsv;
  - work/ (analysis parts, markers, fai and checksum caches).
- V: compare_papers.py, compare_papers.log, prelim_papers.tsv, ltrmix_crosscheck.tsv, prelim_tables/, PRELIM.md,
  investigate_misses.py, investigate_misses.txt, snapshots/.
- benchmark_pav/dead_ends.md: new section, three entries covering the 5 MISS rows.
- memo_ltrpav.md: new section "Plan 2 analyses on main3 and the preliminary comparison with the papers (Task 12)".
  It holds the view construction, the launch, the PID check, the comparison commands and the claude --resume line.
- Repo: docs/DESIGN.md section 12, "Plan 2 outcome", 5 lines. Nothing else in the repo changed.
- Scratch (session scratchpad t12/): the pytest logs, a test view and the figure crops.

## For the user (Step 8)
- **Direct answer.**
  - Genome-wide, yes: D_pav +0.29 (Z 7.4).
  - Gene flow rather than lineage sorting, yes, preliminarily: the young-insertion excess gives dD +0.40, Z 3.1, but
    no simulated null exists yet.
  - Locally, only at the Mb scale: windows track ELAI at 1-10 Mb (p 0.001). Chromosomes 5, 8, 9 rank lowest by the
    posterior.
  - But there is one informative insertion per 84 kb, and no tract passes the FDR. ZmPRR37a, the high-frequency regions
    and the class-share ranking miss.
- **Figure:** /data2/chris/maize_introgression/benchmark_pav/main3_analyses/overview.png (and overview.pdf).
- **Plan 3 must settle:**
  - the simulated null and power of D_pav and of the painting;
  - direction, with unequal Ne between taxa (the maize bottleneck) in both the null and the gene-flow runs;
  - the painting discovery variant;
  - the six-genome controls.
- **Builder call 11** (fallback discovery, four-point eligibility) still needs the user's confirmation. main3 does not
  exercise it, because the donor TIL18 is annotated.

## Concerns
1. **The figure's short legend breaks the skill's rule** (line 7). It shows q, D and K thresholds, and states "gene
   flow, not lineage sorting" without "preliminary". No code change here; the controller rules.
2. **Ruling 7's sparse flag, applied literally,** flags 303 of 523 blocks (58%). Among them is Inv4m's dense B73~TIL18
   block (464 loci, 30.4 per Mb against B73's median of 53.8), so the label "known caller defect" lands on real
   inversions. I applied the rule as written, with each block's density on both genomes beside it, and said so in
   PRELIM.md. A defect-specific description would serve better, for example a span far above n_loci times the
   genome-wide informative spacing, or a block between sequences outside the dominant syntenic pair.
3. **Verdicts on both weightings.** Rows with a bar got a verdict in both the unweighted and the span-weighted
   version: 16 window rows, 4 chromosome rows, 2 high-frequency rows. The two agree everywhere here. If the controller
   wants one primary weighting, the counts change, but no verdict changes: 19 → 10 PASS, 5 → 3 MISS.
4. **Named-locus rules** (the conservative choices):
   - "called" means a q <= 0.05 tract (the tool's reported tracts), and the ZmPRR37a verdict reads ±50 kb only.
   - The cob-weight "intermediate" expectation has no principled hit/miss rule for a one-haplotype painting, so it is
     "reported", although the brief asks for hit or miss.
   - HPC1 and ZmLPCAT1 are "hit" vacuously: no tract passes q <= 0.05 anywhere.
5. **The high-frequency test.** The brief specifies the mean posterior; DESIGN 10.3 says "enrichment of donor-like
   loci". I ran the brief's test, and the class-share reading only post hoc (it misses too). Plan 3 should fix which
   test applies.
6. **The PAV painting is coarser than LTRmix's** (84 vs 24 kb median spacing; 7,515 vs 31,395 informative loci). Its
   emissions are degenerate (0.9993), so the posterior copies classes. PRELIM says plainly that LTRpav adds no
   resolution on main3.
7. **Identity split.** s = 0.074% ± 0.009% against LTRmix's 0.048% (0.034-0.063%); the 95% intervals overlap only
   narrowly, as Task 9 noted. The fractions below s agree with LTRmix's.
8. **compare_papers.py imports more than the brief names.** Beyond load_catalog and discover it uses pav_distances,
   ltrpav.analysis.stats, read_samples and two constants. All come from the ltrpav package; no new environment.
9. **Snapshot count.** I count 226 main3 entries at depth 3, where Task 10 reported 234, probably counted another way.
   The before/after comparison here uses one method and is exact.

Not done: nothing from the brief, except the cob-weight hit/miss (concern 4).

## Fix round 1 (review task-12-review.md; rulings task-12-fix-1.md)

Commit: 4b73977 "Correct the Plan 2 outcome summary" (docs/DESIGN.md section 12 only; existing identity, no trailers,
not pushed). Tests: `python -m pytest -W error -m "not slow"`: 1121 passed, 2 deselected in 396 s, exit 0.

What changed:
- **compare_papers.py**, rerun in 87 s; deterministic; ltrmix_crosscheck.tsv byte-identical. prelim_papers.tsv now has
  109 rows: 19 PASS, 5 MISS, 84 reported, 1 skipped. The verdicts are unchanged; 6 reported rows were added.
- **PRELIM.md, dead_ends.md** (one new entry: the withdrawn mechanism), **memo_ltrpav.md**, **DESIGN.md section 12**.

Findings:
- **I1 (fixed).**
  - HPC1 and ZmLPCAT1 now read "met by construction (no tract passes q anywhere)", in PRELIM.md's table and caveats
    and in prelim_papers.tsv's notes.
  - ZmLPCAT1's disagreement is stated: posterior 0.905 under a q 0.855 tract built from 2 R+D loci, against Yang's
    ELAI 0.08. Every named locus now carries ELAI's in-gene dosage: ZmPRR37a 1.55 (39 SNPs), HPC1 0.03 (8), ZmLPCAT1
    0.08 (42), cob weight 0.66 (5).
  - HPC1's "weakly" is gone: no informative locus lies within ±50 kb, and its posterior (0.21) is interpolated, so it
    carries no local evidence either way. The cob-weight row now says its posterior is interpolated too.
- **I2 (fixed).**
  - I reran the reviewer's check_mech.py in scratch (env ltrmix, which has pandas) and reproduced it exactly.
  - The same test is now in compare_papers.py: function `absence_readings`, on the catalog, with the D_pav jackknife.
    Its rows are in section 3.
  - PRELIM section 3 says verification changes neither D nor its gradient on this trio. The answer, section 7, DESIGN
    12 and the memo say the same.
  - The dilution mechanism and prediction 3 are withdrawn, and recorded as withdrawn in PRELIM and dead_ends.md.
  - The headline sentence is restated.
  - The D_pav vs D_ins gap is marked untested, with candidates named: different loci, annotation completeness 1.08,
    library presence calls on paralogs or orthology errors (11-12% of LTRmix's "absent" calls occupied), LTRmix's
    symmetric-synteny filter, and age composition (per bin, LTRpav's D is higher too).
- **M1 (fixed).** A caveat on the s gap: the aligner is ruled out (minimap2 0.075%); the pair set and LTRmix's global
  whole-record alignment remain open. The lower-tail over-prediction is given (fitted 9.8/15.1/25.3% vs observed
  8.5/12.9/21.4%). No conclusion rests on s.
- **M2 (fixed).** The per-claim summary leads PRELIM section 2, DESIGN 12 and the memo's result line, with row counts in
  parentheses: 16 of the 19 PASS rows are the windows claim.
- **M3 (fixed).** New row: tract coverage of chr1-10, LTRpav 22.0% (469 Mb) and LTRmix ancestry 27.9% (594 Mb; recent
  18.3%). Every recall cell gives "x chance": LTRpav 1.4x (< 10 kb) to 2.3x (>= 500 kb); LTRmix ancestry 1.3x-2.9x.
- **M4 (fixed).**
  - Inv4m becomes "LTRmix's v5 coordinates, source not recorded". A search of the project record found no source; the
    TSV says "reference" instead of "published".
  - ZmLPCAT1 becomes "(Barnes: selection candidate; Yang's ELAI 0.08)".
- **M5 (fixed).** The memo now has the fai sha256 line, `mamba run -n ltrpav python investigate_misses.py`, and
  run_analyses.sh verbatim in a heredoc.
- **M6 (fixed).** Lineage sorting gives *symmetric* sharing (D = 0) at every age; "Genome-wide: yes (prelim)". The CLR
  caveat now cites per-age resolution symmetry, recomputed in compare_papers.py.
- **M7 (not done, as ruled).** The figure's short legend stays for Plan 2's final wave.

I2 numbers. D_pav's candidate loci (TIL18 discovers, Zd E in TIL18's call), jackknifed as D_pav (5-Mb blocks on TIL18's
sites):

| reading of the sisters' calls | n_RD / n_SD | D (Z) | K=0 | 0<K<0.01 | K>=0.01 | dD (Z) |
|---|---|---|---|---|---|---|
| verified, E only (the tool's) | 1,317 / 724 | +0.2905 (7.42) | +0.600 (32/8) | +0.612 (320/77) | +0.203 (965/639) | +0.397 ± 0.127 (3.13) |
| E, D or O absent | 1,869 / 1,035 | +0.2872 (7.74) | +0.644 (37/8) | +0.586 (437/114) | +0.209 (1,395/913) | +0.436 ± 0.116 (3.74) |
| P only present; E, D, O, S or T absent | 1,896 / 1,065 | +0.2806 (7.92) | +0.610 (33/8) | +0.580 (421/112) | +0.208 (1,442/945) | +0.402 ± 0.124 (3.23) |
| the added D/O patterns alone | 552 / 311 | +0.2793 (5.23) | | | | |

The verified row equals D_pav and its gradient exactly (checked in code against the recount).

Restated headline sentence (PRELIM section 7): "Read in the assembly, only a third to a half of LTR-retrotransposon
absences between maize and teosinte are empty sites, fewer for older insertions, yet counting the unverified absences as
absent leaves the introgression signal and its young-insertion excess unchanged on this trio, so genome verification
describes how absences arise without sharpening the gene-flow test."

main3 unchanged: after the commit, snapshots/main3.fix1.tsv (226 entries, depth 3) and the fai sizes, mtimes and
sha256 (fai.fix1.*) equal the pre-launch snapshot. Nothing in main3, inputs, run, benchmark/truth or LTRmix is newer
than the start marker. The reviewer's probe was rerun from a copy in my scratch, which reads main3 only.

Not done: M7 (the figure, final wave, as ruled). The cob-weight locus still has no hit/miss rule (ruled as reported).
No source for Inv4m's v5 coordinates was found in the project record.

## Fix round 2 (re-review "Re-review (fix round 1)" in task-12-review.md: N1-N4)

Commit: none. DESIGN.md section 12 quotes neither the multipliers nor the headline, so the repo is unchanged, and HEAD
stays 4b73977. Files changed: compare_papers.py (rerun in 98 s), prelim_papers.tsv, PRELIM.md, memo_ltrpav.md. The
"x chance" multipliers in the Fix round 1 section above (1.4-2.3x, 1.3-2.9x) are superseded by N1 below.

- **N1 (fixed).**
  - New `recall_chance` in compare_papers.py. Each chromosome's tracts are shifted circularly together by one offset per
    chromosome, uniform in [0, length), a wrapped tract split at the end. That is the per-chromosome shift the windows'
    test uses.
  - 1,000 shifts, seed 3 (SEED_RECALL), one generator per call. Draws go chromosome by chromosome, so every tract set
    of both tools sees the same offsets. The chance rate of a bin is its mean recall over the shifts.
  - Every recall cell now reads "obs (chance c, Nx)". The coverage row is relabeled as the chance rate for a point-like
    run, with a note that longer runs are hit more often.
  - PRELIM row 7 gives the per-bin values and says "at >= 500 kb recall equals chance (n 10 runs)".
  - The reviewer's check_recall_chance.py, rerun in my scratch, gives the same multipliers (it shifts each run instead;
    the expectation is the same).
- **N2 (fixed).** PRELIM section 7 now says annotation completeness would widen the gap rather than explain it. LTRmix's
  code (ltrmix.py:1185-1187) says one-sided dropout biases D_ins toward the more complete sister, and B73/TIL01 is 1.081,
  so the bias would raise D_ins.
- **N3 (fixed).** The headline reads "shows which absences are empty sites", and section 3 reads "the state of each
  absence (which ones are empty sites)". DESIGN 12, the memo and dead_ends.md never quoted the old wording.
- **N4 (fixed).** absence_readings takes its codes from `STATE = STATE_CODE`, imported from ltrpav.analysis.catalog, so
  no literal codes remain. The rerun leaves every row outside section 7 byte-identical, the I2 rows included.

New multipliers (observed recall / chance, by ELAI run length: < 10 kb, 10-100 kb, 100-500 kb, >= 500 kb):

| tracts | < 10 kb (n 1,807) | 10-100 kb (n 523) | 100-500 kb (n 218) | >= 500 kb (n 10) |
|---|---|---|---|---|
| LTRpav, all | 0.310 / 0.231 = 1.3x | 0.419 / 0.246 = 1.7x | 0.486 / 0.304 = 1.6x | 0.500 / 0.520 = 1.0x |
| LTRmix ancestry, all | 0.374 / 0.297 = 1.3x | 0.488 / 0.328 = 1.5x | 0.601 / 0.442 = 1.4x | 0.800 / 0.743 = 1.1x |
| LTRmix recent, all | 1.1x | 1.1x | 1.1x | 0.6x |
| LTRmix recent, q <= 0.05 | 0.9x | 1.0x | 1.3x | 3.9x (2 of 10 runs) |

LTRpav and LTRmix ancestry have no tract at q <= 0.05.

Restated headline sentence: "Read in the assembly, only a third to a half of LTR-retrotransposon absences between
maize and teosinte are empty sites, fewer for older insertions, yet counting the unverified absences as absent leaves
the introgression signal and its young-insertion excess unchanged on this trio, so genome verification shows which
absences are empty sites without sharpening the gene-flow test."

TSV recheck:
- 109 rows: 19 PASS, 5 MISS, 84 reported, 1 skipped. The verdicts are unchanged.
- Only the section 7 coverage row and the four recall rows changed.
- ltrmix_crosscheck.tsv is byte-identical.

main3 unchanged: snapshots/main3.fix2.tsv (226 entries) and fai.fix2.* equal the pre-launch snapshot. Nothing in main3,
inputs, run, benchmark/truth or LTRmix is newer than the start marker.

Not done: nothing from N1-N4.
