"""Input checks and caching (pre-release audit): bad inputs fail early with a message, and nothing stale is reused."""
import csv
import gzip

import pysam
import pytest

from ltrkin.annot import read_gff3
from ltrkin.cli import main


def _calls(out):
    with open(out + ".genotypes.tsv") as fh:
        return {r["element_id"]: (r["genotype"], r["gq"], r["n_F"], r["n_E"], r["n_S"])
                for r in csv.DictReader(fh, delimiter="\t")}


def _genotype(data, out, gff=None, bam=None, ref=None):
    main(["genotype", "-r", ref or data["ref"], "-a", gff or data["gff"], "-o", out, "-t", "2", bam or data["full"]])
    return _calls(out)


def _gff_lines(path):
    return [ln for ln in open(path) if ln.strip() and not ln.startswith("#")]


def test_evidence_cache_follows_the_annotation(data, tmp_path):
    """Same number of elements, another annotation: a rerun with the same prefix must not reuse the evidence."""
    out = str(tmp_path / "run")
    _genotype(data, out)
    lines = _gff_lines(data["gff"])
    drop = [ln for ln in lines if "E8_decoy_hom" in ln]
    assert drop
    keep = [ln for ln in lines if "E8_decoy_hom" not in ln]
    add = ["chr1\tt\tLTR_retrotransposon\t140001\t145000\t.\t+\t.\tID=X_new;family=famA\n",
           "chr1\tt\tlong_terminal_repeat\t140001\t140400\t.\t+\t.\tParent=X_new\n",
           "chr1\tt\tlong_terminal_repeat\t144601\t145000\t.\t+\t.\tParent=X_new\n"]
    gff2 = tmp_path / "other.gff3"
    gff2.write_text("##gff-version 3\n" + "".join(keep + add))
    rerun = _genotype(data, out, gff=str(gff2))
    fresh = _genotype(data, str(tmp_path / "fresh"), gff=str(gff2))
    assert rerun == fresh


def test_truncated_cache_is_rescanned(data, tmp_path):
    out = str(tmp_path / "t")
    first = _genotype(data, out)
    cache = out + ".full.evidence.json.gz"
    raw = open(cache, "rb").read()
    open(cache, "wb").write(raw[: len(raw) // 2])
    assert _genotype(data, out) == first


def test_duplicate_element_ids_are_rejected(data, tmp_path):
    lines = _gff_lines(data["gff"])
    e7 = [ln.replace("E7_hom", "E1_het_empty") for ln in lines if "E7_hom" in ln]   # another chromosome, same ID
    g = tmp_path / "dup.gff3"
    g.write_text("##gff-version 3\n" + "".join([ln for ln in lines if "E7_hom" not in ln] + e7))
    with pytest.raises(ValueError, match="more than once"):
        read_gff3(str(g))
    with pytest.raises(SystemExit, match="more than once"):
        _genotype(data, str(tmp_path / "d"), gff=str(g))


def test_bam_aligned_to_another_reference_is_rejected(data, tmp_path):
    fa = pysam.FastaFile(data["ref"])
    ref2 = tmp_path / "ref_v2.fa"
    with open(ref2, "w") as fh:
        for c in fa.references:
            s = fa.fetch(c) + ("ACGT" * 250 if c == "chr1" else "")          # chr1 1 kb longer
            fh.write(f">{c}\n" + "\n".join(s[i:i + 80] for i in range(0, len(s), 80)) + "\n")
    with pytest.raises(SystemExit, match="another reference"):
        _genotype(data, str(tmp_path / "r"), ref=str(ref2))


def test_element_past_the_sequence_end_is_rejected(data, tmp_path):
    g = tmp_path / "past.gff3"
    g.write_text("##gff-version 3\n" + "".join(_gff_lines(data["gff"])) +
                 "chr3\tt\tLTR_retrotransposon\t39001\t47800\t.\t+\t.\tID=X_past\n"
                 "chr3\tt\tlong_terminal_repeat\t39001\t39400\t.\t+\t.\tParent=X_past\n"
                 "chr3\tt\tlong_terminal_repeat\t47401\t47800\t.\t+\t.\tParent=X_past\n")
    with pytest.raises(SystemExit, match="past their reference sequence"):
        _genotype(data, str(tmp_path / "p"), gff=str(g))


def test_duplicate_flagged_reads_are_ignored(data, tmp_path):
    """Reads flagged as duplicates must count nowhere: the calls equal those on the BAM without them."""
    flagged, removed = str(tmp_path / "flagged.bam"), str(tmp_path / "removed.bam")
    with pysam.AlignmentFile(data["full"]) as inp, pysam.AlignmentFile(flagged, "wb", template=inp) as f, \
            pysam.AlignmentFile(removed, "wb", template=inp) as r:
        for x in inp:
            if sum(map(ord, x.query_name)) % 5 < 2:                         # ~40% of reads, all their records
                x.flag |= 0x400
            else:
                r.write(x)
            f.write(x)
    for b in (flagged, removed):
        pysam.index(b)
    assert _genotype(data, str(tmp_path / "f"), bam=flagged) == _genotype(data, str(tmp_path / "r"), bam=removed)


def test_vcf_values_are_encoded(data, tmp_path):
    """An ID with a character that has a meaning in VCF is percent-encoded there, so the VCF stays valid."""
    g = tmp_path / "enc.gff3"
    g.write_text("##gff-version 3\n" + "".join(ln.replace("E3_hom", "E3%3Bhom") for ln in _gff_lines(data["gff"])))
    out = str(tmp_path / "v")
    calls = _genotype(data, out, gff=str(g))
    assert "E3;hom" in calls                                                   # the table keeps the decoded ID
    with pysam.VariantFile(out + ".vcf.gz") as vf:
        ids = {rec.id for rec in vf}
    assert "E3%3Bhom" in ids
    with gzip.open(out + ".vcf.gz", "rt") as fh:
        assert all(";hom" not in ln for ln in fh)
