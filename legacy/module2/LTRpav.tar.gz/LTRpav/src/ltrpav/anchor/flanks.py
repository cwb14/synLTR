"""Flank routes: anchors from mapping only the unique sequence beside each annotated element.

`flank_pieces` cuts, for each top-level element of A and each side, the free sequence (no annotated element,
no N run) within FLANK_CAP bp, nearest first until FLANK_TARGET bp are collected. Routes:
  flank-mm2    the pieces mapped onto B's asm20 index (the whole-genome mm2 route's index and hit-to-block code)
  flank-blast  the pieces searched with megablast against a BLAST database of B
  hybrid       a primary whole-genome route's blocks, plus flank-mm2 blocks for the elements whose provisional
               window that route left unresolved
Their raw blocks are unchained; `anchor_pair` chains and nets them like any other route's.
"""
from __future__ import annotations

import bisect
import logging
import os
import shutil
import subprocess
import threading
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from itertools import accumulate
from typing import TYPE_CHECKING

import mappy
import numpy as np

from ..blocks import BLOCK_DTYPE, blocks_from_rows
from ..chain import chain_blocks, net_blocks
from ..checkpoint import (
    CHECKSUM_CACHE,
    atomic_path,
    clear_done,
    file_checksum,
    is_done,
    mark_done,
    marker,
    stage_key,
    tool_version,
)
from ..constants import (
    BLAST_EVALUE,
    BLAST_MAX_HSPS,
    BLAST_MAX_TARGETS,
    FLANK_CAP,
    FLANK_PIECE_MIN,
    FLANK_TARGET,
    MAPPY_BEST_N,
    SPLIT_INDEL,
)
from ..seqio import Fasta, n_runs
from ..window import make_windows
from . import mm2

if TYPE_CHECKING:
    from ..elements import Element
    from . import PairContext, Route

log = logging.getLogger("ltrpav.anchor")

BLAST_FIELDS = "qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore nident stitle"
_WRITE_CHUNK = 10_000_000  # bp per fetch when streaming B into a plain FASTA


@dataclass(frozen=True)
class Piece:
    """A flank piece of A: 0-based half-open."""

    seqid: str
    start: int
    end: int


def flank_pieces(elements: list[Element], fasta: Fasta, cap: int = FLANK_CAP,
                 target: int = FLANK_TARGET, targets: set[str] | None = None) -> list[Piece]:
    """Flank pieces of the top-level `elements` of A, deduplicated, in fai order then start.

    Per element and side the flank region is [start - cap, start) or [end, end + cap) clipped to the sequence.
    Every annotated element (all levels) and every N run is cut out; the free stretches of >= FLANK_PIECE_MIN
    bp are taken nearest-first, whole, until they total >= `target` bp (the last may overshoot).
    `targets` (eids) limits the pieces to those top-level elements; every element is still cut out.
    """
    lengths = fasta.lengths()
    by_seq: dict[str, list[tuple[int, int]]] = {}
    for e in elements:
        by_seq.setdefault(e.seqid, []).append((e.start - 1, e.end))
    # per seqid: spans sorted by start, their starts, and the running max of ends (non-decreasing, so nested
    # spans cannot hide an overlap): a region [lo, hi) can only meet spans[j:k]
    spans = {}
    for sid, lst in by_seq.items():
        lst.sort()
        spans[sid] = (lst, [s for s, _ in lst], list(accumulate((t for _, t in lst), max)))
    out: set[Piece] = set()
    for e in elements:
        if e.level != 0 or (targets is not None and e.eid not in targets):
            continue
        s0, t0, n = e.start - 1, e.end, lengths[e.seqid]
        for lo, hi, left in ((max(0, s0 - cap), s0, True), (t0, min(n, t0 + cap), False)):
            if hi <= lo:
                continue
            lst, starts, max_end = spans[e.seqid]
            j, k = bisect.bisect_right(max_end, lo), bisect.bisect_left(starts, hi)
            cuts = [(max(s, lo) - lo, min(t, hi) - lo) for s, t in lst[j:k] if t > lo]
            cuts += n_runs(fasta.fetch(e.seqid, lo, hi))
            free, pos = [], 0
            for s, t in sorted(cuts):
                if s - pos >= FLANK_PIECE_MIN:
                    free.append((pos, s))
                pos = max(pos, t)
            if hi - lo - pos >= FLANK_PIECE_MIN:
                free.append((pos, hi - lo))
            total = 0
            for s, t in (reversed(free) if left else free):
                if total >= target:
                    break
                out.add(Piece(e.seqid, lo + s, lo + t))
                total += t - s
    order = {name: i for i, name in enumerate(lengths)}
    return sorted(out, key=lambda p: (order[p.seqid], p.start, p.end))


def _flank_params(cap: int, target: int) -> dict:
    return {"cap": cap, "target": target, "piece_min": FLANK_PIECE_MIN}


class FlankMm2Route:
    """Flank pieces of A mapped onto B's minimap2 index (the mm2 route's, built once per B FASTA)."""

    name = "flank-mm2"
    whole_genome = False
    reads_elements = True

    def __init__(self, cap: int = FLANK_CAP):
        self.cap = cap

    def params(self, ctx: PairContext) -> dict:
        return {**_flank_params(self.cap, FLANK_TARGET), "preset": mm2.PRESET, "best_n": MAPPY_BEST_N,
                "split_indel": SPLIT_INDEL, **mm2.index_versions()}

    def raw_blocks(self, ctx: PairContext) -> np.ndarray:
        return map_pieces(ctx, flank_pieces(ctx.a_elements, ctx.a_fa, self.cap, FLANK_TARGET))


def map_pieces(ctx: PairContext, pieces: list[Piece]) -> np.ndarray:
    """Raw blocks of `pieces` (A) mapped with mappy onto B's asm20 index.

    Pieces are fetched in this thread (pysam handles are not thread-safe) and mapped by a thread pool, one
    mappy ThreadBuffer per thread; results come back in piece order, so the output is deterministic.
    """
    t0 = time.perf_counter()
    if not pieces:
        return np.zeros(0, dtype=BLOCK_DTYPE)
    aligner = mm2._aligner(ctx)
    a_index = {n: i for i, n in enumerate(ctx.a_fa.lengths())}
    b_index = {n: i for i, n in enumerate(ctx.b_fa.lengths())}
    local = threading.local()

    def work(job: tuple[Piece, str]) -> list[tuple]:
        piece, seq = job
        buf = getattr(local, "buf", None)
        if buf is None:
            buf = local.buf = mappy.ThreadBuffer()
        return mm2.map_rows(aligner, buf, seq, a_index[piece.seqid], piece.start, b_index, 0, len(seq))

    threads = max(1, ctx.threads)
    parts: list[list[tuple]] = []
    pending: deque = deque()
    with ThreadPoolExecutor(threads) as pool:
        for p in pieces:  # fetched just before submission; at most _QUEUED * threads pieces in flight
            pending.append(pool.submit(work, (p, ctx.a_fa.fetch(p.seqid, p.start, p.end))))
            if len(pending) >= mm2._QUEUED * threads:  # collected in piece order: deterministic
                parts.append(pending.popleft().result())
        parts.extend(f.result() for f in pending)
    rows = [r for part in parts for r in part]
    raw = blocks_from_rows(rows) if rows else np.zeros(0, dtype=BLOCK_DTYPE)
    log.debug("%s vs %s (flank-mm2): %d pieces, %d raw blocks, %.1f s", ctx.a.label, ctx.b.label, len(pieces),
             len(raw), time.perf_counter() - t0)
    return raw


class FlankBlastRoute:
    """Flank pieces of A searched with megablast against a BLAST database of B."""

    name = "flank-blast"
    whole_genome = False
    reads_elements = True

    def __init__(self, cap: int = FLANK_CAP):
        self.cap = cap

    def params(self, ctx: PairContext) -> dict:
        return {**_flank_params(self.cap, FLANK_TARGET), "task": "megablast", "evalue": BLAST_EVALUE,
                "max_target_seqs": BLAST_MAX_TARGETS, "max_hsps": BLAST_MAX_HSPS, "fields": BLAST_FIELDS,
                "blastn": tool_version("blastn"), "makeblastdb": tool_version("makeblastdb")}

    def raw_blocks(self, ctx: PairContext) -> np.ndarray:
        for exe in ("blastn", "makeblastdb"):
            if shutil.which(exe) is None:
                raise RuntimeError(f"route 'flank-blast' needs {exe} (BLAST+) on PATH (not found)")
        pieces = flank_pieces(ctx.a_elements, ctx.a_fa, self.cap, FLANK_TARGET)
        if not pieces:
            return np.zeros(0, dtype=BLOCK_DTYPE)
        t0 = time.perf_counter()
        db = _blast_db(ctx)
        tmpdir = ctx.workdir / "tmp"
        tmpdir.mkdir(parents=True, exist_ok=True)
        query = tmpdir / f".{ctx.a.label}__{ctx.b.label}.flanks.{os.getpid()}.fa"
        try:
            with open(query, "w") as fh:
                fh.writelines(f">p{i}\n{ctx.a_fa.fetch(p.seqid, p.start, p.end)}\n" for i, p in enumerate(pieces))
            cmd = ["blastn", "-task", "megablast", "-query", str(query), "-db", str(db), "-outfmt",
                   f"6 {BLAST_FIELDS}", "-evalue", BLAST_EVALUE, "-max_target_seqs", str(BLAST_MAX_TARGETS),
                   "-max_hsps", str(BLAST_MAX_HSPS), "-num_threads", str(max(1, ctx.threads))]
            log.debug("%s vs %s (flank-blast): %s", ctx.a.label, ctx.b.label, " ".join(cmd))
            res = subprocess.run(cmd, check=False, capture_output=True, text=True)
        finally:
            query.unlink(missing_ok=True)
        if res.returncode != 0:
            raise RuntimeError(f"blastn failed (exit {res.returncode}): {res.stderr.strip()[-2000:]}")
        a_index = {n: i for i, n in enumerate(ctx.a_fa.lengths())}
        b_index = {n: i for i, n in enumerate(ctx.b_fa.lengths())}
        rows = []
        for line in res.stdout.splitlines():
            f = line.split("\t")
            p = pieces[int(f[0][1:])]
            qs, qe, ss, se = int(f[6]), int(f[7]), int(f[8]), int(f[9])
            bi = b_index[f[13].split()[0]]
            rows.append((a_index[p.seqid], p.start + qs - 1, p.start + qe, bi, min(ss, se) - 1, max(ss, se),
                         -1 if ss > se else 1, int(f[12]), int(f[3])))
        raw = blocks_from_rows(rows) if rows else np.zeros(0, dtype=BLOCK_DTYPE)
        log.debug("%s vs %s (flank-blast): %d pieces, %d raw blocks, %.1f s", ctx.a.label, ctx.b.label,
                 len(pieces), len(raw), time.perf_counter() - t0)
        return raw


def _blast_db(ctx: PairContext):
    """B as a nucleotide BLAST database <workdir>/blastdb/<B>.<sha12>.fa (+ index files), built once.

    B is streamed through `Fasta` into a plain FASTA first (BLAST reads neither bgzip nor gzip).
    """
    sums = ctx.workdir / CHECKSUM_CACHE
    sha = file_checksum(ctx.b_fa.path, sums)
    stem = ctx.workdir / "blastdb" / f"{ctx.b.label}.{sha[:12]}.fa"
    done = marker(stem)
    key = stage_key("blastdb", {"B": sha}, {"dbtype": "nucl", "makeblastdb": tool_version("makeblastdb")})
    if is_done(done, key):
        return stem
    clear_done(done)
    stem.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(stem) as tmp, open(tmp, "w") as fh:
        for name, n in ctx.b_fa.lengths().items():
            fh.write(f">{name}\n")
            for s in range(0, n, _WRITE_CHUNK):
                seq = ctx.b_fa.fetch(name, s, min(n, s + _WRITE_CHUNK))
                fh.writelines(seq[i:i + 80] + "\n" for i in range(0, len(seq), 80))
    res = subprocess.run(["makeblastdb", "-dbtype", "nucl", "-in", str(stem), "-out", str(stem)],
                         check=False, capture_output=True, text=True)
    if res.returncode != 0:
        raise RuntimeError(f"makeblastdb failed on {stem} (exit {res.returncode}): "
                           f"{(res.stderr or res.stdout).strip()[-2000:]}")
    mark_done(done, key, [stem])
    return stem


class HybridRoute:
    """A primary route's blocks, plus flank-mm2 blocks for the elements it left without a resolved window."""

    name = "hybrid"
    whole_genome = False
    reads_elements = True

    def __init__(self, primary: Route, cap: int = FLANK_CAP):
        self.primary = primary
        self.cap = cap

    def params(self, ctx: PairContext) -> dict:
        return {"primary": self.primary.name, "primary_params": self.primary.params(ctx),
                **FlankMm2Route(self.cap).params(ctx)}

    def raw_blocks(self, ctx: PairContext) -> np.ndarray:
        from . import _raw_blocks
        raw = _raw_blocks(ctx, self.primary, ctx.workdir / CHECKSUM_CACHE)
        a_names, b_names = list(ctx.a_fa.lengths()), list(ctx.b_fa.lengths())
        provisional = f"{ctx.a.label} vs {ctx.b.label} (hybrid, {self.primary.name} windows)"
        windows = make_windows(ctx.a_elements, net_blocks(chain_blocks(raw), label=provisional), a_names, b_names,
                               ctx.b_fa.lengths(), ctx.a_fa.lengths())
        bad = {eid for w in windows if w.status != "ok" for eid in w.eids}
        todo = [e for e in ctx.a_elements if e.level == 0 and e.eid in bad]
        log.info("%s vs %s (hybrid): %d of %d elements unresolved by %s, mapping their flanks",
                 ctx.a.label, ctx.b.label, len(todo), sum(e.level == 0 for e in ctx.a_elements),
                 self.primary.name)
        if not todo:
            return raw
        pieces = flank_pieces(ctx.a_elements, ctx.a_fa, self.cap, FLANK_TARGET, targets={e.eid for e in todo})
        flank = map_pieces(ctx, pieces)
        return np.concatenate([raw, flank]) if len(flank) else raw

