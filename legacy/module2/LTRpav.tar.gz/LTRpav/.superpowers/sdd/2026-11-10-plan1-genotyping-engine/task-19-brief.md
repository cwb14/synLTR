### Task 19: Locus catalog

**Files:** Create `src/ltrpav/loci.py`, `tests/test_loci.py`

**Interfaces:**
- Produces:

```python
@dataclass
class GenomeState:
    state: str; tier: str; seqid: str | None; start: int | None; end: int | None; strand: str | None
    k: float | None; flags: list[str]
@dataclass
class Locus:
    lid: str; members: dict[str, str]          # genome -> eid (annotated copies)
    discovery: list[str]; family: str | None; superfamily: str | None; clade: str | None
    length: int; ltr_len: int; tsd: str | None; states: dict[str, GenomeState]
QcRow = tuple[str, str, float]                  # (scope, metric, value)
def build_loci(samples: list[Sample], elements: dict[str, list[Element]],
               call_paths: dict[tuple[str, str], Path]) -> tuple[list[Locus], list[QcRow]]
```

- [ ] **Step 1: Write the failing tests** (synthetic call tables; genomes A and B annotated, C unannotated, both A and
  B use seqid "chr1").

```python
def test_link_and_states():       # a1->B call P whose image overlaps b1 >= 80% reciprocal: one locus {A: a1, B: b1};
                                  # C state from a1->C and b1->C calls; member states "P", tier "annot"
def test_conflict_rules():        # a1->C E/high vs b1->C D/high -> C "U" + "conflict"; E/high vs D/medium -> E
def test_annotation_conflict():   # a2->B E/high but B annotation linked to the locus -> B stays P + "annot_conflict"
def test_unannotated_genome():    # C appears only through projections; never a member
def test_shared_seqid_names():    # A chr1:1000-2000 and B chr1:1000-2000 unlinked by calls -> two loci
def test_lid_deterministic():     # same inputs in another order -> same lids (L0000001...)
def test_qc_counters():           # n_loci, n_conflict, n_multi_member reported as QcRows
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - **Linking:** union-find over `(genome, eid)`. A P/S/T call whose B image overlaps a B element with reciprocal
    overlap `>= COV_PRESENT` links the two.
  - **States:** members get `P` (tier `annot`). Other genomes take the highest-tier call; tied different states give
    U + `conflict`. Member-vs-projection disagreement adds `annot_conflict`.
  - **Lids:** sort loci by the first sheet genome with coordinates, then its fai seqid order, then start.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add locus catalog across genome pairs"`.

---

