# Task 16A review: compare_papers' final edits, final_papers.tsv, the PRELIM diff, FINAL.md

## Re-review (fix round 1)

Date: 2026-11-14, 19:00-19:20 EST. The scope is the fix-round changes only (task-16a-report.md, "Fix round 1"):
- FINAL.md: sha256 f3733339...4647, 352 lines.
- test_compare_papers.py: sha256 1bf4dbef...8603.

The review was read-only. Probes are in
`/tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3t16a-review/r1/`.

**Outputs unchanged (confirmed).**
- compare_papers.py: still sha256 47d2c20d...2145 (mtime 18:01).
- papers/views/main: the outputs are dated 18:02-18:03 and are byte-identical to my 18:35 rerun.
  - final_papers.tsv (sha256 19016fae...) and final_ltrmix_crosscheck.tsv: 18:03:25.
  - final_tables/: 18:02 and 18:03.
- Nothing in views/, control_main3/ or logs/ is newer than 18:12. final_vs_prelim.tsv is unchanged, and FINAL.md is
  the only file in papers/ that changed.
- FINAL.md's 21 table lines are byte-identical to the original's. I compared them with my transcription of the
  original as I read it at 18:2x (`r1/orig_table.md`). The implementer's hash bfc1e4d8 is the same lines without the
  separator row, and I reproduced it.
- No verdict changed.

**Per finding**

| Finding | Verdict | Where |
|---|---|---|
| I1 robustness | ADDRESSED | FINAL.md:224-235 (the caveat); qualified at :24-27, :31-32, :111-116, :120-121, :264-265, :290-293 and :315-319; Terms :56 and :57-59 |
| I2 control tally | ADDRESSED, but the new tally sentence has an error (N1) | :304-308 (citrus n, SE and flaggable \|D\|); :296-299 (the controls swap); :315-319 (tally); :289; :327-329 |
| M1 stale path | ADDRESSED | :14-19, :348-350 |
| M2 "Mb scale" | ADDRESSED | :33-37, :269-270 |
| M3 unlike counts | ADDRESSED in FINAL.md | :117-121. The compare_papers.py row note (:1126-1130) is ruled to 16B (progress.md:296) |
| M4 0.66 | ADDRESSED (see N3) | :208-210 |
| M5 "more distant" | ADDRESSED | :195-196 |
| M6 Zea nulls for citrus | ADDRESSED | :263-264 |
| M7 TIL25 | ADDRESSED | :122-125 |
| M8 ties | ADDRESSED | test_compare_papers.py:193. Against my ">" mutant: 1 failed, 18 passed (`assert 0 == 2`); installed script: 19 passed (`r1/m8_mutant`, `r1/m8_green`); ruff clean |
| M9 import | ADDRESSED | test_compare_papers.py:5-6, :17 |
| M10 precedent | ADDRESSED (see N6) | :253-259. KKSC, PMID 26967525, matches PubMed |
| M11 jargon | ADDRESSED | :12-13, :128-129 |

**Numbers added this round, re-derived once from source files**
- **D_pav across variants.** Source: `stability/block/b{1,2,5,10,20}/stats.tsv` and
  `{mm2,cap5k,default4}/views/main/stats.tsv`.
  - Z by block length: 8.385, 7.867, 7.385, 6.635 and 6.041.
  - mm2: Z 6.890, D +0.2860. cap5k: Z 7.489, D +0.2948. default4: Z 7.421.
  - So "+0.286 to +0.295, Z 6.0 to 8.4" holds.
  - The `*_papers.tsv` files of mm2, cap5k and default4: 0 of the 24 bar rows differ from the final.
- **dD.**
  - mm2: +0.3969 ± 0.1405, Z 2.825. Its SE is 10.8% above 0.1268.
  - Blocks: b10 Z 3.103, b20 Z 3.088.
  - mm2 has 27+7 = 34 informative loci at K = 0.
  - mm2 resolves fewer calls: B73 0.709 against 0.728, TIL01 0.686 against 0.710.
- **Six-genome controls** (`block/all_b*`, block lengths 1, 2, 5, 10, 20 Mb).
  - Positive control Z: 3.781, 3.498, 3.158, 2.922, 2.764.
  - Negative control Z: 3.800, 3.535, 3.201, 2.800, 2.793.
  - They swap at 10-20 Mb, and no block length passes both.
- **SE ratios** (raw stats of the 20 trios): 1.082 at 10 Mb and 1.151 at 20 Mb. From 1 to 5 Mb the median ratio is
  1.182, above 1 in 20 of 20 trios.
- **Simulated nulls** (the 60 runs' views/main stats and eval.json).
  - 101-107 blocks per run (median 103) of 0.935-0.990 Mb: "about 1 Mb" holds.
  - Genomes are 93.5-102.1 Mb (mean 97.6), so "about 96 Mb" is low (N4).
  - The flat simulated SE (0.061-0.063) belongs to truth D (`sim/probes/task11/claims.txt:20-31`; N5).
- **Citrus and genus controls.**
  - k1: 21/8 loci, SE 0.1716, so it flags |D| above 0.515.
  - k2: 15/19 loci, SE 0.2176, so it flags |D| above 0.653.
  - Genus control: 73/84 loci, SE 0.1024, so it flags |D| above 0.307.
  - k1's Z of 2.61 is reached by 0 default nulls and by 2 bottleneck nulls (2.903 and 3.143).
- **Row 3 note.** 1.17/301.4 = 0.39%, and 40/2,036 = 1.96%.
- **Row 4 note.**
  - d(TIL18,TIL25) is 0.343184 against d(TIL18,B73) 0.342776.
  - `second_donors` (`trio.py:471-486`) requires d(D,g) to be below all four cross distances, so TIL25 fails.
  - The PAV distance definition matches `relations.py:199-215`.
  - The Toronto gloss matches DESIGN.md:102-103.

**New issues in the changed text**
- **N1 (should fix; one sentence).** FINAL.md:316 says "The genus control passes with the most power (157
  informative insertions; ... |D| above about 0.31)".
  - The six-genome negative control is far more powerful: 1,896 informative insertions (1,085 + 811), SE 0.0451, so
    it could flag |D| above about 0.14 (`six/views/all/stats.tsv`).
  - It is also the control that misses at 5 Mb. Ranking the genus control first overstates the passing evidence.
  - Fix: "Of the controls that pass at 5 Mb, the genus control has the most power (157; |D| above about 0.31); the
    six-genome control, the most powerful (1,896; |D| above about 0.14), misses at 5 Mb and passes at 10-20 Mb."
- **N2 (nit).** FINAL.md:291 says "by 0.015". The margin is 3.1576 − 3.1434 = 0.014. Task 13's review set it at
  0.014, and six/RESULTS.md:124 rounds it to 0.01.
- **N3 (nit, caused by my M4).** FINAL.md:208-209 states as fact that rule 8's 0.66 is 0.19/0.29. No file records
  where 0.66 came from, and 0.1949/0.2959 (D_ins against the no-outgroup-filter stratum, which PRELIM sets it beside)
  gives 0.659 too. Say that the source is not recorded and both ratios give 0.66. The interval claim is unaffected.
- **N4 (nit).** FINAL.md:58 and :234 say "about 96 Mb". The nulls' genomes are 93.5-102.1 Mb (mean 97.6).
- **N5 (nit).** FINAL.md:112-113 and :233: the flat simulated SE was measured on truth D (perfect genotypes), not
  D_pav. Add "(truth D)".
- **N6 (nit).** FINAL.md:258 calls "a local-ancestry painting from insertion presence/absence" possibly new. But
  LTRmix, compared throughout this report, paints from LTR-RT classes that include presence/absence. DESIGN 1a's
  novelty claim is relative to the published literature; say so.

**Out of scope**
- The residual M3 note in compare_papers.py:1126-1130 is ruled to 16B (progress.md:296); not judged here.

**Assessment (fix round 1): Needs fixes.**
- Required: N1 only, one sentence in FINAL.md, no rerun.
- Optional: N2-N6.
- Everything else is approved. I1, I2 and M1-M11 are addressed, the added numbers match their sources apart from
  N2-N4, and no verdict, table line or output changed.

---

# Original review (2026-11-14 18:25-18:50)

Reviewer: independent read-only review, 2026-11-14 18:25-18:50 EST. Snapshot 2 (SNAP_SHA=6282541 via common/env.sh),
one thread per probe, every probe under 3 min. R = benchmark_pav/plan3/real. Probes and their outputs in
`/tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3t16a-review/`:
- `base/`: the installed compare_papers.py (sha256 47d2c20d...2145) and test file: 19 passed with `-W error`.
- `mutate.py`, `mut/`: each fix reverted one at a time in a scratch copy, then the 16A tests run (18 of 19 reverts fail
  at least one test; see M8).
- `view/` (copy of the final view, absolute links) and `rerun/`: the installed script rerun with `--prefix final`;
  final_papers.tsv, final_ltrmix_crosscheck.tsv and both tables are byte-identical to the shipped ones; inputs/*.fai
  unchanged.
- `fvp.tsv`: diff_prelim.py rerun; byte-identical to papers/final_vs_prelim.tsv.
- `nullz.py`: the 60 null Z values recomputed from sim/runs/*/eval/eval.json. `cmp_pairs.py`: main3's 9 pair files
  against six/geno's.

## Spec compliance

- ✅ Verdict constants PASS / MISS: `R/common/compare_papers.py:98`; test `test_verdicts_read_pass_and_miss`.
- ✅ Rules 1-2 and the null distributions read from sim/: `load_sim` `compare_papers.py:263-314` (bars.tsv,
  calibration.tsv, null.tsv, direction.tsv; per-run Z from eval.json with a fail-fast check against null.tsv at
  `:310`); rows at `:1034` (rule 1), `:1047` (rule 2), `:1063` (null distribution). Reading per-run Z from eval.json
  rather than sim/tables was a flagged concern, accepted (progress.md:285).
- ✅ D_pav row: bar "D > 0, Z > 3" kept; rules 1-2 beside it; both quantiles (default max |Z| 1.97, bottleneck 3.14);
  verdict rests on the bottleneck nulls (`dpav_verdict` `:334-340`), PASS only when no bottleneck null reaches |Z|,
  as ruled (progress.md:285, ruling I4).
- ✅ dD rows: PRELIM's bar and "reported" verdict kept, caveat added (`dd_caveat` `:1099-1107`, `:1120`, `:1154`); new
  row "not available: dD is testable in 1 of 30 default nulls (29 NA) and 3 of 30 bottleneck nulls" with
  SIM_RESULTS section 1's reason (`:1110-1143`). No null invented.
- ✅ Roles misread: `trio_sharing` `:954-967` reads only the declared trio's sharing scope; `add_roles` `:970-1004`
  says "roles fixed by --trio ... agree" (six_main_papers.tsv's old row read "TIL11 + TIL01 ... DOES NOT match").
- ✅ Direction misread: `add_direction` `:1179-1247` reads the B73,PT;TIL25,TIL18 quartet, D_dir and the view's
  "not validated by simulation (Plan 3)" status; "reported" (the old row read "51 rows ... skipped").
- ✅ Cross-check carries the prefix: `output_paths` `:940-944`, written at `:1894` (final_ltrmix_crosscheck.tsv,
  control_main3/main3_ltrmix_crosscheck.tsv).
- ✅ The two extra text fixes (f4 note `amount_note` `:1157-1168`; pooled pair count `mech_pooled_item`
  `:1170-1173`): beyond R2's list, accepted by the controller (progress.md:285); main3's control shows them as script
  edits only.
- ✅ Tests fail before each fix: `common/test_compare_papers.red.out` (17 failed / 2 guards passed on the refactored
  module ea95e18d; phase 2: 2 failed). The refactored module is not kept, so I re-derived it: reverting each fix in a
  scratch copy fails its test(s) for 18 of 19 reverts (constants, prefix, roles scope, roles note, bottleneck rule,
  calibrated branch, quantile cell, rule-1 row, both dD caveats, f4 note, pooled count, direction, the null.tsv check,
  the run-name filter, the "not demonstrated" reading, the taxon-pair naming, the status line). Ruff F/E9/B: the same 8
  findings as Task 13's copy.
- ✅ sha256 recorded: old 1e04f43e...334a (kept as compare_papers.py.task13), new 47d2c20d...2145 (installed;
  `logs/compare_papers.log:1` records it for the final run).
- ✅ final_papers.tsv: `R/papers/views/main/final_papers.tsv` (152 rows), symlink `R/papers/final_papers.tsv`; rerun
  byte-identical.
- ✅ PRELIM diff: `R/papers/final_vs_prelim.tsv` with `diff_prelim.py` (rerun byte-identical); every changed row has a
  cause (the script exits on an uncaused row).
- ✅ FINAL.md structure: 10.3 table with LTRmix's columns as in PRELIM (`FINAL.md:75-95`), misses with their
  dead_ends.md entries (`:117-142`), changes from PRELIM (`:144-195`), the four closing items each labeled
  (`:213-283`). Citations: the four PMIDs/DOIs match PubMed (38033071, 35771940, 36643761, 23902747).
- ❌ FINAL.md honesty, thin and fragile results: the block-length flips of the six-genome controls (Task 15) and the
  rest of Task 15's robustness results are absent (I1); the citrus controls' low power is not stated (I2).
- ✅ Provenance: snapshot 2 in `logs/{view,stats,paint,compare_papers,control_main3}.log:1`; `logs/fai.before.tsv` =
  `fai.after.tsv`; in views/main only the three compare_papers outputs are newer than `final_view.done` (work/checksums.json
  is 17:32, so the catalog's checksum cache hit); main3_analyses has no file modified on 2026-11-14; six/ and sim/
  have none after 17:30. papers/views/main stats.tsv = six/views/main's plus the 28 identity rows.
- ⚠️ The red phase itself (module ea95e18d) cannot be replayed (not kept); the mutation probe stands in for it.

## Verdict check

| Row (final_papers.tsv) | Re-read from the view | Bar | TSV verdict | Agree |
|---|---|---|---|---|
| 3: D_pav(B73,TIL01;TIL18) all | stats.tsv D +0.289784, SE 0.039238, Z 7.38529 (1,313/723); from the 60 eval.json: default max \|Z\| 1.9668 (p95 1.36), bottleneck max 3.1434 (p95 2.74), 0 and 0 reach 7.39, empirical p 1/31 = 0.032; rule 2 not calibrated (SD 0.717, 0.571-0.964) | D > 0, Z > 3; no bottleneck null at \|Z\| >= 7.39 | PASS | agree |
| 28-29: chromosomes by posterior (unw., w.) | stats.tsv paint_seqid: chr9 0.307, chr5 0.320, chr8 0.325, then chr4 0.350; weighted chr9, chr5, chr8 (chr4 0.348) | exactly chr5, 8, 9 | PASS ×2 | agree |
| 30-31: chromosomes by class share | chr5 0.244, chr9 0.252, chr4 0.294, chr8 0.321 (weighted chr5, chr9, chr4) | exactly chr5, 8, 9 | MISS ×2 | agree |
| 40-55: windows vs ELAI, 1-10 Mb | final_tables/windows.tsv: r 0.256-0.383, p 0.000999 in all 16 (rerun identical) | shift p < 0.01 at >= 1 Mb | PASS ×16 | agree |
| 71: ZmPRR37a ±50 kb | tracts.B73.bed: no tract overlaps chr7:183.90-184.03 Mb; smallest q anywhere 0.198 (767 tracts) | a q <= 0.05 tract overlaps | MISS | agree |
| 79-80: 52 HF regions | shift p 0.3856 / 0.3736 | p < 0.01 | MISS ×2 | agree |
| 153: direction | findings.txt: DFOIL-alt (B73,PT;TIL25,TIL18) 0000 "none", largest \|Z\| 1.90; D_dir +0.064 (Z 0.90); "not validated by simulation (Plan 3)" | exploratory | reported | agree |
| totals | 152 rows: 19 PASS, 5 MISS, 128 reported, 0 skipped | | | agree |

PRELIM diff, checked independently:
- 158 rows: 25 same, 78 changed, 6 removed, 49 added (4 script, 45 view); 133 differ.
- Only verdict change: direction "skipped" -> "reported". PASS (prelim) -> PASS 19 and MISS (prelim) -> MISS 5. No
  LTRmix or bar cell changed in any matched row.
- Every changed column is explained by the A->B (script) or B->C (view) difference.
- The control separates the causes. PRELIM against control_main3 differs only in the 24 verdict labels, the D_pav
  primary row, the two dD notes, the f4 note and the pooled item, plus the 4 new rows. Its roles and direction rows are
  identical to PRELIM's. E6, E7 and E8 are script edits that show only on the new view, so they correctly sit with W
  codes.
- The view cause holds:
  - all 9 pair files among B73, TIL18, TIL01 and Zd are identical to main3's in every column except
    anchor_left/anchor_right (127,636, 124,641 and 137,847 elements; 0 differences);
  - Task 15's `stability/default4/views/main` (six/geno's pair files merged on main3's four genomes, snapshot 2)
    reproduces main3's stats.tsv in all 2,981 shared statistic rows. The only differences are the run keys and roles
    source data -> --trio; the extra rows are new emission rows.
  - So neither the engine (7d71073 -> 12d3e6c) nor the analysis code (12d3e6c -> 6282541) moves a number: the
    seven-genome merge does.

## Strengths

- The work began with a behavior-preserving refactor, proven byte-identical on six/views/main (sha256 77f95239...
  both), before any fix. Each fix is then a small named function with a failing-first test.
- load_sim refuses per-run nulls that do not reproduce null.tsv. It also excludes the 100-Mb pilot run, and a test
  pins that.
- The D_pav verdict logic is exactly the ruled reading. The row states rule 1, rule 2, both quantiles and the 1/31
  floor.
- The dD rows say plainly that no null exists, and why.
- The diff is reproducible, refuses uncaused rows, and its control design (main3 rescored) separates script from view
  cleanly.
- FINAL.md's table is faithful to final_papers.tsv; I checked every number in rows 1-14.
- FINAL.md gives statistics with nearly every claim. It never presents the direction "none", the HPC1/ZmLPCAT1 rows
  or dD as findings, states the smallest detectable DFOIL effect (±0.13), and says D_pav does not separate the
  six-genome controls.

## Issues

### Critical
None.

### Important

**I1. FINAL.md omits Task 15's robustness results, so its fragile results are stated at their 5-Mb values only.**
- Where:
  - `FINAL.md:21-22`: "none of the 60 ... came near it".
  - `:23-26` and `:80`: dD Z 3.1.
  - `:98-103`: row 2's note.
  - `:248-249`: the positive control "passes narrowly".
  - `:266-267`: "four negative controls, of which three pass".
  - Neither "stability" nor "block" appears anywhere in FINAL.md.
- What `R/stability/RESULTS.md` shows:
  - Controls (`:39-44`, `:104-105`, `:150-152`): the six-genome controls flip with jackknife block length. The
    positive control falls to Z 2.92 and 2.76 at 10 and 20 Mb (MISS; 1-2 bottleneck nulls reach it). The negative
    control falls to 2.80 and 2.79 (PASS). No block length passes both.
  - dD (`:32-38`, `:95`): Z 2.83 with `--anchor mm2` (same estimate) and 3.09-3.10 at 10-20 Mb.
  - Block lengths (`:145-147`, `:201-202`): the 60 nulls' Z used about 103 blocks of 0.96 Mb on 50-Mb genomes
    (`sim/runs/null_s101/views/main/stats.tsv`: "103 jackknife blocks of 962,736 bp"; the real data use 425 blocks of
    5 Mb). The real SE still grows at 20 Mb (x1.15 median). So the empirical-quantile reading is not a like-for-like
    comparison.
  - The main D_pav PASS survives all of it: Z 6.04-8.39 across block lengths and 6.89 under mm2, each above the
    bottleneck maximum of 3.14.
- Why it matters: the generality tally and "the positive control passes" rest on one analysis choice. The review
  criteria and CLAUDE.md ("name the exceptions") ask for this to be stated.
- Fix (text only): add a short "Robustness (Task 15)" bullet to section 6, linking `../stability/RESULTS.md`, and
  qualify lines 22, 24, 248 and 266. For example: "D_pav's PASS holds under every route, flank cap and block length
  (Z 6.0-8.4); dD's Z sits at the threshold (2.83 with whole-genome anchors, 3.09-3.14 across block lengths); the
  six-genome controls swap verdicts at 10-20 Mb blocks; the nulls used about 1-Mb blocks on 50-Mb genomes, so their
  quantiles are a guide, not a like-for-like null."

**I2. The generality tally counts underpowered controls as passes and overstates the rank agreement.**
- `FINAL.md:259` ("both sour-orange controls hold (Z 2.61 and −0.54)") and `:266-267` ("of which three pass"). Per
  `R/citrus/RESULTS.md:78-79` and `:152-160`:
  - k1 rests on 29 informative insertions and reads D +0.448. No default null reaches its Z of 2.61.
  - k2 rests on 34 insertions, and its smallest flaggable effect is |D| ≈ 0.65. "The controls test only for strong
    gene flow."
  - They are consistent with no gene flow, not evidence that D_pav holds a null.
- `FINAL.md:253`: "D_pav ranks them as the SNP D does (Spearman rho 0.90 ...)". But `R/six/RESULTS.md:105` says the
  two controls swap ranks, and they are the one pair that matters.
- Fix: give n and the detectable |D| for the citrus controls and call them uninformative or "consistent". Recount, for
  example: "the genus control passes; the six-genome control misses at 5 Mb and passes at 10-20 Mb; the two citrus
  controls could flag only |D| above about 0.5-0.65". Then write "nearly as the SNP D does (rho 0.90), except that the
  two controls swap".

### Minor

- **M1. Stale script path.** `FINAL.md:13`, `:15` and `:295` name `../common/compare_papers.next.py`, which no longer
  exists: it was moved over compare_papers.py, sha 47d2c20d, and the old file kept as `.task13` (progress.md:286). Fix
  the three paths and drop "once Task 15 ends".
- **M2. "Only at the Mb scale" contradicts the table.** `FINAL.md:27` ("Locally: only at the Mb scale") and `:228`
  ("the signal shows only in 1-10 Mb windows") contradict row 6 (`:84`; final_papers rows 32-39: r +0.20 to +0.28 at
  0.1-0.5 Mb, each p 0.001) and the element AUROC of 0.71. Reword: "correlation with ELAI is significant at every
  window size and strongest at 1-10 Mb; no tract can be certified".
- **M3. Unlike counts in the dD note.** `FINAL.md:104-106` and the row note at `compare_papers.py:1126-1130` set young
  informative loci per 50-Mb null (mean 1.2) against 40 in a 2.1-Gb genome. Use a like-for-like figure: 2.0% of
  informative loci here (40/2,036) against 0.4% (1.2/301), or about 0.9 per 50 Mb against 1.2.
- **M4. 0.66 is not a rounding of 0.67.** `FINAL.md:188` says "D_ins/D_pav is 0.67 here, rounded to 0.66 in Plan 3's
  rule 8". 0.66 is 0.19/0.29, the ratio of PRELIM's rounded values. The claim that 0.43-0.69 contains the real ratio
  is unaffected.
- **M5. Unsupported "more distant".** `FINAL.md:175-176` reads "(the same definition over more, and more distant,
  discoverers)". "More distant" is unsupported: PT is B73's nearest genome, and TIL25 is TIL18's taxon-mate. Drop it.
- **M6. Zea nulls applied to Citrus.** `FINAL.md:222-223` says "Each lies beyond all 60 simulated nulls", but the
  nulls are Zea-parameterized 50-Mb genomes. For sweet orange, call them a reference, not that system's null.
- **M7. Why TIL25 is not a second donor.** At `FINAL.md:82` ("no genome qualifies as a second donor") a biologist will
  ask why TIL25 (mexicana) does not. By PAV distance TIL18~TIL25 is 0.3432 against TIL18~B73 0.3428
  (views/main/stats.tsv distance rows). One clause would answer it.
- **M8. Ties untested.** `compare_papers.py:330`: null_quantile counts ties (>=), but no test pins this. Changing it
  to > passes all 19 tests. Add a tie case, for example `null_quantile(3.14, [3.14]).k == 1`.
- **M9. Stale import fallback.** `test_compare_papers.py:17-19` still prefers a stray `compare_papers.next.py`. Now
  that the move is done, import compare_papers.py only (16B).
- **M10. No precedent line for the headline.** The headline sentence (`FINAL.md:217-219`) has none. CLAUDE.md asks to
  "check the literature for precedent and state what is new". `LTRpav/docs/DESIGN.md:37` and `docs/lit_review.md:48`
  already record insertion-based hybridization tests (KKSC, doi 10.1371/journal.pcbi.1004812), and the spacing limit
  is expected for any marker-based painting. Name what is new, as SIM_RESULTS' headline does: donor-only discovery
  plus assembly genotyping, blind to sister annotation.
- **M11. Undefined jargon.** `--trio` (`FINAL.md:12`, `:77`, `:173`) and "Toronto Agreement release" (`:108`) are
  undefined for a non-CS reader.

## Assessment

**Needs fixes**, in FINAL.md text only (I1, I2; the minors at the writer's discretion). compare_papers.py
(47d2c20d), its tests, final_papers.tsv, final_ltrmix_crosscheck.tsv, final_tables/, final_vs_prelim.tsv and
control_main3/ are correct as they stand and need no rerun. The verdicts (19 PASS, 5 MISS, 128 reported; D_pav PASS on
the bottleneck reading) and the PRELIM diff (133 differ, 25 same, no flip, no LTRmix change) are confirmed.
