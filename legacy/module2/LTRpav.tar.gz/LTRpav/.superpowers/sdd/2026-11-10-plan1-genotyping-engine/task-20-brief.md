### Task 20: Output files

**Files:** Create `src/ltrpav/outputs/{__init__,tables,vcf,tracks,manifest}.py`, `tests/test_outputs.py`

**Interfaces:**
- Consumes: `Locus`, `GenomeState`, `QcRow`, `Sample`, `Fasta`.
- Produces: `write_loci_tsv(loci, samples, path)`; `write_pav_matrix(loci, samples, path)`;
  `write_qc(rows: list[QcRow], path)` (columns `scope metric value`); `write_vcf(loci, samples, ref_label: str, fasta: Fasta, path: Path) -> tuple[Path, Path]`
  (vcf.gz with `.tbi`, and the unplaced TSV); `write_tracks(loci, samples, outdir)`;
  `write_manifest(path, argv, params, samples, checksums, started, finished)`.

- [ ] **Step 1: Write the failing tests**

```python
def test_vcf_encoding(tmp_path):
    v = pysam.VariantFile(write_vcf(loci, samples, "A", fa, tmp_path / "pav.vcf.gz")[0])
    rec = next(iter(v))
    assert rec.alts == ("<INS:ME:LTR>",) and rec.info["SVTYPE"] == "INS"
    assert [rec.samples[s]["GT"] for s in ("A", "B", "C")] == [(1,), (0,), (None,)]
    assert [rec.samples[s]["ST"] for s in ("A", "B", "C")] == ["P", "E", "D"]
    assert rec.info["AA"] == rec.ref                     # an empty site is observed
def test_vcf_pos_conventions(tmp_path):  # present in ref genome: POS = start-1; E in ref genome: POS = last base of the TSD copy
def test_unplaced_side_file(tmp_path):   # ref-genome state D -> row in pav.unplaced.tsv, not in the VCF
@pytest.mark.skipif(shutil.which("bcftools") is None, reason="bcftools missing")
def test_bcftools_reads_vcf(tmp_path):   # `bcftools view -H` exit 0 with the expected record count
def test_tracks(tmp_path):               # <label>.pav.gff3 types: P/S/T LTR_retrotransposon, E insertion_site,
                                         # D deletion_junction; attribute states=A:P,B:E,C:D (every genome);
                                         # BED6+3 columns state, tier, family
def test_matrix_and_loci_tsv(tmp_path): ...
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - **VCF:** pysam `VariantHeader` with contigs from the reference genome's fai. INFO `SVTYPE`, `SVLEN`, `END`,
    `FAM`, `SF`, `K`, `DISC`, `NE` (number of E genomes), `AA`; FORMAT `GT` (haploid), `ST`, `TR`;
    `##ALT=<ID=INS:ME:LTR,...>`. Sort the records, then `pysam.tabix_index(..., preset="vcf", force=True)`.
  - **GT:** 1 for P/S/T, 0 for E, missing for D/O/G/U.
  - **GFF3:** `##gff-version 3` plus `##sequence-region` lines.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add TSV, VCF, GFF3/BED and manifest outputs"`.

---

