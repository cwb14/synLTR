# Task 6 report: painting — HMM, tracts, target-decoy q-values, youngest insertion per tract (DESIGN 7.4, 7.5)

Status: DONE_WITH_CONCERNS. The port is faithful and every test passes. The concerns are about what the
ported model does on real data (concern 1) and a few judgment calls (listed under Decisions).

Commit: de55445 "Add painting HMM with target-decoy q-values" (on 14d76e9). Global git identity, no trailers,
not pushed. Files:
- src/ltrpav/analysis/paint.py (new);
- tests/test_paint.py (new);
- src/ltrpav/analysis/constants.py (+2 lines: CALLABLE_FLANK, CALLABLE_MAX; see Decisions 6).

No engine module was touched.

## Tests
- TDD: the tests were written first. `pytest -W error tests/test_paint.py` failed on the import
  (ModuleNotFoundError), then passed.
- tests/test_paint.py: 18 passed in about 10 s (the brief's 12 tests and 6 of my own).
- Full suite `NUMPY_MADVISE_HUGEPAGE=0 python -m pytest -W error -m "not slow"`: 981 passed, 1 deselected (127 s).
- `ruff check .` (repo root): clean.
- The brief's tests are AST-identical to the brief except one lint-only edit. In
  test_forward_backward_matches_enumeration, `post, ll, c1, c0 = ...` became `post, ll, _, _ = ...`
  (RUF059, unused variables), as Task 4 did. Every assertion and value is verbatim.
- Extra tests (mine):
  - `test_forward_backward_chains_restart_and_counts`: two chains in one call equal two separate calls; the
    expected counts c1/c0 equal the posterior summed per class; a one-locus chain gives Bayes' rule.
  - `test_fit_hmm_two_blocks`: EM keeps state 1 donor-like; pi stays in [1e-4, 0.5]; L comes from the grid;
    the RD block is one tract; no emitting locus raises ValueError.
  - `test_target_decoy_edges`: no target; no decoy tract; the scale multiplies the decoy counts
    (hand-computed q 0.5, 0.5, 0.75, 0.75 at scale 2, against 0.5 at scale 1).
  - `test_classes_any_discovery`: the "any" variant uses merged states and non-member loci; the recipient
    rule uses members and own calls only; an unknown rule raises.
  - `test_skips`: no RS locus; recipient unannotated; count rows, a WARNING, no file.
  - `test_youngest_u95_from_self_rows`: R's copy first, else D's; an RS locus is never counted; exactly one
    Dating line.
  - `test_rows_and_files`, which checks:
    - the statistics against the Painting;
    - `mean_donor_run_bp = L/(1 - pi)`;
    - excess, n_tracts_q05, and the scale as the ratio of informative loci (decision 7);
    - every row's loci; paint_seqid in fai order;
    - the shortest-callable rows against `shortest_callable`;
    - the decoy painted with the target's parameters unchanged (recomputed with `forward_backward`);
    - stale files removed; headers; names, scores and strand; the "any" painting declares `disc=any`.

### D8: does test_paint_null fail when painting is broken? (mutation check)
I applied 11 mutations to paint.py one at a time, ran the tests and restored the source each time; cmp
confirms paint.py was restored. Every mutation was caught. The tests that caught them:

| Mutation | Caught by |
|---|---|
| swap RD/RS emissions | finds_tracts; also null_and_positive_control |
| decoy built from the target's own loci | finds_tracts; also null_and_positive_control |
| no distance in switching | enumeration; also null_and_positive_control |
| everything painted donor-like | null_and_positive_control |
| classes from merged states | test_classes |
| "old" ignored | test_classes |
| tract rule without the odds test | test_tract_rule |
| q without the +1 correction | test_target_decoy_plus_one |
| scale inverted | test_rows_and_files |
| decoy refitted | test_rows_and_files |
| no EM | test_fit_hmm_two_blocks |

Run on its own, test_paint_null_and_positive_control catches the four mutations that break the painting
itself (the first four rows).

## What was built (the brief's names and signatures)
- PAINT_CLASSES, POSTERIOR_COLUMNS, TRACT_COLUMNS, HmmFit, Tract and Painting, as given.
- `Painting` gained four trailing fields with defaults; the brief's fields are unchanged:
  - `discovery`;
  - `decoy_inv`;
  - `scale` (None = no decoy);
  - `self_counts`.
- `classes`:
  - Recipient rule: X's members, with every state from X's own calls (`pcls(X, .)`).
  - "any" rule: merged cls(X) == 1 and merged states.
  - Class order: old (some outgroup present), missing, RD, RS, both, neither.
  - idx in X's (fai index, start) order (stable lexsort, so ties keep catalog order).
- `forward_backward`: `@njit(cache=True)`, a line-for-line port of LTRmix `_fb_cat`, plus a range check on
  emission codes.
- `fit_hmm`:
  - port of `fit_hmm_cat`: pi 0.1, L 1e5, the `np.geomspace(*HMM_L_GRID)` scan, +0.5 pseudocounts;
  - pi clipped to [1e-4, PI_MAX]; HMM_TOL and HMM_ITERS as the stopping rules;
  - a final forward-backward pass;
  - a ValueError when no locus emits.
- Initial emissions as LTRmix: the decoy's class counts + 1 (the target's own without a decoy), and
  e1 = e0 * (5, 0.2), normalized.
- `donor_state` = e1[RD] > e0[RD].
- `call_tracts`: maximal runs on one fai index with post > 0.5 and odds >= BF_TRACT x prior odds.
- `target_decoy`: LTRmix's q (smallest raw at or below the score, capped at 1) and p.
- `shortest_callable`: lower bound with no flanks, upper bound with 20 RS loci on each side, middle locus
  k // 2, k from 1 to 200.
- `paint`:
  - the decoy is S's loci under the same rule, classed by S's own calls with X = S, Y = R;
  - it is painted with the fitted parameters unchanged, and its tracts use the same rule;
  - scale = n informative(R) / n informative(S);
  - `inside` flags R's loci (and S's for the decoy), keyed on fai indexes with the site start.
- `write_paintings`:
  - deletes old tracts.*.bed, posterior.*.tsv, decoy_tracts.*.bed and decoy_posterior.*.tsv first;
  - writes one file per recipient and one decoy file per sister, rows ordered by trio scope then position;
  - BED is 0-based, name `<D>-like`, score min(1000, int(1000 * mean_post)), strand ".";
  - values go through `tsv_field` (6 significant digits);
  - q and p_decoy are "none" without a decoy and "." on decoy tracts.
- `paint_rows`:
  - rows `paint`: the brief's 21 statistics, in order;
  - rows `paint_resolution` (`stats.resolution`, so it warns above RESOLVE_WARN);
  - rows `paint_seqid` (posterior_mean, n_RD, n_RS, class_share), one set per R sequence with painted
    loci, in fai order;
  - findings in "Painting" and "Dating"; every row declares its loci, e.g.
    `disc=R;present=R;res=S,D;outgroup=not_present` for the HMM rows and `...;outgroup=none` for
    posterior means.
- Lengths (A24/D13): `mean_tract_bp` = L, LTRmix's name and quantity; `mean_donor_run_bp` = L/(1 - pi).

## Decisions to check (not fixed by the brief; the most defensible choice taken)
1. **Tract end = the largest end over the run's loci**, not the last locus's end. The brief says "end of
   the last". With nested loci sorted by start, the last locus can end inside an earlier host; the BED
   interval should hold every locus. The two are identical without nesting, and the tests compare with
   `t.end`, so they are consistent either way.
2. **HMM positions = X's site starts**, the insertion point, rather than LTRmix's element midpoints. Starts
   never decrease along idx; a nested element's midpoint can, which LTRmix clamps to distance 0. The
   difference is at most half an element, against L >= 10 kb. The spacing statistics use the same
   positions.
3. **No decoy when S's loci hold no informative locus**, as well as when S is unannotated: a decoy that
   cannot emit calibrates nothing. Either way q and p are "none", with a WARNING naming the reason.
4. **Skipped paintings write no file rows.** A recipient whose every trio is skipped gets no file;
   `paint_rows` still gives n_informative, n_RD, n_RS and the resolution rows when classes exist.
5. **Decoy files use TRACT_COLUMNS and POSTERIOR_COLUMNS.** The sister column holds R (in the decoy, X = S
   and Y = R); q and p_decoy are "."; youngest_k and inv_frac are computed for S's copies the same way.
   A posterior row's `tract` column holds the tract as `seqid:start-end` (1-based), "." outside a tract.
6. **CALLABLE_FLANK = 20 and CALLABLE_MAX = 200 went into analysis/constants.py**, each with a one-line
   reason. The Global Constraints put thresholds there, and Task 4's JK_MIN_BLOCKS is the precedent. The
   brief's Files list does not name constants.py. The flank is named as a heuristic in findings.
7. **n_tracts_q05 counts q <= 0.05** (LTRmix's "FDR <= 0.05"). The brief's null test checks q < 0.05;
   both hold.
8. **Caveat line on q's floor.** When the target-decoy test cannot reach 0.05 with this few tracts, a
   Painting line says so: the +1 corrections keep q >= 1/n_tracts and p_decoy >= 1/(1 + n_decoy_tracts).
   This is the case in every admixed toy: 3 true tracts give q >= 1/3, and 0 decoy tracts give p = 1.
9. **No "maize" in src/** (Global Constraints). The gene-conversion caveat reads "common in plant LTR
   retrotransposons (40% of the elements in one survey, docs/lit_review.md)".
10. **youngest_u95:** R's self row is used if it has sites, else D's, else the locus is left out. The
    smallest bound over the tract is taken through `stats.u95`; nothing is reimplemented.

## Toy calibration (simulate_run, 4 x 1 Mb, defaults)
- **Null**, seeds 1-25:
  - any tract at q <= 0.05: 0 of 25;
  - excess over the decoy >= 0.05: 1 of 20 at seeds 6-25 (seed 22, +0.075), none at seeds 1-5 (seed 4 is
    the largest, +0.043);
  - the fit often collapses to pi = 1e-4 with no tract (classes are i.i.d. in the toy).
- **Admixed** (TRACTS, 900 kb), seeds 1-25:
  - truth bp covered 0.959-0.999;
  - excess +0.17 to +0.21;
  - 3-4 tracts, 0-1 decoy tracts;
  - fitted e1[RD] 0.99-0.997 against e0[RD] 0.23-0.32, so the background state stays a mixture, unlike
    main3; L 159-197 kb;
  - q >= 1/3 always (decision 8).

## main3, read-only probe (B73, TIL18, TIL01, Zd)
- **View:** symlinks to loci.tsv, manifest.json, qc.tsv, pairs/ and work/elements, with the view's own
  work/ (checksum and fai caches):
  /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t6/view
- **Script:** probe_main3.py in the same t6 directory. Output: probe_main3.out; files in t6/out.
- **main3 untouched:** a find of every path with its mtime and size, taken before and after, is identical
  (4,997 paths).
- **Roles from the data** (`trios`): B73,TIL01;TIL18. 523 inverted blocks.
- **Cost:** load 11.8 s; the paint itself (fit and decoy) 8.5 s; files and rows 0.6 s. Max RSS 0.53 GB.
- **Loci:**
  - 126,853 B73 loci: 2,699 RD, 4,816 RS, 14,115 both, 14,830 neither, 80,364 missing, 10,029 old;
  - decoy TIL01: 1,495 RD, 4,863 RS (scale 1.18);
  - resolved by B73's own calls: TIL01 0.521, TIL18 0.462 (the resolution warning does not fire: the
    difference is 0.058).
- **Fit:**
  - pi 0.359; L (`mean_tract_bp`) 301.7 kb; `mean_donor_run_bp` 470.7 kb;
  - e1 (RD, RS) = (0.9993, 0.0007), e0 = (0.0005, 0.9995): donor_state true, but near-deterministic
    (concern 1).
- **Tracts:** 770, covering 470,455,400 bp (21.6% of B73's 2.18 Gb; 469.5 Mb on chr1-10).
  - The decoy has 599 tracts on 302.8 Mb of TIL01 (11.6%).
  - Tract length: median 440 kb, 10-90% 181 kb to 1.19 Mb.
  - 64 tracts have inv_frac > 0.5; 14,527 painted loci (11.5%) lie inside inverted blocks against TIL01 or
    TIL18.
- **Posterior mean** (unweighted over loci): 0.370 against 0.317 in the decoy, excess +0.053. LTRmix
  ancestry mode on the same genomes: 0.383 against 0.341, +0.042.
- **Decoy q-values:**
  - none <= 0.05 (min 0.2, the five highest-scoring tracts at 0.2);
  - quantiles 10/25/50/75/100% = 0.58 / 0.62 / 0.76 / 0.86 / 0.92;
  - p_decoy: min 1/600 = 0.0017, with 63 tracts at p <= 0.05 (per-tract and unadjusted);
  - the five tracts above every decoy score (sum_post 272-350, against a decoy maximum of 213) are four on
    chr7 (36.2-71.0 Mb) and one on chr3 (70.8-75.6 Mb).
  - LTRmix ancestry mode also had 0 at FDR <= 0.05 (1,686 tracts against 1,597 in the decoy).
- **Three largest tracts:**
  - B73v5_chr7:64,711,177-71,025,991 (6.31 Mb, 375 loci, 17 RD, mean posterior 0.892, q 0.2,
    youngest K 0);
  - B73v5_chr7:58,071,009-64,268,847 (6.20 Mb, 386 loci, 20 RD, 0.907, q 0.2, youngest K 0.0015);
  - B73v5_chr7:36,152,369-41,729,856 (5.58 Mb, 335 loci, 52 RD, 0.924, q 0.2, youngest K 0).
- **Per chromosome:** chr7 has the highest posterior mean (0.449, class share 0.499). chr9 (0.307), chr5
  (0.319) and chr8 (0.325) are the three lowest (Task 12's item 5 tests this formally).
- **Spacing:** informative loci every 84.4 kb (median; mean 283 kb). The shortest callable tract is 1 locus
  (84.4 kb), with or without 20 RS flanks: a consequence of concern 1.
- **Dating:** the median youngest K over tracts is 0.0167 (all 770 tracts have a K); 35 tracts hold an
  identical-LTR RD insertion.

## Concerns
1. **On real data, EM drives the two-class emissions to near-determinism.** e1 = (0.9993, 0.0007) and
   e0 = (0.0005, 0.9995). This is not a porting error:
   - LTRmix's own main3 fit does the same: recent mode e1 (0.998, 0.0022), e0 (0.0019, 0.998); ancestry
     mode also near-deterministic.
   - The toys do not show it, because their classes are i.i.d.; real RD/RS classes cluster along the genome
     (shared genealogies from lineage sorting, inversions).

   Consequences:
   - the HMM reduces to segmenting runs of RD against RS loci, with L-scaled smoothing across missing loci;
   - an RD locus in a sister-like background is treated as almost impossible, so any single RD locus is a
     tract: shortest callable = 1 locus;
   - tracts extend over missing-data loci until the posterior decays (e.g., chr1:586,794-1,078,649 holds
     1 RD locus among 27 loci);
   - the TIL01 decoy also paints 599 tracts, so no single tract reaches q <= 0.05. The genome-wide signal is
     the excess (+0.053), and the five chr7/chr3 tracts above every decoy score (q 0.2).

   The brief says to port unchanged, so I did not change the model. A principled option for the controller:
   fix e0 at the decoy's class frequencies (the null emission) and fit only e1, pi and L, so the background
   state cannot become deterministic. That is a design change (DESIGN 7.4 says "EM-fitted emissions") and
   would need its own null/power check in Plan 3.
2. **The target-decoy q cannot reach 0.05 with fewer than 20 tracts** (q >= 1/n_tracts). With an empty
   decoy, p_decoy is 1. So the positive control recovers 96-100% of the truth bp, yet no tract is
   "significant". A findings line now says so whenever it applies (decision 8). The figure (Task 11) picks
   "the q <= 0.05 tract (else any tract)" and will usually fall back.
3. **`posterior_mean` is unweighted** (brief), while LTRmix's is length-weighted. Task 12 item 4 asks for
   both and must compute the weighted one itself from posterior.<R>.tsv.
4. **Painting extends the brief's interface** (decisions 1-6 and the four trailing Painting fields). A
   reviewer should confirm the tract-end and position choices (decisions 1, 2).

## Follow-up after review (task-6-review.md: Approved, 5 Minor), commit 87519c8
Commit: 87519c8 "Harden painting's q tests; report collapsed fits as such" (on de55445). Global identity, no
trailers, not pushed. Files: src/ltrpav/analysis/paint.py and tests/test_paint.py only.

**Results:**
- tests/test_paint.py: 25 passed (7 new tests, and new assertions in 3 tests of mine; the brief's 12 tests
  are unchanged).
- Full suite (-W error -m "not slow"): 988 passed, 1 deselected.
- ruff: clean.
- main3, read-only rerun: all four painting files are byte-identical to the first probe. The only changed
  findings line is "1 locus". main3 is untouched (all 4,997 paths have the same mtime and size).

**Changes:**
- **M1/M2, test gaps.** New tests:
  - `test_q_path_scores_sums_at_the_informative_scale`: a spy on `target_decoy` at seed 3 (4 tracts, 1
    decoy tract). It checks the target and decoy sum_post lists, the scale n_inf(R)/n_inf(S) (not 1), and
    that q and p are the function's return.
  - `test_target_decoy_edges` gained a tie case: [4, 3, 2, 1] against [3] gives p = [0.5, 1, 1, 1].
  - `test_rows_and_files` now checks that decoy_idx and decoy_cls equal `classes(cat, "S", "R", "D")`.
  - `test_tracts_break_at_sequences`: seq [0, 0, 1, 1], all posteriors 0.9, gives two tracts.
  - `test_fit_hmm_matches_ltrmix`: frozen LTRmix `fit_hmm_cat` values, recomputed from a scratch copy of
    ltrmix.py (sha256 b2dc6310..., geomspace grid; the port is bit-identical). The input is
    emit[::3] = -1: pi 0.20021184711, L 44,393.5372536, e0 (0.0062588872, 0.9937411128), e1 (0.9748814355,
    0.0251185645), loglik -9.952418349. Asserted at rel 1e-6.
  - `test_youngest_u95_from_self_rows` gained a K = 0 "both" locus inside the tract. It must not count:
    n_loci 40, n_RD 39, youngest_k 0.004, n_identical 0.
  - `test_shortest_callable_middle_locus`: pi 0.2, L 2e5, e0 (0.3, 0.7), e1 (0.6, 0.4), 20-kb spacing gives
    ((3, 60,000), (7, 140,000)), recomputed with LTRmix's `_fb_cat`.
- **M3, collapsed fit.**
  - New property `Painting.collapsed`: pi at its floor (1e-4) and no tract.
  - Then paint_rows writes donor_state, mean_tract_bp, mean_donor_run_bp and the four shortest_callable rows
    as NA, with a note saying why.
  - A findings line reads "the fit collapsed (pi at its floor 1e-4, no tract): no <D>-like ancestry is
    detectable in this trio ...". The main line and the resolution line no longer quote L or a callable
    tract, and the "no D-like state" WARNING is not added for a collapsed fit.
  - Painting.donor_state keeps the brief's rule.
  - `test_collapsed_fit_reported_as_such` runs on seed 1's null (pi exactly 1e-4, no tract).
- **M4, exact tie comparisons.**
  - sum_post is now `math.fsum` (exactly rounded) over the tract's posteriors, so the same posteriors score
    the same wherever they lie and in any order.
  - `test_tied_tract_sums_compare_equal`: [0.7, 0.9, 0.8, 0.6, 0.95, 0.85] after a 1,000-locus prefix,
    against the same values reversed in the decoy. They tie, and p_decoy is 1, not 1/2.
  - Both cumulative-sum differences and np.sum (order-dependent: 4.8 against 4.800000000000001) fail this
    test.
- **M5, wording.**
  - "1 locus" (`_n_loci`).
  - `_floor_line` names each floor with its own reason: q >= 1/n_tracts means too few tracts for a
    target-decoy q; p_decoy >= 1/(1 + n_decoy) means too few decoy tracts for a per-tract p-value.
  - `test_floor_line_names_each_reason` covers 100 tracts against 5 decoy tracts (only p named), 5 against
    100 (only q), neither, and both.

**Mutants now failing** (each applied alone to 87519c8's paint.py, the whole test file run, source
restored and verified by cmp):

| Mutant | Failing test(s) |
|---|---|
| M06 scale dropped from target_decoy | test_q_path_scores_sums_at_the_informative_scale |
| M14 tracts scored by mean_post | test_q_path_scores_sums_at_the_informative_scale |
| M07 decoy counts with > | test_target_decoy_edges, test_tied_tract_sums_compare_equal |
| M02 decoy classed from merged states | test_rows_and_files |
| M08 tracts joined across sequences | test_tracts_break_at_sequences |
| M16 no EM update of the emissions | test_fit_hmm_matches_ltrmix |
| M04 pi averaged over all loci | test_fit_hmm_matches_ltrmix |
| M11 youngest_k over every tract locus | test_youngest_u95_from_self_rows |
| M12 shortest_callable at the first locus | test_shortest_callable_middle_locus |
| M3 reverted (collapse not recognized) | test_collapsed_fit_reported_as_such |
| M4 reverted (cumulative-sum differences) | test_tied_tract_sums_compare_equal |
| M4 as np.sum | test_tied_tract_sums_compare_equal |
| M5 reverted ("1 loci") | test_floor_line_names_each_reason |
| M5 reverted (one reason for both floors) | test_floor_line_names_each_reason |

Scripts and outputs are in
/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t6:
mutate2.py and mutate2.out, mutate3.py, and freeze_ltrmix.py.
