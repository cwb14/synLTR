#!/usr/bin/env python3
"""Comparator: the ltrmix single-copy k-mer statistic on whole assemblies (chromosomes only) in 100-kb windows,
either all sequence or with annotated LTR-RTs masked (non-LTR genome). Writes per-window tallies for each genome:
k-mers single-copy in every genome that carries them, by carrier pattern [self only, +o1, +o2, all three]."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import argparse
import re
import sys
import time

import numpy as np

sys.path.insert(0, "/data2/chris/maize_introgression/LTRmix")
import ltrmix  # noqa: E402


def read_chroms(path, label):
    seqs = {}
    name, buf = None, []
    with open(path, "rb") as f:
        for line in f:
            if line.startswith(b">"):
                if name:
                    seqs[name] = b"".join(buf)
                nm = line[1:].split()[0].decode()
                name = nm if re.fullmatch(rf"{label}_chr\d+", nm) else None
                buf = []
            elif name:
                buf.append(line.strip())
    if name:
        seqs[name] = b"".join(buf)
    return seqs


def ltr_intervals(gff):
    iv = {}
    with open(gff) as f:
        for line in f:
            if line.startswith("#"):
                continue
            p = line.split("\t")
            if len(p) > 4 and p[2] == "LTR_retrotransposon":
                iv.setdefault(p[0], []).append((int(p[3]) - 1, int(p[4])))
    return iv


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--mode", choices=["all", "noLTR"], required=True)
    ap.add_argument("--win", type=int, default=100_000)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    labels = ["B73v5", "TIL18", "TIL01"]
    run = "/data2/chris/maize_introgression/run"
    D = {}
    t0 = time.time()
    for lab in labels:
        seqs = read_chroms(f"/data2/chris/maize_introgression/inputs/{lab}.fa", lab)
        if a.mode == "noLTR":
            iv = ltr_intervals(f"{run}/{lab}_LTRs_all_depth_LTR_cleaned.gff3")
            for c, s in seqs.items():
                arr = bytearray(s)
                for st, en in iv.get(c, []):
                    arr[st:en] = b"N" * (en - st)
                seqs[c] = bytes(arr)
        names, chunks, offs = [], [], [0]
        for c in sorted(seqs, key=lambda x: int(x.split("chr")[-1])):
            s = seqs[c]
            for w in range(0, len(s), a.win):
                chunks.append(s[w:w + a.win])
                names.append((c, w, min(w + a.win, len(s))))
                offs.append(offs[-1] + len(chunks[-1]))
        seq = np.frombuffer(b"".join(chunks), np.uint8)
        del seqs, chunks
        keys = ltrmix._keys_of(seq, np.asarray(offs, np.int64), ltrmix.K, ltrmix.RBITS)
        del seq
        keys.sort()
        u, st = ltrmix._runs(keys, ltrmix.RBITS)
        D[lab] = dict(names=names, keys=keys, u=u, st=st)
        print(f"{lab}: {len(names)} windows, {len(keys):,} k-mers ({time.time() - t0:.0f}s)", file=sys.stderr, flush=True)
    for lab in labels:
        o1, o2 = [x for x in labels if x != lab]
        d = D[lab]
        i1 = ltrmix._merge_idx(d["u"], D[o1]["u"])
        i2 = ltrmix._merge_idx(d["u"], D[o2]["u"])
        T = ltrmix._tally_single(d["keys"], d["st"], i1, D[o1]["st"], i2, D[o2]["st"], len(d["names"]), ltrmix.RBITS)
        with open(f"{a.out}.{lab}.tsv", "w") as f:
            f.write(f"chrom\tstart\tend\tonly_self\twith_{o1}\twith_{o2}\twith_both\n")
            for (c, s, e), t in zip(d["names"], T):
                f.write(f"{c}\t{s}\t{e}\t" + "\t".join(map(str, t)) + "\n")
        print(f"{lab} tallied ({time.time() - t0:.0f}s)", file=sys.stderr, flush=True)


if __name__ == "__main__":
    main()
