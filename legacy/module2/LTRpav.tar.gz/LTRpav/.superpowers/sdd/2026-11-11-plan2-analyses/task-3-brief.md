### Task 3: Relationships — run summary, discovery, sharing, tree, sister pairs, outgroup conflicts (DESIGN 7.1, 7.2)

**Files:**
- Create: `src/ltrpav/analysis/relations.py`, `tests/test_relations.py`

**Interfaces:**
- Consumes: `Catalog` (`cls`, `pcls_by`), `StatRow`, `Findings`, `P_WARN`; `scipy.stats.binomtest`.
- Produces:

```python
@dataclass(frozen=True)
class Node:
    name: str | None; children: tuple[Node, ...] = (); length: float = 0.0
    def leaves(self) -> frozenset[str]
    def newick(self) -> str                     # lengths to 6 significant digits, ";" at the end
@dataclass
class Counted:
    rows: np.ndarray                           # (n,) bool: candidates with x and y resolved in gstar's calls
    cand: np.ndarray                           # (n,) bool: gstar exists, z present, outgroup rule (gstar's calls)
    gstar: np.ndarray                          # (n,) int16: each row's discovering genome (z, or a fallback genome); -1 none
    disc: tuple[str, ...]                      # z, or the eligible fallback genomes
    loci: str                                  # e.g. "disc=D;present=D;res=R,S;outgroup=E"
    excluded: dict[str, str]                   # fallback genomes left out -> why
def run_summary(cat: Catalog) -> tuple[list[StatRow], Findings]
def pav_distances(cat: Catalog) -> tuple[np.ndarray, np.ndarray]    # (G, G) distance, (G, G) loci counted
def shared_derived(cat: Catalog) -> np.ndarray                      # (G, G) counts of derived insertions two genomes share
def neighbor_joining(d: np.ndarray, labels: list[str]) -> Node       # unrooted: top node with 3 children (2 for 2 leaves)
def root_on(tree: Node, outgroup: str) -> Node                      # root on the outgroup's branch: (outgroup, rest)
def four_point_ok(dist: np.ndarray, cat: Catalog, r: str, s: str, x: str, d: str) -> bool
    # d(r,s) + d(x,d) < min(d(r,x) + d(s,d), d(r,d) + d(s,x)): x splits with d from r and s (cat: label -> index)
def eligible_fallback(cat: Catalog, x: str, y: str, z: str, dist: np.ndarray) -> tuple[tuple[str, ...], dict[str, str]]
def discover(cat: Catalog, x: str, y: str, z: str, dist: np.ndarray, outgroup: str) -> Counted | None
    # outgroup: "E" (every outgroup E), "not_present" (no outgroup present), "none" (no rule)
@dataclass(frozen=True)
class SisterCall:
    pair: tuple[str, str]; donor: str; counts: dict[str, int]; p_top: float; p_kksc: float; kksc_loci: str
    ambiguous: bool
def trio_sharing(cat: Catalog, genomes: tuple[str, str, str]) -> tuple[dict[str, int], int]   # "x+y" -> count; loci counted
def sister_pair(cat: Catalog, genomes: tuple[str, str, str], dist: np.ndarray) -> SisterCall
def relations(cat: Catalog) -> tuple[list[StatRow], Findings, Node | None, np.ndarray]   # rows, findings, rooted tree, distances
```

**`discover` is the one discovery function** (DESIGN 7.1; review A12). D_pav, the f4-ratio and the identity layer call
it with `outgroup="E"` (DESIGN 7.1: an outgroup must be E). `p_kksc` calls it with `"not_present"` (DESIGN 7.2's
set-aside). The rule goes into `Counted.loci`.
- `disc = (z,)` if z is annotated, else `eligible_fallback`: the annotated ingroup genomes w outside {x, y, z} with
  `four_point_ok(dist, cat, x, y, w, z)`. The others go to `excluded` ("groups with x", "groups with y" or "distance
  unresolved"); terminal-branch effects of annotation depth cancel in each four-point sum. An empty `disc` returns
  `None`, and the caller writes "skipped" with a WARNING naming the excluded genomes and why (builder call 11).
- Per row, `gstar` = z if z is a member there; under fallback, the first eligible genome that is a member there, in
  sheet order.
- `cand` = `gstar >= 0`, `pcls_by(gstar, z) == 1`, and the outgroup rule on `pcls_by(gstar, o)` for every outgroup o.
- `rows` = `cand` with `pcls_by(gstar, x) >= 0` and `pcls_by(gstar, y) >= 0`.
- `loci` = `disc=<disc joined by ,>;present=z;res=x,y;outgroup=<rule>`.

Other rules (every row carries its `loci` declaration):

- **`run_summary`** (test `catalog`, section "Run"):
  - n loci; per genome `resolved_frac` (merged cls >= 0) and whether it is annotated;
  - quotes `qc.tsv`'s `annot_sensitivity` and every `skipped_<reason>` count (DESIGN 7.1, 8); a missing `qc.tsv` is one
    findings line.
- **Distances** (merged states, any discovery):
  - `d(x, y)` = loci where x and y are both resolved and differ (present against E), over loci where both are resolved;
  - every locus counts, outgroups included; `loci` = `disc=any;res=x,y`;
  - rows `distance`, scope `x~y`, statistic `d`, with n.
- **Shared derived insertions** (DESIGN 7.2's pairwise counts), for ingroup x, y:
  - loci present in both, with no outgroup present, and E in at least one other ingroup genome (so not fixed);
  - `loci` = `disc=any;present=x,y;absent=another ingroup genome;outgroup=not_present`;
  - rows `shared_derived`, scope `x~y`, statistic `n`.
- **Tree:**
  - Neighbor joining (Saitou & Nei Q-matrix; ties to the first pair in sheet order; negative branch lengths set to 0) on
    every genome.
  - Rooted on the first outgroup, unrooted without one.
  - Row `tree`, scope `all`, statistic `newick`.
  - Skipped with a findings line when a distance is nan or there are fewer than three genomes.
- **Sharing**, which only picks the sister pair; per trio of ingroup genomes in sheet order:
  - merged states: loci resolved in all three, with no outgroup present (DESIGN 7.2);
  - `n_x+y` = x and y present, the third E;
  - `loci` = `disc=any;res=a,b,c;outgroup=not_present`.
- **Sister pair:**
  - `pair` = the largest count (ties: first pair in sheet order); `donor` = z, the third genome;
  - `p_top` = two-sided `binomtest(n_top, n_top + n_second)`;
  - `ambiguous` when `p_top >= P_WARN`, which also writes a WARNING naming the sister pair.
- **`p_kksc`**, the symmetry the KKSC tests rest on (equal minority counts under lineage sorting):
  - two-sided `binomtest(n_x+z, n_x+z + n_y+z)` on `discover(cat, x, y, z, dist, "not_present")`;
  - n_x+z = `pcls_by(gstar, x) == 1` and `pcls_by(gstar, y) == 0` on its rows; n_y+z the mirror;
  - `kksc_loci` = that `Counted.loci`, or `none` (with `p_kksc` nan) when `discover` returns `None`;
  - the note: it ignores block dependence (nested clusters, linkage), so its p is anti-conservative; the jackknifed D_pav
    is the test of record.

  Rows `sharing`: statistics `n_x+y` for the three pairs, `sister_pair`, `p_top`, `p_kksc` (its own `loci`).
- **Outgroup conflicts:**
  - Per ingroup genome g: among loci where some outgroup is present and g is resolved (merged), the fraction where g is E.
  - Row `outgroup_conflict`, statistic `frac_E`, n, note "an upper bound on the combined rate of ingroup false E and
    outgroup false presence; deep lineage sorting and parallel insertions also give it".

- [ ] **Step 1: Write the failing tests**

```python
D5 = np.array([[0, 5, 9, 9, 8], [5, 0, 10, 10, 9], [9, 10, 0, 8, 7], [9, 10, 8, 0, 3], [8, 9, 7, 3, 0]], float)

def leaf_distances(t: Node, labels: list[str]) -> np.ndarray:
    """Path lengths between leaves on the unrooted tree."""
    edges, stack = {}, [t]
    while stack:
        node = stack.pop()
        for c in node.children:
            edges.setdefault(id(node), []).append((id(c), c.length)); edges.setdefault(id(c), []).append((id(node), c.length))
            stack.append(c)
    leaf = {n.name: id(n) for n in _walk(t) if not n.children}
    def dist_from(a):
        seen, out, todo = {a: 0.0}, {}, [a]
        while todo:
            u = todo.pop()
            for v, w in edges.get(u, ()):
                if v not in seen:
                    seen[v] = seen[u] + w; todo.append(v)
        return seen
    return np.array([[dist_from(leaf[a])[leaf[b]] for b in labels] for a in labels])

def splits(t: Node) -> set[frozenset[str]]:
    """Leaf sets below every inner node."""
    return {n.leaves() for n in _walk(t) if n.children}

def _walk(t):
    yield t
    for c in t.children:
        yield from _walk(c)

def test_nj_recovers_additive_tree():
    t = neighbor_joining(D5, list("abcde"))
    assert leaf_distances(t, list("abcde")) == pytest.approx(D5)
    assert {frozenset("ab"), frozenset("de")} <= splits(t) | {frozenset("abcde") - s for s in splits(t)}

def test_root_on_outgroup():
    t = root_on(neighbor_joining(D5, list("abcde")), "e")
    assert t.leaves() == frozenset("abcde")
    assert {c.leaves() for c in t.children} == {frozenset("e"), frozenset("abcd")} and t.newick().endswith(";")

R_S_SISTER = ([loc(1000 * i, "R:P* S:P D:E O:E") for i in range(1, 13)]          # R+S x12
              + [loc(20_000 + 1000 * i, "R:P S:E D:P* O:E") for i in range(2)]      # R+D x2, D members
              + [loc(30_000, "R:E S:P D:P* O:E")]                                   # S+D x1, D member
              + [loc(40_000 + 1000 * i, "R:P* S:P D:E O:P") for i in range(3)]      # outgroup present x3
              + [loc(50_000, "R:P* S:U D:E O:E")])                                  # S unresolved

def test_sharing_and_sister(tmp_path, toy_fastas):
    cat = write_run(tmp_path, R_S_SISTER, fasta_dir=toy_fastas).load()
    sc = sister_pair(cat, ("R", "S", "D"), pav_distances(cat)[0])
    assert sc.pair == ("R", "S") and sc.donor == "D" and sc.counts == {"R+S": 12, "R+D": 2, "S+D": 1}
    assert sc.p_top == pytest.approx(binomtest(12, 14).pvalue) and not sc.ambiguous          # 0.0129
    assert sc.p_kksc == pytest.approx(1.0) and sc.kksc_loci == "disc=D;present=D;res=R,S;outgroup=not_present"

def test_kksc_reads_the_third_genomes_calls(tmp_path, toy_fastas):
    # sister pair (R, S), donor D: D's own calls are read. One more R+D locus whose merged S is E (R, a member, calls it E)
    # while D's own call into S is U: the merged sharing counts it, p_kksc does not
    loci = R_S_SISTER + [loc(60_000, "R:P* S:E D:P* O:E", calls={("D", "S"): "U"})]
    cat = write_run(tmp_path / "a", loci, fasta_dir=toy_fastas).load()
    sc = sister_pair(cat, ("R", "S", "D"), pav_distances(cat)[0])
    assert sc.pair == ("R", "S") and sc.counts["R+D"] == 3 and not sc.ambiguous             # binomtest(12, 15): 0.035
    assert sc.p_kksc == pytest.approx(binomtest(2, 3).pvalue)                               # n_R+D 2, n_S+D 1
    unannotated_d = [GENOMES[0], GENOMES[1], ("D", "taxD", None, False), GENOMES[3]]
    loci2 = [loc(1000 * i, "R:P* S:P D:E O:E") for i in range(1, 13)] + [loc(30_000, "R:P* S:E D:P O:E")]
    cat2 = write_run(tmp_path / "b", loci2, genomes=unannotated_d, fasta_dir=toy_fastas).load()
    sc2 = sister_pair(cat2, ("R", "S", "D"), pav_distances(cat2)[0])
    assert math.isnan(sc2.p_kksc) and sc2.kksc_loci == "none"

def test_discover_rules(tmp_path, toy_fastas):
    loci = [loc(10_000, "R:P S:E D:P* O:E"), loc(20_000, "R:P S:E D:P* O:U"), loc(30_000, "R:P S:E D:P* O:P"),
            loc(40_000, "R:P* S:E D:P O:E"), loc(50_000, "R:P S:U D:P* O:E")]
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    dist = pav_distances(cat)[0]
    e, np_ = discover(cat, "R", "S", "D", dist, "E"), discover(cat, "R", "S", "D", dist, "not_present")
    assert e.cand.tolist() == [True, False, False, False, True] and e.rows.tolist() == [True, False, False, False, False]
    assert np_.cand.tolist() == [True, True, False, False, True]
    assert e.gstar.tolist() == [2, 2, 2, -1, 2] and e.disc == ("D",)
    assert e.loci == "disc=D;present=D;res=R,S;outgroup=E" and np_.loci.endswith("outgroup=not_present")

def test_sister_tie_warns(tmp_path, toy_fastas):
    loci = ([loc(1000 * i, "R:P* S:P D:E O:E") for i in range(1, 4)]
            + [loc(10_000 + 1000 * i, "R:P* S:E D:P O:E") for i in range(3)])
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    rows, f, tree, dist = relations(cat)
    sc = sister_pair(cat, ("R", "S", "D"), dist)
    assert sc.pair == ("R", "S") and sc.ambiguous
    assert any(t.startswith("WARNING:") and "R+S" in t for _, t in f.items())

def test_outgroup_conflict(tmp_path, toy_fastas):
    loci = ([loc(1000 * i, "R:P* S:P D:P O:P") for i in range(1, 8)] + [loc(9000, "R:E S:P* D:P O:P")]
            + [loc(10_000 + 1000 * i, "R:U S:P* D:P O:P") for i in range(2)])
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    r = next(x for x in relations(cat)[0] if x.test == "outgroup_conflict" and x.scope == "R")
    assert r.value == pytest.approx(1 / 8) and r.n == 8 and "upper bound" in r.note

def test_distances_pairwise_complete(tmp_path, toy_fastas):
    loci = [loc(1000, "R:P* S:P D:E O:E"), loc(2000, "R:P* S:E D:E O:E"), loc(3000, "R:E S:P* D:E O:E"),
            loc(4000, "R:P* S:U D:E O:E")]
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    d, n = pav_distances(cat)
    assert d[cat.g("R"), cat.g("S")] == pytest.approx(2 / 3) and n[cat.g("R"), cat.g("S")] == 3

def test_shared_derived(tmp_path, toy_fastas):
    loci = ([loc(1000 * i, "R:P* S:P D:E O:E") for i in range(1, 4)]
            + [loc(5000 + 1000 * i, "R:P* S:P D:P O:E") for i in range(2)] + [loc(9000, "R:P* S:P D:E O:P")])
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    assert shared_derived(cat)[cat.g("R"), cat.g("S")] == 3

def test_four_point():
    cat = SimpleNamespace(g=["R", "S", "D", "X"].index)
    near_d = np.array([[0, .2, .5, .5], [.2, 0, .5, .5], [.5, .5, 0, .1], [.5, .5, .1, 0]])
    near_r = np.array([[0, .2, .5, .1], [.2, 0, .5, .25], [.5, .5, 0, .5], [.1, .25, .5, 0]])
    assert four_point_ok(near_d, cat, "R", "S", "X", "D")          # 0.3 < 1.0
    assert not four_point_ok(near_r, cat, "R", "S", "X", "D")      # 0.7 > 0.6

def test_run_summary_quotes_qc(tmp_path, toy_fastas):
    cat = write_run(tmp_path, [loc(1000, "R:P* S:E D:P* O:E")], fasta_dir=toy_fastas).load()
    rows, f = run_summary(cat)
    lines = [t for s, t in f.items() if s == "Run"]
    assert any("annot_sensitivity" in t and "0.9" in t for t in lines)
    assert any("skipped_malformed_coordinates 2" in t for t in lines)
    assert next(r for r in rows if r.statistic == "resolved_frac" and r.scope == "S").value == 1.0
```

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_relations.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** the tests. Expected: PASS.
- [ ] **Step 5: Commit.** `"Add relationships: discovery, sharing, tree, sister pairs, outgroup conflicts"`
---

