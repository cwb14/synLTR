### Task 6: GFF3 reader and writer

**Files:** Create `src/ltrpav/annotation/gff3.py`, `tests/test_annot_gff3.py`

**Interfaces:**
- Produces: `load_gff3(path: Path, genome: str) -> tuple[list[Element], Counter]`;
  `write_gff3(elements: list[Element], path: Path) -> None` (LTRquest convention: one `LTR_retrotransposon` line +
  two `long_terminal_repeat` children `ID=<id>.lLTR/.rLTR`; attributes `Name`, `tsd`, `K2P_d`, `family`,
  `superfamily`, `clade`, `confidence`; gzip if the path ends in `.gz`).

- [ ] **Step 1: Write the failing tests.** Use three inline fixtures:
  - **LTRquest convention:** the real host line `B73v5_chr1 ... LTR_retrotransposon 51712 70182 ... ID=B73v5_LTRs_LTRRT_95050;...;tsd=CACCT;K2P_d=0.00340137;...`
    plus its `lLTR 51712-53005` and `rLTR 59462-70182` children.
  - **EDTA convention:** `repeat_region_1` holding `lTSD 60659-60663`, `lLTR 60664-61985`,
    `Copia_LTR_retrotransposon 60664-70130 (ltr_identity=1.0000;tsd=GAGTG;Classification=LTR/Copia;Method=structural)`,
    `rLTR 68826-70130` and `rTSD 70131-70135`, all children of the region (siblings of the element).
  - **EDTA homology fragment:** an `LTR_retrotransposon` line with `Method=homology` and no LTRs.

```python
def test_ltrquest_convention(tmp_path):
    (e,), _ = load_gff3(p, "B73")
    assert (e.start, e.end, e.ltr_left, e.ltr_right, e.tsd) == (51712, 70182, (51712, 53005), (59462, 70182), "CACCT")
    assert abs(e.k - 0.00340137) < 1e-9 and (e.superfamily, e.clade) == ("Copia", "SIRE")

def test_edta_convention_and_fragment(tmp_path):
    els, skipped = load_gff3(p, "B73")
    assert len(els) == 1 and els[0].ltr_right == (68826, 70130) and els[0].tsd == "GAGTG"
    assert els[0].k == 0.0 and els[0].superfamily == "Copia" and els[0].family is None
    assert skipped["no_ltr_pair"] == 1

def test_write_read_round_trip(tmp_path): ...   # write_gff3(els) then load_gff3 returns the same fields
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - An element is any feature whose type ends in `LTR_retrotransposon`.
  - Its LTRs are its `long_terminal_repeat` children, or else `long_terminal_repeat` siblings (same `Parent`) inside
    its span. Skip it unless there are exactly two.
  - `k`: `K2P_d`, else JC69 from `ltr_identity` (`p = 1 - id`; `-0.75*ln(1 - 4p/3)`), else None.
  - Superfamily and clade: the attribute, else split `classification` / `Classification`.
  - `name`: `Name` or `ID`. Read gzip transparently and unescape `%XX`.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add GFF3 reader/writer for LTRquest and EDTA conventions"`.

---

