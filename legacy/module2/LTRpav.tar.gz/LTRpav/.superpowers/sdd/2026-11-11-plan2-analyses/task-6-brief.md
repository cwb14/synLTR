### Task 6: Painting — HMM, tracts, target-decoy q-values, youngest insertion per tract (DESIGN 7.4, 7.5)

**Files:**
- Create: `src/ltrpav/analysis/paint.py`, `tests/test_paint.py`

**Interfaces:**
- Consumes:
  - `Catalog` (`pcls`, `cls`), `Trio`, `InvBlock`, `inside`, `inverted_blocks`, `age_bin`;
  - `StatRow`, `Findings`, `resolution`, `u95`;
  - the analysis constants `PI_MAX`, `BF_TRACT`, `HMM_L_GRID`, `HMM_ITERS`, `HMM_TOL`.
- Produces:

```python
PAINT_CLASSES = ("RD", "RS", "both", "neither", "missing", "old")   # emissions: RD 0, RS 1, the rest -1 (missing data)
POSTERIOR_COLUMNS = ("lid", "seqid", "start", "end", "sister", "donor", "class", "post", "tract", "inv")
TRACT_COLUMNS = ("#chrom", "start0", "end", "name", "score", "strand", "sister", "donor", "n_loci", "n_RD", "n_RS",
                 "mean_post", "sum_post", "q", "p_decoy", "youngest_k", "youngest_u95", "n_identical", "inv_frac")
@dataclass
class HmmFit:
    pi: float; L: float; e0: np.ndarray; e1: np.ndarray; post: np.ndarray; loglik: float
@dataclass
class Tract:
    seq: int; start: int; end: int; first: int; last: int; mean_post: float; sum_post: float   # seq: X's fai index;
                                                                                                # first/last: positions in idx
@dataclass
class Painting:
    trio: Trio; idx: np.ndarray; cls: np.ndarray; post: np.ndarray; inv: np.ndarray      # recipient loci, idx in X order
    fit: HmmFit | None; donor_state: bool; tracts: list[Tract]; q: list[float | None]; p: list[float | None]
    decoy_idx: np.ndarray; decoy_cls: np.ndarray; decoy_post: np.ndarray; decoy_tracts: list[Tract]
    skipped: str | None                                                                  # why nothing was painted
def classes(cat: Catalog, X: str, Y: str, D: str, discovery: str = "recipient") -> tuple[np.ndarray, np.ndarray]
    # (idx: int64 catalog indexes in X's (fai index, start) order, cls: int8 index into PAINT_CLASSES)
def forward_backward(pos: np.ndarray, emit: np.ndarray, starts: np.ndarray, pi: float, lam: float, e0: np.ndarray,
                     e1: np.ndarray) -> tuple[np.ndarray, float, np.ndarray, np.ndarray]
    # numba: post, loglik, c1, c0; starts = each chain's first index plus a final len(pos) sentinel (LTRmix)
def fit_hmm(pos: np.ndarray, emit: np.ndarray, starts: np.ndarray, e0: np.ndarray, e1: np.ndarray) -> HmmFit
def call_tracts(seq: np.ndarray, start: np.ndarray, end: np.ndarray, post: np.ndarray, pi: float) -> list[Tract]
def target_decoy(target: np.ndarray, decoy: np.ndarray, scale: float) -> tuple[np.ndarray, np.ndarray]   # (q, p)
def shortest_callable(fit: HmmFit, spacing: float) -> tuple[tuple[int | None, float | None], tuple[int | None, float | None]]
    # ((loci, bp) lower bound: no flanks; (loci, bp) upper bound: 20 RS loci on each side)
def paint(cat: Catalog, trio: Trio, blocks: list[InvBlock], discovery: str = "recipient",
          self_counts: dict[tuple[str, str], tuple[int, int]] | None = None) -> Painting
    # self_counts: (lid, genome) -> (sites, diffs) from identity.tsv's self rows, when that file exists
def write_paintings(paintings: list[Painting], cat: Catalog, outdir: Path) -> list[Path]
def paint_rows(p: Painting, cat: Catalog) -> tuple[list[StatRow], Findings]
```

Rules:

- **`classes`** (X = target, Y = the other sister, D = donor):
  - Rows are X's members (`discovery="recipient"`).
  - Y's, D's and the outgroups' states are X's own calls (`pcls(X, ·)`). Class, checked in this order: `old` (some
    outgroup present); `missing` (Y or D unresolved); then `RD` (D present, Y E), `RS` (Y present, D E), `both`,
    `neither`.
  - The `"any"` variant takes loci with merged `cls(X) == 1` and keeps `loci.tsv`'s merged states, and says so in its
    `loci` declaration. It is DESIGN 7.1's simulation-only alternative, the one Plan 3 tests under one-sided dropout,
    and is never exposed on the command line.
- **`forward_backward`:** port LTRmix `_fb_cat` (l. 936): bp-distance switching `q = exp(-lam * d)`, `p01 = pi(1 - q)`,
  `p10 = (1 - pi)(1 - q)`, missing emission 1, a chain restarting at each `starts` boundary. Return the posterior of
  state 1 and the expected emission counts.
- **`fit_hmm`:** port `fit_hmm_cat` (l. 999). Start at pi 0.1, L 1e5. Each round scans `np.geomspace(*HMM_L_GRID)` for the
  best log-likelihood, then updates `e1 = (c1 + 0.5) / Σ`, `e0 = (c0 + 0.5) / Σ` and
  `pi = clip(mean post of emitting loci, 1e-4, PI_MAX)`. Stop at `HMM_TOL` or `HMM_ITERS`.
- **Initial emissions** (LTRmix `_hmm`): `e0` = the decoy's class frequencies + 1 (the target's own if there is no
  decoy); `e1 = e0 * (5, 0.2)`, normalized.
- **`donor_state`:** `e1[0] > e0[0]`. Without it, no tracts are called.
- **Tract length:**
  - L, the switch scale, is reported as `mean_tract_bp`: LTRmix's name and quantity (its `mean_tract_bp = Lh`).
  - The mean donor-like run under the model, `L / (1 - pi)` (the rate out of state 1 is `(1 - pi) / L`), is reported
    as `mean_donor_run_bp`.
- **`call_tracts`:** maximal runs, on one sequence (fai index), of loci with post > 0.5 and post/(1 - post) >=
  `BF_TRACT` × pi/(1 - pi). Bounds: X's start of the first locus and end of the last.
- **Decoy** (DESIGN 7.4, LTRmix):
  - S's loci under the same `discovery` (its members, classed by S's own calls `pcls(S, ·)` with X = S and Y = R, or
    S-present loci under `"any"`);
  - painted with the fitted parameters unchanged; decoy tracts use the same rule.
- **`target_decoy`:** port LTRmix's q (l. 1359-1375). Scores are each tract's `sum_post`.
  - `raw = ((#decoy >= x) * scale + 1) / #target >= x`;
  - `q` = the smallest raw at or below the tract's score, capped at 1;
  - `p = (1 + #decoy >= x) / (1 + #decoy)`;
  - `scale = n informative(R) / n informative(S)`.

  With S unannotated there is no decoy: q and p are written `none`, with a WARNING.
- **`shortest_callable`**, at the median informative spacing (consecutive RD/RS loci on one sequence):
  - The lower bound is the fewest consecutive RD loci, with no flanks, whose middle locus (index k // 2) passes the tract
    rule. Missing flanks would change nothing, because the chain is stationary across missing loci.
  - The upper bound is the same with 20 RS loci on each side.
  - For each, bp = k × spacing; k is tried from 1 to 200, and None past 200.
- **Per tract:**
  - `youngest_k` = min K of X's copy (the annotation's K2P) over the tract's RD loci, `.` without any. The admixture is
    younger than any insertion it transferred.
  - `youngest_u95`, from exact counts only:
    - it exists only when the identity layer (Task 9, `--identity`) has written `identity.tsv`. `paint` takes its self
      rows as `self_counts`; without them, the column is `.` (no K-based stand-in);
    - with them, it is the min over the tract's RD loci of `u95(diffs, sites)` (Task 2), taken from X's own copy, else
      from the donor's copy of the same insertion (also a self row; either dates it);
    - loci without a self row are left out.
  - `n_identical` = RD loci with K == 0.
  - `inv_frac` = the share of loci inside an inverted block of X against Y or D (`inside`, with X's fai indexes).
  - Posterior rows carry the same `inv` flag. The fit itself is unchanged by inverted blocks (DESIGN 7.7 flags only).
- **Skips** (`Painting.skipped`):
  - X unannotated under `"recipient"`;
  - no RD or no RS locus.
- **`write_paintings`:**
  - removes old `tracts.*.bed`, `posterior.*.tsv`, `decoy_tracts.*.bed` and `decoy_posterior.*.tsv` first;
  - writes one `tracts.<R>.bed` and `posterior.<R>.tsv` per recipient, and one `decoy_*.<S>` per sister, all trios
    included, ordered by trio scope then position;
  - BED is 0-based; name `<D>-like`; score `min(1000, int(1000 * mean_post))`; strand `.`; seqid names from
    `cat.seqids` (output only).
- **`paint_rows`** (test `paint`, scope = trio):
  - Statistics: `pi`, `mean_tract_bp` (= L), `mean_donor_run_bp` (= L/(1 - pi)), `donor_state`, `loglik`,
    `n_informative`, `n_RD`, `n_RS`, `posterior_mean`, `decoy_posterior_mean`, `excess` (their difference),
    `n_tracts`, `n_decoy_tracts`, `n_tracts_q05`, `spacing_median`, `spacing_mean`, `shortest_callable_loci_lo`,
    `shortest_callable_bp_lo`, `shortest_callable_loci_hi`, `shortest_callable_bp_hi`, `n_inv_loci`.
  - Posterior means are taken over loci, unweighted.
  - Resolution: `resolution("paint_resolution", scope, {"S": ..., "D": ...}, ...)` over X's loci from X's own calls.
  - Rows `paint_seqid`, one per X sequence (stratum = its name): `posterior_mean`, `n_RD`, `n_RS`, `class_share`
    (RD/(RD+RS)).
  - The "Dating" findings give the median `youngest_k` over tracts and the number of tracts holding an identical-LTR RD
    insertion. Two caveats go with them: K = 0 is not age 0, and LTR-LTR gene conversion (40% of maize elements, lit
    review) makes K too young, so the bound can be too recent. Without any K: one line "youngest insertion per tract
    skipped: no K2P". `youngest_u95` gets its own line only with `identity.tsv`.

- [ ] **Step 1: Write the failing tests**

```python
TOTAL = sum(b - a + 1 for _, a, b in TRACTS)

def enumerate_paths(pos, emit, pi, lam, e0, e1):
    """Brute force over the 2**n state paths of one chain: posterior of state 1 and log-likelihood."""
    n, tot, p1 = len(pos), 0.0, np.zeros(len(pos))
    for path in itertools.product((0, 1), repeat=n):
        w = pi if path[0] else 1 - pi
        for t in range(1, n):
            q = math.exp(-lam * (pos[t] - pos[t - 1])); p01, p10 = pi * (1 - q), (1 - pi) * (1 - q)
            w *= (p01 if path[t] else 1 - p01) if path[t - 1] == 0 else (1 - p10 if path[t] else p10)
        for t, k in enumerate(emit):
            if k >= 0:
                w *= (e1 if path[t] else e0)[k]
        tot += w; p1 += w * np.array(path)
    return p1 / tot, math.log(tot)

def covered_bp(tracts, cat, truth):
    """bp of the truth intervals (R seqid name, a, b) covered by called tracts on the same R sequence."""
    return sum(max(0, min(b, t.end) - max(a, t.start) + 1) for name, a, b in truth for t in tracts
               if cat.seqids["R"][t.seq] == name)

def test_forward_backward_matches_enumeration():
    pos = np.array([0.0, 5e4, 6e4, 3e5]); emit = np.array([0, 1, -1, 0])
    e0, e1 = np.array([0.3, 0.7]), np.array([0.8, 0.2])
    post, ll, c1, c0 = forward_backward(pos, emit, np.array([0, 4]), 0.2, 1 / 1e5, e0, e1)
    exp_post, exp_ll = enumerate_paths(pos, emit, 0.2, 1 / 1e5, e0, e1)
    assert np.allclose(post, exp_post, atol=1e-9) and ll == pytest.approx(exp_ll, abs=1e-9)

def test_tract_rule():
    tr = call_tracts(np.zeros(6, dtype=int), np.arange(6) * 1000 + 1, np.arange(6) * 1000 + 500,
                     np.array([0.9, 0.95, 0.4, 0.8, 0.99, 0.6]), pi=0.5)     # prior odds 1: post >= 0.75
    assert [(t.first, t.last) for t in tr] == [(0, 1), (3, 4)]

def test_target_decoy_plus_one():
    q, p = target_decoy(np.arange(30, 0, -1.0), np.array([5.5]), 1.0)
    assert np.allclose(q[:25], 1 / 25) and np.allclose(q[25:], 2 / 30)
    assert p[0] == pytest.approx(0.5) and p[-1] == pytest.approx(1.0)
    assert target_decoy(np.array([10.0]), np.array([1.0, 2.0]), 1.0)[0][0] == 1.0   # a lone target is not significant

def test_classes(tmp_path, toy_fastas):
    loci = [loc(1000, "R:P* S:E D:P O:E"), loc(2000, "R:P* S:P D:E O:E"), loc(3000, "R:P* S:P D:P O:E"),
            loc(4000, "R:P* S:E D:E O:E"), loc(5000, "R:P* S:U D:P O:E"), loc(6000, "R:P* S:E D:P O:P"),
            loc(7000, "R:P* S:E D:P* O:E", calls={("R", "S"): "U"})]          # merged S E (D's call); R's own call U
    cat = write_run(tmp_path, loci, fasta_dir=toy_fastas).load()
    idx, cls = classes(cat, "R", "S", "D")
    assert idx.tolist() == list(range(7))
    assert [PAINT_CLASSES[c] for c in cls] == ["RD", "RS", "both", "neither", "missing", "old", "missing"]

def test_paint_finds_tracts(tmp_path, toy_fastas):
    cat = simulate_run(tmp_path, seed=1, tracts=TRACTS, fasta_dir=toy_fastas).load()
    p = paint(cat, Trio("R", "S", "D", False), [])
    assert p.donor_state and covered_bp(p.tracts, cat, TRACTS) >= 0.8 * TOTAL and len(p.decoy_tracts) < len(p.tracts)

def test_paint_null_and_positive_control(tmp_path, toy_fastas):
    null = paint(simulate_run(tmp_path / "n", seed=1, fasta_dir=toy_fastas).load(), Trio("R", "S", "D", False), [])
    assert sum(q is not None and q < 0.05 for q in null.q) == 0
    assert null.post.mean() < null.decoy_post.mean() + 0.05        # the fitted proportion stays at the decoy's level
    cat = simulate_run(tmp_path / "a", seed=1, tracts=TRACTS, fasta_dir=toy_fastas).load()
    adm = paint(cat, Trio("R", "S", "D", False), [])                # positive control: known tracts recovered
    assert covered_bp(adm.tracts, cat, TRACTS) >= 0.8 * TOTAL and adm.post.mean() > adm.decoy_post.mean() + 0.05

def test_outputs(tmp_path, toy_fastas):
    run = simulate_run(tmp_path, seed=1, tracts=TRACTS, inversion=("S", "chr2", 300_001, 700_000),
                       fasta_dir=toy_fastas)
    cat = run.load(); blocks = inverted_blocks(cat)
    p = paint(cat, Trio("R", "S", "D", False), blocks)
    write_paintings([p], cat, run.outdir)
    post = read_tsv(run.outdir / "posterior.R.tsv")
    assert len(post) == cat.member[:, cat.g("R")].sum() and {r["class"] for r in post} <= set(PAINT_CLASSES)
    beds = read_tsv(run.outdir / "tracts.R.bed")
    t = p.tracts[0]
    assert int(beds[0]["start0"]) == t.start - 1 and int(beds[0]["end"]) == t.end and beds[0]["youngest_u95"] == "."
    rd = [p.idx[i] for i in range(t.first, t.last + 1) if PAINT_CLASSES[p.cls[i]] == "RD"]
    assert float(beds[0]["youngest_k"]) == pytest.approx(min(cat.k[i, cat.g("R")] for i in rd))
    (blk,) = [b for b in blocks if {b.x, b.y} == {"R", "S"}]
    flagged = {cat.lid[i] for i in p.idx if cat.seq[i, cat.g("R")] == blk.seq_x
               and blk.start_x <= cat.start[i, cat.g("R")] <= blk.end_x}
    assert {r["lid"] for r in post if r["inv"] == "1"} == flagged and flagged
    assert (run.outdir / "decoy_tracts.S.bed").is_file() and (run.outdir / "decoy_posterior.S.tsv").is_file()

def test_no_decoy_without_sister_annotation(tmp_path, toy_fastas):
    genomes = [GENOMES[0], ("S", "taxS", None, False), GENOMES[2], GENOMES[3]]
    loci = ([loc(1000 * i, "R:P* S:E D:P* O:E") for i in range(1, 40)]
            + [loc(50_000 + 1000 * i, "R:P* S:P D:E O:E") for i in range(40)])
    run = write_run(tmp_path, loci, genomes=genomes, fasta_dir=toy_fastas)
    cat = run.load(); p = paint(cat, Trio("R", "S", "D", True), [])
    write_paintings([p], cat, run.outdir); _, f = paint_rows(p, cat)
    beds = read_tsv(run.outdir / "tracts.R.bed")
    assert len(beds) >= 1 and all(b["q"] == "none" and b["p_decoy"] == "none" for b in beds)
    assert any(t.startswith("WARNING:") and "decoy" in t for _, t in f.items())

def test_tracts_without_k(tmp_path, toy_fastas):   # Review Focus 2
    run = simulate_run(tmp_path, seed=1, tracts=TRACTS, k_known=False, fasta_dir=toy_fastas)
    cat = run.load(); p = paint(cat, Trio("R", "S", "D", False), [])
    write_paintings([p], cat, run.outdir); _, f = paint_rows(p, cat)
    assert p.tracts and {b["youngest_k"] for b in read_tsv(run.outdir / "tracts.R.bed")} == {"."}
    assert sum("youngest insertion per tract skipped" in t for s, t in f.items() if s == "Dating") == 1

def test_paint_many_scaffolds(tmp_path, toy_fastas):   # Review Focus 4
    seqids = ("chr1",) + tuple(f"scaf{i:03d}" for i in range(300))
    loci = ([loc(1000 * i, "R:P* S:E D:P O:E") for i in range(1, 60)]
            + [loc(70_000 + 1000 * i, "R:P* S:P D:E O:E") for i in range(60)]
            + [loc(1001, "R:P* S:E D:P O:E" if i % 2 else "R:P* S:P D:E O:E", seqid=f"scaf{i:03d}") for i in range(300)])
    cat = write_run(tmp_path, loci, seqids=seqids, seq_len=5_000, seq_lens={"chr1": 200_000},
                    fasta_dir=toy_fastas).load()
    p = paint(cat, Trio("R", "S", "D", True), [])
    assert p.skipped is None and len(p.idx) == 419 and np.isfinite(p.post).all()
    assert all(t.start <= t.end and t.first <= t.last for t in p.tracts)  # one-locus chains give well-formed tracts

def test_shortest_callable():
    fit = HmmFit(pi=0.1, L=1e5, e0=np.array([0.1, 0.9]), e1=np.array([0.9, 0.1]), post=np.zeros(0), loglik=0.0)
    assert shortest_callable(fit, 5000.0) == ((2, 10_000.0), (4, 20_000.0))   # the re-review's recomputation
```

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_paint.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified. `forward_backward` is `@njit(cache=True)`, as in `chain.py`.
- [ ] **Step 4: Run** the tests. Expected: PASS.
- [ ] **Step 5: Commit.** `"Add painting HMM with target-decoy q-values"`
---

