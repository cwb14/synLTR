"""Test hap_truth.py on a synthetic haplotype pair with planted states (needs minimap2 in PATH).
Run: pytest benchmark/test_hap_truth.py"""
import os
import random
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "tests"))
from synth import rand_seq, make_family, make_copy, build_hap, write_gff, mutate  # noqa: E402


def test_states(tmp_path):
    rng = random.Random(3)
    fam = make_family(rng, 500, 5000)
    A = rand_seq(rng, 400000)
    cp = lambda: make_copy(rng, fam, 0.003)
    ev = [dict(id="full", p=30000, copy=cp(), fam="f", state={"h1": "F", "h2": "F"}),
          dict(id="empty", p=80000, copy=cp(), fam="f", state={"h1": "F", "h2": "E"}),
          dict(id="solo", p=130000, copy=cp(), fam="f", state={"h1": "F", "h2": "S"}),
          dict(id="deleted", p=200000, copy=cp(), fam="f", state={"h1": "F", "h2": "X"}, xdel=(196000, 212000)),
          dict(id="replaced", p=290000, copy=cp(), fam="f", state={"h1": "F", "h2": "F"})]
    ann = []
    h1 = build_hap(A, ev, "h1", ann, "chr1")
    h2 = build_hap(A, ev, "h2")
    # replace 8 kb around the 'replaced' element on hap2 with unrelated sequence
    r = next(a for a in ann if a["id"] == "replaced")
    i = h2.find(h1[r["s"] - 3000:r["s"] - 2000])
    j = h2.find(h1[r["e"] + 2000:r["e"] + 3000])
    assert i > 0 and j > i
    h2 = h2[:i + 1000] + rand_seq(rng, 9000) + h2[j:]
    h2 = mutate(rng, h2, 0.005)              # haplotype divergence
    for name, s in (("h1", h1), ("h2", h2)):
        with open(tmp_path / f"{name}.fa", "w") as fh:
            fh.write(f">chr1\n{s}\n")
    write_gff(tmp_path / "h1.gff3", ann)
    subprocess.run(f"minimap2 -cx asm20 --eqx --secondary=no {tmp_path}/h2.fa {tmp_path}/h1.fa "
                   f"> {tmp_path}/aln.paf 2>/dev/null", shell=True, check=True)
    subprocess.run([sys.executable, os.path.join(HERE, "hap_truth.py"), "--paf", str(tmp_path / "aln.paf"),
                    "--gff", str(tmp_path / "h1.gff3"), "-o", str(tmp_path / "t.tsv")], check=True)
    rows = [ln.rstrip("\n").split("\t") for ln in open(tmp_path / "t.tsv")]
    hdr = rows[0]
    st = {x[0]: x[hdr.index("state")] for x in rows[1:]}
    assert st == {"full": "F", "empty": "E", "solo": "S", "deleted": "Nd", "replaced": "Nr"}, st
