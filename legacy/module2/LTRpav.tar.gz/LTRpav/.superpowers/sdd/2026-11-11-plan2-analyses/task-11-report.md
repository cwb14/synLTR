# Task 11 report: the overview figure and ltrpav-plot

Status: DONE_WITH_CONCERNS (concerns at the end; none blocks Task 12)
Branch plan2-analyses, base 84c909e. Commits:
- 2c12cc9 Add the overview figure and ltrpav-plot
- 9d717af Set the overview's math text in the figure's sans font
- 65c7467 Share one D axis across the trio small multiples; set every math font

Tests: `python -m pytest -W error -m "not slow"` on 65c7467: 1098 passed, 2 deselected (257 s); tests/test_overview.py has 15
tests (the brief's 6, one edited for -W error, plus 9).
ruff check . clean.

## main3 outputs (read-only view of benchmark_pav/main3; main3 and inputs/ untouched)

- /data2/chris/maize_introgression/benchmark_pav/plan2_figure/run/overview.png (2125 x 2558 px, 300 dpi, 180 x 217 mm)
- /data2/chris/maize_introgression/benchmark_pav/plan2_figure/run/overview.pdf (3 pages: figure; short legend 230 words;
  long legend 1,051 words; text searchable; fonts Liberation Sans/Mono, TrueType, fonttype 42)
- /data2/chris/maize_introgression/benchmark_pav/plan2_figure/run/overview_numbers.tsv (93 rows; every value appears
  verbatim in the legend text; every source file exists in the run)
- memo with commands, layouts, render rounds and the figure check: /data2/chris/maize_introgression/benchmark_pav/plan2_figure/memo.md
- cost: ltrpav-plot 49 s the first time (FASTA checksums for the key, cached), 27 s after a code change, 12 s when it
  skips; 0.87 GB peak.

## Panels (main3)

- A (lead): B73's 10 chromosomes to scale, each above its TIL01 counterpart painted the same way (the decoy, same bp
  scale); every informative insertion a tick (R+D vermillion above: 2,699 vs 1,495 in the decoy, 36% vs 24% of
  informative insertions; R+S blue below); bar colored by the posterior of TIL18-like ancestry per 1-Mb bin, hatched
  without an informative insertion; tracts on the bar's edge (770 vs 599; none black: no q <= 0.05); dense inverted
  blocks as gray bands.
- B: the typical tract B73v5_chr4:105,323,764-105,761,185 (437 kb, 27 loci, 2 R+D, q 0.72) +- one tract length,
  every insertion a box in B73, TIL01, TIL18, Zd (present filled, empty site open, missing hatched), posterior above.
- C: insertion L0116159 at base-pair scale: flanks, identical TSD copies GGAAC and LTR ends in B73 and TIL18, TIL01's
  empty site with one TSD copy; element cartoon to scale.
- D: what an absence is: the 69,697 absences of B73 insertions from TIL01 by class and age (empty sites 38%: 53% of
  the youngest, 32% of the oldest; derived share between 1.2% and 62%), other ingroup pairs as context.
- E: the three sharing counts (5,392 sisters, 3,097 B73+TIL18, 1,828 TIL01+TIL18) with equal minority counts drawn.
- F: D_pav +0.29 (95% +0.21 to +0.37, Z 7.4) and by age (K = 0 +0.60, 0<K<0.01 +0.61, K >= 0.01 +0.20; gradient Z
  3.1) and the three checks, D = 0 drawn, n_R+D/n_S+D shown.
- G: mean posterior per chromosome pair, TIL01 decoy -> B73 (B73 higher on 10 of 10; 0.317 vs 0.370, excess +0.053).
- (H every trio as small multiples on one shared D axis; drawn only with more than one trio.)

Headline (short legend): of the insertions TIL18 shares with only one sister, B73 carries 1.8 times as many as
TIL01, most of all among young insertions: gene flow from TIL18-like donors into B73, not lineage sorting; in B73's
genome this ancestry is thin and diffuse, not in distinct tracts. The figure shows the null painting result
honestly: the decoy rows look much like B73's, and no tract is drawn as significant.

## Layout and example

Three layouts sketched (memo.md): 1 "browser stack" (chosen), 2 "karyogram" (vertical chromosome pairs, fig1
style), 3 "signature first" (tree with arcs). Layout 1 because its horizontal tracks zoom straight down A -> B -> C,
it puts the decoy directly under each recipient chromosome at the same bp scale, and it keeps every informative
insertion visible; layout 2 crowds 20 tracks into ~8-mm columns, layout 3 opens off genome coordinates. Signature
view: panel B's genotype matrix (every insertion x four genomes on the backbone's axis).

Example: the tract nearest the medians of loci (26) and length (440 kb) by mid-rank percentile distance (q <= 0.05
tracts first: none), tracts taken in that order until one holds a clean R+D insertion; in it, the clean insertion
with K nearest the median K of all 2,699 R+D insertions (0.0202). Clean: D's call high-tier or annotated, S's E call
with tsd_match (read from pairs/B73__TIL01), R's TSD known; from the FASTAs: R's two TSD copies identical and equal
to the annotated TSD, TG...CA in R, both LTRs whole (shorter >= 0.9 x longer), length inside the family's IQR (the
superfamily's below 10 elements), D's copy with the same TSDs and TG...CA, S's single TSD copy identical and its
flanks >= 90% identical to R's over 20 bp. The first 7 tracts held no clean candidate (e.g. L0067814: TIL01's TSD
copy AAACC against AAACT and diverged flanks; L0129545: non-identical TSD copies); the 8th gave L0116159 (9,528 bp,
K 0.0065; flanks 19/20 and 20/20); 13 candidates screened. The rule and these counts are on the long legend page.

## Figure check (figure agent; the independent check is Task 12's)

1. Panel A shows the biology in genome coordinates, every element drawn: yes (A, B).
2. Raw evidence for a real, typical, structurally verified example: yes (C base-pair alignment; B per-site calls).
3. Control drawn as a full partner at the same scale: yes (A decoy rows; G).
4. Every null drawn: yes (F D = 0; E equal minority counts; A/G the decoy painting; D is a composition, other pairs
   as context).
5. On-figure text only letters, axis labels, ticks, direct labels, keys, n: yes.
6. Crops clean, one grid, reading order, no empty bands: yes (five render-inspect rounds on main3, plus toy runs).
7. Each panel answers a different question; legend pages follow the rules: yes.

## Departures from the brief (skill or data)

- Tracts are not labeled with q on the figure (skill: no statistics on the figure): a tract at q <= 0.05 is black
  with a mark; the example tract's q and the smallest q are on the long legend page.
- The posterior in A is the bar's color (a painted chromosome), not a separate thin line: the line read as noise at
  whole-chromosome scale (round 1); same per-bin values, one layer. B keeps the posterior as a line track.
- Letters follow layout 1's reading order (A genome, B tract, C bp, D absences, E sharing, F D_pav, G posterior per
  pair, H trios); G (posterior excess over the decoy per chromosome) is added as the painting's quantification.
- D shows one pair (R's insertions in S) by age, the other ingroup pairs as all-age context ticks.
- Inverted blocks: drawn only where their loci average >= 1 per display bin (a display-resolution rule); the 49 sparse
  ones are counted, with the largest, in the long legend.
- Brief test code: `PIL.Image.open(png).info` wrapped in `with` (an unclosed file fails under -W error); the six tests
  are otherwise as given. Added 9 tests: every number in the legends (with and without painting, and the two-genome
  case), no painting, --trio, the plot stage's marker and skip, missing stats.tsv (exit 1), a figure error inside
  `ltrpav run` is one WARNING, a real-sequence toy that yields a verified base-pair example, and the sequence readers.
- `overview(...)` has a keyword-only `cat=` so the plot stage reuses the loaded catalog.
- ltrpav/cli.py: help text only (ltrpav-plot named twice); it is in no stage key.
- The plot stage's key: analysis_fingerprint("plot"), the paint stage's inputs, stats.tsv, findings.txt,
  inversions.tsv, mechanisms.tsv, identity.tsv and the painting files that exist, and every FASTA's checksum (the
  base-pair panel reads sequence; "absent" when a FASTA is gone, which only omits panel C). ltrpav-plot runs only the
  plot stage; without stats.tsv it exits 1 ("error: no stats.tsv ..."); in `ltrpav run` any plot error is one WARNING.

## Concerns

1. Inversion caller (Task 5): on TIL01's side 49 blocks of 5-19 loci span tens of Mb up to 278 Mb, many between
   non-syntenic chromosomes (scattered or paralogous loci chained into "reversed runs"); 31,473 of TIL01's 136,308
   decoy loci are flagged inv only by them (B73's 14,527 flags all come from dense blocks). No statistic uses the
   flags, but inversions.tsv and the decoy's inv column overstate inversions. Candidate fix for the final wave:
   blocks only within dominant syntenic sequence pairs, with comparable spans on both genomes.
2. Heuristics named in the module (example checks and display only, no statistic depends on them): FLANK_CHECK 20,
   FLANK_IDENT 0.9, LTR_RATIO 0.9, FAMILY_MIN 10, BINS 250, and the inverted-block display rule.
3. The plot key checksums every FASTA (8.7 GB on main3, ~25 s once, cached); a run directory that cannot write
   work/checksums.json would rehash them on every ltrpav-plot.
4. The long legend is ~1,050 words (target ~1,000); panel A's paragraph is the longest (~200 words).

## Not done

- The independent figure check (Task 12, by a reviewer who did not make the figure).
- H (every trio) is checked only on a toy with four ingroup genomes (render-inspected: four small multiples on one
  shared D axis); main3 has one trio, and no unit test asserts H.

## Figure round 1 (task-11-figure-fixes-1.md)

Commit 3b9352a "Overview round 1: one color system, the control's posteriors beside panel B, plain caveats".
Tests: `python -m pytest -W error -m "not slow"`: 1102 passed, 2 deselected (279 s); ruff clean. New tests: F4 plain
warnings, F5 open-points sentence in both cases (2), F9 every trio.
Re-rendered on the same read-only main3 view: overview.png 2125 x 2605 px (180 x 220 mm, 300 dpi); short legend 239
words, long legend 1,142; overview_numbers.tsv 99 rows, each verbatim in the legends, every source file in the run.
Crops inspected (B's right column, C/D boundary, A's zoom letter, right edges measured), toys re-rendered (two
genomes, 300 scaffolds, no painting, real-sequence example, four trios). memo.md holds the figure check again.

- F1: E is now R+S blue, R+D filled vermillion, S+D open vermillion (the decoy's class); G's decoy points are open
  vermillion too; H uses no class colors.
- F2: the alternative form, with the reason: the band of decoy tracts' mean posteriors (middle half 0.79-0.86)
  would have put the example tract (mean posterior 0.92, 96th percentile of decoy tracts) above it and made it
  look exceptional against its own q of 0.72 (ranked on summed posterior). Beside B's posterior track, on its axis:
  the posterior of every painted insertion genome-wide in bins of 0.1, B73 against the decoy (posterior >= 0.9:
  10.2% vs 5.0%). Track taller (11 mm); no percentile line; "no control drawn" without a decoy.
- F3: C's legend states "Only 1 of the 13 R+D insertions screened in that order passed every check, so the example
  comes from a small clean subset; commonest failures: recipient's TSD copies not identical (3), length atypical of
  its family (2), sister's empty site without a matching TSD (2)"; rows C_passed, C_fail_1-3; same in memo.md.
- F4: caveats carry only warnings on drawn comparisons, in plain words (resolution symmetry of the D_pav count,
  painting or donor-read sharing counts, naming the panel); the rest are counted: main3 "1 further warning is
  listed with the run's findings". Test: planted warnings with stage, metric and file names never reach the legend.
- F5: "Open points: not testable ..." only when F (or H) draws one; absent on main3; tested both ways.
- F6: key "S sister TIL01 (parviglumis), the decoy" and "tract, q <= 0.05 (none)".
- F7: D's row "cut inside, remnant not shown", legend "or with the remnant not shown".
- F8: "B" above its box in the gap between rows, on a white backing (to the box's right on a column's first row,
  under the key); A, B and D data areas end at one edge (176 mm, measured); D's label column widened so it clears C.
- F9: test_overview_every_trio: a four-ingroup toy renders H, one D_pav number row per trio.
- Rulings applied: group names as the sheet gives them (memo notes the user italicizes for publication); the sparse
  inverted blocks stay for Plan 2's final wave.

New numbers (main3): B_high_target 10.2%, B_high_decoy 5.0%, C_passed 1 (of C_screened 13), C_fail_1-3 = 3, 2, 2,
warnings_other 1; the verbatim warning row is gone.
Not done: nothing from the list.

## Fix round 1 (task-11-review.md; rulings task-11-fix-1.md)

Commits: f1d27b2 "Name the target-decoy q cutoff Q_TRACT" (analysis/constants.py, paint.py: the same 0.05, now
named, so the figure can import it); 1b0ee8f "Overview fix round 1: verdicts from their statistics, typical tracts
on what panel B draws, current paintings only" (overview.py, report.py, tests).
Tests: `python -m pytest -W error -m "not slow"`: 1116 passed, 2 deselected (315 s); ruff clean. tests/test_overview.py
holds 33 tests. The reviewer's probe scripts are now fixtures (`_probe_run`: normal, swapped, stale_paint,
no_outgroup, d_unannotated, scaffolds).
Re-rendered on the main3 view (stats, paint and plot rerun; D_pav unchanged +0.290544, Z 7.42). Crops of B and C and
both legend pages inspected; memo.md holds the example and the figure check again.

- I1 fixed (1b0ee8f). One verdict helper `_direction` on Z_SIG (D_pav, the gradient, each check) and `_compare`
  for descriptive comparisons, which are always stated with both numbers. The headline and the short legends of
  A, D, E, F and G branch on these:
  - D_pav: up / down ("S, not R, ... points against the roles, which were set by the user") / none (no evidence) /
    untestable (with trio.py's reason in plain words) / missing (why the counted set is empty);
  - the gradient: young, old, no clear difference, untestable;
  - checks: "holds in k of n checks (not ...)";
  - shares, frac_E, counts, means: direction words with both numbers.
  Tests: test_verdicts_follow_their_statistics, test_discovery_and_outgroup_wording.
- I2 fixed (1b0ee8f). B now says: "...10.2% of B73's insertions and 5.0% of the decoy's: plateaus this high also
  occur in the sister's control painting (roles swapped), about half as often; the tract's q weighs this one
  against the decoy's tracts". The ratio words come from the two printed numbers.
  - The sentence depends on a decoy painting, a drawn tract and a decoy share above 0.
  - With a 0% share it says "never reaches 0.9"; when only the decoy reaches 0.9, it says the control reaches it
    and R never does.
  - The selection text says a verified insertion was found only when one was. Otherwise: "no tract held a
    structurally verified R+D insertion (n screened in k tracts), so the window is the first tract".
  - The docstrings were changed to match.
  Tests: the probe tests (the toy decoy's 0% path).
- I3 fixed (1b0ee8f). Tracts are ranked by mid-rank distance from the medians of loci, length and mean posterior,
  and taken in that order until one holds a clean R+D insertion. The long legend states the tract's three
  percentiles among R's tracts, and its mean posterior's percentile among the decoy's tracts. "Typical" is printed
  only when all three percentiles lie within 25-75. main3 changed:
  - tract: B73v5_chr3:139,704,026-140,123,941 (2nd examined; 420 kb, 27 loci, 3 R+D, mean posterior 0.83, q 0.75);
    percentiles among B73's tracts: loci 53, length 47, mean posterior 51; decoy 61;
  - insertion: L0089444 (B73v5_chr3:139,963,278-139,972,720, 9,443 bp, K 0.0100, TSD ATTAC, flanks 20/20 and
    20/20); 1 of 4 screened passed, the other 3 failing on length atypical of their family.
- I4 fixed (1b0ee8f). A painting is drawn only when stats.tsv holds the trio's paint rows. Otherwise the classes
  are drawn, and the legend says "There is no current painting for this trio, so no posterior or tract is drawn".
  A painting file whose lids are no longer in loci.tsv also counts as not current.
  Tests: test_stale_painting_is_not_drawn, and test_no_missing_value_reaches_a_legend[stale_paint].
- I5 fixed (1b0ee8f). The donor-read counts are mapped by label (`_pair_counts`).
  Test: test_kksc_counts_map_by_label (the recipient follows its sister in the sheet).
- I6 fixed (1b0ee8f). F names the discovering genome from the D_pav row's `disc=` field, with "(fallback
  discovery: D has no annotation)" when it applies. The outgroup clauses appear only with an outgroup.
  Test: test_discovery_and_outgroup_wording[d_unannotated, no_outgroup].
- No None, nan or inf reaches a legend (1b0ee8f). One formatter, `_fmt`, returns None for missing or non-finite
  values, and their clauses are dropped. The old "nan" formatters were removed.
  Test: test_no_missing_value_reaches_a_legend (6 probe paths, both pages and the numbers table).
- M1 fixed: tokens wider than the line break after "/" or "_" (characters as the last resort).
  Test: test_long_paths_wrap (a 150+-character path).
- M2 fixed:
  - "roles as given by the user", "unless the user named it";
  - no command or file names;
  - the no-example note uses the plain check labels and "X's genome sequence";
  - no title on the no-trio figure (its sentence is on the legend page).
- M3 fixed: Z_SIG, BF_TRACT and Q_TRACT are imported, with no literal thresholds left in overview.py's logic or
  text.
- M4 fixed:
  - R's own TSD (`e.tsd`) is used, not `Catalog.tsd`;
  - the failure labels are split into "recipient's TSD copies differ", "... differ from the annotated TSD" and
    "sequence ends";
  - re-rendered: the clean subset is 1 of 4.
- M5 fixed: the lid index is cached on the catalog object.
- M6 fixed: one pass over the pair file for all candidates (`prefetch`); run tables are parsed once
  (`_Run.table`).
- M7 fixed: an unreadable FASTA keys as "unreadable", and the figure leaves C out ("D's genome sequence cannot be
  read"). Test: test_unreadable_fasta_omits_the_example.
- M8 fixed: the sources are now "genome index:<R> sequence lengths", "display:bin, ..." and "genome
  sequence:<labels>". The brief's file-source assertion now also accepts these three kinds.
- M9 fixed:
  - "not present in the outgroup";
  - "thin", "a little" and "diffuse" are gone; magnitudes are stated as numbers;
  - the sparse-block sentence states the rule: "drawn where their loci average at least one per display bin
    (296 intervals; 49 sparser blocks not drawn, the largest 278 Mb on 6 loci)".
- M10 fixed: test_numbers_equal_their_tables compares values, not substrings (D_pav, Z, n_RD, n_SD, the three E
  counts, G's two means, B's two shares). Branch tests are listed above.

Not done: nothing.

## Fix round 2 (task-11-review.md "Re-review (fix round 1)"; requirements task-11-fix-2.md)

Commits:
- 28808ce "Overview fix round 2: both counts when not significant, the recipient from the donor-sharing test, one
  text per numbers key" (overview.py, tests, DESIGN.md's selection rule);
- dc5824d "Refuse a stale stats.tsv in the plot stage" (report.py, analysis/cli.py, DESIGN.md, test).

Tests: on dc5824d, `python -m pytest -W error -m "not slow"` gives 1119 passed, 2 deselected (343 s); ruff is clean.
tests/test_overview.py now holds 36 tests.

Re-rendered on the main3 view:
- **Refusal first.** Before the reruns, ltrpav-plot refused the run (run/plot_refused.log, exit 1): "error: stats.tsv
  in . is not current (the stats part: the analysis code changed; the paint part: the analysis code changed):
  rerun the analyses (ltrpav-stats and ltrpav-paint, or ltrpav run), then ltrpav-plot".
- **Unchanged.** stats, paint and plot were then rerun with the committed code. stats.tsv, findings.txt,
  inversions.tsv, mechanisms.tsv and both tract files are byte-identical to fix round 1's.
- **Numbers table.** overview_numbers.tsv has the same 102 values. Only the four N5 source cells changed. All 102
  values appear verbatim on pages 2-3, every source file exists, and no None, nan or inf appears.
- **Legends.** The short legend changed only in E's sentence, and the long legend only in the definitions sentence.
- **Figure page.** It is unchanged: 2125 x 2605 px, the same layout and content.

Items:
- **N1 fixed (28808ce).** One helper, `not_significant`, writes the |Z| < Z_SIG branch of the headline and of F's
  short legend: "Of the insertions D shares with only one of the sisters, R carries a, S b; the difference is not
  significant (|Z| < 3): no evidence of gene flow."
  - The 3 is printed from Z_SIG.
  - Without both counts it says "The difference between R and S ... is not significant (|Z| < 3)".
  - Test: test_not_significant_is_not_equal. It sets D_pav's Z to Z_SIG - 0.1 on the normal probe, with counts 268
    and 155. The sentence appears in the headline and in F, and "about equally" appears nowhere.
- **N2 fixed (28808ce).** With roles from the data, E's short legend now ends "...; the donor-sharing test (panel F)
  makes B73 the recipient.", whatever E's merged counts show. With other roles it ends after the counts.
  - The definitions now read "roles from the data: the sisters are the pair sharing the most insertions (panel E),
    the recipient the sister with more donor-shared insertions in the donor-sharing test (panel F)". The letters
    are the figure's own.
  - The spec docstring no longer says E's counts "set the roles".
  - Test: test_verdicts_follow_their_statistics checks both sentences, reading F's letter from the legend, and
    checks that "which makes R the recipient" is gone.
- **N3 fixed (28808ce).** test_unreadable_fasta_omits_the_example is skipped when os.geteuid() == 0.
- **N4 fixed (28808ce).** `_Legend.num` goes through `_Legend.text`.
  - A key registered again returns its text when the new text is the same. A different text raises ValueError
    ("numbers key 'k' written twice with different texts: ...").
  - The repeated call sites (posterior_mean, decoy_posterior_mean, n_tracts, n_tracts_q05, C_screened) all use one
    style. main3 and every test render without a raise.
  - Test: test_a_numbers_key_keeps_one_text.
- **N5 fixed (28808ce).** The tract BED's columns are chrom, start0 and end.
  - B_pct_length and B_tract_length now cite "tracts.<R>.bed:end - start0".
  - B_median_length carried the same "end-start0" and now cites the same.
  - B_tract cites "chrom, start0 + 1, end", because the legend prints 1-based starts.
- **Out-of-scope 1 done (dc5824d).** `stale_parts` needs no option that only the stats command knows. It recomputes
  each key from the --trio and --identity values the stage's marker records, plus LASTZ's version, which it probes.
  - `run_plot` calls `stale_parts(cat, warn=False)` before drawing. Any stale part is an AnalysisError that names
    each part and why, and ends "rerun the analyses (ltrpav-stats and ltrpav-paint, or ltrpav run), then
    ltrpav-plot".
  - Standalone, that is one "error:" line and exit 1. Inside `ltrpav run` it is the existing single WARNING, exit 0.
  - The new `warn` flag keeps the assembly's "left out of stats.tsv" WARNING out of the plot's output. ltrpav-plot
    does not reassemble stats.tsv.
  - A skipped plot ("plot: done, skip") is not re-checked. Its key covers the run's files and the analysis code, so
    it was drawn from a stats.tsv that was current then. Only a LASTZ version change (stats with --identity) makes a
    part stale without changing the plot key. In that case the figure on disk still matches the stats.tsv it was
    drawn from.
  - Updated to match: the docstrings of report.py and analysis/cli.py, the ltrpav-plot epilog and DESIGN.md.
  - Test: test_plot_refuses_a_stale_stats_tsv.
    - After stats and paint, the toy run is re-merged in place (simulate_run, seed 2).
    - ltrpav-plot then exits 1 with one error line naming both parts ("its inputs changed (loci.tsv, ...").
    - It logs no WARNING, draws no figure and writes no plot marker.
    - After the analyses rerun, it draws.
- **Out-of-scope 2 done.** memo.md now reads as current:
  - The two-key example rule is replaced by the current rule, with one line noting that the first rule was
    superseded.
  - "plateaus near 1 arise without gene flow too" is removed.
  - Round 1's tract numbers (mean posterior 0.92, 1 of 13 screened) and the first-render figure check are marked
    superseded.
  - The header gives the current commits and outputs.
- **Correction to fix round 1's report (I4).** It said "A painting file whose lids are no longer in loci.tsv also
  counts as not current". That was wrong: `_painting` never checked lids. That case now cannot reach a drawing
  through ltrpav-plot or ltrpav run, because a changed loci.tsv makes both parts stale and the plot stage refuses.
  A direct call of `overview()` still trusts the files.
- **Also corrected (28808ce).** DESIGN.md section 6 still gave the first, two-key selection rule (loci and length).
  It now gives the three keys.

Found, not fixed (out of scope):
- **The PNG is not pixel-reproducible between runs.** Two Liberation versions are installed: 1.x in
  /usr/share/fonts/truetype/liberation and 2.x in liberation2.
  - `_fonts()` registers the unordered list from `findSystemFonts()`, so each process may draw with either version.
    Six fresh processes chose 2.x for sans five times and 1.x once.
  - The metrics are the same, so text, numbers and layout are identical. About 1% of the PNG's pixels (glyph
    antialiasing) differ between two renders of the same code.
  - Proposed fix: register the files in a fixed order, newest fontRevision first.

Not done: nothing.

## Fix round 3 (task-11-review.md "Re-review (fix round 2)", item 6; the coordinator's ruling)

Commit: 2c2e639 "Plot stage: compare the tool versions the markers recorded, and refuse a part left out of
stats.tsv" (report.py, analysis/cli.py, DESIGN.md, tests/test_cli_analysis.py).
Tests: `python -m pytest -W error -m "not slow"`: 1121 passed, 2 deselected (362 s); ruff clean.

- **Fixed as ruled.** `stale_parts(cat, warn=True, probe_tools=True)`.
  - With probe_tools=False, each key is recomputed with the tool versions its marker recorded. `stage_params`
    takes a new `tools` argument (the marker's params) instead of probing `localign.backend_version`. No external
    tool is probed.
  - `run_plot` passes probe_tools=False.
  - The stats and paint commands keep probe_tools=True. A new or missing LASTZ still reruns
    `ltrpav-stats --identity`, and the assembly still leaves the stats part out until then.
- **Added beyond the ruling: the ruling alone opened a regression.** A part can be current by the plot's check yet
  absent from stats.tsv, because an assembly that probed a new or missing LASTZ left it out. This is the reviewer's
  out-of-scope case: ltrpav-paint run without lastz after `ltrpav-stats --identity`.
  - With probe_tools=False alone, ltrpav-plot then drew from a stats.tsv without the stats part. The probe (stats
    --identity, then ltrpav-paint under another LASTZ, then ltrpav-plot; scratchpad r3/probe2.py) drew the no-trio
    figure: "With fewer than three ingroup genomes (R, S, D) there is no trio", for a run with three.
  - dc5824d refused that state; the ruling alone would have drawn it.
  - `run_plot` now also refuses a part that the last assembly left out, for example: "the stats part: left out when
    stats.tsv was last assembled: LASTZ's version differs (now ...)".
  - It reads these parts with `left_out_parts`, from findings.txt, which `assemble` writes atomically together
    with stats.tsv. Its line is now one constant, `_LEFT_OUT`, with its pattern beside it.
  - The reason in the message says what to fix: put lastz back on PATH, or rerun `ltrpav-stats --identity` under
    the new LASTZ.
  - A current --identity stats.tsv, assembled while lastz was available, has no left-out line, so the reviewer's
    false refusal stays fixed.
- **Tests** (tests/test_cli_analysis.py):
  - **test_plot_check_probes_no_tool.**
    - Setup: stats --identity and paint with lastz, then backend_version patched to return None (lastz gone).
    - stale_parts with probes calls the stats part stale ("LASTZ's version differs"); without probes it finds
      nothing.
    - ltrpav-plot draws (exit 0).
    - After a re-merge (one locus fewer), it refuses, naming both parts ("its inputs changed (loci.tsv"); the
      message mentions no LASTZ.
  - **test_another_lastz_reruns_stats_and_still_draws.**
    - With a LASTZ other than the recorded one, ltrpav-plot draws.
    - ltrpav-paint's assembly then leaves the stats part out. `left_out_parts` names it, and ltrpav-plot refuses
      with the reason.
    - `ltrpav-stats --identity` reruns: not a skip, and the marker records the new version.
    - The figure is then drawn again.
  - **Checked by reverting.** With `run_plot`'s call reverted to dc5824d's probing, both tests fail at the first
    plot. Without the new guard, the left-out case fails.
- **main3: not re-rendered.** This code path does not change what main3 draws: main3's stats part has no
  --identity, so no tool version enters any key, and its findings.txt records no left-out part (`left_out_parts`
  returns {}). The view's stats and paint markers predate 2c2e639's analysis code, so the next ltrpav-plot there
  needs ltrpav-stats and ltrpav-paint first, as after any analysis-code edit.

Not done: nothing.
