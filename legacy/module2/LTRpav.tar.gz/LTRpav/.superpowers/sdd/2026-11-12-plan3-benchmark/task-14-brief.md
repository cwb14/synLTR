### Task 14: *Zea* genus event, sweet orange, EDTA portability

**Files** (in `benchmark_pav/plan3/real/`): `genus/{views,score_genus.py,RESULTS.md}`,
`citrus/{views,score_citrus.py,RESULTS.md}`, `edta/{views,RESULTS.md}`; `memo.md` (append); and
`benchmark_pav/dead_ends.md`.

- [ ] **Step 1: Genus** (EDTA annotations; no outgroup). Views:
  - `all`;
  - `p1` (`--trio Zh,TIL18,Zn`);
  - `p2` (`--trio TIL01,TIL18,Zn`);
  - `ctrl` (`--trio TIL18,TIL25,Zn`);
  - `zd` (`--trio Zh,TIL18,Zd`).

  Bars (DESIGN 10.4):
  - P1, D > 0 with Z > 3 for Zh: PASS or MISS;
  - control |Z| < 3: PASS or MISS;
  - P2 reported.

  For each trio, report the resolved fractions of D's loci in R and in S. This is the synteny problem that broke
  LTRmix's D_ins: Zn inside synteny 0.95 / 0.58 / 0.35.

  `zd` is decision 11's case. Report:
  - the discovery genomes the four-point fallback used (findings.txt);
  - the genomes the unnarrowed DESIGN 7.1 wording would add (listed);
  - D and Z, beside the simulated `nodonor` results (Task 11). The rule is not changed; the user decides decision 11
    after Plan 3.
- [ ] **Step 2: Sweet orange** (no outgroup). Views:
  - `c1` (`--trio CsB,Cm,Cr`);
  - `c2` (`--trio CsA,Cr,Cm`);
  - `k1` (`--trio CaM,Cr,Cm`);
  - `k2` (`--trio CaP,Cm,Cr`).

  Bars (DESIGN 10.4, as LTRmix 6c):
  - **Called tracts.** Every true tract of at least 1.7 Mb in `CsB.M.bed` and `CsA.P.bed` is called: tracts by the
    tract rule at any q cover >= 50% of it. PASS or MISS per tract. Recall at q <= 0.05 is also reported.
  - **C1.** D > 0 with Z > 3, reported. LTRmix: +0.469, Z 4.8.
  - **Controls.** |Z| < 3 and no tract at q <= 0.05: PASS or MISS.
  - **Base pairs.** bp precision and recall at any q and at q <= 0.05, reported.
- [ ] **Step 3: Portability.**
  - Make view `edta/views/main` with `view.sh` on `edta/geno`.
  - Run `ltrpav-stats` and `ltrpav-paint` with `--trio B73,TIL01,TIL18`.
  - Then run `compare_papers.py --run edta/views/main --prefix edta_main`.

  `RESULTS.md` sets these rows beside view `six/views/main` (Task 13):
  - D_pav, dD;
  - chromosome ranking;
  - window r at 1 and 10 Mb;
  - AUROC, spacing;
  - Inv4m.

  Reported, with no bar. LTRmix found the genome-wide tests hold on EDTA while windows weaken (`benchmark/edta/out`).
- [ ] **Step 4: Memo.** Append dates, commands and outputs to `real/memo.md`.

---

