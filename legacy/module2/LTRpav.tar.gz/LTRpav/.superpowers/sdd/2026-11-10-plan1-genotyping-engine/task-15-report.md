# Task 15 report: route interface, mm2 route, PAF route, checkpoints

Status: DONE_WITH_CONCERNS (three deliberate deviations from ruling 4, each forced by a measured failure; one
ruling-mandated behavior, the N-chunk skip, is implemented as ruled but is lossy, see Concerns).

## Commits (branch plan1-engine)
- `0021b39` Collapse same-diagonal contained blocks before chaining
- `a70cc84` Add route interface, mm2 and PAF routes, checkpoints

No trailers; global git identity.

## What was implemented

### chain.py (commit 0021b39), ruling 5 as written
- `_uncontained(blocks, idx)` runs inside `chain_blocks` right after `_distinct`. Within an (a_chrom, b_chrom,
  strand) group it drops Y when another block X has X.a_start <= Y.a_start, Y.a_end <= X.a_end,
  X.b_start <= Y.b_start, Y.b_end <= X.b_end, and the diagonals agree within CHAIN_OVERLAP (+: b_start - a_start;
  -: b_end + a_start). It logs `dropped N block(s) contained in a same-diagonal block` at DEBUG on ltrpav.chain.
- Implementation: one lexsort (group, a_start asc, a_end desc, B length desc, so a container sorts before what
  it contains), then a numba sweep `_contained` whose active list holds the blocks still overlapping the current
  a_start. A block whose end is at or before the current start can contain nothing later and leaves the list.
  Cost is O(n log n + n * depth), never all-pairs. Dropped blocks stay active as containers (the rule is "some
  other block").

### checkpoint.py
- `file_checksum(path, cache)`: streams sha256 in 8-MB blocks (`readinto`, works on py3.10). The cache is a JSON
  file keyed by resolved absolute path and holding size, mtime_ns and sha256. A damaged cache is rebuilt with a
  warning. Writes are atomic (temp file + os.replace).
- `stage_key(stage, inputs, params)`: sha256 of canonical JSON (sorted keys, compact) of stage, inputs, params
  and `ltrpav.__version__`. Path and numpy scalars are converted; any other non-JSON type is a TypeError.
- `is_done(marker, key)`: True only if the marker's key matches and every listed output exists with its recorded
  size.
- `mark_done(marker, key, outputs)`: written atomically and last. Output paths are stored relative to the
  marker's directory, so a moved work dir stays valid. A missing output raises FileNotFoundError and nothing is
  written.
- Added `clear_done(marker)`, called before a stage rewrites its outputs. Without it, a crash mid-rewrite leaves
  the old marker beside new, partial outputs, and they would be trusted again once the old key returns. Also
  added `CHECKSUM_CACHE = "checksums.json"` (stored at `<workdir>/checksums.json`).

### anchor/__init__.py
- `PairContext` follows ruling 1, with the read-only `workdir` property = outdir / "work".
- `Route` Protocol: `name`, `raw_blocks(ctx)`, plus `whole_genome: bool`, `reads_elements: bool` and
  `params(ctx) -> dict`. `params` returns the JSON values the raw blocks depend on besides the FASTAs, and is part
  of the cache key. `anchor_pair` reads the three added members with getattr defaults (False/False/{}), so a later
  route that defines only `name` and `raw_blocks` still works.
- `get_route`: "mm2" gives Mm2Route; "paf:<dir>" gives PafRoute(Path(dir)). Anything else, including "paf:", is
  a ValueError naming `known routes: mm2, paf:<dir>`.
- `anchor_pair(ctx, route)` caches at `workdir/anchors/<A>__<B>.<route>.npz` with marker `<file>.done.json`.
  - Key: both FASTA checksums; element digests when `reads_elements`; route params; and the chaining constants
    (ANCHOR_MIN, CHAIN_*, MIN_CHAIN_SCORE).
  - On a hit it loads the blocks and recomputes d. On a miss it runs raw -> chain_blocks -> net_blocks, then an
    atomic save (temp + rename), then mark_done.
  - d = 1 - sum(matches)/sum(alen), nan if empty (`divergence()`).
- W-route raw cache (ruling 2): stored at `workdir/anchors/<X>__<Y>.<route>.raw.npz`, X < Y lexicographically.
  The raw blocks are always computed in canonical direction (A = X), even when B->A is requested first, so the
  result does not depend on call order. The other direction loads them and applies `swap_blocks`; name lists
  are swapped to match.
- The element digest is sha256 over the Element reprs. PairContext carries no elements file, so this stands in
  for the "elements file checksum" in ruling 8. No route in this task reads elements; it is tested with a fake
  route.

### anchor/mm2.py (Mm2Route: name "mm2", whole_genome True)
- **B index**, built once per B FASTA at `workdir/anchors/<B>.asm20.mmi`. The marker is keyed by the FASTA
  checksum and the preset.
  - With the minimap2 binary: `minimap2 -x asm20 -t T -I <B total bp> -d <tmp> <fasta>`, then rename.
  - Without it: `mappy.Aligner(fn_idx_in=<fasta>, preset="asm20", ..., fn_idx_out=<tmp>)`, so the fallback
    also writes and reuses the index.
  - Loaded with `mappy.Aligner(fn_idx_in=<mmi>, preset="asm20", best_n=MAPPY_BEST_N, extra_flags=EQX)`.
  - `aligner.seq_names` must equal B's fai names. On a mismatch the marker is cleared and a RuntimeError raised.
- **Chunking** follows ruling 4: chunks of MM2_CHUNK+MM2_OVERLAP stepping MM2_CHUNK, read with `Fasta.fetch` in
  the main thread. Chunks over MM2_MAX_N = 0.5 N are skipped, and the skip count and their non-N bp are logged at
  INFO. Mapping runs in a `ThreadPoolExecutor(T)` with one `mappy.ThreadBuffer` per thread (threading.local).
  At most 2*T chunks are in flight (bounded memory), and results are collected FIFO, so output is deterministic.
- **Core rule**: a hit starting past the chunk's core yields nothing (ruling 4). Hits are also cut at the core end
  (deviation 2 below).
- **Blocks**: hits are cut into pieces (deviation 1 below). For each piece: matches = '=' columns, and alen =
  '=' + 'X' + shorter-indel columns. A hit with no indel >= SPLIT_INDEL that lies inside its core gives exactly
  the ruling's block (a = chunk_start + q_st..q_en, b = r_st..r_en, matches = mlen, alen = blen), except alen
  also counts ambiguous-base columns, which blen leaves out.

### anchor/paf.py (PafRoute: name "paf", whole_genome False)
- Lookup order: `<dir>/<A>__<B>.paf`, `.paf.gz`, then `<B>__<A>.paf`, `.paf.gz` (read with swap=True). If none
  exists: FileNotFoundError naming `<dir>/A__B.paf[.gz]` and `<dir>/B__A.paf[.gz]`.
- `params` holds the PAF's file name and sha256, so a changed PAF invalidates the netted cache (tested).
  `whole_genome = False` because each PAF already is the pair's raw cache.

### blocks.py
- `_flush` renamed to public `blocks_from_rows` (with a docstring), so mm2 reuses it instead of duplicating it.

### constants.py
- `MM2_MAX_N = 0.5`: a chunk more than half N is mostly assembly gap and is not mapped (ruling 4's threshold).
- `SPLIT_INDEL = 80`: Wicker's 80-bp minimum (the same basis as MIN_SEG). A longer indel may be a TE fragment,
  so it splits an alignment.

## Deviations from the rulings, with evidence

1. **Hits are split at indels >= SPLIT_INDEL (80 bp)**, where ruling 4 says each hit is one block.
   - minimap2 asm20 chains anchors across gaps up to 10 kb (max_gap). Its z-drop discounts long gaps, so it aligns
     straight through element insertions.
   - Probe on the brief's toy: one 110-kb hit, q 0-110000 -> r 0-95600, CIGAR with three `4800I` ops, mlen 94641,
     blen 110000. Unsplit, the brief's mm2 test got d = 0.134-0.139 against the required 0.005 < d < 0.02. The
     block's linear A->B map was also off by up to ~2.4 kb inside it, more than WINDOW_PAD.
   - The chain design already assumes element-sized indels fall between blocks (test_chain_bridges_insertion,
     the solo-LTR flank tests).
   - Implementation: EQX CIGAR (`extra_flags=0x4000000`, so `=` ops sum exactly to mlen) and `_pieces()`. It walks
     the query forward; on the minus strand it takes the CIGAR reversed with B descending (minus-strand CIGARs walk
     the query down from q_en; verified with an asymmetric probe).
   - After the split: d = 0.0095-0.0104 on 30 seeds, and no netted block spans an insertion (asserted in the test).
2. **Hits are cut at their chunk's core end** (ruling 4 keeps a hit that starts in the core whole).
   - With hits kept whole, seed 18 of the toy gave margin 0.96. The chunk-1 piece A[142000,207998) and chunk 2's
     left-truncated copy A[200000,208000) end 2 bp apart: the copy's alignment runs into the insertion gap, while
     the container's extension stopped at a terminal mismatch.
   - Not strictly contained, so ruling 5 does not drop the copy. Its A end advances by only 2 bp (< ANCHOR_MIN),
     so the DP cannot chain it either. It competes as a fake paralog.
   - Cutting at the core end means every A position is reported by exactly one chunk. The next chunk starts
     exactly at the cut and reports the rest, the two parts abut and chain, and the 10-kb overlap still gives each
     chunk context past its core.
   - Result: 30/30 seeds have all margins 1.0, coverage 1.0, and raw count == netted count (no copies). Ruling 5
     stays exactly as written (still needed for PAF and other inputs).
   - The ruling's stated property, an alignment inside an overlap zone yields exactly one block, holds and is
     tested.
3. **`-I <B genome bp>` added to the minimap2 index command.**
   - mappy loads only the first part of a multi-part index (mappy.pyx: "NB: ONLY read the first part").
   - Verified: a 3 x 400-kb FASTA indexed with `-I 500k` loads as ['s1','s2']. With `-I 1200000` it has all three
     sequences, and the index is byte-identical to mappy's own (fn_idx_out).
   - minimap2's default -I 8G would silently drop sequences for genomes > 8 Gb. The seq_names check is a second
     guard.

Smaller additions not in the brief: `clear_done`, `CHECKSUM_CACHE`, the Route `params`/`whole_genome`/
`reads_elements` members, the size check in `is_done`, and atomic npz/mmi writes.

## Tests (all synthetic, seeded, fast; no network, no real genomes)
- tests/test_chain.py (+8 cases):
  - `test_chain_collapses_contained_same_diagonal_copy[strand x shift 0/CHAIN_OVERLAP]`: the probe E case on
    both strands, giving one chain, margin 1.0 and the DEBUG count.
  - `test_chain_keeps_contained_copy_on_other_diagonal[strand x shift CHAIN_OVERLAP+1/4000]`: not collapsed; the
    margin is lowered to 1 - 2900/10000.
- tests/test_checkpoint.py (4):
  - Roundtrip: checksum matches hashlib with streaming forced to 3-byte blocks. The key is order-independent and
    changes with an input checksum, a param, the stage or the version. is_done/mark_done/clear_done work, leave no
    temp files, and detect a rewritten or deleted output.
  - mark_done with a missing output raises and writes nothing.
  - A marker stays valid after its directory is moved.
  - The checksum cache follows size and mtime_ns. Same size with the mtime restored returns the cached sum; a new
    mtime or a new size re-reads; a path through `.` hits the same entry; a damaged cache is rebuilt with a warning.
- tests/test_routes.py (14):
  - `test_mm2_route_covers_shared_sequence` (the brief's toy: 300-kb backbone, B mutated 1%, 10 A-only 4.8-kb
    elements; B contigs reordered, one reverse-complemented): coverage >= 0.95 (got 1.0), 0.005 < d < 0.02
    (0.0097), strand and contig mapping, all margins 1.0, no block spans an insertion.
  - `test_mm2_pieces_split_at_long_indels[+/-]` and `test_mm2_pieces_cut_at_stop[5 cases]`: CIGAR-level unit
    tests, including a stop inside a short insertion and the M-op error.
  - `test_mm2_index_built_once_with_or_without_minimap2`: the index is reused (mtime unchanged). With
    `shutil.which` patched to None, mappy builds it: same raw blocks and a byte-identical .mmi.
  - `test_mm2_chunk_core_rule` (chunks patched to 20k+5k): an alignment inside an overlap zone gives exactly one
    block. An alignment across a core end is cut there and continued by the next chunk; after anchor_pair it is
    one chain with margin 1.0 and > 0.99 coverage.
  - `test_w_route_reused_both_directions`: B->A is requested first, and the spy shows one raw_blocks call with
    ("A","B") (canonical order). A->B and repeat calls add no call. The three expected npz files exist, raw names
    are in canonical order, B->A coverage >= 0.95, and |d_AB - d_BA| < 0.002.
  - `test_paf_route`: A__B.paf read directly, B__A.paf.gz read swapped (identical arrays). anchor_pair B->A via
    `paf:<dir>` gives the swapped coordinates and the exact d. Appending a PAF record rebuilds the cache. Neither
    file present gives a FileNotFoundError naming both paths.
  - `test_anchor_pair_cache_key`: threads are not in the key; changed elements (route reads them), a changed
    route param, or another B FASTA under the same label each recompute. An empty route gives no blocks, names
    from the FASTAs, and d = nan.
  - `test_get_route`: known specs, plus ValueError for "", "MM2", "minimap2", "paf", "paf:".

### TDD evidence
RED 1 (tests first, before any implementation):
```
mamba run -n ltrpav pytest tests/test_checkpoint.py tests/test_routes.py tests/test_chain.py -p no:cacheprovider
E   ImportError: cannot import name 'checkpoint' from 'ltrpav'
E   ModuleNotFoundError: No module named 'ltrpav.anchor'
ERROR tests/test_checkpoint.py / ERROR tests/test_routes.py (collection)
mamba run -n ltrpav pytest tests/test_chain.py
FAILED test_chain_collapses_contained_same_diagonal_copy[0-1] [0--1] [100-1] [100--1]   (len(ch) == 2: two chains)
```
GREEN chain: `39 passed in 18.97s` (test_chain.py including slow).

First GREEN attempt for routes: 2 failed (`d = 0.1389 / 0.1336`, outside 0.005-0.02). Root cause: hits span the
insertions (deviation 1).
RED 2: `ERROR tests/test_routes.py` (ImportError of SPLIT_INDEL, before the splitter existed). GREEN: 13 passed.
Seed scan: seed 18 had margin 0.96 (deviation 2).
RED 3, after rewriting the unit and chunk tests for the core-end cut: `7 failed, 6 passed`. GREEN: 18 passed. The
30-seed scan was all clean.

Final, on the committed tree:
```
mamba run -n ltrpav pytest -m "not slow" -p no:cacheprovider -W error   -> 421 passed, 1 deselected in 5.22s
mamba run -n ltrpav pytest -m slow -p no:cacheprovider                   -> 1 passed (chain+net 1e6 blocks 18.09s; 16.85s before)
mamba run -n ltrpav ruff check .                                         -> All checks passed!
PATH without minimap2 (CI-like, mappy indexing): routes + checkpoint     -> 18 passed
Python 3.10.18 ast.parse of all 9 new/changed files                      -> ok
```

## Throughput (synthetic random sequence only: no repeats, so an optimistic upper bound)
- Toy pair (348 kb vs 300 kb): anchor_pair 0.12-0.26 s including indexing.
- 10.3 Mb A (50 x 6-kb insertions) vs 10.0 Mb B (1% substitutions):

  | threads | index + map | map only (index reused) |
  |---|---|---|
  | 1 | 3.55 s | 3.03 s = 3.4 Mb/s |
  | 4 | 1.32 s | 0.86 s = 12.0 Mb/s |
  | 8 | 0.94 s | 0.50 s = 20.6 Mb/s |

  150 raw blocks become 150 netted, d = 0.0101.
- Thread scaling is near-linear (a mappy probe: 2.13 s at 1 thread, 0.28 s at 8): mappy releases the GIL.
- Real maize (~85% repeats) will be far slower per Mb; measure it in the bake-off.

## Files changed
- New: src/ltrpav/anchor/__init__.py, src/ltrpav/anchor/mm2.py, src/ltrpav/anchor/paf.py,
  src/ltrpav/checkpoint.py, tests/test_routes.py, tests/test_checkpoint.py
- Modified: src/ltrpav/chain.py (containment collapse), src/ltrpav/blocks.py (`blocks_from_rows`),
  src/ltrpav/constants.py (MM2_MAX_N, SPLIT_INDEL), tests/test_chain.py (+2 tests, 8 cases)

## Self-review findings (fixed before commit)
- A short insertion straddling the core-end cut counted its full length in alen; it now counts only the part
  before the cut (test case added).
- A sequence-name mismatch in a cached index would have failed on every run; it now clears the marker so the next
  run rebuilds.
- Docstrings hard-coded "10 kb"; they now name MM2_OVERLAP.
- Dropped a structured-array astype on route output: numpy casts structured arrays by position, so routes must
  return BLOCK_DTYPE.
- ruff 0.17 (the CI installs the latest): sorted `__all__`, explicit `check=False`, removed an unused variable.

## Concerns
1. **The N-chunk skip (ruling 4, implemented as ruled) is lossy and buys nothing.**
   - A chunk more than 50% N can still hold up to 55 kb of real sequence. Of that, up to ~45 kb lies outside the
     neighbors' overlap and is never mapped.
   - With the core-end cut, the previous chunk also no longer reports into the skipped chunk's core (up to 10 kb
     more).
   - Measured cost of not skipping: mapping an all-N 110-kb chunk takes 0.49 ms. A 60%-N chunk takes 12 ms, all
     of it spent on its real 50 kb.
   - Suggested: never skip, or skip only chunks with fewer than ANCHOR_MIN non-N bases (lossless for the net).
     Maize NAM assemblies use 100-N gaps, so it rarely triggers on the target data; it matters for assemblies
     with large sized gaps. Skipped chunks and their non-N bp are logged at INFO.
2. **PAF route: same spanning-indel issue.** External PAF records that align through insertions (e.g. minimap2
   PAF) still become single blocks whose linear map spans the insertion, and they inflate d. read_paf could split
   on the `cg:Z:` CIGAR when present, using SPLIT_INDEL (Task 9 territory). Relevant to the route bake-off.
3. **SPLIT_INDEL = 80 is my choice**, justified by Wicker's 80-bp minimum TE fragment (an indel that long may be a
   TE fragment and must sit between blocks). 50 bp (the SV convention) would also be defensible. Please confirm.
4. **Labels containing "__" make cache file names ambiguous** (e.g. "a__b"+"c" vs "a"+"b__c"). Keys prevent
   wrong reuse, but two such pairs would overwrite each other's caches. Suggest forbidding "__" in labels in
   samples.py.
5. **Caches key on `ltrpav.__version__`, not on code.** During development (0.1.0.dev0), changes to
   chain/net/route code do not invalidate cached anchors; clear `work/` after such changes.
6. **Concurrency.** Processes sharing one work dir may drop each other's checksum-cache entries (benign: a
   recompute). Two processes computing the same raw cache at once duplicate work. All writes are atomic, so
   neither case corrupts anything.

---

# Fix report: controller rulings on the Task 15 concerns

Accepted as implemented: the split at indels >= SPLIT_INDEL = 80, the cut at the chunk's core end, and
`minimap2 -I <genome size>`. In constants.py, SPLIT_INDEL now carries the requested reason on the line above it
(the CHAIN_OVERLAP style; inline the line would exceed 110 columns):
`# Wicker's 80-bp minimum; split at longer indels, blocks stay near-collinear: A->B errs < 80 bp per indel`.

## Commits
- `b9730c8` Reserve the label pair separator in the samples sheet
- `9b86d55` Split PAF records at long CIGAR indels; skip only chunks that cannot anchor
- `e07db80` Wrap anchoring code and tests to the 110-column limit

No trailers; global identity.

## Changes
**A. Chunk skipping** (anchor/mm2.py, constants.py)
- A chunk is skipped only when it has fewer than ANCHOR_MIN non-N bases, since it cannot yield an anchor.
  MM2_MAX_N and the >50%-N rule are removed.
- Skipped chunks are counted and logged at INFO: `skipped N chunk(s) with fewer than 100 non-N bases`.
- Route params use `"min_acgt": ANCHOR_MIN` in place of `"max_n"`, so the raw-cache key follows the rule.

**B. read_paf splits at `cg:Z:` CIGARs** (blocks.py)
- `read_paf(..., split_indel=SPLIT_INDEL)`: a record whose CIGAR has an I/D (or N) op >= split_indel is cut
  into sub-blocks with exact coordinates on both genomes, strand-aware. The minus-strand CIGAR runs along the
  target while the query descends from qe.
- Matches per sub-block are its '=' columns when the CIGAR uses =/X. With M ops they are the record's matches
  prorated by sub-block alen; cumulative rounding keeps the total exact.
- Sub-block alen counts aligned columns plus the shorter indels.
- A record stays one block, with the record's own matches and alen, when it has no CIGAR, no indel that long,
  or a CIGAR that is malformed or disagrees with its coordinates. The last case is counted in one warning. The
  docstring says all of this.
- One strand-aware CIGAR walker, `blocks.split_cigar(ops, q_st, r_st, r_en, strand, split_indel, stop=None)`,
  now serves both read_paf and the mm2 route. mm2's `_pieces` is a thin wrapper that still rejects M ops, since
  EQX is required for exact counts.
- PAF lines are stripped of `\r\n`, so a CRLF file's trailing `cg:Z:` tag still parses.
- PafRoute passes `split_indel=SPLIT_INDEL` and adds `split_indel` to its cache params.

**C. Label separator** (samples.py)
- Labels containing "__" are rejected with a SampleSheetError explaining that "__" is reserved and joins two
  labels in cache file names.
- I also reject a leading or trailing "_". Forbidding only "__" leaves the join ambiguous: "a_" + "__" + "b" and
  "a" + "__" + "_b" both give "a___b". With neither "__" inside nor "_" at either end, x__y splits back into
  exactly one pair. Revert that part if unwanted; it is one condition.

**Tidy** (separate commit e07db80): wrapped the 34 lines this task had added over 110 columns.
- Mostly docstring re-flow.
- Factored out `_load(mmi)` in mm2.py (the aligner construction appeared twice).
- Split the swap row tuple in read_paf.
- `ruff --select E501` is back to the 25 pre-existing hits. E501 is not in the default lint set; nothing
  else changed.

## Tests added
- tests/test_routes.py::test_mm2_maps_gappy_chunks: a1 is a single chunk, 60% N, holding a 30-kb segment
  shared with B; its alignment is reported (coverage > 0.99). a2 is a chunk with ANCHOR_MIN - 1 non-N bases;
  it is skipped, and the log says so.
- tests/test_blocks.py::test_read_paf_splits_at_long_indels, three cases:
  - Plus and minus records with a 500-bp D and a 300-bp I (plus 10I/5D/X ops inside) split into 3 sub-blocks
    with exact A/B coordinates and '=' matches.
  - The same alignment with M ops gets prorated matches [4996, 1996, 1996] (sum 8988).
  - Each case also checks: swap=True equals swap_blocks of the forward read; split_indel=501 keeps the record
    whole; the record without cg:Z: is one block with its own matches/alen, unchanged.
- tests/test_blocks.py::test_read_paf_short_indels_and_bad_cigar:
  - A CIGAR with only 10I/79D (< 80) gives one block with the record's values.
  - A CIGAR spanning 1700 bp of B against a record claiming 1400 is kept whole, with one warning.
- tests/test_samples.py::test_label_pair_separator: "B73__x", "B73_" and "_B73" are rejected with the reserved
  separator message; "B_7.3-x" is accepted.

## TDD evidence
RED (tests written first): `6 failed, 23 passed`.
- read_paf returned the whole record: `At index 0 diff: (0, 1000, 10301, 0, 2000, 11496, 1, 8988, 9806) !=
  (0, 1000, 6001, 0, 2000, 6996, 1, 4990, 5006)`.
- The gappy chunk was skipped: `assert 0.0 > 0.99`.
- No warning: `assert ('1 PAF record(s)' in '')`.
- `Failed: DID NOT RAISE SampleSheetError`.

GREEN after each step:
- blocks: `9 passed`.
- affected files (samples, blocks, routes, checkpoint): `33 passed in 1.56s`.
- 30-seed toy scan after the walker refactor: 30/30 clean, numbers identical to before (e.g. seed 44: raw 14,
  net 14, cov 1.0, d 0.0097, min margin 1.0).

## Final verification (committed tree, e07db80)
```
mamba run -n ltrpav pytest -m "not slow" -p no:cacheprovider -W error   -> 427 passed, 1 deselected in 5.20s
mamba run -n ltrpav pytest -m slow -p no:cacheprovider                   -> 1 passed (1e6-block chain+net 17.91s)
mamba run -n ltrpav ruff check .                                         -> All checks passed!
no minimap2 on PATH: routes + blocks + samples + checkpoint tests        -> 33 passed in 1.43s
Python 3.10.18 ast.parse of the changed files                            -> ok
```

## Remaining notes
- Caches are keyed on `ltrpav.__version__`, not on code: clear `work/` after dev changes to chain/net/route code.
- Processes sharing one work dir may drop each other's checksum-cache entries (benign recompute); all writes are
  atomic.
- Throughput numbers are synthetic (random sequence, no repeats); measure real maize in the bake-off.

---

# Fix round 1: chunks mapped with left context; pieces clipped to the core on both sides

Finding: the core-end cut lost alignment just past a core end. Chunk k kept its hit only up to its core end,
and chunk k+1 had to find the rest from its very first base, with no left context.

Ruling: map every chunk with MM2_OVERLAP bp of context on both sides, clip each hit's pieces to the core on
both sides (`begin` mirrors `stop` in `split_cigar`), and keep exact tiling.

## Commit
- `3758535` Map chunks with left context; clip pieces to the core on both sides (no trailers)

## Changes
- **`blocks.split_cigar`** now takes keyword-only `begin=None, stop=None` and keeps only query positions in
  [begin, stop).
  - An op crossing either cut is split there, with exact reference coordinates.
  - Whether an I/D splits the alignment is judged on the whole op, even when a cut falls inside it.
  - A reference-only op exactly at a cut belongs to the window that starts there. The previous window stops
    before it, so every column is kept by exactly one window and adjacent windows' pieces abut on A and B.
  - read_paf is unaffected (no cuts).
- **mm2 `_chunks`** keeps the same cores as before. Each window is now [core start - MM2_OVERLAP, core end +
  MM2_OVERLAP), clipped to the sequence, and the job carries the window start.
  - Skip rule: the core, not the window, must hold >= ANCHOR_MIN non-N bases, since only the core is reported.
- **mm2 `_pieces(cigar, q_st, r_st, r_en, strand, begin, stop)`** passes the core bounds in window coordinates.
  The worker shifts pieces by the window start.
- Docstrings corrected (module, `raw_blocks`, `_chunks`). The false claim that the next chunk reports the rest
  is replaced by a description of the two-sided context and why it matters.

## Tests (tests/test_routes.py; +17 cases)
- `test_mm2_keeps_homology_ending_just_past_a_core_end[100, 150, 200]`
  - Setup: 20-kb cores, 5-kb overlaps, core end at 40 kb; homology A[34000, 40000 + past).
  - Expect exactly 2 raw pieces abutting at A 40000 with equal B coordinates, the second ending at
    40000 + past (±10). After anchor_pair, coverage > 0.99.
- `test_mm2_keeps_fragment_before_insertion_just_past_a_core_end[800, 1000, 1100]`
  - Setup: an A-only 4.8-kb insertion `past` bp after the core end.
  - Expect 3 pieces; the core-end pair abuts exactly on A and B; the fragment ends at 40000 + past and the
    next piece starts after the insertion. After anchor_pair, coverage > 0.99.
- `test_mm2_pieces_cut_at_begin`: 9 hand-computed cases on both strands.
  - `begin` inside a = run, inside the short I5, inside the I4800, exactly at the D90 (kept by this side).
  - `begin` and `stop` together; a hit ending before `begin`.
- `test_mm2_pieces_tile_the_alignment[+/-]`: cuts through matches, the short insertion, the long insertion and
  the long deletion. Pieces from consecutive windows abut exactly and glue back into the uncut pieces (eq and
  alen sum exactly).
- `test_mm2_chunk_core_rule`: comment updated to the new windows; now asserts exact abutment at 40000 on A
  and B.
- Existing `_pieces` calls updated to the new signature.

## TDD evidence
RED, before the implementation:
- Walker tests: `18 failed` (new signature absent).
- Regressions on the old code: `4 failed, 2 passed`. Homology 100/150/200: `len(raw) == 1`, the fragment
  missing, e.g. only `(0, 34000, 40000, ...)`. Insertion at 1000: pieces `[30000,40000)` and `[45799, ...)`,
  so `[40000, 41000)` lost. 800 and 1100 happened to pass with these sequences; the loss depends on sequence,
  as the reviewer measured.

GREEN: `41 passed` (routes + blocks); full suite `444 passed`.

Reviewer probe `probes/p4c_scan.py`, before and after (lost bp in [core end, core end + off), seeds 1/2):

| case | before (lost bp) | after (lost bp) |
|---|---|---|
| end and ins, off 100 | 100 / 100 | 0 / 0 |
| end and ins, off 200 | 200 / 200 | 0 / 0 |
| ins, off 800 | 800 / 800 | 0 / 0 |
| ins, off 900 | 900 / 900 | 2 / 0 |
| ins, off 1000 | 1000 / 1000 | 0 / 0 |
| ins, off 1100 | 0 / 1100 | 0 / 0 |
| all other offsets | <= 5 | <= 4 |

The remaining 1-4 bp occur at scattered offsets, before and after alike. They are alignment-end trimming at
mismatches, or ±1-2 bp gap placement at an insertion edge (an equivalent alignment), not chunk loss.

30-seed toy scan: 30/30 clean, numbers identical (e.g. seed 44: raw 14, net 14, cov 1.0, d 0.0097, min margin
1.0).

## Extra mapping cost
Interior windows grow from 110 kb (MM2_CHUNK + MM2_OVERLAP) to 120 kb (MM2_CHUNK + 2 x MM2_OVERLAP): A is
mapped 1.2x instead of 1.1x, +9% bases. Measured on the 10.3-Mb synthetic pair (index reused, map only):

| threads | before | after | change |
|---|---|---|---|
| 1 | 3.02 s | 3.29 s | +9% |
| 4 | 0.84 s | 0.93 s | +11% |
| 8 | 0.50 s | 0.54 s | +8% |

Raw (150) and netted (150) counts and d (0.0101) are unchanged.

## Verification (committed tree, 3758535)
```
mamba run -n ltrpav pytest -m "not slow" -p no:cacheprovider -W error   -> 444 passed, 1 deselected in 5.62s
mamba run -n ltrpav pytest -m slow -p no:cacheprovider                   -> 1 passed (17.36s)
mamba run -n ltrpav ruff check .                                         -> All checks passed!
ruff --select E501 (not in the lint set)                                 -> 25, the pre-task count
no minimap2 on PATH: tests/test_routes.py tests/test_blocks.py           -> 41 passed in 1.81s
Python 3.10.18 ast.parse of the changed files                            -> ok
```
Minor findings were deferred as instructed; none addressed.
