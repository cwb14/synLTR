"""Exploratory direction (ltrpav.analysis.direction): n(X->Y), DFOIL-alt, 4-LIST, on toy run directories."""
from __future__ import annotations

import math
import re

import numpy as np

from catalog_toy import dmat, loc, write_run
from ltrpav.analysis.direction import DFOIL_ALT, _pair_masks, direction, signature
from ltrpav.analysis.relations import pav_distances
from ltrpav.analysis.stats import block_size

QUARTET = [("x1", "X", None, True), ("x2", "X", None, True), ("y1", "Y", None, True), ("y2", "Y", None, True)]
OUT = ("O", "OG", "outgroup", False)


def spec(p: str, member: int | None = None) -> str:
    """'x1:P* x2:E y1:P y2:E O:E' from presence pattern p over x1 x2 y1 y2; member = index (default: the first present)."""
    m = p.index("1") if member is None else member
    return " ".join(f"{g}:{'P' if c == '1' else 'E'}{'*' if j == m else ''}"
                    for j, (g, c) in enumerate(zip(("x1", "x2", "y1", "y2"), p))) + " O:E"


def test_counts(tmp_path, toy_fastas):
    genomes = [*QUARTET, ("z", "Z", None, True), OUT]
    loci = ([loc(1000 * i, "x1:P* x2:P y1:P y2:E z:E O:E") for i in range(1, 4)]     # X->Y x3
            + [loc(5000, "x1:P* x2:E y1:P y2:P z:E O:E")]                              # Y->X x1
            + [loc(6000, "x1:P* x2:P y1:P y2:E z:P O:E"), loc(7000, "x1:P* x2:P y1:P y2:E z:E O:U")])   # not counted
    cat = write_run(tmp_path, loci, genomes=genomes, fasta_dir=toy_fastas).load()
    rows, f = direction(cat, block_size(cat), pav_distances(cat)[0])
    got = {r.statistic: r.value for r in rows if r.test == "direction" and r.stratum == "all"}
    assert (got["n_XY"], got["n_YX"], got["D_dir"]) == (3, 1, 0.5)
    label = "not validated by simulation"
    assert all(r.note.startswith(label) for r in rows)
    assert any(label in t for _, t in f.items())
    d = next(r for r in rows if r.statistic == "D_dir")
    assert math.isnan(d.z) and "not testable" in d.note     # all loci in one block: no variance, no Z


def test_dfoil_signature():
    assert signature({"DFO": 4, "DIL": 5, "DFI": 3.5, "DOL": -4}) == "P1=>P3"
    assert signature({"DFO": 4, "DIL": 5, "DFI": 3.5, "DOL": 0.2}) == "none"    # full-DFOIL P1=>P3 is no alt code
    assert signature({"DFO": 4, "DIL": -5, "DFI": 3.5, "DOL": -4}).startswith("P1<=>P3 or P2<=>P4")
    assert signature({"DFO": math.nan, "DIL": 5, "DFI": 3.5, "DOL": -4}) == "none"


# expected DFOIL-alt pattern counts by the branch-length rule: on ((P1,P2),(P3,P4)),O with T12 = 2, T34 = 4, Troot = 8,
# each branch adds its length to the pattern of the leaves below it; with f = 0.1 the recipient's lineage follows the
# donor's from t = 1 (ancestral scenarios: the P1+P2 ancestor's, from t = 3). The species tree holds none of these
# patterns, so each count is f times its branch length in the migrant genealogy.
BRANCH_COUNTS = {
    "P1=>P3": {"1010": 0.1, "1110": 0.6}, "P1=>P4": {"1001": 0.1, "1101": 0.6},
    "P2=>P3": {"0110": 0.1, "1110": 0.6}, "P2=>P4": {"0101": 0.1, "1101": 0.6},
    "P3=>P1": {"1010": 0.3, "1011": 0.4}, "P4=>P1": {"1001": 0.3, "1011": 0.4},
    "P3=>P2": {"0110": 0.3, "0111": 0.4}, "P4=>P2": {"0101": 0.3, "0111": 0.4},
    "P1+P2<=>P3": {"1110": 0.5}, "P1+P2<=>P4": {"1101": 0.5}}


def test_dfoil_alt_signatures_from_branch_lengths():
    for scenario, counts in BRANCH_COUNTS.items():
        z = {}
        for stat, (left, right) in DFOIL_ALT.items():
            a, b = sum(counts.get(p, 0) for p in left), sum(counts.get(p, 0) for p in right)
            z[stat] = 1000 * (a - b) / (a + b) if a + b else math.nan
        assert signature(z) == scenario


def test_pair_discovery(tmp_path, toy_fastas):
    loci = [loc(1000, spec("1010", member=2)),      # 1010 discovered only by P3 (y1)
            loc(2000, spec("1010", member=0)),      # 1010 discovered by P1 (x1)
            loc(3000, spec("1110", member=1))]      # 1110 with P1 not a member: read from P2's (x2) calls
    cat = write_run(tmp_path, loci, genomes=[*QUARTET, OUT], fasta_dir=toy_fastas).load()
    pc = {st: {p: int(np.count_nonzero(m)) for p, m in d.items()}
          for st, d in _pair_masks(cat, ("x1", "x2", "y1", "y2"), ()).items()}
    assert pc["DFO"].get("1010", 0) == 1 and pc["DFO"].get("1110", 0) == 1 and pc["DFI"].get("1010", 0) == 1


def test_four_list_counts(tmp_path, toy_fastas):
    pats = ["1100", "1010", "1001", "0110", "0101", "0011", "1110", "1101", "1011", "0111"]
    loci = ([loc(20_000 * i + 1000 * (k + 1), spec(p)) for i, p in enumerate(pats) for k in range(i + 1)]
            + [loc(900_000, spec("1000"))])
    cat = write_run(tmp_path, loci, genomes=[*QUARTET, OUT], fasta_dir=toy_fastas).load()
    rows, _ = direction(cat, block_size(cat), dmat({("x1", "x2"): 0.05}, 0.5, cat.labels))
    assert {r.statistic: r.value for r in rows if r.test == "four_list"} == {p: i + 1 for i, p in enumerate(pats)}


def test_skips(tmp_path, toy_fastas):
    cat = write_run(tmp_path / "a", [loc(1000, spec("1100").replace(" O:E", ""))], genomes=QUARTET, fasta_dir=toy_fastas).load()
    rows, f = direction(cat, block_size(cat), pav_distances(cat)[0])
    assert rows == [] and any("skipped: no outgroup" in t for _, t in f.items())
    cat = write_run(tmp_path / "b", [loc(1000, "R:P* S:P D:E O:E")], fasta_dir=toy_fastas).load()
    rows, f = direction(cat, block_size(cat), pav_distances(cat)[0])
    assert rows == [] and any("skipped: needs two genomes per taxon" in t for _, t in f.items())


def test_p1p2_by_distance(tmp_path, toy_fastas):
    cat = write_run(tmp_path, [loc(1000, spec("1010")), loc(2000, spec("0101"))], genomes=[*QUARTET, OUT],
                    fasta_dir=toy_fastas).load()
    scope = lambda d: {r.scope for r in direction(cat, block_size(cat), d)[0] if r.test == "dfoil"}
    assert scope(dmat({("x1", "x2"): 0.05, ("y1", "y2"): 0.2}, 0.5, cat.labels)) == {"x1,x2;y1,y2"}
    assert scope(dmat({("x1", "x2"): 0.3, ("y1", "y2"): 0.05}, 0.5, cat.labels)) == {"y1,y2;x1,x2"}


def _quartet_run(tmp_path, toy_fastas, loci):
    return write_run(tmp_path, loci, genomes=[*QUARTET, OUT], fasta_dir=toy_fastas).load()


def test_nan_z_signature_none(tmp_path, toy_fastas):
    cat = _quartet_run(tmp_path, toy_fastas, [loc(1000, spec("1010")), loc(2000, spec("1001"))])
    rows, _ = direction(cat, block_size(cat), dmat({("x1", "x2"): 0.05}, 0.5, cat.labels))
    sig = next(r for r in rows if r.statistic == "signature")
    assert sig.value == "none" and "not testable" in sig.note


def test_age_strata(tmp_path, toy_fastas):
    loci = [loc(1000, "x1:P* x2:P y1:P y2:E O:E", k=0.0), loc(2000, "x1:P* x2:P y1:P y2:E O:E", k=0.0),
            loc(3000, "x1:P* x2:P y1:P y2:E O:E", k=0.05), loc(4000, "x1:P* x2:E y1:P y2:P O:E", k=0.05)]
    cat = _quartet_run(tmp_path, toy_fastas, loci)
    rows, _ = direction(cat, block_size(cat), pav_distances(cat)[0])
    got = {(r.stratum, r.statistic): r.value for r in rows if r.test == "direction"}
    assert (got[("K=0", "n_XY")], got[("K=0", "n_YX")]) == (2, 0)
    assert (got[("K>=0.01", "n_XY")], got[("K>=0.01", "n_YX")]) == (1, 1)
    assert ("0<K<0.01", "n_XY") not in got


def test_ddir_coordinate_fallback(tmp_path, toy_fastas):
    cat = _quartet_run(tmp_path, toy_fastas, [loc(1000, "x1:P* x2:P y1:P y2:E O:E"),
                                             loc(900_000, "x1:P* x2:P y1:P y2:E O:E")])
    cat.seq[:, cat.g("x1")] = -1       # the first X+Y genome has no coordinates
    rows, _ = direction(cat, block_size(cat), pav_distances(cat)[0])
    assert next(r for r in rows if r.statistic == "n_XY").value == 2


def test_dfoil_block_fallback(tmp_path, toy_fastas, monkeypatch):
    cat = _quartet_run(tmp_path, toy_fastas, [loc(1000, spec("1010")), loc(2000, spec("1001"))])
    d = dmat({("x1", "x2"): 0.05}, 0.5, cat.labels)
    base = {r.statistic: r.value for r in direction(cat, block_size(cat), d)[0] if r.test == "dfoil"}
    real = type(cat).proj_site

    def no_p1(self, gstar, label):
        seq, mid = real(self, gstar, label)
        return (np.full_like(seq, -1), np.full_like(mid, np.nan)) if label == "x1" else (seq, mid)
    monkeypatch.setattr(type(cat), "proj_site", no_p1)
    rows, f = direction(cat, block_size(cat), d)       # P1's site missing: the next quartet genome's
    assert {r.statistic: r.value for r in rows if r.test == "dfoil"} == base
    monkeypatch.setattr(type(cat), "proj_site", lambda self, g, label: (np.full(len(self.lid), -1),
                                                                         np.full(len(self.lid), np.nan)))
    rows, f = direction(cat, block_size(cat), d)       # no site anywhere: dropped, counted in findings
    assert any("dropped" in t for _, t in f.items())
    assert next(r for r in rows if r.statistic == "DFO").n == 0


def test_fallback_blocks_carry_the_genome(tmp_path, toy_fastas):
    """A row read in a fallback genome's coordinates gets that genome in its block id, so it never
    shares a jackknife block with another genome's sequence of the same fai index and bin."""
    from ltrpav.analysis.direction import coord_blocks

    ids = coord_blocks(np.array([0, 0, 1, 1]), np.array([0, 0, 0, 0]), np.array([10.0, 20.0, 10.0, 20.0]), 1000)
    assert ids[0] == ids[1] and ids[2] == ids[3] and ids[0] != ids[2]
    loci = [loc(1000 * i, "x1:P* x2:P y1:P y2:E O:E") for i in range(1, 4)]   # three X->Y loci in one 40-kb block
    cat = _quartet_run(tmp_path, toy_fastas, loci)
    cat.seq[2, cat.g("x1")] = -1                                    # the third: x2's coordinates, same index and bin
    rows, _ = direction(cat, block_size(cat), pav_distances(cat)[0])
    d_dir = next(r for r in rows if r.statistic == "D_dir" and r.stratum == "all")
    assert re.search(r"(\d+) jackknife blocks", d_dir.note).group(1) == "2"   # x1's block and x2's: two, not one
