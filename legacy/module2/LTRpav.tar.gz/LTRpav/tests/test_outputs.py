"""Output files (ltrpav.outputs): TSVs, VCF (+tabix), GFF3/BED tracks and manifest from hand-built loci of
genomes A (reference), B and C."""
from __future__ import annotations

import json
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import pysam
import pytest

from ltrpav.loci import GenomeState, Locus
from ltrpav.outputs.manifest import write_manifest
from ltrpav.outputs.tables import write_loci_tsv, write_pav_matrix, write_qc
from ltrpav.outputs.tracks import write_tracks
from ltrpav.outputs.vcf import write_vcf
from ltrpav.samples import Sample
from ltrpav.seqio import Fasta

SAMPLES = [Sample(g, Path(f"/x/{g}.fa"), f"/x/{g}", None, None) for g in "ABC"]
ORDER = {g: {"chr1": 0, "chr2": 1} for g in "ABC"}
LENGTHS = {g: {"chr1": 1000, "chr2": 500} for g in "ABC"}


def gs(state, tier="high", seqid=None, start=None, end=None, strand=None, k=None, flags=(), reason=None):
    return GenomeState(state, tier, seqid, start, end, strand, k, list(flags), reason)


def locus(lid, a, b, c, family="RLG_1", **kw):
    fields = {"lid": lid, "members": {"A": "A:e"}, "discovery": ["A"], "family": family, "superfamily": "Gypsy",
                  "clade": "Ale", "length": 5000, "ltr_len": 300, "tsd": "ACGTA", "states": {"A": a, "B": b, "C": c}}
    return Locus(**{**fields, **kw})


@pytest.fixture
def fa(tmp_path):
    p = tmp_path / "A.fa"
    p.write_text(">chr1\n" + "ACGT" * 250 + "\n>chr2\n" + "TTGCA" * 100 + "\n")
    return Fasta(p)


@pytest.fixture
def loci():
    return [
        # present in ref A, B has the empty site, C missing
        locus("L0000001", gs("P", "annot", "chr1", 101, 5100, "+", 0.02), gs("E", "high", "chr1", 50, 54, "+"),
              gs("D", "low"), members={"A": "A:e1"}),
        # empty in ref A (E): A site 200-204; B present
        locus("L0000002", gs("E", "high", "chr1", 200, 204, "+"), gs("S", "medium", "chr2", 10, 5010, "-"),
              gs("P", "annot", "chr1", 1, 50, "+", 0.04), members={"B": "B:e2", "C": "C:e3"},
              discovery=["B", "C"], family="A;B,C"),
        # ref state D: unplaced
        locus("L0000003", gs("D", "low"), gs("P", "annot", "chr2", 5, 400, "+", 0.01), gs("U", ".", flags=["no_call"]),
              members={"B": "B:e3"}, discovery=["B"], family=None),
        # present at base 1 in ref: unplaced
        locus("L0000004", gs("P", "annot", "chr1", 1, 400, "-", 0.03), gs("U", "."), gs("U", "."),
              members={"A": "A:e4"}),
    ]


def test_vcf_encoding(tmp_path, loci, fa):
    vcf, _ = write_vcf(loci, SAMPLES, "A", fa, tmp_path / "pav.vcf.gz")
    v = pysam.VariantFile(str(vcf))
    recs = list(v)
    assert [r.id for r in recs] == ["L0000001", "L0000002"]
    rec = recs[0]
    assert rec.alts == ("<INS:ME:LTR>",) and rec.info["SVTYPE"] == "INS"
    assert [rec.samples[s]["GT"] for s in ("A", "B", "C")] == [(1,), (0,), (None,)]
    assert [rec.samples[s]["ST"] for s in ("A", "B", "C")] == ["P", "E", "D"]
    assert [rec.samples[s]["TR"] for s in ("A", "B", "C")] == ["annot", "high", "low"]
    assert rec.info["AA"] == rec.ref
    assert rec.info["NE"] == 1 and rec.info["SVLEN"] == 5000 and rec.info["FAM"] == "RLG_1"
    assert rec.info["K"] == pytest.approx(0.02) and rec.info["DISC"] == ("A",)
    assert Path(str(vcf) + ".tbi").is_file()
    assert list(v.header.contigs) == ["chr1", "chr2"] and v.header.contigs["chr2"].length == 500
    [note] = [r.value for r in v.header.records if r.key == "LTRpav_POS"]  # the E site's POS
    assert "without a readable TSD copy, the flank junction, to within 1 bp" in note


def test_vcf_pos_conventions(tmp_path, loci, fa):
    vcf, _ = write_vcf(loci, SAMPLES, "A", fa, tmp_path / "pav.vcf.gz")
    r1, r2 = list(pysam.VariantFile(str(vcf)))
    assert r1.pos == 100 and r1.ref == "ACGT"[99 % 4]  # present: POS = start - 1
    assert r2.pos == 204 and r2.ref == "ACGT"[203 % 4]  # E: last base of the site copy
    assert r2.info["K"] == pytest.approx(0.04) and "AA" in r2.info and r2.info["DISC"] == ("B", "C")
    assert r2.info["FAM"] == "A%3BB%2CC"
    assert r1.stop == r1.pos
    assert [r2.samples[s]["GT"] for s in "ABC"] == [(0,), (1,), (1,)]


def test_unplaced_side_file(tmp_path, loci, fa):
    vcf, unp = write_vcf(loci, SAMPLES, "A", fa, tmp_path / "pav.vcf.gz")
    rows = [ln.split("\t") for ln in Path(unp).read_text().splitlines()]
    assert rows[0] == ["lid", "ref_state", "reason"]
    assert [r[:2] for r in rows[1:]] == [["L0000003", "D"], ["L0000004", "P"]]
    assert "L0000003" not in [r.id for r in pysam.VariantFile(str(vcf))]


@pytest.mark.skipif(shutil.which("bcftools") is None, reason="bcftools missing")
def test_bcftools_reads_vcf(tmp_path, loci, fa):
    vcf, _ = write_vcf(loci, SAMPLES, "A", fa, tmp_path / "pav.vcf.gz")
    out = subprocess.run(["bcftools", "view", "-H", str(vcf)], capture_output=True, text=True, check=True)
    assert len(out.stdout.splitlines()) == 2
    q = subprocess.run(["bcftools", "query", "-f", "%ID\t[%GT ]\n", str(vcf)], capture_output=True, text=True,
                       check=True)
    assert q.stdout.splitlines()[0].split("\t")[1].split() == ["1", "0", "."]


def test_tracks(tmp_path, loci):
    write_tracks(loci, SAMPLES, tmp_path, ORDER, LENGTHS)
    lines = (tmp_path / "A.pav.gff3").read_text().splitlines()
    assert lines[0] == "##gff-version 3"
    assert lines[1] == "##sequence-region chr1 1 1000" and not lines[2].startswith("##")  # only seqids used
    feats = [ln.split("\t") for ln in lines if not ln.startswith("#")]
    assert [f[2] for f in feats] == ["LTR_retrotransposon", "LTR_retrotransposon", "insertion_site"]
    assert feats[0][:8] == ["chr1", "LTRpav", "LTR_retrotransposon", "1", "400", ".", "-", "."]  # sorted by start
    byid = {dict(kv.split("=") for kv in f[8].split(";"))["ID"]: f for f in feats}
    attrs = dict(kv.split("=", 1) for kv in byid["L0000001"][8].split(";"))
    assert attrs["states"] == "A:P,B:E,C:D" and attrs["state"] == "P" and attrs["tier"] == "annot"
    assert byid["L0000002"][2] == "insertion_site"
    assert "family=A%3BB%2CC" in byid["L0000002"][8]  # escaped ; and ,
    gb = [ln.split("\t") for ln in (tmp_path / "C.pav.gff3").read_text().splitlines() if not ln.startswith("#")]
    assert [f[2] for f in gb] == ["LTR_retrotransposon"]  # D without coordinates and U are omitted
    bed = [ln.split("\t") for ln in (tmp_path / "A.pav.bed").read_text().splitlines()]
    assert bed[0] == ["chr1", "0", "400", "L0000004", "0", "-", "P", "annot", "RLG_1"]
    b = [ln.split("\t") for ln in (tmp_path / "B.pav.bed").read_text().splitlines()]
    assert ["chr1", "49", "54", "L0000001", "0", "+", "E", "high", "RLG_1"] in b
    assert any(r[3] == "L0000003" and r[8] == "." for r in b)
    assert (tmp_path / "B.pav.gff3").read_text().count("deletion_junction") == 0


def test_tracks_deletion_junction(tmp_path):
    ls = [locus("L0000001", gs("P", "annot", "chr1", 5, 50, "+"), gs("D", "high", "chr2", 7, 8, "+"), gs("U", "."))]
    write_tracks(ls, SAMPLES, tmp_path, ORDER, LENGTHS)
    assert "deletion_junction" in (tmp_path / "B.pav.gff3").read_text()


def test_matrix_and_loci_tsv(tmp_path, loci):
    write_pav_matrix(loci, SAMPLES, tmp_path / "m.tsv")
    m = [ln.split("\t") for ln in (tmp_path / "m.tsv").read_text().splitlines()]
    assert m[0] == ["lid", "A", "B", "C"] and m[1] == ["L0000001", "P", "E", "D"]
    write_loci_tsv(loci, SAMPLES, tmp_path / "l.tsv")
    rows = [ln.split("\t") for ln in (tmp_path / "l.tsv").read_text().splitlines()]
    head = rows[0]
    assert head[:9] == ["lid", "family", "superfamily", "clade", "length", "ltr_len", "tsd", "discovery", "flags"]
    assert head[9:18] == ["A_eid", "A_state", "A_tier", "A_seqid", "A_start", "A_end", "A_strand", "A_k", "A_flags"]
    r = dict(zip(head, rows[1], strict=True))
    assert r["A_eid"] == "A:e1" and r["B_eid"] == "." and r["A_k"] == "0.02" and r["B_k"] == "."
    assert r["flags"] == "." and r["C_state"] == "D" and r["B_start"] == "50"
    r3 = dict(zip(head, rows[3], strict=True))
    assert r3["family"] == "." and r3["C_flags"] == "no_call" and r3["discovery"] == "B"
    r2 = dict(zip(head, rows[2], strict=True))
    assert r2["discovery"] == "B,C"


def test_qc(tmp_path):
    write_qc([("all", "n_loci", 4), ("all", "frac", 0.123456789)], tmp_path / "qc.tsv")
    assert (tmp_path / "qc.tsv").read_text().splitlines() == ["scope\tmetric\tvalue", "all\tn_loci\t4",
                                                              "all\tfrac\t0.123457"]


def test_manifest(tmp_path):
    t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
    write_manifest(tmp_path / "manifest.json", ["ltrpav", "run"], {"threads": 4}, SAMPLES,
                   {"A": {"fasta": "abc"}}, t0, t0)
    m = json.loads((tmp_path / "manifest.json").read_text())
    assert m["tool"] == "ltrpav" and m["command"] == ["ltrpav", "run"] and m["params"] == {"threads": 4}
    assert m["samples"][0]["label"] == "A" and m["samples"][0]["checksums"] == {"fasta": "abc"}
    assert m["samples"][1]["checksums"] == {}
    assert m["started"].startswith("2026-01-01") and "pysam" in m["dependencies"] and "host" in m


def test_deterministic(tmp_path, loci, fa):
    outs = []
    for d in ("x", "y"):
        o = tmp_path / d
        o.mkdir()
        write_loci_tsv(loci, SAMPLES, o / "loci.tsv")
        write_pav_matrix(loci, SAMPLES, o / "m.tsv")
        write_qc([("all", "n", 1)], o / "qc.tsv")
        write_vcf(loci, SAMPLES, "A", fa, o / "pav.vcf.gz")
        write_tracks(loci, SAMPLES, o, ORDER, LENGTHS)
        outs.append(o)
    names = sorted(p.name for p in outs[0].iterdir())
    assert "pav.vcf.gz" in names and "A.pav.gff3" in names
    for n in names:
        assert (outs[0] / n).read_bytes() == (outs[1] / n).read_bytes(), n


def test_tracks_follow_fai_order_and_escape_bed_columns(tmp_path):
    """Rows in the genome's FASTA index order (chr10 before chr2 here, against lexicographic
    order); a family with a tab or newline cannot break a BED line; an unknown seqid is a clear error."""
    order = {g: {"chr10": 0, "chr2": 1} for g in "ABC"}
    lengths = {g: {"chr10": 9000, "chr2": 9000} for g in "ABC"}
    ls = [locus("L0000001", gs("P", "annot", "chr2", 5, 50, "+"), gs("U", "."), gs("U", "."), family="a\tb\nc"),
          locus("L0000002", gs("P", "annot", "chr10", 900, 950, "+"), gs("U", "."), gs("U", "."))]
    write_tracks(ls, SAMPLES, tmp_path, order, lengths)
    bed = [ln.split("\t") for ln in (tmp_path / "A.pav.bed").read_text().splitlines()]
    assert [r[0] for r in bed] == ["chr10", "chr2"] and len(bed) == 2
    assert bed[1][8] == "a%09b%0Ac" and all(len(r) == 9 for r in bed)
    gff = (tmp_path / "A.pav.gff3").read_text().splitlines()
    assert gff[1:3] == ["##sequence-region chr10 1 9000", "##sequence-region chr2 1 9000"]
    bad = [locus("L0000003", gs("P", "annot", "chrX", 5, 50, "+"), gs("U", "."), gs("U", "."))]
    with pytest.raises(ValueError, match="L0000003: A's seqid 'chrX' is not in A's FASTA index"):
        write_tracks(bad, SAMPLES, tmp_path, order, lengths)
