# Task 1 report

Status: DONE. Commit ed1e53a "Scaffold package, environment and CI" (branch plan1-engine, no trailers).

Implemented: pyproject.toml, environment.yml, environment.lock.yml, LICENSE (copied from LTRquest), README.md,
.gitignore (exact entries), .github/workflows/ci.yml, src/ltrpav/{__init__,constants}.py, tests/test_smoke.py,
DESIGN.md section 12 subsection "Build decisions (plan 1)" (six numbered items, inserted before section 13; nothing else changed).

TDD: RED = `mamba run -n ltrpav pytest -q` with src/ltrpav moved aside: 2 FAILED, ModuleNotFoundError: No module named 'ltrpav'
(expected, package absent). GREEN = same command with package restored: `..  [100%]` (2 passed).
Ruff: first check flagged I001 (missing second blank line in the brief's test file; formatting only); fixed with `ruff check --fix`,
now clean. Initial commit was amended to include the fix.

Installed versions: python 3.12.16, numpy 2.5.4, numba 0.68.1, pysam 0.24.1, mappy 2.31, minimap2 2.31-r1302,
fastga 1.5.20260729, blast 2.17.0, lastz 1.04.60, bcftools 1.25. All pinned versions were available; no substitutions.

Concerns / notes:
- environment.lock.yml ends with `prefix: /home/chris/...` and lists the editable install as `ltrpav==0.1.0.dev0` under pip
  (not installable from PyPI); left as exported.
- The brief's test file needed one added blank line for ruff (I001).
- Task 25 / CI: ci.yml `push` trigger is on branch `main` per LTRquest; repo has only plan1-engine for now.
