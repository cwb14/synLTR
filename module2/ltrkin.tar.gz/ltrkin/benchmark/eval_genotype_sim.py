#!/usr/bin/env python3
"""Score `ltrkin genotype` and Sniffles2 --genotype-vcf against the planted truth of sim_genotype_truth.py.

Reads, under the benchmark directory (-d, laid out by run_genotype_bench.sh):
  truth/truth.tsv, ltrkin/<tech>_d<depth>.<mode>.{genotypes.tsv,log,time}, sniffles/<tech>_d<depth>.<mode>.{vcf,time},
  bam/<tech>_d<depth>.full.bam (independent depth check).
Scoring (planted sites; truth F/F, F/E, F/S, F/N, and 'other' = F/N or F/F):
  call     ltrkin genotype; N/N is a no-call (written ./. in ltrkin's VCF). Sniffles2: its two DEL records combined
           (empty 0/0 + solo 0/0 -> F/F; empty 0/1 -> F/E; solo 0/1 -> F/S; 1/1 -> E/E or S/S; both alt -> S/E;
           both ./. -> no-call). GQ: of the alt record(s); F/F takes the lower of the two.
  conc_all   correct calls / planted sites, no GQ filter (no-calls count as wrong)
  conc_gq20  correct / calls with GQ >= 20;  call_rate_gq20 = calls with GQ >= 20 / planted sites
  per class: recall = correct / sites of the truth class; precision = correct / calls of that genotype
Writes to -o: calls.tsv, summary.tsv, by_class.tsv, precision.tsv, strata.tsv, confusion.tsv, context.tsv,
depth_check.tsv, report.md.
"""
import argparse
import glob
import os
import random
import re
import sys

import numpy as np
import pandas as pd
import pysam

ALLOWED = {"F/F": {"F/F"}, "F/E": {"F/E"}, "F/S": {"F/S"}, "F/N": {"F/N"}, "F/N|F/F": {"F/N", "F/F"}}
CLASS = {"F/F": "F/F", "F/E": "F/E", "F/S": "F/S", "F/N": "F/N (hemi)", "F/N|F/F": "other"}
CLASS_ORDER = ["F/F", "F/E", "F/S", "F/N (hemi)", "other"]
NOCALL = {"./.", "N/N"}


def log(msg):
    print(f"[eval_genotype_sim] {msg}", file=sys.stderr, flush=True)


def parse_name(path, suffix):
    b = os.path.basename(path)[: -len(suffix)]
    m = re.fullmatch(r"(hifi|ont)_d(\d+)\.(full|primary)", b)
    return (m.group(1), int(m.group(2)), m.group(3)) if m else None


def parse_time(path):
    d = {}
    if not os.path.exists(path):
        return d
    for ln in open(path):
        ln = ln.strip()
        if ln.startswith("Elapsed (wall clock) time"):
            v = ln.rsplit(" ", 1)[-1].split(":")
            d["wall_s"] = sum(float(x) * 60 ** i for i, x in enumerate(reversed(v)))
        elif ln.startswith("Maximum resident set size"):
            d["max_rss_gb"] = int(ln.rsplit(" ", 1)[-1]) / 1024 ** 2
        elif ln.startswith("User time"):
            d["user_s"] = float(ln.rsplit(" ", 1)[-1])
        elif ln.startswith("System time"):
            d["sys_s"] = float(ln.rsplit(" ", 1)[-1])
    if "user_s" in d:
        d["cpu_s"] = d.pop("user_s") + d.pop("sys_s", 0.0)
    return d


def ltrkin_runs(d):
    rows, calls = [], []
    for p in sorted(glob.glob(os.path.join(d, "ltrkin", "*.genotypes.tsv"))):
        key = parse_name(p, ".genotypes.tsv")
        if not key:
            continue
        tech, depth, mode = key
        g = pd.read_csv(p, sep="\t", dtype={"genotype": str, "flags": str})
        info = dict(tool="ltrkin", tech=tech, depth=depth, mode=mode)
        lg = p.replace(".genotypes.tsv", ".log")
        if os.path.exists(lg):
            for ln in open(lg):
                m = re.search(r"depth(?: mode)? ([\d.]+) \(per haplotype ([\d.]+)\), NB size (\d+), mean read span (\d+) bp, "
                              r"error ([\d.]+)", ln)
                if m:
                    info.update(depth_mode=float(m.group(1)), d_hap=float(m.group(2)), nb_k=int(m.group(3)),
                                mean_span=int(m.group(4)), err=float(m.group(5)))
        info.update(parse_time(p.replace(".genotypes.tsv", ".time")))
        rows.append(info)
        c = g[["element_id", "genotype", "gq", "flags", "n_F", "n_E", "n_S", "n_O", "n_U", "n_P", "exp_reads",
               "flank_ratio"]].copy()
        c = c.rename(columns={"genotype": "call"})
        for k, v in info.items():
            if k in ("tool", "tech", "depth", "mode"):
                c[k] = v
        calls.append(c)
    return rows, calls


def read_sniffles_vcf(path):
    recs = {}
    with open(path) as fh:
        for ln in fh:
            if ln.startswith("#"):
                continue
            x = ln.rstrip("\n").split("\t")
            vid = x[2]
            fmt = x[8].split(":")
            val = dict(zip(fmt, x[9].split(":")))
            gq = val.get("GQ", ".")
            recs[vid] = (val.get("GT", "./."), int(gq) if gq not in (".", "") else 0,
                         int(val.get("DR", 0) or 0) if val.get("DR", ".") != "." else 0,
                         int(val.get("DV", 0) or 0) if val.get("DV", ".") != "." else 0)
    return recs


def sniffles_combine(e, s):
    """Combine the empty and solo DEL records of one element into one genotype and GQ."""
    (ge, qe, _, _), (gs, qs, _, _) = e, s
    if ge.startswith(".") and gs.startswith("."):
        return "./.", 0
    ae = 0 if ge.startswith(".") else ge.replace("|", "/").split("/").count("1")
    as_ = 0 if gs.startswith(".") else gs.replace("|", "/").split("/").count("1")
    if ae == 0 and as_ == 0:
        return "F/F", min(qe if not ge.startswith(".") else qs, qs if not gs.startswith(".") else qe)
    if ae and as_:
        return "S/E", min(qe, qs)
    if ae:
        return ("F/E" if ae == 1 else "E/E"), qe
    return ("F/S" if as_ == 1 else "S/S"), qs


def sniffles_runs(d, planted_ids):
    rows, calls = [], []
    for p in sorted(glob.glob(os.path.join(d, "sniffles", "*.vcf"))):
        key = parse_name(p, ".vcf")
        if not key:
            continue
        tech, depth, mode = key
        recs = read_sniffles_vcf(p)
        info = dict(tool="sniffles2", tech=tech, depth=depth, mode=mode)
        info.update(parse_time(p[:-4] + ".time"))
        rows.append(info)
        out = []
        for eid in planted_ids:
            e, s = recs.get(f"{eid}|empty"), recs.get(f"{eid}|solo")
            if e is None or s is None:
                out.append((eid, "./.", 0, "missing_record", e[3] if e else 0, s[3] if s else 0))
                continue
            gt, gq = sniffles_combine(e, s)
            out.append((eid, gt, gq, f"empty={e[0]}:{e[1]}:{e[2]}:{e[3]};solo={s[0]}:{s[1]}:{s[2]}:{s[3]}", e[3], s[3]))
        c = pd.DataFrame(out, columns=["element_id", "call", "gq", "flags", "dv_empty", "dv_solo"])
        c["tool"], c["tech"], c["depth"], c["mode"] = "sniffles2", tech, depth, mode
        calls.append(c)
    return rows, calls


def score(c):
    c = c.copy()
    c["gq"] = pd.to_numeric(c["gq"], errors="coerce").fillna(0)
    c["called"] = ~c["call"].isin(NOCALL)
    c["called20"] = c["called"] & (c["gq"] >= 20)
    c["correct"] = [cl in ALLOWED[t] for cl, t in zip(c["call"], c["truth"])]
    return c


def summarize(c, keys):
    def f(g):
        n = len(g)
        n20 = int(g.called20.sum())
        return pd.Series(dict(n=n, conc_all=g.correct.sum() / n if n else np.nan,
                              conc_called=(g.correct & g.called).sum() / g.called.sum() if g.called.sum() else np.nan,
                              conc_gq20=(g.correct & g.called20).sum() / n20 if n20 else np.nan,
                              call_rate_gq20=n20 / n if n else np.nan,
                              correct_gq20_frac=(g.correct & g.called20).sum() / n if n else np.nan,
                              n_nocall=int((~g.called).sum())))
    return c.groupby(keys).apply(f, include_groups=False).reset_index()


def depth_check(d, truth, n=2000, seed=11):
    """Mode and mean of primary MAPQ>=20 depth at random region positions (outside planted hemizygous deletions), the
    definition ltrkin uses, plus how many of ltrkin's 400 depth points fall in the simulated region."""
    t = truth
    chrom = t.chrom.iloc[0]
    reg0, reg1 = int(t.start.min()) - 1, int(t.end.max())
    hemi = [(int(a) - 1, int(b)) for a, b in zip(t[t.state == "H"].del_start, t[t.state == "H"].del_end)]
    rows = []
    try:
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
        from ltrkin.model import sample_points
        bam0 = sorted(glob.glob(os.path.join(d, "bam", "*.full.bam")))
        L = pysam.AlignmentFile(bam0[0]).get_reference_length(chrom) if bam0 else None
        pts = sample_points({chrom: L}) if L else []
        in_reg = sum(reg0 <= p < reg1 for _, p in pts)
    except Exception as ex:                       # informative only
        log(f"ltrkin sample_points unavailable: {ex}")
        in_reg = None
    rng = random.Random(seed)
    for p in sorted(glob.glob(os.path.join(d, "bam", "*.full.bam"))):
        key = parse_name(p, ".bam")
        if not key:
            continue
        bam = pysam.AlignmentFile(p)
        dep = []
        while len(dep) < n:
            x = rng.randrange(reg0 + 50000, reg1 - 50000)
            if any(a <= x < b for a, b in hemi):
                continue
            k = 0
            for r in bam.fetch(chrom, x, x + 1):
                if not (r.is_unmapped or r.is_secondary or r.is_supplementary) and r.mapping_quality >= 20:
                    k += 1
            dep.append(k)
        dep = np.array(dep)
        vals, cnts = np.unique(dep, return_counts=True)
        sm = np.convolve(cnts, np.ones(3) / 3, mode="same")
        rows.append(dict(tech=key[0], depth=key[1], region_mode_q20=int(vals[np.argmax(sm)]),
                         region_mean_q20=dep.mean(), region_median_q20=float(np.median(dep)),
                         frac_zero_q20=(dep == 0).mean(), ltrkin_points_in_region=in_reg))
    return pd.DataFrame(rows)


def md_table(df, floatfmt="{:.3f}"):
    cols = list(df.columns)
    out = ["| " + " | ".join(cols) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    for _, r in df.iterrows():
        cells = []
        for c in cols:
            v = r[c]
            if isinstance(v, float):
                cells.append("" if np.isnan(v) else floatfmt.format(v))
            else:
                cells.append(str(v))
        out.append("| " + " | ".join(cells) + " |")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-d", "--dir", required=True, help="benchmark directory (run_genotype_bench.sh OUTDIR)")
    ap.add_argument("-o", "--out", required=True, help="output directory")
    ap.add_argument("--no-depth-check", action="store_true", help="skip the independent BAM depth check")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    truth = pd.read_csv(os.path.join(a.dir, "truth", "truth.tsv"), sep="\t", dtype=str)
    for k in ("start", "end", "length", "nn_dist"):
        truth[k] = truth[k].astype(int)
    truth["neighbor"] = pd.cut(truth.nn_dist, [-1, 999, 9999, 10 ** 9], labels=["<1kb", "1-10kb", ">=10kb"]).astype(str)
    planted = truth[truth.category == "planted"].copy()
    planted["truth_class"] = planted.truth.map(CLASS)
    lr, lc = ltrkin_runs(a.dir)
    sr, sc = sniffles_runs(a.dir, list(planted.element_id))
    runs = pd.DataFrame(lr + sr)
    if runs.empty:
        sys.exit("no runs found")
    allc = pd.concat(lc + sc, ignore_index=True)
    keys = ["tool", "tech", "depth", "mode"]
    pc = allc.merge(planted[["element_id", "truth", "truth_class", "state", "length", "len_bin", "age_bin", "K2P_d",
                             "neighbor", "tsd_len", "ltr5_len", "family"]], on="element_id", how="inner")
    pc = score(pc)
    n_runs = pc.groupby(keys).size()
    if (n_runs != len(planted)).any():
        log(f"warning: runs with missing planted sites: {n_runs[n_runs != len(planted)].to_dict()}")
    pc.to_csv(os.path.join(a.out, "calls.tsv"), sep="\t", index=False)
    summ = summarize(pc, keys).merge(runs, on=keys, how="left")
    summ = summ.sort_values(["tech", "depth", "tool", "mode"], ascending=[True, False, True, True])
    summ.to_csv(os.path.join(a.out, "summary.tsv"), sep="\t", index=False)
    bycls = summarize(pc, keys + ["truth_class"]).rename(columns={"conc_all": "recall_all",
                                                                  "correct_gq20_frac": "recall_gq20"})
    bycls.to_csv(os.path.join(a.out, "by_class.tsv"), sep="\t", index=False)
    prec = []
    for k, g in pc.groupby(keys):
        for gt in sorted(set(g.call) - NOCALL):
            x = g[g.call == gt]
            x20 = x[x.called20]
            prec.append(dict(zip(keys, k), call=gt, n_called=len(x), precision_all=x.correct.mean(),
                             n_called_gq20=len(x20), precision_gq20=x20.correct.mean() if len(x20) else np.nan))
    prec = pd.DataFrame(prec)
    prec.to_csv(os.path.join(a.out, "precision.tsv"), sep="\t", index=False)
    strata = []
    for col in ("len_bin", "age_bin", "neighbor"):
        s = summarize(pc, keys + [col]).rename(columns={col: "stratum"})
        s.insert(4, "variable", col)
        strata.append(s)
    strata = pd.concat(strata, ignore_index=True)
    strata.to_csv(os.path.join(a.out, "strata.tsv"), sep="\t", index=False)
    # allele detection: does the call contain an empty (E) or solo (S) allele where the truth has one? (ltrkin source
    # calls a copy "new" when any sample carries an E allele at GQ >= 20)
    det = []
    for k, g in pc.groupby(keys):
        for al, tcls in (("E", "F/E"), ("S", "F/S")):
            has_t = g.truth_class == tcls
            for lab, sel in (("all", g.called), ("gq20", g.called20)):
                has_c = sel & g.call.str.contains(al)
                tp, fp, fn = int((has_t & has_c).sum()), int((~has_t & has_c).sum()), int((has_t & ~has_c).sum())
                det.append(dict(zip(keys, k), allele=al, filter=lab, tp=tp, fp=fp, fn=fn,
                                recall=tp / (tp + fn) if tp + fn else np.nan,
                                precision=tp / (tp + fp) if tp + fp else np.nan))
    det = pd.DataFrame(det)
    det.to_csv(os.path.join(a.out, "allele_detection.tsv"), sep="\t", index=False)
    # ltrkin flags: are flagged calls less accurate? (one row per flag; a call can carry several)
    fl = []
    for k, g in pc[pc.tool == "ltrkin"].groupby(keys):
        f = g["flags"].fillna("PASS").astype(str)
        for flag in sorted({x for v in f for x in v.split(",")}):
            sel = f.str.split(",").apply(lambda v: flag in v)
            fl.append(dict(zip(keys, k), flag=flag, n=int(sel.sum()), conc_all=g[sel].correct.mean(),
                           n_wrong=int((~g[sel].correct).sum())))
    pd.DataFrame(fl).to_csv(os.path.join(a.out, "flags.tsv"), sep="\t", index=False)
    # GQ calibration: observed error vs the error the GQ claims (mean of 10^(-GQ/10)) per GQ bin, called sites
    cal = []
    bins = [(0, 10), (10, 20), (20, 30), (30, 60), (60, 99), (99, 100)]
    for k, g in pc[pc.called].groupby(keys):
        for lo, hi in bins:
            x = g[(g.gq >= lo) & (g.gq < hi)]
            if len(x):
                cal.append(dict(zip(keys, k), gq_bin=f"{lo}-{hi - 1}", n=len(x), error=1 - x.correct.mean(),
                                claimed_error=float(np.mean(10 ** (-x.gq / 10)))))
    pd.DataFrame(cal).to_csv(os.path.join(a.out, "gq_calibration.tsv"), sep="\t", index=False)
    conf = pc.groupby(keys + ["truth_class", "call"]).size().rename("n").reset_index()
    conf.to_csv(os.path.join(a.out, "confusion.tsv"), sep="\t", index=False)
    # context: unplanted elements left full on both haplotypes (truth F/F); ltrkin only
    ctx = truth[(truth.category != "planted") & (truth.hap2_state == "F")].copy()
    ctx["ctx"] = np.where(ctx.category == "context_nested", "nested", "unplanted, not nested")
    ctx["truth"] = "F/F"
    cc = pd.concat(lc, ignore_index=True).merge(ctx[["element_id", "ctx", "truth", "len_bin", "age_bin"]],
                                                 on="element_id", how="inner") if lc else pd.DataFrame()
    if len(cc):
        cc = score(cc)
        cs = summarize(cc, keys + ["ctx"])
        nonref = cc[cc.called20 & (cc.call != "F/F")].groupby(keys + ["ctx", "call"]).size().rename("n").reset_index()
        cs.to_csv(os.path.join(a.out, "context.tsv"), sep="\t", index=False)
        nonref.to_csv(os.path.join(a.out, "context_nonref_calls.tsv"), sep="\t", index=False)
    dc = pd.DataFrame() if a.no_depth_check else depth_check(a.dir, truth)
    if len(dc):
        dc = dc.merge(summ[(summ.tool == "ltrkin") & (summ["mode"] == "full")][["tech", "depth", "depth_mode",
                                                                                 "d_hap", "err", "mean_span"]],
                      on=["tech", "depth"], how="left")
        dc.to_csv(os.path.join(a.out, "depth_check.tsv"), sep="\t", index=False)
    # report
    R = ["# Simulated-reads genotype benchmark: tables", "",
         f"Planted sites: {len(planted)} ({', '.join(f'{k} {v}' for k, v in planted.truth_class.value_counts().reindex(CLASS_ORDER).items())}).", ""]
    cols = ["tool", "tech", "depth", "mode", "n", "conc_all", "conc_gq20", "call_rate_gq20", "n_nocall"]
    extra = [c for c in ("depth_mode", "err", "mean_span", "wall_s", "max_rss_gb") if c in summ.columns]
    R += ["## Summary (planted sites)", "", md_table(summ[cols + extra]), ""]
    for depth in sorted(pc.depth.unique(), reverse=True):
        b = bycls[bycls.depth == depth]
        piv = b.pivot_table(index=["tool", "tech", "mode"], columns="truth_class", values="recall_all").reindex(
            columns=CLASS_ORDER).reset_index()
        R += [f"## Recall by truth class, all calls ({depth}x)", "", md_table(piv), ""]
        piv = b.pivot_table(index=["tool", "tech", "mode"], columns="truth_class", values="recall_gq20").reindex(
            columns=CLASS_ORDER).reset_index()
        R += [f"## Recall by truth class, GQ >= 20 ({depth}x)", "", md_table(piv), ""]
        p = prec[prec.depth == depth]
        if len(p):
            pv = p.pivot_table(index=["tool", "tech", "mode"], columns="call", values="precision_all").reset_index()
            R += [f"## Precision by called genotype, all calls ({depth}x)", "", md_table(pv), ""]
        s = strata[strata.depth == depth]
        sv = s.pivot_table(index=["tool", "tech", "mode"], columns=["variable", "stratum"], values="conc_all")
        sv.columns = [f"{v}:{st}" for v, st in sv.columns]
        R += [f"## Concordance (all calls) by stratum ({depth}x)", "", md_table(sv.reset_index()), ""]
    R += ["## Empty / solo allele detection (planted sites)", "",
          md_table(det.sort_values(["allele", "filter", "tech", "depth", "tool", "mode"],
                                   ascending=[True, True, True, False, True, True])), ""]
    nstr = planted.groupby(["len_bin"]).size().to_dict()
    R += [f"Stratum sizes: length {nstr}; age {planted.age_bin.value_counts().to_dict()}; nearest element "
          f"{planted.neighbor.value_counts().to_dict()}", ""]
    if len(cc):
        R += ["## Context elements (truth F/F, ltrkin)", "", md_table(cs), ""]
    if len(dc):
        R += ["## Depth model check", "", md_table(dc), ""]
    open(os.path.join(a.out, "report.md"), "w").write("\n".join(R) + "\n")
    log(f"{len(runs)} runs scored; tables in {a.out}")


if __name__ == "__main__":
    main()
