"""User-facing output files: TSV tables, VCF, GFF3/BED tracks and the run manifest."""
