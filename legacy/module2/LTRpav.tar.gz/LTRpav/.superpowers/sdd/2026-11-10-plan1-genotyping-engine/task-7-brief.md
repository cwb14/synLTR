### Task 7: BED reader with LTR finding

**Files:** Create `src/ltrpav/annotation/bed.py`, `tests/test_annot_bed.py`

**Interfaces:**
- Produces: `find_ltrs(seq: str) -> tuple[int, int] | None` (left and right LTR lengths);
  `load_bed(path: Path, genome: str, fasta: Fasta) -> tuple[list[Element], Counter]`.

- [ ] **Step 1: Write the failing tests**

```python
def test_find_ltrs_planted():
    rng = random.Random(1); ltr = toy.rand_seq(400, rng); el = ltr + toy.rand_seq(3000, rng) + toy.mutate(ltr, 0.005, rng)
    l5, l3 = find_ltrs(el); assert abs(l5 - 400) <= 5 and abs(l3 - 400) <= 5

def test_find_ltrs_random_is_none():
    assert find_ltrs(toy.rand_seq(4000, random.Random(2))) is None

def test_load_bed(tmp_path): ...   # 0-based BED start -> 1-based Element.start; strand col 6 optional; no-LTR row skipped
```

(`tests/toy.py` is created in this task with `rand_seq(n, rng)` and `mutate(seq, rate, rng)`; Task 12 extends it.)
- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement `find_ltrs`.**
  - `n = min(len(seq)//2, 6000)`. Index `seq[-n:]` with `mappy.Aligner(seq=..., preset="asm20")` and map `seq[:n]`.
  - Accept a `+` hit with `q_st <= 20`, `r_en >= n - 20`, `mlen/blen >= COV_PRESENT` and both lengths `>= MIN_SEG`.
  - Return `(hit.q_en, n - hit.r_st)`.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add BED reader with LTR self-alignment"`.

---

