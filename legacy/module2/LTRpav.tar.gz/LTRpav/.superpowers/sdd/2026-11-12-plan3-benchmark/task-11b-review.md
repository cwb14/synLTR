# Re-review (fix round 2)

Date: 2026-11-14. Scope: I1-I4 and M1-M12, the text the fix changed, and the new or changed probes (claims.py
section 6, fix2_checks.py), under the ledger's "Ruling (I1)", "Ruling (I4)" and "Ruling (I2, I3, M1-M12)". I wrote
nothing but this file. Scratch: `.../scratchpad/p3t11b-review/fix2/` (sim.diff and de.diff against the reviewed versions,
bf876aaf and 477d5aeb; recheck2.py and its output; probes/ copy).

Checked:
- **Files.** Their hashes equal the report's: SIM_RESULTS.md 1f5a0d79 (764 lines), dead_ends.md 84d81362 (395 lines;
  lines 1-213 byte-identical to the pre-task copy), probes SHA256SUMS f7274c91 (12 of 12 OK). RULES.md is still
  4111826d. LTRpav git is clean, and no file in runs/ or lq/ is newer than rescore.done.
- **Probes.** A scratch copy of the updated rerun.sh (5 commands, absolute SIM) reproduces perrun.tsv, calib_truth.tsv,
  calib_truth.log, qprobe.tsv, claims.txt and fix2_checks.txt byte-identically in 37 s.
- **New numbers.** recheck2.py recomputes them from eval.json and eval_ltrmix.json, not from perrun.tsv, and every one
  agrees:
  - McNemar exact, with discordant runs 18, 14, 10 and 4 against 0: D_ins 7.6e-6, D_kmer 1.2e-4, D_self_outgroup
    0.002, D3_triples 0.12 (sister-discovered truth D 0.12).
  - Null quantiles: default SD 0.717, max |Z| 1.97, 95th percentile 1.36; bottleneck 1.294, 3.14, 2.74; dropout 1.061,
    2.79, 2.29.
  - Head-to-head AUROC sign tests: 22 of 29 (p 0.0081) and 23 of 29 (p 0.0023).
  - LTRmix B1-C1 pairs: 1,341 per null.
  - nodonor hits that used A2: Z 3.19 and 3.38.
  - Annotation completeness: 0.802, 0.599 and 0.900 (my first review found the same from eval.json's realism block).
  - Also checked: the F-tests (p 0.0022, 0.056, 0.55), chi-square p 0.029, CP 0 of 35 = 0.10003 and 0 of 36 = 0.0974.
- **Citations.** Both resolve on Crossref (DOI) and Europe PMC (PMID), and title, authors, journal, volume and pages
  match the text:
  - Patterson et al. 2012, Genetics 192(3):1065-1093, doi 10.1534/genetics.112.145037, PMID 22960212;
  - Günther and Nettelblad 2019, PLoS Genet 15(7):e1008302, doi 10.1371/journal.pgen.1008302, PMID 31348818.

  Each characterization agrees with the abstract: a SNP array with known ascertainment; reference bias that skews
  allele-sharing and archaic-ancestry estimates. The novelty for transposon insertions is marked unverified
  (SIM_RESULTS.md:759-761).

## Per-finding verdicts

| finding | verdict | where |
|---|---|---|
| I1 rule 7 causes | ADDRESSED | SIM_RESULTS.md:319-328, :345-380, :708-712; dead_ends.md:351-395. C1>A1 is a design and prediction mismatch at any genome size; A1>C1 lacks loci at 50 Mb; the posctl nulls are vacuous; 3 untested causes labeled; "names no direction when any Z is undefined"; no code change (Ruling (I1)). The derivation checks out: empty classes are DFO, DIL, DFI in quartet A1,A2;C1,C2 and DFO, DFI, DOL in C1,C2;A1,A2 (fix2_checks.txt:63-70). |
| I2 discovery vs genotyping | ADDRESSED | SIM_RESULTS.md:435-441, :740-743 |
| I3 dropout levels | ADDRESSED | SIM_RESULTS.md:23, :408-409, :414, :737-738, :748; the change at :752 ("already at a 10-point gap") is justified (D_ins -4.95 vs -5.31) |
| I4 Task 16 null | ADDRESSED | SIM_RESULTS.md:93-97; dead_ends.md:229-233, :261-263; matches Ruling (I4) |
| M1 CP 36 | ADDRESSED | SIM_RESULTS.md:255-256; dead_ends.md:337-339 |
| M2 McNemar | ADDRESSED | SIM_RESULTS.md:411-413, :739-740; claims.py section 6. The code is a correct exact McNemar test: two-sided binomial test on the discordant runs, the same 20 null runs for both statistics. |
| M3 matching cell | ADDRESSED | SIM_RESULTS.md:446-448 |
| M4 dropout nulls, multiplicity | ADDRESSED | SIM_RESULTS.md:131-142; dead_ends.md:244-253, :257-259 |
| M5 hypothesis | ADDRESSED | SIM_RESULTS.md:299-300; dead_ends.md:291-293 |
| M6 no-call specificity | ADDRESSED | SIM_RESULTS.md:83-84, :319-327 |
| M7 pairs, whose fit | ADDRESSED | SIM_RESULTS.md:580-583, :607-608 |
| M8 nodonor A2 | ADDRESSED | SIM_RESULTS.md:668-670, :693-694 |
| M9 wrong trios, paired test | ADDRESSED | SIM_RESULTS.md:190-194, :208, :217-219 (see N1) |
| M10 terms, breaks | ADDRESSED | SIM_RESULTS.md:39-42, :173-175, :250-252, :570-571; dead_ends.md:240-241; reflowed :238-243, dead_ends.md:302 |
| M11 headings | ADDRESSED | dead_ends.md:325-328 |
| M12 precedent | ADDRESSED | SIM_RESULTS.md:755-761; citations verified above |

## New issues from the fix (all Minor)

- **N1. The new wrong-trio sentence names only LTRpav's drag** (SIM_RESULTS.md:217-218).
  - LTRmix's own 6 wrong trios are also A1,C1;B1, at f 0.25-0.50, and pull its AUROC down further (0.0002-0.20).
  - Leaving out each tool's wrong-trio runs, the means are LTRpav 0.72 (26 runs) and LTRmix 0.90 (25 runs), so the
    gap widens. Role inference does not explain it.
  - Fix: add one clause saying this.
- **N2. "Or predictions made with LTRpav's own testability rule" (dead_ends.md:390-391) is a hollow remedy.** Alone, it
  would let the C1>A1 control be re-predicted "none" and pass without testing direction. Make it "and", as the Plan 4
  lead at SIM_RESULTS.md:710-711 already says: "pre-registered with LTRpav's own testability rule". The "or" came from
  my own suggested wording in I1.
- **N3. Nits.**
  - pc_A1C1_r2's DOL Z is -0.79, not 0.79 (SIM_RESULTS.md:364; dead_ends.md:370).
  - The both-nulls, bottleneck-verdict rule comes from Ruling (I4), not from the plan's Task 16 Step 2, whose text only
    asks for an empirical quantile. Cite the ruling beside it (SIM_RESULTS.md:96; dead_ends.md:232).

## Out of scope

- Untouched closing line, SIM_RESULTS.md:763-764: "direction test ... limited at 50 Mb" no longer matches I1, which
  says the C1>A1 limit holds at any genome size. Optional wording change.

## Assessment (fix round 2)

**Approved.** All of I1-I4 and M1-M12 are addressed. Every new number reproduces from the eval files, the probes rerun
byte-identically, and both citations resolve. N1-N3 are minor and can be fixed in passing. No verdict or Part C
decision changed.

---

# Task 11 Part B review: SIM_RESULTS.md, dead_ends.md (Task 11 section), lq_compare, probes

Date: 2026-11-14. Reviewer read-only on benchmark_pav/ and the repo (this file is the only write). Scratch:
`/tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3t11b-review`
(recompute.py + recompute.out, probes/ copy, lq_compare.tsv).

Reviewed (sha256): SIM_RESULTS.md bf876aaf... (702 lines, = the report's last hash); dead_ends.md 477d5aeb...;
lq_compare.py cc5dbba3...; tables/lq_compare.tsv e2728639...; probes/task11/SHA256SUMS 9fbe91b8... (10 of 10 OK);
RULES.md 4111826d...a293 (unchanged). LTRpav `git status` clean; no file in runs/ or lq/ newer than rescore.done.

What I ran:
- `recompute.py`: every bar and reading recomputed from the 144 runs' eval.json and eval_ltrmix.json, not from tables.
- A copy of probes/task11 with an absolute SIM path: perrun.tsv, calib_truth.tsv, calib_truth.log, qprobe.tsv and
  claims.txt came out byte-identical to the originals (41 s).
- `lq_compare.py -o <scratch>`: byte-identical (e2728639...); lq_compare numbers spot-checked against lq/ eval files.
- Source reads: snap direction.py and common.why (testability rule), probe_direction.py (prediction Z),
  direction_counts.tsv, snap sim/pop.py `dropout_of`, posctl per-pair score files; F, chi-square and McNemar tests.

## Spec compliance

- ✅ Sections 1-11, Plan 4 leads and the headline (SIM_RESULTS.md:86-702).
- ✅ Every bar PASS or MISS with numbers, n and source table (:54-84); totals PASS 9 / MISS 7 match the rulings (:46).
- ✅ Rule 2 as readings: 7 calibrated, D_pav not calibrated, dD not demonstrated (:49-52, :57-65; ruling (rule 2)).
- ✅ Rule 8 read "reproduces", outside the count (:47-48, :84, :514; ruling (rule 8)).
- ✅ Rule 5 no-calls FAIL for `any` and `decoy` (:71, :74; ruling "Rule 5 with no calls"); vacuous precision PASS
  wording (:73, :76).
- ✅ PA head-to-head binary first, strict E-only beside it, G excluded and counted, genotype.tsv's ltrmix rows labeled
  strict (:476-491).
- ✅ LTRmix absent-but-present calls library first; the pilot's 62% restated as not-E, truly present 38-39% (:494-508).
- ✅ Section 10 names all seven gaps with effects and says once, plainly, that simulated power is optimistic beyond
  the locus-count projection (:566-614).
- ✅ Section 11: nodonor on its own, Task 14's zd case, rule unchanged, the user decides (:616-646).
- ✅ Section 5 covers predictions, observed codes, posctl, false calls, PT-like, D_dir against its null (:302-364).
  The cause analysis needs fixing (I1).
- ✅ Headline sentence, mechanism, generality (tested vs assumed), predictions (:675-702). Accuracy issues I2, I3, M2.
- ✅ lq_compare.py and tables/lq_compare.tsv: all requested rows present, ltrmix_absent "not attributed" noted,
  read-only, reconciles with the eval files, reruns byte-identically.
- ✅ dead_ends.md: one entry per MISS (7) plus the two readings, five headings each (dead_ends.md:215-364); one entry
  merges two headings (M11). Earlier sections byte-identical to the pre-task copy (213 lines, e3ff2aa6).
- ✅ Probes durable in sim/probes/task11/ and cited; rerun.sh reproduces them.
- ✅ Untested s and D causes listed as Plan 4 leads (:556-562, :648-673).
- ✅ American English; no AI attribution.
- ✅ Misses investigated with truth D and genotype scores. The entries cite pooled precision; I checked the posctl per-pair
  scores (3 runs, all pairs P and E high-tier precision >= 0.987), which agree.
- ⚠️ "Save after each section": not verifiable after the fact.

## Verdict table check

Recomputed from the per-run eval files (recompute.out); every row agrees.

| rule | item | reported | recomputed | |
|---|---|---|---|---|
| 1 | D_pav, 30 nulls | PASS, 0 of 30, CP 0-0.116 | 0 of 30, 0 NA, CP 0-0.1157 | agree |
| 1 | reported counts | truth D x3, LTRmix x4, nodonor 0/30; bneck D_pav 1/30, D_self_outgroup 1/30 | same | agree |
| 2 | D_pav | not calibrated: SD 0.717 (0.571-0.964), mean +0.072 (2 SE 0.262) | same | agree |
| 2 | dD | not demonstrated, 1 of 30 | 1 usable | agree |
| 2 | truth D x3 | calibrated (0.758, 0.859, 0.914) | same | agree |
| 2 | LTRmix x4 | calibrated (0.904, 0.901, 0.822, 1.085) | same on z_A1 (note 1) | agree |
| 3 | P, E high tier | PASS 0.99710, 0.99676 | 10,265,265/10,295,167; 6,580,568/6,601,942 | agree |
| 4 | main | PASS: 0/30; -0.00045 (-0.0036, +0.0027) | same | agree |
| 4 | any | PASS: 0/30, -0.00065; dropout 0/20, -0.00027 | same | agree |
| 4 | decoy | PASS: 0/30, +0.00097 | same | agree |
| 4 | anydecoy | PASS: 0/30, +0.00010; dropout 0/20, +0.0013 | same | agree |
| 5 | any FDR / recall / precision | MISS / MISS / PASS (vacuous) | 0 of 0; +0 -0 of 42 (42 NA); p(lower) 1 | agree |
| 5 | decoy FDR / recall / precision | MISS / MISS / PASS (vacuous) | 0 of 0; 36 NA; p(lower) 1 | agree |
| 5 | anydecoy FDR / recall / precision | MISS / MISS / PASS | 0 of 21, CP upper 0.1611; +1 -0, p 0.5; p(lower) 1 | agree |
| 5 | adoption | default kept | no variant passes all four; decoy-only route off (default holds rule 4); joint route off | agree |
| 6 | degenerate default fits | 7 of 36 (19.4%), no label | 7 of 36 by the flag and by e1_RD, e0_RS | agree |
| 7 | posctl confirmation | MISS, 2 of 8 | 2 of 8 (both posctl nulls, 0 informative loci) | agree |
| 7 | false calls, maize-like, PT-like | 0/30, 0/30; 0 wrong, 0 right of 50; PT-like none | 118 of 118 seven-genome runs "none" | agree |
| 8 | D_ins / D_pav | reproduces: 0.543 (0.430-0.692), 30 of 36 | 0.543 (0.432-0.693, my 20,000 resamples) | agree |

Note 1. LTRmix's own D is oriented toward the sister it calls the recipient; on that orientation D_kmer's null mean is
+0.71 and it would read not calibrated. The A1-oriented Z (z_A1), which summarize.py uses, is the correct null
reading.

Note 2. Rule 5's verdicts do not depend on reading a no-tract run's recall as NA. If it were 0: `any` +0 -1, `decoy`
+0 -1, `anydecoy` +1 -0 (f0.50_Ta500_r1); all still fail.

## The decisions for Part C

Confirmed: no variant is adopted (the default stays `main`); rule 6 reads 7 of 36 (19.4%, not below 10%: no label);
rule 7 is not confirmed, so the direction rows' note changes to "not validated by simulation (Plan 3)" and snapshot 2
follows. None of the issues below changes a verdict or one of these decisions. Part C's DESIGN 7.6 text should state
the rule 7 cause as corrected in I1.

## Strengths

- Every verdict holds under independent recomputation, and the rulings (no-calls FAIL, vacuous PASS, readings outside
  the count) are applied exactly as written.
- The calibration investigation is careful: the label shuffle (jackknife SE = binomial SE), the nested-cluster design
  effect (1.47 predicts 0.059 against 0.062), block sizes 0.25-5 Mb, and the bottleneck variance test together rule
  out genotyping and the jackknife.
- The q-floor probe finds the structural reason rule 5 could not compare variants, and tests it on every run.
- Context numbers are kept apart from rule inputs, and claims.txt prints each one; the probes rerun byte-identically.
- lq_compare.py is minimal and safe: fail-fast reconciliation, an atomic write, read-only.
- The headline is framed as method validation, says it is not a maize finding, and separates tested from assumed
  generality.

## Issues

### Critical
None.

### Important

**I1. Rule 7: the investigation does not separate a design defect from lack of power, and "what would change it" is
wrong for C1>A1** (SIM_RESULTS.md:327-341, :658-660; dead_ends.md:341-364).
- The evidence, by direction:
  - **C1>A1 (3 runs): could not pass at any genome size.** Every Ne is 1,000 and C1's lineage split from C2 30,000
    generations ago (grid.tsv `sub_c:30000,1000`, 15 coalescent units). No lineage sorting can put a C1-derived
    insertion beside C2 or A2, so the only quartet patterns are A1+C1 and A1+C1+C2 (DFOIL_ALT 1010 and 1011).
    DFO, DIL and DFI therefore each have an empty class by construction. The probe's own 300-Mb counts
    (direction_counts.tsv, written before scoring) show it: 510 vs 0, 0 vs 510, 1,046 vs 0.
  - LTRpav's documented rule makes an empty class untestable (`common.why`). It names no direction when any of the
    four Z is undefined (direction.py:312-315), so the call is "none" whatever the other statistics read; the code
    string only shows "0".
  - The pre-registered "+-+0" came from probe_direction.py's binomial Z with a 0.5 continuity term, which stays
    finite at D = ±1 (Z 361). So the C1>A1 miss is (b): the control's design and its prediction method do not match
    the implementation's testability rule. It is not a lack of loci: these runs have 57-157 loci per statistic.
  - **A1>C1 (3 runs): mostly (a).** A1's lineage split only 2,000 generations ago, so a few opposing loci exist (6 at
    300 Mb, about 1 expected at 50 Mb). The classes were empty in 2 of 3 runs, and even with a finite Z the probe's
    counts give DIL about 2.6 and DFI and DOL about 3.2 at 50 Mb. Lack of loci at 50 Mb, compounded by (b).
  - **posctl nulls:** 0 informative loci in every statistic, so their "none" is vacuous.
- What the text says: it lists one-sidedness and "too few loci at 50 Mb" side by side. :336-338 points to the 50-Mb
  fallback. dead_ends.md:362-363 and Plan 4 lead 3 say a positive control at genome scale would change the outcome.
  For C1>A1 it would not: the same design at 300 Mb reads "none" again, because the probe's counts are already at
  300 Mb.
- Why it matters: rule 7's consequence stands as written. But removing the test is the Plan 4 decision, and the
  current text reads as "the test lacks power at 50 Mb". The evidence says something else: the implemented test was
  never run in a regime where a direction was both predicted and computable. All 50 maize-like gene-flow runs were
  predicted "none", and the C1>A1 control could not be computed by design. A Plan 4 rerun of this control at genome
  scale would fail again.
- Fix (text only):
  - Split the cause by direction in dead_ends and section 5. C1>A1 is a design and prediction defect, tested by
    derivation from DFOIL_ALT and the probe's counts, and independent of scale. A1>C1 is too few loci at 50 Mb
    (tested by scaling), plus empty classes.
  - Say the posctl nulls are vacuous.
  - Change "reads an undefined Z as '0'" (dead_ends.md:350; SIM_RESULTS.md:330) to "names no direction when any Z
    is undefined".
  - Replace "a positive control at genome scale" with what would actually change it. For C1>A1: a control whose
    lineages keep some lineage sorting, so the classes are two-sided, or predictions made with LTRpav's own
    testability rule. For A1>C1: at least 300 Mb.
  - Label as untested:
    - whether the implemented test names the right direction in any regime with two-sided classes and a predicted
      direction;
    - whether A1>C1 confirms at 300 Mb;
    - whether choosing P1, P2 by the smaller PAV distance mislabels direction. In 2 of 3 C1>A1 runs it put the
      older-split C pair (30,000 against 2,000 generations) in P1, P2, while DFOIL assumes P1, P2 split more recently.

**I2. "The discovery rule, not the genotyping, carries the bias" is contradicted at 20% dropout** (SIM_RESULTS.md:394-396;
headline evidence :687-688).
- The comparison: truth D on the sister-discovery rule, with perfect genotypes, isolates the discovery part.
- At A1 dropout 0.2:
  - this truth D reads mean Z -0.36 ± 0.84, with 0 of 10 nulls beyond -3;
  - LTRmix's D_ins reads -4.95 ± 1.06, with 9 of 10, and its sister pair is right in all 10 (:388-389).
- At 0.4, the discovery rule gives about half of D_ins's shift (-2.85 against -5.31).
- So at 20% most of the bias comes from LTRmix's annotation-dependent presence calls: a copy missing from A1's library
  is called absent, and cause b rises from 17% to 27.8% of the truly present absent calls (:507-508). At 40% both
  parts contribute.
- Why it matters: this is the evidence line of the headline, and it names the wrong component.
- Fix: say that both carry the bias. With perfect genotypes, the sister-discovery rule alone reproduces about half of
  D_ins's shift at 40% (-2.85 against -5.31) and little of it at 20% (-0.36 against -4.95); the rest comes from
  LTRmix's library-based presence calls. The headline sentence and its mechanism line already cover both parts and can
  stay.

**I3. The dropout levels are misdescribed** (SIM_RESULTS.md:369, :685, :23).
- How the dropout works: snap sim/pop.py:139 (`dropout_of`) replaces A1's base dropout; it does not add to it.
- Measured annotated/alive elements over the 26 dropout runs: A1 0.802 (level 0.2) and 0.599 (level 0.4); B1 and C1
  0.900.
- So A1's annotation is 10 or 30 points less complete than its sister's. It is not "20% or 40% ... on top of the base
  10%" (:369), and not "20-40% extra annotation dropout" (:685).
- Why it matters: the headline predicts a lean "in proportion to the annotation gap" but states the wrong gap. The
  true gap is smaller: a 10-point gap already gives D_ins 9 of 10 false signals.
- Fix:
  - :369 should read "A1's annotation keeps 80% or 60% of its elements, against 90% in the other genomes".
  - :685 should read "with A1's annotation 10 or 30 points less complete than its sister's".
  - :23 should read "dropout 0.2 or 0.4 in A1 (0.1 elsewhere)".

**I4. The Task 16 line does not say which null gives the empirical quantile, and the default nulls give the most
lenient one** (SIM_RESULTS.md:92-93; dead_ends.md:229-230).
- D_pav's null SD of Z by null set:

  | null set | runs | SD of Z | max \|Z\| | 95th percentile of \|Z\| |
  |---|---|---|---|---|
  | default | 30 | 0.72 | 1.97 | 1.36 |
  | dropout | 20 | 1.06 | | |
  | bottleneck | 30 | 1.29 | 3.14 | 2.74 |

  The bottleneck set is wider than the default set (F-test p = 0.002; quantiles from perrun.tsv).
- A quantile taken from the default nulls would lower the bar below 3. That is anti-conservative if the real history
  resembles the bottleneck set: a bottleneck in the recipient's lineage after the A-B split, the simulated analog of
  B73's domestication.
- Fix: add one sentence to section 1 and to the dead_ends Result line.
  - The quantile must come from a null that matches the real data's demography.
  - The default nulls give the most lenient threshold of the three sets.
  - Until a matched null exists, the verdict rests on the widest set (bottleneck), or |Z| > 3 is kept.
  - The dead_ends "What would change it" line (:252-253) already asks for such a null; link the two lines.

### Minor

- **M1. The CP threshold is off by one** (SIM_RESULTS.md:240; dead_ends.md:326-327, :329). 0 false in 35 tracts gives
  a two-sided 95% upper bound of 0.10003, which is above 0.10; 36 is the minimum (0.0974).
- **M2. Paired outcomes are tested with Fisher's exact test** (SIM_RESULTS.md:371-373, :686-687; claims.py section 6).
  Both statistics score the same 20 dropout nulls, so the paired test applies: an exact McNemar test on the
  discordant runs gives D_ins p = 7.6e-6 (not 3.4e-9), D_kmer 1.2e-4 (not 3.3e-6), D_self_outgroup 0.002, D3_triples
  0.12. The conclusions are unchanged.
- **M3. The dropout power comparison uses the wrong 7-genome cell** (SIM_RESULTS.md:401-403). The dropout f 0.18 runs
  are all Ta 5,000, but the 7-genome mean of 2.13 pools Ta 50, 500 and 5,000. The matching cell (f 0.18, Ta 5,000)
  reads 1.41 ± 0.09 (2 runs).
- **M4. "Not reproduced in 20 more nulls of the same demography" needs qualifying** (SIM_RESULTS.md:129-133;
  dead_ends.md:240, :249-251).
  - Those 20 nulls are trios with A1 dropout, not plain repeats of the default set.
  - The default and dropout spreads do not differ significantly (F = 2.19, p = 0.056).
  - Truth D's spread does not differ either (0.76 against 0.85, p = 0.55).
  - Among 9 readings, one failure of a 95% interval happens about 37% of the time even if every statistic is
    calibrated (D_pav's chi-square p = 0.029).
- **M5. A hypothesis is stated as fact** (SIM_RESULTS.md:284-285). Lineage sorting is given as the reason the decoy's
  best tracts keep pace; dead_ends.md:282-284 labels that why as untested. Label it a hypothesis in SIM_RESULTS too.
- **M6. "The test makes no false call" overstates specificity** (SIM_RESULTS.md:307-310). The test made no
  directional call in any of the 118 seven-genome runs, so 0 false calls says nothing about specificity. Also say
  that the 2 posctl nulls had no loci (:82, :305).
- **M7. Two section 9 numbers are unclear** (SIM_RESULTS.md:559, :533).
  - :559's "1,361 library ortholog pairs" is the B1-C1 count of one run (null_s101, rate_free_split.txt), set against
    LTRpav's mean over 30 nulls (2,282), and it is not in claims.txt. Use the 30-null mean.
  - :533 does not say whose isolation fit it describes: claims.txt shows LTRpav's (8.9% against 3.2%); LTRmix's own
    fit reads 10.6% against 4.0%.
- **M8. Two of nodonor's power hits used the recipient's own taxon for discovery** (SIM_RESULTS.md:620, :642-646). Two
  of the 7 hits (f0.50_Ta500_r2, Z 3.19; f0.50_Ta5000_r2, Z 3.38) used A2 for discovery, which is decision 11's own
  concern. Say so beside "7 of 36".
- **M9. The section 3 table is incomplete** (SIM_RESULTS.md:180-204).
  - It omits the wrong-trio counts (6 of 36 for each tool, tracts.tsv), which pull down LTRpav's head-to-head AUROC
    (f0.50_Ta500_r1: trio A1,C1;B1, AUROC 0.31).
  - "LTRmix paints better" has no paired test; a per-run sign test on AUROC would do.
- **M10. Undefined terms for a non-CS reader:** "EM-fitted emissions" (:236), "emission" (:245, :257), "probit" and
  "profile 95% interval" (:165), "AIC" (:529), "posterior" (:39-41, :186), "design effect" (dead_ends.md:237). There
  are also stray mid-paragraph line breaks at :222-229 and dead_ends.md:292-294.
- **M11. One entry merges two headings** (dead_ends.md:317): "Evidence and cause tested" should be the two separate
  headings the brief asks for.
- **M12. The headline has no precedent line** (CLAUDE.md: "state what is new"). Ascertainment bias in ABBA-BABA-type
  tests is known for SNP panels; what may be new here is annotation-dependent presence calling for TE insertions and
  the donor-discovery remedy. Add one sentence, with checked citations or marked [unverified].

## Assessment

**Needs fixes.** Every verdict and all three Part C decisions are correct and can go ahead: no variant adopted, rule 6
at 7 of 36, rule 7 not confirmed so the note changes. Four text fixes remain:
- I1: separate the C1>A1 design defect from the A1>C1 power limit;
- I2: correct the "discovery rule, not the genotyping" inference;
- I3: correct the dropout levels in the headline and section 6;
- I4: name the null set for Task 16's empirical quantile.
