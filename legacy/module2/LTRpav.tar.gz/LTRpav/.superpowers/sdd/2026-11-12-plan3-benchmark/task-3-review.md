# Task 3 review: one-pass genome builder and assembly gaps

Scope: 42607ad..7f5cedb (commits 0a3c0ba, 7f5cedb), against task-3-brief.md, task-3-rulings.md, the ledger's Task 3
rulings (C1-C6), and plan lines 206-281. Line numbers are those of 7f5cedb. The working tree, index, HEAD and env
`ltrpav` were not changed. Probe scripts and logs are in
`/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t3review/`.

## Checks run

1. **Independent oracle** (`oracle.py`, `run_oracle.py`).
   - Per sample, the oracle starts from the backbone as a list of tagged tokens, one per base: (system, coordinate,
     value, genome orientation).
   - It applies the sample's insertions and losses oldest first, by whole-list edits:
     - an insertion goes right after its host's base `pos - 1` at its time, so youngest-first ordering emerges
       rather than being coded;
     - a removal marks tokens as ghosts, so later anchors stay findable;
     - replacing sequence goes after the replaced span's last base.
   - Small indels come last (they have no times).
   - Payload substitutions are off (mu 0, copy noise 0). From the builder it reads only its random draws: replacing
     bases, indel bases, and the same-branch TSD coin.
   - It compares the sequence bytes, all 21 Copy fields, and `lift_pos` at every position 0..L.
   - Landscapes, 180 in all:
     - 60 dense 4-kb TREE16 landscapes, with five loss mixes;
     - 30 TREE7 landscapes of 30 kb, with nested and overlapping backbone elements;
     - 30 multi-tree msprime ancestries (r 3e-7);
     - 60 shared-anchor landscapes. Primaries are collapsed onto 8 positions, including element starts and ends, and
       nested offsets onto 3 per host; the result is thinned with thin_events. Indel insertions are moved onto shared
       anchors, and indel deletions are placed over removal edges, with the removal's carriers or a subset.
   - Result: **0 mismatches** over 2,340 sample builds and about 330,000 Copy records.
   - The landscapes cover (event counts per landscape; the loss and indel counts are per carrying sample):
     - 23,201 kept insertions, 8,517 of them at depth 2;
     - 4,522 del_flanks that run into the host's host;
     - 185 overlapping del_partial pairs on one lineage;
     - 5,613 replaces;
     - 890 nested insertions kept in a host's solo LTR;
     - 2,343 shared-anchor pairs;
     - 13,566 indels within 5 bp of an element or removal boundary;
     - 880 TSD coin cases.
   - All fates occur: intact 10,707, partial 1,832, solo 4,093, replaced 1,881, deleted 90,408, absent 222,509.
2. **Oracle sensitivity** (`oracle_mutants.py`, `mutants.log`). 15 planted builder bugs, one per worker process: the
   oracle kills **15/15**. They include:
   - oldest first at one anchor;
   - the junction rule read as "base p removed";
   - the window one base narrower;
   - the replacing sequence anchored at the element's start;
   - indel bases placed before LTR payloads;
   - a strict-superset indel skip;
   - an off-by-one on minus-strand images;
   - Copy.tsd not in genome orientation.

   A first run reported three zero counts and one copied result. That was a harness flaw: a pool worker reused
   another mutant's module binding. It was rerun with one mutant per worker.
3. **Payloads with mu > 0** (`payload_check.py`). The same events were built at mu 2e-7 and copy noise 0.005, and the
   oracle's token map (lengths do not depend on mu) was used to read the builder's genome. 0 mismatches:
   - no non-payload base changes;
   - Copy.k2p equals K2P recomputed from the genome's LTR bases for 4,405 intact or partial copies;
   - at mu 0 with copy noise, every carrier holds the same body, and the two LTRs are identical.

   Divergence ratios:

   | Comparison | Observed / expected |
   |---|---|
   | Copy against its inserted content, JC(mu·age) | 0.994 ± 0.008 |
   | Carrier pairs, JC(2·mu·T_MRCA): shared branches | 1.000 |
   | Carrier pairs, under independent paths | 0.346 |
   | Nested second TSD copy against the host's in-place target, "host content at the nested point" | 0.87 ± 0.16 |
   | Same, under the alternative "host's inserted content" | 0.51 ± 0.12 |
   | Primary TSD copies, JC(2·mu·t) | 1.16 ± 0.09 |
4. **TSD bases against msprime truth** (`tsd_truth.py`). draw_events' SNP seed was replayed to get the time and node
   of each mutation, and the true target bases at each primary's time were compared with the builder's tsd0.
   - 966 of 1,039 target SNP sites agree.
   - All 73 disagreements come from the named approximation:
     - 67 are same-branch coin cases;
     - 6 are sites with more than one mutation.
   - There are 0 other disagreements, so the deterministic part of the rule is exact.
5. **Gaps** (`gaps_check.py`; 3 chromosomes, 200 seeds).
   - Exactly n runs per genome; every record equals its N run.
   - Near share 0.334 against 1/3 (SE 0.006).
   - Uniform gaps fall by chromosome length (0.607 / 0.296 / 0.097 against 0.6 / 0.3 / 0.1).
6. **Tests.**
   - `tests/test_popbuild.py`: 22 passed (`-W error -m "not slow"`). ruff is clean.
   - Seed sweep (`sweep_seeds.py`): the 5 statistical tests, each rerun with 100 shifted seeds, gave 0 failures in
     500 runs. The seeds are not tuned.
   - My mutants against the test file (`test_vs_mutants.py`): 4 of 7 survive (Minor M1).
7. **5-Mb probe** (R3), rerun from my scratch with 4 threads; it reproduces the report:
   - 0.22-0.44 s and 27-29 MB traced per sample;
   - 0.39 GB peak RSS;
   - build_chrom end to end 4.1 s, identical to the per-sample build;
   - 50,247 indels and 4,251 insertions and losses in about 4 s. A per-event copy of a 7.7-Mb chromosome could not
     run that fast.

## Spec Compliance

| | Requirement | Where | Evidence |
|---|---|---|---|
| ✅ | Interfaces: Copy (brief's fields in order, then strand/family/superfamily with defaults, C3), PopGenome, Lift, build_chrom, lift_pos, add_gaps | popbuild.py:106-148, 825-885 | signatures read; oracle compares all 21 fields |
| ✅ | R1: existence checked once per chromosome through thin_events; ValueError names Task 2's rule; no `site_lost` | :357-363, :94 | test_site_lost (test_popbuild.py:561) |
| ✅ | R1: removed() is the only interval definition; nothing re-derived | :364-365, :393-396, :551 | removals, indel skips and the replace cover rule all read `self.rem` |
| ✅ | R1/C3 target bases `[pos - 5, pos)`; left copy in place; body by strand; second copy follows in the host's order | :483, :615-654 | oracle exact (both strands, depth 2, minus hosts) |
| ✅ | Event order; youngest nearest the target at one anchor | :575, :625 | oracle, 2,343 shared-anchor pairs; mutant killed |
| ✅ | A deletion takes what is nested; C4a nested insertion in the solo LTR stays; C4c flank into the host's host | :543-544 (junction on the union) | oracle: 890 C4a cases, 4,522 C4c cases |
| ✅ | One pass: pieces joined once; coordinates from cumulative lengths; no per-event copy | :582-599 | probe (check 7) |
| ✅ | Lift and lift_pos: kept positions base by base; a deleted position maps to the next kept base; L maps to the genome length | :805-820, :836-847 | oracle compares every position, 2,340 builds |
| ✅ | Empty-site window and Copy.site: only removals break it; SNPs, indels and other insertions never do | :771-782 | oracle exact; test_site_window (:352) pins both edges |
| ✅ | Payloads: copy noise once per insertion, then left LTR over right | :461-465 | check 3 |
| ✅ | Payloads: mu along the path, shared branches; nested payloads spliced in after their own mutation | :502-526, :795-802 | check 3 |
| ✅ | Losses as removed(); differences from the brief's paragraph reported (end-side flank includes the TSD copy; solo keeps C4a; del_partial union) | report §"Where removed() and the brief's Losses paragraph differ" | oracle |
| ✅ | own / own_kept exclude nested; fates | :667-700, :716-760 | oracle |
| ✅ | k2p: simulated position by position | :762-769 | check 3 |
| ✅ | k2p: backbone source p plus derived SNPs, back with the source's Ts/Tv | :702-714, :435-443, :287-298 | oracle; test (:583) |
| ✅ | Gaps: rate, near share, records, one stream per genome | :850-885 | check 5; test (:611) |
| ✅ | R2: indel bases drawn once in event order before any sample | :388-389 | oracle; mutants |
| ✅ | R2: indels against removals | :393-396, :573 | oracle; mutants |
| ✅ | R2/R3: order-free and deterministic | :825-833 | test (:646); oracle reverse-order check on all 180 landscapes |
| ✅ | R3: 5-Mb probe, wall time and memory per sample | report; check 7 | reproduced. Per-sample memory is tracemalloc peak plus flat process RSS, not RSS per sample; adequate |
| ✅ | C2: two approximations named | :21-24 (indel, equal carriers), :34-37 (one mutation per SNP site) | check 4 quantifies the second |
| ✅ | C3: Copy additions and Lift layout | :60-61, :64-66, :132-133 | |
| ✅ | C4: Copy.site, replaced image and Copy.tsd orientation | :50-54, :45, :59 | |
| ✅ | C5: removed() wins | :24-25 | |
| ✅ | C6: nested windows clipped; all samples returned at once | :53, :828 | |
| ⚠️ | C1: backbone ageing implemented as ruled (derived SNPs from the root state), but not named in popbuild's docstring | :55-58 | Minor M2 |
| ✅ | 0a3c0ba: N1 (flank stop condition) | popevents.py:300-304 | I re-derived it: host bases between the flank's start and the far part are at least ltr + internal |
| ✅ | 0a3c0ba: N2 ("removed with its host" defined) | popevents.py:60-61, :306-309 | |
| ✅ | Brief's 15 tests present (plus 7 more); commit subject verbatim | test_popbuild.py:125-659 | |
| ✅ | User identity, no trailers; only `sim/` and tests touched; no maize names; importorskip; builder imports without msprime | test_popmodel.py:276 | |

## Strengths

- The builder is a faithful reading of popevents' conventions. My physical-edit oracle shares no code with it and
  agrees byte for byte on 2,340 sample builds, including the hard cases:
  - depth-2 nesting through minus-strand hosts;
  - flanks spilling two systems up;
  - insertions kept in solo LTRs;
  - many insertions on one anchor;
  - indels on removal edges with equal carriers.
- The order and existence logic is small and auditable:
  - `present` is one line on the per-sample union (:543-544);
  - every random draw happens before any sample is built (:388-392), which makes order independence structural,
    not tested luck.
- Payload evolution is exact for the intended model:
  - JC per segment, depth first, splitting at nested points (:502-526);
  - nested target bases are read from the host's evolving content;
  - each carrier stores only its differences.
- Fail-fast checks are broad (:400-433, :467-478). The implementer's carrier check on the subtree walk is a good
  invariant.
- Tests are mostly exact on engineered histories, and the 3-SE tests are honest (0/500 seed-sweep failures). The
  implementer's own 25-mutant run is real evidence; my survivors are in rules it could not have known to target
  (M1).
- The report is candid: removed() against the brief's differences, named approximations, and Task 4 notes.

## Issues

### Critical
None.

### Important
None.

### Minor

**M1. Four builder rules are not pinned by any test.** My mutants of each pass all 22 tests (`test_vs_mutants.py`),
though the oracle kills each:
- the "clipped" event (popbuild.py:662-664; Task 4 prints events in `events_x/y`);
- derived SNPs skipped on removed or indel-deleted LTR bases (:711; this feeds the annotated K2P);
- replacing sequence anchored at the element's end, before insertions there (:567);
- indel bases after the LTR payloads at one anchor, which keeps target bases adjacent to the copy (:574).

Fix: one exact assertion each. For example, extend test_partial_deletion with a neighbor's flank (["…", "clipped"])
and a derived SNP inside a removed LTR stretch; extend test_replace with an older insertion at e.end; extend
test_indel_against_removal with an indel insertion at an LTR insertion's pos.

**M2. C1 is not named in popbuild's docstring** (:55-58).
- The ruling reads source K as K at the root: each sample adds its root-to-sample derived SNPs, about 2·mu·T_root.
- The k2p entry describes the arithmetic but not that reading. Task 4's rulings state it; the module that produces
  the number should too.
- Fix: one clause.

**M3. Replacing sequences and indel inserted bases never take substitutions** (:388-391, :594-598). Payloads take
them at mu along the path and backbone bases take SNPs, but every carrier of an old replace or indel holds
byte-identical random bases. This is an unnamed simplification. It touches only those bases, and Task 4 scores a
replaced copy as O, so the cost is small. Fix: name it in the module docstring, or evolve them as payloads are.

**M4. Two input checks are missing** (`_check`, :400-433).
- It does not check that a primary's pos lies in [TSD_DEFAULT, L] and a nested one's in [TSD_DEFAULT, len(host
  body)). A hand-built pos under 5 slices the target silently wrong (:483-484, :518).
- It does not check that an event's time lies on its branch. A nested time off its branch is over- or under-evolved
  in `_walk` (:515-519) without error.
- draw_events never produces either. This is a fail-fast gap for hand-built input only.

**M5. add_gaps edge behavior.**
- A near gap that falls wholly off a chromosome is dropped silently (:881-884), so a genome can receive fewer than
  round(per_mb·Mb) runs. This needs a target within GAP_NEAR of a chromosome end; the records stay truthful.
- Near targets index `seqs` by `Copy.chrom` (:854, :866). Task 5 must number chromosomes 0..k-1 in seqs order, or
  gaps land on the wrong chromosome. The contract is stated in the docstring; carry it into Task 5's brief.

## Assessment

**Approved.**
- Spec: compliant. Every brief, R1-R3 and C2-C6 item is implemented as ruled. C1 is implemented but not named in the
  docstring (M2).
- Quality: the independent oracle, the mu > 0 payload checks, the msprime-truth TSD check and the reproduced 5-Mb
  probe agree with the builder everywhere they can, and the oracle is shown sensitive (15/15 mutants).
- The five Minor items are polish (tests, docstrings, input checks) and can ride along with Task 4.

Full suite (implementer's detached run, `p3t3/suite.log`):
- `suite.done` = 0; 1,222 tests, all passed;
- last line: `......................................................................   [100%]` (no summary line was
  printed).
