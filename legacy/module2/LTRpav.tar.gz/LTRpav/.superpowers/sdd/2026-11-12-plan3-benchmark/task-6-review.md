# Task 6 review: decoy-anchored emission model (and Task 5's review minors)

Range 78abe50..c7ccacd (2c4db4b, c7ccacd), branch plan3-benchmark. Working tree clean; src and tests equal HEAD.
Scratch: `$R` = `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t6review`.
Snapshots: `git archive` of 78abe50 (`$R/base`) and c7ccacd (`$R/head`); every probe ran from one of them on PYTHONPATH,
with `ltrpav.__file__` asserted. Env ltrpav was not changed.

## Spec Compliance

### The model (brief "The model"; DESIGN 7.4, 7.1)

- ✅ **e0 under decoy.**
  - paint.py:457-461 sets e0 = (decoy counts + 0.5) / (n + 1).
  - The decoy's classes come from `classes(cat, Y, X, D, discovery)` (paint.py:450). This uses the target's discovery
    rule, and the existing `dcls <= RS` test decides whether there is a decoy (paint.py:451).
  - main3 check (`$R/scripts/dump.py`, `$R/m3/headdecoy/fit.txt`): TIL01 gives 1,495 RD and 4,863 RS, and fit.e0 is
    `[0.2351784871835194, 0.7648215128164806]`, bit-equal to the formula.
  - Toy check under `discovery="any"`: e0_RD = 0.288283 = 248.5/862.
- ✅ **fix_e0.**
  - paint.py:333-334 is the only e0 update in `fit_hmm` (paint.py:311-340). Nothing renormalizes e0, and HmmFit
    returns the array it was given (:340).
  - Mutation check: re-enabling the update fails `test_decoy_e0_fixed` and `test_em_degenerates_decoy_does_not`.
    With the mutant, the decoy fit on the degenerate toy collapses to e0 (0.004, 0.996) and has 0 intermediate
    posteriors, so the test's posterior assertion has teeth even without its e0 assertion.
- ✅ **e1 starts at e0 * (5, 0.2), normalized** (paint.py:462-463, using `_INIT`).
- ✅ **The donor-like rule is unchanged** (paint.py:465): e1[RD] > e0[RD].
- ✅ **Fallback.**
  - paint.py:454-456 falls back for both reasons, through `_no_decoy_text` (:737-741).
  - It gives one fallback WARNING (paint.py:873-875).
  - Toy diff (`$R/toy_head.tsv`, scenarios S_unannot and S_noinf): the fallback painting equals the default painting
    except for the emission row's note and that one WARNING.
  - Note: the existing "no decoy" WARNING (paint.py:870-872) still fires as well, so a fallback painting carries two
    WARNINGs that name the same reason. The brief asks for one WARNING naming why, and gets it.
- ✅ **The q-values are unchanged.** `target_decoy` (paint.py:372-385) and the scale are untouched.
- ✅ **The default path is byte-identical to BASE**, verified two ways:
  - **main3.** On a `cp -a` copy of the main3_analyses view, I painted through the package API at 78abe50 and at
    c7ccacd with identical inputs. That includes the same `read_self_counts(identity.tsv)`, which removes the
    stale-identity confound the implementer had to work around.
    - Identical: rows.tsv (2,235 rows, the new five apart), findings, tracts.B73.bed, posterior.B73.tsv,
      decoy_tracts.TIL01.bed and decoy_posterior.TIL01.tsv.
    - Also identical: pi, L, loglik, e0 and e1 as float.hex (`$R/m3/{base,head}`).
  - **Seven toy scenarios** (`$R/scripts/toydump.py`): planted tracts, a collapsed null, `any` discovery, null seed
    5, a skipped painting (no RS), S unannotated, and S with no informative locus. Old rows, findings and fits are
    identical, 259 of 259 lines (`$R/{b,h}_def.tsv`).

### Rows

- ✅ **The emission row and the e0_RD, e0_RS, e1_RD and e1_RS rows** come right after donor_state (paint.py:687,
  :744-772). A skipped painting gets them after n_RS (:647-650).
  - Under decoy, the e0 rows declare the decoy's loci, `n` = 6,358 and `disc=TIL01;…`. This matches
    n_decoy_tracts' declaration.
- ✅ **NA** for a skipped or collapsed painting (paint.py:764-765). It is written ".", as for donor_state; checked on
  seed 1's null and on the skipped toy.
- ✅ **The e\* pairs sum to 1** by construction, since both vectors are normalized. The test checks it with approx
  (test_paint.py:512-513), which is right for floating point.
- ✅ **Existing rows are unchanged**: the main3 and toy comparisons above.

### Tests

- ✅ **Degenerate inputs are built directly**: `_segregated` (test_paint.py:472-486), the fallback toys (:553-558) and
  the skipped toy (:522-523).
- ✅ **Plan 2's seed rule.** My sweep of seeds 6-25 (`$R/seeds_*.log`) failed 0 of 20 for each seeded test. The null
  had 0 tracts at q <= 0.05 every time. The planted tract's mean posterior was 1.000 inside and 0.000 outside.
- ✅ **Exact values where the math fixes them**: e0 at test_paint.py:459, :466 and :498; the e\* rows equal the fit
  at :511.
- ✅ **C1's adaptation keeps its purpose.**
  - em degenerates: e1[RD] and e0[RS] are above 0.99, and no informative posterior lies in (0.05, 0.95)
    (test_paint.py:494-496).
  - decoy does not degenerate (:498-499), and the mutation above shows why.
- ✅ **C2's adaptation keeps its purpose.** The planted region is chr1 and chr2 whole, and the test asserts that loci
  exist inside and outside it (test_paint.py:546).
- ⚠️ **Two coverage gaps** (Minor 1 and 2 below):
  - nothing pins the decoy's discovery rule;
  - the null test cannot fail at the toy's scale.

### Task 5 minors (first commit, 2c4db4b)

- ✅ **m1: the indel counter.**
  - `held` is recorded in the same statements that apply each indel: deletions at popbuild.py:612, inserted bases at
    :629, exposed at :889 and :901.
  - pop.py:237-241 counts realized indels as `held`, and the remainder as `indel_in_no_genome`.
  - A run of the module toy at base and at head (`$R/pop_{base,head}`, threads 3): all 54 output files are
    byte-identical except params.json. params.json differs only in the indel counters: 368, 460 and 183 indels in no
    genome. RNG use is unchanged.
  - `test_held_indels` (test_popbuild.py:505) gives its expected set {1, 3, 4} by construction. I checked each case.
- ✅ **m3: the seed bound.**
  - `_seed` (sim/cli.py:120-126) is shared by `pop` and `pair`. A seed outside the bound is an argparse type error:
    exit 2, one error line.
  - simulate_pop raises ValueError (pop.py:298-299).
  - The stream layout is asserted at pop.py:79-81 and stated in the docstring.
  - Tests at test_pop_cli.py:422-440. No existing script uses a seed above 2^32 - 1.
- ✅ **m4: the stale outdir.**
  - `check_outdir` (pop.py:445-458) runs in `_pop` (sim/cli.py:244) before simulate_pop, after only argument
    validation.
  - It raises one ValueError, which becomes one error line and exit 1.
  - `fai/` is allowed only as a directory.
  - write_pop checks again (pop.py:468).
  - The test monkeypatches simulate_pop to fail (test_pop_cli.py:443-476).
- ✅ **m5**: fractions.tsv's fraction and lifted_fraction, the overrides, the backbone counts and A2's empty tract
  file are all pinned (test_pop_cli.py:187-196, :210-215, :317-344).
- ✅ **m6** (test_pop_cli.py:249-269):
  - two `subprocess.run` interpreters, with PYTHONHASHSEED 0 and 12345 and threads 1 and 2;
  - every file compared byte for byte, with `.fai` excluded through `_files`;
  - tracts are asserted present.

### Engine isolation and process

- ✅ **Engine fingerprints are unchanged** (`$R/fp_{base,head}.txt`). All seven `STAGE_MODULES` fingerprints are
  equal at 78abe50 and c7ccacd: elements a78af75d, anchor/raw/blastdb ebbfd97f, mm2_index 28f6fc79, and
  genotype_pair/genotype_chunk 52071c27.
- ✅ **No engine file changed.** `git diff 12d3e6c c7ccacd -- src/ltrpav/constants.py src/ltrpav/checkpoint.py` is
  empty.
- ✅ **The new constants live in analysis/constants.py:24-26**, each with a reason. The new sim names stay in sim/.
- ✅ **No maize names** in the changed src files.
- ✅ **Commit 1 holds only sim files.** Commit 2 holds the brief's three files.
- ✅ **Authorship.** Both commits use the global identity and carry no trailers.
- ✅ **ruff** passes on the head snapshot.
- ✅ **Suite log** (`p3t6/suite/suite.log`): 1,273 "." marks, no F, E, s or x marks, exit 0.
- ✅ **Focused tests** run from the head snapshot: test_paint plus test_popbuild, 61 passed; test_pop_cli, 15
  passed.
- ✅ **Nothing was written** under main3 or main3_analyses during my probes (`find -newer`: 0).

## Strengths

- **One expression keeps em bit-identical.** `counts + (0.5 if fix_e0 else 1.0)` (paint.py:460) keeps the em path
  bit-identical while giving decoy the brief's pseudocounts. The em path through `fit_hmm` is untouched.
- **Clear fallback reporting.** The fallback is recorded on the Painting (`fallback`, paint.py:175), so the rows, the
  note and the WARNING all give the same reason. The fallback painting is shown equal to the default painting.
- **Honest row declarations.** The decoy's e0 rows declare the loci they come from, not the target's.
- **The degenerate test has teeth.** It fails under the obvious mutant, and its input is built, not seed-picked.
- **m1 is fixed at the source.** `held` is recorded in the same statements that apply each event, so the counter
  cannot drift from the sequences. A base-vs-head run shows that only the counters moved.
- **The report is accurate.** Its main3 numbers (e0, tract counts, the 368/460/183 indels in no genome) match my
  independent reruns.

## Issues

### Critical

None.

### Important

None.

### Minor

1. **Nothing pins the decoy's discovery rule, which e0 depends on.**
   - I mutated paint.py:450 to `classes(cat, Y, X, D)`, dropping `discovery`. test_paint and test_cli_analysis
     still pass.
   - The line is BASE code, but under decoy it now defines e0. The brief names "the same discovery rule"
     explicitly, and `test_decoy_e0_fixed` (test_paint.py:455-459) checks recipient discovery only.
   - Fix: add a `discovery="any"` painting to that test, with its exact e0 from `classes(cat, "S", "R", "D", "any")`.
     The toy gives 248 and 613 there, against 176 and 448 under recipient discovery, so the mutant would fail.
2. **`test_decoy_null_no_tract` cannot fail at the toy's scale (plan-mandated test, low power).**
   - With the +1 correction, q >= 1 / n_target (paint.py:381). A tract at q <= 0.05 therefore needs at least 20
     target tracts above every decoy tract.
   - Seed 5 and seeds 6-25 give 0-2 target tracts: 1, 1, 1 and 2 at seeds 12, 14, 15 and 22, each with 0 decoy
     tracts.
   - So the test pins nothing about the decoy model's false positives. The pattern it shows (target tracts against
     zero decoy tracts) is the double-use asymmetry that ruling C3 sends to Task 11.
   - This is Minor, not Important: the test does what the brief specifies, and the FDR question is ruled to Task 11.
   - Task 11 should not count this test as evidence about the null.
3. **On a collapsed fit, the decoy findings line reports a pseudocount artifact.**
   - The line (paint.py:876-880) says "EM fitted e1 (0.5, 0.5)". On the same painting, the e\* rows are NA, and the
     collapsed line says state 1 holds no data. Toy: seed 1's null with `emission="decoy"`.
   - The BASE donor_state note (paint.py:666) also prints e1 on a collapsed fit, so this follows precedent, but it
     sits next to the line that contradicts it.
   - Fix: when `p.collapsed`, keep n_D, n_X and e0, and replace the e1 clause with "e1 not estimated (the fit
     collapsed)".
4. **Polish.**
   - `classes()` keeps the literal default `"recipient"` (paint.py:190), while `paint` and `Painting` use
     PAINT_DISCOVERY (paint.py:173, :415). The default is now spelled two ways.
   - The module docstring cites `classes(cat, Y, X, D)` without the discovery argument (paint.py:28), which reads as
     if the decoy always used recipient discovery.
   - A fallback painting carries two WARNINGs that name the same reason: the existing no-decoy one (:870-872) and the
     fallback one (:873-875). Optionally, merge them.

## Assessment

**Approved.**

The model matches the brief. Specifically:

- e0 is fixed exactly from the decoy's classes, with the target's discovery rule;
- EM never touches e0;
- e1's start and the donor-like rule are as specified;
- the fallback carries one WARNING that names the reason;
- the q-values are unchanged.

The default em painting is byte-identical to BASE: on main3 with identical inputs, including bit-equal fit
parameters, and on seven toy scenarios. The rows are complete, NA where required, and leave existing rows unchanged.

Task 5's minors are all addressed, with real tests. m1 changes only the counters, and m6 is a true two-process,
two-hash-seed comparison. The engine fingerprints are unchanged.

The four Minor items are coverage and wording. None of them makes the task untrustworthy. Minor 2 belongs with C3 in
Task 11's realized-FDR measurement.
