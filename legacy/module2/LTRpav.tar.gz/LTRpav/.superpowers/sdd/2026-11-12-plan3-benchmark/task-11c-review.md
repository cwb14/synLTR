# Task 11c review (78a7c05..6282541)

Spec compliance
- DESIGN 7.1, 7.4, 7.6 (docs/DESIGN.md): ✅ numbers and verdicts match SIM_RESULTS.md (7 of 36 / 19.4%, 0 of 21 false, CP 0.161, p 0.5, 2 of 8 posctl, 0 of 30 nulls); no variant adopted; rule 4 holds for all four models; rule 7 not confirmed with the corrected cause (empty classes, undefined jackknife Z vs binomial prediction; too few loci at 50 Mb; uninformative nulls); removal left to Plan 4. The long 7.4 line is rewrapped.
- Direction note (direction.py NOTE, test_direction.py::test_counts): ✅ minimal; test asserts a literal (can fail). Findings line now reuses NOTE: reasonable, consistent labeling, tested.
- env.sh: ✅ default unchanged (${SNAP_SHA:-4f3973e}); old checks intact; new "no snapshot" check runs first. Verified: SNAP_SHA=6282541 imports from snap/6282541/src; SNAP_SHA=deadbee prints the error and rc=1.
- Snapshot: ✅ diff -r of snap/6282541/src against git archive 6282541 src is empty; SHA file = 6282541a15e3...
- real/memo.md: ✅ snapshot 2 entry present, matches the report.
- ⚠️ Not verified by me: full-suite result (in progress), engine fingerprint equality (diff touches no engine file, constants.py or checkpoint.py, so it holds by construction).

Strengths: every number traceable to a table; honest statement that zero directional calls make the 0 false calls uninformative; stale FOUR_LIST_NOTE flagged rather than silently changed.

Issues
- Minor: direction.py FOUR_LIST_NOTE still says Plan 3's dropout runs check saturation; they do not (trios, no direction test). Frozen into snapshot 2; wording only, report flags it. Fix in Plan 4 or before snapshot 3.
- Minor: DESIGN 10.2 / 14 still say "kept only if simulations recover it"; consistent with the outcome, no change needed.

Assessment: Approved
