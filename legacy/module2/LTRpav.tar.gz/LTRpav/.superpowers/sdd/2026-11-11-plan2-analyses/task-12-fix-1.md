# Task 12, fix round 1 of 5 (review: task-12-review.md, 0 Critical, 2 Important, 7 Minor)

Read task-12-review.md in full first. The rulings below bind. Leave M7 (the figure's short legend) alone: it goes to
Plan 2's final wave as a code fix.

## I1. Named loci met by construction
- No tract anywhere reaches q <= 0.05, so every "not called" expectation is met by construction. In PRELIM.md
  section 2 and in prelim_papers.tsv, relabel HPC1 and ZmLPCAT1 "met by construction (no tract passes q anywhere)",
  not "hit".
- State the disagreement at ZmLPCAT1 plainly. The painting gives posterior 0.905 under a q 0.855 tract built from 2
  R+D loci, against Yang's ELAI 0.08 there. The painting points the wrong way at that locus, and only the q rule keeps
  it from being called.
- Check the cob-weight row and HPC1's "weakly" wording the same way.

## I2. The dilution mechanism is testable, and the test contradicts it
- Run the reviewer's test on D_pav's own loci: read D/O (and S/T) as absent, as a library-only test would. Its
  script is `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t12review/check_mech.py`.
  Read it, rerun it in your own scratch, and verify its numbers: D +0.287 (1,869/1,035) and +0.281 against +0.291;
  added patterns 552 vs 311, D +0.279.
- Report it in PRELIM.md as a result: on this trio, verifying absences does not change D or its age gradient. Check
  the gradient as well and give the numbers.
- Section 7: drop or restate the dilution mechanism and prediction 3. A refuted prediction is not kept as a
  prediction. Restate the headline sentence and mechanism so that they hold:
  - the falling empty-site share stands;
  - the claim that verification sharpens D does not.
- Name candidate reasons for the D_pav vs D_ins gap (+0.29 vs +0.19) without asserting any:
  - different loci (donor-discovered vs the sisters' own elements);
  - annotation completeness (1.08);
  - library presence calls on paralogs;
  - age composition. Per bin, LTRpav's D is higher too: 0.203 vs 0.153 old.
- Mark the gap untested.
- Section 3 ("what LTRpav adds"): say plainly that on this trio, verifying absences does not change D. What
  verification adds here is the mechanisms description and the outgroup polarization, not a different D.

## Minors
- **M1.** One sentence on the s gap (0.074% vs 0.048%), with the record's candidates:
  - the aligner is ruled out (minimap2 gives 0.075%, Task 9's review);
  - the pair set differs;
  - LTRmix uses a whole-record global alignment.

  Note also the isolation fit's lower-tail over-prediction. No conclusion rests on s.
- **M2.** Lead with the per-claim summary in PRELIM.md section 2, DESIGN.md section 12 and the memo's result line:
  - D_pav PASS;
  - windows PASS;
  - chromosomes PASS by painting, MISS by class share;
  - ZmPRR37a MISS;
  - 52 HF regions MISS.

  Row counts go in parentheses.
- **M3.** Put each tool's tract coverage fraction (LTRpav 22.0%, LTRmix 27.9% of chr1-10) beside its recall, as the
  chance baseline.
- **M4.** Provenance:
  - Inv4m's v5 coordinates become "LTRmix's v5 coordinates (source not recorded)" unless you find the source;
  - ZmLPCAT1 becomes "(Barnes: selection candidate; Yang's ELAI 0.08)".
- **M5.** Memo gaps:
  - add the fai sha256 snapshot line;
  - write `mamba run -n ltrpav python investigate_misses.py`;
  - give run_analyses.sh verbatim.
- **M6.** Wording:
  - lineage sorting gives *symmetric* sharing at every age;
  - add "(prelim)" to "Genome-wide: yes";
  - strengthen the CLR caveat with the per-age resolution symmetry.

## Process
- Edit PRELIM.md, prelim_papers.tsv (and compare_papers.py, if a label comes from it; rerun it then), the memo,
  dead_ends.md if an entry changes, and DESIGN.md section 12.
- One repo commit, with a plain subject such as "Correct the Plan 2 outcome summary". No trailers, nothing set,
  never push.
- main3 and the other read-only trees stay untouched; recheck the snapshot.
- Append "Fix round 1" to task-12-report.md.
- Return only:
  - the commit;
  - one line per finding;
  - the I2 numbers, including the gradient;
  - the restated headline sentence;
  - anything not done.
