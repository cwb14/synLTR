#!/usr/bin/env bash
# Lift ELAI per-SNP truth and named loci (B73 v4) to Zm-B73-REFERENCE-NAM-5.0 coordinates with the MaizeGDB chain.
set -euo pipefail
source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix
A=/data2/chris/maize_introgression/benchmark_data/annot
CH=$A/B73_RefGen_v4_to_Zm-B73-REFERENCE-NAM-5.0.chain
cd /data2/chris/maize_introgression/benchmark/truth
awk 'NR>1{printf "%s\t%d\t%d\t%d\n",$1,$2-1,$2,NR}' elai_summary.v4.tsv > elai.v4.bed
liftOver -minMatch=0.95 elai.v4.bed $CH elai.v5.bed elai.unlifted.bed
echo "lifted $(wc -l < elai.v5.bed) of $(wc -l < elai.v4.bed)"
# join back by row number and sort by v5 coordinate
awk 'BEGIN{FS=OFS="\t"} NR==FNR{c[$4]=$1;p[$4]=$3;next} FNR==1{print "chrom_v5","pos_v5","chrom_v4","pos_v4",$3,$4,$5,$6,$7,$8,$9;next} (FNR in c){print c[FNR],p[FNR],$1,$2,$3,$4,$5,$6,$7,$8,$9}' elai.v5.bed elai_summary.v4.tsv > tmp.tsv
head -1 tmp.tsv > elai_summary.v5.tsv; tail -n +2 tmp.tsv | sort -k1,1V -k2,2n >> elai_summary.v5.tsv; rm tmp.tsv
wc -l elai_summary.v5.tsv
zcat $A/Zm00001d.2.gff3.gz | awk -F'\t' '$3=="gene"{match($9,/gene_id=[^;]*/); g=substr($9,RSTART+8,RLENGTH-8); sub(/^Chr/,"",$1); print $1"\t"$4-1"\t"$5"\t"g}' > genes.v4.bed
liftOver -minMatch=0.5 genes.v4.bed $CH genes.v5.lift.bed genes.unlifted.bed
echo "genes lifted $(wc -l < genes.v5.lift.bed) of $(wc -l < genes.v4.bed)"
grep -E "Zm00001d039542|Zm00001d017584|Zm00001d022590|Zm00001d029675" genes.v4.bed genes.v5.lift.bed
