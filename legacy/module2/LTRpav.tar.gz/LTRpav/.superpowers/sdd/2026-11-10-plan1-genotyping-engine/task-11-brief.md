### Task 11: Windows

**Files:** Create `src/ltrpav/window.py`, `tests/test_window.py`

**Interfaces:**
- Consumes: `Element`, netted blocks, `a_to_b`, `WINDOW_PAD`, `WINDOW_CAP`, `ANCHOR_MIN`.
- Produces:

```python
@dataclass
class Window:
    wid: int; a_seqid: str; a_start: int; a_end: int              # 0-based half-open
    b_seqid: str | None; b_start: int; b_end: int; strand: int    # +1/-1; B window revcomp'd when -1
    eids: list[str]                                               # top-level elements (descendants implied)
    status: str            # "ok" | "no_anchor" | "no_left_anchor" | "no_right_anchor" | "breakpoint" | "span_cap"
    anchor_left: int; anchor_right: int; margin: float            # bp from element to anchor; min anchor margin
def make_windows(elements: list[Element], blocks: np.ndarray, a_names: list[str], b_names: list[str],
                 b_lengths: dict[str, int]) -> list[Window]
```

- [ ] **Step 1: Write the failing tests**

```python
def test_window_basic():                 # blocks either side, same chain: status ok, B coords from a_to_b, pads applied
def test_window_breakpoint():            # left anchor on B chr0, right on chr1 -> "breakpoint"
def test_window_missing_right():         # no block right of the element -> "no_right_anchor"
def test_window_span_cap():              # anchors 600 kb apart in B -> "span_cap"
def test_windows_merge_overlap():        # two adjacent top-level elements with overlapping windows -> one window, both eids
def test_window_minus_strand():          # '-' chain: strand -1, b_start < b_end, element image inside
def test_window_at_sequence_start():     # element at A position 3: "no_left_anchor", no exception (Review Focus 3)
def test_no_blocks_on_seqid():           # A seqid without any block -> "no_anchor"
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.** For each top-level element `[s0, t0)`:
  - **Left anchor:** the nearest block with `a_start < s0`, clipped to end at `<= s0`, whose clipped length is
    `>= ANCHOR_MIN`. **Right anchor:** the same rule mirrored at `t0`.
  - **Consistency:** both anchors on the same `b_chrom`, same strand, B order consistent with the strand, and both
    spans `<= WINDOW_CAP`. If not, try up to 3 next-nearest blocks per side, then give the U reason.
  - **Windows:** A `[aL - WINDOW_PAD + 1, aR + WINDOW_PAD)` and B from the anchor images, both clipped.
  - **Merging:** merge "ok" windows that overlap in A, share `b_seqid` and strand, have overlapping or adjacent B
    intervals, and stay within `WINDOW_CAP`.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add anchor-to-window construction"`.

---

