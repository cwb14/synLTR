# Task 11 review: overview figure and ltrpav-plot (84c909e..3b9352a)

Reviewed in three passes: the diff (plot stage plumbing, overview.py's model, drawing and legend code, tests); the
main3 render against its tables; probes on toy runs for the conditional paths. Probe scripts (scratch only):
/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t11review/probe.py
(cases normal, swapped `--trio S,R,D`, stale paint part), noout.py (no outgroup; donor unannotated), scaffolds.py,
tracts.py. No hunk was cut off; no changed file was read outside the diff.

### Spec Compliance
- ❌ Issues found:
  - The skill's Honesty and legend rules fail on reachable conditional paths. The headline and short-legend verdicts
    are not conditioned on the statistics they state (I1). Panel B's control sentence is inaccurate and
    unconditional (I2). Panel B's tract is called typical but sits at the 91st percentile of the quantity B draws
    (I3). A stale painting puts "None" into the legend (I4). One count pair in panel E is mapped by position (I5).
    Panel F's method text hard-codes the donor as discoverer (I6).
  - Location: overview.py:2026-2062, 2110-2114, 2170-2196, 2282, 2304-2311, 2325-2346, 2360-2365.
  - F2's sentence (overview.py:2186-2189) carries the wording the controller asked about (I2).
  - F1 and F3-F9 and both rulings are applied.
- ⚠️ Cannot verify from diff:
  - The full-resolution crop check of the round-1 render. I looked at the main3 PNG once and at one toy crop; the
    independent figure check is Task 12's.
  - The suite result (1102 passed). Not rerun, per instructions.
  - The layouts and the figure check in memo.md: present (memo.md:37-65, 147-157), not judged.

### Strengths
- **Numbers pipeline**
  - Every legend number on main3 is registered with its source: all 99 values appear verbatim in pages 2-3.
  - The spot checks equal the tables:
    - D_pav +0.29, CI +0.21 to +0.37, Z 7.4, the age strata, the checks and the gradient (stats.tsv);
    - ratio 1317/724 = 1.8;
    - A's class counts 2,699/4,816 and 1,495/4,863 (posterior files);
    - B_high 12957/126853 = 10.2% and 6860/136308 = 5.0%;
    - the tract medians, 26 loci and 439,703 bp;
    - the 8th tract in mid-rank order, B73v5_chr4:105,323,764-105,761,185, with 13 R+D screened in the first 8
      tracts.
- **Plot stage plumbing**
  - Clean: the PLOT constant, stage_inputs/params/fingerprint, and a marker that lists the three files.
  - stale_parts iterates STAGES only, so the plot marker is never treated as a part (report.py:201-221 checked).
  - The soft WARNING path in `ltrpav run` is tested.
  - ltrpav-plot fails with one CliError line when stats.tsv is missing.
  - matplotlib, ltrpav.plot and scipy are imported only inside functions.
  - The ltrpav/cli.py edit is help text only. checkpoint.py:11-17 keeps the CLI outside every engine stage set, so
    no engine key moves.
- **Base-pair example**
  - Built from real sequence through `Fasta.fetch`, 0-based half-open, matching the 1-based coordinates.
  - Orientation is correct: R forward, D by R's call strand, S by b_strand, unit-tested both ways.
  - The E call's b_start..b_end is S's single TSD copy (classify._empty_site), so the S check is the one the legend
    states.
  - A wrong orientation can only reject a candidate, never draw a wrong one.
  - The failure counts (F3) make the clean subset visible.
- **Decoy file filter.** The filter (sister == R, donor == D, overview.py:355) matches paint's writer, as shown by
  the decoy_posterior header and rows.
- **Round-1 fixes.** F4 is well done: a planted stage, metric or file name never reaches the legend, and a test
  covers it. F5 is tested both ways. F1, F6, F7, F8 and F9 are applied.
- **Generality basics hold.** No "chr" assumption (`_short_names`); MAX_ROWS/MIN_FRAC; no trio; no painting;
  300 scaffolds; several trios (H). Nothing crashed in any probe.

### Issues

#### Critical (Must Fix)
None.

#### Important (Should Fix)

**I1. Verdict sentences in the headline and short legend are not conditioned on what they assert.**
overview.py:2036-2062, 2112-2114, 2240, 2282, 2310-2311, 2360-2365.

On main3 every one happens to be true. On reachable paths they contradict the panels beside them. Probe evidence:
- **Significantly negative D** (`--trio` with R and S swapped; D_pav -0.27, Z -4.0):
  - the headline says "S and its sister R share insertions with D about equally often: no evidence of gene flow";
  - F's short legend says "about as common in S as in R".
  - The branch at 2042 lumps D < 0 at |Z| ≥ 3 with "no difference".
- **Age gradient untestable or not significant** (toy: D by age +1.00/+0.29/+0.06, gradient Z nan). The headline
  says "though not concentrated in young insertions as recent gene flow would be". That is absence of evidence
  stated as evidence of absence. trio.py's own verdicts here are "not significant" or "not testable" (trio.py:470-480).
- **D_pav skipped, or no counted locus.** The headline says "No insertion of D is shared with exactly one of R and
  S". Panel E of the same figure shows R+D 225 and S+D 63 in the merged calls (no-outgroup probe). The test counted
  nothing from the discoverer's calls, or was skipped; that is not the same claim.
- **"R, not S, shares more with D (the recipient)"** (E, 2310). It prints when the roles came from `--trio`, and
  even when findings warn "the recipient is not identified" (no-outgroup probe, roles "sheet order").
- **"are a larger share of R's informative insertions (28%) than of the control's (43%)"** (A, 2113). The swapped
  probe printed this. "lie along every chromosome" is never checked.
- **"fewer among old insertions"** (D, 2282). It printed with 100% in both age bins, and "Only about 100%".
- **"holds in every check"** (F, 2363). The check strata are never consulted.
- **"Only k of the n ... so the example comes from a small clean subset"** (C, 2240). This prints whatever k/n is.

Why it matters: these are the figure's claims. The brief makes the gene-flow wording conditional, and the skill
says the figure must never be more convincing than the data.

Fix:
- Branch each sentence on its statistic: sign and |Z| ≥ Z_SIG for D; the gradient's own three verdicts (young,
  older, not significant or untestable); the check strata's sign and Z; the merged counts' order; the two shares;
  the two frac_E values; k/n.
- Write a neutral sentence where the statistic is missing.
- Add a test per branch (see M10).

**I2. Panel B's control sentence is inaccurate and unconditional.**
overview.py:2186-2189 (long), 2193-2195 (short), 1493-1496 (docstring).

On the controller's wording point: "so a plateau like this tract's also arises without gene flow" is not accurate.
The decoy is the sister, painted with the recipient's fitted model and the roles swapped. It is a mirror control in
which lineage sorting acts as it does in R. It is not a genome shown to lack gene flow; gene flow into S would show
there too.

The clause is also unconditional:
- **Decoy never reaches 0.9.** In the normal toy the decoy has 0.0% of insertions at ≥ 0.9. The long legend still
  says the plateau "also arises", and the short legend says "posteriors this high also occur in the control
  painting".
- **No tract.** With no tract ("With no tract called", swapped and no-outgroup probes) the text still says
  "a plateau like this tract's" and "Above: the posterior per insertion and the tract" (2182).
- **No verified insertion.** When no tract holds a clean R+D insertion, 2172 still says "taking tracts in that
  order until one held a verified R+D insertion (3 examined)". Yet the window is the first tract and panel C is
  absent (normal probe).

Accurate wording when the decoy share is above 0: "Posteriors of 0.9 or more are 10.2% of B73's insertions and 5.0%
of the decoy's: plateaus this high also occur in the sister's control painting (roles swapped), half as often; the
tract's q weighs this one against the decoy's tracts."

Fix:
- When the decoy share is 0, say the control never reaches 0.9.
- Drop the tract words without a tract.
- Make the B selection sentence say "no tract held a verified R+D insertion; the window is the first tract in that
  order" on that path.
- Fix the docstring the same way.

**I3. Panel B's example tract is atypical in the quantity B draws, yet the legend calls it "one typical donor-like
stretch".**
overview.py:652-660 (the walk), 2193 (short legend).

The walk ("until one held a verified R+D insertion") reached the 8th tract in (n_loci, length) order. On mean
posterior, the plateau B draws, the chosen tract is not typical:

| Tracts compared | Mean posterior 0.921 is above |
|---|---|
| B73's tracts | 700 of 770 (91st percentile; median 0.826) |
| The decoy's tracts | 575 of 599 (96th percentile) |

memo.md (F2) gives these percentiles. It says the decoy-tract band was not drawn because it "would make it look
exceptional". On the drawn measure, the tract is exceptional. Its summed posterior (the q ranking) is ordinary:
24.9, against a median of 21.2.

Why it matters: the skill requires a typical showcase region, with alternatives checked and the reason given on the
long legend page. Here the reader sees a near-1 plateau over 437 kb, without being told it is in the top tenth.

Fix (any one):
- Choose, among the tracts that hold a clean candidate, the one nearest the medians of n_loci, length and mean
  posterior.
- Or state the percentiles on the long legend page and drop "typical" from the short legend.
- Or draw the decoy-tract band the controller preferred.

**I4. A stale painting is drawn and its statistics print as "None".**
overview.py:346-378, 584, 2120-2129, 2376-2392; nan at 2124-2126, 2262-2265, 2351.

`painted` means the painting files exist. Nothing checks that the paint part is current, that is, that stats.tsv
holds the trio's paint rows. Once a paint part is stale, `assemble` drops its rows (report.stale_parts) but leaves
the files. A realistic path: `ltrpav-stats --identity` after ltrpav-paint (identity.tsv is a paint input), then
`ltrpav-plot`.

Probe (paint rows removed, as assemble does):
- A reads "switch scale None", "(...; None in R, None in S), black when q ≤ 0.05 against the decoy (None)";
- G reads "genome-wide means (None and None; excess None)" and "None of its None tracts";
- G's short legend asserts "R's painting is no more donor-like" from a missing excess;
- painting files whose lids or seqids left loci.tsv would raise a KeyError instead.

The same templates print "nan" on other paths:
- "switch scale nan bp";
- "Youngest minus oldest: +0.94 (Z nan)";
- "nan of the youngest";
- "D_pav ... : nan (no jackknife Z; ...)";
- H "R,S;D nan".

Fix:
- Treat the painting as present only when the trio's paint rows are in stats.tsv (or the paint marker is current).
  Otherwise draw the classes with a plain note.
- Never interpolate a missing value; omit the clause instead.
- Add a test that "None" and "nan" never reach pages 2-3.

**I5. Panel E's donor-call counts are mapped by position.**
overview.py:2304-2309.

`re.match(r"n_\S+ (\d+), n_\S+ (\d+)", kk.note)` takes the first number as R+D. But relations.py:657 writes the
sister pair in sheet order (x, y), not in role order. Whenever S precedes R in the sheet (or under `--trio`), the
legend's "From D's own calls they are a and b" swaps R+D and S+D, and E_kksc_RD/E_kksc_SD are mislabeled.

Confirmed in the swapped probe: the legend prints "316 and 183" where R+D is 183. A sheet ordered TIL01, B73, TIL18
would do the same on main3 data, with roles from the data.

Fix: capture the genome names (`n_(\S+)\+(\S+) (\d+)`) and map by pair, or read the counts from a stats row.

**I6. Panel F's method sentence hard-codes the donor as the discoverer, and the outgroup as present.**
overview.py:2325-2329, 2346, 2296.

The F legend says "the N loci D annotated and carries, ... all states from D's own calls" and "By the K of D's
copy". Under DESIGN 7.1's fallback discovery the row reads `disc=X;present=D`. The probe with an unannotated D
printed "on the 31 loci D annotated and carries".

Without an outgroup, the legends still say "every outgroup an empty site" (F) and "absent from the outgroup" (E).

Fix: take the discoverer from the row's loci column (`disc=`), and drop the outgroup clauses when
`cat.outgroups` is empty.

#### Minor (Nice to Have)
- **M1. Long paths are clipped (overview.py:2566-2580).** `_text_page` never breaks a word wider than the line. In
  the required last line "Analysis: <host>:<path>", a path longer than about 90 characters runs off the page and is
  lost, even to pdftotext. Confirmed with a 120-character path: ".../a7cbe20d-.../scra" is cut. Main3's
  73-character path fits. Break long tokens after "/" or "_".
- **M2. Pipeline jargon on fallback paths.** The F4 test covers only warnings. Cases:
  - "There are no painting files for this trio (ltrpav-paint not run, ...)" (2133);
  - "(roles as given (--trio))" (2070);
  - "unless --trio named it" (2403);
  - the raw failure reason with "RD" and "tier high" in the no-example caveat (881; `_FAIL_SHORT` is not applied
    there);
  - "the FASTA of X" (877);
  - a sentence title on the no-trio figure (1916).
- **M3. Thresholds duplicated as literals instead of the analysis constants (plan constraint).**
  - `abs(z) >= 3` (2026) and `dD_z >= 3` (2029) restate Z_SIG.
  - The legend text "odds ≥ 3 times the prior odds" (2128) restates BF_TRACT.
  - `q <= 0.05` appears at 546, 638 and 1434, and in the legend text.
  - Import them, so the figure's verdicts stay in step with findings.txt.
- **M4. `Catalog.tsd` is the first member's TSD in sheet order** (loci.py:17, 528), not necessarily R's
  (overview.py:793, 823).
  - When R is not the first annotated member, R's copies are compared with another genome's TSD. This can only
    fail safe, but it biases the clean subset.
  - Use R's own `e.tsd`, which verify() already loads.
  - The label "recipient's TSD copies not identical" (830) also covers "copies equal to each other but not to the
    annotated TSD" and "sequence ends".
- **M5. `_LID_CACHE` is keyed by `id(cat)`** (397-405). In a long-lived process (a library or notebook) a freed
  catalog's id can be reused and the stale map returned. Cache on the Catalog, or build the dict per call.
- **M6. Repeated reads.**
  - `_Checker.calls` (758-771) re-streams pairs/R__S.calls.tsv.gz for every tract that has new candidates. On the
    no-clean-candidate path that is up to n_tracts passes (770 on main3, 5 MB gz each). Collect the eids once.
  - mechanisms.tsv (9.8 MB) is parsed five times (611, 1645-1646, 2249, 2269).
- **M7. An existing but unreadable FASTA fails the plot key** (report.py:147: `file_checksum` raises). This
  contradicts the comment at report.py:146 and the docstring ("only omits the base-pair panel").
- **M8. Misattributed number sources.**
  - sequences_drawn and sequences_not_drawn cite `loci.tsv:<R>_seqid` (607-608) but come from the FASTA index
    lengths.
  - A_bin cites `posterior.<R>.tsv:start` (2124) but is a display choice.
  - C_flank_identity cites pair-file columns (2223) but is computed from the FASTAs.
- **M9. Wording.**
  - E's "absent from the outgroup" (main3 legend) describes the rule outgroup=not_present, which includes missing
    states. Say "not present in the outgroup" (DESIGN 5.4).
  - "a little more donor-like" (2389) and "thin" (2059) are magnitude words not tied to a number.
  - "sparser ones ... are scattered loci" (2147) interprets the density rule rather than stating it.
- **M10. Test gaps.**
  - No test compares numbers values with their source tables. The current check is a substring check, and short
    values such as "1" pass trivially.
  - No tests for the headline and verdict branches, a negative D, an untestable gradient, no outgroup, fallback
    discovery or a stale painting. These would have caught I1 and I4-I6.

### Checks run (outside the diff; one per named risk)
- **The plot marker leaking into the assembly.** report.py:201-221: stale_parts loops over STAGES only.
- **The ltrpav/cli.py edit invalidating engine keys.** checkpoint.py:11-17 lists the CLI outside every stage set.
- **Decoy row filter.** decoy_posterior.TIL01.tsv rows carry sister=B73 and donor=TIL18, matching
  overview.py:355.
- **`paint.classes` signature and class order** (paint.py:83, 161-185): they match the code's use.
- **E-call coordinates.** classify.py:239-256: b_start..b_end is the single TSD copy.
- **TSD orientation and source.** annotation/__init__.py:57-64 gives forward-strand TSDs; loci.py:17 and 528 take
  the first member's TSD (M4).
- **KKSC note order.** relations.py:514-535 and 657 order the pair by sheet (I5).
- **D_pav when the donor is unannotated.** trio.py:249-255 writes no rows when skipped, and `disc=X` under the
  fallback (I1, I6).
- **The skipped-painting path.** paint.py:495-515 writes no files.
- **Z threshold.** constants.py:8 and 12 define Z_SIG and BF_TRACT (M3).
- **main3 numbers.** Every value is present in pages 2-3; class counts, B_high, tract medians and order, and the
  example tract's percentiles were recomputed with awk and numpy.
- **Fonts and pages.** pdffonts lists embedded Liberation Sans/Mono TrueType; the PDF has 3 pages, page 1 180 x 221
  mm.
- **Probes of conditional legend text.** Toy runs: normal, `--trio S,R,D`, paint rows removed, no outgroup, D
  unannotated, 300 scaffolds.

### Assessment
**Task quality:** Needs fixes

**Reasoning:** The plumbing, the base-pair checks and main3's numbers are right. But the legend templates state
verdicts, method details and a control comparison that are not conditioned on the data, and they print false or
"None" text on reachable paths (`--trio`, sheet order, an unannotated donor, a stale paint part, no clean example).
The showcase tract is also called typical while it sits at the 91st percentile of the plateau panel B draws.

## Re-review (fix round 1)

**Scope**
- Fix diff 3b9352a..1b0ee8f:
  - f1d27b2 names Q_TRACT and uses it in paint.py; the value and text are unchanged.
  - 1b0ee8f holds the overview fixes and their tests.
- Read against the rulings in task-11-fix-1.md and the report's "Fix round 1" section.

**Checks run**
- **Probes.** Re-ran my five probe scripts on the fixed tree: normal, `--trio S,R,D`, paint rows removed, no outgroup, D unannotated. Outputs are in /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t11review/r1_*.
- **Tract order.** Recomputed main3's tract order and percentiles from tracts.B73.bed and decoy_tracts.TIL01.bed (tracts3.py).
- **main3 legends.** All 102 values in overview_numbers.tsv appear in pages 2-3, and no "None", "nan" or "inf" does.
- **B and C.** Looked at a crop of the new B and C.
- **Tests not run.** The probes exercise the same paths; the suite was reported as 1116 passed.

### Verdict per finding

| Finding | Verdict |
|---|---|
| I1-I6 | ADDRESSED |
| M1-M10 | ADDRESSED |

**I1, verdicts.** overview.py:2015-2040 (`_direction`, `_compare`), 2174-2238 (headline), panels at 2240, 2457, 2505 and 2545. Probe output:
- **Swapped.** The headline reads "R, not S, carries more of the insertions D shares with one sister (268 against 155): the test points against the roles, which were set by the user". Panel F's short legend says the same.
- **Normal.** It reads "...: more than lineage sorting alone gives; the age gradient could not be tested" and "the excess holds in all 3 checks".
- **No outgroup.** It reads "The donor-sharing test ... has no result: its counted set is empty: ...".
- **D unannotated.** "No insertion counted ... is shared" appears only where both counts are 0.
- **Comparisons.** A, D, E and G now state the direction with both numbers. Examples: "a smaller share ... (28%) than of the control's (43%)"; "fewer among old insertions (32%) than among young ones (53%)".
- New Minor N1 concerns the |Z| < Z_SIG branch.

**I2, panel B's control sentence.**
- **Selection text** (2347-2353). It names a verified insertion only when one was found. Normal probe: "no tract held a structurally verified R+D insertion (149 screened in 3 tracts), so the window is the first tract".
- **Control sentence** (2384-2405). It depends on a decoy painting, a drawn tract and the two shares:
  - main3: "Posteriors of 0.9 or more are 10.2% of B73's insertions and 5.0% of the decoy's: plateaus this high also occur in the sister's control painting (roles swapped), about half as often; the tract's q weighs this one against the decoy's tracts".
  - normal probe: "... never reaches 0.9";
  - swapped probe: "... reaches 0.9, while S's painting never does";
  - "and the tract" is dropped when there is no tract.
- **Docstring.** `_posterior_histograms` (1502) is reworded too.

**I3, the typical tract** (651-700 ranking; 2355-2370 percentiles, with "typical" printed only when all three percentiles lie within 25-75).
- **Recomputed independently.** The 2nd tract in the three-key order is B73v5_chr3:139,704,026-140,123,941: 27 loci, 3 R+D, mean posterior 0.828, q 0.75.
- **Percentiles.** 53, 47 and 51 among B73's 770 tracts; 61 among the decoy's 599.
- **Example screen.** 1 + 3 = 4 R+D insertions screened, 1 passed.
- All of this matches the legend.

**I4, stale painting** (589-597). A painting is drawn only when stats.tsv holds the trio's current paint rows.
- The stale-paint probe prints "There is no current painting for this trio, so no posterior or tract is drawn", with no "None".
- Tests: test_stale_painting_is_not_drawn and test_no_missing_value_reaches_a_legend (6 paths).
- The report also claims that "a painting file whose lids are no longer in loci.tsv also counts as not current". That is not in the code: `_painting` (353-385) still indexes lids and seqids directly. The stats.tsv gate covers the case whenever stats.tsv has been reassembled (see Out-of-Scope).

**I5, panel E's donor-call counts** (`_pair_counts`, 2049-2058; 2527-2534). Counts are mapped by label.
- Swapped probe: "183 (R+D) and 316 (S+D)", which is correct.
- main3: "2,763 (R+D) and 1,495 (S+D)".
- Test: test_kksc_counts_map_by_label.

**I6, discoverer and outgroup wording** (`_disc` 2042-2047; F at 2556-2565; outgroup clauses at 2517 and 2563).
- D-unannotated probe: "on the 31 loci X discovered (fallback discovery: D has no annotation) ... every state from X's own calls".
- No-outgroup probe: no outgroup clause anywhere.

**M1, long paths** (`pieces`, 2882-2897; test_long_paths_wrap). Probe paths of about 120 characters now wrap and pdftotext recovers them whole.

**M2, jargon.**
- The legends now say "roles as given by the user" (2077) and "unless the user named it" (2683), with no command or file names.
- The failure labels are plain where they are counted (the `_fail` calls, 828-890), and the no-FASTA note reads "X's genome sequence cannot be read" (911).
- The no-trio title is gone.

**M3, constants.**
- Z_SIG, BF_TRACT and Q_TRACT are imported (97).
- Q_TRACT is added with its reason (constants.py:13).
- The remaining 0.05 literals are axis margins (1518, 1809, 1879), not thresholds.

**M4, R's own TSD.**
- `e.tsd` replaces `Catalog.tsd` (828-851).
- The failure labels are split: "sequence ends", "recipient's TSD copies differ", "... differ from the annotated TSD" (859-863).
- main3 re-rendered: 1 of 4 passed; the commonest failure is "length atypical of its family (3)".

**M5, lid cache.** Cached on the catalog object (404-410).

**M6, repeated reads.** One pass over the pair file per call site (`prefetch`, 789-803); `_Run.table` parses each file once.

**M7, unreadable FASTA.** `_plot_checksum` keys it as "unreadable" (report.py:151-160), and test_unreadable_fasta_omits_the_example covers it (see N3).

**M8, sources** (615-616, 2290, 2432).
- The three sources now read "genome index", "display" and "genome sequence".
- C_site, C_length and C_TSD now cite work/elements (see N5).

**M9, wording.**
- "not present in the outgroup" (2517).
- "thin", "diffuse" and "a little" are gone. Magnitudes now carry their numbers, for example "exceeds ... by +0.053 (0.370 against 0.317)".
- The sparse-block sentence states the rule (2318).

**M10, tests.** test_numbers_equal_their_tables compares values, plus the branch tests named above.

### New findings in the fix diff
None are Critical or Important. Minor:

- **N1. "About equally many" is not what the test shows.** overview.py:2191 and 2632. The |Z| < Z_SIG branch says "R and S carry about equally many of the insertions D shares with one sister (a and b)". But non-significance is not equality. At Z 2.9 with 1,317 and 724, the headline would call the counts about equal right next to the numbers. Under the round's principle, the wording should follow the statistic: "R carries a, S b; at |Z| < 3 the test shows no difference: no evidence of gene flow".
- **N2. "Which makes R the recipient" misattributes the roles.** overview.py:2540-2542. With roles from the data, the recipient is set by the sign of D_pav on the donor's loci. The stats.tsv roles note says "recipient B73 by the sign of D_pav(...)", not E's merged counts. Point to panel F instead, or drop the clause.
- **N3. The unreadable-FASTA test fails as root.** tests/test_overview.py:484-500. The test makes the FASTA unreadable with `chmod(0)`. As root, which is common in CI containers, the file stays readable and the test fails. Skip it when `os.geteuid() == 0`, or make the path unreadable another way.
- **N4. The duplicate-key guard is gone.** overview.py:2097-2108. `_Legend.num` and `_Legend.text` return the first text when a key is registered again. So `_Numbers.add`'s guard no longer catches one key written with two different values. This is latent. Keep the guard by checking that the new text equals the old.
- **N5. A source names a missing column (nit).** B_pct_length cites "tracts.<R>.bed:length", which is no column; B_tract_length cites "end-start0".

### Out-of-Scope Observations
- **ltrpav-plot never checks that stats.tsv itself is current.** If the run's inputs change (a re-merge, a new identity.tsv) and stats/paint are not rerun, stats.tsv keeps the old paint rows. The I4 gate then passes, and the figure draws the old painting against the new catalog. That gives a KeyError on a lid that left loci.tsv, or a silent mismatch if lids were reused. `report.stale_parts(cat)` detects this; a WARNING or a refusal in the plot stage would close it.
- **memo.md still carries superseded text.** It keeps the old two-key example rule (line 68) and the earlier phrase "plateaus near 1 arise without gene flow too" (line 130) above its new "Fix round 1" section. The new section supersedes them, but a reader of the run record could take the old lines as current.

### Assessment (fix round 1)
**Task quality:** Approved
**Reasoning:** All 16 findings are addressed, and the fixes hold on every probe path and on the main3 re-render. The fix diff adds only Minor issues (N1-N5). None of them makes a number, or a verdict on the main path, wrong.

## Re-review (fix round 2)

**Scope**
- Fix diff 1b0ee8f..dc5824d:
  - 28808ce covers N1-N5, DESIGN.md's selection rule and the tests.
  - dc5824d makes the plot stage refuse a stale stats.tsv.
- Read against the requirements in task-11-fix-2.md and the report's "Fix round 2" section.

**Checks run**
Probes are in /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t11review/: stale_probe.py (outputs r2_cli, r2_run, r2_identity) and missing_fasta_probe.py.

| Probe | Setup | Result |
|---|---|---|
| Standalone refusal | stats and paint, then the run re-merged in place; ltrpav-plot as a subprocess | exit 1; one `error:` line naming both parts; no WARNING; no overview file; no plot marker |
| `ltrpav run` path | `run_analyses` with `stale_parts(warn=False)` planted to report a stale part | returns normally (exit 0); exactly one WARNING, "figure failed (AnalysisError: stats.tsv ... is not current (the paint part: ...)"; no plot marker |
| `--identity` | `ltrpav-stats --identity` and ltrpav-paint with lastz on PATH, then ltrpav-plot without lastz, then with it | refused without lastz (see item 6); draws with it |
| main3 re-render | pages 2-3 diffed against fix round 1's | only E's short sentence and the definitions sentence changed |

The main3 numbers table holds 102 values, all present in pages 2-3, with no None, nan or inf; only the length and tract sources changed.

### Verdict per item

| Item | Verdict |
|---|---|
| N1-N5 | ADDRESSED |
| Item 6 (the plot stage's stale check) | PARTLY |
| Item 7 (memo.md) | ADDRESSED |

**N1, not-significant wording.** `not_significant` writes both the headline and F's short legend when |Z| < Z_SIG: "...R carries a, S b; the difference is not significant (|Z| < 3): no evidence of gene flow". The 3 is printed from Z_SIG. test_not_significant_is_not_equal sets Z to Z_SIG - 0.1 with counts 268 and 155.

**N2, who sets the recipient.**
- With roles from the data, E's short legend now ends "; the donor-sharing test (panel F) makes B73 the recipient".
- The definitions now read "...the recipient the sister with more donor-shared insertions in the donor-sharing test (panel F)". The panel letters are formatted from the figure.
- main3's legend diff shows exactly these two sentences changed.
- The test reads F's letter from the legend.

**N3, root.** The unreadable-FASTA test is skipped when `os.geteuid() == 0`.

**N4, one text per key.** `_Legend.num` goes through `_Legend.text`. A key written again with the same text returns it; a different text raises ValueError (test_a_numbers_key_keeps_one_text). I traced the repeated call sites (headline and panels A, F and G; C_screened in B or C) and found none that writes two different texts.

**N5, sources.** B_pct_length, B_tract_length and B_median_length cite "tracts.<R>.bed:end - start0"; B_tract cites "chrom, start0 + 1, end".

**Item 6, PARTLY.**
- **What works.**
  - A stale part, from changed inputs or changed code, is refused as required: standalone, one `error:` line and exit 1; inside `ltrpav run`, one WARNING and exit 0. Both were probed.
  - The skip path is not re-checked, which is acceptable: the plot key covers the run's files and code.
- **What fails: the coordinator's check.** It can refuse a current stats.tsv made with `--identity`.
  - `stale_parts` recomputes the stats key with `backend_version("lastz")`. When lastz is not on PATH that version is None, so the part is judged stale.
  - Probe r2_identity: ltrpav-plot without lastz on PATH exits 1 with "error: stats.tsv in ... is not current (the stats part: LASTZ's version differs (lastz is not on PATH, so it cannot be compared)): rerun the analyses (ltrpav-stats and ltrpav-paint, or ltrpav run), then ltrpav-plot". The same run draws with lastz on PATH.
  - The plot itself needs no LASTZ.
  - The message sends the user to rerun analyses that are current. Rerunning ltrpav-stats --identity skips and changes nothing, so the user loops until they fix PATH.
  - This is a plausible case: an env's ltrpav-plot called by absolute path, or a job script without the env activated.
- **Why it counts.** It is the case the requirement's stop-and-report clause anticipated: the --identity key needs something the plot stage does not have. The implementer did not report it.
- **Fix, either of:**
  - Treat an unknown LASTZ version as "cannot compare" rather than stale in the plot's check. Compare everything else; log the uncompared version once.
  - Report it and move it to the final wave, as the requirement says.

**Item 7, memo.md.**
- The two-key rule is replaced by the current rule, with a one-line superseded note (memo.md:72-76).
- The phrase "plateaus near 1 arise without gene flow too" is gone.
- Round 1's tract numbers and the first-render figure check are marked superseded.

### New findings in the fix diff

| Severity | Findings |
|---|---|
| Critical | None |
| Important | One: the false refusal under item 6 (counted there, not listed twice) |
| Minor | None |

### Out-of-Scope Observations
- **The same LASTZ rule also hits the assembly; this predates the round (Task 10).** Running ltrpav-paint without lastz on PATH after `ltrpav-stats --identity` drops the current stats part from stats.tsv.
  - Probe r2_identity: stats.tsv went from 584 to 40 rows, with one WARNING, "stats: its part is left out of stats.tsv ... LASTZ's version differs (lastz is not on PATH, so it cannot be compared)".
  - It has the same root cause as item 6's gap. One fix to the rule would serve both.
- **A missing FASTA never reaches the plot stage.** `read_samples` rejects it at sheet validation before any stage runs (missing_fasta_probe.py). So the plot key's "absent" branch, and the documented "a FASTA that is gone only omits panel C", are reachable only through a direct `overview()` call. An existing but unreadable FASTA still takes the "unreadable" branch.

### Assessment (fix round 2)
**Task quality:** Needs fixes

**Reasoning:** N1-N5 and the memo are fixed and verified. But the new stale check refuses a current `--identity` stats.tsv whenever lastz is not on PATH. That is a false refusal, with a misleading "rerun the analyses" message, in exactly the case the requirement said to stop and report.

## Re-review (fix round 3)

**Scope:** fix diff dc5824d..2c2e639 (report.py, analysis/cli.py, DESIGN.md, tests/test_cli_analysis.py), read with the "Fix round 3" section of the report and the coordinator's ruling. In the ruling, `stale_parts` gains `probe_tools`, the plot passes False, and stats and paint keep probing.

**Checks run.** Probe r3_probe.py ran on a fresh `--identity` toy run, with lastz on PATH unless noted. Output: /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t11review/r3_probe.out.

| Step | Command | lastz | Exit | stats.tsv rows | Result |
|---|---|---|---|---|---|
| 1 | stats `--identity` | yes | 0 | 545 | |
| 2 | paint | yes | 0 | 584 | |
| 3 | plot | no | 0 | 584 | drawn with the trio (round 2's false refusal is gone) |
| 4 | paint | no | 0 | 40 | the assembly leaves the stats part out; findings.txt holds the left-out line in Run and Warnings |
| 5 | plot | no | 1 | 40 | one `error:` line: "the stats part: left out when stats.tsv was last assembled: LASTZ's version differs (lastz is not on PATH, ...)" |
| 6 | plot, findings.txt deleted | no | 0 | 40 | draws the no-trio figure ("fewer than three ingroup genomes") for a run with three ingroup genomes |
| 7 | plot, findings.txt with one word edited ("is left out" to "was left out") | no | 0 | 40 | the same false no-trio figure |
| 8 | paint | yes | 0 | 584 | reassembled with the stats part |
| 9 | plot | no | 0 | 584 | draws the trio (D_pav +0.27) |

### Verdict: the round-2 Important finding (ltrpav-plot refusing a current `--identity` stats.tsv without lastz): ADDRESSED
- The fix is in report.py: `stale_parts(..., probe_tools=False)` takes `backend_version` from the marker's recorded params (`stage_params(..., tools=recorded)`). `run_plot` uses it.
- Step 3 draws where round 2 refused.
- A real catalog change is still refused (test_plot_check_probes_no_tool).
- The assembly still probes, so a new LASTZ still reruns `ltrpav-stats --identity` (test_another_lastz_reruns_stats_and_still_draws).
- Skipping the LASTZ comparison is safe for the figure: the overview never draws identity rows.

### The added guard (`left_out_parts`, read from findings.txt), judged on its merits
- **It is needed.** Without it, step 6's false no-trio figure is what the ruling alone produces after step 4, from a plausible sequence: `ltrpav-stats --identity`, then ltrpav-paint without lastz.
- **It cannot refuse a current run.**
  - Only an assembly that left a part out of stats.tsv writes the left-out line, so stats.tsv lacks that part.
  - Every stats or paint command reassembles, which clears the line once the part is current (step 8 leads to step 9).
  - A part simply not run, such as no paint marker, writes no line.
- **Older format: robust.**
  - `_LEFT_OUT` is the same text assemble wrote inline since Task 10.
  - Older analysis code changes the markers' code fingerprint, so `stale_parts` refuses such a run on its own.
- **A missing or hand-edited findings.txt: not robust; it fails open** (steps 6 and 7 above).
- **"Atomically together" overstates it.** `assemble` writes stats.tsv and then findings.txt as two separate atomic renames (report.py assemble). A crash between them leaves the guard blind in the same way. That is rare.

### New findings in the fix diff
- Critical: none. Important: none.
- **Minor, report.py `left_out_parts` and `run_plot`: the left-out guard fails open.** It depends on findings.txt, a human-readable report, rather than on stats.tsv itself. Deleting findings.txt, or changing one word of the left-out line, while the stats part is out of stats.tsv makes ltrpav-plot draw a false no-trio figure, with exit 0 and no warning (probe steps 6-7). Two ways to harden it:
  - Check stats.tsv against the parts directly: each stage whose marker is current under probe_tools=False must have its `work/analysis/<stage>.rows.tsv` rows present in stats.tsv. This is robust to edits, deletion and the crash window.
  - Or refuse when findings.txt is missing.
  - Either is fine for the final wave; it needs a deliberate edit or deletion of a result file to trigger.

### Assessment (fix round 3)
**Task quality:** Approved

**Reasoning:** The round-2 Important finding is fixed and verified on a fresh `--identity` run. The added guard is needed and never refuses a current run. Its only weakness is a fail-open path that requires deleting or hand-editing findings.txt (Minor).
