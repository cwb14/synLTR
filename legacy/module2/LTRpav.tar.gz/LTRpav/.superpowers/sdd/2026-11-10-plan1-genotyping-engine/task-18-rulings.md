# Task 18 — controller rulings (bind as much as the brief; override it where they conflict)

1. Piece(seqid, start, end): 0-based half-open A coordinates. flank_pieces(elements, fasta, cap=FLANK_CAP,
   target=FLANK_TARGET): for each TOP-LEVEL element (level 0), on each side, take the flank region (left
   [max(0, s0 - cap), s0), right [t0, min(len, t0 + cap))), remove every annotated element span (all levels) and every
   N run (seqio.n_runs on one fetch of the region), keep maximal free pieces >= FLANK_PIECE_MIN, and take them
   nearest-first until their total >= target (whole pieces; the last one may overshoot). Deduplicate pieces by
   (seqid, start, end) and return them in fai order then start.
2. Shared mapping helper: reuse the mm2 route's B index (same .mmi, built once, asm20, one part) and its hit-to-block
   conversion (split at SPLIT_INDEL via blocks.split_cigar, matches = "=" counts). Pieces are fetched in the main
   thread; mapping runs in a ThreadPoolExecutor(threads) with one ThreadBuffer per thread, best_n = MAPPY_BEST_N.
   Move shared code into a helper module or function rather than duplicating it.
3. FlankMm2Route(cap=FLANK_CAP): name "flank-mm2"; whole_genome False; reads_elements True; params include cap and
   target (so different caps never share a cache). FlankBlastRoute(cap=FLANK_CAP): name "flank-blast"; same flags.
4. BLAST: B's FASTA is streamed through Fasta into a plain FASTA `<workdir>/blastdb/<label>.<sha12>.fa` once (sha12 =
   file_checksum prefix, as in the FastGA route), then `makeblastdb -dbtype nucl -in <that> -out <same stem>` once
   (checkpoint marker); query = the pieces as FASTA with names "p<index>"; `blastn -task megablast -query <q> -db <db>
   -outfmt "6 qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore nident stitle"
   -evalue 1e-20 -max_target_seqs 50 -max_hsps 20 -num_threads <threads>`; the subject seqid is the first
   whitespace token of stitle (robust whether or not -parse_seqids was used). Blocks: a = [piece.start + qstart - 1,
   piece.start + qend), b = [min(sstart, send) - 1, max(sstart, send)), strand -1 when sstart > send,
   matches = nident, alen = length. Missing blastn/makeblastdb -> clear RuntimeError at route use.
5. HybridRoute(primary): name "hybrid"; params include the primary's name and params. raw_blocks(ctx): primary raw
   blocks (through the same raw cache the primary uses for its unordered pair) -> provisional chain_blocks/net_blocks ->
   make_windows -> top-level elements whose window status != "ok" -> flank_pieces for those elements only -> mapped
   with the flank-mm2 helper -> return the union of primary raw and flank raw blocks (anchor_pair chains/nets it).
   get_route("hybrid") -> HybridRoute(FastgaRoute() if shutil.which("FastGA") else Mm2Route()).
   Register "flank-mm2", "flank-blast", "hybrid" in get_route and KNOWN_ROUTES.
6. Tests as the brief, with: the hybrid test's primary = PafRoute whose PAF lacks blocks within 15 kb of one element
   (primary window not ok) -> hybrid resolves that element with its expected state; flank-mm2 through genotype_pair on
   toy.build_pair recovers the expected states for the P, E and D cases (and report any other case that differs, with
   the reason, instead of hiding it); flank-blast (skipif no blastn) produces strand-correct blocks.
