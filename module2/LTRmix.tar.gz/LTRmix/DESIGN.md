# LTRmix design notes

Question: can admixture and introgression between genomes be detected and characterized from their LTR-RT libraries
alone (no genome sequence, genes, SNP panel or outgroup)? Test case: maize B73, *Zea mays* ssp. *mexicana* TIL18 and
ssp. *parviglumis* TIL01 (LTRquest 5042a1e libraries), against Yang et al. 2023 (Science 382:eadg8940) and Barnes
et al. 2022 (PNAS 119:e2100036119).

## What LTR-RTs give that SNPs do not

| Property | Use |
|---|---|
| An insertion is derived; absence is ancestral | Presence/absence site patterns are polarized without an outgroup (D_ins) |
| The 5-bp TSD records one insertion event | Orthology can be certified inside the library (chance agreement ~0.3%) |
| The two LTRs were identical at insertion | LTR-LTR divergence is a clock (K2P); each LTR is an outgroup for the other (D_self) |
| Orthologous copies coalesced after the insertion | Ortholog divergence <= LTR-LTR divergence; paralogs violate this (clock test) |

## Decisions and reasons

- **Orthology from the library alone.** Candidates are record pairs sharing k-mers with <= 4 copies per library
  (no multi-mapping cap; minimap2 `-N 20` missed orthologs in high-copy families in the spike). Anchors are
  reciprocal best pairs that pass the clock test. Chromosome correspondence is learned: a chromosome pair is used
  only if it carries more anchors than independence predicts (Poisson, Bonferroni). A collinear chain must be longer
  than the longest chain among the same anchors with shuffled partner positions (20 shuffles). Without these two
  rules, paralog anchors between non-homologous chromosomes formed "blocks" by chance (chains through random
  points grow like the square root of n). Simulation: precision 0.9994, recall 0.996.
- **Clock test compares LTRs with LTRs.** Comparing whole-element ortholog divergence with LTR-LTR K2P rejected true
  orthologs (66% of rejected in-window pairs had identical TSDs): internal regions and LTRs evolve at different
  rates. Whole records are used only when LTR bounds are unknown.
- **Absence = inside a syntenic interval with no ortholog.** Elements outside chains are 'unresolved' and excluded
  from presence/absence statistics. A strict subset ('absence certain': the interval is shorter than half the
  element) is reported but is small.
- **Symmetric resolution for presence/absence and the identity spectrum.** An R+D-not-S insertion needs R-D
  orthology and R-S synteny; its mirror needs S-D orthology and S-R synteny. When one sister's synteny with the donor
  is incomplete (a distant donor: few orthologous intact elements, so few anchors), only the other sister's pattern
  can be counted there, which biased D_ins toward it (genus test: D = 1 on four chromosomes). Each pattern's donor
  copy must therefore also be absent from the other sister through donor-sister synteny, and the identity spectrum
  uses only donor copies resolved in both sisters. `donor_resolved` in stats.tsv reports the coverage; findings warn
  below 0.8 joint coverage or when the sisters differ by > 0.1 (heuristic levels; maize: 0.97 / 0.98 / 0.97).
- **Second donor for the f-ratio** (four or more genomes): a genome qualifies only if it and the donor are each other's
  closest relative among {donor, it, R, S} (1:1 ortholog counts). A looser rule picked an admixed member of the
  sisters' lineage (maize PT for mexicana TIL18); in simulations the true second donor still qualifies (8/8).
- **Roles from the data.** The sister pair is the pair sharing most single-copy k-mers; the third genome is the
  donor; the recipient is the sister with positive D. Nothing about taxa or chromosome names is hard-coded.
- **Four genome-wide tests, each with a delete-one-block jackknife.** Blocks are 5 Mb (>> LD in outcrossing
  grasses; hundreds of blocks), capped at 1/100 of the smallest genome's span for small genomes.
- **Triples are projected onto the donor's record.** Projecting onto the recipient's record let alignment noise
  inflate only the sister-donor comparison and biased D3 toward whichever sister was called recipient (seen in
  null simulations).
- **Mirror (target-decoy) logic throughout.** Without gene flow the two sisters are exchangeable: every statistic
  computed for recipient-donor is also computed for sister-donor, and the sister's version is the null.
  - Identity spectrum: recipient-donor vs sister-donor ortholog divergences, scaled to equal counts in the deep
    half (conservative). The excess is a lower bound on the admixed fraction of recipient-donor orthologs.
  - Tracts: the fitted HMM is applied unchanged to the sister's own evidence classes; decoy tracts estimate false
    tracts (conservative if the sister also carries donor ancestry).
- **HMM on informative classes only.** Element classes: near-identical to the donor (closer than 95% of
  sister-donor pairs), donor-only insertion, near-identical to the sister, sister-only insertion; 'shared', 'private'
  and 'near both' are missing data. 'Private' reflects each lineage's own TE activity and annotation, and when it
  was included EM used genome-wide composition differences between sisters as a fake ancestry state (null
  synthetic trio). One near-threshold (from the less-admixed sister's donor pairs) is used for target and decoy,
  so both genomes' classes mean the same thing; separate thresholds created false tracts.
  Both state emissions, the donor-like fraction (<= 1/2: a genome with more donor than sister ancestry would have
  been inferred as the donor's sister) and the mean tract length (grid) are fitted by Baum-Welch. State 1 must be
  enriched for near-donor and depleted of near-sister elements, else 'no donor-like state'. Tract elements need
  posterior > 0.5 and posterior odds >= 3 x prior odds (Kass & Raftery 'positive' evidence).
- **No windows in inference.** The painting HMM runs element by element; switching depends on the bp distance
  between neighbors and on the fitted mean tract length (likelihood over a 10 kb-50 Mb grid), so its scale adapts
  to each dataset (maize B73 197 kb; sweet orange mandarin haplotype 2.5 Mb). Windows appear only in summaries
  (the overview trace: ~25 elements per window, within display limits) and in jackknife blocks (5 Mb or 1/100 of
  the genome; chosen to exceed linkage, not for resolution). Agreement with a smooth reference such as ELAI always
  rises with window size, so it cannot select an 'optimal' window.
- **Only the recipient is painted.** The sister-state anchoring is valid only for the less-admixed sister.
- **No index cache.** Rebuilding a 1.7-Gb library index takes ~1.5 min; reading a 13-GB cached index back from a
  busy disk took >13 min.

## Known limits (see the benchmark)

- One haplotype per taxon: incomplete lineage sorting makes many sister-like clusters look donor-like; tracts much
  shorter than the spacing of informative elements (~10-30 kb in maize) are not recoverable individually.
- The HMM's raw donor-like fraction is not an admixture estimate (it absorbs lineage-sorting clusters); the decoy-
  corrected excess and the identity-spectrum bound are reported instead.
- Direction of gene flow and an admixture fraction (not a bound) need a second donor genome (f-ratio).
- One-sided annotation dropout biases presence/absence statistics toward the better-annotated sister.
- With a distant donor (here *Z. nicaraguensis*, split ~120 kyr; a few hundred 1:1 intact orthologs per pair),
  insertion and ortholog tests lose power and coverage; the alignment-free D_kmer remains usable. Possible fix,
  not built: an optional gene-synteny input (`docs/idea_synteny_input.md`).
- Sister inference by shared k-mers can follow annotation depth when depths differ; check it against ortholog
  divergence (which completeness does not affect).
- Old inversion polymorphisms mimic or hide introgression over tens of Mb. When two arrangements split before the
  taxa did (recipient ortholog divergence across the inverted block > genome-wide median sister-donor divergence),
  recombination between them is suppressed and the block's genealogy follows the arrangement: the posterior moves
  toward whichever genome shares the recipient's arrangement (B73: up in Inv1n, carried by TIL01; down in Inv4m and
  chr8/chr9 blocks carried by TIL18; nine blocks, 6.4% of elements; one exception, chr4 113-118 Mb, stays low). Lineage sorting otherwise gives short
  discordant segments, which the HMM and decoy assume; an inversion gives one long one. Orthology is not at fault
  (blocks are chained in both orientations; Inv1n fully resolved). Genome-wide statistics barely move (effects
  cancel in maize; not guaranteed elsewhere), but window agreement with ELAI falls by about a third when the blocks
  are masked (`benchmark/REPORT.md`, section 8). Not yet in the tool: flag such blocks (from `inversions.tsv` and
  ortholog divergence), leave them out of the HMM fit and summaries, and test inside them whether the recipient's
  divergence to the genome sharing its arrangement is unusually low (an introgressed arrangement, e.g. PT and
  TIL25 at Inv4m, 0.15% vs 1.03% genome-wide) rather than typical (an old shared arrangement, e.g. B73 and TIL18 at
  Inv1n, 0.75% vs 0.91%). Masking alone would discard introgressed inversions.
- "Younger than the split" is rate-dependent when the split is given in years. Rate-free version
  (`benchmark/scripts/rate_free_split.py`): read the split in substitutions per LTR site from the sister-donor ortholog LTR
  divergence (isolation model: divergence = s + exponential ancestral coalescence, Poisson differences; plus a
  post-split gene-flow and an upper-tail component as a check), then compare each insertion's 95% upper bound on
  LTR-LTR divergence, chi2.ppf(0.95, 2(d+1)) / 2 / n, with s. Maize: s = 0.05-0.07%, so no single insertion
  qualifies (identical 644-site LTRs bound divergence at 0.47%); the rate-based 13 vs 1 (3e-8, 30 kyr) implies
  s = 0.18%. A single insertion can be certified only when s > ~3 / (LTR sites). Sweet orange (pummelo-mandarin,
  s = 1.0%, ~300 identical sites needed) passes: 9-37 insertions shared by the pummelo haplotype and mandarin vs
  0-2 the other way. Rate-free evidence that remains:
  the age gradient of D_ins, and the excess of recipient-donor ortholog pairs below s. Not in the tool: the split
  estimate in `stats.tsv` and a per-element 'younger than the split' flag.
- Resolution is set by the spacing of informative elements (near-identical to, or shared with, only one other
  genome), not of all LTR-RTs: B73 31,395 of 127,636, median spacing 25 kb (mean 67 kb); citrus trios median
  24-49 kb (mean 50-144 kb). It depends on TE activity since the taxa split, not only on genome size or LTR-RT
  content. Not yet reported by the tool: this spacing and the shortest callable tract (informative elements
  needed to reach the tract rule x spacing) in `findings.txt`; summary windows defined by a count of informative
  elements (e.g. 25: share to about +-0.1) rather than bp.
