### Task 4: Truth, annotations and tracts in sample coordinates

**Files:**
- Create: `src/ltrpav/sim/poptruth.py`, `tests/test_poptruth.py`.
- Modify: `src/ltrpav/sim/pair.py`. Two helpers are factored out of `_annotation`, which then uses them.

**Interfaces:**
- Consumes:
  - `PopGenome`, `Copy`, `lift_pos` (Task 3);
  - `truth.TRUTH_COLUMNS`;
  - `COV_PRESENT`, `MIN_SEG`, `REFINE_PAD`, `TSD_DEFAULT`, `SLOP_TSD_MULT`;
  - `elements.Element`, `make_eid`, `annotation.gff3.write_gff3`;
  - `pair.jitter_bounds` and `pair.read_tsd`, factored out of `pair._annotation` here (Annotation, below).
- Produces:

```python
def alive(c: Copy) -> bool          # fate "intact" or "partial", and each LTR keeps >= COV_PRESENT of its own bases
                                    # (Plan 1: not deleted, not a solo-LTR)
def pair_truth(x: PopGenome, y: PopGenome) -> list[dict]   # TRUTH_COLUMNS, one row per alive element of x
def annotate(g: PopGenome, dropout: float, jitter: float, rng: np.random.Generator) -> list[Element]
def tract_bed(g: PopGenome, chrom_tracts: dict[int, list[tuple[int, int]]]) -> list[tuple[str, int, int]]
                                    # chrom_tracts: chromosome index -> this sample's backbone tracts (Task 1 `tracts`,
                                    # taken at the sample's index for each chromosome)
def insertion_rows(genomes: list[PopGenome], ins: dict[int, list["Ins"]]) -> list[dict]   # key: chromosome index
```

- **Truth rules.** These are Plan 1's (`sim/truth.py` docstring), with "inherited by Y" (Y lies below e's origin) in
  place of "present before the split". `w = SLOP_TSD_MULT * TSD_DEFAULT`. For an alive element e of X, read in Y:
  - **`G`:** Y has an N within `REFINE_PAD` of e's site or image in Y.
  - **e not inherited by Y, with a simulated host Y did not inherit:** the outermost such host's truth, plus
    `host_empty` when that truth is E.
  - **e not inherited by Y, otherwise:**
    - `O` when Y carries another insertion whose target overlaps e's target (same chrom and host, positions within
      `TSD_DEFAULT`);
    - `E` when Y's copy has `site >= 0`;
    - `D` otherwise, `site_lost` included.
  - **e inherited by Y:**
    - `S` on fate solo;
    - `O` on fate replaced (unrelated sequence of at least `MIN_SEG` at the intact site, DESIGN 5.4);
    - `P` when `own_kept >= COV_PRESENT * own` and each LTR keeps `COV_PRESENT`;
    - `T` when `own_kept >= MIN_SEG`;
    - `D` otherwise.
  - **The empty-site window** is Task 3's: the w shared bases on each side plus the TSD (`Copy.site`). Plan 1's rule
    holds:
    - only a target overlap gives O;
    - only losses or deletions of window bases give D;
    - **SNPs, small indels and insertions at other sites inside the window never break it.** Plan 1's truth says "a
      1-bp indel beside an empty site leaves it E", and treats Y-specific insertions at other sites as transparent.
  - **Columns.**
    - `origin` is `backbone` or `sim`; `events_x` and `events_y` are the copies' events.
    - `name` is the eid, so `ltrpav-sim score` joins unchanged.
    - Inversions are not simulated, so the painting's inverted-block flags go untested on the sims.
- **Annotation.** Plan 1's `_annotation` rules, applied to alive copies through two helpers factored out of
  `pair._annotation`:
  - `pair.jitter_bounds(start, end, ltr_left, ltr_right, length, jit, ds, dt) -> (start, end, ltr_left_start,
    ltr_right_end)`;
  - `pair.read_tsd(seq, start, end) -> str | None`.

  `_annotation` then uses them. The caller keeps the RNG draws, so `ltrpav-sim pair` stays byte-identical on its tests.
  The rules:
  - each dropped with probability `dropout`;
  - with probability `jitter`, start and end moved by U{-3..3};
  - the TSD read beside the reported ends.

  K2P comes from `Copy.k2p`. Family and superfamily come from the donor or the source. Name is the eid.
- **`tract_bed`** lifts each backbone tract's ends with `lift_pos` (Task 3's `PopGenome.lift`). A payload inserted
  inside a tract belongs to it.

- [ ] **Step 1: Write the failing tests** (engineered histories on `toy_ts`, one test per truth rule).

```python
def test_truth_P_inherited_intact():  def test_truth_E_never_inserted():   def test_truth_S_solo_in_y():
def test_truth_T_partial():           def test_truth_D_deleted_in_y():     def test_truth_D_site_deleted():
def test_truth_O_replaced():          def test_truth_O_same_target():
def test_truth_host_empty():          # nested in a simulated host Y never got: E + host_empty
def test_truth_G_gap_near_site():
def test_truth_E_with_snp_and_indel_beside_site():   # a SNP in the TSD and a 2-bp indel 5 bp from the site: still E
def test_truth_E_with_other_insertion_in_window():   # Y-only insertion 4 bp from e's target: still E
def test_pair_annotation_unchanged():   # tests/test_sim.py's annotation outputs byte-identical with the helpers
def test_annotation_dropout_bounds(): # 2,000 copies, dropout 0.1: annotated within 0.9n +- 3 sd
def test_annotation_loads(tmp_path):  # write_gff3 -> load_annotation: count, TSD, K2P_d, Name == eid
def test_tracts_lifted():             # every copy whose backbone point lies in a tract lies in the lifted tract
def test_score_joins(tmp_path):       # truth TSV + calls equal to truth -> ltrpav-sim score: P and E precision 1.0
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement** the Interfaces.
- [ ] **Step 4: Run.** Expected: PASS; then the suite.
- [ ] **Step 5: Commit:** `"Add population truth, annotations and lifted tracts"`.

---

