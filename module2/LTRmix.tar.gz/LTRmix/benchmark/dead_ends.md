# Dead ends and corrected mistakes (LTRmix benchmark, 2026-11-07)

- **minimap2 `-N 20` for orthology** (spike): high-copy families fill the 20 secondary slots, so true orthologs went
  unreported; replaced by low-copy shared k-mers (no cap).
- **"Collinear block" = >= 5 anchors in a chain**: chains through random paralog anchors between non-homologous
  chromosomes reach that length by chance (longest chain ~ 2 sqrt(n)); synthetic precision 0.89-0.945. Fixed by
  a chromosome-pair enrichment test and a per-pair shuffled-anchor null (precision 0.9994).
- **Clock test on whole records vs LTR-LTR K2P**: rejected true orthologs (66% of rejected in-window pairs had
  identical TSDs); internal regions and LTRs evolve at different rates. Now LTR vs LTR, plus TSD as a second
  certificate.
- **Triples projected onto the recipient's record**: alignment noise inflated only the sister-donor comparison and
  biased D3 toward whichever sister was called recipient. Now projected onto the donor's record.
- **HMM likelihood ratios (r - 1 + f)/f from the identity ratio**: amplified noise near r = 1 for small f; painted
  TIL01 71% donor-like. Replaced by an EM-fitted categorical HMM.
- **HMM anchored to the sister's composition, all 7 classes**: EM used genome-wide differences in the 'private'
  class (lineage TE activity, annotation) as a fake ancestry state (null synthetic trio painted 82% donor-like).
  Now only exchangeable, informative classes; both emissions free; pi <= 1/2; donor-state check; BF >= 3 rule.
- **Separate near-thresholds for target and decoy**: near_sister meant different things in the two genomes; false
  tracts made of near_sister elements. One threshold now.
- **Within-chromosome shuffles as the tract null**: destroys the spatial clustering that lineage sorting itself
  creates; q <= 0.05 tracts were 67% false in simulation. Replaced by target-decoy (sister).
- **Painting the second sister against the recipient**: anchoring on an admixed genome labels any difference as
  donor-like (P painted 90% M-like in simulation). Only the recipient is painted.
- **Simulator: msprime samples an ancestral population of a split at the split time** unless `initially_active`:
  parviglumis was sampled 9,000 generations in the past, which biased every null toward P (12/12 runs). Fixed and
  asserted. Lesson: D_self (polarized by the sister LTR) was immune; D_kmer, D_ins and D3 assume equal branch
  lengths.
- **k-mer index cache on disk**: 13-GB npz files read at ~2 MB/s under disk contention (>13 min) vs ~45 s to rebuild.
  Removed.
- **Whole-genome minimap2 asm20 of maize assemblies for a SNP comparator**: 545 GB RSS (repeats, -K 2G); killed
  within ~40 min to protect the shared server. Replaced by gene-space alignments (gene +-1 kb; ~10 GB).
- **Recent-sharing tracts as 'introgression tracts'**: significant against the decoy (58 at q <= 0.05) but only weakly
  enriched for ELAI mexicana ancestry (dosage >= 1 in 6.3% of SNPs vs 4.9%); they mark recent shared ancestry with
  the sampled TIL18 genome (either direction), not ELAI-style ancestry. Reported as such.
- **Inversion scoring summed every inverted block within +-20 Mb**: the TIL18-TIL01 Inv1n row (48.1 Mb, 238 anchors)
  added a separate pericentromeric inversion (217 anchors) to the Inv1n block (21 anchors). `eval_real.py` now lists
  each block; REPORT corrected.
- **Absence checks without `NUMPY_MADVISE_HUGEPAGE=0`**: two runs spent 3 h, mostly in the kernel (8-9 ks system vs
  1.6-2.5 ks user time; transparent-huge-page compaction). Killed and relaunched with the variable; every benchmark
  script now sets it before importing numpy.
- **Ortholog-based tests with a distant donor**: *Z. nicaraguensis* shares only 228-783 1:1 intact orthologs with each
  *Z. mays* genome (75-119 triples per trio), so D3 and D_self had no power (|Z| <= 1.3) where k-mer and insertion
  tests gave Z 6-18. Not a failure of the logic; the ortholog tests need donors within roughly the LTR-RT half-life.
- **D_ins counted asymmetrically when donor synteny is incomplete** (found from per-chromosome D = 1 on four
  chromosomes in the genus run): an R+D-not-S insertion needed R-D orthology and R-S synteny, but its mirror needed
  S-D orthology, so where one sister's synteny with a distant donor was missing only the other sister's pattern could
  be counted. Fixed by requiring the donor copy to be absent from the other sister through donor-sister synteny as
  well (same rule for the identity spectrum: donor copies resolved in both sisters). Effect: maize D_ins +0.189 ->
  ~+0.195 (negligible); genus D_ins Zh vs TIL18 +0.646 -> ~+0.45, but the two-mexicana control moves from +0.06 to
  ~+0.31 because only 4 chromosomes stay resolved. With a donor this distant, insertion tests are unreliable; the
  alignment-free k-mer tests (library and whole assembly) carry the genus result. Every analysis was rerun.
- **Second donor chosen as 'shares more orthologs with the donor than either sister'**: in the six-genome run this
  picked maize PT (more mexicana ancestry than B73) as a second mexicana for B73's f-ratio (alpha ~0.6 = B73's excess
  / PT's excess). Now the donor and second donor must be each other's closest relative among the four genomes; the
  four-genome simulations still select their true second donor in 8/8 runs; no genome qualifies in the real set.
- **Real-genome spike-in (TIL25 tracts spliced into TIL11, donor TIL18)**: precision equal to the spiked fraction
  (0.10), genome-wide D unchanged. Not a method failure but a design one: TIL25 is no closer to TIL18 than parviglumis
  is (median ortholog divergence 0.0102 vs 0.0104), so the spliced tracts carried no TIL18-specific signal. A spike-in
  needs a source genome that shares recent ancestry with the donor reference; none of the six qualifies.
- **Pre-registered direction trio {TIL18, TIL25; B73}**: the data never pair the two mexicana (B73 + TIL18 share the
  most k-mers), so ltrmix cannot form it; run post hoc with `scripts/forced_trio.py` (no difference, |Z| <= 1.8).
