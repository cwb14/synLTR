#!/usr/bin/env python3
"""Calibration of the two locality nulls in `ltrkin source` (bp share; source-cluster permutation).
Copies of a simulated genealogy (sim_source.py) are re-placed on chromosomes at random R times (per-chromosome
copy counts kept), the sources table is relabeled, and both tests are rerun. Under random placement the false
positive rate at alpha should be ~alpha. Usage: calibrate_locality.py SIMDIR LTRKIN_PREFIX [R]"""
import sys
import numpy as np
import pandas as pd
from ltrkin.source import locality_test

sim, prefix = sys.argv[1], sys.argv[2]
R = int(sys.argv[3]) if len(sys.argv) > 3 else 200
T = pd.read_csv(f"{sim}/truth.tsv", sep="\t").set_index("element_id")
S = pd.read_csv(f"{prefix}.sources.tsv", sep="\t")
S = S[(S.divergence <= 0.002) & ~S["flags"].str.contains("segdup")].copy()
S["weight"] = 1.0 / S.groupby("new_id").new_id.transform("size")
rng = np.random.default_rng(5)
res = []
for r in range(R):
    lab = pd.Series(rng.permutation(T.chrom.values), index=T.index)
    share = lab.value_counts(normalize=True)
    d = S.assign(new_chrom=lab.reindex(S.new_id).values, source_chrom=lab.reindex(S.source_id).values)
    d["same_chrom"] = d.new_chrom == d.source_chrom
    t = locality_test(d, share, rng, n_perm=1000)
    res.append((t["p"], t["perm_p"], t["obs_exp"], t["perm_obs_exp"]))
x = pd.DataFrame(res, columns=["p_bp", "p_perm", "oe_bp", "oe_perm"])
print(f"{sim.rstrip('/').split('/')[-1]}: R {R}; FPR bp a=0.05 {np.mean(x.p_bp <= 0.05):.3f}, a=0.01 {np.mean(x.p_bp <= 0.01):.3f}; "
      f"FPR perm a=0.05 {np.mean(x.p_perm <= 0.05):.3f}, a=0.01 {np.mean(x.p_perm <= 0.01):.3f}; "
      f"O/E bp median {x.oe_bp.median():.2f} [{x.oe_bp.quantile(.05):.2f}-{x.oe_bp.quantile(.95):.2f}]; perm median {x.oe_perm.median():.2f}")
