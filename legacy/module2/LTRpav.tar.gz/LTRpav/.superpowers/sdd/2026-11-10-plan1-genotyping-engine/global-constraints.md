# Global constraints (bind every task) — copied from the plan's Global Constraints + controller rulings

Repo: /data2/chris/maize_introgression/LTRpav (branch plan1-engine). Env: `ltrpav` (created in Task 1); run tools as
`mamba run -n ltrpav <cmd>` (or activate it).

## From the plan (verbatim)
- Python `>=3.10`; CI matrix 3.10, 3.12, 3.13; package `ltrpav`, src layout, hatchling, `GPL-3.0-or-later`.
- Author everywhere: `Chris Benson <oulab.osu@gmail.com>` (as in `code/LTRquest/pyproject.toml`). No AI attribution in
  any file, commit message or trailer. Commit with the existing global git identity; never set author/committer.
- Commits are local, on branch `plan1-engine`; never push.
- `os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")` runs before numpy is imported (`src/ltrpav/__init__.py`).
- Never load a whole genome: FASTA access only through `seqio.Fasta.fetch` (pysam random access).
- Real-data jobs: <= 64 threads and <= 250 GB RAM; anything over 15 min runs as
  `setsid -f nohup <cmd> > log 2>&1 < /dev/null`, PID verified (`pgrep -af`, then `ps -o pid,ppid,sid,cmd`).
- `run/`, `inputs/` and every LTRmix result are read-only. Real-run outputs go under
  `/data2/chris/maize_introgression/benchmark_pav/`.
- Thresholds come from `src/ltrpav/constants.py` (one line of reason each); never tune one against a truth set.
- Coordinates: internal 0-based half-open; every file a user reads is 1-based inclusive (GFF3, TSV, VCF), except BED.
- CLI: argparse, short help, `-v/--verbose`; default log = start, milestones, done, errors.
- American English in code, docs and messages.

## Controller rulings that bind every task
- Commit messages: plain subject (+ optional body). NO trailers of any kind: no `Co-Authored-By`, no
  "Generated with", no links. If a hook blocks a commit for attribution, remove the attribution and retry.
- Coordinate exception (explicit in the plan's interfaces): `Element` records, `Call` B coordinates and locus
  coordinates are 1-based inclusive (they mirror GFF3); computational structures (blocks, windows, AlnMap, Gap,
  Piece, SimGenome) are 0-based half-open.
- Tests: pytest, small synthetic fixtures, seeded randomness, no network, no real genomes (except `slow`-marked).
  Test output must be pristine (no warnings).
- Never read or modify `docs/plans/` or `.superpowers/` except the brief/report files you are pointed at.
