# Task 11a report

Commit: 78a7c05 "Clear Task 7 review minors: variant rerun advice, DESIGN 7.3/7.4 wording, a block-size test" (on plan3-benchmark, BASE 4f3973e).

## Implemented
1. m2: `report._rerun_advice(outdir, stage)` reads the stage marker's options (`stage_options`) and names every non-default
   one as its flag. Default: "ltrpav-paint (or ltrpav run)" (unchanged text in findings.txt). Variant:
   "ltrpav-paint --discovery any --emission decoy (ltrpav run remakes it at the defaults)". Used in `_LEFT_OUT` (now takes {advice})
   and in the `stale_parts` WARNING, whose wording is now "...until the paint stage reruns, with <advice>: <why>".
   Generic over OPTIONS, so a stale stats part made with --block-size names `--block-size N` too.
2. m3: DESIGN 7.4 "NA when the fit collapsed or the painting was skipped".
3. m4: paint.py module docstring paragraph rewrapped (width <= 115, same words).
4. m5: test_block_size_reaches_every_jackknife spies on report.trio_tests, direction, identity_layer (identity stubbed: no LASTZ
   alignment) and asserts each gets 40,000 by rule and 1,000,000 with --block-size.
5. m1: DESIGN 7.3 clause (removes identity.tsv, painting left out until paint reruns; own copy of the run dir or repeat --identity);
   10.4 stability bullet points to it.

## TDD
- RED (m2): `pytest -W error -q tests/test_cli_analysis.py -k advice_names` on the old report.py:
  `AssertionError: ... 'stage reruns, with ltrpav-paint (or ltrpav run): ' in 'paint: its part is left out ... until the paint stage reruns (ltrpav-paint or ltrpav run): its parameters differ (backend_version)'`
- RED (m5), mutants of report.py (restored after): `direction(cat, 40_000, dist)` gives
  `{'trio_tests': {1000000}, 'direction': {40000}, 'identity_layer': {1000000}}`; identity_layer with 40_000 gives
  `{..., 'direction': {1000000}, 'identity_layer': {40000}}`; both fail the assertion.
- GREEN: `pytest -W error -q tests/test_cli_analysis.py -k "advice_names or reaches_every or block_size_option or left_out or stale or marker"`: 9 passed, no warnings. `ruff check .`: All checks passed.
  (A larger run of test_cli_analysis + test_paint + test_overview started earlier exceeded the tool wait and was left to the full suite.)

## Fingerprints (repo src vs snap/12d3e6c/src): identical, all 7
elements a78af75d...c8dab; anchor/raw/blastdb ebbfd97f...c977d; mm2_index 28f6fc79...822a02;
genotype_pair/genotype_chunk 52071c27...38b361 (full hashes equal in both outputs; engine files untouched).

## Suite
Detached: `setsid -f nohup bash -c 'cd .../LTRpav && NUMPY_MADVISE_HUGEPAGE=0 .../envs/ltrpav/bin/python -m pytest -W error -m "not slow" -q > SUITE_DIR/suite.log 2>&1; echo $? > SUITE_DIR/suite.exit'`
SUITE_DIR=/tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3t11a/suite (PID 2071796 at launch).

## Files changed
docs/DESIGN.md, src/ltrpav/analysis/paint.py, src/ltrpav/analysis/report.py, tests/test_cli_analysis.py.

## Self-review / concerns
- The stale_parts WARNING wording changed for default parts too (now "stage reruns, with ltrpav-paint (or ltrpav run): why"); no existing test pinned the old text. findings.txt default line is byte-identical.
- An earlier foreground pytest (3 files) was moved to background by the tool and may still be running; it reads the tree and is harmless.
- Briefly wrote two temp fingerprint files and a backup into /tmp/claude-1007/ (outside the scratchpad); removed.
