# Task 8 Part A report (Steps 1-8)

Snapshot 4f3973e. Outputs under `$P/benchmark_pav/plan3/` (P=/data2/chris/maize_introgression).

## Files
All under `$P/benchmark_pav/plan3/` (nothing in the repo; `git status` clean at 4f3973e).
- `snap/4f3973e/` (src + SHA)
- `common/env.sh`, `common/view.sh`, `common/numba_cache/` (numba's cache, redirected out of LTRmix/)
- `sim/backbone.py`, `sim/backbone.tsv`
- `sim/calibrate.sh`, `sim/calibrate.log`, `sim/calibration.tsv`, `sim/demography.json`
- `sim/probe_direction.py`, `sim/direction_predictions.tsv`(+`.done`), `sim/direction_counts.tsv`,
  `sim/direction_jobs/`, `sim/probe_direction.{log,time,exit}`
- `sim/make_grid.py`, `sim/grid.tsv` (30 bottleneck nulls; Step 11 regenerates)
- `sim/run_one.sh`, `sim/run_grid.sh`
- `sim/gff3_to_ltrmix.py`, `sim/test_gff3_to_ltrmix.py`
- `sim/memo.md` (Part A section; Part B sections as headings)
- `sim/probes/` unchanged (SHA256SUMS still match: checked below)
Not created (Part B): `sim/pilot.tsv`, `sim/pilot/`, `sim/runs/`.

## Step 1: snapshot, env.sh, view.sh
- Snapshot: `cd $P/LTRpav && git archive 4f3973e src | tar -x -C $P/benchmark_pav/plan3/snap/4f3973e`;
  `snap/4f3973e/SHA` = 4f3973e39ad663764b71e45d7750fe5727e69e96. Repo untouched (`git status` clean).
- `common/env.sh`: exports P, PLAN3, SNAP_SHA, SNAP, LTRPAV_ENV, LTRMIX_ENV, LTRMIX_PY, LTRMIX_DIR;
  `PYTHONPATH=$SNAP/src`, `NUMPY_MADVISE_HUGEPAGE=0`, `PYTHONDONTWRITEBYTECODE=1`, env ltrpav's bin first on PATH
  (R7: lastz), and `NUMBA_CACHE_DIR=$PLAN3/common/numba_cache` (LTRmix's `@njit(cache=True)` kernels otherwise write
  `.nbi/.nbc` files into the read-only `$P/LTRmix/__pycache__`). Asserts with env ltrpav's python that
  `ltrpav.__file__` is under `$SNAP/src` and that SHA matches the directory name; on failure prints one line and
  returns 1.
  - Checked: sourcing gives `ltrpav.__file__` = `snap/4f3973e/src/ltrpav/__init__.py`, ltrpav-genotype and lastz
    from env ltrpav; a snapshot dir without `src/ltrpav` fails with
    `env.sh: ltrpav imported from .../LTRpav/src/ltrpav/__init__.py, not from the snapshot ...` (rc 1).
- `common/view.sh RUN VIEW SHEET [PAIRS_FILTER]`: see Steps 6-7 for its toy check.

## Step 2: backbone
- `sim/backbone.py` (snapshot `load_annotation` + `ltrpav.sim.donors.backbone_elements`, the elements `ltrpav-sim pop`
  carries) writes `sim/backbone.tsv` (region seqid start end length elements inside_raw n_frac note).
- All ten windows match the brief: elements 582 555 597 594 515 658 609 586 584 612 (raw fully-inside count equal);
  chr1 N fraction 0.0053, all others <= 0.0002.
- The drafting draw reproduces exactly: `rng = numpy.random.default_rng(20261112)`, then per chromosome chr1..chr10
  `s0 = rng.integers(0, length - 10_000_000 + 1)`, region `s0+1 .. s0+10_000_000`. The script redraws and checks it.
- Run: `. common/env.sh && python sim/backbone.py > sim/backbone.tsv` (29.8 s, 0.24 GB).

## Step 3: calibration
Command: `cd $PLAN3/sim && OMP_NUM_THREADS=1 timeout 15m ./calibrate.sh 2>&1 | tee calibrate.log` (one process,
624 s wall, 0.70 GB peak; run before the queue stop: one process is under R2's 4-process threshold). Writes
`sim/calibration.tsv` (parameter value command source; sources carry sha256 prefixes) and `sim/demography.json`
(only the three calibrated fields; every other Demog/Rates field stays the snapshot's LTRmix default). The written
JSON is read back through the snapshot's `demog_from_json` and checked.

| Value | Calibrated (exact) | Drafting | Command (in calibrate.sh) | Source |
|---|---|---|---|---|
| kept elements | 9,219 | - | B73__Zd rows with `level` 0 and state P/S/T | main3/pairs/B73__Zd.calls.tsv.gz |
| TIL18 states of kept | D 468, E 188, G 2, O 583, P 5,580, S 334, T 1,405, U 659 | - | join by eid | main3/pairs/B73__TIL18.calls.tsv.gz |
| TIL01 states of kept | D 393, E 173, G 8, O 480, P 6,013, S 312, T 1,280, U 560 | - | join by eid | main3/pairs/B73__TIL01.calls.tsv.gz |
| pooled S, D, T, O | 646, 861, 2,685, 1,063 (sum 5,255) | 646, 861, 2,685, 1,063 | sum over both sisters | both |
| `loss_split` (solo, del_flank, del_partial, replace) | 0.12293054234062797, 0.1638439581351094, 0.510941960038059, 0.20228353948620362 | 0.123, 0.164, 0.511, 0.202 | counts / 5,255 | both |
| `replace_mean` | 13,538.154280338664 bp (1,063 O calls, all with b_ins) | 13,538 | mean b_ins of the O calls, pooled | both |
| conflict bound | 0.0323232 (TIL18; B73 0.0267723, TIL01 0.031446) | 0.032 | max `outgroup_conflict frac_E` | main3_analyses/stats.tsv |
| `t_o` | 900,000 | 900,000 | smallest candidate with conflict <= bound in A1, B1, C1 | simulation |

Outgroup-split candidates (probe_outgroup's computation through the snapshot's `popmodel.ancestry`, i.e.
`popmodel.demography`: `Demog(t_o=X)`, default Rates, one 10-Mb chromosome, msprime seed 11, binary insertions at
lam 1.2e-10 with seed 12, denominator 58 backbone elements/Mb + insertions in O and an ingroup genome):

| t_o | conflict A1 / B1 / C1 | <= 0.0323? | D_pav-informative /Mb | painting-informative /Mb | A1 insertions /Mb | sim s |
|---|---|---|---|---|---|---|
| 120,000 | 0.2290 / 0.2043 / 0.2023 | no | 10.0 | 18.4 | 67 | 67 |
| 300,000 | 0.1383 / 0.1408 / 0.1420 | no | 13.9 | 21.7 | 83 | 86 |
| 600,000 | 0.0633 / 0.0694 / 0.0528 | no | 15.5 | 26.8 | 118 | 137 |
| **900,000** | **0.0165 / 0.0248 / 0.0165** | **yes (chosen)** | 17.0 | 28.4 | 146 | 171 |
| 1,200,000 | 0.0068 / 0.0068 / 0.0085 | yes | 19.5 | 28.4 | 180 | 157 |

Every candidate the drafting probe also ran (120k, 600k, 900k, 1.2M) reproduces its values to the third decimal; the
probe's own msprime Demography and the snapshot's `popmodel.demography` give the same genealogy at seed 11. The
choice is the same under the brief's rounded 0.032 (600k is above both, 900k below both). The bound includes
genotyping errors, so the chosen split is the shallowest consistent with main3 (an upper bound), not a fit.

## Queue stop (R2)
- Stopped before Step 4's 16-process run (Steps 1-3 ran at most 2 processes; calibration was one process).
- Before: `ps` showed group 1563670 = `bash genotype_all.sh` (PPID 1, SID 1563670, 6 h 23 min elapsed), `/usr/bin/time
  ... ltrpav-genotype --samples .../real/six/samples...`, `mem_sampler.sh`, ltrpav-genotype python (11.0 GB RSS).
- `kill -TERM -- -1563670` at **2026-11-13 00:43:40 EST** (rc 0). At 00:43:46 `pgrep -af
  'genotype_all|ltrpav-genotype|lastz|mem_sampler'` showed none, and no process had PGID 1563670.
- Pair files done (`ls real/six/geno/pairs/*.done.json`): **19 of 36**: B73__{PT,TIL01,TIL11,TIL18,TIL25,Zd},
  PT__{B73,TIL01,TIL11,TIL18,TIL25,Zd}, TIL11__B73, TIL25__{B73,PT,TIL01,TIL11,TIL18,Zd}.
- Nothing else in `plan3/real/` was touched (only that `ls` and the `ps` listing). The queue stays stopped for the
  controller to relaunch after the grid.

## Step 4: direction predictions
- `sim/probe_direction.py` (from `probes/probe_direction.py`): scenarios = the grid's rows of kinds null, power,
  reverse, ptlike, bneck, posctl grouped by name without the replicate suffix (29 scenarios; the rows of a scenario
  must agree on every field). Each scenario's demography is built as `ltrpav-sim pop` builds it (demography.json, the
  row's sub/ne, then f, ta, pulse, per_taxon, bottleneck) and simulated by the snapshot's `popmodel.ancestry`
  (= `popmodel.demography`), 4 x 10 Mb (posctl 30 x 10 Mb), msprime seeds 100+c, binary insertions at the calibrated
  lam with seeds 900+c (the drafting probe's seeds). Quartet A1 A2 C1 C2, B1 B2 O1 absent. `DFOIL_ALT` (the pattern
  pairs), `DFOIL_ALT_SIGNS`, `STATS` imported from `ltrpav.analysis.direction`, `Z_SIG` from
  `ltrpav.analysis.constants`; Z binomial with the drafting probe's 0.5 continuity term (no block jackknife).
  Per-(scenario, chromosome) JSON in `sim/direction_jobs/` (resumable; a job is reused only at the same length and
  fields).
- Small functional test first (2 x 2 Mb, 2 processes, scratch): pc_C1A1 `+-+0`.
- Detached run (after the queue stop), launched 2026-11-13 00:43:58:
  `setsid -f nohup bash -c '. common/env.sh && export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 &&
  /usr/bin/time -v -o sim/probe_direction.time python sim/probe_direction.py --workers 16; echo $? >
  sim/probe_direction.exit' > sim/probe_direction.log 2>&1 < /dev/null`; launcher PID 2823424, PPID 1, SID 2823424.
  Waited with a Monitor until-loop. **Exit 0, 13 min 18 s wall, 0.18 GB peak (main process), 194 chromosome jobs;
  `direction_predictions.tsv.done` written.** Posctl chromosomes take about 1.4 s each (all Ne 1,000); the others
  100-150 s.

| scenario | code | label | expected (drafting) |
|---|---|---|---|
| null | 0000 | none | 0000 |
| f{0.02,0.05,0.10,0.25,0.50} x Ta{50,500,5000} (15) | 0000 | none | 0000 |
| f0.18_Ta50 | **00+0** | none | 0000 |
| f0.18_Ta500 | **0-0-** | none | 0000 |
| f0.18_Ta5000 | 0000 | none | 0000 |
| rev_f{0.10,0.25}_Ta{500,5000} (4) | 0000 | none | 0000 |
| pt | 0000 | none | 0000 |
| bn_null, bn_f0.18_Ta5000 | 0000 | none | 0000 |
| pc_C1A1 | +-+0 | P3=>P1 | +-+0 (P3=>P1) |
| pc_A1C1 | +++- | P1=>P3 | +++- (P1=>P3) |
| pc_null | 0000 | none | 0000 |

- **Labels: every prediction matches the brief** ("none" for every population and PT-like pulse; both posctl
  directions orient; posctl null none). Posctl counts equal the drafting probe's tb2k rows exactly (C1>A1 DFO 510/0,
  DFI 1046/0, DOL 536/510; A1>C1 149/6, 113/42, 42/6, 6/42), so direction power is estimable under this demography.
- **Deviation in two codes (labels unchanged):** f0.18_Ta50 `00+0` (DFI +0.165, Z 3.03, 191/137) and f0.18_Ta500
  `0-0-` (DIL -0.194, Z -3.37, 116/172; DOL -0.151, Z -3.17, 183/248). Neither code is in the sign table, so both
  read "none". Per chromosome, f0.18_Ta500's A1-only vs A2-only donor patterns (1011 vs 0111) are 12/28, 22/40,
  11/21 and 46/20: the sign flips between chromosomes, i.e. a population-wide pulse at Ta <= 500 landing unequally in
  A1 and A2 by chance, which the P1-vs-P2 contrasts (DIL, DOL) read, and which the binomial Z treats as independent
  sites (linked insertions are overdispersed; the method's block jackknife absorbs this). Not a systematic
  direction. 3 of 104 non-posctl statistics reach |Z| >= 3 against ~0.3 expected under a valid N(0, 1), consistent
  with that overdispersion. Task 9's RULES.md should state the prediction by label ("none"), and note that single
  significant statistics outside the sign table occur in the gene-flow scenarios.
- f0.02_Ta50 and f0.05_Ta50 give identical counts: common random numbers (same seeds) and no sampled lineage moved
  by a 50-generation pulse at f <= 0.05 on these chromosomes.
- Files: `sim/direction_predictions.tsv` (scenario code label), `sim/direction_counts.tsv` (D, Z, left/right per
  statistic, n(C->A), n(A->C), simulation seconds), `sim/direction_jobs/` (194 JSON), `sim/probe_direction.{log,time,exit}`.

## Step 5: grid
- `sim/make_grid.py --bneck-nulls 30` wrote `sim/grid.tsv`: **144 rows = 118 on 7 genomes (88 + 30 bottleneck nulls) +
  26 trios**; by kind null 30, power 36, reverse 8, ptlike 3, bneck 33, posctl 8, dropout 26.
  `--bneck-nulls 10` (checked into scratch): 124 rows = 98 + 26, every non-null row byte-identical.
- Columns as the brief: `name design per_taxon f ta pulse sub ne bottleneck dropout_A1 seed kind`. An empty cell is
  "not set" (ta and pulse are empty at f = 0, so the simulator's defaults stand; no pulse happens at f = 0).
  `sub` is `sub_a:SPLIT,NE;sub_c:SPLIT,NE`; `ne` = 1000 sets ne_a, ne_b, ne_c, ne_bc, ne_o, ne_root (posctl only).
- ptlike's `sub_a (6000, ne_a)` is resolved at grid time from demography.json/Demog: `sub_a:6000,30000`.
- Seeds: null 101-130; power 1001-1036 (f outer, Ta, replicate inner); reverse 3001-3008; ptlike 5001-5003;
  bn_null_s{i} = 4000+i, bn_f0.18_Ta5000_r{1,2,3} = 4031-4033 at either N (so the gate's regeneration changes only the
  nulls); posctl pc_C1A1 6001-6003, pc_A1C1 6004-6006, pc_null 6007-6008; dropout in the brief's brace order:
  fn0.2_null_s1-10 2001-2010, fn0.4_null_s1-10 2011-2020, fn0.2_f0.18_r1-3 2021-2023, fn0.4_f0.18_r1-3 2024-2026.
- Names keep the brief's literal f strings (`f0.10_Ta500_r1`, `f0.50_...`; `pc_*` f 0.5).
- Every row is checked when the grid is written: row.json (demography.json + sub/ne) read by the snapshot's
  `demog_from_json`, then the CLI fields (f, ta, pulse, per_taxon, bottleneck) applied through `Demog`, as
  `ltrpav-sim pop` does. Names and seeds are unique.
- `make_grid.py --row-json NAME OUT` writes a row's row.json (run_one.sh's sim step uses it); null rows give exactly
  demography.json; pc rows add sub_a [2000, 1000], sub_c [30000, 1000] and the six ne fields at 1000.

## Steps 6-7: run_one.sh, run_grid.sh (and view.sh's checks)
**run_one.sh NAME [--from S] [--until S] [--rundir D] [--runs D] [--grid TSV] [--backbone TSV] [--windows N] [--dry-run]**
- Sources env.sh; reads NAME's row by column name (split on `\x1f`, see bug below); runs sim, geno, views, ltrmix,
  eval in DIR (default `sim/runs/NAME`), each as `/usr/bin/time -v -o <step>.time bash -c step_<step>` with output in
  `<step>.log`; `run.exit` from an EXIT trap (255 mapped to 1 for xargs); `run.done` after eval; one-line milestones
  to stderr and `run.log` (wall time and peak RSS per step).
- Markers `<step>.done`; a step that runs clears every later marker and run.done; `--from S` clears S and later and
  requires the earlier markers; `--until S` stops after S. `sim.done` records the row, backbone and windows: a run
  dir simulated from another row/backbone/window count is refused ("move it aside"), never silently skipped.
- sim: `rm -rf sim row.json geno views lib ltrmix eval rate_free_split.*` (R3: ltrpav-sim refuses a non-empty outdir;
  a new simulation invalidates everything derived), `make_grid.py --row-json NAME row.json`, then `ltrpav-sim pop
  --fasta $P/inputs/B73v5.fa --region x10 --annotation $P/run/B73v5_LTRs --outdir sim --demography row.json --seed S
  --f F [--ta T] [--pulse P] --per-taxon N [--bottleneck 5000,2000] [--dropout-genome A1=X] --dropout 0.1 --jitter 0.05
  --threads 16`, then `mv row.json sim/row.json`. **Deviation:** the brief's `--demography sim/row.json` cannot work
  (ltrpav-sim pop refuses an outdir holding row.json, Task 5 m4), so row.json is written in the run dir and moved into
  sim/ after the simulation; sim/row.json still records the merged fields. Base annotation passed explicitly.
- geno: `ltrpav-genotype --samples sim/samples.tsv --outdir geno --threads 16`; `ltrpav-merge ... --outdir geno`.
- views: exactly the brief's table (main with `--identity --threads 16` for kind null; roles without --trio; any,
  decoy, anydecoy each in its own view, R7; nodonor for null and power: `view.sh geno views/nodonor sim/samples.tsv
  C1`, `ltrpav-merge`, `ltrpav-stats --trio A1,B1,C1`).
- ltrmix: `rm -rf lib ltrmix rate_free_split.*`; `gff3_to_ltrmix.py sim/G.gff3 sim/G.fa lib/G` for A1 B1 C1 C2 (A1
  B1 C1 in the trio design); `$LTRMIX_PY $P/LTRmix/ltrmix.py --genome G=lib/G.fa,lib/G.tsv ... --outdir ltrmix -t 8
  --no-figure`; for kind null `rate_free_split.py --res ltrmix --donor C1=... --sister B1=... --recipient A1=... -t 8
  --out ltrmix/rate_free_split.tsv > rate_free_split.txt` (in the run dir, the brief's literal path) with its exit
  in `rate_free_split.exit`, not fatal.
- eval: `python sim/eval_run.py DIR` and `$LTRMIX_PY sim/eval_ltrmix.py DIR` (DIR absolute); fails with one line
  while Task 9's scripts are absent.
- `--windows N` (first N backbone windows; Step 11's fallback is `--windows 5`) and `--backbone`, `--runs` were added
  for the gate's fallback and for the toy check below.

**run_grid.sh TSV [--until S] [--windows N] [--backbone TSV] [--runs D] [--dry-run]**: `xargs -P 2 -L 1 run_one.sh
--grid TSV --runs D [--until S] [--windows N]` over the names (rows read from TSV itself); removes each row's old
run.exit first; then `<TSV>.done` when every run.exit is 0 and the last requested marker exists, else
`<TSV>.failed` (`name<TAB>exit`, or `none`/`no-marker`); `<TSV>.exit` always.

**Bug found and fixed in the dry-run:** bash `read -a` with IFS=tab collapses runs of empty cells, so the null row
read seed '' and pulse 'null'. Rows are now split on `\x1f`, with a field-count check.

**Checks**
- Dry-runs (`run_one.sh NAME --dry-run`) for null_s101, f0.18_Ta5000_r1, rev_f0.10_Ta500_r1, pt_r1, bn_null_s1,
  bn_f0.18_Ta5000_r1, pc_C1A1_r1, pc_null_r1, fn0.4_f0.18_r2, fn0.2_null_s3: every command as the brief (identity,
  nodonor and rate_free_split only where due; `--pulse C>A1` / `C1>A1`, `--bottleneck 5000,2000`,
  `--dropout-genome A1=0.4`, 3 libraries for trios). `--from eval --until sim` -> error (rc 1); unknown row -> error
  (rc 1); unknown step -> rc 2. `run_grid.sh pilot-like.tsv --until ltrmix --dry-run` (null_s101, f0.18_Ta5000_r1)
  prints both runs' sim/geno/views/ltrmix commands, writes no marker and creates no `sim/runs/`.
- view.sh: new view, reuse of the same view (rc 0, samples.tsv unchanged), existing non-view dir and empty dir
  refused, same dir with another filter refused, filter not a label / unannotated label refused, RUN without
  manifest refused, usage rc 2.
- **Toy end-to-end 1** (scratch; 2 x 1.5-Mb windows, `--windows 2`, null_s101 through ltrmix, 16 threads while
  Step 4 ran 16): sim 24 s, geno 128 s (36 pair files), views 44 s, ltrmix 49 s. nodonor: 30 pair files linked
  (no C1__*), C1 annotation '.', merge read the element tables from cache (`elements done, skip`; RUN's tables
  unchanged), D_pav discovered by C2 (`disc=C2`), the decision-11 fallback. Rerun: every step `done, skip`;
  `--windows 1` against it -> refused (run.exit 1). LTRmix found **0** orthologs: with two chromosomes its
  chromosome-pair enrichment test (Poisson, alpha 1e-6/pairs) cannot pass (95 anchors; observed ~48 vs expected ~24
  per pair), so it builds no blocks. A toy-scale artifact, confirmed by toy 2.
- **Toy end-to-end 2** (5 x 1.5-Mb windows; `run_grid.sh toy.tsv --until ltrmix --backbone ... --windows 5 --runs
  ...` launched with `setsid -f nohup`, PID 318775, PPID 1, SID = PID; rows null_s101 and fn0.2_f0.18_r1, two at a
  time): **`toy.tsv.done`, exit 0** in 9 min. null_s101: sim 20 s (0.49 GB), geno 4 min 16 s (0.41 GB), views
  1 min 3 s, ltrmix 3 min 29 s (1.35 GB); A1 14.2 Mb from a 7.5-Mb backbone, 834 elements. LTRmix: 231-285 1:1
  orthologs per pair; with 4 libraries the trios are in `ltrmix/A1_B1_C1/` etc. and orthologs at the root; with 3
  (trio row) the trio's files are in `ltrmix/` itself. rate_free_split printed its s line (`s (split, substitutions
  per LTR site) = 0.00112, 95% block bootstrap 0.00097-0.00337`) then failed in the LTRquest-only section (exit 1
  recorded). After moving the command echo to stderr, `--from ltrmix --until ltrmix` reran only ltrmix (178 s) and
  `rate_free_split.txt` holds the script's stdout only.
- Failure path: a row with seed `notanumber` -> sim FAILED (exit 2) in 2 s, `bad.tsv.failed` = `bad_seed 1`,
  `bad.tsv.exit` = 1.
- Inputs: `inputs/B73v5.fa.fai` size, mtime and sha256 identical before and after; `LTRmix/__pycache__` still 130
  files; nothing newer than the snapshot in run/, inputs/, LTRmix/, benchmark/scripts/; repo clean.

## Step 8: converter and test
- R6: env `ltrmix` imports `ltrmix` with `$P/LTRmix` on sys.path (it is a script, not an installed package:
  `import ltrmix` alone fails with ModuleNotFoundError, as for rate_free_split.py, which inserts the path itself).
- `sim/gff3_to_ltrmix.py GFF3 FASTA OUTPREFIX`: reads the GFF3 with the snapshot's own `load_gff3` (LTRmix and LTRpav
  see the same elements), fetches each span with pysam through the .fai, header `seqid:start-end#LTR/<sf|unknown>`,
  minus strand reverse-complemented, table `seq_id k2p tsd strand ltr5_len ltr3_len` (k2p `%.6g` or nan, tsd '.'
  unless ACGT, ltr5 = genome-left LTR), written atomically; fails fast on a seqid missing from the FASTA, an
  element past its sequence end, or a duplicate name.
- Test: `. common/env.sh && cd sim && python -m pytest -q -p no:cacheprovider test_gff3_to_ltrmix.py` ->
  **`4 passed in 1.32s`** (reruns after the check=False edit: 4 passed in 1.36 s, 1.3 s). Tests: exact headers, sequences (plus as is, minus reverse-
  complemented across a wrapped FASTA line) and table rows; env ltrmix's `ltrmix.load_library` reads the toy
  library: n 2, names, chrom/start/end parsed from the names, strand, k2p (0.0123, nan), canonical TSD, l5/l3
  (5/5, 5/7), cls; two fail-fast cases leave no output. `$P/LTRmix/__pycache__` unchanged (130 files) after the
  tests, numba cache redirected to `common/numba_cache`.

## Concerns (and what Part B must know)
1. **Queue stopped** at 2026-11-13 00:43:40 EST with 19 of 36 six-genome pair files done; not relaunched (R2).
2. **Server load.** Load average ~200 on 256 cores from other jobs (other users' minimap2/bwa, and this user's other
   projects: rmfast, cenfuse, samtools, rmblastn), 400 GB free. The pilot's h7 (the gate's input) is measured under
   this contention; Part B should record the load average beside the pilot's times.
3. **LTRmix step may cost more than the plan's ~6-min "merge, views, LTRmix, scoring" share.** At toy scale (4
   libraries, ~800 elements each) LTRmix took 3.5 min (6 orthology pairs, 4 trios; under load). The pilot measures it.
4. **LTRmix needs several chromosomes.** Its enrichment test failed with two toy chromosomes (0 orthologs). Ten
   (or five under the 50-Mb fallback) 10-Mb windows with ~600 elements each are far above that; noted for any
   future small test.
5. **rate_free_split.txt is in the run dir** (the brief's literal path), with `rate_free_split.exit`; its `--out` is
   `ltrmix/rate_free_split.tsv`. Task 9's eval_ltrmix.py should read the s line from `RUN/rate_free_split.txt`.
6. **row.json location**: written in the run dir, moved to `sim/row.json` after the sim (ltrpav-sim pop refuses a
   non-empty outdir). Same content the brief describes.
7. **Direction codes**: two power scenarios have single significant statistics outside the sign table (labels
   "none"); RULES.md should state predictions by label. Binomial Z (no jackknife) is optimistic.
8. **Grid file holds 30 bottleneck nulls** until Step 11 regenerates it (`make_grid.py --bneck-nulls 10` changes only
   the bn_null rows; gene-flow seeds stay 4031-4033).
9. **50-Mb fallback**: `run_grid.sh grid.tsv --windows 5` (and the pilot dirs moved to `runs/<name>.100Mb`); a run dir
   simulated on 10 windows is refused by a 5-window call, so a forgotten move fails loudly.
10. **Views of a moved run** keep absolute FASTA/GFF3 paths in their samples.tsv (the brief's design): never analyze
    the views of a moved-aside run.
11. **Genome growth**: the toy A1 genome was 14.2 Mb on a 7.5-Mb backbone (1.9x), in line with R4's 92-99%; the
    pilot will show ~180-195 Mb genomes rather than the plan's ~177 Mb estimate if this holds at 100 Mb.
12. **Lint**: `probe_direction.py` keeps two cosmetic ruff findings (an unused import, `se == se`) so that the file is
    byte-identical to the one that produced the predictions (sha256 639bbba66873a582...).
13. Toy runs are in the session scratchpad (`.../scratchpad/toy`, `toy2`, `fail`; ~1 GB), not in plan3.

---

# Task 8 Part B report (Steps 9-11)

Started 2026-11-13 ~01:35 EST. Snapshot 4f3973e. Paths under `$P/benchmark_pav/plan3/` unless absolute. Filled in
as steps finish; a section still marked PENDING was not reached.

## R9 first fixes (m1, m2, m4)
Originals kept in scratch (`.../scratchpad/p3t8b/orig/`). Toy checks in `.../scratchpad/p3t8b/` (P3T8B below).
- **m1, `common/env.sh`.** env ltrpav's bin is now always first on PATH (an earlier copy further down is removed, so
  repeated sourcing does not grow PATH). The assertion runs `python` as found on PATH (the interpreter the harness
  calls) and checks `realpath(sys.prefix) == $LTRPAV_ENV`, then the snapshot import as before.
  Toy checks (`env -i`, clean shells):
  - PATH = ltrmix bin, ltrpav bin, /usr/bin: new env.sh -> rc 0, `python` = env ltrpav's, ltrpav from
    `snap/4f3973e/src`, ltrpav bin listed once and first. The original env.sh under the same PATH -> rc 0 with
    `python` = ltrmix's (the defect, reproduced).
  - Sourced twice: PATH identical.
  - A copy whose LTRPAV_ENV is a fake env with `bin/python` -> ltrmix's python: rc 1, `env.sh: python on PATH is
    .../fakeenv/bin/python (prefix .../envs/ltrmix), not env ltrpav's (.../fakeenv)`.
  - Under `set -euo pipefail` (as run_one.sh sources it): rc 0.
- **m2, `sim/run_one.sh`.** After `mkdir -p DIR; cd DIR`: `exec 9>> DIR/.lock; flock -n 9 || die "DIR is in use by
  another run_one.sh (lock DIR/.lock held)"`, before `rm -f run.exit` and the EXIT trap, so a refused launch touches
  nothing. fd 9 is inherited by the step processes, so the lock lasts until the run's last process ends (an orphaned
  step still blocks a relaunch); the samplers get `9>&-`. Also (the review's optional half): `run_grid.sh` takes
  `flock -n` on `<TSV>.lock` (fd 8) before it removes any marker.
  Toy check (P3T8B/t2: a 1-row grid, `--until sim --windows 2` on 2 x 1.5-Mb windows): while it ran, a second
  `run_grid.sh` on the same TSV -> rc 1, one line `run_grid.sh: error: .../toy.tsv is in use by another
  run_grid.sh (lock .../toy.tsv.lock held)`, no marker removed; a second `run_one.sh` on the same run dir -> rc 1,
  one line `run_one.sh: error: .../runs/null_s101 is in use by another run_one.sh (lock .../.lock held)`, run.exit
  absent (untouched). The first run then finished normally (`toy.tsv.done`, exit 0); a later relaunch got the lock
  and skipped by marker.
- **m4, `sim/run_one.sh`.** The run-directory checks are one function, `check_rundir`, called by `--dry-run` before
  it prints anything and by a real run after the lock: the steps before `--from` must be done, and a sim.done whose
  signature differs is refused unless `--from sim` reruns it (the real run's old order, where `--from sim` cleared
  sim.done before the check, gives the same rule).
  Toy checks on P3T8B/t2's run and a copy with the seed changed in sim.done's signature:
  - matching dir, `--dry-run --until geno`: `[sim] marker exists: skip`, then geno's commands;
  - changed signature, `--dry-run`: rc 1, `... was simulated from another row or backbone (sim.done); move it aside`
    (Part A's script printed `[sim] marker exists: skip` here, per the review);
  - changed signature, `--from geno --dry-run`: rc 1, same line;
  - changed signature, `--from sim --until sim --dry-run`: allowed (prints the sim commands);
  - `--from views --dry-run` on a dir without geno.done: rc 1, `--from views: step geno is not done in ...`.
- **Measurement (R9, m3), added to the runners:**
  - `common/mem_sampler.sh ROOT OUT STOP`: `real/mem_sampler.sh`'s tree walk (`/proc/<pid>/task/*/children`) and Pss
    sum (`smaps_rollup`) every 5 s, without its limit and kill.
  - `run_one.sh` runs each step's `/usr/bin/time` in the background, samples its tree into `<step>.mem.tsv`, waits,
    then stops the sampler. run.log's lines now read `<step>: start (load average 1m 5m 15m)` and `<step>: done in
    N s, peak RSS X GB (largest process), peak tree PSS Y GB`. The step's wall time is taken when the step ends,
    before the sampler is stopped.
  - `run_grid.sh` samples its own tree (both concurrent runs) into `<TSV>.mem.tsv` and logs the peak, for the
    250-GB budget.
  - `x` now stamps each logged command with the time (`+ [HH:MM:SS] cmd`), so a step can be split by command.
  - Toy check (P3T8B/t2): run.log `sim: start (load average 219.30 208.73 209.62)`, `sim: done in 135 s, peak RSS
    0.32 GB (largest process), peak tree PSS 0.41 GB`; `sim.mem.tsv` 27 samples; the grid log `peak summed PSS
    0.25 GB`. (The toy sim took 135 s at load ~219 against 20 s in Part A's toy: setup contention, as the review
    measured.)
- `bash -n` clean on run_one.sh, run_grid.sh and mem_sampler.sh. view.sh is unchanged.

## Queue stop (R2, R9)
- Before: group 2932602 = `bash genotype_all.sh` (PPID 1, SID 2932602, 27 min elapsed), its `/usr/bin/time ...
  ltrpav-genotype --samples real/six/samples.tsv --outdir real/six/geno --threads 32 -v`, `real/mem_sampler.sh`, 32
  pool workers and their lastz processes.
- `kill -TERM -- -2932602` at **2026-11-13 01:41:43 EST** (rc 0). At 01:41:47 `pgrep -af
  'genotype_all|ltrpav-genotype|lastz|mem_sampler'` showed no process of the queue (the only `plan3/real` match was
  the pgrep's own shell line) and `ps -g 2932602` was empty.
- Pair files done (`ls real/six/geno/pairs/*.done.json`): **20 of 36** (Part A's stop: 19; new: TIL11__PT):
  B73__{PT,TIL01,TIL11,TIL18,TIL25,Zd}, PT__{B73,TIL01,TIL11,TIL18,TIL25,Zd}, TIL11__{B73,PT},
  TIL25__{B73,PT,TIL01,TIL11,TIL18,Zd}.
- Nothing else in `plan3/real/` was touched (the `ls`, the `ps` listing, and reading `real/mem_sampler.sh`). Not
  relaunched: the controller relaunches it after the grid.

## Step 9: pilot launch
- `sim/pilot.tsv`: grid.tsv's header and its rows `null_s101` (kind null, seed 101) and `f0.18_Ta5000_r1` (kind
  power, f 0.18, Ta 5000, pulse C>A, seed 1023), copied verbatim, so the grid later skips them by marker
  (`runs/<name>/`, same row text in sim.done's signature).
- Launched 2026-11-13 01:41:56 EST, from `sim/`:
  `setsid -f nohup ./run_grid.sh pilot.tsv --until ltrmix > pilot/pilot.log 2>&1 < /dev/null`.
  Load average at launch 216.33 / 212.14 / 210.80 (256 cores); 458 GB free, 522 GB available.
- PID check: `pgrep -af 'run_grid.sh pilot.tsv'` -> 1270604; `ps -o pid,ppid,pgid,sid -p 1270604` -> PPID 1,
  PGID 1270604, SID 1270604 (= PID). Children: xargs -P 2 and the grid's mem_sampler.sh.
- Threads: two runs of 16 (the queue stopped; no other job of this task running): 32.
- Waited with a Monitor until-loop on `pilot.tsv.exit` (with `pilot.tsv.done` / `pilot.tsv.failed`), also ending
  if PID 1270604 vanished without it.

## Step 9: per-step measurements
**IN PROGRESS at hand-back (2026-11-13 01:49 EST; the pilot is still running detached, PID 1270604).**

| run | step | wall | GNU peak RSS (largest process) | peak tree PSS | load average at start |
|---|---|---|---|---|---|
| null_s101 | sim | 240 s | 2.48 GB | 6.63 GB | 216.33 212.14 210.80 |
| f0.18_Ta5000_r1 | sim | 233 s | 2.47 GB | 6.33 GB | 216.33 212.14 210.80 |
| null_s101 | geno | running (started 01:45:56) | | | 202.61 209.98 210.58 |
| f0.18_Ta5000_r1 | geno | running (started 01:45:49) | | | 203.53 210.28 210.68 |

- Whole pilot (both runs together), `pilot.tsv.mem.tsv`: peak summed PSS 12.66 GB so far (during sim).
- Genotyping goes pair by pair at 16 threads: pair 1 (A1 vs A2, including index builds) took ~2 min 10 s in each run
  (11,282 calls in null_s101). At that pace 36 pairs take ~75-80 min, so h7 will be ~1.4-1.6 h, not the plan's
  ~68 min (1.13 h). The gate's pass limits at the toy's h_trio/h7 ratio are ~62 min for 30 nulls and ~73 min for
  10. **The 50-Mb fallback is likely, but not decided: the gate has not been applied.**

**Filled by the post-pilot dispatch (2026-11-13 ~03:50-04:10), from `pilot/pilot_100Mb.log`, `pilot/pilot_50Mb.log`
and the runs' geno.log stamps.** The 100-Mb pilot finished 03:03:27, exit 0. The controller moved both runs aside
(`runs/<name>.100Mb`) and reran the two rows at 50 Mb (rule-3 ruling); that run finished 03:46:48, exit 0.

| scale | run | step | wall | GNU peak RSS | peak tree PSS | load at start |
|---|---|---|---|---|---|---|
| 100 Mb | null_s101 | sim | 240 s | 2.48 GB | 6.63 GB | 216 |
| 100 Mb | null_s101 | geno | 3,484 s (ltrpav-genotype 3,466 s) | 1.32 GB | 2.23 GB | 203 |
| 100 Mb | null_s101 | views | 455 s | 0.26 GB | 0.43 GB | 181 |
| 100 Mb | null_s101 | ltrmix | 711 s | 11.66 GB | 11.39 GB | 144 |
| 100 Mb | f0.18_Ta5000_r1 | sim | 233 s | 2.47 GB | 6.33 GB | 216 |
| 100 Mb | f0.18_Ta5000_r1 | geno | 3,573 s (3,547 s) | 1.32 GB | 2.26 GB | 204 |
| 100 Mb | f0.18_Ta5000_r1 | views | 163 s | 0.25 GB | 0.21 GB | 185 |
| 100 Mb | f0.18_Ta5000_r1 | ltrmix | 628 s | 11.94 GB | 11.68 GB | 155 |
| 50 Mb | null_s101 | sim | 197 s | 1.36 GB | 3.26 GB | 136 |
| 50 Mb | null_s101 | geno | 1,695 s (1,688 s) | 0.75 GB | 1.39 GB | 141 |
| 50 Mb | null_s101 | views | 229 s | 0.22 GB | 0.38 GB | 155 |
| 50 Mb | null_s101 | ltrmix | 427 s | 6.44 GB | 6.13 GB | 142 |
| 50 Mb | f0.18_Ta5000_r1 | sim | 182 s | 1.34 GB | 3.19 GB | 136 |
| 50 Mb | f0.18_Ta5000_r1 | geno | 1,705 s (1,697 s) | 0.76 GB | 1.38 GB | 140 |
| 50 Mb | f0.18_Ta5000_r1 | views | 84 s | 0.22 GB | 0.17 GB | 157 |
| 50 Mb | f0.18_Ta5000_r1 | ltrmix | 327 s | 6.33 GB | 5.88 GB | 151 |
| 50 Mb | null_s101 | eval (Task 9) | 14 s | 0.14 GB | 0.41 GB | 159 |
| 50 Mb | f0.18_Ta5000_r1 | eval (Task 9) | 15 s | 0.14 GB | 0.51 GB | 155 |

- Grid peak summed PSS (both runs together): 22.29 GB at 100 Mb, 11.06 GB at 50 Mb. The grid's two concurrent runs
  stay far below the 250-GB budget.
- Halving the backbone halves the genotyping time (3,466-3,547 s to 1,688-1,697 s) and LTRmix's memory (11.4-11.9 to
  5.9-6.1 GB). The sim step falls only from 233-240 s to 182-197 s: its setup (annotation load and FASTA hash) is
  fixed (Part A R3). The 50-Mb pilot ran at a lower load (136-160 against 145-216).

## Step 9: realized counts against the estimates
Partial (from sim/params.json; pair-file count pending):

| quantity | estimate (plan) | null_s101 | f0.18_Ta5000_r1 |
|---|---|---|---|
| genome length | ~177 Mb | 187.2-192.5 Mb (A1 189.4) | 190.7-194.9 Mb (A1 192.7) |
| backbone growth (100 Mb) | (R4: 92-99% in the 20-Mb probe) | 87-93% | 91-95% |
| alive elements / genome | ~13,900 | 12,337-12,705 | 12,559-12,969 |
| annotated elements (dropout 0.1, ingroup) | - | 11,148-11,466 | 11,315-11,715 |
| alive per Mb (A1) | (R4: 67 in the 20-Mb probe; B73 LTRquest 58.5) | 66.1 | 66.9 |
| backbone elements | 5,892 (backbone.tsv) | 5,892 | 5,892 |
| pair files | 36 | 36 | 36 |

At 50 Mb (the grid's scale after the gate; from `pilot/realism.tsv`):

| quantity | null_s101 | f0.18_Ta5000_r1 |
|---|---|---|
| genome length | 96.3-100.7 Mb (A1 98.0) | 95.6-98.5 Mb (A1 96.4) |
| backbone growth (50 Mb) | 93-101% | 91-97% |
| alive elements / genome | 6,389-6,581 | 6,227-6,566 |
| annotated elements (ingroup) | 5,718-5,861 | 5,626-5,904 |
| alive per Mb (A1) | 66.0 | 66.3 |
| backbone elements | 2,843 | 2,843 |
| pair files | 36 | 36 |

Against the plan's estimates at 100 Mb: genomes are 6-10% longer (187-195 Mb against ~177 Mb), and they hold 7-11%
fewer alive elements (12,337-12,969 against ~13,900).

## Step 9: nodonor check
Filled by the post-pilot dispatch. The catalog accepts the view, so `view.sh` was not changed.
- Each run's views.log shows `view.sh ... C1`: 30 pair files, C1's six left out, and C1's annotation `.`. Then
  `ltrpav-merge` reads 7 genomes and 30 pair files without error.
- `views/nodonor/stats.tsv` D_pav (A1,B1;C1, stratum all) falls back to discovery in C2 (`disc=C2`) in all four runs:

| run | D | se | z | n |
|---|---|---|---|---|
| null_s101 (50 Mb) | -0.0486 | 0.0840 | -0.58 | 185 |
| f0.18_Ta5000_r1 (50 Mb) | +0.1925 | 0.0923 | 2.09 | 161 |
| null_s101 (100 Mb) | -0.0215 | 0.0576 | -0.37 | 325 |
| f0.18_Ta5000_r1 (100 Mb) | +0.1118 | 0.0616 | 1.82 | 340 |

- eval_run.py reads the same values (`decision11`: discovery genomes [C2], agree true).

## Step 10: realism check against main3 (with R4's additions)
Not run yet (needs geno and views). Prepared and tested:
- `sim/realism.py RUN [RUN ...] --out TSV`: main3's side and the runs' side with the same definitions (genome
  length, growth, alive/annotated per Mb; qc.tsv state fractions and resolved_frac by taxon-pair class; outgroup
  conflict; D_pav counted/informative per Mb of the discovery genome; painting n_informative per Mb of the
  recipient and spacing_median; K of elements shared with the outgroup, called and truth). Tested on Part A's toy
  run (4.6 s).
- main3's side, already computed: B73 2,182.1 Mb, 58.5 elements/Mb (41.9 level 0); TIL18 2,493.7 Mb, 50.0; TIL01
  2,616.8 Mb, 52.7; Zd 3,290.9 Mb. resolved_frac: ingroup pairs 0.43-0.52, X>Zd 0.25-0.27. outgroup_conflict
  frac_E 0.0268 / 0.0323 / 0.0314. D_pav(B73,TIL01;TIL18): D 0.291, 2,041 informative (0.82/Mb of TIL18), 14,067
  counted (5.64/Mb). Painting: n_informative 7,515 (3.44/Mb of B73), spacing_median 84,400 bp. K of B73 elements
  called P in B73>Zd: n 6,336, median 0.0603 (q25 0.0416, q75 0.0972), mean 0.0809.
- Toy-scale preview (Part A's 7.5-Mb toy, not the pilot): resolved_frac ~0.72-0.84 ingroup, ~0.54-0.59 to O1;
  K of A1 elements called P in A1>O1 median 0.090 (n 26): backbone aging 2*mu*T_root, as Task 3's C1 ruling expects.
- `sim/deficit_replay.py RUN --workers 10`: replays the run's per-chromosome streams with the snapshot code
  (ancestry + draw_events), checks trees/insertions/losses/SNPs against the run's params.json and sim.log, then
  sums lam x a x B_R (replacing sequence) and the solo-LTR term. On the toy (2 x 1.5 Mb, seed 101): replay matches
  exactly; 888 kept primaries, 326.3 expected missing in replacing sequence (36.7%), 7.7 in solo LTRs. Must run
  after the pilot (thread budget), <= 10 processes, ~minutes.

**Run by the post-pilot dispatch (2026-11-13 03:49-03:51).** Every value is reported and none is tuned (R4). Files:
`sim/pilot/realism.tsv` (long, from realism.py over the four runs, 7 s), `sim/pilot/realism_table.tsv` (wide, from the
new 67-line `sim/pilot/realism_table.py`: class means over directed pairs), and `sim/pilot/deficit.{tsv,log,time,exit}`.
Summarize's `sim/tables/realism.tsv` gives the per-kind view with eval.json's definitions. Analogs: A1 ~ B73, B1 ~ TIL01,
C1 ~ TIL18, O1 ~ Zd.

| quantity | 50 Mb null | 50 Mb f0.18 | 100 Mb null | 100 Mb f0.18 | main3 |
|---|---|---|---|---|---|
| genome length, A1 / B73 | 98.0 Mb | 96.4 Mb | 189.4 Mb | 192.7 Mb | 2,182 Mb (TIL18 2,494; Zd 3,291) |
| annotated elements per Mb, A1 / B73 | 59.3 | 59.7 | 59.6 | 60.2 | 58.5 (TIL18 50.0, TIL01 52.7) |
| alive per Mb, A1 | 66.0 | 66.3 | 66.1 | 66.8 | - |
| level-0 annotated per Mb, A1 / B73 | 32.5 | 33.0 | 32.5 | 33.1 | 41.9 |
| A1>C1 / B73>TIL18 P | 0.401 | 0.431 | 0.397 | 0.429 | 0.212 |
| E | 0.248 | 0.249 | 0.255 | 0.245 | 0.209 |
| D | 0.113 | 0.093 | 0.107 | 0.090 | 0.217 |
| O | 0.071 | 0.070 | 0.074 | 0.073 | 0.173 |
| T | 0.079 | 0.069 | 0.075 | 0.067 | 0.033 |
| S | 0.015 | 0.016 | 0.017 | 0.017 | 0.009 |
| G | 0.057 | 0.055 | 0.061 | 0.061 | 0.0002 |
| U | 0.014 | 0.017 | 0.014 | 0.018 | 0.146 |
| resolved_frac | 0.744 | 0.765 | 0.745 | 0.758 | 0.464 |
| resolved_frac, class mean A~B / A~C / B~C | 0.78 / 0.75 / 0.75 | 0.78 / 0.76 / 0.75 | 0.78 / 0.75 / 0.75 | 0.78 / 0.77 / 0.75 | 0.51 / 0.47 / 0.44 |
| resolved_frac, X>O | 0.58 | 0.60 | 0.58 | 0.60 | 0.26 |
| A1>O1 / B73>Zd E; U | 0.48; 0.07 | 0.50; 0.07 | 0.47; 0.07 | 0.48; 0.06 | 0.19; 0.22 |
| outgroup conflict frac_E, mean of 6 (range) | 0.024 (0.011-0.034) | 0.018 (0.009-0.023) | 0.020 (0.011-0.027) | 0.013 (0.007-0.015) | 0.030 (0.027-0.032) |
| conflict discovery set | 5 genomes: **not like-for-like** | 5: not like-for-like | 5: not like-for-like | 5: not like-for-like | 2 genomes |
| D_pav counted / Mb of the donor C1 / TIL18 | 20.3 (1,974) | 20.8 (2,003) | 20.0 (3,752) | 20.6 (3,953) | 5.64 (14,067) |
| D_pav informative / Mb of the donor | 3.25 (315) | 2.97 (286) | 3.18 (595) | 3.29 (632) | 0.82 (2,041) |
| D_pav informative / Mb of A1 / B73 | 3.22 | 2.97 | 3.14 | 3.28 | 0.94 (eval_run.py's constant: 0.97) |
| painting n_informative (/ Mb of recipient) | 671 (6.85) | 659 (6.83) | 1,325 (6.99) | 1,343 (6.97) | 7,515 (3.44) |
| painting spacing_median | 79.8 kb | 90.1 kb | 79.7 kb | 81.9 kb | 84.4 kb |
| K median of elements shared with the outgroup (called P vs O1 / Zd) | 0.095 (n 195) | 0.097 (n 192) | 0.096 (n 398) | 0.099 (n 415) | 0.060 (n 6,336) |
| K q25-q75 | 0.080-0.117 | 0.082-0.117 | 0.080-0.118 | 0.083-0.120 | 0.042-0.097 |
| K median, truth P in all six others (origin) | 0.107 (77, backbone) | 0.097 (98, backbone) | 0.102 (199, backbone) | 0.099 (209, backbone) | - |

**The named deficit (R4; Task 2 ruling I2), 50-Mb null_s101.** `deficit_replay.py runs/null_s101 --workers 10` ran
detached under `timeout 15m` (PID 2783119, SID = PID, PPID 1), with 5 processes (one per chromosome) and
OMP_NUM_THREADS=1. It took 2 min 16 s, max RSS 0.84 GB, exit 0.
- The replay matches the run: trees, insertions, losses and SNPs per chromosome agree with params.json and sim.log.
- Kept primaries: 15,041 (300.8 per Mb of backbone).
- Expected insertions missing in replacing sequence: 4,294.6 (28.6% of kept primaries; 85.9 per Mb).
- In solo LTRs of simulated insertions: 172.6.
- Against Task 2's 5-Mb figure: 460 of 1,458 (31.6%).

**Reading (reported, not tuned).**
- Element density matches B73: 59-60 annotated per Mb against 58.5. But fewer of the elements are top-level (32-33
  against 41.9 per Mb), so the simulations nest more.
- The genotype landscape is much easier than main3's:
  - resolved_frac is 0.74-0.78 against 0.44-0.52 in the ingroup, and 0.58-0.60 against 0.26 to the outgroup;
  - U is 1-2% against 15%;
  - P is twice main3's, and D and O are half;
  - G (an N in the target between the flank images) is 5.5-6.1% against 0.02%. Its cause was not checked.
- Hence D_pav has 3.6x main3's counted loci per Mb and 3.6-4.0x its informative loci per Mb. The painting has 2.0x
  main3's informative loci per Mb, at the same median spacing (80-90 kb against 84 kb).
- The outgroup lacks far more elements (E 0.47-0.50 against 0.19). The elements shared with it are older: K median
  0.095-0.099 against 0.060, all backbone copies aged by 2 mu T_root.
- Outgroup conflict sits at or below main3's (0.013-0.024 against 0.027-0.032), but on a discovery set of 5 genomes
  against 2: not like-for-like.
- The 50-Mb and 100-Mb runs agree on every per-Mb and fractional quantity, so the fallback changes counts, not rates.

## Step 11: budget gate
Not applied yet. `sim/gate.py RUN RUN` applies the plan's formula as written; its input reading was fixed and
recorded in sim/memo.md before any pilot time was known: h7 = a run's summed step walls (sim geno views ltrmix; eval
unmeasured), h_trio = h7 - genotype + 9/36 x genotype (genotype from geno.log's command stamps), the gate on the
mean of the two runs, each run's projection reported as a sensitivity. Checked by hand on the toy's logs.
- **Controller ruling (rule 3: measure, do not extrapolate).** Rules 1 and 2 are applied at 100 Mb with the
  pilot's h7 and h_trio. If both fail: both pilot runs move to `runs/<name>.100Mb`, the same two rows run again at
  50 Mb (`run_grid.sh pilot.tsv --until ltrmix --windows 5`, detached, same checks), and h7_50 and h_trio_50 from
  that run choose 30 or 10 nulls by the same rule. Realism is reported on the runs the chosen grid keeps (the
  100-Mb numbers too). (My extrapolation proposal of the hand-back is withdrawn.)
- Then `python sim/make_grid.py --bneck-nulls N`.

**Applied by the controller at 100 Mb and by the post-pilot dispatch at 50 Mb (2026-11-13 03:48).** The formula is
the plan's: projected h = (N7 x h7 + 26 x h_trio) / 2 + 3 x 1.4 + 22, with N7 = 88 + the bottleneck nulls and a limit
of 96 h.

| scale | file | h7 (null / f0.18 / mean) | h_trio (mean) | projection, 30 nulls | projection, 10 nulls | rule |
|---|---|---|---|---|---|---|
| 100 Mb | `pilot/gate_100Mb.tsv` | 1.358 / 1.277 / **1.318 h** | **0.587 h** | 111.6 h | 98.4 h | 1 and 2 fail -> 3 (50-Mb fallback) |
| 50 Mb | `pilot/gate_50Mb.tsv` | 0.708 / 0.638 / **0.673 h** | **0.320 h** | **70.1 h** | 63.3 h | rule 1 passes -> 30 nulls |

- At 50 Mb, each run alone also picks 30 (72.6 h and 67.6 h). At this h_trio/h7 ratio (0.476), 30 nulls pass while
  h7 <= 64.2 min, so the margin is 24 min per run.
- Hand check: (118 x 0.673 + 26 x 0.320) / 2 + 4.2 + 22 = 70.07 h. This equals the controller's preview (h7 0.673,
  h_trio 0.320, 70.1 h).
- **Decision: the 50-Mb fallback with 30 bottleneck nulls.** The projection is 70.1 h. At 50 Mb, 30 nulls cost 6.8 h
  more than 10 would (63.3 h); the brief's "about 12 h more" was the full-scale figure. Telling the user is the
  controller's (R5).
- `python make_grid.py --bneck-nulls 30` -> `sim/grid.tsv`, **144 rows**:
  - 118 on 7 genomes: null 30, power 36, reverse 8, ptlike 3, bneck 33, posctl 8;
  - 26 trios.

  The file is byte-identical to Part A's (sha256 `24e5fe2a...406b`).
- The pilot rows are grid rows 1 (`null_s101`) and 53 (`f0.18_Ta5000_r1`), text-identical to pilot.tsv. They are not
  the grid file's first two lines; they are the first two grid runs done. `run_one.sh NAME --grid grid.tsv --windows 5
  --dry-run` prints `marker exists: skip` for sim, geno, views and ltrmix on both. Since Task 9 Step 4 scored them,
  eval.done and run.done exist too, so `run_grid.sh grid.tsv --windows 5` skips every step of both.
- Not done here: the queue (PID 2732713) must stop before the grid launch (controller, Task 10).

## Concerns
1. **Handed back before the pilot finished** (harness demand, 01:49); resumed at 01:50 by the controller, Monitor
   re-armed on `pilot.tsv.exit`.
2. **h7 looks like ~1.4-1.6 h, above both gate limits** (pair 1 took ~2 min 10 s; 36 pairs in sequence). Server
   load is ~200-230 on 256 cores from other jobs, so the measured h7 includes contention.
3. **The 50-Mb fallback's 30-vs-10 choice needs an h7 at 50 Mb.** Ruled by the controller: measure it with a
   50-Mb rerun of the two pilot rows (Step 11).
4. **outgroup_conflict is not like-for-like.** `_conflicts` (snap analysis/relations.py:650-680) reads every
   annotated ingroup genome but g as a discoverer, and `--trio` does not narrow it, so in a 7-genome view the
   discovery set is 5 genomes, against main3's 2. Ruled: the main view's (`--trio A1,B1,C1`) value is reported
   beside main3's and labeled not like-for-like; realism.py prints each row's discovery-set size.
5. **Real-genome queue stopped** (20/36 pairs); it stays stopped until the controller relaunches it after the grid.
6. Grid and run locks plus samplers were added to run_grid.sh and run_one.sh (R9). view.sh is unchanged.

- Second forced hand-back at 2026-11-13 01:52 EST: pilot still genotyping (PID 1270604 alive); realism.py now labels each
  conflict row with its discovery-set size (`frac_E[disc=N genomes]`). Steps 9 (rest), 10, 11 still to do, per
  'Resume' and the controller's rule-3 ruling.

## Resume (for the next dispatch)
- Wait for `sim/pilot.tsv.exit` (`pilot.tsv.done` / `.failed`), e.g. a Monitor until-loop, or check
  `ps -p 1270604`.
- Step 9: run.log lines give each step's wall, GNU RSS, tree PSS and load. Count `runs/*/geno/pairs/*.calls.tsv.gz`
  (36 each). Then nodonor: `views/nodonor/stats.tsv` D_pav rows (disc=C2) and views.log.
- Step 10: `. common/env.sh && python sim/realism.py runs/null_s101 runs/f0.18_Ta5000_r1 --out pilot/realism.tsv`;
  `OMP_NUM_THREADS=1 python sim/deficit_replay.py runs/null_s101 --workers 10 > pilot/deficit.tsv`.
- Step 11: `python sim/gate.py runs/null_s101 runs/f0.18_Ta5000_r1`, then make_grid.py and, under the fallback, the
  moves. Fill sim/memo.md's Step 10/11 sections and this report's PENDING sections.

## Post-pilot dispatch (2026-11-13 03:47-04:15): Resume done
Every Resume item is done: Step 9's measurements, counts and nodonor; Step 10 with R4's additions; Step 11 at 50 Mb;
grid.tsv regenerated. The PENDING and "not run yet" sections above are filled, and sim/memo.md has the Step 9 outcome,
Step 11 and Step 10 sections. Nothing in plan3/real/, main3/, main3_analyses/, inputs/, run/, LTRmix/, benchmark/ or
`runs/*.100Mb` was written (the 100-Mb runs were only read by realism.py). RULES.md still hashes 4111826d...a293.
New file: `sim/pilot/realism_table.py` (reporting only; sha256 39050f21...).

Concerns from this dispatch:
1. **Realism gap (reported, not tuned).** The simulated genotype landscape is much easier than main3's:
   - resolved 0.74-0.78 against 0.44-0.52, and U 1-2% against 15%;
   - so 3.4-4.0x main3's D_pav informative loci per Mb, and 2x its painting loci per Mb.

   Power per Mb will be optimistic for the real data. The power table's `Z * sqrt(2041 / n)` projection rescales by
   locus count, which carries part of this, but not the per-locus difficulty.
2. **frac_G 5.5-6.1% in the sims against 0.02% in main3.** G is an assembly-gap call (an N in the target between the
   flank images). Its cause in the simulated genomes was not checked. In the pooled parity counts, half of all-tier G
   calls are truth-wrong (G tp 5,363, fp 5,924 in null_s101); G is never high tier.
3. **D_pav informative per Mb: denominators differ.**
   - realism.py: per Mb of the donor (TIL18 0.82; sims 2.97-3.29);
   - eval_run.py: per Mb of A1, against the brief's main3 constant 0.97;
   - per Mb of B73's 2,182-Mb assembly, main3 reads 0.94.

   The ratio is 3.2-4.0x whichever is used.
4. **The pilot rows are grid rows 1 and 53**, not "its first two runs" in file order. The grid skips both by marker
   anyway.
5. **Another run_one.sh was running during this dispatch**: a scratch toy grid `.../scratchpad/p3t8breview/` (xargs
   -P 2, `--until ltrmix --windows 5`, PID 3079345, 8 threads seen), probably a reviewer's. Not this dispatch's. With
   the queue's 32 threads it puts the machine above the 32-thread project budget. This dispatch's probes were 1 to 8
   processes at a time.
