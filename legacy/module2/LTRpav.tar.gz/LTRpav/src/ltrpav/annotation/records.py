"""Skipped annotation records: counts by reason, and a warning naming the file and line of each of the first
malformed records (warn and skip minor issues, with counts)."""
from __future__ import annotations

import logging
from collections import Counter
from pathlib import Path

from ltrpav.constants import RECORD_WARNINGS

log = logging.getLogger("ltrpav.annotation")


class RecordSkips:
    """A loader's skip counts by reason (`counts`). `malformed` skips a record that cannot be read, with a
    warning naming its file and line for the first RECORD_WARNINGS of them (later ones are only counted);
    `filtered` counts a record the loader leaves out by design (no LTR pair, LTRquest status not pass)."""

    def __init__(self) -> None:
        self.counts: Counter = Counter()
        self._warned = 0

    def malformed(self, path: Path | str, line: int, reason: str, why: str) -> None:
        self.counts[reason] += 1
        if self._warned < RECORD_WARNINGS:
            self._warned += 1
            more = "; further malformed records are only counted" if self._warned == RECORD_WARNINGS else ""
            log.warning("%s:%d: record skipped, %s: %s%s", path, line, reason, why, more)

    def filtered(self, reason: str) -> None:
        self.counts[reason] += 1
