# Task 24 phase A review (file-based; ledger ruling R8)

Reviewed 2026-11-11 05:50-06:20 against `task-24-brief.md`, `task-24-rulings.md` 1-12 and `task-24a-report.md`.
Repo HEAD bfeeb55, clean. D = `/data2/chris/maize_introgression/benchmark_pav/bakeoff`. Probes and their outputs
are in `D/review24a/` (`probe_outputs.txt` has every number quoted below). Both batches were left untouched
(PIDs 3523920 and 662846, still running, SID = PID, PPID 1).

- **Spec: ✅** Every phase-A requirement is met. Steps 1-4, the Step 6 setup and launch, and the Step 7 read-out
  classification are done or running, as rulings 1-12 specify. Rulings 6 and 9 override the brief, and both
  overrides are followed: `maf` is not a registered backend, and chr10 annotations use the TSV prefix. The 64-thread
  run is pending by design (it waits for the sims batch). Nothing is unmet. Small labeling and documentation gaps
  are listed as Minor (M5, M7, M8).
- **Quality: Changes needed.** This does not block the running batches. The scripts are correct, and every number
  produced so far can be trusted: the read-out, the backends and the patches were verified independently (see below).
  One Important hazard is latent. It changes no existing number, so **no run needs a rerun**. It should be fixed
  before any relaunch or phase-B rerun of a chr10 measurement. Apply the fix only after `chr10/batch.exit`
  exists: the running chr10 batch re-executes `bakeoff.py` for every remaining run, so editing it now would change the
  harness partway through the batch.

## Findings

### Critical
None.

### Important

**I1. A relaunched chr10 measurement resumes a partial run and records it as the variant's full cost.**
`04_chr10.sh:44-50, 65-69, 83-84`; `bakeoff.py:164, 245-247`.
- Evidence: `measure --skip-done` skips a run only when `status.json` exists. `run_measured` deletes only
  `status.json` (bakeoff.py:164), and only mm2_lastz and mm2_wfa get `rm -rf` (04_chr10.sh:58). After an
  interruption (reboot, a killed driver), relaunching `04_chr10.sh` starts `ltrpav run` in the old outdir. Its
  checkpoints then skip the finished work: elements, the mm2 index ("reusing index"), raw and netted anchors, finished
  chunks and finished pairs. So `time.txt` holds the wall time and RSS of only the remaining work, and nothing in
  `status.json` shows this. The decision metric (the cost bar) would be silently understated. Deleting `status.json`
  of a failed route to rerun it has the same effect. `02_run_sims.py:51-52` handles this correctly: it runs `rmtree`
  on a directory without `status.json`, and its docstring states the principle, "every timing is of a whole run".
- Fix: in `run_measured` (or in `measure` before the call), if `--rundir` exists without `status.json`, remove it (it
  is the run's own ltrpav outdir) or refuse with an error. Make the same change in the shell wrapper if preferred:
  `[[ -f $dir/status.json ]] || rm -rf "$dir"`.
- Runs affected: none. The chr10 batch has had one uninterrupted launch, and every chr10 rundir (awpaf, mm2,
  mm2_lastz, mm2_wfa, fastga, ...) was created by it. Rerun: none.

### Minor

**M1. Exit 137 is classified as "timeout" even when the run died early from SIGKILL.** `bakeoff.py:193`.
- Evidence: an OOM kill of the main process makes `timeout` re-raise the signal, and `/usr/bin/time` then exits
  128+9. In a probe, a job with a 30-min limit that was SIGKILLed after 3 s got status `timeout`, exit 137, wall
  3.02 s.
- The timeout kill itself is sound. In a probe with 3 forked workers and a `sleep` subprocess and a 6-s limit, the
  run got exit 124 and no process survived: GNU timeout signals its own process group, the workers reset SIGTERM to
  the default action, and PDEATHSIG backs this up.
- Fix: classify as `timeout` only on exit 124, or on exit 137 when wall time is at least the limit. Classify anything
  else as `killed` or `failed`.
- Runs affected: none (every run so far exited 0).

**M2. The batch drivers are not safe to relaunch.** `02_run_sims.py:78-81`, `04_chr10.sh:25, 81`.
- `02_run_sims.py` never removes an old `runs/batch.done` or `runs/batch.exit` at startup. `04_chr10.sh` removes
  `batch.done` but not `batch.exit`.
- If phase B reuses `02_run_sims.py` (ruling 1's follow-up lastz/wfa runs), the phase-A markers will report "done"
  while the new batch runs. A stale `runs/batch.exit` would also end `04_chr10.sh`'s wait for the 64-thread run
  (line 81) at once, giving 96 threads.
- A measured run also outlives a kill of its driver, because `timeout` runs in its own process group. A relaunch
  could then `rmtree` (02:52) a directory that the orphaned run is still writing to.
- No stale marker existed at 05:57.
- Fix: delete both markers when a driver starts. Before any relaunch, check that `pgrep -af run_variant.py` returns
  nothing.
- Runs affected: none.

**M3. The `--sims` option is not validated.** `02_run_sims.py:37`.
- An absolute or `..` sim name would move `rundir` and its `rmtree` (line 52) outside `runs/`. With the default
  options every deletion stays inside `runs/<sim>/<variant>`, and in `04_chr10.sh` inside `chr10/runs/mm2_{lastz,wfa}`.
- Fix: add `choices=SIMS`, or check `rundir.resolve().is_relative_to(runs.resolve())`.
- Runs affected: none.

**M4. The sims batch runs an older `bakeoff.py` than the chr10 batch.**
- Evidence: `02_run_sims.py` imported `bakeoff.py` at 05:25:03 (`__pycache__/bakeoff.cpython-312.pyc`, whose header
  shows a source mtime of 05:24:49). `bakeoff.py` was then edited at 05:33:55. A bytecode diff
  (`review24a/pyc_diff.py`) shows that the edit only added `progress()` and the `progress` key. Sampling, CHUNK_WINDOWS,
  VARIANTS, parse_time, the status rule and the table code are identical in both versions.
- So the sims `status.json` files have no `progress` field, although the report and the module docstring say they do.
  This is harmless: under rule 8 a sims timeout is simply a failure.
- Fix: state it in the memo and report.
- Runs affected: none.

**M5. PARAMS.md has three inaccuracies, none of which changes a run.**
- (a) §10 says the process tree is sampled every 5 s. The code samples every 2 s (`SAMPLE_S`, bakeoff.py:34); the
  chr10 mem.tsv files show mean intervals of 2.1-2.9 s.
- (b) §4 gives the `--ydrop` default as "606 here". `lastz --match=1,4 --gap=6,2 --show=defaults` reports Y=40. This is
  moot, because the backend sets 166.
- (c) §9.5 says the chunk-size bias is "slightly" better balanced, and the report calls it a "small optimistic bias".
  This understates it. With the default 2,000 windows per chunk, a maize genome has about 40 chunks for 32 workers
  (chr10 has 5,039-5,823 windows per direction, times 14-15). That takes 2 rounds where about 1.2-1.4 would be
  balanced, so the default's genotype stage can take about 1.5-1.7x the balanced time that the bake-off measures
  (1.3x even at the report's figure of about 50 chunks). In minutes this is small for mappy and lastz, and large for
  wfa.
- Fix for (c): phase B should model ceil(chunks/32) rounds when extrapolating, or should apply this rule to
  CHUNK_WINDOWS.
- Verified separately: the calls are byte-identical at 8 and at 2,000 windows per chunk, and at 2 and at 32 threads
  (R1_s1 mm2; `review24a/chunk8` and `review24a/chunk2000`), so PARAMS 9.5's premise holds.

**M6. Tree-memory sampling under-samples short phases.**
- Sustained peaks are caught, but:
  - runs shorter than about 2 s get no sample, so peak_tree_* = 0;
  - the 4-10-s genotype phases of 5 of the 6 chr10 mm2 directions got only 1-4 samples;
  - the chr10 mm2 PSS peak (19.0 GB) comes from the 60-s TIL18->B73v5 phase.
- The PSS sum itself is right. It sums the `Pss:` line of `smaps_rollup` over the whole tree from `/usr/bin/time`
  down. Pages shared with processes outside the tree are slightly undercounted.
- Fix: for the 250-GB bar, use max(max_rss_kb, peak_tree_pss_kb) from the chr10 runs, and give the sims' tree peaks
  no weight. Optionally, sample at 0.5 s during each run's first minute.
- Runs affected: none.

**M7. One run is missing from the report's disclosure.**
- `runs/R1_s1/flank-mm2_2k` was measured by hand at 05:24:30. Its `cmd` uses relative paths, and it ran outside the
  batch, 12 s after PARAMS.md's last edit. The batch then skipped it (`[3/78] skip ... status.json exists`).
  Report concern 8 names only the mm2 smoke run.
- Its variant.json shows the same patches as the batch (mappy, cap 2000, chunk 8). Its calls should equal a batch
  run's, and its timing comes from the same harness, apart from any `bakeoff.py` edits made between 05:24:30 and
  05:24:49.
- Fix: note it in the memo, or rerun it inside a batch (4 s) after the sims batch ends.
- Runs affected: the timing provenance of R1_s1/flank-mm2_2k only.

**M8. The AnchorWave-anchors yardstick is not labeled in the runs table.**
- Its row in `chr10/runs.tsv` has variant "." and route `paf:...` (04_chr10.sh:44 passes no `--variant`). Nothing in
  the table marks it as a yardstick, although PARAMS §8 and ruling 12 require it.
- Fix: give it a name, for example `awpaf_yardstick` (or a role column), so that phase B's winner rule cannot pick
  it up.

**M9. The read-out has two robustness gaps, with no effect on the current outputs.**
- The PAF/segments cache key (`06_anchorwave_readout.py:375-387`, `paf.done`) covers only the MAF's path, size and
  mtime. A later fix to `maf_to_paf` would therefore be skipped silently.
- `Segments.hits` ignores seqids. That is correct for chr10 alone; add an assert that `w.b_seqid` is the MAF's B
  seqid.

## Verification by focus item

1. **`06_anchorwave_readout.py`**: correct.
   - MAF minus-strand coordinates:
     - The `-` start conversion is srcSize - start - size, for both the PAF target interval and the segment's y,
       which is the forward end.
     - Checked against the FASTAs, independently of the script. Gap-free segments have median identity 0.973 on +
       and 0.962 on -, over 400 segments each. Shifting B by 1 bp gives 0.27-0.28, so the coordinates are exact on
       both strands. The script's own first and last 1,000 bases of every block also pass.
   - PAF:
     - Walked all 5 `cg:Z` records in target order (on `-`, the query is reverse-complemented). The CIGAR spans
       equal the coordinates, every sampled `=` run matches (14,666/14,666) and every sampled `X` run differs
       (110,902/110,902). `I` is B73-only and `D` is TIL18-only, as `read_paf`/`split_cigar` expect.
     - The paf: run log has no "kept whole" CIGAR warning (15,998 raw blocks).
   - Mirror of `_Genotyper.rows`:
     - Both directions' read-out window files are byte-identical to the engine's paf: run windows, so `read_paf`,
       chain/net and `make_windows` behave identically.
     - The element files are identical to the mm2 and awpaf runs.
     - The fetch, the reverse complement for strand -1, `classify_window` and `call_row` are the same calls, and the
       private helpers are the engine's own.
   - Per-window AlnMaps (from `Segments.hits` plus `alnmap_from_hits`, on sequences fetched and reverse-complemented
     as the engine does):
     - Median identity is 0.961 / 0.956 on all 178 / 150 strand -1 windows, and 0.978 / 0.980 on 600 strand +1
       windows.
     - For elements called P by both the read-out and the paf: run, the B coordinates agree: median |diff| 0, and
       93.5-98.1% within 5 bp, on both strands.
   - Streaming: `maf_blocks` yields one block pair at a time. The per-block arrays take about 10-15 bytes per column,
     roughly 2-3 GB for the first, 188-M-column block.
2. **`backends.py`**: correct.
   - LASTZ:
     - On a synthetic window (1% SNPs, a 3-kb A insertion, a 2-kb inversion), lastz and mappy give identical
       segments: 488 truth positions exact, 0 wrong, 178/17,998 mismatches. Both give the inverted hit
       (15000, 17000, 12000, 14000), which is the truth.
     - On a repeat window both report the same 4 inverted hits (ends within 5 bp). In both, q = A (query) and
       r = B (target); minus-strand hits carry forward coordinates.
   - WFA:
     - It matches the truth at all 489 sampled positions and reports no inverted hits (declared).
     - WFA2 v2.3 source: `I` advances the text (A) and `D` the pattern (B). pywfa's call is `__call__(text, pattern)`.
       Gap cost is o + e*l.
     - The match-0 conversion x' = 2(A+B), o' = 2O, e' = 2E+A follows from 2M + 2X + I + D = |A| + |B|.
       `PRESET_SCORING` reproduces minimap2 2.31's AS:i exactly for asm5, asm10 and asm20.
     - Guards: the length-difference skip takes 0.07 s, and two unrelated 40-kb sequences end with status -100 in
       14.7 s. BiWFA enforces the cap on the forward plus reverse score (`wavefront_bialign.c:1077`). The aligner is
       reusable afterwards.
3. **`run_variant.py`**: correct.
   - All 5 patches are module globals that the engine reads at call time: `cli.BACKEND` (`_run`/`_genotype`),
     `cli.get_route` (`_route`), `mm2.MAPPY_BEST_N` (`_load`, `params`), `genotype.CHUNK_WINDOWS` and
     `flanks.flank_pieces` (each called by its module-global name).
   - The workers are forked, so they inherit the patches.
   - Evidence:
     - The `bakeoff-flanks` maximum reach equals the cap (2/5/10/20 kb).
     - Windows are md5-identical across mm2, mm2_lastz and mm2_wfa, and across fastga and its lastz/wfa variants.
     - States differ on 46 (lastz) and 172 (wfa) elements over both directions; the report's 23 and 88 are for one
       direction.
     - mm2_N50 has 616 raw blocks against mm2's 568.
     - The window aligner imports `localign.MAPPY_BEST_N` (5) separately, so mm2_N50 changes anchoring only.
4. **`bakeoff.py`**:
   - Wall time and max RSS come from GNU time. Max RSS is the largest single waited-for process.
   - The PSS sum and the timeout kill are correct (M1, M6).
   - The runs table is correct.
5. **`02_run_sims.py`, `04_chr10.sh`**:
   - Thread budget:
     - Each batch runs one 32-thread run at a time.
     - The 64-thread run waits for `runs/batch.exit` or for the sims driver to end.
     - No other bake-off job is active (AnchorWave finished, with `done.flag`).
   - Timeouts: 30m (sims), 2h (routes, awpaf, t64) and 45m (genotype runs) match rules 8 and 10.
   - Markers: `batch.exit` is always written, and `batch.done` is written last.
   - Failures and timeouts are recorded in `status.json` and never retried. chr10 timeouts carry
     `progress` (windows, and chunks done out of total).
   - Deletions stay inside each run's own outdir.
   - See I1, M2 and M3.
6. **`chr10_inputs.py`**: correct.
   - It filters with the loader's own `_SEQ_ID` regex.
   - The chr10 loads equal the chr10 subsets of the whole-genome loads in every field: 9,064, 8,319 and 9,304
     elements.
   - The chr10 sequences equal AnchorWave's FASTAs (sha256).
7. **`PARAMS.md`**:
   - Each choice is reasoned from the use case. No scoring script exists yet, so no choice can depend on sim scores.
   - The variants, including mm2_N50, are declared.
   - The wrapper patches are listed completely: backend, cap through `get_route`, the `flank_pieces` logging wrapper,
     mm2 best_n and CHUNK_WINDOWS, plus the environment variables in §10.
   - Factual claims checked against the installed tools:
     - asm presets set -N 50: the minimap2 2.31 binary prints 51 PAF lines by default, 6 with `-N 5` and 79-80 with
       `-N 200`, for asm5, asm10 and asm20.
     - Preset scoring: confirmed (exact AS:i).
     - mappy rejects `pri_ratio`, `mid_occ`, `zdrop` and `max_gap`.
     - FastGA defaults (-f 10, -c 85, -s 1000, -l 100, -i .7) match its usage text.
     - `-pafx` writes =/X CIGARs (R1_s1 PAF).
     - The LASTZ K, L and X defaults under `--match=1,4` are as stated.
     - The AnchorWave genoAli defaults are as stated.
   - See M5.

## Notes for phase B (observations, not findings)
- **AnchorWave aligns some windows at low identity.** The sampled per-window identity has a 5th percentile of
  0.87-0.89 and a minimum of 0.51, and 13-18% of sampled gap-free segments are below 0.9. A global aligner can read
  unrelated sequence as aligned (the wfa effect of O read as T), so look closely at read-out T and P calls with low
  `ident`.
- **The paf: run's extra U calls.** On the identical windows, mappy windows call 2,174 U against the read-out's
  449. Most are `flank_unaligned` (1,529) or `inv_site` (254), and the read-out has no `inv_site` calls at all.
- **Thread scaling.**
  - mm2_t64 runs B73v5/TIL18 alone. Its 32-thread comparator is the B73v5/TIL18 part of the 3-genome mm2 run, which
    was measured while the sims batch ran.
  - Compare the per-stage log times (index 5.6 s, mapping 71.6 s, genotyping 4 s + 60 s), not total wall time.
  - Machine load is a confound.
- **RSS extrapolation.** During mapping, the chr10 mm2 main process holds 9-12.5 GB, while the `.mmi` index is
  0.39 GB; the rest is per-thread mapping buffers. Scaling the 19-GB PSS by the genome length ratio (to about 270 GB)
  would overstate whole-genome RSS (rule 11).
