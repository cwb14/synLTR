"""Window alignment map (ltrpav.localign) and the toy genotype cases (tests/toy.py)."""
import math
import random
from collections import namedtuple

import numpy as np
import pytest

import ltrpav.localign as la
import toy
from conftest import needs_lastz
from ltrpav.constants import MAPPY_BEST_N, MIN_SEG, WINDOW_PAD
from ltrpav.elements import make_eid
from ltrpav.localign import (
    AlnMap,
    Gap,
    align_window,
    alnmap_from_hits,
    preset_for_divergence,
)
from ltrpav.seqio import revcomp

Hit = namedtuple("Hit", "q_st q_en r_st r_en strand mlen cigar")  # the mappy.Alignment fields used
BACKENDS = ["mappy", pytest.param("lastz", marks=needs_lastz)]  # the built-in window aligners


def amap(*segs, inv=()):
    """AlnMap from (a, b, len[, mm]) tuples."""
    rows = [s if len(s) == 4 else (*s, 0) for s in segs]
    cols = list(zip(*rows)) if rows else [(), (), (), ()]
    return AlnMap(*(np.array(c, dtype=np.int64) for c in cols), inv=list(inv))


def _hamming(x, y):
    return sum(p != q for p, q in zip(x, y))


# ---------------------------------------------------------------- simple pairs on each backend; the divergence preset


@pytest.mark.parametrize("backend", BACKENDS)
def test_identical_one_segment(backend):
    s = toy.rand_seq(20_000, random.Random(1))
    m = align_window(s, s, backend=backend)
    assert m.aligned_bp(0, 20_000) >= 19_950
    assert len(m.seg_a) == 1 and m.identity(0, 20_000) == 1.0 and m.inv == []


@pytest.mark.parametrize("backend", BACKENDS)
def test_insertion_makes_gap(backend):
    rng = random.Random(2)
    b = toy.rand_seq(20_000, rng)
    el, _, _ = toy.make_element(rng, 500, 5000)
    a = b[:10_000] + el + b[10_000:]
    g = align_window(a, b, backend=backend).gap_around(13_000)
    assert abs(g.a0 - 10_000) <= 50 and abs(g.a1 - 16_000) <= 50
    assert abs(g.b0 - 10_000) <= 50 and abs(g.b1 - 10_000) <= 50


@pytest.mark.parametrize("backend", BACKENDS)
def test_divergence_identity(backend):
    rng = random.Random(3)
    a = toy.rand_seq(20_000, rng)
    b = toy.mutate(a, 0.02, rng)
    assert abs(align_window(a, b, backend=backend).identity(0, len(a)) - 0.98) <= 0.005


@pytest.mark.parametrize("backend", BACKENDS)
def test_inversion_recorded(backend):
    rng = random.Random(4)
    a = toy.rand_seq(23_000, rng)
    b = a[:10_000] + revcomp(a[10_000:13_000]) + a[13_000:]
    m = align_window(a, b, backend=backend)
    assert any(a0 <= 10_050 and a1 >= 12_950 and b0 <= 10_050 and b1 >= 12_950 for a0, a1, b0, b1 in m.inv)
    assert m.aligned_bp(10_050, 12_950) == 0  # the inverted piece is not in the collinear segments
    assert m.aligned_bp(0, 10_000) >= 9_950 and m.aligned_bp(13_000, 23_000) >= 9_950


def test_preset_for_divergence():
    assert [preset_for_divergence(d) for d in (0.0005, 0.005, 0.02)] == ["asm5", "asm10", "asm20"]
    assert preset_for_divergence(0.001) == "asm5" and preset_for_divergence(0.01) == "asm10"
    assert preset_for_divergence(math.nan) == "asm20"  # unknown divergence: most tolerant preset
    with pytest.raises(ValueError):
        preset_for_divergence(-0.01)


# ---------------------------------------------------------------- AlnMap queries (hand-built maps)


def test_gap_around_runs():
    # run 1 = two segments split by a 1-bp A insertion (a flank indel); 3-kb A insertion; run 2
    m = amap((0, 0, 1000), (1001, 1000, 999), (5000, 1999, 1000))
    assert m.gap_around(3000) == Gap(2000, 5000, 1999, 1999)
    assert m.gap_around(2000) == Gap(2000, 5000, 1999, 1999)  # run 1 ends at 2000 (half-open)
    # inside a run: zero-length gap at a
    assert m.gap_around(500) == Gap(500, 500, 500, 500)
    assert m.gap_around(1000) == Gap(1000, 1000, 1000, 1000)  # on the 1-bp indel: B insertion point
    assert m.gap_around(5000) == Gap(5000, 5000, 1999, 1999)
    assert m.gap_around(5500) == Gap(5500, 5500, 2499, 2499)
    # no run on one side
    assert m.gap_around(6000) is None and m.gap_around(-5) is None
    assert amap().gap_around(10) is None


def test_gap_around_run_joining():
    flank, far = (0, 0, 1000), (3000, 1119, 1000)
    # B gap < MIN_SEG: the 40-bp segment joins the flank run, which then ends at its end
    m = amap(flank, (1000, 1000 + MIN_SEG - 1, 40), far)
    assert m.gap_around(2000) == Gap(1040, 3000, 1119, 1119)
    # B gap == MIN_SEG: the 40-bp segment is its own run, too short to be a flank
    m = amap(flank, (1000, 1000 + MIN_SEG, 40), (3000, 1200, 1000))
    assert m.gap_around(2000) == Gap(1000, 3000, 1000, 1200)
    assert m.gap_around(1010) == Gap(1000, 3000, 1000, 1200)  # inside the short run: not a flank
    # A gap < MIN_SEG joins as well
    m = amap(flank, (1000 + MIN_SEG - 1, 1000, 40), far)
    assert m.gap_around(2000) == Gap(1119, 3000, 1040, 1119)
    # short segments that join into a run of >= MIN_SEG aligned bases make a flank
    m = amap((0, 0, 50), (51, 50, 50), (3000, 100, 1000))
    assert m.gap_around(1000) == Gap(101, 3000, 100, 100)
    # a side holding only a short run has no flank
    m = amap((0, 0, MIN_SEG - 1), (3000, 100, 1000))
    assert m.gap_around(1000) is None


def test_b_gaps_within():
    m = amap((0, 0, 1000), (1000, 1100, 1000), (2005, 2100, 500), (2600, 2700, 400))
    assert m.b_gaps_within(500, 3000) == [Gap(1000, 1000, 1000, 1100), Gap(2505, 2600, 2600, 2700)]
    assert m.b_gaps_within(1000, 1001) == [Gap(1000, 1000, 1000, 1100)]
    assert m.b_gaps_within(0, 1000) == []  # the gap starts at the interval end
    assert m.b_gaps_within(1500, 2500) == []  # only an A insertion (B gap 0) starts inside
    assert amap().b_gaps_within(0, 100) == []


def test_aligned_bp():
    m = amap((0, 0, 1000), (1001, 1000, 999), (5000, 1999, 1000))
    assert m.aligned_bp(0, 6000) == 2999
    assert m.aligned_bp(500, 1500) == 999  # A base 1000 is unaligned
    assert m.aligned_bp(2000, 5000) == 0 and m.aligned_bp(10, 10) == 0 and m.aligned_bp(20, 10) == 0
    assert m.aligned_bp(5999, 7000) == 1 and m.aligned_bp(-100, 1) == 1


def test_identity_prorated():
    m = amap((0, 0, 1000, 10), (1000, 1100, 1000, 0))
    assert m.identity(0, 1000) == pytest.approx(0.99)
    assert m.identity(500, 1500) == pytest.approx(0.995)  # 5 prorated mismatches over 1000 bp
    assert m.identity(0, 5000) == pytest.approx(0.995)
    assert math.isnan(m.identity(3000, 4000)) and math.isnan(amap().identity(0, 10))


def test_alnmap_rejects_bad_segments():
    for segs in ([(0, 0, 1000), (900, 1000, 100)],  # overlap on A
                 [(0, 0, 1000), (1000, 900, 100)],  # overlap on B
                 [(0, 0, 0)],  # empty segment
                 [(0, 0, 10, 11)]):  # more mismatches than bases
        with pytest.raises(ValueError):
            amap(*segs)


# ---------------------------------------------------------------- hits -> map: chain DP and clipping


def test_chain_picks_best_collinear_hits_and_clips():
    rng = random.Random(9)
    a, b = toy.rand_seq(3000, rng), toy.rand_seq(3000, rng)
    h1 = Hit(0, 1000, 0, 1000, 1, 1000, [(1000, 0)])
    hits = [
        Hit(2100, 2600, 900, 1400, 1, 500, [(500, 0)]),  # after h1 only: B goes back after h2
        Hit(500, 1500, 2500, 3000, 1, 400, [(100, 0), (500, 1), (400, 0)]),  # after h1 only; weaker
        Hit(970, 2000, 990, 2040, 1, 1030, [(30, 0), (20, 2), (1000, 0)]),  # 1st M inside h1 on both axes
        Hit(2200, 2400, 100, 300, -1, 200, [(200, 0)]),
        Hit(2200, 2400, 100, 300, -1, 200, [(200, 0)]),  # mappy can repeat an inverted hit as secondary
        h1,
    ]
    m = alnmap_from_hits(hits, a, b)
    assert list(zip(m.seg_a.tolist(), m.seg_b.tolist(), m.seg_len.tolist())) == [(0, 0, 1000), (1000, 1040, 1000)]
    assert m.seg_mm.tolist() == [_hamming(a[:1000], b[:1000]), _hamming(a[1000:2000], b[1040:2040])]
    assert m.inv == [(2200, 2400, 100, 300)]
    # partial overlap: the second hit is clipped on the diagonal, not dropped
    m = alnmap_from_hits([h1, Hit(950, 2000, 1050, 2100, 1, 1000, [(1050, 0)])], a, b)
    assert list(zip(m.seg_a.tolist(), m.seg_b.tolist(), m.seg_len.tolist())) == [(0, 0, 1000), (1000, 1100, 1000)]
    # hits that do not advance on every axis cannot chain: the higher-mlen one wins
    m = alnmap_from_hits([h1, Hit(0, 1500, 1200, 2700, 1, 1400, [(1500, 0)])], a, b)
    assert list(zip(m.seg_a.tolist(), m.seg_b.tolist(), m.seg_len.tolist())) == [(0, 1200, 1500)]


def test_hits_cigar_ops():
    s = "ACGTACGTAC" * 3
    t = s[:10] + "T" + s[11:]  # one substitution at 10
    m = alnmap_from_hits([Hit(0, 30, 0, 30, 1, 29, [(10, 7), (1, 8), (19, 7)])], s, t)
    assert m.seg_len.tolist() == [30] and m.seg_mm.tolist() == [1]  # =/X runs merge into one segment
    m = alnmap_from_hits([Hit(0, 30, 0, 29, 1, 29, [(10, 0), (1, 1), (19, 0)])], s, s[:10] + s[11:])
    assert list(zip(m.seg_a.tolist(), m.seg_b.tolist(), m.seg_len.tolist())) == [(0, 0, 10), (11, 10, 19)]
    with pytest.raises(ValueError, match="unsupported CIGAR op 4 in the hit at A 0-10"):  # S: soft clip
        alnmap_from_hits([Hit(0, 10, 0, 10, 1, 10, [(10, 4)])], s, s)
    with pytest.raises(ValueError, match="ends at A 10, B 10"):  # the CIGAR spans less than the hit
        alnmap_from_hits([Hit(0, 12, 0, 12, 1, 10, [(10, 7)])], s, s)
    m = alnmap_from_hits([Hit(0, 20, 0, 25, 1, 20, [(10, 7), (5, 3), (10, 7)])], s, s[:10] + "AAAAA" + s[10:])
    assert list(zip(m.seg_a.tolist(), m.seg_b.tolist())) == [(0, 0), (10, 15)]  # N: B only, like D
    assert len(alnmap_from_hits([], s, s).seg_a) == 0


def test_n_counts_as_mismatch():
    s = "ACGTACGTAC" * 3
    t = s[:5] + "NN" + s[7:]
    m = alnmap_from_hits([Hit(0, 30, 0, 30, 1, 28, [(30, 0)])], s.lower(), t)
    assert m.seg_mm.tolist() == [2]


# ---------------------------------------------------------------- align_window with mappy


def test_flank_indel_is_not_a_gap():
    rng = random.Random(6)
    x = toy.rand_seq(12_000, rng)
    el, _, _ = toy.make_element(rng, 400, 4000)
    a = x[:6000] + el + x[6000:]
    b = x[:3000] + x[3001:]  # 1-bp deletion in the left flank of B
    m = align_window(a, b, backend="mappy")
    assert len(m.seg_a) >= 3  # the indel splits the left flank into two raw segments
    g = m.gap_around(6000 + 2400)
    assert abs(g.a0 - 6000) <= 50 and abs(g.a1 - 10_800) <= 50 and abs(g.b0 - 5999) <= 50
    assert g == m.gap_around(6000 + 100)
    z = m.gap_around(3000)  # at the indel itself: inside the flank run
    assert z.a0 == z.a1 == 3000 and z.b0 == z.b1 and abs(z.b0 - 3000) <= 2


def test_no_hits_gives_empty_map():
    rng = random.Random(5)
    m = align_window(toy.rand_seq(5000, rng), toy.rand_seq(5000, rng), backend="mappy")
    assert len(m.seg_a) == 0 and m.inv == [] and m.aligned_bp(0, 5000) == 0
    assert m.gap_around(2500) is None and math.isnan(m.identity(0, 5000))
    for a, b in (("", "ACGT"), ("ACGT", "")):
        assert len(align_window(a, b, backend="mappy").seg_a) == 0


def test_unknown_backend():
    with pytest.raises(ValueError, match="backend"):
        align_window("ACGT", "ACGT", backend="nope")


@pytest.mark.parametrize("backend", ["mappy", "lastz"])  # checked before any alignment: no binary needed
def test_unknown_preset(backend):
    with pytest.raises(ValueError, match="preset"):
        align_window("ACGT", "ACGT", preset="asm2", backend=backend)


@pytest.mark.parametrize("name", toy.CASES)
def test_toy_flanks_align(name):
    c = toy.case(name, random.Random(11))
    m = align_window(c.a, c.b, backend="mappy")
    assert m.aligned_bp(0, 2400) >= 2300  # the left flank always anchors
    if name != "U_flank":
        assert m.aligned_bp(len(c.a) - 2400, len(c.a)) >= 2300


@pytest.mark.parametrize("preset", ["asm5", "asm10", "asm20"])
@pytest.mark.parametrize("name", ["T", "O", "inv_site"])
def test_window_sized_flanks_align(name, preset):
    """The toy case cut to WINDOW_PAD bp of flank on each side, as make_windows cuts a window: both flanks
    align around the element-sized indel (minimap2's long join would bridge them and lose the far one at the
    Z-drop), and the inverted site keeps its inverted hit and its flanks (short flank chains are not
    dropped as secondaries under the long inverted hit)."""
    cut = toy.FLANK - WINDOW_PAD
    for seed in (7, 0, 4, 6, 9, 11, 14):
        c = toy.case(name, random.Random(seed))
        a, b = c.a[cut:len(c.a) - cut], c.b[cut:len(c.b) - cut]
        assert a[:WINDOW_PAD] == b[:WINDOW_PAD] and a[-WINDOW_PAD:] == b[-WINDOW_PAD:]  # L and R kept in both
        [e] = c.elements
        s, t = e.start - 1 - cut, e.end - cut
        m = align_window(a, b, preset, backend="mappy")
        sides = (m.aligned_bp(0, s), m.aligned_bp(t, len(a)))
        assert min(sides) >= MIN_SEG, (seed, sides)
        if name == "inv_site":
            assert any(a1 - a0 >= MIN_SEG and a0 < t and a1 > s for a0, a1, _, _ in m.inv), (seed, m.inv)


@pytest.mark.parametrize("preset", ["asm5", "asm20"])
def test_dense_window_hits_bounded(preset, monkeypatch):
    """A window packed with 20 copies of one LTR family (2% apart) between unique spacers, B lacking three
    copies: minimap2's -N (MAPPY_BEST_N) applies per strand, so each yields at most one primary per A
    segment plus MAPPY_BEST_N secondaries (reporting all chains would grow the hits with the square of the
    copies), and the shared sequence still aligns collinearly."""
    seen = []
    real = la.alnmap_from_hits

    def spy(hits, a_seq, b_seq):
        hits = list(hits)
        seen.append(len(hits))
        return real(hits, a_seq, b_seq)

    monkeypatch.setattr(la, "alnmap_from_hits", spy)
    n, rng = 20, random.Random(20)
    fam, _, _ = toy.make_element(rng, 500, 5000)
    parts = []
    for _ in range(n):
        parts += [toy.rand_seq(rng.randint(3000, 8000), rng), toy.mutate(fam, 0.02, rng)]
    parts.append(toy.rand_seq(4000, rng))
    gone = {5, 15, 25}  # copies 2, 7 and 12
    a = "".join(parts)
    b = toy.mutate("".join(p for i, p in enumerate(parts) if i not in gone), 0.005, rng)
    m = align_window(a, b, preset, backend="mappy")
    assert len(seen) == 1 and seen[0] <= 2 * (2 * n + 1 + MAPPY_BEST_N), seen  # 2 strands x (41 + 5)
    assert m.aligned_bp(0, len(a)) >= 0.99 * (len(a) - sum(len(parts[i]) for i in gone))


# ---------------------------------------------------------------- toy builders

ELEM_LEN = {"e": 4800, "e1": 4800, "e2": 4800, "h": 7810, "c": 3000}
LTR_LEN = {"e": 400, "e1": 400, "e2": 400, "h": 400, "c": 300}
HOST = ("nested_E", "host_E", "host_S", "host_G")
STATES = {
    "P": {"e": "P"}, "P_nestB": {"e": "P"}, "S": {"e": "S"}, "S_notsd": {"e": "S"}, "T": {"e": "T"},
    "E": {"e": "E"}, "E_mm1": {"e": "E"}, "E_mm2": {"e": "E"}, "D_left": {"e": "D"}, "D_both": {"e": "D"},
    "O": {"e": "O"}, "G": {"e": "G"}, "G_near": {"e": "G"}, "G_far": {"e": "E"}, "U_flank": {"e": "U"},
    "inv_site": {"e": "U"}, "nested_E": {"h": "P", "c": "E"}, "host_E": {"h": "E", "c": "E"},
    "host_S": {"h": "S", "c": "D"}, "host_G": {"h": "G", "c": "G"}, "adjacent_E": {"e1": "E", "e2": "E"},
}
FLAGS = {("P_nestB", "e"): {"nestB"}, ("S", "e"): {"solo_tsd"}, ("E", "e"): {"tsd_match"},
         ("E_mm1", "e"): {"tsd_match"}, ("host_E", "c"): {"host_empty"}, ("host_G", "c"): {"inherit"},
         ("adjacent_E", "e1"): {"adjacent"}, ("adjacent_E", "e2"): {"adjacent"}}
NOFLAGS = {("S_notsd", "e"): {"solo_tsd"}, ("E_mm2", "e"): {"tsd_match"}}
TIERS = {("E", "e"): "high", ("E_mm2", "e"): "medium"}
REASONS = {("U_flank", "e"): "flank_unaligned", ("inv_site", "e"): "inv_site"}


def _expected_b(name, a):
    """B built from A's pieces, for the cases without random filler or mutation."""
    L, T, R = a[:3000], a[3000:3005], a[-3000:]
    e = a[3005:-3005]  # the element (host for host cases)
    return {
        "S": L + T + e[:400] + T + R,
        "S_notsd": L + T + e[:400] + R,
        "T": L + T + e[:400] + e[400:2000] + e[-400:] + T + R,
        "E": L + T + R,
        "D_left": L[:-500] + R,
        "D_both": L[:-300] + R[400:],
        "G": L + T + "N" * 100 + R,
        "G_near": L[:-70] + "N" * 50 + L[-20:] + T + R,
        "G_far": L[:-550] + "N" * 50 + L[-500:] + T + R,
        "inv_site": L + T + revcomp(e) + T + R,
        "nested_E": L + T + e[:2405] + e[5410:] + T + R,  # h without c and one GAGAG
        "host_E": L + T + R,
        "host_S": L + T + e[:400] + T + R,
        "host_G": L + T + "N" * 100 + R,
        "adjacent_E": L + T + "GAGAG" + R,
    }.get(name)


def test_make_element():
    seq, ll, rl = toy.make_element(random.Random(1), 400, 4000)
    assert (len(seq), ll, rl) == (4800, 400, 400) and seq[:400] == seq[-400:]


def test_cases_list():
    assert toy.CASES == list(STATES) and len(toy.CASES) == 21
    with pytest.raises(ValueError):
        toy.case("nope", random.Random(1))


@pytest.mark.parametrize("name", toy.CASES)
def test_toy_case_elements(name):
    c = toy.case(name, random.Random(7))
    by_name = {e.name: e for e in c.elements}
    assert set(by_name) == set(STATES[name]) and len(by_name) == len(c.elements)
    for e in c.elements:
        assert (e.genome, e.seqid, e.strand, e.k) == ("toy", "a", "+", 0.0)
        assert e.eid == make_eid("toy", "a", e.start, e.end)
        assert e.end - e.start + 1 == ELEM_LEN[e.name]
        n = LTR_LEN[e.name]
        assert e.ltr_left == (e.start, e.start + n - 1) and e.ltr_right == (e.end - n + 1, e.end)
        assert c.a[e.start - 1:e.start - 1 + n] == c.a[e.end - n:e.end]  # identical LTRs at the bounds
        assert e.tsd == ("GAGAG" if e.name in ("c", "e2") else "CTCTC")
        k = len(e.tsd)
        assert c.a[e.start - 1 - k:e.start - 1] == e.tsd == c.a[e.end:e.end + k]
    eid = {n: e.eid for n, e in by_name.items()}
    assert c.expect == {eid[n]: s for n, s in STATES[name].items()}
    assert c.flags == {eid[n]: f for (cn, n), f in FLAGS.items() if cn == name}
    assert c.noflags == {eid[n]: f for (cn, n), f in NOFLAGS.items() if cn == name}
    assert c.tiers == {eid[n]: t for (cn, n), t in TIERS.items() if cn == name}
    assert c.reasons == {eid[n]: r for (cn, n), r in REASONS.items() if cn == name}


@pytest.mark.parametrize("name", toy.CASES)
def test_toy_case_b(name):
    c = toy.case(name, random.Random(7))
    a, b = c.a, c.b
    want = _expected_b(name, a)
    if want is not None:
        assert b == want
    elif name == "P":
        assert len(b) == len(a) and 0.005 <= _hamming(a, b) / len(a) <= 0.015
    elif name in ("E_mm1", "E_mm2"):
        assert b[:3000] == a[:3000] and b[3005:] == a[-3000:] and len(b) == 6005
        assert _hamming(b[3000:3005], "CTCTC") == (1 if name == "E_mm1" else 2)
    elif name == "P_nestB":
        assert len(b) == len(a) + 3000 and b[:5405] == a[:5405] and b[8405:] == a[5405:]
    elif name == "O":
        assert len(b) == 8010 and b[:3005] == a[:3005] and b[-3005:] == a[-3005:]
    else:
        assert name == "U_flank" and len(b) == 6005 and b[:3005] == a[:3005] and b[3005:] != a[-3000:]


def test_toy_host_nesting():
    for name in HOST:
        c = toy.case(name, random.Random(8))
        h, ch = sorted(c.elements, key=lambda e: e.level)
        assert (h.name, h.level, h.parent) == ("h", 0, None)
        assert (ch.name, ch.level, ch.parent) == ("c", 1, h.eid)
        assert h.start + 2405 == ch.start and ch.end + 2405 == h.end
    for name in set(toy.CASES) - set(HOST):
        assert all(e.level == 0 and e.parent is None for e in toy.case(name, random.Random(8)).elements)


def _name_of(c, eid):
    return next(e.name for e in c.elements if e.eid == eid)


def test_build_pair_offsets():
    names = ["E", "host_E", "adjacent_E", "P_nestB"]
    pair = toy.build_pair(random.Random(5), names)
    rng = random.Random(5)  # build_pair draws the cases first, in order, then the spacers
    cases = [toy.case(n, rng) for n in names]
    sp = toy.SPACER
    assert len(pair.a) == sum(len(c.a) for c in cases) + (len(names) + 1) * sp
    assert len(pair.b) == sum(len(c.b) for c in cases) + (len(names) + 1) * sp
    oa = ob = sp
    for n, c in zip(names, cases):
        assert pair.a[oa - sp:oa] == pair.b[ob - sp:ob]  # same spacer before the case in A and B
        assert pair.a[oa:oa + len(c.a)] == c.a and pair.b[ob:ob + len(c.b)] == c.b
        new = {e.name: e for e in pair.elements if e.name.startswith(n + ".")}
        assert len(new) == len(c.elements)
        for e in c.elements:
            p = new[f"{n}.{e.name}"]
            assert (p.genome, p.seqid, p.tsd, p.k, p.level) == ("toy", "chr1", e.tsd, 0.0, e.level)
            assert (p.start, p.end) == (e.start + oa, e.end + oa)
            assert p.ltr_left == (e.ltr_left[0] + oa, e.ltr_left[1] + oa)
            assert p.ltr_right == (e.ltr_right[0] + oa, e.ltr_right[1] + oa)
            assert p.eid == make_eid("toy", "chr1", p.start, p.end)
            assert pair.a[p.start - 1:p.end] == c.a[e.start - 1:e.end]
            assert pair.expect[p.eid] == c.expect[e.eid]
            for d_pair, d_case in ((pair.flags, c.flags), (pair.noflags, c.noflags), (pair.tiers, c.tiers),
                                   (pair.reasons, c.reasons)):
                assert d_pair.get(p.eid) == d_case.get(e.eid)
            if e.parent is not None:
                assert p.parent == new[f"{n}.{_name_of(c, e.parent)}"].eid
        oa += len(c.a) + sp
        ob += len(c.b) + sp
    assert pair.a[-sp:] == pair.b[-sp:]
    assert len(pair.expect) == len(pair.elements) == sum(len(c.elements) for c in cases)


def test_build_pair_default_cases():
    pair = toy.build_pair(random.Random(6))
    assert {e.name.split(".")[0] for e in pair.elements} == set(toy.CASES) - {"U_flank"}
    assert all(e.seqid == "chr1" for e in pair.elements)
    assert sorted(e.start for e in pair.elements) == [e.start for e in pair.elements]
