# Task 9 Part B (code) review: eval_run m1/m2, eval_ltrmix.py, summarize.py, test_summarize.py

Reviewed 2026-11-13. Files (plan3/sim), sha256 as reported: eval_run.py 6fbe0794, eval_ltrmix.py 53318469,
summarize.py afd525e1, test_summarize.py c142be5b, common/evalib.py f9f61a20. RULES.md is unchanged and read-only:
4111826d...a293.

Every probe ran on copies in
`/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t9breview/`:
- `synth.py` builds synthetic eval.json and eval_ltrmix.json sets on the real 144-row grid;
- `probe_r123.py`, `probe_r456.py`, `probe_r78.py` and `probe_power.py` probe the bars;
- `m1_check.py`, `mix_check.py`, `paint_check.py` and `absentP.py` recompute the evals independently;
- `mut/` holds the mutation runs.

## Spec Compliance

### eval_run.py fixes
- ✅ **m1** (eval_run.py:459-479). Sister-discovered truth D now blocks on the C1 copy of each eid. An independent
  recompute (csv plus my own delete-one-block jackknife, `m1_check.py`) matches eval.json to every digit:
  - null_s101: D 0.28125, se 0.144446, z 1.94709, n 64, 43 blocks;
  - fn0.2_f0.18_r1: D -0.131579, se 0.133392, z -0.986410, 51 blocks.

  The change at line 470 from `in_d[n]` to `r["state"]` is equivalent: both read the same `x__C1` file.
- ✅ **m2** (eval_run.py:631): `wrong_trio = not wrong and scope != TRIO`, so the two flags are exclusive. On the trio
  toy, wrong_recipient is 1 and wrong_trio 0. eval_ltrmix.py:440 mirrors it.
- ✅ **Parity holds.** Rerunning eval_run.py on fresh copies gives parity equal on 36 and 9 pairs. The output is
  identical to the implementer's files except for one field: `scripts.eval_ltrmix.py` now holds a hash, where the
  implementer's toy eval.json recorded "not written yet". That explains the NA counts of 44 / 105 against the
  reported 45 / 106.

### eval_ltrmix.py against eval_sim.py, sim_summary.py and the brief
Checked independently with pandas in env ltrmix (`mix_check.py`).
- ✅ **D tests.** D_kmer, D_ins, D3 and D_self match LTRmix's stats.tsv in D, SE, Z, nA and nB, on the right strata.
  - The recipient read from the sister-pair line equals eval_sim.py's `D(single-copy k-mers; R,` reading on both toys
    (ltrmix.py:1092-1101 writes R first).
  - z_A1 = +z for R A1 (null toy) and -z for R B1 (trio toy), as sim_summary.py does.
- ✅ **D_ins young/old.** Pooled over eval_sim.py's strata. Old: D 0.053571 (null) and 0.017241 (trio, re-signed
  -0.017241). Young is NA with its reason, since LTRmix writes no stratum with fewer than 10 loci.
- ✅ **f-ratio and f_lower_bound.** f_ratio_ins alpha 0.125, se 0.225711 (`second donor C2`); f_lower_bound 0.201679
  and 0.220806. The trio design gives NA with a reason.
- ✅ **Recipient and wrong_recipient** (eval_ltrmix.py:236-254, 420-446).
  - recipient_identified is false when D_kmer is 0 or nan; wrong_recipient then gives recall 0 and AUROC NA.
  - A missing elements.A1.tsv is recorded and never raises (probed by deleting it).
- ✅ **Painting accuracy.** `paint_check.py` uses a copy of the null toy with 8 synthetic true A1 tracts in all four
  length bins and q = 0.01 on 3 recent and 2 ancestry tracts. eval_ltrmix.json equals eval_sim.py's own `auc`,
  `merge` and `overlap_bp` exactly:
  - AUROC: recent 0.818618314, ancestry 0.596382522; 107 elements inside;
  - bp precision and recall, all and q05; n called;
  - recall by length under the named >= 50% rule (eval_sim.py counted any overlap);
  - tract FDR.
- ✅ **Presence/absence.** An independent pandas join (record span -> GFF3 Name -> truth state) reproduces the pooled
  counts:
  - null toy: present tp/fp/fn 2866/150/2809, absent 2625/4315/71;
  - trio toy: 1362/82/1407 and 1419/2130/80.

  The class rules match `ltrpav.sim.score.CLASSES`.
- ✅ **rate_free_split.** s 0.00112 [0.00097, 0.00337] (5 blocks, 200 replicates); mixture 0.00357; true s
  2 x 3e-8 x 60000 = 0.0036. A deleted s line and a deleted file each give NA with their reason.

### summarize.py bars against RULES.md
Each bar was run on synthetic eval sets with known verdicts, edge cases included (scripts listed above).

- ✅ **Rule 1.**
  - |Z| = 3.0 and -3.0 are not counted; 3.0001 is. 1 of 30 gives PASS, CP [0.000844, 0.172169], equal to the beta
    quantiles.
  - With one run missing, 0 exceeded and 1 exceeded both read NA. 2 exceeded with 1 missing reads FAIL "decided".
  - A Z that is NA gives NA, with the eval file's reason surfaced.
  - Stale inputs are caught: a RULES hash mismatch, a marker newer than the eval file, and a failed run.exit.
  - Reported rows: truth D x3, LTRmix x4 (z_A1 over every null), nodonor, and the bottleneck nulls (3 of 30). The
    no_outgroup_filter stratum sits beside LTRmix in null.tsv.
- ✅ **Rule 2.** The chi-square interval of the SD (29 df) and |mean| <= 2 SE are each tested on both sides of their
  boundary:
  - mean at 2 SE ± 1e-4;
  - SD giving lo = 0.9999 / 1.0001;
  - SD giving hi = 1.0001 / 0.9999.

  All 6 cases read correctly for D_pav and for LTRmix D_ins. There are 9 items: D_pav, dD, truth D x3, LTRmix x4.
  SD(D) / mean SE is right, and a missing null gives NA.
- ✅ **Rule 3.** The eid pool is summed over every run.
  - P at exactly 0.95 (13,680 / 14,400) passes; E at 0.949 fails; the bar fails; a missing run gives NA.
  - On the toys, an awk sum of high-tier P/E tp/fp over every eval/score file equals summarize's 14,194/36 and
    10,264/56.
- ✅ **Rule 4.**
  - Count bar on `models.<m>.n_tracts_q05 > 0`, with excess within 2 SE.
  - For any and anydecoy, 2 of the 20 dropout nulls fails the model (C2 probe).
  - FAIL propagates through tri_and; missing runs give NA.
- ✅ **Rule 5.**
  - **FDR:** 180/3,600 = 0.05 (CP high 0.0576) passes; 181/3,600 fails; 2/36 (CP high 0.187) fails; a missing power
    run gives NA.
  - **Sign tests:** 5 NA pairs dropped (m3) and 2 ties dropped. +20 / -9 gives p = binom.sf(19, 29) = 0.030714,
    exact. Precision lower in 20 of 29 fails "not lower".
  - **Adoption:**
    - every variant passes, anydecoy included -> "any + decoy";
    - anydecoy fails on the nulls, or on the dropout nulls only -> the larger median gain (any);
    - equal gains -> default;
    - default fails rule 4, and decoy holds the null and passes the FDR bar but loses recall -> decoy (clause);
    - the same with decoy's FDR failing -> default.
- ✅ **Rule 6.** 3/36 gives the label, carried into the adoption bar; 4/36 gives no label (strict <). A missing run
  gives NA.
- ✅ **Rule 7.**
  - All 8 posctl runs read their prediction -> confirmed. A posctl null reading C>A, or a C1>A1 run reading
    unresolved -> not confirmed, with the consequence text from RULES.md. A missing run gives NA.
  - Nulls: 2 directional + 1 unresolved count as 3 false calls.
  - Gene-flow runs over power, reverse, ptlike and bneck f > 0: 3 wrong counted false, 4 right reported.
  - ptlike: 1 of 3 right. Only the prediction's label is read, through dfoil_direction (R2).
- ✅ **Rule 8.** The ratio of means equals the hand value (0.66 when D_ins = 0.66 D_pav). The interval is [0.66, 0.66]
  and contains 0.66. Flip runs are excluded (but see I1).

### Power, missing runs and the rulings
- ✅ **Power.**
  - Cell mean and SD of Z, the count with Z > 3, and Z = 3 not counted.
  - The projection Z_sim * sqrt(2041 / n) is exact and labeled.
  - On a 360-run synthetic dose-response, the probit fit equals an independent BFGS fit: a -2.85843, b 22.5491,
    f80 0.164088 (true 0.1671). The profile interval [0.151233, 0.178975] equals a brute-force profile within the
    1e-4 grid.
  - Two near-separated 12-run sets match BFGS. Complete and quasi-complete separation give NA with a bracket.
  - The no_outgroup_filter stratum sits beside LTRmix's D tests.
- ✅ **Missing and stale runs are never imputed.** The converse holds: a count bar that is not exceeded with runs
  missing is NA, never PASS (rules 1 and 4 counts, 3, 5, 6, 7).
- ✅ **Rulings implemented:** I2, I3, I4, I5/pools/files, bins (LOCI_BINS labels "0-1"..."30-inf"), m1, m2, m3,
  resolution rows, and the five summarize readings.
- ❌ **Latest ruling (progress.md:132) not implemented:** "summarize also reports the fraction of runs where LTRmix's
  sister pair is A1,B1 beside the power" and for rule 8. See I1.
- ⚠️ **Tests do not pin every bar.** They cover rules 1, 2, 6, power, the probit, sign and FDR arithmetic, and one
  adoption path. They do not cover rules 3, 7 and 8, rule 4's FAIL paths on the nulls, or rule 5's both / larger-gain /
  tie / default-fails clauses. See m1.

## Strengths
- **Correct bars.** Every bar's arithmetic and verdict logic is right on every synthetic edge case tried, the boundary
  cases (Z = 3, FDR = 0.05, 10%, the SD interval ends) included.
- **NA handling.**
  - Three-valued logic (`tri_and`, `verdict_of`) keeps NA from ever turning into PASS.
  - `count_bar` (summarize.py:444-459) gets the decided-FAIL case right.
  - NA reasons travel from the eval files into the bars.
- **Guards.** Staleness is keyed on script hashes plus the RULES.md hash, and the registered RULES.md hash stops a
  changed rule at the door. Every BAR text is tested to be RULES.md's own words.
- **Faithful port.** eval_ltrmix.py reproduces eval_sim.py's scoring exactly where the two share a definition. It
  names the one deliberate difference (the >= 50% "found" rule, shared with LTRpav) and the 0-based element midpoint.
- **Joins and reproducibility.** The PAV join by GFF3 Name is exact by construction. The eval outputs are
  reproducible.

## Issues

### Critical
None.

### Important
- **I1. The binding ruling on the summarize readings (progress.md:132) is not implemented.** LTRmix's power and
  rule 8 drop the flip runs without reporting the sister-pair fraction beside them.
  - **Power** (summarize.py:618-623, 634-670): flips become NA, appear only inside a free-text top-3 reason, and the
    probit row lumps them into "N run(s) missing or NA, not imputed" (663-669). The docstring's "counted as n_flip"
    (line 51) names a column that does not exist.
  - **Rule 8** (summarize.py:1104-1105, 1133-1139): flips are dropped silently. In the r8 probe, the bar shows n 32 of
    n_required 36 with n_missing 0, and no flip count in its reason. gaps.tsv's "D_ins (A1)" rows say only "LTRmix
    runs with sister pair A1, B1".
  - **Effect:** a reader can take LTRmix's power and the D_ins / D_pav reading as holding over all runs, when they
    hold only for those where LTRmix found the right trio.
  - **Fix:** add `n_sister_ok` and `frac_sister_ok` (of runs with an LTRmix file) to every LTRmix power row, cell and
    probit. Put the same fraction in gaps.tsv's D_ins rows and in the rule 8 bar's reason ("k of n runs with sister
    pair A1,B1; m flips excluded"). Fix the docstring.

### Minor
- **m1. The tests do not pin rules 3, 7 or 8, or rule 5's adoption clauses** (test_summarize.py). I mutated a copy of
  summarize.py 10 times; 9 mutants pass all 12 tests:
  - rule 3's bar raised to 0.96;
  - larger median gain swapped;
  - "tie keeps the default" removed;
  - "both" mapped to "any";
  - the default-fails clause inverted;
  - posctl `all` changed to `any`;
  - unresolved reads not counted as false;
  - 0.66 changed to 0.5;
  - the power set widened to the reverse runs.

  Only dropping the dropout nulls from rule 4 was caught. The code is right today (probes above), but summarize
  decides pre-registered verdicts. The probe scripts named above can be turned into tests.
- **m2. One NA label covers every NA pair in the sign tests** (summarize.py:787-796, 885-886). `q05()` returns NA when
  `models.<m>.accuracy` is missing for any reason, and the counts text says "(no q <= 0.05 tract)" for all of them.
  Adoption is unaffected, because the FDR series goes NA for the same run (856-861). A related edge: a C>A power run
  with an empty A1 truth (eval_run.py:305, 598-599) makes rule 5's FDR NA for good, although every called tract there
  is false. This is unlikely at full scale.
- **m3. Some decided outcomes are still reported NA.**
  - Rule 6 is NA whenever a power run is missing (summarize.py:926-927), even when 4 of 36 are already degenerate and
    "no label" is decided (probe I).
  - posctl confirmation is NA when a present run already fails (1045).

  Conservative, never wrong, but inconsistent with count_bar's decided FAIL.
- **m4. Staleness misses two cases** (load_doc, summarize.py:312-335).
  - A step marker that is absent is not treated as stale, and run.exit is checked only when the eval file is absent.
    run_one.sh clears later markers on a rerun (run_one.sh:201, 213), but eval/ survives a `--from views` rerun. A
    failed rerun of a finished run would therefore be scored from its old eval files.
  - eval_ltrmix.json is not tied to the eval.json it read.

  Requiring run.done (written after eval) to be newer than both eval files would close both.
- **m5. The sign tests are one-sided** (summarize.py:32-33, 882-884). This reading is named in the docstring and the
  report, but it was not among the readings put to the controller. With 36 pairs, one-sided p < 0.05 needs 24
  positives and two-sided needs 25. Surface it for confirmation.
- **m6. Two rule 7 bars are incomplete.**
  - The ptlike bar hard-codes "prediction none" (summarize.py:1083-1084). The direction.tsv row reads the prediction
    from the file (1036-1038).
  - The gene-flow bar (1071-1076) omits the count of unresolved reads.
- **m7. The probit's separation message misreads quasi-complete separation** (summarize.py:221-223). When the boundary
  f holds both outcomes, it says "every run at f >= 0.1 reached Z > 3, none at f <= 0.1 ... between 0.1 and 0.1".
- **m8. Two brief items are not fully followed.**
  - tracts.tsv's `excess_mean` (summarize.py:771-772) lacks the true fraction beside it; the brief asks for "the
    excess against the true fraction".
  - gaps_table drops a run from the D_pav vs truth-D comparison when only its LTRmix file is missing (1099-1101).
- **m9. The report misattributes LTRmix's "absent" calls on truly present copies.**
  - On the null toy, pair A1 -> B1: 224 of 471 truly-P elements are called absent. 82% of them are annotated in B1,
    95% of those with exact spans, and the young ones are over-represented (mean K2P 0.042 vs 0.061).
  - These are LTRmix orthology misses, not unannotated copies and not jitter of the annotation.
  - eval_ltrmix's counts are right (the independent join reproduces them).
  - Worth checking at pilot scale before the presence/absence head-to-head is read.
- **m10. eval_ltrmix.py has no pytest** (QA scripts only), against CLAUDE.md's "every standalone tool gets at least
  basic tests".

## Assessment
**Needs fixes.**
- The bars are correct against RULES.md word by word.
- eval_ltrmix.py reproduces eval_sim.py's reference logic.
- m1 and m2 are implemented exactly, and parity holds.
- The one Important finding, I1, is a binding controller ruling that was never implemented: one or two columns plus a
  reason string. Fix it before the pilot is scored.
- m1 (tests for rules 3, 7, 8 and the adoption clauses) is strongly recommended in the same pass, since summarize
  decides the pre-registered verdicts.

## Re-review (fix round 1)

Reviewed 2026-11-13. The files hash as the report states:
- summarize.py c0c9dd3a;
- eval_ltrmix.py 3287f3d0;
- test_summarize.py 4100464d;
- test_eval_ltrmix.py 3b449b85.

eval_run.py (6fbe0794), evalib.py and RULES.md (4111826d...a293) are unchanged. I diffed both changed scripts against
my round-0 copies. eval_ltrmix.py changes only in its `inputs` record (line 662).

All probes ran on copies in `.../scratchpad/p3t9breview/`; plan3/sim/runs/ was not touched. The synth harness now
writes step markers and the `inputs` tie, since the new staleness rules require both.

### Findings
- **I1: fixed.** The fraction of runs where LTRmix's sister pair is A1, B1 is now reported wherever it decides
  inclusion.
  - `right_pair` and `flip_reason` (summarize.py:649-668) give `n_flip` and `frac_right_pair` on every LTRmix power
    row (697-702). The probit row carries the ta's totals (720-727), and a cell's n_na no longer counts flips.
  - The rule 8 bar has `count` = n_flip plus both columns and a reason (1231-1236). gaps.tsv's D_ins rows carry the
    same columns.
  - Probes:
    - 6 flips of 12 at ta 500 give n_flip 6 and frac 0.5 on the probit row, and 1 of 2 on each cell;
    - rule 8 with 4 flips reads count 4, frac 32/36, "32 of 36; 4 flip(s) excluded";
    - adding 1 missing LTRmix file gives 31 paired, 1 missing, frac 31/35.
- **m1: mostly fixed, partly open.**
  - New exact-verdict tests cover:
    - rule 3 (test_summarize.py:403);
    - rule 5's four adoption clauses, the FDR boundary and the sign-test p (441-519);
    - rule 6 decided with runs missing (522);
    - rule 7 (534);
    - rule 8 with flips (581);
    - the flip columns (612);
    - staleness (630);
    - quasi-complete separation (645).
  - All 10 of my round-0 mutants are now caught. 11 of 12 new mutants on the round-1 code and other bars are caught.
  - **Still unpinned:** rule 4's excess test and the 2-SE multiplier.
    - `within_2se` returning ok always survives (summarize.py:179-185), as do SD in place of SE and 2.5 SE.
    - Rule 2's 2-SE line can move: 2.2 SE survives. The only mean test shifts by 0.5 = 2.74 SE
      (test_summarize.py:65), so any multiplier below 2.74 passes.
    - Rule 4's "holds the null" therefore rests on its count half alone in the tests.
  - The code itself is right: my probes pin both boundaries (mean at 2 SE ± 1e-4), and rule 4's excess fails when it
    should.
  - Two other survivors are harmless:
    - widening `bneck_null` to the gene-flow runs survives only because the fixture's bneck Z are 0;
    - rule 6's `<` changed to `<=` cannot differ, since k/36 is never exactly 0.1.
- **m2: fixed for the reasons; the edge case stays open by choice.**
  - `paired` (summarize.py:864-877) now names each NA pair's reason. A probe shows "no q <= 0.05 tract (ruling m3) x2;
    pulse into A1 but no tract survived in A1 x1".
  - A power run with an empty A1 truth still makes rule 5's FDR NA, and adoption stays NA. This is documented and
    unlikely at full scale.
- **m3: fixed.**
  - Rule 6 (summarize.py:1002-1007), with k degenerate + m missing of 36:
    - 4+1 gives "no label";
    - 3+1 gives NA;
    - 1+1, 2+1 and 0+3 give "label";
    - 0+4 gives NA;
    - 3 degenerate + 1 NA fit gives NA.
  - posctl (1125): one misread + one missing gives "not confirmed", reason "decided: a present run misreads".
- **m4: fixed.** An absent marker makes the eval file stale (summarize.py:345). eval_ltrmix.json must name the sha256 of
  the eval.json beside it (379-384; eval_ltrmix.py:662). Probes:
  - views.done absent: LTRpav stale, LTRmix ok;
  - ltrmix.done absent: LTRmix stale;
  - eval.json rewritten: LTRmix stale;
  - `inputs` missing: stale;
  - eval.json absent: LTRmix stale "now absent".
- **m5: resolved by the controller's ruling.** The sign tests are one-sided, as the code already reads them.
- **m6: fixed.**
  - The PT-like bar reads its prediction (summarize.py:1164-1174), and adds the Task 13 note only when it is "none".
  - The gene-flow bar reads "3 false, 4 right, 2 unresolved, 41 none".
- **m7: fixed** (summarize.py:226-235). Complete and quasi-complete separation get separate messages: "1 of 2 at
  f = 0.1; f80 lies between 0.05 and 0.18". Fits that are not separated still match BFGS.
- **m8: fixed.**
  - `A1_true_fraction_mean` sits beside the excess (summarize.py:831-834).
  - gaps.tsv keeps LTRpav's comparison when only the LTRmix file is missing (1186-1197): D_pav n 36, D_ins n 31 with
    1 missing.
- **m9: fixed in the report** (task-9-report.md:367-370).
- **m10: fixed.** test_eval_ltrmix.py has 5 tests, each worked by hand. I checked:
  - AUROC 0.75 and 1.0;
  - bp 1500 / 3000 sitting exactly on the >= 50% rule;
  - presence/absence 6/1/0 and 5/0/1 with 6 unannotated;
  - the tie giving "not identified";
  - the s-line NA.

### Regressions
None found.
- **Verdict probes.** Every round-0 probe gives its old verdicts: rules 1-8, power and the probit, the CP and
  chi-square boundaries, and the sign-test p. The only changes are the intended ones: decided outcomes with runs
  missing, and the flip columns.
- **Toys.** I reran eval_ltrmix.py on fresh toy copies. They differ from round 0 only in `inputs` and the script hash.
  summarize on the toys still gives 2 of 144 runs ok/ok and 42 NA + 14 reported bars, as before.
- **Tests.** 36 passed with -W error on a copy: summarize 22, eval_ltrmix 5, evalib 9.
- **Minor, cosmetic.** `ruff check --no-cache` run from sim/ reports 2 import-order findings (I001), at summarize.py:83
  and eval_ltrmix.py:65. The report says "ruff clean".

### Assessment
**Approved.** I1 and m2-m10 are addressed, and m5 is settled by ruling. The new tests pin exact verdicts for rules 3,
5, 6, 7 and 8, the flips and staleness. What remains is Minor:
- the tests leave rule 4's excess half and the 2-SE multiplier (rules 2 and 4) unpinned, though the code is right;
- the empty-truth FDR edge is left by choice.
