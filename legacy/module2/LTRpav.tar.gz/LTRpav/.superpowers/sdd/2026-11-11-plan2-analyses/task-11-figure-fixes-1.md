# Task 11, figure round 1: controller's figure check of overview.png and the legend pages (main3 render)

Reviewed: `benchmark_pav/plan2_figure/run/overview.png` and `overview.pdf` pages 2-3 at commit 65c7467, with
full-resolution crops.

| Line | Verdict |
|---|---|
| 1. Panel A shows the biology in genome coordinates, every element drawn | Yes (A; B draws every insertion) |
| 2. Raw evidence for a real, typical, verified example | Yes (C), but the legend hides how small the clean subset is (F3) |
| 3. Control drawn as a full partner at the same scale | Yes (A decoy rows; G) |
| 4. Every null drawn | No: B's posterior track has none (F2) |
| 5. On-figure text only letters, labels, keys, n | Nearly: A's key carries an explanation, and a key class has no n (F6) |
| 6. Crops: nothing clipped or colliding; one grid | Nearly: the "B" zoom label sits on data; the right edges are about 2 mm off (F8) |
| 7. Each panel answers a different question; the legend pages follow the rules | Questions: yes. Legends: jargon and an unconditional sentence (F4, F5). Color system: E contradicts A and B (F1) |

The rest is strong: the layout, the decoy beneath each chromosome, the C alignment, F's n column, and the paired
points in G. Keep all of it.

## Fixes (all required, except where marked)

**F1. Color means the same entity in every panel (Important).**
- In A and B, blue marks R+S, the insertions the sisters share.
- E draws B73 + TIL01 (R+S) in gray and TIL01 + TIL18 (S+D) in blue, which contradicts that.
- Map E as follows:
  - R+S in blue;
  - R+D in filled vermillion;
  - S+D in the decoy's style, which G already uses: an open vermillion circle, matching the vermillion S+D ticks of
    A's decoy rows.
- Another mapping is fine if it keeps A, B, E and G consistent; give a one-line reason in memo.md.
- Check panel H the same way.

**F2. Draw the null on B's posterior track (Important; honesty).**
- A plateau near 1 over 437 kb reads as a confident call. The tract's q is 0.72, and the legend's caveat says only
  q-values carry evidence. That null is stated only in the legend, so it gets lost.
- On B's posterior track, draw how high the control's posteriors reach, so a reader can see without the legend that
  this tract is ordinary.
- Preferred form: compare tracts with tracts. Draw a gray band for the middle half (or middle 90%) of the mean
  posterior of the decoy's tracts, with a direct label. Add, if it fits, the same quantity for the recipient's
  tracts.
- Acceptable alternative: thin marginal histograms or half-violins of the per-insertion posterior, recipient against
  decoy. On main3, 10.2% of B73's insertions reach >= 0.9, against 5.0% of the decoy's. Give the reason in memo.md.
- Do not draw a per-insertion percentile line: it invites a per-locus "p < 0.05" reading, which the tract q
  contradicts.
- Make the posterior track taller if it needs room; the page can grow to about 240 mm.
- Every new number goes into overview_numbers.tsv and the long legend.
- Without decoy tracts there is no band, and the legend says so.

**F3. Say how small the clean subset is (Important; legend honesty).**
- The long legend says "Checks, fixed before looking, on 13 candidates" but not how many passed.
- State the pass count and the most common failed check or checks (for example: "k of 13 passed; most failures:
  non-identical TSD copies, ..."), so the reader knows the example comes from the clean subset and how small that
  subset is.
- The skill requires this: a showcase must be "typical of all calls, not of a confirmed subset (if drawn from a
  subset, say so)".
- Same text in memo.md. Add a number row for the pass count.

**F4. Keep pipeline jargon out of the caveats (legend rules).**
- The caveats currently quote findings.txt verbatim ("findings.txt warns: Mechanisms: branches_resolution all: ...
  (heuristic threshold)"). That warning concerns per-branch counts, which no panel draws.
- Include only warnings that bear on a drawn panel, in plain words. For the resolution-symmetry warning, for example:
  "calls are resolved unequally among the genomes (B73 60%, ...), which favors the better-resolved genome in <the
  drawn comparison>".
- Any other warning becomes one plain line: "N further warnings are listed with the run's findings". No stage, file
  or metric names.
- Test: a findings warning that carries a stage or metric name never reaches the legend verbatim.

**F5. Conditional sentence.** "Open points: not testable by the block jackknife." prints even though panel F has no
open point. Print it only when one is drawn, and test both cases.

**F6. On-figure text (line 5).**
- A's key entry "S sister TIL01 (parviglumis), painted beneath each R sequence as the decoy" explains the panel. Cut
  it to the role and "the decoy"; the row labels already show where the decoy is.
- The key entry "tract, q <= 0.05" names a class the figure does not contain. Add its n, for example "(none)" or
  "(n = 0)".

**F7. Label precision (Minor).**
- D's row "cut inside, no remnant" asserts that no remnant exists. The class (D_inside_unshown + O_inside_unshown)
  means a remnant is *not shown*: it is >= MIN_SEG, or it holds an annotated child.
- Rename the row, for example "cut inside, remnant not shown", and match the long legend's "or with no remnant".

**F8. Crops and grid (Minor).**
- A's zoom label "B" sits on chr4's vermillion ticks. Move it clear of the data, for example above the tick row or
  on a white backing.
- A's right-column axis ends about 2 mm left of B's and D's right edges. Align them if the layout allows: one shared
  grid.

**F9. Panel H test (Minor; listed as not done).** Add a minimal test: a multi-trio toy sheet renders H, and the
numbers table holds one D row per trio.

## Rulings (no change needed)
- **Group names stay as written.** The legend shows the sheet's groups, so *parviglumis*, *mexicana* and
  *diploperennis* appear upright. Group names are sheet labels that the tool cannot classify as taxa, and
  italicizing them by heuristic would italicize "maize" too. Render them as given and note in memo.md that the user
  italicizes them for publication.
- **The inversion-caller concern goes to Plan 2's final wave, not this round.** The concern is report concern 1: 49
  sparse TIL01 blocks flag 31,473 decoy loci.

## Process
- Fix the issues, re-render on the same read-only main3 view (`benchmark_pav/plan2_figure/run`), and inspect
  full-resolution crops again.
- Answer the figure check again in memo.md.
- Run the full suite (`python -m pytest -W error -m "not slow"`) and `ruff check .`.
- Commit with plain subjects, no trailers, and nothing set.
- Append a "Figure round 1" section to task-11-report.md.
- Return only:
  - the commits;
  - the test line;
  - one line per fix;
  - the new numbers;
  - anything not done.
