#!/usr/bin/env python3
"""Comparator (independent of LTR-RTs): SNP ABBA/BABA in gene space with Z. diploperennis as outgroup.
B73 v5 genes (+-1 kb) are aligned to each other assembly (minimap2 asm10, primary, mapq >= 20, >= 80% of the query);
for each B73 gene position with an aligned base in all three other genomes:
ABBA = P1 = P3 != P2 = O;  BABA = P2 = P3 != P1 = O (default P1 B73, P2 TIL01, P3 TIL18, O Zd).
Outputs per-site counts per 100-kb window (B73 coordinates) and D with a 5-Mb block jackknife."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import argparse
import gzip
import os
import re
import subprocess

import numpy as np
import pandas as pd

BASE = {"A": 0, "C": 1, "G": 2, "T": 3}


def genes_fasta(gff, genome, out, flank=1000):
    if os.path.exists(out):
        return
    seqs, name, buf = {}, None, []
    with open(genome) as f:
        for line in f:
            if line.startswith(">"):
                if name:
                    seqs[name] = "".join(buf)
                name, buf = line[1:].split()[0], []
            else:
                buf.append(line.strip())
    seqs[name] = "".join(buf)
    with gzip.open(gff, "rt") as f, open(out, "w") as o:
        for line in f:
            p = line.split("\t")
            if len(p) < 9 or p[2] != "gene" or not re.fullmatch(r"chr\d+", p[0]):
                continue
            c = "B73v5_" + p[0]
            s, e = max(int(p[3]) - 1 - flank, 0), int(p[4]) + flank
            gid = re.search(r"ID=([^;]+)", p[8]).group(1)
            o.write(f">{gid}|{c}|{s}\n{seqs[c][s:e]}\n")


def parse_cs(cs, qstart):
    """Yield (query position, target base) for every aligned (match/mismatch) query position."""
    q = qstart
    for op, val in re.findall(r"([:*+\-])([0-9]+|[acgtn]+)", cs):
        if op == ":":
            n = int(val)
            for k in range(n):
                yield q + k, None          # identical to query
            q += n
        elif op == "*":
            yield q, val[0].upper()        # *xy: x = target (other genome) base, y = query (B73) base
            q += 1
        elif op == "+":                    # bases in the query (B73) absent from the target
            q += len(val)
        elif op == "-":                    # bases in the target absent from the query
            pass


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--outdir", required=True)
    ap.add_argument("-t", type=int, default=16)
    ap.add_argument("--p1", default="B73v5", help="tested genome (B73v5 = the gene reference itself) [B73v5]")
    ap.add_argument("--p2", default="TIL01", help="its sister [TIL01]")
    ap.add_argument("--p3", default="TIL18", help="donor [TIL18]")
    ap.add_argument("--outgroup", default="Zd", help="outgroup assembly label [Zd]")
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    gff = "/data2/chris/maize_introgression/benchmark_data/annot/Zm-B73-REFERENCE-NAM-5.0_Zm00001eb.1.gff3.gz"
    gfa = os.path.join(a.outdir, "B73_genes_1kb.fa")
    genes_fasta(gff, "/data2/chris/maize_introgression/inputs/B73v5.fa", gfa)
    gseq = {}
    with open(gfa) as f:
        name = None
        for line in f:
            if line[0] == ">":
                name = line[1:].strip()
            else:
                gseq[name] = line.strip().upper()
    calls = {}
    for g in [x for x in (a.p3, a.p2, a.p1, a.outgroup) if x != "B73v5"]:
        paf = os.path.join(a.outdir, f"{g}.paf")
        if not os.path.exists(paf + ".done"):
            cmd = (f"minimap2 -t {a.t} -x asm10 -c --cs=short --secondary=no -K 200M "
                   f"/data2/chris/maize_introgression/inputs/{g}.fa {gfa} > {paf}.tmp 2> {paf}.log && mv {paf}.tmp {paf}")
            subprocess.run(cmd, shell=True, check=True)
            open(paf + ".done", "w").close()
        best = {}
        with open(paf) as f:
            for line in f:
                p = line.rstrip("\n").split("\t")
                qn, ql, qs, qe, strand, mapq = p[0], int(p[1]), int(p[2]), int(p[3]), p[4], int(p[11])
                if mapq < 20 or (qe - qs) < 0.8 * ql:
                    continue
                cs = [x[5:] for x in p[12:] if x.startswith("cs:Z:")]
                if not cs:
                    continue
                if qn not in best or (qe - qs) > best[qn][1] - best[qn][0]:
                    best[qn] = (qs, qe, strand, cs[0])
        al = {}
        comp = str.maketrans("ACGT", "TGCA")
        for qn, (qs, qe, strand, cs) in best.items():
            s = gseq[qn]
            arr = np.full(len(s), "N", dtype="<U1")
            if strand == "+":
                for pos, tb in parse_cs(cs, qs):
                    arr[pos] = s[pos] if tb is None else tb
            else:
                # for reverse-strand alignments minimap2's cs is on the target strand; query coordinates run backward
                rc = s[::-1].translate(comp)
                L = len(s)
                for pos, tb in parse_cs(cs, L - qe):
                    b = rc[pos] if tb is None else tb
                    arr[L - 1 - pos] = b.translate(comp)
            al[qn] = arr
        calls[g] = al
        print(g, len(al), "genes aligned", flush=True)
    rows = []
    for qn, s in gseq.items():
        if not all(qn in calls[g] for g in calls):
            continue
        ref = np.array(list(s))
        get = lambda g: ref if g == "B73v5" else calls[g][qn]
        b, x, y, z = get(a.p1), get(a.p3), get(a.p2), get(a.outgroup)
        ok = np.isin(b, list("ACGT")) & np.isin(x, list("ACGT")) & np.isin(y, list("ACGT")) & np.isin(z, list("ACGT"))
        abba = ok & (b == x) & (y == z) & (b != y)
        baba = ok & (y == x) & (b == z) & (b != y)
        _, c, st = qn.split("|")
        rows.append((c, int(st), int(ok.sum()), int(abba.sum()), int(baba.sum())))
    d = pd.DataFrame(rows, columns=["chrom", "start", "sites", "abba", "baba"])
    tag = "" if (a.p1, a.p2, a.p3, a.outgroup) == ("B73v5", "TIL01", "TIL18", "Zd") else f".{a.p1}_{a.p2}_{a.p3}"
    d.to_csv(os.path.join(a.outdir, f"gene_abba_baba{tag}.tsv"), sep="\t", index=False)
    blk = d.chrom + ":" + (d.start // 5_000_000).astype(str)
    ub, inv = np.unique(blk, return_inverse=True)
    A, B = np.bincount(inv, d.abba, len(ub)), np.bincount(inv, d.baba, len(ub))
    D = (A.sum() - B.sum()) / (A.sum() + B.sum())
    jk = np.array([((A.sum() - A[i]) - (B.sum() - B[i])) / (A.sum() + B.sum() - A[i] - B[i]) for i in range(len(ub))])
    se = np.sqrt((len(jk) - 1) / len(jk) * ((jk - jk.mean()) ** 2).sum())
    print(f"D({a.p1},{a.p2};{a.p3};{a.outgroup}) genes with all four: {len(d)}; sites {d.sites.sum():,}; "
          f"ABBA {A.sum():,} BABA {B.sum():,}; "
          f"D = {D:+.4f} +- {se:.4f} (Z = {D / se:.1f})")


if __name__ == "__main__":
    main()
