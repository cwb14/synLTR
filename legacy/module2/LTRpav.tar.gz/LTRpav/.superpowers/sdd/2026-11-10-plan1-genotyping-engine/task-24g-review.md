# Task 24G review (8dfc012..1cb1b34)

## Spec Compliance
- ✅ Rule matches measure_5a.py `_present_5a`: same `_runs(MIN_SEG)[:2]` crossing test, same `aligned_bp(a0, s)` / `aligned_bp(t, a1)` >= MIN_SEG test, same `_solo_tsd` fallback, same `U`/`unanchored` (classify.py:262-278).
- ✅ Order: 5a runs after rule 5 picks P/S/T (`_present_call`, classify.py:281), so S/solo_tsd and T/P are decided first. `_present` is reached only when own_aligned >= MIN_SEG (classify.py:113) and `_present_call` returns only P/S/T, so the prototype's "state in P/S/T" guard is equivalent.
- ✅ Inheritance goes through rule 0 `_inherit` (classify.py:132), unchanged; test shows U + `inherit` on the nested child.
- ✅ No new constant; rule 4g and other rules untouched; docstring (classify.py:19-24) and DESIGN 5.4 and U table row updated.
- ✅ Verified: new tests (7 cases) pass under -W error; ruff clean. Reproduction claim (R1_s1.A__B 5, R1_s2.B__A 7) not rerun; plausible.
- ⚠️ The TSD exception (`_solo_tsd`) does not itself check that the element's image lies between its flanks; it reads TSD bases beside the LTR-end images. This is identical to the frozen prototype, so by spec, but a paralog copy that happens to sit in a TSD-flanked context passes (that is the intended exception).

## Strengths
- Faithful, minimal port; rule isolated in `_anchored` with clear docstring.
- Tests use hand-built AlnMaps, cover unanchored, TSD exception, one-sided anchors (P and T, both sides), and inheritance.

## Issues
### Critical
None.
### Important
None.
### Minor
- classify.py:262-278: for S calls `_solo_tsd` runs twice (in `_present_call` and again in `_anchored` when no run anchors); harmless cost, could cache.
- test_classify.py (inheritance test): asserts only the nested U; no test that a P/S/T element nested in a *present* anchored host is unaffected (low risk).
- Report notes a pre-existing test_cli failure without blastn on PATH; environment, not code.

## Assessment
Task quality: Approved. A faithful port of the frozen rule, correct in rule order and inheritance, with passing tests and clean lint.
