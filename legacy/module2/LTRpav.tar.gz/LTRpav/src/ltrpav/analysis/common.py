"""Helpers shared by the analysis modules: the trio check and the fallback-discovery reasons, each row's first
member, the findings number format, the block jackknife's testability rule (`why`, `guard`), the R+D / S+D
patterns and the jackknife blocks on the donor's sites. Called module-qualified (`common.blocks(...)`), as
several names are common words."""
from __future__ import annotations

import math

import numpy as np

from .catalog import AnalysisError, Catalog
from .constants import JK_MIN_BLOCKS
from .stats import Jk, block_ids


def check_trio(cat: Catalog, labels: tuple[str, ...], who: str) -> None:
    """AnalysisError unless `labels` are distinct ingroup genomes of the run."""
    for x in labels:
        cat.g(x)  # an unknown label raises, naming the run's genomes
    out = [x for x in labels if x in cat.outgroups]
    if out or len(set(labels)) != len(labels):
        raise AnalysisError(f"{who}: {', '.join(labels)} must be distinct ingroup genomes"
                            + (f" ({', '.join(out)}: outgroup)" if out else ""))


def fallback_reasons(excluded: dict[str, str]) -> str:
    return ("; ".join(f"{w}: {why}" for w, why in excluded.items())
            or "no annotated ingroup genome outside the trio")


def first_member(cat: Catalog, disc: tuple[str, ...] | list[str]) -> np.ndarray:
    """gstar, (n,) int16: per row, the first genome of `disc`, in order, that is a member there; else -1."""
    gstar = np.full(len(cat.lid), -1, dtype=np.int16)
    for w in disc:
        g = cat.g(w)
        gstar[(gstar < 0) & cat.member[:, g]] = g
    return gstar


def fmt(v: float, spec: str) -> str:
    """A number for findings.txt; nan as "nan"."""
    return "nan" if math.isnan(v) else format(v, spec)


def guard(jk: Jk, why: str | None) -> tuple[Jk, str | None]:
    """jk with se and z nan, and the reason, when `why` says the jackknife cannot estimate the variance, or
    the estimate is undefined, or the pseudovalues do not vary; the estimate stands. (jk, None) otherwise."""
    if why is None and not math.isfinite(jk.est):
        why = "the estimate is undefined"
    if why is None and not jk.se > 0:
        why = "the block pseudovalues do not vary" if jk.se == 0 else "the jackknife gives no se"
    return (jk, None) if why is None else (Jk(jk.est, math.nan, math.nan, jk.nblocks), why)


def why(classes: dict[str, int], blocks: np.ndarray) -> str | None:
    """Why a delete-one block jackknife cannot estimate the variance of a statistic comparing `classes`
    (name -> informative loci), whose informative loci lie in `blocks` (their block ids): an empty class,
    whose sampling variance never shows among the blocks, or fewer than JK_MIN_BLOCKS distinct blocks. None
    when neither."""
    empty = [name for name, n in classes.items() if not n]
    if empty:
        return "no " + " and no ".join(empty) + " locus"
    nb = len(np.unique(blocks))
    if nb < JK_MIN_BLOCKS:
        return f"its informative loci lie in {nb} block{'' if nb == 1 else 's'}, fewer than {JK_MIN_BLOCKS}"
    return None


def blocks(cat: Catalog, gstar: np.ndarray, D: str, rows: np.ndarray, size: int) -> np.ndarray:
    """Block ids of the selected rows (catalog order): D's site in each row's discoverer call."""
    seq, mid = cat.proj_site(gstar, D)
    seq, mid = seq[rows], mid[rows]
    if (seq < 0).any():  # D is present in every counted row's call, and a present call has a site
        raise ValueError(f"{np.count_nonzero(seq < 0)} counted locus/loci have no site of {D} in their "
                         f"discoverer's call: D must be present at every counted locus")
    return block_ids(seq, mid, size)


def patterns(cat: Catalog, gstar: np.ndarray, R: str, S: str) -> tuple[np.ndarray, np.ndarray]:
    """(n,) masks from gstar's own calls: R present and S E (R+D, when D is present), and the mirror."""
    pr, ps = cat.pcls_by(gstar, R), cat.pcls_by(gstar, S)
    return (pr == 1) & (ps == 0), (ps == 1) & (pr == 0)
