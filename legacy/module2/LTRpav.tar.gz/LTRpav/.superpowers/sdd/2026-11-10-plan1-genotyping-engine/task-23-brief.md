### Task 23: Scoring calls against truth

**Files:** Create `src/ltrpav/sim/score.py`, `tests/test_score.py`

**Interfaces:**
- Produces: `score(calls_path: Path, elements_path: Path, truth_path: Path) -> list[dict]`. Rows carry
  `state`, `tier_set` ("all" or "high"), `tp`, `fp`, `fn`, `precision`, `recall`, plus one summary row with
  `correct_resolved_frac`, which is (call == truth and truth in P/S/T/E) / (truth in P/S/T/E), and
  `unresolved_frac`. Calls join truth through `eid -> Element.name`.

- [ ] **Step 1: Write the failing test.** A tiny table gives known counts, e.g. P precision 2/3 and E recall 1/2.
- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.** Use the csv module.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add simulation scoring"`.

---

