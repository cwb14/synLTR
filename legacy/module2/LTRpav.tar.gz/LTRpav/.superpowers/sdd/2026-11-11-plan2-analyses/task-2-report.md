# Task 2 report
Status: DONE. Commits: d44acf2 (toy carry-over N1-N3), then the stats core commit (see git log).
- Toy: U calls keep wid (no_anchor, no inv); D site is pos-1..pos+b_ins; docstring reasons corrected. tests/test_catalog.py asserted wid "." for U; updated to "2".
- stats.py implements the brief verbatim; 8 brief tests pass; ruff clean (applied ruff's __all__ sort / writelines).
- Choices: jackknife also gives nan se if fewer than 2 finite pseudovalues; read_stats parses value as int, then float, else text; block_size uses smallest genome's summed lengths.
