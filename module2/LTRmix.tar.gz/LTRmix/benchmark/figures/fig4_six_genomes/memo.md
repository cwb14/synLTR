# memo: fig4_six_genomes (LTRmix benchmark, Fig. 4)
date: 2026-11-07
purpose: Fig. 4 — six genomes: positive controls (Inv4m, HPC1, PT > B73), LTR-RT D vs gene-space SNP D, maize–mexicana near-identity, every trio
env: `source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix` (python 3.11, numpy, pandas, matplotlib, edlib, samtools, minimap2)
inputs (read-only):
- results/six/{blocks.tsv, orthologs.<A>.<B>.tsv.gz, <trio>/stats.tsv, <trio>/elements.<R>.tsv, analysis/trio_summary.tsv, analysis/ltr_vs_snp.tsv, analysis/six_findings.txt}
- results/forced/<trio>/stats.tsv; results/main3/benchmark_real.tsv (B73 HPC1 posterior with TIL18 as donor)
- libraries run/{B73v5,TIL01}_LTRs_depth*_clean_ltr.tsv, benchmark/ltrquest_extra/{PT,TIL25}_LTRs_depth*_clean_ltr.tsv
- assemblies inputs/{B73v5,PT,TIL25,TIL01}.fa (+.fai) via samtools faidx; truth/loci.v5.tsv (HPC1)
outputs: fig4_six_genomes.{py,pdf (3 pages: figure, short legend, long legend; fonttype 42),png (300 dpi, 180 x 238 mm)}, fig4_six_genomes_numbers.tsv (346 rows), work/ (pickled caches, HPC1 fasta copies)

## Commands
```
cd /data2/chris/maize_introgression/benchmark/figures/fig4_six_genomes
source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix; export NUMPY_MADVISE_HUGEPAGE=0
python fig4_six_genomes.py -v            # uses work/*.pkl caches
python fig4_six_genomes.py --rebuild     # re-reads every input: 15 s, 0.39 GB RSS
pdftoppm -r 80 -png fig4_six_genomes.pdf /tmp/x; pdffonts fig4_six_genomes.pdf   # inspection
```

## Layout sketches (chose L1)
L1 (chosen) genome first, three scales, then numbers:
```
A  Inv4m: chr4 B73 150-205 Mb, six genomes stacked TIL01|TIL11|B73|PT|TIL25|TIL18, every 1:1 ortholog between
   neighbors a line (near-identical = accent by pair type, older gray), inverted-vs-B73 segments outlined   (full width)
B  HPC1 +-200 kb: TIL01 | B73 | PT | TIL25 centered on each genome's HPC1 copy, every element to size, ortholog
   ribbons by class; TIL25-like posterior of B73 and PT on the same relative axis                          (full width)
C  bp: the one TIL25-shared PT insertion near HPC1 with an empty site in both B73 and TIL01 (TSD, flanks)  (full width)
D LTR D vs SNP D (7 trios) | E near-identity: each genome's 5 partners | F every trio D_kmer +-2 SE by question
```
L2 vertical ideograms like Fig. 1A/5A with D/E/F stacked at right: rejected (D/E/F ~35 mm tall, 23-row forest unreadable).
L3 quantification first (near-identity network + forest as lead): rejected (lead must be genome coordinates, every anchor drawn; networks less exact than points).
Why L1: the controls (B73, TIL11, TIL01) are full partners at the same bp scale, HPC1 goes region -> base pair, and D/E/F each answer one question (calibration, two directions, every trio).
Row order parviglumis | maize | mexicana (as Fig. 1 P | B | M); B73 next to PT so the arrangement switch falls between the two maize lines.

## Data choices and findings made while drawing
- Panel A anchors: orthologs.<A>.<B> (present) for the 5 neighboring pairs, both copies on chr4 inside each genome's window (B73 150-205 Mb mapped through 1:1 orthologs: median partner position of anchors within 1 Mb of each edge); 2,914 lines. Inverted flag = anchor inside a blocks.tsv block of opposite sign to the pair's main orientation; black boxes = B73-relative blocks with >= 20 anchors (= six_findings.txt Inv4m lines).
- Inside Inv4m (each genome's B73-relative inverted segment; B73 published span): PT–TIL25 median divergence 0.15% (n 237, 63% near-identical) vs 1.03% outside; TIL25–TIL18 0.19% (n 163) vs 1.27%; B73–PT 3.03% (n 27) vs 0.12% (n 701); TIL11–B73 0.87% (n 203). New number (not in REPORT): the mexicana Inv4m haplotype is young and shared near-identically by PT, TIL25, TIL18.
- HPC1 placed by minimap2 -x asm20 of B73's gene (chr3:8,497,916-8,499,434) into each genome: PT chr3:9,088,384-9,089,905 (1495/1522), TIL25 8,083,207-8,084,728 (1496/1522), TIL01 8,668,823-8,670,338 (1504/1519). Gene-copy differences (NM): PT–TIL25 5, B73–TIL01 15, B73–TIL25 26, B73–PT 27, TIL01–TIL25 39, PT–TIL01 40.
- Panel B classes/posteriors from trios with TIL25 as donor and TIL01 as sister for both rows (B73v5_TIL01_TIL25, TIL01_PT_TIL25; near threshold 0.096%). PT +-200 kb: 8/27 TIL25-shared, 0 TIL01-only. B73: 9/20 TIL01-only (4 near-identical), 3 TIL25-shared (left of the gene, the same TIL25 copies as PT's). B73 posterior with TIL25 donor: 0.56-0.995 left of HPC1, <= 0.03 rightward; with TIL18 donor <= 0.093 (main3 benchmark_real.tsv).
- CONFLICT with SPEC/REPORT: they say "PT chr3 ~9.04-9.08 Mb ... 1-3 TIL25-shared elements" and "B73 posterior <= 0.09". The 1-3 count came from a PT window mapped through B73 anchors (8.89-9.08 Mb), which stops left of HPC1 because B73's haplotype right of the gene has no PT orthologs; the gene itself sits at 9.088 Mb in PT. The <= 0.09 is the TIL18-donor trio; with TIL25 as donor B73's left flank is TIL25-like (0.97-0.99). Legend reports both.

## Example (panel C): rule and structural checks
rule: PT elements within +-200 kb of HPC1 with class donor_only/near_donor (8); keep those whose 100-bp flanks (left ending with the TSD, right starting with it) align in both B73 and TIL01 (edlib HW, <= 10 edits, same strand) overlapping by exactly 5 bp (= one TSD copy). Result: 1 of 8.
- the other 7: 3 also present in B73 (flanks found with the element between: 11,972 / 14,032 / 26,337 bp gaps), 1 empty in B73 only (nested PT_chr3:9131581-9141878; flanks are Retand sequence), 3 with flanks in neither genome (different haplotype structure right of HPC1).
- chosen: PT_chr3:9154165-9177445#LTR/Gypsy/Retand (23,281 bp incl. nested PT-only SIRE PT_chr3:9164146-9173676, 9,531 bp, K2P 0.0015, TSD CCTGC); ortholog TIL25_chr3:8140746-8154476 (13,731 bp; family merged_fam00003 PT median 13.9 kb).
- TSD ATATT identical at both ends in PT and TIL25 (asserted from sequence); motif tg...ca in both; LTRs 1,392/1,411 bp (PT); K2P 0.0310 (PT) and 0.0314 (TIL25) — consistent; PT–TIL25 copy divergence 0.37% (ortholog table).
- 100-bp flanks: PT vs TIL25 0 + 0 differences; PT vs B73 4 + 2; PT vs TIL01 4 + 2; empty sites B73 chr3:8,564,403-8,564,407, TIL01 chr3:8,790,440-8,790,444 (65 kb and 120 kb right of their HPC1 copies; PT copy 64 kb right).
- uniqueness: each flank has exactly one hit with <= 20 edits within +-1 Mb in B73 and TIL01 (asserted in script).
- typicality: the only element that passes; Inv4m and HPC1 are named loci (SPEC), all anchors/elements drawn, no selection.

## Figure check (figure agent's answers)
1. Panel A shows the biology in genome coordinates, every element drawn: yes — A, all 2,914 anchors between neighbors; B, every LTR-RT of four genomes +-200 kb to size with LTRs.
2. Raw evidence for a typical, structurally verified example: yes — C, base-pair junctions (TSD, LTR ends, flanks) of the PT/TIL25 insertion and the B73/TIL01 empty sites; verified as above (only element passing the rule; stated).
3. Control drawn as a full partner at the same scale: yes — A (B73, TIL11, TIL01 rows, one bp scale), B (B73, TIL01 rows), C (B73, TIL01 empty sites).
4. Every null or chance expectation drawn: yes — D zero lines + 1:1 line; F zero line; E dashed same-subspecies reference per row; B posterior 0-1 axis. A is structural (no null).
5. On-figure text only letters, axis labels, ticks, direct labels, keys and n: yes — keys, row labels with coordinates, HPC1 copy differences (keyed), bp lengths in C.
6. Full-resolution crops: no clipping/collisions found after round 3 (A/B keys moved off the letters, B posterior labels in frame, C TSD columns fixed, D labels with leader lines, E key above axes, F Z column outside); panels on one grid (A/B/C share the row-label column; D/E/F share top and x-axis baseline).
7. Each panel answers a different question; legend pages follow the rules: yes — short legend 256 words (headline + meaning 42 words); long legend 939 words (320 mm, longer than the ~800-word target; six panels with many control numbers), terms first, last line as required.

## Gotchas
- pandas column named `head` shadows DataFrame.head — use T["head"].
- benchmark_real.tsv has NaN in `item`: `.astype(str).str.startswith`.
- Each run's ortholog tables differ slightly from main3's (e.g. TIL01–TIL18 near-identical 1,638 here vs 1,532 in Fig. 2): numbers here are from results/six.
- E shares use pairs with a divergence value as denominator (B73–TIL18 5,941/24,020 = 24.7%; with all present pairs 24.65%; both round to the REPORT's 25%).
