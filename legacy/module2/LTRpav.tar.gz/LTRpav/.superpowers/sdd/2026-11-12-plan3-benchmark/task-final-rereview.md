# Plan 3 final fix wave: re-review (a44f532..256a914)

### Findings
- I1 ADDRESSED: src/ltrpav/sim/pop.py:85-103 (12 entries, each checked against popmodel/popevents/popbuild/poptruth docstrings; accurate, written to params.json); epilog src/ltrpav/sim/cli.py:60-85 (defaults read from Demog()/Rates(), sources, field names, sub_a/sub_c sentence); tests/test_pop_cli.py (NAMED, test_pop_help_epilog) pass.
- M1 ADDRESSED: tests/test_cli_analysis.py:794 carries @needs_lastz.
- M2 ADDRESSED: docs/DESIGN.md:796-798 states the 50 Mb fallback.
- M3 ADDRESSED: pop.py write_pop docstring (~476-478), poptruth.py insertion-table docstring, and the epilog: 0-based, BED-like, anchor before base pos of the backbone or host donor body.
- M4-partial ADDRESSED: grep for the trace phrases in src/ltrpav/sim and tests returns nothing; popbuild.py:377-379 message rewritten (test match="existence" still holds). Protected diff (analysis, constants.py, checkpoint.py) is 0 bytes (verified).

### Checks
- AST comparison of all 40 changed .py files (docstrings blanked): only cli.py, pop.py, popbuild.py (intended code/message changes) and tests/test_cli_analysis.py (the @needs_lastz decorator) and tests/test_pop_cli.py (new tests) differ. The other 35 test files and donors.py/poptruth.py are text-only. Scrub of all test files is acceptable.
- Formatter: _Lines overrides private HelpFormatter._fill_text, the same hook RawDescriptionHelpFormatter overrides; stable since Python 3.2, and the 80-column test would fail loudly if it changed. RawDescriptionHelpFormatter alone would keep breaks but not wrap long lines (epilog lines run ~200 chars), so it would need pre-wrapping at a fixed width. Acceptable; low fragility.
- Focused tests (epilog, writes_outputs) pass.

### New Issues in the Fix Diff
- Critical: none. Important: none.
- Minor: the two extra SIMPLIFICATIONS entries (recombination rule, exponential shape) go beyond the review list but are accurate; fine. pop --help is 88 lines (cosmetic).

### Out-of-Scope Observations
- Workflow traces remain in src/ltrpav/analysis/, plot/overview.py and engine modules (listed in the implementer's report); correctly left for Plan 4 because editing them re-keys views.

### Verdict: Approved
