#!/usr/bin/env python3
"""Truth for the citrus test: Wu B. et al. 2023 Hortic Res (uhac247) Supplementary Table 4, mandarin (M) / pummelo (P)
origin of every DVS segment, written as BED in this benchmark's seqids (CsA_chrN = DVS chrNA, CsB_chrN = chrNB).
Writes truth/CsA.P.bed (pummelo tracts in the mandarin-derived haplotype) and truth/CsB.M.bed (mandarin tracts in the
pummelo-derived haplotype), plus truth/DVS_segments.tsv (all segments) and a length check against the assemblies."""
import sys
import openpyxl

X = "research/dvs_hortres2023_suppl/09282022 Supplementary Tables.xlsx"
ws = openpyxl.load_workbook(X, read_only=True, data_only=True)["Supplementary Table 4"]
seg, cur = [], None
for row in ws.iter_rows(min_row=3, values_only=True):
    c, s, e, o = row[:4]
    if s is None or o not in ("M", "P"):
        continue
    if c:                                  # chromosome ID only on the first row of each block
        cur = c
    hap, n = cur[-1], cur[3:-1]
    seg.append((f"Cs{hap}_chr{n}", int(s) - 1, int(e), o))
lens = {}
for lab in ("CsA", "CsB"):
    with open(f"/data2/chris/maize_introgression/inputs/{lab}.fa") as f:
        name, n = None, 0
        for line in f:
            if line.startswith(">"):
                if name:
                    lens[name] = n
                name, n = line[1:].split()[0], 0
            else:
                n += len(line.strip())
        lens[name] = n
with open("truth/DVS_segments.tsv", "w") as fo:
    fo.write("chrom\tstart0\tend\torigin\n")
    for x in seg:
        fo.write("\t".join(map(str, x)) + "\n")
ends = {}
for c, s, e, o in seg:
    ends[c] = max(ends.get(c, 0), e)
for c in sorted(ends):
    print(f"{c}\ttable end {ends[c]:,}\tassembly {lens.get(c, 0):,}\tdiff {lens.get(c, 0) - ends[c]:+,}")
for lab, want in (("CsA", "P"), ("CsB", "M")):
    with open(f"truth/{lab}.{want}.bed", "w") as fo:
        tot = 0
        for c, s, e, o in seg:
            if c.startswith(lab + "_") and o == want:
                fo.write(f"{c}\t{s}\t{e}\n")
                tot += e - s
    print(f"{lab}: {want} tracts {tot / 1e6:.2f} Mb of {sum(v for k, v in lens.items() if k.startswith(lab)) / 1e6:.1f} Mb")
