### Task 7: Direction, exploratory (DESIGN 7.6)

**Files:**
- Create: `src/ltrpav/analysis/direction.py`, `tests/test_direction.py`

**Interfaces:**
- Consumes: `Catalog` (`pcls_by`, `proj_site`, `cls`), `age_bin`, `jackknife`, `d_ratio`, `block_ids`, `resolution`,
  distances; `Z_SIG`.
- Produces:

```python
DFOIL_ALT = {   # (left, right) patterns: presence in P1 P2 P3 P4, outgroup absent. Pease & Hahn 2015; dfoil.py weights,
                # single-derived (terminal) patterns dropped (DFOIL-alt)
    "DFO": (("1010", "1110", "0101"), ("1001", "1101", "0110")),
    "DIL": (("0110", "1001", "1110"), ("0101", "1010", "1101")),
    "DFI": (("1010", "1011", "0101"), ("0110", "0111", "1001")),
    "DOL": (("0110", "1001", "1011"), ("0101", "0111", "1010")),
}
DFOIL_ALT_SIGNS = {   # DFOIL-alt codes over DFO DIL DFI DOL: infinite-sites expectations without the single-derived
                      # patterns (checked by coalescent simulation). Each directional entry has one branch-length slot:
                      # deep root (Troot - T12 > T12 - t, Troot - T34 > T34 - t) gives the first code, a non-significant
                      # slot the second, the opposite sign one of the two ambiguous classes at the end.
    "+++-": "P1=>P3", "+0+-": "P1=>P3", "---+": "P1=>P4", "-0-+": "P1=>P4",
    "++-+": "P2=>P3", "0+-+": "P2=>P3", "--+-": "P2=>P4", "0-+-": "P2=>P4",
    "+-++": "P3=>P1", "+-+0": "P3=>P1", "-+++": "P4=>P1", "-+0+": "P4=>P1",
    "-+--": "P3=>P2", "-+-0": "P3=>P2", "+---": "P4=>P2", "+-0-": "P4=>P2",
    "++00": "P1+P2<=>P3", "--00": "P1+P2<=>P4",
    "+-+-": "P1<=>P3 or P2<=>P4 (direction unresolved)", "-+-+": "P1<=>P4 or P2<=>P3 (direction unresolved)",
}
PAIR_DISC = {   # each left|right pattern pair: genomes present in both patterns that may discover it, in order of use
    "DFO": {("1010", "1001"): ("P1",), ("1110", "1101"): ("P1", "P2"), ("0101", "0110"): ("P2",)},
    "DIL": {("0110", "0101"): ("P2",), ("1110", "1101"): ("P1", "P2"), ("1001", "1010"): ("P1",)},
    "DFI": {("1010", "0110"): ("P3",), ("1011", "0111"): ("P3", "P4"), ("0101", "1001"): ("P4",)},
    "DOL": {("1001", "0101"): ("P4",), ("1011", "0111"): ("P3", "P4"), ("0110", "1010"): ("P3",)},
}
def taxa(cat: Catalog) -> dict[str, tuple[str, ...]]       # group -> its ingroup genomes, groups with >= 2 genomes
def dfoil_values(counts: dict[str, float]) -> dict[str, float]
    # pattern -> count  ->  DFO DIL DFI DOL = (left - right) / (left + right); nan for 0 / 0
def pair_counts(cat: Catalog, quartet: tuple[str, str, str, str], z: tuple[str, ...]) -> dict[str, dict[str, int]]
    # statistic -> pattern -> count, each pattern counted by its PAIR_DISC rule on the quartet (P1, P2, P3, P4)
def signature(z: dict[str, float]) -> str
    # sign code over DFO DIL DFI DOL: "+" / "-" when |z| >= Z_SIG, else "0" (nan too); the DFOIL_ALT_SIGNS label, else "none"
def direction(cat: Catalog, size: int, dist: np.ndarray) -> tuple[list[StatRow], Findings]
```

The rules are not fixed by the signatures:

```
no outgroup, or fewer than two taxa with >= 2 genomes -> every row skipped, one findings line with the reason
  ("skipped: no outgroup", "skipped: needs two genomes per taxon")
for each pair of taxa X, Y (order of first sheet appearance):
  Z = ingroup genomes outside X and Y ("absent from the sister taxon's genomes")
  n(X->Y), n(Y->X), 4-LIST: merged states, disc=any, with a findings note that three present genomes nearly saturate
    discovery (Plan 3's one-sided dropout runs check it):
    rows = loci resolved in every genome of X, Y, Z and the outgroups, with Z and the outgroups all E
    n(X->Y) = all X present and 1 <= (Y present) <= |Y| - 1;  n(Y->X) the mirror
    D_dir = (n(X->Y) - n(Y->X)) / sum, jackknife on the first X+Y genome's merged coordinates; strata "all" and the age
      bins of the median member K; rows test "direction", scope "X>Y", statistics D_dir, n_XY, n_YX
    resolution(...) rows: each genome of X, Y, Z and the outgroups, resolved fraction among loci present in some X or Y
  each quartet (two genomes of X, two of Y): (P1, P2) = the pair with the smaller PAV distance (DFOIL needs the more
    recent split there)
    pair_counts: per left|right pattern pair (PAIR_DISC), gstar = the first listed genome that is a member at the row;
      the pair's patterns are read from gstar's own calls on rows where gstar's calls resolve all four quartet genomes,
      Z and the outgroups, with Z and the outgroups E
    each DFOIL-alt statistic: left - right summed over its three pairs, / their sum; jackknife on P1's coordinates as
      each row's gstar reads them (proj_site)
    rows "dfoil", scope "P1,P2;P3,P4": statistics DFO DIL DFI DOL (value, se, z) and "signature" (signature()); then
      resolution(...) rows for the four quartet genomes in the gstar calls; then the ten 4-LIST pattern counts (two or
      three of the four present; merged states) as rows "four_list", statistic = the pattern
every row's note: "exploratory: kept only if simulations with known direction recover it (DESIGN 7.6, 10.2)";
  D_dir rows add: "not read as direction: unequal Ne alone drives it (no gene flow: +0.93 at Ne 1000 vs 5000), and drift
  in a small recipient fixes transferred insertions. DFOIL-alt is the direction statistic."
```

- [ ] **Step 1: Write the failing tests**

```python
QUARTET = [("x1", "X", None, True), ("x2", "X", None, True), ("y1", "Y", None, True), ("y2", "Y", None, True)]
OUT = ("O", "OG", "outgroup", False)

def spec(p: str, member: int | None = None) -> str:
    """'x1:P* x2:E y1:P y2:E O:E' from presence pattern p over x1 x2 y1 y2; member = index (default: the first present)."""
    m = p.index("1") if member is None else member
    return " ".join(f"{g}:{'P' if c == '1' else 'E'}{'*' if j == m else ''}"
                    for j, (g, c) in enumerate(zip(("x1", "x2", "y1", "y2"), p))) + " O:E"

def test_counts(tmp_path, toy_fastas):
    genomes = [*QUARTET, ("z", "Z", None, True), OUT]
    loci = ([loc(1000 * i, "x1:P* x2:P y1:P y2:E z:E O:E") for i in range(1, 4)]     # X->Y x3
            + [loc(5000, "x1:P* x2:E y1:P y2:P z:E O:E")]                              # Y->X x1
            + [loc(6000, "x1:P* x2:P y1:P y2:E z:P O:E"), loc(7000, "x1:P* x2:P y1:P y2:E z:E O:U")])   # not counted
    cat = write_run(tmp_path, loci, genomes=genomes, fasta_dir=toy_fastas).load()
    rows, f = direction(cat, block_size(cat), pav_distances(cat)[0])
    got = {r.statistic: r.value for r in rows if r.test == "direction" and r.stratum == "all"}
    assert (got["n_XY"], got["n_YX"], got["D_dir"]) == (3, 1, 0.5) and all("exploratory" in r.note for r in rows)

def test_dfoil_alt_values():
    v = dfoil_values({"1010": 4, "1001": 1})
    assert [round(v[k], 3) for k in ("DFO", "DIL", "DFI", "DOL")] == [0.6, -0.6, 0.6, -0.6]
    assert math.isnan(dfoil_values({"1110": 1})["DFI"])

def test_dfoil_signature():
    assert signature({"DFO": 4, "DIL": 5, "DFI": 3.5, "DOL": -4}) == "P1=>P3"
    assert signature({"DFO": 4, "DIL": 5, "DFI": 3.5, "DOL": 0.2}) == "none"    # full-DFOIL P1=>P3 is no alt code
    assert signature({"DFO": 4, "DIL": -5, "DFI": 3.5, "DOL": -4}).startswith("P1<=>P3 or P2<=>P4")

# expected DFOIL-alt pattern counts by the branch-length rule: on ((P1,P2),(P3,P4)),O with T12 = 2, T34 = 4, Troot = 8,
# each branch adds its length to the pattern of the leaves below it; with f = 0.1 the recipient's lineage follows the
# donor's from t = 1 (ancestral scenarios: the P1+P2 ancestor's, from t = 3). The species tree holds none of these
# patterns, so each count is f times its branch length in the migrant genealogy.
BRANCH_COUNTS = {
    "P1=>P3": {"1010": 0.1, "1110": 0.6}, "P1=>P4": {"1001": 0.1, "1101": 0.6},
    "P2=>P3": {"0110": 0.1, "1110": 0.6}, "P2=>P4": {"0101": 0.1, "1101": 0.6},
    "P3=>P1": {"1010": 0.3, "1011": 0.4}, "P4=>P1": {"1001": 0.3, "1011": 0.4},
    "P3=>P2": {"0110": 0.3, "0111": 0.4}, "P4=>P2": {"0101": 0.3, "0111": 0.4},
    "P1+P2<=>P3": {"1110": 0.5}, "P1+P2<=>P4": {"1101": 0.5}}

def test_dfoil_alt_signatures_from_branch_lengths():
    for scenario, counts in BRANCH_COUNTS.items():
        assert signature({k: 1000 * x for k, x in dfoil_values(counts).items()}) == scenario

def test_pair_discovery(tmp_path, toy_fastas):
    loci = [loc(1000, spec("1010", member=2)),      # 1010 discovered only by P3 (y1)
            loc(2000, spec("1010", member=0)),      # 1010 discovered by P1 (x1)
            loc(3000, spec("1110", member=1))]      # 1110 with P1 not a member: read from P2's (x2) calls
    cat = write_run(tmp_path, loci, genomes=[*QUARTET, OUT], fasta_dir=toy_fastas).load()
    pc = pair_counts(cat, ("x1", "x2", "y1", "y2"), ())
    assert pc["DFO"].get("1010", 0) == 1 and pc["DFO"].get("1110", 0) == 1 and pc["DFI"].get("1010", 0) == 1

def test_four_list_counts(tmp_path, toy_fastas):
    pats = ["1100", "1010", "1001", "0110", "0101", "0011", "1110", "1101", "1011", "0111"]
    loci = ([loc(20_000 * i + 1000 * (k + 1), spec(p)) for i, p in enumerate(pats) for k in range(i + 1)]
            + [loc(900_000, spec("1000"))])
    cat = write_run(tmp_path, loci, genomes=[*QUARTET, OUT], fasta_dir=toy_fastas).load()
    rows, _ = direction(cat, block_size(cat), dmat({("x1", "x2"): 0.05}, 0.5, cat.labels))
    assert {r.statistic: r.value for r in rows if r.test == "four_list"} == {p: i + 1 for i, p in enumerate(pats)}

def test_skips(tmp_path, toy_fastas):
    cat = write_run(tmp_path / "a", [loc(1000, spec("1100"))], genomes=QUARTET, fasta_dir=toy_fastas).load()
    rows, f = direction(cat, block_size(cat), pav_distances(cat)[0])
    assert rows == [] and any("skipped: no outgroup" in t for _, t in f.items())
    cat = write_run(tmp_path / "b", [loc(1000, "R:P* S:P D:E O:E")], fasta_dir=toy_fastas).load()
    rows, f = direction(cat, block_size(cat), pav_distances(cat)[0])
    assert rows == [] and any("skipped: needs two genomes per taxon" in t for _, t in f.items())

def test_p1p2_by_distance(tmp_path, toy_fastas):
    cat = write_run(tmp_path, [loc(1000, spec("1010")), loc(2000, spec("0101"))], genomes=[*QUARTET, OUT],
                    fasta_dir=toy_fastas).load()
    scope = lambda d: {r.scope for r in direction(cat, block_size(cat), d)[0] if r.test == "dfoil"}
    assert scope(dmat({("x1", "x2"): 0.05, ("y1", "y2"): 0.2}, 0.5, cat.labels)) == {"x1,x2;y1,y2"}
    assert scope(dmat({("x1", "x2"): 0.3, ("y1", "y2"): 0.05}, 0.5, cat.labels)) == {"y1,y2;x1,x2"}
```

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_direction.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** the tests. Expected: PASS.
- [ ] **Step 5: Commit.** `"Add exploratory direction tests: n(X->Y), DFOIL-alt, 4-LIST counts"`
---

