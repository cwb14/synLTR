### Task 1: Repository scaffold and environment

**Files:**
- Create: `LTRpav/pyproject.toml`, `LTRpav/environment.yml`, `LTRpav/LICENSE`, `LTRpav/README.md`,
  `LTRpav/.gitignore`, `LTRpav/.github/workflows/ci.yml`, `LTRpav/src/ltrpav/__init__.py`,
  `LTRpav/src/ltrpav/constants.py`, `LTRpav/tests/test_smoke.py`
- Modify: `LTRpav/docs/DESIGN.md` (section 12: add "Build decisions (plan 1)" with the six builder calls above)

**Interfaces:**
- Produces: `ltrpav.__version__ = "0.1.0.dev0"`; `ltrpav.constants` with exactly these names and values:

```python
TSD_DEFAULT = 5            # most LTR-RTs make 4-6-bp TSDs; 5 bp is the common case
SLOP_TSD_MULT = 2          # E needs the gap within ~2 TSD lengths of the element ends (DESIGN 5.4)
COV_PRESENT = 0.8          # Wicker et al. 2007 80-80-80 rule: >=80% of a part aligned = present
SOLO_LEN = (0.8, 1.2)      # a solo-LTR is one LTR's worth of aligned sequence, same 80% rule
MIN_SEG = 80               # Wicker's 80-bp minimum: less aligned sequence counts as none
IDENT_MIN = 0.8            # flank identity below the 80% rule: site placement not trusted
MARGIN_HIGH = 0.5          # orthologous chain outscores any competitor 2:1
ANCHOR_MIN = 100           # FastGA's default minimum alignment length; shorter anchors not trusted
WINDOW_PAD = 500           # anchored sequence kept at each window end so the local aligner can seed
WINDOW_CAP = 500_000       # runtime guard on window span (A and B); bake-off reports its cost
CHAIN_MAX_GAP = 1_000_000  # no chaining across >1 Mb without alignment
CHAIN_INDEL_COST = 0.05    # per bp of diagonal shift: a 30-kb insertion is bridged by >=1.5 kb of alignment
CHAIN_OVERLAP = 100        # tolerated overlap of consecutive blocks (chunk and seed edges)
CHAIN_LOOKBACK = 200       # predecessors examined per block in the chaining DP
MIN_CHAIN_SCORE = 1000     # a chain must carry >=1 kb of aligned sequence
REFINE_PAD = 150           # junction refinement half-width; covers local-aligner end error
SCORE = (1, 4, 6, 2)       # match, mismatch, gap open, gap extend: minimap2 asm20 short-gap scoring
MM2_CHUNK = 100_000        # query chunk for in-process whole-genome mapping; bounds memory
MM2_OVERLAP = 10_000       # chunk overlap so no alignment is lost at a chunk edge
FLANK_TARGET = 2000        # unique flank bases collected per side (DESIGN 5.1: >=1-2 kb)
FLANK_CAP = 10_000         # farthest a flank may reach (bake-off varies 2/5/10/20 kb)
FLANK_PIECE_MIN = 200      # shorter flank pieces seed poorly and multi-map
CHUNK_WINDOWS = 2000       # windows per worker task: bounds memory, sets resume granularity
DEFAULT_ROUTE = "mm2"      # provisional; Task 24 sets it from the bake-off
```

- [ ] **Step 1: Create the repo and branch.** `cd /data2/chris/maize_introgression/LTRpav && git init && git checkout -b plan1-engine`.
  Check `git config user.name` prints the user's name (global config exists); never pass `--author` or `-c user.*`.
- [ ] **Step 2: Write `tests/test_smoke.py`**

```python
import os

def test_import_sets_thp_guard_and_version():
    import ltrpav
    assert ltrpav.__version__ == "0.1.0.dev0"
    assert os.environ["NUMPY_MADVISE_HUGEPAGE"] == "0"

def test_constants_are_numbers():
    from ltrpav import constants as c
    assert c.SLOP_TSD_MULT * c.TSD_DEFAULT == 10
    assert 0 < c.COV_PRESENT < 1 and c.SOLO_LEN == (0.8, 1.2) and c.DEFAULT_ROUTE == "mm2"
```

- [ ] **Step 3: Write `pyproject.toml`.** Model it on `code/LTRquest/pyproject.toml`: hatchling, `[tool.hatch.version] path = "src/ltrpav/__init__.py"`,
  `requires-python = ">=3.10"`, license `GPL-3.0-or-later`, the author above, dependencies `numpy>=1.26`, `numba>=0.60`,
  `pysam>=0.22`, `mappy>=2.28`; extra `dev = ["pytest>=8", "ruff>=0.5"]`; scripts `ltrpav = "ltrpav.cli:main"`,
  `ltrpav-anchor = "ltrpav.cli:anchor_main"`, `ltrpav-genotype = "ltrpav.cli:genotype_main"`,
  `ltrpav-merge = "ltrpav.cli:merge_main"`, `ltrpav-sim = "ltrpav.sim.cli:main"`; pytest marker `slow` (real data or
  long runs); ruff `line-length = 110`, `target-version = "py310"`. URLs: `https://github.com/cwb14/LTRpav`.
- [ ] **Step 4: Write `environment.yml`** (name `ltrpav`; channels conda-forge, bioconda): `python=3.12`, `numpy`,
  `numba=0.68.1`, `pysam`, `mappy=2.31`, `minimap2=2.31`, `fastga=1.5.20260729`, `blast=2.17.0`, `lastz=1.04.60`,
  `bcftools=1.25`, `htslib`, `pytest`, `ruff`, `hatchling`, `pip`, and pip `-e .`. Then run
  `mamba env create -f environment.yml && mamba env export -n ltrpav > environment.lock.yml`.
- [ ] **Step 5: Write `src/ltrpav/__init__.py`** (THP guard first, then `__version__`) and `constants.py` (module
  docstring "Fixed internal constants; each has a one-line reason. Nothing here is tuned to a dataset." + the block above).
- [ ] **Step 6: Write the rest.** LICENSE (copy `code/LTRquest/LICENSE`); README stub (one paragraph, "under development").
  `.gitignore`: `__pycache__/ *.egg-info/ .pytest_cache/ .ruff_cache/ docs/plans/ /out/`. Plans stay unpublished.
  CI: copy the `code/LTRquest/.github/workflows/ci.yml` structure, matrix `["3.10", "3.12", "3.13"]`, test command
  `pytest -m "not slow" -q`, lint job `ruff check --output-format github .` (drop shellcheck).
  Finally add the DESIGN.md section 12 subsection.
- [ ] **Step 7: Verify.** `mamba run -n ltrpav pytest -q && mamba run -n ltrpav ruff check .`. Expected: 2 passed, ruff clean.
- [ ] **Step 8: Commit.** `git add -A && git commit -m "Scaffold package, environment and CI"`

---

