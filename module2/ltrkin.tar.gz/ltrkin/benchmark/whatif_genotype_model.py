#!/usr/bin/env python3
"""What-if rescoring of `ltrkin genotype` runs with two model changes, using ltrkin's own likelihood (ltrkin.model)
on the per-site counts of each run. Evidence for proposals in docs/benchmark_genotype_sim.md; ltrkin is not modified.

  asis      ltrkin's model recomputed from the TSV counts (must reproduce the run's calls: sanity check)
  solo_iv   a read whose length change lies between the two single-LTR solo expectations, -(L - LTR5) and
            -(L - LTR3) (+- ltrkin's tau), counts as solo, not other. From the TSV only the median of a site's
            'other' reads is known: all its other reads move to S when that median lies in the interval
  prior_N   genotype prior pi^#N (1 - pi)^(ploidy - #N) instead of flat, pi = 0.05 and 0.01 per haplotype
            (fixed levels for a sensitivity range, not tuned)
  depth_mean  per-haplotype depth = half the mean MAPQ >= 20 depth measured independently at 2,000 region points
            (eval/depth_check.tsv) instead of ltrkin's 400-point mode: sensitivity of the calls to the depth estimate
Usage: whatif_genotype_model.py -d BENCHDIR -o out.tsv
"""
import argparse
import glob
import math
import os
import re
import sys

import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))   # this repository's ltrkin
from ltrkin.constants import ANCHOR, TAU_ABS, TAU_REL, GQ_CAP  # noqa: E402
from ltrkin.model import genotypes, loglik  # noqa: E402

ALLOWED = {"F/F": {"F/F"}, "F/E": {"F/E"}, "F/S": {"F/S"}, "F/N": {"F/N"}, "F/N|F/F": {"F/N", "F/F"}}


class M:
    def __init__(self, d_hap, k, ploidy=2):
        self.d_hap, self.k, self.ploidy = d_hap, k, ploidy


def call(counts, rates, model, eps, pi=None):
    gts = genotypes(model.ploidy)
    lls = {}
    for g in gts:
        ll = loglik(counts, g, rates, model.d_hap, eps, model.k)
        if pi is not None:
            n = g.split("/").count("N")
            ll += n * math.log(pi) + (model.ploidy - n) * math.log(1 - pi)
        lls[g] = ll
    mx = max(lls.values())
    post = {g: math.exp(v - mx) for g, v in lls.items()}
    z = sum(post.values())
    best = max(post, key=post.get)
    pb = post[best] / z
    gq = GQ_CAP if pb >= 1 - 10 ** (-GQ_CAP / 10) else int(round(-10 * math.log10(1 - pb)))
    return best, min(gq, GQ_CAP)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-d", "--dir", required=True)
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    truth = pd.read_csv(os.path.join(a.dir, "truth", "truth.tsv"), sep="\t", dtype={"truth": str})
    pl = truth[truth.category == "planted"][["element_id", "truth", "state"]]
    dc = pd.read_csv(os.path.join(a.dir, "eval", "depth_check.tsv"), sep="\t")
    true_dhap = {f"{r.tech}_d{r.depth}": r.region_mean_q20 / 2 for r in dc.itertuples()}
    rows, per_site = [], []
    for p in sorted(glob.glob(os.path.join(a.dir, "ltrkin", "*.genotypes.tsv"))):
        run = os.path.basename(p)[: -len(".genotypes.tsv")]
        par = None
        for ln in open(p[: -len(".genotypes.tsv")] + ".log"):
            m = re.search(r"per haplotype ([\d.]+)\), NB size (\d+), .* error ([\d.]+)", ln)
            if m:
                par = (float(m.group(1)), float(m.group(2)), float(m.group(3)))
        g = pd.read_csv(p, sep="\t").merge(pl, on="element_id")
        d_hap, k, eps = par
        mod = M(d_hap, k)
        mod_true = M(true_dhap.get(run.split(".")[0], d_hap), k)
        res = {}
        for _, r in g.iterrows():
            counts = {"F": r.n_F, "S": r.n_S, "E": r.n_E}
            rates = {"F": r.r_F, "S": r.r_S, "E": r.r_E}
            L = r.length
            lo_s = -(L - min(r.ltr5_len, r.ltr3_len))
            hi_s = -(L - max(r.ltr5_len, r.ltr3_len))
            tau = max(TAU_ABS, TAU_REL * ((r.ltr5_len + r.ltr3_len) / 2 + 2 * ANCHOR))
            c2 = dict(counts)
            if r.n_O > 0 and r.other_delta_median != "." and lo_s - tau <= float(r.other_delta_median) <= hi_s + tau:
                c2["S"] += r.n_O
            variants = {"asis": call(counts, rates, mod, eps), "solo_iv": call(c2, rates, mod, eps),
                        "prior_N_0.05": call(counts, rates, mod, eps, 0.05),
                        "prior_N_0.01": call(counts, rates, mod, eps, 0.01),
                        "solo_iv+prior_N_0.01": call(c2, rates, mod, eps, 0.01),
                        "depth_mean": call(counts, rates, mod_true, eps)}
            for v, (gt, gq) in variants.items():
                res.setdefault(v, []).append((r.element_id, r.truth, gt, gq, r.genotype, int(r.gq)))
        for v, lst in res.items():
            df = pd.DataFrame(lst, columns=["element_id", "truth", "call", "gq", "ltrkin_call", "ltrkin_gq"])
            df["correct"] = [c in ALLOWED[t] for c, t in zip(df.call, df.truth)]
            df["c20"] = (df.gq >= 20) & (df.call != "N/N")
            fn = df[df.call == "F/N"]
            rows.append(dict(run=run, variant=v, n=len(df), reproduces_ltrkin=(df.call == df.ltrkin_call).mean(),
                             conc_all=df.correct.mean(), conc_gq20=df[df.c20].correct.mean(),
                             call_rate_gq20=df.c20.mean(),
                             recall_FF=df[df.truth == "F/F"].correct.mean(),
                             recall_FS=df[df.truth == "F/S"].correct.mean(),
                             recall_FN=df[df.truth == "F/N"].correct.mean(),
                             precision_FN=fn.correct.mean() if len(fn) else float("nan")))
            df.insert(0, "variant", v)
            df.insert(0, "run", run)
            per_site.append(df)
    out = pd.DataFrame(rows)
    out.to_csv(a.out, sep="\t", index=False, float_format="%.3f")
    pd.concat(per_site).to_csv(a.out.replace(".tsv", "") + ".sites.tsv", sep="\t", index=False)
    print(out.to_string(index=False, float_format=lambda x: f"{x:.3f}"))


if __name__ == "__main__":
    main()
