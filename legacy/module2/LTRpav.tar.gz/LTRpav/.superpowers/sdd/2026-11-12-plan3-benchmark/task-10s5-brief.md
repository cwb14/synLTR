# Task 10 Step 5: the grid and LTRquest memo

Plan 3's simulation grid (144 runs) and its three LTRquest-annotated runs have finished. Append a Task 10 section to
`/data2/chris/maize_introgression/benchmark_pav/plan3/sim/memo.md` in that file's existing style: terse key: value
lines and fenced command blocks, facts only. Nothing else is written except your scratch directory and your report.

## Record
- **Dates.** Grid launch 2026-11-13 04:12:16 (runner 1, `run_grid.sh grid.tsv --windows 5`, PID 4159239). The
  2026-11-14 speed-up, when the user allowed more threads:
  - runner 2, `run_grid.sh grid_rev.tsv --windows 5`, PID 765312, from 08:15:51 (the 46 rows not started then, in
    reverse);
  - LTRquest beside the grid, `lq/run_lq.sh --ignore-grid`, from 08:18:23;
  - after_grid2.sh's final pass.

  Give the end time of each, and grid.tsv.done's time.
- **Snapshot:** 4f3973e (`benchmark_pav/plan3/snap/4f3973e`).
- **Commands:** the exact launch lines (see `grid.log`, `grid_rev.log`, `lq/run_lq.log`, `after_grid.log`,
  `after_grid2.log`, and the ledger `progress.md` entries dated 2026-11-14 in this directory).
- **Per-kind wall times against the estimates.**
  - From each run's `run.log` (step lines: "<step>: done in N s"), tabulate per kind (null, power, reverse, ptlike,
    bneck, posctl, nodonor, dropout, and 7-genome against trio) the median and range of each step and of the whole run.
  - Estimates (plan, Compute budget): a 7-genome run ~68 min at 16 threads at 100 Mb; trio ~26 min. The 50-Mb pilot
    measured h7 0.673 h and h_trio 0.320 h (gate_50Mb.tsv). Compare against both.
  - Also give the grid's total wall time and its peak summed PSS (`grid.tsv.mem.tsv`, `grid_rev.tsv.mem.tsv`).
- **Failures and collisions.** Rows in grid.tsv.failed or grid_rev.tsv.failed, before and after the final pass.
  Count the "in use by another run_one.sh" lock collisions between the two runners (expected and harmless) and say
  each was finished by the other runner. Name any real failure with its log line.
- **LTRquest.** Commit 5042a1e (env ltrquest_5042a1e). For each of the three runs:
  - LTRquest wall time and max RSS (`lq/<name>/ltrquest.time`);
  - thread peaks and the share of samples above 32 running (`threads.tsv`, `threads_peak.txt`);
  - the record check output (`lq.done`);
  - the downstream steps' times.

  Also give the defect found at the first launch: env ltrpav's python3 stayed first on PATH after conda activate, so
  TEsorter2's check failed. Record the fix in `in_lq_env` and the first attempt's files kept in
  `lq/null_s101/attempt1_pathbug/`.
- **Gotchas:** one line each. The two runners and their lock collisions; run_lq.sh's PATH fix; the scoring-script
  sha256s that changed mid-grid (the 2026-11-14 entry above yours) and the full rescore that unified them.
- **The resume name:** `claude --resume` for this session. Ask the controller if you cannot find it, or leave the
  placeholder `<session name>`.

Read-only everywhere else: never write in `runs/` or `lq/`, never edit any script, and never kill a process. At most 4
threads and 15 minutes per probe. American English; no AI attribution.
