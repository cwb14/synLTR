"""VCF of the locus catalog, bgzipped and tabix-indexed, with haploid genotypes; the reference genome's
coordinates. An insertion is anchored VCF-style on the base before it: a locus present in the reference genome
(P, S, T) has POS = start - 1; one empty there (E) has POS = the last base of the target-site copy, or, for an
E site without a readable TSD copy (its site is then the flank junction), the junction's last base: the
insertion point to within 1 bp (the header's LTRpav_POS line says so). REF is the reference
base at POS, ALT <INS:ME:LTR>, END = POS, SVLEN the locus length. GT: 1 present, 0 absent (E), missing for D,
O, G, U. INFO strings with ; , = whitespace or % are percent-encoded. Loci the VCF cannot hold go to a side
file (lid, ref_state, reason)."""
from __future__ import annotations

import statistics
from pathlib import Path

import pysam

from ..loci import Locus
from ..samples import Sample
from ..seqio import Fasta

_PRESENT = frozenset("PST")
# the header's description of POS (##LTRpav_POS): where each site is anchored, the E site's too
POS_NOTE = ("POS is the base before the insertion: start - 1 where the reference genome holds the element (ST P, "
            "S or T); at its empty site (ST E), the last base of the target-site (TSD) copy, or, without a "
            "readable TSD copy, the flank junction, to within 1 bp (within the few extra bases, at most two TSD "
            "lengths, the reference may hold there)")
_ESC = {";": "%3B", ",": "%2C", "=": "%3D", " ": "%20", "\t": "%09", "\n": "%0A", "\r": "%0D"}


def _esc(s: str) -> str:
    return s.replace("%", "%25").translate(str.maketrans(_ESC))


def _header(samples: list[Sample], fasta: Fasta) -> pysam.VariantHeader:
    h = pysam.VariantHeader()
    h.add_meta("fileformat", "VCFv4.2")
    h.add_meta("source", "LTRpav")
    h.add_meta("LTRpav_POS", POS_NOTE)
    for seqid, n in fasta.lengths().items():
        h.contigs.add(seqid, length=n)
    h.add_meta("ALT", items=[("ID", "INS:ME:LTR"), ("Description", "LTR retrotransposon insertion")])
    for name, num, typ, desc in (
            ("SVTYPE", 1, "String", "Structural variant type"),
            ("SVLEN", 1, "Integer", "Length of the LTR retrotransposon"),
            ("END", 1, "Integer", "End position (equal to POS)"),
            ("FAM", 1, "String", "Family"),
            ("SF", 1, "String", "Superfamily"),
            ("K", 1, "Float", "Median K2P divergence of the member elements' LTRs"),
            ("DISC", ".", "String", "Genomes whose annotation holds the insertion"),
            ("NE", 1, "Integer", "Genomes with the empty site (state E)"),
            ("AA", 1, "String", "Ancestral allele: the reference base, given when an empty site is observed")):
        h.info.add(name, num, typ, desc)
    h.formats.add("GT", 1, "String", "Genotype: 1 present, 0 absent, . missing")
    h.formats.add("ST", 1, "String", "Call state (P S T E D O G U)")
    h.formats.add("TR", 1, "String", "Call tier")
    for s in samples:
        h.add_sample(s.label)
    return h


def write_vcf(loci: list[Locus], samples: list[Sample], ref_label: str, fasta: Fasta,
              path: Path) -> tuple[Path, Path]:
    """Write `path` (.vcf.gz) and its .tbi, from the loci in the coordinates of genome `ref_label` (`fasta`).
    Returns (vcf.gz path, unplaced TSV path: <stem>.unplaced.tsv next to it)."""
    path = Path(path)
    if path.suffix != ".gz":
        raise ValueError(f"VCF path must end in .gz: {path}")
    plain = path.with_suffix("")
    unplaced = path.with_name(path.name.removesuffix(".vcf.gz").removesuffix(".gz") + ".unplaced.tsv")
    order = {sid: i for i, sid in enumerate(fasta.lengths())}
    labels = [s.label for s in samples]
    header = _header(samples, fasta)

    keep, skipped = [], []
    for loc in loci:
        st = loc.states[ref_label]
        if st.state not in _PRESENT and st.state != "E":
            reason = "ref_state_not_placeable"
        elif st.seqid is None or st.start is None or st.end is None:
            reason = "no_coordinates"
        elif st.seqid not in order:
            reason = "seqid_not_in_reference"
        else:
            pos = st.start - 1 if st.state in _PRESENT else st.end
            if pos < 1:
                skipped.append((loc.lid, st.state, "starts_at_base_1"))
            else:
                keep.append((order[st.seqid], pos, loc.lid, st.seqid, loc))
            continue
        skipped.append((loc.lid, st.state, reason))
    keep.sort(key=lambda t: t[:3])

    with pysam.VariantFile(str(plain), "w", header=header) as out:
        for _, pos, _, seqid, loc in keep:
            ref = fasta.fetch(seqid, pos - 1, pos)
            ne = sum(loc.states[g].state == "E" for g in labels)
            ks = [loc.states[g].k for g in loc.members if g in loc.states and loc.states[g].k is not None]
            rec = header.new_record(contig=seqid, start=pos - 1, stop=pos, alleles=(ref, "<INS:ME:LTR>"),
                                    id=loc.lid)
            rec.info["SVTYPE"] = "INS"
            rec.info["SVLEN"] = int(loc.length)
            if loc.family is not None:
                rec.info["FAM"] = _esc(loc.family)
            if loc.superfamily is not None:
                rec.info["SF"] = _esc(loc.superfamily)
            if ks:
                rec.info["K"] = float(statistics.median(ks))
            if loc.discovery:
                rec.info["DISC"] = tuple(_esc(g) for g in loc.discovery)
            rec.info["NE"] = ne
            if ne:
                rec.info["AA"] = ref
            for g in labels:
                st = loc.states[g]
                call = rec.samples[g]
                call["GT"] = (1,) if st.state in _PRESENT else (0,) if st.state == "E" else (None,)
                call.phased = False
                call["ST"] = st.state
                call["TR"] = st.tier
            out.write(rec)
    pysam.tabix_index(str(plain), preset="vcf", force=True)

    with open(unplaced, "w", encoding="utf-8", newline="") as fh:
        fh.write("lid\tref_state\treason\n")
        fh.writelines(f"{lid}\t{state}\t{reason}\n" for lid, state, reason in skipped)
    return path, unplaced
