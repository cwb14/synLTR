### Task 2: Statistics core — rows, blocks, jackknife, u95, resolution, findings

**Files:**
- Create: `src/ltrpav/analysis/stats.py`, `tests/test_stats_core.py`

**Interfaces:**
- Consumes: `Catalog`; the analysis constants `BLOCK_BP`, `BLOCK_FRAC`, `BLOCK_MIN`, `RESOLVE_WARN`;
  `scipy.stats.chi2` (imported inside `u95`).
- Produces:

```python
STATS_COLUMNS = ("layer", "test", "scope", "stratum", "statistic", "value", "se", "z", "n", "loci", "note")
@dataclass
class StatRow:
    layer: str; test: str; scope: str; stratum: str; statistic: str
    value: float | int | str; se: float = math.nan; z: float = math.nan; n: int | None = None
    loci: str = "."; note: str = "."
@dataclass(frozen=True)
class Jk:
    est: float; se: float; z: float; nblocks: int
def block_size(cat: Catalog) -> int          # min(BLOCK_BP, max(smallest genome total // BLOCK_FRAC, BLOCK_MIN))
def block_ids(seq: np.ndarray, mid: np.ndarray, size: int) -> np.ndarray   # int64 (seq << 32) | (mid // size); seq >= 0
def jackknife(stat: Callable[[np.ndarray], float], blocks: np.ndarray) -> Jk
def d_ratio(a: np.ndarray, b: np.ndarray) -> Callable[[np.ndarray], float]   # keep -> (Σa - Σb) / (Σa + Σb), nan if 0
def u95(d: np.ndarray, n: np.ndarray) -> np.ndarray   # chi2.ppf(0.95, 2(d + 1)) / 2 / n: one-sided 95% Poisson bound
def resolution(test: str, scope: str, fracs: dict[str, float], n: int, loci: str, findings: Findings,
               section: str) -> list[StatRow]
    # one row "resolved_<genome>" per entry (layer "pav", stratum "all"); a WARNING when max - min > RESOLVE_WARN
    # (named a heuristic in its text); the caller sets layer or note when it needs another
def write_stats(rows: list[StatRow], path: Path) -> None   # header row STATS_COLUMNS only; tsv_field values; nan -> "."
def read_stats(path: Path) -> list[StatRow]
SECTIONS = ("Run", "Relationships", "Trio tests", "Painting", "Dating", "Direction (exploratory)", "Inversions",
            "Mechanisms", "Sequence-identity layer (outside the PAV-only core)")
class Findings:
    def add(self, section: str, text: str) -> None
    def warn(self, section: str, text: str) -> None    # stores "WARNING: " + text
    def extend(self, other: Findings) -> None
    def items(self) -> list[tuple[str, str]]           # (section, line), insertion order
```

`u95` and `resolution` are written once here. Tasks 3, 4, 6, 7 and 9 import them; nobody re-derives the formula or the
warning.

The callers pass `block_ids` the coordinates their rule names, e.g. D's site in each row's discoverer call
(`cat.proj_site`).

`jackknife` ports LTRmix `jackknife` (l. 893) for any statistic:
- `est = stat(all rows)`;
- one pseudovalue `stat(blocks != b)` per distinct block, non-finite ones dropped;
- `se = sqrt((m'-1)/m' * Σ(p - mean)²)` over the m' finite pseudovalues;
- `se` and `z` are nan with fewer than 3 blocks, counted as distinct blocks among the rows before non-finite
  pseudovalues are dropped (LTRmix);
- `z = est / se` when `se > 0`.

This is the unweighted delete-one form, kept for comparability with LTRmix. Busing's weighted form, standard for unequal
blocks, is a candidate for Plan 3's stability checks.

- [ ] **Step 1: Write the failing tests**

```python
def test_jackknife_matches_leave_one_out():
    rng = np.random.default_rng(0)
    a = rng.integers(0, 2, 200); b = 1 - a; blocks = rng.integers(0, 20, 200)
    jk = jackknife(d_ratio(a, b), blocks)
    loo = np.array([(a[blocks != x].sum() - b[blocks != x].sum()) / (blocks != x).sum() for x in range(20)])
    assert jk.est == pytest.approx((a.sum() - b.sum()) / 200) and jk.nblocks == 20
    assert jk.se == pytest.approx(math.sqrt(19 / 20 * ((loo - loo.mean()) ** 2).sum()))

def test_jackknife_two_blocks_has_no_se():
    jk = jackknife(d_ratio(np.array([1, 1, 0]), np.array([0, 0, 1])), np.array([0, 0, 1]))
    assert jk.est == pytest.approx(1 / 3) and jk.nblocks == 2 and math.isnan(jk.se) and math.isnan(jk.z)

def test_block_size():
    lens = lambda *t: SimpleNamespace(lengths={f"g{i}": np.array(x) for i, x in enumerate(t)})
    assert block_size(lens([600_000, 400_000], [2_000_000])) == 10_000
    assert block_size(lens([2_100_000_000])) == 5_000_000 and block_size(lens([300_000_000])) == 3_000_000
    assert block_size(lens([500_000])) == 10_000

def test_block_ids_split_by_seqid_and_size():
    ids = block_ids(np.array([0, 1, 0, 0, 0, 0]), np.array([5e3, 5e3, 19_999.5, 20_000.5, 21e3, 29e3]), 10_000)
    assert ids[0] != ids[1] and ids[2] != ids[3] and ids[3] == ids[4] == ids[5]

def test_u95():
    assert u95(np.array([0]), np.array([1000]))[0] == pytest.approx(0.0029957, rel=1e-4)
    assert u95(np.array([2]), np.array([500]))[0] == pytest.approx(chi2.ppf(0.95, 6) / 2 / 500)

def test_resolution_rows_and_warning():
    f = Findings()
    rows = resolution("resolution", "R,S;D", {"R": 0.85, "S": 0.40}, 1000, "disc=D", f, "Trio tests")
    assert [(r.statistic, r.value, r.n, r.loci) for r in rows] == [("resolved_R", 0.85, 1000, "disc=D"),
                                                                ("resolved_S", 0.40, 1000, "disc=D")]
    assert len(f.items()) == 1 and f.items()[0][1].startswith("WARNING:") and "heuristic" in f.items()[0][1]
    g = Findings()
    resolution("resolution", "R,S;D", {"R": 0.85, "S": 0.80}, 1000, "disc=D", g, "Trio tests")
    assert g.items() == []

def test_stats_roundtrip(tmp_path):
    rows = [StatRow("pav", "D_pav", "R,S;D", "all", "D", 0.123456789, 0.01, 12.3456789, 400, "disc=D", "."),
            StatRow("pav", "tree", "all", "all", "newick", "(A,B);")]
    write_stats(rows, tmp_path / "s.tsv")
    lines = (tmp_path / "s.tsv").read_text().splitlines()
    assert lines[0].split("\t") == list(STATS_COLUMNS) and len(lines) == 3
    assert lines[1].split("\t")[5:9] == ["0.123457", "0.01", "12.3457", "400"]
    assert lines[2].split("\t")[5:9] == ["(A,B);", ".", ".", "."]
    back = read_stats(tmp_path / "s.tsv")
    assert back[0].value == pytest.approx(0.123457) and math.isnan(back[1].se) and back[1].value == "(A,B);"

def test_findings_order():
    f = Findings()
    f.add("Painting", "p1"); f.warn("Run", "w1"); f.add("Run", "r1")
    assert f.items() == [("Painting", "p1"), ("Run", "WARNING: w1"), ("Run", "r1")]
```

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_stats_core.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** the tests. Expected: PASS.
- [ ] **Step 5: Commit.** `"Add statistics core: rows, blocks, jackknife, u95, resolution, findings"`
---

