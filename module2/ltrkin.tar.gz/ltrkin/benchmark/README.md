# ltrkin benchmarks (for developers)

Results: `../docs/benchmark_v0.2.md` (this release) and `../docs/benchmark.md`, `../docs/benchmark_genotype_sim.md` (v0.1).
Environment: `mamba env create -f environment.yml` (env `ltrkin_bench`: ltrkin's dependencies plus Sniffles2, kanpig,
badread, pbsim3, bcftools, snakemake). Run the scripts with that env active.

## Assembly truth (v0.2): `assembly_truth/`
Truth = each reference element's state on the other haplotype of a haplotype-resolved assembly, from a whole-genome
alignment confirmed by the allele junctions (`hap_truth.py`). Reads of the same individual are subsampled to a depth
series and genotyped by ltrkin, v0.1, Sniffles2 and kanpig; reads of the other haplotype only (HipHap partition)
give the presence/absence test. Everything runs in one working directory; paths in `config.yaml` are relative to it.
Extra tools: HipHap v0.2.0 (github.com/jheinz27/hiphap, release binary), LTRquest 1.0.1 (annotation),
ncbi-datasets-cli and sra-tools (download).

```bash
W=<repo>/benchmark/assembly_truth; mkdir work && cd work && cp $W/config.yaml .
bash $W/fetch_data.sh 8                                   # 4 assemblies + 2 read sets (~250 GB of reads)
# LTR-RT annotation of both haplotypes per species (LTRquest 1.0.1), then link the GFF3 files to the config's paths:
#   ltrquest --genome <S>_hap1.fa <S>_hap2.fa --proteins <pep> --threads 10 --run-sdust --no-plots \
#     --strand-recovery sensitive --strand-recovery-ppt --reboundary --detect-args "ltr-timeout=300"
#   proteins: C. amara hap1 + hap2 protein.faa (GCA_056512385.1, GCA_056512305.1; exact duplicates removed);
#   M. falcata: M. sativa RefSeq GCF_051527215.1 protein.faa
#   annot/<S>/<S>_hap{1,2}_LTRs_all_depth_LTR_cleaned.gff3 <- LTRquest's <S>_hap{1,2}_LTRs_all_depth_LTR_cleaned.gff3
bash $W/align.sh Camara map-hifi 0.27 24 reads/Camara/SRR40190226.fastq.gz     # ~120x total
bash $W/align.sh Mfalcata map-ont 0.30 36 reads/Mfalcata/SRR39462928.fastq.gz  # ~60x total (*)
bash $W/run_wga.sh Camara 20; bash $W/run_wga.sh Mfalcata 20
snakemake -s $W/Snakefile --configfile config.yaml --cores 56            # truth, depth series, baselines, scoring
bash $W/truth_check.sh Camara,Mfalcata                                   # truth vs other-haplotype reads
bash $W/robustness.sh dev <repo>/src && bash $W/robust_summary.sh dev    # jitter, primary-only, multi-sample
bash $W/source_check.sh dev <repo>/src                                   # genotype errors -> ltrkin source
python $W/make_tables.py dev; python $W/doc_tables.py Camara dev; python $W/doc_tables.py Mfalcata dev
python $W/strata_confirmed.py Camara hap1 d20_s1 v01,dev,sniffles,kanpig; python $W/truth_sensitivity.py Mfalcata hap1 d20_s1 dev
```
- `versions` in `config.yaml` lists the ltrkin versions compared; `dev` is this repository. v0.1 is the 0.1.0
  release (`ltrkin_src: {v01: <its src/>}`); remove it from `versions` to score the current code only.
- (*) The published run subsampled M. falcata in two steps (keep 0.5, then 0.6 of that); one step of 0.30 gives an
  equivalent, not identical, read set. Depths per species are in `config.yaml` (M. falcata reaches 40x).
- Main outputs: `<S>/eval/{hap1,hap2}.{diploid,haploid}.summary.tsv` (one row per condition x tool x stratum),
  `<S>/eval/diploid/<ref>_<cond>.calls.tsv.gz` (per-site calls vs truth), `truth_readcheck.summary.tsv`.
- Cost: the read alignments dominate (M. falcata ~45 Gb of ONT reads per haplotype). One ltrkin run takes 1-17 min
  at 8 threads; the full matrix is 132 ltrkin runs (two versions) and 84 baseline runs.
- `partition_reads.py` (target `<S>/part/check.stats`) re-implements HipHap's scoring rule as a cross-check.
- `docs/img/fig1_ltrkin` was drawn from these outputs with the author's plotting library (script not included).

## v0.1 benchmarks and other tools
| script | purpose |
|---|---|
| `run_genotype_bench.sh`, `sim_genotype_truth.py`, `eval_genotype_sim.py`, `compare_genotype_runs.py`, `diagnose_genotype_sim.py`, `whatif_genotype_model.py` | simulated reads (badread HiFi / ONT) over planted states on real sequence; `../docs/benchmark_genotype_sim.md` |
| `haplotag_eval.py` | zygosity vs read-phasing haplotags (*P. supina* HiFi) |
| `assembly_eval.py` | presence/absence vs each accession's own assembly (*P. annua*) |
| `sim_source.py`, `eval_source.py`, `eval_mosaic.py`, `calibrate_locality.py`, `search_completeness.py` | `ltrkin source` on simulated genealogies; locality nulls; search completeness |
| `hap_truth.py`, `eval_hap_truth.py`, `truth_to_genotypes.py`, `compare_sources.py`, `elements_to_sv_vcf.py`, `jitter_gff.py`, `whatif_phase.py` | assembly truth and its scoring, baselines' input VCFs, annotation jitter, phase-model what-ifs |
| `test_hap_truth.py`, `test_sim_genotype_truth.py` | tests of the truth builders: `pytest benchmark/` |

The *P. supina* and *P. annua* inputs (assemblies, haplotags, accession assemblies) are unpublished. The v0.2
regression on them reran `ltrkin genotype` with the same commands as v0.1 (`../docs/benchmark.md`) and scored
the calls with `haplotag_eval.py` and `assembly_eval.py`; the simulated set reran the `ltrkin` and `eval` stages
of `run_genotype_bench.sh` on the v0.1 reads.
