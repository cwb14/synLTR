# Task 1 report: Foundations — dependencies, constants, catalog loader, toy runs

**Status:** DONE_WITH_CONCERNS (the concerns are small, listed at the end; nothing blocks Task 2)
**Commit:** 837ea50 "Add analysis catalog loader, constants and toy runs" (on plan2-analyses, parent 12279a1; author
cwb14 from the global git config; no trailers; not pushed)
**Tests:** `python -m pytest -W error -m "not slow"`: 891 passed, 1 deselected (72.8 s). `ruff check .`: clean.

## What was built

| File | Content |
|---|---|
| `src/ltrpav/analysis/__init__.py` | docstring only |
| `src/ltrpav/analysis/constants.py` | the Step 5 block, verbatim, with its docstring |
| `src/ltrpav/analysis/catalog.py` | `STATE_CODE`, `TIER_CODE`, `FLAGS`, `FLAG_BIT`, `AGE_LABELS`, `AnalysisError`, `Catalog` (every field and method of the brief), `load_catalog`, `age_bin`, `cluster_keys` |
| `src/ltrpav/plot/__init__.py` | a one-line docstring |
| `tests/catalog_toy.py` | `GENOMES`, `TRACTS`, `ToyLocus`, `ToyRun` (`.load()`), `loc`, `dmat`, `read_tsv`, `write_run`, `simulate_run` |
| `tests/conftest.py` | session fixture `toy_fastas` (one `tmp_path_factory` directory) |
| `tests/test_catalog.py` | the brief's 5 tests verbatim, plus 1 added test (below) |
| `docs/DESIGN.md` | section 12: "Build decisions (plan 2)", the twelve calls, call 11 worded as the brief gives it |
| `pyproject.toml` | `scipy>=1.11`, `matplotlib>=3.8` |
| `environment.yml`, `environment.lock.yml` | scipy and matplotlib-base (decision 1); lock refreshed by the 84c8088 procedure |
| `tests/test_checkpoint.py` | one line (deviation 2) |

How `load_catalog` reads a run:
- **Fail-fast checks, cheapest first:**
  - `manifest.json`, then `loci.tsv` (both messages name `ltrpav-merge`);
  - loci.tsv's header against the sheet's labels, in sheet order (the message names both label lists);
  - the element tables, then every pair file (missing ones are named as `A__B`).
- **Then it parses:**
  - the sheet's sha256 via `file_checksum` (cache `work/checksums.json`);
  - the FASTA lengths via `Fasta(..., cache_dir=work/fai).lengths()`;
  - loci.tsv in two passes: a binary count of rows and lid width, then csv into preallocated arrays;
  - `top`, from `read_elements` of each annotated genome by walking `parent` links (memoized, cycle-safe);
  - each pair file, streamed once and split only through `b_strand`, so the evidence columns are never parsed.
- **Joining the pair files:** each row joins on the member eid. A's other elements (multi_member extras) are skipped.
  The call's strand is `A's element strand code × b_strand code`, which equals loci.py's `_turn`. A's own column is
  filled from its member (P, tier high).
- **Never calls** `_check_pair_files` or any engine-fingerprint check.

## TDD evidence

- **RED** (Step 4): `python -m pytest -W error tests/test_catalog.py` → collection error
  `ModuleNotFoundError: No module named 'ltrpav.analysis'`.
- **GREEN:** 5 passed in 4.7 s. Then `ruff check .` was clean.
- **Full suite:** 1 failure on the first run (deviation 2): `test_checkpoint.py::test_package_fingerprint`,
  `FileExistsError` on `ltrpav/analysis`. Fixed; now 891 passed.
- **Added test** `test_own_calls_strands_clusters_and_mismatches` covers behavior the five brief tests do not reach:
  - the call strand turned at an inverted window, and unknown strands on either side;
  - the mirrored site coordinates;
  - `cluster_keys` (a host and its nested element share a key) and its caller error;
  - an extra member element skipped;
  - a member's lost call and a truncated gzip, each an AnalysisError naming `R__D`.
- **Mutation check of the added test:** each break was made in a backed-up copy and restored after (`cmp` identical).
  The test failed for all three:
  - the strand not turned;
  - extra elements raising instead of being skipped;
  - the completeness check removed.

## Real-data smoke (read-only, scratch copy of main3)

- **Setup:** main3's `loci.tsv`, `qc.tsv`, `manifest.json`, `pairs/*.calls.tsv.gz`, `work/elements/*.tsv` and
  `samples.tsv` were copied into the scratchpad, so nothing was written into `benchmark_pav/` or `inputs/`. All four
  `.fai` files already exist beside the FASTAs, so `Fasta` only read them.
- **Size:** 322,538 loci, 4 genomes, 9 pair files.
- **Cost:** `load_catalog` took 10.3 s (11.1 s wall for the process), peak RSS 460 MB.
  - The time splits about evenly: loci.tsv parse, the pair files, and `read_elements`. `read_elements` builds full
    records only to get `parent`.
- **Cross-check:**
  - On the 272,012 loci with a single member genome and no `multi_member`, the merged state equals the discoverer's
    own call exactly (1.000000) for all 9 discoverer→genome pairs. So do the tier, site (seq, start, end) and strand.
  - This independently validates the eid join and the strand turn against the engine's own merge.
- **Other:**
  - members: B73 126,853, TIL18 123,019, TIL01 136,308;
  - K is finite at every member;
  - nested members mapped to an outer ancestor: 35,539, 33,649 and 37,518.

## The toy against the plan's quoted expectations

These are plain counts through the catalog API, not the later tasks' code:

| Check | Plan | Got |
|---|---|---|
| seed 1, `p_missing={"S": 0.6}`: R and S resolved in D's calls | 0.85 ± 0.03, 0.40 ± 0.03 | 0.847, 0.410 |
| seed 1, `p_missing={"O": 0.8}`: share of D-present loci the outgroup rule removes | 0.85 ± 0.03 | 0.848 |
| seed 1, n_per_seq 3000, `p_member` R 0.95 / S 0.5, `p_missing` 0.3: merged-state leak | > 0.05, about +0.15 | +0.147 |
| same run, D's own calls | about 0 | −0.031 (SE 0.049) |
| null seeds 1–5: sharing | R+S largest | R+S 811–843 vs 301–372 |
| seed 1, TRACTS, n_per_seq 3000: D_pav | > 0, K=0 above K≥0.01 | +0.288; K=0 +1.000; K≥0.01 +0.129 |

**Null calibration of D_pav** (binomial Z on D's own calls; the jackknife adds block structure on top):
- seeds 6–25: |Z| ≥ 3 in 0 of 20;
- seeds 26–125: mean Z −0.12 (SE 0.10), SD 1.04, |Z| ≥ 3 in 0 of 100; pooled D = −0.006.

## Decisions (made without the user, as instructed)

1. **`matplotlib-base` instead of the `matplotlib` metapackage.**
   - A dry run showed the cost of the metapackage in the `ltrpav` env: the Qt GUI stack (pyside6, qt6-main, about 47
     more packages), icu downgraded 79.1 → 78.3, and libsqlite and libpsl rebuilt (both already used by the engine's
     Python).
   - `matplotlib-base` installs 53 packages and changes none.
   - The plan only renders PNG/PDF headless (Agg; checked by rendering both).
   - `matplotlib-base` provides the `matplotlib` distribution (3.11.2), so pyproject's `matplotlib>=3.8` is exactly
     right for pip.
   - Reversal is one command (`mamba install -n ltrpav matplotlib`), whereas removing Qt later would be messy.
   - environment.yml says why in a comment.
2. **The toy's `b_strand`** is "+" where A's and B's strands agree, "-" where they differ, and "." where either is
   unknown.
   - With the loader's turn, a call's `pstrand` then equals B's loci.tsv strand.
   - An inversion gives "-", which Task 5's `n_strand` test needs.
   - Task 9's `strand={"S": "."}` locus gives `pstrand` 0 (unorientable), which its findings line needs.
3. **The inversion flips the strand.** That is "-" for the default "+", as the brief says; a given "-" becomes "+".
   Loci are selected by the locus start (`pos`) in [a, b].
4. **Toy validation (`_check`).** `write_run` raises ValueError on a toy the engine could not write:
   - a locus without every genome's state, or with no member (every locus is some annotation's element);
   - a member without annotation;
   - a call from a non-member;
   - a site outside its sequence (pos ≥ 6 for the empty site);
   - a bad parent, strand or inversion.
5. **Loader checks beyond the brief.** Each is fail-fast with file and line:
   - unknown state, tier or strand;
   - a pair-file tier "annot" (not a call tier);
   - a site that is not 1 ≤ start ≤ end;
   - a seqid absent from the FASTA;
   - an eid called twice;
   - a P/S/T call without a site;
   - a member eid with no call in a pair file, or absent from its element table ("rerun ltrpav-merge");
   - a corrupt gzip.
6. **API details:**
   - `g()` of an unknown label raises AnalysisError (a ValueError).
   - `pcls` of an unannotated genome returns all −1 (no calls).
   - `proj_site` returns the fai index as int64 (see concern 1).
   - `age_bin` maps a negative K to −1.
   - `cluster_keys` raises ValueError for a selected row whose gstar genome has no member there.
   - `top` has every label, with `{}` for unannotated genomes.
   - `lid` is a numpy unicode array; family, superfamily and TSD strings are interned.
   - `Catalog` is `@dataclass(eq=False, repr=False)` with a one-line repr, so array fields never break `==` and never
     flood pytest output.
7. **`simulate_run` details:**
   - Draw order is fixed and vectorized: pattern, K choice, true states, members, calls.
   - Tracts change presence only, never the draws, so an admixed run is the same seed's null run with R's presence
     copied from D inside the tracts.
   - `truth["n_rd_tract"]` counts the written loci (after the member filter).
   - Toy pair files are gzip level 1 with mtime 0 (reproducible bytes).
8. **`plot/__init__.py`.** "Empty docstring" was read as a module holding only a docstring; it has one line.

## Deviations

1. matplotlib-base (decision 1).
2. **`tests/test_checkpoint.py`, one line.** The engine test `test_package_fingerprint` simulates "a later analysis
   package" by `mkdir` of `ltrpav/analysis` in a copy of the package, which now exists.
   - Changed to `mkdir(exist_ok=True)`, with a comment.
   - The assertions are unchanged and still meaningful: the copy's analysis package holds the real modules plus the
     test's `stats.py`.
   - This file is a test, not an engine module, so no fingerprint changes.
3. **Field layout.** `ToyLocus` and `Catalog` fields are one per line instead of the brief's semicolon-joined lines.
   Fields, types, defaults and comments are the brief's.
   - The reason is the codebase's dataclass style. ruff 0.17.4's default rules would not have flagged the semicolons;
     my first reason, that they would, was wrong and I checked it.
4. **One added test** (above); the brief's five are verbatim.
5. **Line width.** My code is wrapped to the repo's 110 columns. The brief's verbatim constants block and the
   `ToyLocus.evidence` line are left as given; E501 is not enabled.

## Self-review findings (fixed before the commit)

- `_elements` in the toy rebuilt a set per element (quadratic). Fixed.
- **Toy speed:** pair-file writing now short-circuits None and str before `tsv_field`, and toy gzip uses level 1. Toy
  runs are now 2.5× faster:
  - default 0.63 s for 5,649 loci;
  - n_per_seq 3000: 1.36 s for 11,291 loci.

  The decompressed output of all 15 written files is identical to the slower version.
- `read_tsv` raised IndexError on an empty file; it now returns [].
- Ran the full suite rather than only the task's file, which found the engine test collision (deviation 2).

## Concerns for later tasks

1. **The int32 trap for Task 2.** `cat.seq` and `cat.pseq` are int32 as the brief specifies, so
   `block_ids(seq, ...)` must cast to int64 before `seq << 32`: an int32 shift by 32 is wrong in NumPy. `proj_site`
   already returns int64.
2. **Seed 5 is near the bar.** For Task 4's `test_null_and_admixed`, the null seed 5 gives D_pav −0.131, binomial
   Z ≈ −2.5. That is within |Z| < 3, and the null is calibrated (above). The jackknife Z will be close to it.
3. **Toy tiers for D and O differ by file, by design.** loci.tsv gives D and O tier "medium"; the pair files give the
   same calls tier "high". Both come from the brief's text and are noted in case a later test reads D or O call tiers.
4. **Loader time.** About 10 s per stage on main3. A light eid/parent parser instead of `read_elements` would save
   about 3 s. I kept the engine's validated reader, which the Interfaces name.

---

## Fix round 1 (review: task-1-review.md; controller rulings I1, I2, M1-M5)

**Commit:** 3cb7c3e "Make the toy write what the engine writes; harden the catalog loader" (parent 837ea50; author
cwb14; no trailers; not pushed).
**Tests:** `python -m pytest -W error -m "not slow"`: 894 passed (885 engine + 9 catalog), 1 deselected; `ruff check .`
clean. The brief's five tests are still AST-identical to the reviewer's extraction of the brief.

### Findings

- **I1, fixed.**
  - `b_strand` is the window's orientation, "+" or "-" on every call with a site:
    - "-" where exactly one genome of the pair is mirrored at the locus;
    - flipped again where both given strands are known and differ.
  - A call's strand is therefore unknown only where the caller's own strand is ".".
  - A "." strand on a non-member now raises ValueError in the toy: in the engine it is only an annotated member's own
    strand.
  - A non-member's loci.tsv strand is the deciding call's (via build_loci, below).
  - The added test now asserts `pstrand["R"][1, s] == -1`; `pstrand["S"][1, r] == 0` is kept.
- **I2, fixed. Calls now follow classify's rules:**
  - **(a)** An O call's site is B's inserted sequence, pos .. pos + b_ins - 1 (default b_ins 500), with a strand.
  - **(b)** Tiers come from placement plus evidence:
    - P high;
    - S high only with `solo_tsd` (added to S calls);
    - E high with `tsd_match`;
    - T, D and O medium. T also moves to medium: the engine never writes T high, though the review's sketch kept it
      high;
    - G and U ".".
  - **(c)** A D call's site is the junction, pos - 1 .. pos (2 bp).
  - **(d)** `inv` goes on every call from a reversed window (G included), and on the loci.tsv state such a call
    decides.
  - **loci.tsv now goes through Plan 1's path:** `build_loci` over the written pair files, then `write_loci_tsv`, so
    pair-file and loci.tsv tiers agree by construction. Lids are renumbered to list order, as the brief's tests
    require; the engine orders lids by position. `write_run` raises ValueError where:
    - the engine would merge two toy loci;
    - the engine would split one, because its members are never linked by a P/S/T call;
    - a locus's calls merge to states other than its spec.
  - **simulate_run** links members as the engine does. Members whose mutual calls both fail become separate loci, one
    per linked set. No random draws change.
  - **Engine details matched beyond the ruling:**
    - U is `no_anchor` with no window: no `inv`, and `wid` "." (genotype.py writes it so).
    - An S site is its solo LTR, pos .. pos + ltr - 1. The engine's S site is the image of the aligned LTR, about
      one LTR long.
    - Pair-file rows are in the engine's order (A fai order, start, -end, level).
    - Inherited calls (`host_empty`, `inherit`) carry no evidence flag.
    - `inv`, `conflict`, `no_call` and `annot_conflict` cannot be given: the engine sets them.
  - **loci.py docstring fixed:** O's B coordinates are B's sequence in the element's place, not a site.
    - All seven engine stage keys are identical before and after the edit.
    - `ltrpav.loci` is in no `STAGE_MODULES` set, and test_checkpoint's parametrized `("loci.py", set())` case
      already guards that.
- **M1, fixed.** `cluster_keys` requires a bool mask of shape (n,) and checks gstar's shape (`_gstar`). An index array
  raises ValueError; the own-calls test covers it.
- **M2, fixed.** Every site is bound-checked where the toy places it (`_Places.site`: 1 <= start <= end <= length),
  before any file is written. The reviewer's case (pos 49,990 mirrored by 1..50,000) raises ValueError.
- **M3, fixed.**
  - A run directory that cannot be written is read anyway: the sheet is hashed without the cache, with one warning
    (logger `ltrpav.analysis`). An unreadable sheet still fails.
  - New test `test_read_only_run`, skipped for root.
- **M4, documented, no code change.** The catalog docstring states the dense arrays' cost:
  - 23 bytes per locus × genome × annotated genome: about 90 MB on main3, about 2.3 GB at 1M loci and 10 genomes;
  - pangenome scale would need member-row storage;
  - load once per run, not per stage.
- **M5, fixed.**
  - `catalog.READER_MODULES` = ltrpav.checkpoint, ltrpav.classify, ltrpav.elements, ltrpav.samples, ltrpav.seqio, named
    in the docstring. The analysis fingerprint is `package_fingerprint("ltrpav.analysis", *READER_MODULES)`.
  - DESIGN section 12 call 12 now says so.
  - New test: `READER_MODULES` equals the engine modules catalog.py imports (AST), so a new reader import cannot be
    left out.
  - Task 10's `analysis_fingerprint` should use it. That is plan text, left to the controller.

### Recomputed toy values (seeds and quantities as in round 0)

| Value | Old | New | Quoted by |
|---|---|---|---|
| resolution of R, S in D's calls (seed 1, `p_missing={"S": 0.6}`) | 0.847 / 0.410 | 0.847 / 0.410 | Task 4 `test_resolution_warning` |
| outgroup removed_frac (seed 1, `p_missing={"O": 0.8}`) | 0.848 | 0.848 | Task 4 `test_outgroup_mostly_missing` |
| merged leak (seed 1, 3000/seq, `p_member` R 0.95 S 0.5, `p_missing` 0.3) | +0.147 (512+381) | **+0.127** (466+361) | Task 4 `test_null_with_unequal_annotation` ("about +0.15"; its bound > 0.05 holds) |
| same, D's own calls | −0.031 | −0.031 | (same test, \|Z\| < 3) |
| null seed 5 D_pav | −0.131 (binomial Z −2.55) | −0.131 (−2.55) | Task 4 `test_null_and_admixed` (\|Z\| < 3, seeds 1-5) |
| null calibration, seeds 26-125 | mean Z −0.122 (SE 0.104), SD 1.04, 0/100 \|Z\| ≥ 3, pooled D −0.0060 | identical | Test conventions (seeds 6-25 rule) |
| admixed seed 1 (TRACTS, 3000/seq): D_pav all / K=0 / K≥0.01 | +0.288 / +1.000 / +0.129 | identical | Task 4 `test_null_and_admixed` |
| `n_rd_tract` (same run) | 322 | 322 | none |
| null seeds 1-5, merged sharing | R+S 811-843, others 301-372 | R+S 798-828, others 295-364 | Task 4 (sister pair R, S still first) |

Why only the merged values move: the engine splits loci whose members never link (measured on seed 1's draws: 38 of
3,649 multi-member loci, 1.0%, at `p_missing` 0.15; 198, 5.4%, at 0.3). Each split-off row has the other member U. Every statistic read from D's own calls is
unchanged, because D's rows and calls are the same.

### Plan text the controller should amend (I did not edit the plan)

- **Task 9 `test_identity_end_to_end`.** It puts `strand={"S": "."}` on the non-member S, which the toy now rejects
  (engine-impossible). Put the "." on D, the discovering genome, as the review suggests; D's calls then have
  `pstrand` 0.
- **Task 1's toy table (Step 3).** Amend it to:
  - the tiers and sites above;
  - O with a site and D at its junction;
  - `inv` and `b_strand` as the window;
  - loci.tsv by `build_loci` with lids in list order;
  - simulate_run linking members as the engine does.
- **Task 4.** The leak "expected about +0.15" is now about +0.13.

### Not fixed

**Rule 0.** A host's E, D, O, G or U passes to what is nested in it, with the host's site and tier. The toy does not
model this: a nested element's calls are written as given.
- The brief's verbatim `test_load_roundtrip` needs that freedom:
  - its locus 3 is P in S, nested in locus 2, which is D in S;
  - its locus 2 (top level) carries `inherit`.
- Both are engine-impossible. This is stated in the toy's docstring.
- If the controller amends that test, the toy can derive inherited calls from the host's call.

### Cost

The engine merge makes toy runs slower:
- simulate_run at 1,500 per seqid: 0.63 → 0.99 s;
- at 3,000 per seqid: 1.36 → 2.10 s.
