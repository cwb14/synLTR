### Task 8: Annotation dispatcher, nesting, TSD inference

**Files:** Modify `src/ltrpav/annotation/__init__.py`; Create `tests/test_annotation.py`

**Interfaces:**
- Consumes: `load_ltrquest`, `load_gff3`, `load_bed`, `Fasta`, `Element`.
- Produces: `load_annotation(spec: str, genome: str, fasta: Fasta) -> list[Element]` (sorted by fai seqid order,
  start, -end); `assign_nesting(elements: list[Element]) -> list[Element]`;
  `infer_tsd(fasta: Fasta, e: Element) -> str | None`; `class AnnotationError(ValueError)`.

- [ ] **Step 1: Write the failing tests**

```python
def test_nesting_and_levels():
    # e1 [100,10000] contains e2 [2000,5000] contains e3 [2500,3000]
    out = {e.name: e for e in assign_nesting([...])}
    assert out["e2"].parent == out["e1"].eid and out["e3"].parent == out["e2"].eid
    assert [out[n].level for n in ("e1", "e2", "e3")] == [0, 1, 2]

def test_nesting_partial_overlap():            # Review Focus 4
    # e1 [100,10000] and e4 [9000,12000] overlap but neither contains the other
    assert out["e4"].parent is None and out["e4"].level == 0

def test_infer_tsd(tmp_path):                  # "ACGTA" + element + "ACGTA" -> "ACGTA"; no direct repeat -> None
def test_infer_tsd_at_sequence_start(tmp_path):  # element starting at base 2: returns None, no exception (Review Focus 3)
def test_unknown_seqid_fails_fast(tmp_path):   # AnnotationError message lists the missing seqid(s) (first 5 + count)
def test_duplicates_dropped(tmp_path):         # identical (seqid,start,end) twice -> one element, warning logged
def test_dispatch_by_format(tmp_path):         # .gff3/.gff3.gz -> gff3; .bed -> bed; prefix with depth files -> ltrquest;
                                               # anything else -> AnnotationError("cannot detect annotation format")
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - **Nesting:** sweep the elements sorted by (seqid, start, -end) with a stack. Pop while `top.end < e.start`. The
    parent is the topmost stack entry with `end >= e.end` (it contains `e`); partially overlapping entries stay on
    the stack. `level = parent.level + 1`.
  - **`infer_tsd`:** try L = 5, 4, 6 in that order. Return the first L where `A[s-1-L, s-1) == A[end, end+L)`, both
    have full length and neither contains N.
  - **Validation:** a seqid absent from the FASTA, or an end beyond the sequence length, raises AnnotationError.
  - Log each Counter of skip reasons as one warning line.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add annotation dispatcher, nesting and TSD inference"`.

---

