### Task 12: Real inputs and the genotyping queue

**Files** (in `benchmark_pav/plan3/real/`): `edta_prep.py`, `test_edta_prep.py`, `cap_variant.py`,
`{six,genus,citrus,edta}/samples.tsv`, `stability/{mm2,cap5k}/samples.tsv`, `annot_edta/*.gff3.gz`, `genotype_all.sh`,
`memo.md`.

**Interfaces:**
- `edta_prep.py GFF3 FASTA PREFIX OUT`:
  - Keeps `Method=structural` lines whose type ends in `LTR_retrotransposon` or equals `long_terminal_repeat`. LTRpav's
    loader pairs EDTA's sibling LTRs through their `repeat_region` parent, which needs no `repeat_region` line.
  - Prefixes every seqid with `PREFIX_`. A bare integer N becomes `PREFIX_chrN` when only that form is in the `.fai`
    (Zn).
  - Drops and counts records whose seqid is not in the `.fai`. Writes gzip.
- `cap_variant.py --flank-cap BP genotype ...`:
  - Sets the cap on the route that `ltrpav.cli.get_route` returns, as `bakeoff/run_variant.py` (`--flank-cap`) does.
  - Then calls `ltrpav.cli.genotype_main`, and writes `variant.json`.
  - The anchor stage key holds the cap through the route's `params`.

- [ ] **Step 1: EDTA prep test.** `test_edta_prep.py` writes a toy EDTA GFF3 on seqid `1`, in the layout of
  `inputs/annot_TIL18/te.gff3.gz`:
  - a `repeat_region` (`ID=repeat_region_1;Method=structural;tsd=GTTTT`);
  - its `target_site_duplication` and two `long_terminal_repeat` children (`Parent=repeat_region_1`);
  - a `Copia_LTR_retrotransposon` with `Parent=repeat_region_1`;
  - one `Method=homology` LTR-RT line;
  - one record on an unknown seqid.

  Against a toy `.fai` with `Zn_chr1`, assert:
  - the output loads with `load_annotation` as one element on `Zn_chr1`;
  - the homology line is dropped;
  - the unknown seqid is counted.
- [ ] **Step 2: Prepare annotations** for B73v5, TIL18, TIL01 (`inputs/annot_*`), TIL25, Zh and Zn (raw EDTA).
  - Each is written as `annot_edta/<sheet label>.gff3.gz`; B73's file is `B73.gff3.gz`, with seqid prefix `B73v5`.
  - Record kept elements, dropped seqids and the loader's count.
  - Expected structural counts (LTRmix genus run): TIL01 58,346, TIL18 51,214, TIL25 48,503, Zh 55,801, Zn 60,696.
  - B73, TIL18 and TIL01 must also equal the loader's count on `main3/qc_fixed/edta/*.structural.gff3`.
- [ ] **Step 3: Samples sheets** (absolute paths; `label fasta annotation group role`).
  - `six`:
    - B73 `run/B73v5_LTRs`, maize;
    - PT, TIL25, TIL11 `benchmark/ltrquest_extra/<L>_LTRs`: maize, mexicana, parviglumis;
    - TIL18, TIL01 `run/`: mexicana, parviglumis;
    - Zd `.`, diploperennis, outgroup.
  - `genus`:
    - TIL01, TIL18, TIL25, Zh, Zn with `annot_edta/<L>.gff3.gz`: parviglumis, mexicana, mexicana, huehuetenangensis,
      nicaraguensis;
    - Zd `.`, diploperennis, with no role: an ingroup genome.
  - `citrus`:
    - CsA, CsB, Cr from `lineage2/ltrquest_a/<L>_LTRs`;
    - Cm, CaM, CaP from `ltrquest_b`;
    - groups sweet, sweet, mandarin, pummelo, sour, sour.
  - `edta`: B73, TIL18 and TIL01 with `annot_edta`; Zd outgroup. Groups as in `six`: maize, mexicana, parviglumis,
    and diploperennis. `compare_papers.py` checks the roles against them.
  - `stability/{mm2,cap5k}`: B73, TIL18 and TIL01 (LTRquest); Zd outgroup; the same groups.
- [ ] **Step 4: Queue.** `genotype_all.sh` runs sequentially at 32 threads, each block skipped by its marker:
  1. six;
  2. genus;
  3. citrus;
  4. edta;
  5. `stability/mm2` (`--anchor mm2`). Its first pair, `--pair B73,TIL18`, runs alone with a tree-PSS sampler (main3's
     `mem_sampler.sh`, every 5 s). If the peak exceeds 250 GB:
     - the block stops;
     - the overrun goes in `dead_ends.md`, and the user is told: it is a measured cost of a selectable route (DESIGN 9);
     - the engine-fix task follows only if the overrun traces to a defect.
  6. `stability/cap5k` (`cap_variant.py --flank-cap 5000`).

  Each block runs `ltrpav-genotype --samples <d>/samples.tsv --outdir <d>/geno --threads 32`, then `ltrpav-merge`,
  under `/usr/bin/time -v`.
  - Snapshot `inputs/*.fai` before and after.
  - Launch detached after the grid and the LTRquest runs. Verify the PID; wait with a Monitor until-loop on
    `queue.done` or `queue.exit`.
  - Write `memo.md`.

---

