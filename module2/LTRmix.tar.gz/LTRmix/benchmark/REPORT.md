# Could LTR-RTs alone have found the maize–mexicana admixture? LTRmix benchmark

Date: 2026-11-07. Test case: maize B73 (Zm-B73-REFERENCE-NAM-5.0), *Zea mays* ssp. *mexicana* TIL18 and ssp.
*parviglumis* TIL01 (PanAnd-1.0); LTRquest 5042a1e libraries (127,636 / 124,641 / 137,847 elements).
Truth: Yang et al. 2023 (*Science* 382:eadg8940): ELAI calls for 845 lines, B73 column, lifted to v5; Barnes et al.
2022 (*PNAS* 119:e2100036119). Tool: `LTRmix/ltrmix.py`: input is one LTR-RT library (FASTA + table) per genome;
no genome sequence, genes, SNPs or outgroup. Whole assemblies were used only for benchmark checks.

## Short answer

**Yes for detecting maize–mexicana gene flow and its large-scale pattern; not for its direction or most individual
tracts.** From the three LTR-RT libraries alone:
- four independent tests detect excess maize–mexicana sharing (Z = 4.4–8.4), matching an outgroup-based SNP test on
  the same assemblies (Z = 9.2); across seven trios of six genomes, LTR-RT D tracks SNP D almost linearly (k-mers
  r = 0.99, insertions r = 1.00);
- the excess is concentrated in young insertions (D = 0.43–0.51 for LTR divergence ≤ 0.5% vs 0.08–0.13 for old
  ones); lineage sorting gives D = 0 at every age, so this gradient needs no clock rate. Element by element, 13
  insertions dated below 30 kyr (95% bound) are shared by B73 and mexicana vs 1 the other way (8 vs 0 confirmed in
  the raw assemblies), but that dating assumes 3×10⁻⁸ per site per year and a 30-kyr split. Measured in the data's
  own units, the split (0.05–0.07% LTR divergence) is too recent for any single element's LTRs to resolve, so no
  individual insertion is shown to be younger than the split without that assumption (section 2);
- the three chromosomes Yang et al. report as depleted of mexicana ancestry (5, 8, 9) are the three lowest by every
  recipient-side LTR-RT statistic, and ancestry along the genome tracks the published ELAI calls (r = 0.28 at 1 Mb,
  0.36 at 10 Mb; whole-genome k-mers reach 0.33 and 0.43);
- LTR-RT collinearity recovers Inv4m (B73–TIL18 inverted block within 0.03/0.3 Mb of the published breakpoints),
  shows the highland landrace PT carrying it, and shows TIL01 carrying Inv1n;
- Barnes' HPC1 is parviglumis-like in B73 and mexicana-like in PT (with the HPC1-carrying mexicana TIL25 as donor),
  and PT shares more with mexicana than B73 does (Z = 3.3–4.6).

What three genomes cannot give: the direction. The ELAI agreement shows that the signal includes the published
mexicana→maize ancestry. Two observations would also fit some maize→mexicana gene flow (documented in sympatric
populations): B73's recent-sharing tracts that ELAI does not call mexicana, and both mexicana lines being nearer to
maize than to each other (near-identical orthologs 19–30% vs 10%). Neither is decisive with these genomes (section 6).
With one
genome per taxon, individual introgressed tracts (mostly ~10 kb in B73; LTR-RTs every ~17 kb) cannot be separated
from lineage sorting: no ancestry tract survives a target-decoy FDR, ZmPRR37a is missed, the high-frequency regions
are not enriched, and the 21 recent-sharing tracts that pass the FDR are not ELAI mexicana tracts.

**The approach generalizes (sections 6b, 6c).** In a second, independent admixture event within *Zea* (published EDTA
calls, a different annotator), huehuetenangensis and parviglumis share more with *Z. nicaraguensis* than mexicana does
(k-mer Z = 6–18, confirmed on whole assemblies), as Chen et al. 2022 report; with a donor this distant only the k-mer
test is reliable, and the tool now says so. In sweet orange, whose pummelo × mandarin admixture is a few generations
old, the same libraries paint the published Mb-scale mandarin tracts (element AUROC 0.995; base-pair precision 0.84,
recall 0.95), while two near-pure sour-orange haplotypes stay flat. Local resolution is set by tract length and by
whether the sampled donor genome shares the tract's recent ancestry, not by the use of LTR-RTs: tracts carrying a few
dozen elements and a close donor reference are found; a ~10-kb maize tract carries fewer than one element.

## 1. Genome-wide admixture

| Test (recipient B73, sister TIL01, donor TIL18) | D ± SE | Z | Notes |
|---|---|---|---|
| D_kmer: single-copy k-mers shared by exactly two genomes | +0.111 ± 0.017 | 6.5 | no alignment, no orthology |
| D_ins: insertion presence/absence (absence ancestral) | +0.195 ± 0.027 | 7.2 | 10,918 vs 7,357 insertions |
| D3: ortholog-triple divergence (both sisters on the donor's record) | +0.043 ± 0.010 | 4.4 | 12,445 triples |
| D_self: ABBA/BABA polarized by the element's other LTR | +0.313 ± 0.037 | 8.4 | 28,673 vs 14,990 sites |
| *Comparator:* same k-mer statistic, whole assemblies | +0.107 ± 0.012 | 8.9 | |
| *Comparator:* same, LTR-RTs masked | +0.101 ± 0.011 | 9.4 | |
| *Comparator:* gene-space SNPs, *Z. diploperennis* outgroup | +0.168 ± 0.018 | 9.2 | 8,511 genes, 49.6 M sites |
| *Portability:* D_ins on published EDTA intact calls | +0.270 ± 0.036 | 7.4 | ~40% as many elements |

Roles were inferred from the data (sister pair = most shared single-copy k-mers). 5-Mb block jackknife (617 blocks).

## 2. The LTR clock separates gene flow from lineage sorting

D_ins by the donor copy's LTR-LTR divergence (K2P): 0: +0.51 (n = 122 + 40); ≤ 0.002: +0.43; 0.002–0.005: +0.47;
0.005–0.01: +0.35; 0.01–0.02: +0.21; 0.02–0.05: +0.16; 0.05–0.1: +0.08; > 0.1: +0.13. At 3×10⁻⁸ per site per year,
K2P 0.002–0.004 is 33–67 kyr, the published parviglumis–mexicana split (30–60 kyr: Yang et al. 2023, citing
Ross-Ibarra et al. 2009 and Chen et al. 2022; not estimated here; where the split falls on this axis depends on the
rate, see the rate-free check below). Insertions younger than the split can
be shared only through gene flow. In 30 null simulations young-insertion D was +0.02 ± 0.08; with gene flow 0.2–0.5.
The identity spectrum agrees: B73–TIL18 orthologs below 0.2% divergence outnumber TIL01–TIL18 3.9× (5,902 vs 1,530),
while deep orthologs are matched by construction. Some young TIL01+TIL18 sharing exists too (40 insertions at K2P 0),
consistent with parviglumis–mexicana gene flow.

Element by element: each TIL18 copy's own LTR differences d over n aligned sites give a 95% upper bound on its
insertion age (Poisson, t95 = λ95(d) / 2μn; `scripts/young_shared.py`, from TIL18's ortholog tables). Insertions shared
with exactly one sister:

| Insertion younger than (95% bound, at 3×10⁻⁸) | B73 + TIL18 (not TIL01) | TIL01 + TIL18 (not B73) | Binomial p |
|---|---|---|---|
| 20 kyr | 3 | 0 | 0.25 |
| 30 kyr (earliest split estimate) | 13 | 1 | 0.002 |
| 45 kyr | 60 | 8 | 6 × 10⁻¹¹ |
| 60 kyr | 109 | 18 | 5 × 10⁻¹⁷ |

At 3×10⁻⁸, each of the 13 arose after the earliest published split and is shared across it, which lineage sorting
cannot do; but that reading depends on the rate (see the rate-free check below). Checked against the raw assemblies (junction vs empty-site 21-mers; `absence/young/`), 8 of
the 13 are confirmed (insertion present in B73, empty site in TIL01), 5 are undetermined in TIL01 and none is
contradicted; the single TIL01+TIL18 one is undetermined in both (8 vs 0 confirmed, binomial p = 0.008). Below 60
kyr, 83 B73+TIL18 vs 11 TIL01+TIL18 insertions are confirmed both ways, and 3 of 109 B73+TIL18 calls are contradicted
(the insertion is in TIL01's assembly). Errors in the bound (the clock rate, gene conversion between LTRs) act on an element whatever
sister shares it, so the asymmetry between the columns does not depend on them. Identical LTRs bound age only weakly
(median 644 aligned sites: < 78 kyr), so the clock cannot resolve gene flow in the last ~20 kyr from single elements.
Which way each insertion moved is not identified (section 6).

**Rate-free check (2026-11-09; `scripts/rate_free_split.py`, `analysis/rate_free_split.tsv`).** The split can be read
in the same units as LTR-LTR divergence, so the rate cancels: without gene flow every TIL01–TIL18 ortholog pair
coalesced before the split, so its LTR divergence is s + X, with s = 2μT_split. Maximum likelihood on 20,284 pairs
(≥ 200 LTR sites; Poisson differences, exponential X): s = 0.048% (95% block bootstrap 0.034–0.063%); the fit
matches the lower tail (pairs ≤ 0.1%: observed 5.6%, fitted 5.4%). Adding a post-split gene-flow component (mean ≤
0.1%) and an upper-tail component gives s = 0.070% with 0.12% of pairs assigned to gene flow. (On simulated pairs
with 4% gene flow and s = 0.18%, the isolation-only fit gave 0.024% and the mixture 0.171%.) Against this split, **no**
insertion is younger by its 95% bound, in either column: identical LTRs over the median 644 sites bound divergence at
0.47%, and about 6,200 identical sites would be needed to fall below s. The rate-based table implicitly puts the
split at 0.18% (2 × 3×10⁻⁸ × 30 kyr), 2.6–3.8× above the data's own estimate. If the published split (30–60 kyr) is
right, the implied LTR rate is 0.4–1.2 × 10⁻⁸ per site per year (LTRquest default 3×10⁻⁸;
`ltrharvest_phasing10.py` uses 1.3×10⁻⁸, the rice LTR rate of Ma & Bennetzen 2004), and all ages in years in this
report are underestimates by up to that factor. What does not depend on the rate: (1) the age gradient of D (lineage
sorting gives D = 0 at every age) and the asymmetry between the two columns above; (2) post-split coalescence of
orthologs, in the data's own units: 7.6% of B73–TIL18 pairs fall below s vs 3.5% of TIL01–TIL18 pairs (the latter
mostly sampling noise), and the isolation fit for B73–TIL18 has no shift (s = 0.004%). General rule: a single
insertion can be certified as younger than a split only when the split's divergence exceeds about 3 / (LTR sites),
i.e. ~0.3% for 1-kb LTRs, about 5× deeper than maize–mexicana.

## 3. Where: chromosomes, windows, elements (B73 vs ELAI)

| Benchmark | Result | Bar | Verdict |
|---|---|---|---|
| Chromosomes 5, 8, 9 lowest (Yang) | Lowest three by HMM posterior, model-free class share, k-mer share and insertion share; Spearman with ELAI 0.49–0.64 | exact match (p = 1/120) | PASS |
| Windows vs ELAI (ancestry posterior) | r = 0.21 / 0.26 / 0.28 / 0.29 / 0.31 / 0.36 at 0.1 / 0.5 / 1 / 2 / 5 / 10 Mb; p = 0.001 (1,000 circular shifts, floor) | p < 0.01 at ≥ 1 Mb | PASS |
| Elements vs ELAI | AUROC 0.72 (dosage ≥ 1 vs ≤ 0.2), 0.78 (≥ 1.5) | reported | |
| Ancestry tracts | 1,686 tracts vs 1,597 decoy tracts; 0 at FDR ≤ 0.05; SNPs inside tracts: ELAI dosage ≥ 1 for 8.5% vs 4.9% genome-wide | | MISS (individual tracts) |
| ELAI runs > 1 overlapped by any ancestry tract | 37% (< 10 kb), 49% (10–100 kb), 60% (100–500 kb), 80% (≥ 500 kb) | reported | |

## 4. Inversions

| Inversion | Literature | LTR-RT collinearity | Verdict |
|---|---|---|---|
| Inv4m | in mexicana and highland maize, not B73; v5 chr4:172.88–188.13 Mb | B73–TIL18 inverted block chr4:172.85–187.84 Mb (26 anchors); B73–TIL01 shows a different inversion, 162.5–183.1 Mb; six genomes: B73–PT 173.21–187.84 (25), B73–TIL25 172.85–187.89 (27), TIL11 collinear | PASS |
| Inv1n | common in parviglumis, absent from maize; ~50 Mb on 1S (v2 65–115 Mb) | inverted B73–TIL01 (B73 61.0–109.0 Mb, 20 anchors) and TIL18–TIL01 (TIL18 62.9–99.6 Mb, 21 anchors), collinear B73–TIL18: TIL01 carries it (few anchors) | PASS |
| mexicana inversions on chr 8, 9 | no coordinates published | not assessable | — |

Inverted blocks whose arrangements split before the taxa (Inv1n, Inv4m, B73–TIL18 blocks at chr8 2–33 Mb and chr9
124–149 Mb, and five smaller ones) shift the ancestry posterior over the whole block; see section 8.

## 5. Named loci and selection regions

| Locus (B73 v5) | Expected in B73 | LTR-RT result | Verdict |
|---|---|---|---|
| HPC1 (Barnes), chr3:8.50 Mb | not mexicana in B73; mexicana in PT (shared with TIL25) | B73: neighbors near-identical to parviglumis (near_sister), max posterior 0.06–0.09; PT with TIL25 as donor: up to 0.999 (1–3 TIL25-shared elements; section 6) | PASS |
| ZmPRR37a (Yang), chr7:183.95 Mb | mexicana (ELAI 1.55) | ±50 kb: 5 of 6 elements private, max ancestry posterior 0.36; nearest recent tract q = 0.36 | MISS |
| ZmLPCAT1 (Barnes), chr5:203.42 Mb | not mexicana | ±50 kb: max posterior 0.50 (ambiguous) | inconclusive |
| 52 high-frequency regions (Yang's definition, from the ELAI file) | enriched | posterior 0.40 vs 0.38; shift p = 0.41 | MISS |

## 6. Six genomes: direction, fraction and controls

Added genomes (LTRquest 5042a1e, same flags): PT (Palomero Toluqueño, highland maize; PT_MEXI5, released under the
Toronto Agreement: check with its producers before publishing results from it), TIL25 (a second mexicana) and TIL11
(a second parviglumis). All 20 trios of the six genomes are run with roles inferred from the data.

Predictions, written before the run (2026-11-07 15:00), using the bars of the plan:
- Negative control: trio {TIL11, TIL01; TIL18} (two parviglumis, one mexicana): |Z| < 3 for every test.
- Positive control: trio {B73, PT; TIL18 or TIL25}: recipient PT, D > 0 with Z > 3 (Barnes: highland maize carries
  more mexicana ancestry than B73); HPC1 in PT mexicana-like with TIL25 as donor (B73: not); PT collinear with
  mexicana across Inv4m and inverted relative to B73.
- Direction: trio {TIL18, TIL25; B73}: if TIL18 carries maize-derived haplotypes, recipient TIL18 with D > 0 (Z > 3),
  and B73's confident recent-sharing tracts fall in TIL18's maize-like tracts, with low ELAI ancestry.
- Robustness: B73 with TIL25 instead of TIL18 as donor: D > 0, Z > 3.
- Fraction: f-ratio of B73 with TIL25 as the second donor, reported with its SE against ELAI 17.0%.
- Spike-in: recall by tract length and base-pair precision, reported (simulation expectation: recall 0.1–0.2,
  precision ~0.8 at q ≤ 0.05).

Note added 2026-11-07 15:20, after the genus run (6b) but before the six-genome run: on the EDTA libraries TIL25 is
closer to parviglumis TIL01 than to mexicana TIL18 (median ortholog divergence 0.0058 vs 0.0069; 1,065 vs 819
orthologs below 0.2%; k-mers pick TIL25 + TIL01 as the sister pair). Divergence does not depend on annotation
completeness, so TIL25 may carry parviglumis or maize ancestry. If so, (i) an f-ratio with TIL25 as the second donor
is inflated (its denominator, TIL25's own excess sharing with TIL18, is too small), and (ii) TIL25 rather than TIL18
may come out as the recipient in the direction trio. The predictions above are kept as written.

**Results** (LTRquest: PT 124,384, TIL25 119,210, TIL11 134,021 elements; all 20 trios in `results/six/`, summary
`results/six/analysis/trio_summary.tsv`; the B73/TIL18/TIL01 trio reproduces section 1 exactly).

| Prediction | Result | Verdict |
|---|---|---|
| Positive control: PT vs B73 | Recipient PT with TIL18 as donor: D_kmer +0.068 (Z 3.3), D_ins +0.132 (Z 4.6), D3 Z 2.6, D_self Z 1.5; with TIL25: Z 2.8 / 3.3 / 1.8 / 1.0. Against parviglumis TIL01 with TIL18, PT's excess is 1.5× B73's (D_kmer +0.164, Z 10.1; D_ins +0.291, Z 11.5) | PASS (k-mer and insertion tests) |
| Inv4m in PT | B73–PT inverted block chr4:173.21–187.84 Mb (25 anchors), as B73–TIL18 (172.85–187.84) and B73–TIL25 (172.85–187.89); none against TIL11. Inside the block PT's orthologs are near-identical to TIL25 (median 0.15%, 63% below 0.2%; n = 237; flanking chr4: 1.03%), while B73–PT differ by 3.03% (n = 27; flanks 0.12%): PT carries a young mexicana Inv4m haplotype (Fig. 4A) | PASS |
| HPC1 in PT with TIL25 as donor | With the gene placed by alignment (PT chr3:9.088 Mb): ±200 kb, 8 of 27 PT elements are shared with TIL25 and absent from TIL01, none the reverse; PT posterior ≥ 0.99 within 50 kb; the HPC1 copies differ at 5 of 1,522 positions between PT and TIL25, 27 between PT and B73. B73 is parviglumis-like from the gene rightward (posterior ≤ 0.03; 9 elements shared with TIL01 only) but TIL25-like on its left flank (0.56–0.995) (Fig. 4B, C) | PASS |
| Negative control {TIL11, TIL01; TIL18} | D_kmer +0.030 (Z 1.9), D_ins +0.031 (Z 1.2); D3 +0.026 (Z 3.2), D_self +0.169 (Z 4.1). Gene-space SNPs agree: D +0.052 (Z 3.0), so TIL11 truly shares a little more with TIL18 than TIL01 does. Second control {TIL11, TIL01; TIL25}: all \|Z\| ≤ 0.5 | k-mer/insertion PASS; D3/D_self detect a real asymmetry |
| Robustness: B73 with TIL25 as donor | D_kmer +0.016 (Z 0.8), D_ins Z 1.0, D3 Z 1.5, D_self +0.212 (Z 4.4); SNPs: +0.050 (Z 2.4), vs +0.168 (Z 9.2) with TIL18 | MISS for 3 of 4 tests; the SNPs show the same drop |
| Direction {TIL18, TIL25; B73} | The data never pair the two mexicana: B73 + TIL18 share the most k-mers. Forced post hoc (`scripts/forced_trio.py`): TIL18 vs TIL25 with B73 or PT as donor, \|Z\| ≤ 1.8 in every test (SNPs: +0.046, Z 2.0) | not testable as planned; no difference |
| f-ratio with TIL25 as second donor | Not estimable: no genome is the donor's own closest relative (TIL25 shares fewer orthologs with TIL18 than B73 does). The tool's first rule picked maize PT instead; fixed (`results/six/NOTE_fratio.txt`) | not estimable |
| Spike-in (TIL25 tracts in TIL11, donor TIL18) | 88 tracts, 224 Mb (10.1%): base-pair precision 0.10–0.13 = the spiked fraction; genome-wide D unchanged vs unspiked | uninformative (see below) |

- **The LTR-RT statistics track an outgroup SNP test across trios.** For the seven trios with a gene-space SNP
  ABBA/BABA (*Z. diploperennis* outgroup; `gene_snp/`), LTR-RT D follows SNP D almost linearly: k-mers r = 0.99
  (slope 0.75), insertions r = 1.00 (slope 1.34), D3 r = 0.86, D_self r = 0.71 (trios share genomes, so the 7 points
  are not independent). The LTR-RT libraries rank and scale gene flow the way the SNPs do, including where the
  signal is weak (TIL11, TIL25 trios).

  | Trio (tested, sister; donor) | SNP D (Z) | D_kmer (Z) | D_ins (Z) |
  |---|---|---|---|
  | PT, TIL01; TIL18 | +0.242 (12.0) | +0.164 (10.1) | +0.291 (11.5) |
  | B73, TIL01; TIL18 | +0.168 (9.2) | +0.111 (6.5) | +0.195 (7.2) |
  | TIL25, TIL01; TIL18 | +0.117 (6.4) | +0.057 (3.5) | +0.119 (4.6) |
  | PT, B73; TIL18 | +0.112 (5.2) | +0.068 (3.3) | +0.132 (4.6) |
  | TIL11, TIL01; TIL18 | +0.052 (3.0) | +0.030 (1.9) | +0.031 (1.2) |
  | B73, TIL01; TIL25 | +0.050 (2.4) | +0.016 (0.8) | +0.029 (1.0) |
  | TIL18, TIL25; B73 | +0.046 (2.0) | +0.013 (0.6) | +0.042 (1.4) |

- **Direction stays open.** Below 0.2% ortholog divergence, TIL18 shares 25% (B73) and 30% (PT) of its orthologs
  with maize but 10% with the other mexicana and 8% with parviglumis TIL01; TIL25 19% and 22% with maize, 10% with
  TIL18 and 12% with TIL01. This, and B73's 21 recent-sharing tracts that ELAI does not call mexicana, would fit some
  gene flow from maize into these mexicana accessions (documented in sympatric populations, Hufford et al. 2013), or
  maize ancestry acquired during line maintenance. Neither is decisive: maize is also nearer to each parviglumis
  (22–32%) than the two parviglumis are to each other (18.5%), so near-identity fractions also carry population
  structure, the domestication bottleneck and perhaps assembly error rates; and 17% mexicana→maize admixture whose
  copies are near-identical to TIL18 could alone give ~25% (observed 24.7%). Trios cannot tell the direction, so the
  excess B73–TIL18 sharing of sections 1–2 is maize–mexicana gene flow; the ELAI agreement (chromosomes 5, 8, 9;
  windows r = 0.28–0.36) is the evidence that it includes the published mexicana→maize ancestry.
- **Why the spike-in says nothing.** It spliced TIL25 tracts into TIL11 and asked whether they look like TIL18. They
  cannot: TIL25 is no closer to TIL18 than parviglumis is (above), so the spliced elements carry no TIL18-specific
  signal. Local detection needs a donor genome that shares recent ancestry with the introgressed haplotype, as the
  mandarin reference did in sweet orange (197 vs 1 near-identical orthologs; section 6c). The same limit explains
  why individual maize tracts are missed with one mexicana genome.
- **A second parviglumis is closer to maize.** TIL11 vs TIL01 with B73 as donor (forced): D3 Z 2.7, D_self Z 2.6,
  1.6× more near-identical orthologs; B73's mexicana excess stays significant with TIL11 as sister (D_kmer Z 5.2,
  D_ins Z 6.7, D_self Z 4.5).

## 6b. A second admixture event in *Zea* (predictions written before the run, 2026-11-07 14:30)

Chen et al. 2022 (*Nat Genet* 54:1736) report bidirectional admixture between parviglumis/huehuetenangensis and
nicaraguensis/luxurians. Using the published PanAnd EDTA intact LTR-RT calls (a different annotator; Zl-RIL003 has
none, so nicaraguensis Zn-PI615697 stands for the Luxuriantes) for TIL01, TIL18, TIL25, Zh-RIMHU001 and Zn:
- P1: trio {Zh, TIL18; Zn}: sisters Zh + TIL18, recipient Zh, D > 0 with Z > 3.
- P2: trio {TIL01, TIL18; Zn}: reported either way (the published admixture is population-level).
- Control: trio {TIL18, TIL25; Zn} (two mexicana): |Z| < 3.

**Result: P1 and the control pass by the k-mer tests (library and whole assembly); P2: parviglumis shares more with
nicaraguensis than mexicana does. The insertion test is unreliable with a donor this distant and fails the control.**
Libraries (EDTA intact calls): TIL01 58,346, TIL18 51,214, TIL25 48,503, Zh 55,801, Zn 60,696 elements. Library-only
1:1 orthologs with Zn: Zh 783, TIL01 446, TIL18 246, TIL25 228 (identical TSD in 0.89–0.93 of clock-accepted pairs vs
0.3–0.4% by chance). Roles were inferred from the data in every trio (sisters as written, Zn the third genome).

| Trio: recipient vs sister, donor Zn | D_kmer, library (Z) | D_kmer, whole assemblies (Z) | D_ins (Z) | Zn inside synteny with recipient / sister / both |
|---|---|---|---|---|
| **P1** Zh vs TIL18 | +0.177 (17.0) | +0.139 (15.0) | +0.458 (7.4) | 0.95 / 0.58 / 0.57 |
| Zh vs TIL25 | +0.165 (15.6) | | +0.285 (3.3) | 0.95 / 0.35 / 0.35 |
| Zh vs TIL01 | +0.061 (5.7) | +0.036 (3.6) | +0.278 (4.8) | 0.95 / 0.81 / 0.79 |
| **P2** TIL01 vs TIL18 | +0.121 (17.9) | +0.109 (18.3) | +0.265 (4.0) | 0.81 / 0.58 / 0.58 |
| TIL01 vs TIL25 | +0.112 (15.3) | | +0.066 (0.7) | 0.81 / 0.35 / 0.35 |
| **Control** TIL25 vs TIL18 | +0.013 (1.7) | −0.010 (−1.7) | **+0.307 (3.3)** | 0.35 / 0.58 / 0.30 |

- Both k-mer statistics rank the four *Z. mays* genomes the same way in their sharing with nicaraguensis: Zh > TIL01
  > TIL18 ≈ TIL25, matching Chen et al. 2022 (huehuetenangensis and parviglumis, not mexicana, exchanged genes with
  the Luxuriantes). On whole assemblies Zh and TIL01 exceed TIL18 on all ten chromosomes (+0.07 to +0.23); the
  two-mexicana control stays within ±0.08 per chromosome (genome-wide −0.010).
- The insertion test needs synteny between the donor and both sisters. Zn, ~120 kyr from *Z. mays* (Chen et al.
  2022), shares only a few hundred intact orthologs with each, so only 30–79% of it is resolved in both sisters, and
  coverage itself tracks gene flow (Zh 0.95, TIL01 0.81, TIL18 0.58, TIL25 0.35). The first run counted the two
  patterns asymmetrically (D_ins = 1 on four chromosomes; `dead_ends.md`). Counted symmetrically, D_ins stays
  positive for every Zh and TIL01 trio but also fails the control (+0.307, Z = 3.3, from 30% of Zn). ltrmix now
  reports this coverage and warns that insertion and ortholog tests are unreliable here, which is the right advice.
- Young insertions (K2P ≤ 0.01, i.e. ≲ 170 kyr; symmetric counting) shared with Zn: Zh 46 vs TIL18 6; control TIL25
  11 vs TIL18 4. The Zh asymmetry is far stronger than the control's, but with this coverage it is not used as a test.
- Annotation completeness ratios in the Zn trios are 1.28–1.64 (control 1.38 ± 0.16): with a distant donor,
  introgressed segments bring old donor insertions, so the ratio no longer isolates dropout. The annotation-free
  whole-assembly test settles it.
- Ortholog-based tests are underpowered here (75–119 ortholog triples per trio: D3 and D_self |Z| ≤ 1.3); the
  identity-spectrum bound is not interpreted. Direction is not resolved by trios.
- Whole assemblies show TIL25 sharing single-copy k-mers equally with TIL01 and TIL18 (D = −0.011, Z = −0.7): TIL25
  is not closer to the other mexicana than to parviglumis (see the note in section 6).

Scripts: `genus/run_genus.sh` (EDTA to library, ltrmix), `scripts/wg_kmer_trio.py` (`genus/wgk/run_wgk_trio.sh`; 58
min, 129 GB RSS). Outputs: `genus/out/`, `genus/out/analysis/trio_summary.tsv`, `genus/wgk/wgk_trio.tsv`.

## 6c. Outside *Zea*: sweet orange, a recent pummelo × mandarin admixture (predictions written before the run, 2026-11-07 15:55)

Sweet orange (*Citrus sinensis*) descends from a pummelo × mandarin cross a few generations back, so its
introgressed tracts are Mb-long. Truth: Wu B. et al. 2023 (*Hortic Res* 10:uhac247) Supplementary Table 4, the
mandarin (M) / pummelo (P) origin of every segment of both Valencia haplotypes (DVS_A1.0, DVS_B1.0; NCBI lengths match
within 45 bp). Genomes (NCBI): CsA = DVS_A (mandarin-derived haplotype; P tracts 8.7 Mb = 2.9%: chr2 25.5–32.9 Mb, chr8
0–1.3 Mb), CsB = DVS_B (pummelo-derived haplotype; M tracts 37.7 Mb = 12.6%, 7 tracts, 0.08–23.8 Mb), Cr = Sun Chu Sha
Kat hap1 (mandarin, no pummelo ancestry), Cm = Guanximiyou (pummelo), CaM / CaP = the two haplotypes of sour orange
ZGSC (an F1: each haplotype about pure). Libraries: LTRquest 5042a1e, same flags as maize, RefSeq *C. sinensis*
proteins for gene masking. Citrus has few intact LTR-RTs (published EDTA intact calls for Pera sweet orange: 4,317 in two haplotypes, ~7 per
Mb, vs ~25 per Mb for EDTA in B73 and ~60 per Mb for LTRquest in B73), so tracts shorter than ~1 Mb are below the
expected resolution.
- C1: trio {CsB, Cm; Cr}: sisters CsB + Cm, recipient CsB, D > 0 with Z > 3; ancestry and recent-sharing tracts
  overlap the M tracts (recall reported by tract length; the three ≥ 3.5-Mb tracts should be called), base-pair
  precision reported.
- C2: trio {CsA, Cr; Cm}: sisters CsA + Cr, recipient CsA; with 2.9% P the genome-wide test may lack power (reported
  either way); the 7.5-Mb chr2 tract should be called.
- Controls: trios {CaM, Cr; Cm} and {CaP, Cm; Cr}: |Z| < 3 and no confident tract.

**Result: C1 PASS, C2 PASS for the tract (genome-wide test underpowered, as predicted), controls PASS.** LTRquest
found 7,382–7,747 intact LTR-RTs per haplotype (~25 per Mb). Library-only 1:1 orthologs: ~5,000 between mandarin
haplotypes, ~3,500–4,400 between pummelo haplotypes, ~1,300 across the pummelo–mandarin split, and 1,715–1,737
between CsB and the two mandarins (its mandarin tracts); identical TSD in 0.86–0.98 of clock-accepted pairs vs
0.3–0.45% by chance. Every trio recovered the expected sister pair; donor synteny covered 0.96–0.98 of each donor in
both sisters (no coverage warning). All 20 trios: `lineage2/out/`; scoring: `lineage2/04_eval.py` → `lineage2/eval/`.

| Trio (recipient vs sister; donor) | Truth | D_kmer (Z) | D_ins (Z) | D3 (Z) | D_self (Z) | Element AUROC, ancestry / recent | Mean ancestry posterior inside / outside true tracts |
|---|---|---|---|---|---|---|---|
| **C1** CsB vs Cm; Cr | 12.6% M | +0.315 (4.0) | +0.469 (4.8; 622 vs 225) | +0.045 (2.0) | +0.549 (5.3) | 0.995 / 0.995 | 0.98 / 0.04 |
| **C2** CsA vs Cr; Cm | 2.9% P | +0.007 (0.2) | +0.012 (0.1) | +0.007 (1.2) | −0.015 (−0.2) | 0.933 / 0.996 | recent 0.89 / 0.01 |
| **Control** CaM vs Cr; Cm | ~0 | +0.019 (0.5) | +0.058 (0.9) | +0.005 (0.7) | −0.141 (−1.8) | | |
| **Control** Cm vs CaP; Cr | ~0 | +0.010 (0.4) | +0.130 (2.0) | +0.011 (1.3) | −0.055 (−0.7) | | |

- **Tracts (C1).** Every true mandarin tract of ≥ 1.7 Mb is called: chr1 23.8 Mb (99–100% covered), chr2 3.6 Mb (98%),
  chr3 7.2 Mb (100%), chr9 1.7 Mb (69%). The three tracts ≤ 1.1 Mb carry 0–5 elements and are missed. Called tracts:
  15 recent-sharing tracts, 42.7 Mb, base-pair precision 0.84 and recall 0.95 (ancestry model: 0.83 / 0.94). Most
  of the 17% of called sequence outside the truth lies at the starts of chr5 (0–2 Mb) and chr9 (0–3 Mb); chr9 is one
  of the regions where the two published truth sets disagree on phasing, so these calls are unverified, not
  confirmed errors.
- **Confidence labels.** No citrus tract reaches q ≤ 0.05: with 15 tracts and 4 decoy tracts the +1 target-decoy
  rule cannot certify any (section 7.2; minimum q ≈ 1/15). Here, as in very recent simulated admixture, the
  posteriors carry the information; this is a real limit of the FDR rule for few, long tracts. The decoy is also
  not a pure null here: 2 of the 4 decoy tracts on the pummelo sister lie opposite CsB's own mandarin segments
  (chr1, chr2), where CsB cannot stand in as pummelo's sister.
- **Admixture fraction.** The decoy-corrected excess of the ancestry posterior is +0.101 (truth 0.126); the
  identity spectrum shows 197 vs 1 orthologs below 0.2% divergence.
- **Clock.** D_ins is 0.86–1.00 for insertions with K2P ≤ 0.02 (113 vs 6) and 0.21–0.28 above 0.05 (296 vs 178):
  the shared young insertions are the recent admixture. Rate-free check (2026-11-09; `scripts/rate_free_split.py`,
  `analysis/rate_free_split.citrus.tsv`): the pummelo–mandarin split in LTR-divergence units is s = 1.00% (95% block
  bootstrap 0.79–1.24%; 1,322 Cm–Cr pairs, 60 blocks; the three-component fit gives 1.85%). Here single elements
  resolve the split (identical LTRs need ~300 sites, median 528): insertions shared by S and mandarin with a 95%
  bound below s number 9–37 vs 0–2 shared by pummelo and mandarin (9 vs 0 at the lower bound), so these are shown
  element by element to postdate the split without a rate, unlike maize (section 2). Ortholog pairs below s:
  S–M 30.5% vs P–M 5.8%. The isolation model under-fits the near-identical tail of P–M pairs (0.83% identical vs
  0.14% fitted: some P–M gene flow or annotation error), which lowers s and so makes the count conservative.
- **C2.** With 8.7 Mb of pummelo DNA, genome-wide tests have no power (all |Z| ≤ 1.2), but the recent-sharing model
  calls the 7.5-Mb chr2 tract (66% covered; 10 tracts in total, precision 0.81, recall 0.60). The 1.3-Mb chr8 tract
  (9 elements) is 29% covered. The ancestry model does not separate here (99 tracts vs 98 decoys).
- **Controls.** Sour orange's mandarin and pummelo haplotypes (each about pure) give |Z| ≤ 2.0 in every test and as
  many tracts as decoys (recent 6 vs 3 and 9 vs 12; ancestry 87 vs 89 and 185 vs 185).

## 7. Method benchmark

### 7.1 Orthology from the library alone
Simulation: precision 0.9994, recall 0.996. Real data: 24,098 (B73–TIL18), 31,435 (B73–TIL01) and 20,463
(TIL18–TIL01) 1:1 orthologs; identical TSD in 96.2%, 96.4% and 94.8% of clock-accepted pairs vs 0.29–0.35% for random
pairs. Against the raw assemblies (junction vs empty-site k-mers, decidable cases), library-only "absent" calls
were empty in 87.5–89.3% and "present" calls occupied in 76.4–83.0%, similarly in all six directions
(each genome's calls checked against each partner's assembly; 20,000 calls per class; `absence/`).

### 7.2 Calibration and power (msprime genealogies + LTR-RT insertion, loss and sequence evolution)
200-Mb genomes, ~19,000 elements each (≈ 1/7 of B73), demography from the *Zea* literature.
- No gene flow (30 independent replicates): mean Z −0.26 to +0.15, SD 0.77–1.23; |Z| > 3 in 0/30 for every test; no
  confident tract in any run; young-insertion D +0.02 ± 0.08.
- Power (Z > 3): 100% at f ≥ 0.18 for every test and admixture time; 50–100% at f = 0.10; ~0 at f ≤ 0.05.
- Admixture fraction: three-genome identity bound ≈ 0.6–0.8 × truth (a lower bound); with a second donor genome the
  f-ratio recovers truth (identity version: 0.285/0.271 for 0.318/0.285; 0.148/0.143 for 0.182/0.166; 0.101/0.085
  for 0.097/0.092; 0.020/0.022 for 0).
- Painting: element AUROC ≈ 1.0 (admixture 50 generations ago), 0.85–0.98 (500), 0.80–0.87 (5,000, maize-like).
  Recent-sharing tracts at q ≤ 0.05 (5,000 generations): base-pair precision 0.77–0.84, recall 0.10–0.20.
- With fewer than ~20 tracts the +1 target-decoy rule cannot reach q ≤ 0.05 by construction (very recent admixture:
  a few Mb-scale tracts, posteriors near 1 but no 'high' calls): read the posteriors there.
- 6/36 power runs with realized fractions 0.40–0.58 recast the recipient as the donor's sister (still significant,
  |Z| 7.6–13.2 across the four tests), as defined.

### 7.3 Failure modes found
- **One-sided annotation dropout.** Dropping 20% of the recipient's elements gave D_kmer Z ≈ −21 and D_ins Z ≈ −25
  under no gene flow (toward the better-annotated sister), while D3 (−0.01) and D_self (−0.6) were unaffected; 40%
  dropout broke the sister inference. In the real trio the completeness check (TIL18's old insertions present in B73
  vs TIL01) is 1.08 ± 0.02: B73 is not under-annotated; if TIL01 were, D_kmer and D_ins would be inflated, which is
  why the conclusion rests on D3, D_self, the gene-space SNP test and whole-genome k-mers, which all agree.
- **Unequal branch lengths.** A simulator bug sampled parviglumis 9,000 generations in the past: D_kmer, D_ins and D3
  all leaned toward it in 12/12 null runs; D_self, a properly polarized ABBA/BABA, did not.
- **Sparser annotation.** On EDTA intact calls (~40% of the elements) genome-wide tests hold but windows weaken
  (r = 0.24 at 1 Mb, 0.30 at 10 Mb) and the inversions are lost.
- **Incomplete synteny with a distant donor** (*Z. nicaraguensis*): the two insertion patterns needed different
  syntenies, so D_ins was counted asymmetrically (D = 1 on four chromosomes). Fixed by requiring the donor copy to be
  resolved in both sisters (maize: D_ins +0.189 → +0.195; simulations unchanged); the tool now reports donor synteny
  coverage and warns when it is low or uneven. With this donor, insertion tests still fail the control; k-mers hold.
- **Second donor for the f-ratio.** The first rule picked maize PT as a second "mexicana" for B73; a second donor must
  now be the donor's own closest relative (true second donor kept in 8/8 simulations; none qualifies in real data).
- **Hypothesis-driven trios.** Roles are inferred from the data; when gene flow makes an admixed pair the closest
  (B73 + TIL18), a planned trio such as {TIL18, TIL25; B73} cannot be formed. `scripts/forced_trio.py` sets the donor
  (post hoc here).

### 7.4 What restricting to LTR-RTs costs

| Input | D (Z) | r vs ELAI at 0.1 / 1 / 10 Mb | Chromosomes 5, 8, 9 lowest |
|---|---|---|---|
| LTR-RT libraries (ltrmix) | +0.111 (6.5) k-mers; +0.313 (8.4) D_self | 0.21 / 0.28 / 0.36 (posterior); 0.22 / 0.28 / 0.40 (class share) | yes |
| Whole assemblies, same k-mer statistic | +0.107 (8.9) | 0.25 / 0.33 / 0.43 | yes |
| Assemblies with LTR-RTs masked | +0.101 (9.4) | 0.24 / 0.34 / 0.43 | yes |

Across seven trios of the six genomes, LTR-RT D follows gene-space SNP D (*Z. diploperennis* outgroup) almost linearly
(k-mers r = 0.99, insertions r = 1.00; section 6): restricting to LTR-RTs changes the scale of D, not its ranking.

## 8. Limits

- Local resolution is limited by one haplotype per taxon (lineage sorting) and by how closely the sampled donor
  genome is related to the actual source of a tract, not by LTR-RTs: power for tracts grows with the number of donor
  genomes (section 6; the citrus test, with a close donor reference, paints tracts at Mb resolution).
- Three-genome tests do not identify the direction of gene flow; whether part of the maize–mexicana signal runs
  from maize into the sampled mexicana accessions is open here.
- Presence-based tests need comparable annotation completeness; use the completeness check and D3/D_self.
- ELAI is a reference, not exact truth (B73 dosage > 1.8 at 0.75% of called SNPs); disagreements were investigated.
- An inversion carried by the sister mimics introgression: inside Inv1n (TIL01 inverted, B73 and TIL18 standard)
  97% of B73's informative elements are mexicana-like (515 vs 18; posterior 0.79), and ELAI is high there too (0.34,
  twice the genome mean), so both methods may read old shared arrangement as gene flow. Without that block the
  chromosome-level Spearman with ELAI is 0.61 (vs 0.64) and the window r 0.25 at 1 Mb and 0.31 at 10 Mb (vs 0.28,
  0.36). The effect runs both ways (`scripts/inversion_effect.py`, `scripts/inversion_mask.py`; 2026-11-09): an
  inverted block is "old-arrangement" when the recipient's orthologs in the genome carrying the other arrangement
  diverge more than the genome-wide median sister–donor divergence (1.19%), i.e. the arrangements split before the
  taxa. Nine such blocks (6.4% of B73's elements) push the posterior toward whichever genome shares B73's
  arrangement: up in Inv1n (TIL01 3.5% diverged; 0.79) and chr1 263–267 Mb, down in Inv4m (TIL18 3.2%; 0.15),
  chr9 124–149 Mb (2.9%; 0.12), chr8 2–33 Mb (1.6%; 0.23) and three smaller TIL18 blocks (0.02–0.17). One exception:
  chr4 113–118 Mb (other arrangement in TIL01, 1.5%) stays low (0.11). ELAI agrees in the four large blocks (0.34 in
  Inv1n; 0.03–0.06 in Inv4m, chr8, chr9) but not in all small ones (chr10 126–132 Mb: 0.18, near the genome mean).
  Masking all nine: genome mean 0.383 → 0.382, chr5/8/9 still the lowest three, chromosome Spearman 0.62,
  window r 0.22 (1 Mb) and 0.25 (10 Mb), still above 200 circular shifts (95%: 0.08, 0.20; p = 0.005, floor).
  Orthology is not the problem: inside Inv1n every B73 element is resolved against TIL01, and raw-assembly checks of
  its 'absent' calls find 9% occupied vs 14% genome-wide. Masking alone would also discard introgressed
  arrangements (PT shares mexicana's Inv4m with TIL25 at 0.15% divergence vs 1.03% genome-wide); the proposed fix
  (flag, then test for an unusually young shared arrangement) is described in `LTRmix/DESIGN.md`, not implemented.
- Window size is not a parameter of the painting: the HMM fits its own tract-length scale (B73 197 kb; sweet orange
  mandarin haplotype 2.5 Mb), and the rise of ELAI agreement with window size (section 3) reflects averaging, not an
  optimum. Resolution is the spacing of informative elements: B73 median 25 kb (mean 67 kb; 31,395 of 127,636
  elements informative), citrus trios median 24–49 kb (mean 50–144 kb), similar despite a genome about a sixth the
  size. The tool does not yet report it (`LTRmix/DESIGN.md`, Known limits).
- Generality: tested in three admixture events (maize–mexicana; wild *Zea*; sweet orange) and two annotators;
  other taxa (animals, TE-poor genomes) are untested.

## 9. What is new

- **Precedent.** Asymmetry of conflicting insertion patterns as a test of hybridization vs lineage sorting is
  established for retroposons in mammals (the KKSC statistics of Kuritzin et al. 2016, *PLoS Comput Biol*
  12:e1004812, applied to SINE/LINE presence/absence screened by alignment or PCR). D_ins is a genome-scale version of
  that logic; LTR-RT insertion polymorphisms are also long-used markers in plants (SSAP, IRAP).
- **New here, as far as my searches found:** (1) every insertion is dated by its own LTR pair, so the excess can be
  traced across insertion age without a clock rate (lineage sorting gives D = 0 at every age), which SINE/Alu markers
  cannot do; certifying single insertions as younger than the split needs a split deeper than ~3 / (LTR sites) in
  divergence, which maize–mexicana is not (section 2: 13 vs 1 only at an assumed 3×10⁻⁸); (2) orthology from transposon libraries alone, certified by
  the target-site duplication, with no whole-genome alignment; (3) ABBA/BABA on LTR sites polarized by the element's
  other LTR; (4) local painting with a sister-genome decoy for the error rate; (5) a benchmark against published
  admixture in three independent events (maize–mexicana, wild *Zea*, sweet orange), with the failure modes measured
  (one-sided annotation dropout, incomplete synteny with a distant donor, few long tracts for the FDR rule).

## 10. Headline, mechanism, generality, predictions

**Headline.** A retrotransposon insertion carries its own date, polarity and identity, so insertions younger than a
species split yet shared across it are a direct record of gene flow: transposon annotations of one genome per taxon
are enough to detect gene flow, separate it from lineage sorting, and map introgressed tracts that are long and whose
donor is represented by a close genome.

**Mechanism.** Lineage sorting can share only insertions already present in the common ancestor, i.e. older than the
split; gene flow also moves insertions that arose after it. The two LTRs of an element were identical at insertion,
so their divergence dates it; the target-site duplication certifies that two copies are one insertion; and absence is
the ancestral state, so no outgroup is needed. In an admixed genome the young shared insertions cluster in the
introgressed segments: when segments span tens of elements and the sampled donor carries the same recent haplotype
(sweet orange, a few generations after admixture), their pattern paints the segments; when a segment holds less than
one element or the donor genome is only a distant relative of the source (maize, admixture thousands of generations
old, one mexicana genome), ancestry is recoverable only at genome, chromosome and Mb scale.

**How general.** Tested: three independent admixture events, in grasses and in a eudicot (monocots and eudicots),
genomes of 0.3–2.4 Gb, two independent annotators (LTRquest, EDTA), 30 null simulations without a false positive, and
seven maize/teosinte trios in which LTR-RT statistics track a gene-space SNP test with an outgroup (r = 0.99 for
k-mers, 1.00 for insertions). Assumed, not tested: animals and TE-poor genomes. Limits found: like any three-taxon
test, the direction of gene flow is not identified (whether some maize–mexicana sharing runs from maize into the
sampled mexicana is open); a donor diverged by about the turnover time of intact LTR-RTs (*Z. nicaraguensis*, ~120 kyr)
shares too few orthologous elements for insertion tests, though k-mer sharing still works; and a split as recent as
maize–mexicana (0.05–0.07% LTR divergence) is below what one element's LTRs can date, so single insertions are not
shown to postdate it without an assumed rate (the age gradient of D is rate-free).

**Predictions for other species.** (1) Wherever hybridizing taxa carry active LTR-RT families, the donor-shared
excess will rise as insertion age falls below the split, and insertions younger than the last gene flow will not be
shared, so the age at which sharing stops dates the end of gene flow. (2) Crops and wild species of recent hybrid
origin (admixture a few generations old, as in citrus) can be painted at Mb resolution from reference assemblies
alone, with no population sample; old introgression cannot be resolved locally with one genome per taxon. (3) Crop–
wild pairs sampled as single inbred or reference genomes can share recent ancestry in both directions, so direction
needs more than one genome per taxon. (4) Tests built on insertion orthology lose power once the donor has
diverged for longer than intact LTR-RTs survive.

## Figures

Each PDF has three pages (figure, short legend, long legend); every legend number is in `<stem>_numbers.tsv` with its
source; `<stem>.py` rebuilds it; `memo.md` holds the figure check.
- Fig. 1 `figures/fig1_painting/`: B73 painted against parviglumis and mexicana; ELAI; Inv1n, Inv4m; one element at
  base-pair scale.
- Fig. 2 `figures/fig2_clock/`: the LTR clock separates gene flow from lineage sorting (every shared insertion by age,
  one young insertion and its empty site, nulls). Not yet revised for the rate-free check (section 2): the
  published-split band on the age axis and "younger than the split" in the legend assume 3×10⁻⁸; in the data's own
  units the split lies at 0.05–0.07% LTR divergence, inside the identical-LTR stratum's uncertainty.
- Fig. 3 `figures/fig3_benchmark/`: calibration, power, resolution, failure modes, raw-assembly absence check.
- Fig. 4 `figures/fig4_six_genomes/`: Inv4m in six genomes, HPC1 in PT, LTR-RT vs SNP D across trios, near-identity,
  all trios.
- Fig. 5 `figures/fig5_generality/`: sweet orange painted against the published tracts; the wild *Zea* event.
- Tool figure: `overview.pdf` in every trio output (e.g. `results/main3/`, `lineage2/out/CsB_Cr_Cm/`).

## References

- Yang N. et al. 2023. Two teosintes made modern maize. *Science* 382:eadg8940. https://doi.org/10.1126/science.adg8940
  (ELAI calls: figshare 21579528, https://doi.org/10.6084/m9.figshare.21579528)
- Barnes A.C. et al. 2022. An adaptive teosinte *mexicana* introgression modulates phosphatidylcholine levels and is
  associated with maize flowering time. *PNAS* 119:e2100036119. https://doi.org/10.1073/pnas.2100036119
- Chen L. et al. 2022. Genome sequencing reveals evidence of adaptive variation in the genus *Zea*. *Nat Genet*
  54:1736–1745. https://doi.org/10.1038/s41588-022-01184-y (accepted manuscript: https://par.nsf.gov/servlets/purl/10380573)
  (mexicana–parviglumis divergence ~30 kya, 95% HPD 26.7–34.5 kya; maize–parviglumis ~12 kya)
- Ross-Ibarra J., Tenaillon M., Gaut B.S. 2009. Historical divergence and gene flow in the genus *Zea*. *Genetics*
  181:1399–1413. https://doi.org/10.1534/genetics.108.097238 (with Chen et al. 2022, the source of the 30–60 kya
  split quoted by Yang et al. 2023)
- Ma J., Bennetzen J.L. 2004. Rapid recent growth and divergence of rice nuclear genomes. *PNAS* 101:12404–12410.
  https://doi.org/10.1073/pnas.0403715101 (LTR rate 1.3×10⁻⁸ per site per year)
- Matsuoka Y. et al. 2002. A single domestication for maize shown by multilocus microsatellite genotyping. *PNAS*
  99:6080–6084. https://doi.org/10.1073/pnas.052125199 (domestication ~9 kya)
- Wu B. et al. 2023. A chromosome-level phased genome enabling allele-level studies in sweet orange: a case study on
  citrus Huanglongbing tolerance. *Hortic Res* 10:uhac247 (Supplementary Table 4: mandarin/pummelo origin of each
  DVS segment; DVS_A 97.1% mandarin, DVS_B 87.4% pummelo). https://doi.org/10.1093/hr/uhac247
- Wu G.A. et al. 2021. Diversification of mandarin citrus by hybrid speciation and apomixis. *Nat Commun* 12:4377.
  https://doi.org/10.1038/s41467-021-24653-0
- Hufford M.B. et al. 2013. The genomic signature of crop-wild introgression in maize. *PLoS Genet* 9:e1003477.
  https://doi.org/10.1371/journal.pgen.1003477
- Kuritzin A., Kischka T., Schmitz J., Churakov G. 2016. Incomplete lineage sorting and hybridization statistics for
  large-scale retroposon insertion data. *PLoS Comput Biol* 12:e1004812. https://doi.org/10.1371/journal.pcbi.1004812
- Assemblies: MaizeGDB (Zm-B73-REFERENCE-NAM-5.0; PanAnd-1.0 TIL01, TIL18, TIL25, TIL11, Zh-RIMHU001, Zn-PI615697;
  Zm-PT-REFERENCE-HiLo-1.0, Toronto Agreement), NCBI GenBank (citrus accessions in section 6c and memo_ltrmix.md).
