# Task 24G report: rule 5a (present calls anchored at their site)

Commit 1cb1b34 "Require present calls to be anchored at their site" (on 8dfc012; not pushed).

## What changed
- src/ltrpav/classify.py: `_present` now wraps the old body (renamed `_present_call`) and returns U with reason
  `unanchored` unless `_anchored(x)`. `_anchored` is a direct port of the measure_5a.py prototype: an
  AlnMap._runs(MIN_SEG) run crosses s with >= MIN_SEG aligned A bases before s inside the run, or crosses t with
  >= MIN_SEG after t; else `_solo_tsd(x)`. No new constant. Rule 0 passes the U to nested elements unchanged.
  Module docstring lists rule 5a.
- docs/DESIGN.md: 5.4 gains a rule 5a paragraph (O unchanged, per ruling) and the U table row names `unanchored`.
- tests/test_classify.py: 8 new test cases (unanchored -> U, TSD exception, anchored on one side for P and T on
  each side, nested inheritance), over seven seeds where applicable. Hand-built AlnMaps for determinism. With
  the rule disabled, the unanchored and inheritance tests fail (checked).

## Tests
Full suite under -W error and ruff check pass. Note: tests/test_cli.py::test_fail_fast_on_missing_binary
[flank-blast-makeblastdb] fails unless blastn is on PATH (pre-existing, also at 8dfc012; environment, not code);
run with the ltrpav_bench bin first on PATH. Every existing toy case (all seeds) and classifier test is unchanged.

## Reproduction check
Datasets R1_s1.A__B (5 changes, all T -> U) and R1_s2.B__A (7: 5 T, 1 S, 1 O -> U): live-code reclassification of
every ok window (257 / 275) matches the prototype's data/m5a/*.calls.tsv.gz line for line (0 differ) and the
change counts match the prototype's check.tsv exactly (5, 7). Script:
benchmark_pav/bakeoff/task24g_scratch/repro.py.

## Deviations
None. (The aligner call in the check is the prototype's: mappy asm20.)
