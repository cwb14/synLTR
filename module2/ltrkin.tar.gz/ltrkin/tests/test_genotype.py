import csv
import os

import pysam
import pytest

from ltrkin.annot import read_gff3
from ltrkin.cli import main
from ltrkin.model import ReadModel, call, genotypes
from ltrkin.reads import qpos_at



class _M:  # minimal read model for likelihood tests
    def __init__(self, d_hap=15.0, k=50.0, ploidy=2):
        self.d_hap, self.k, self.ploidy = d_hap, k, ploidy


RATES = {"F": 1.6, "S": 1.0, "E": 1.0}


@pytest.mark.parametrize("counts,expect", [
    ({"F": 48, "S": 0, "E": 0}, "F/F"),
    ({"F": 24, "S": 0, "E": 15}, "F/E"),
    ({"F": 24, "S": 15, "E": 0}, "F/S"),
    ({"F": 0, "S": 0, "E": 30}, "E/E"),
    ({"F": 24, "S": 0, "E": 0}, "F/N"),      # half the reads a two-copy site would give: one haplotype lacks it
    ({"F": 0, "S": 0, "E": 0}, "N/N"),
    ({"F": 47, "S": 0, "E": 1}, "F/F"),      # one stray read does not make a heterozygote
])
def test_model_calls(counts, expect):
    gt, gq, lls, mu = call(counts, RATES, _M(), 0.02)
    assert gt == expect
    assert 0 <= gq <= 99


def test_genotype_space():
    assert len(genotypes(2)) == 10 and "F/N" in genotypes(2)


def test_read_model_rates():
    m = ReadModel([30] * 100, [12000] * 200, 2)
    assert abs(m.depth - 30) < 2 and abs(m.d_hap - 15) < 1
    assert m.r(0) == pytest.approx(1.0) and m.r(12000) == 0.0 and m.r(6000) == pytest.approx(0.5)


def test_gff_ltrquest(data):
    els = read_gff3(data["gff"])
    ids = {e.id for e in els}
    assert {"E1_het_empty", "E5_nested_outer", "E5_nested_outer_inner"} <= ids
    outer = next(e for e in els if e.id == "E5_nested_outer")
    inner = next(e for e in els if e.id == "E5_nested_outer_inner")
    assert outer.n_inner == 1 and inner.n_outer == 1
    assert outer.lltr[1] - outer.lltr[0] == 600


def test_gff_edta_style(tmp_path):
    g = tmp_path / "edta.gff3"
    g.write_text(
        "##gff-version 3\n"
        "c1\tEDTA\trepeat_region\t100\t5210\t.\t+\t.\tID=repeat_region_1\n"
        "c1\tEDTA\ttarget_site_duplication\t100\t104\t.\t+\t.\tID=tsd_1;Parent=repeat_region_1\n"
        "c1\tEDTA\tCopia_LTR_retrotransposon\t105\t5205\t.\t+\t.\tID=LTRRT_1;Parent=repeat_region_1;"
        "Name=TE_00001;Classification=LTR/Copia;tsd=ACGTA\n"
        "c1\tEDTA\tlong_terminal_repeat\t105\t504\t.\t+\t.\tID=lLTR_1;Parent=repeat_region_1\n"
        "c1\tEDTA\tlong_terminal_repeat\t4806\t5205\t.\t+\t.\tID=rLTR_1;Parent=repeat_region_1\n"
        "c1\tEDTA\ttarget_site_duplication\t5206\t5210\t.\t+\t.\tID=tsd_2;Parent=repeat_region_1\n")
    (e,) = read_gff3(str(g))
    assert (e.start, e.end, e.lltr, e.rltr) == (104, 5205, (104, 504), (4805, 5205))
    assert e.family == "TE_00001" and e.clade == "Copia" and e.tsd == "ACGTA"


def test_gff_dante_ltr_style(tmp_path):
    g = tmp_path / "dante.gff3"
    cls = "Class_I|LTR|Ty3/gypsy|non-chromovirus|OTA|Athila"
    g.write_text(
        "##gff-version 3\n"
        f"c1\tdante_ltr\ttransposable_element\t1001\t9000\t.\t+\t.\tID=TE_1;Final_Classification={cls};Name={cls}\n"
        f"c1\tdante_ltr\tlong_terminal_repeat\t1001\t1500\t.\t+\t.\tLTR=5LTR;Parent=TE_1;\n"
        f"c1\tdante_ltr\tprotein_domain\t3001\t3500\t.\t+\t.\tName=RT;Parent=TE_1\n"
        f"c1\tdante_ltr\tlong_terminal_repeat\t8501\t9000\t.\t+\t.\tLTR=3LTR;Parent=TE_1;\n"
        f"c1\tdante_ltr\ttransposable_element\t20001\t23000\t.\t+\t.\tID=TE_partial_2;Final_Classification={cls}\n")
    els = read_gff3(str(g))
    assert len(els) == 1 and read_gff3.skipped == 1          # the domain-only partial element is skipped
    (e,) = els
    assert (e.start, e.end, e.lltr, e.rltr) == (1000, 9000, (1000, 1500), (8500, 9000))
    assert e.clade == "Athila"


def test_qpos_at():
    hdr = pysam.AlignmentHeader.from_dict({"SQ": [{"SN": "c", "LN": 1000}]})
    a = pysam.AlignedSegment(hdr)
    a.reference_id, a.reference_start, a.query_sequence = 0, 100, "A" * 60
    a.cigarstring = "10S20M5D20M10I"   # query: 10 clip, 20 match, (5 del), 20 match, 10 ins (no trailing ref)
    assert qpos_at(a, 100) == 10 and qpos_at(a, 119) == 29
    assert qpos_at(a, 122) == 30          # inside the deletion -> query position after it
    assert qpos_at(a, 125) == 30 and qpos_at(a, 144) == 49 and qpos_at(a, 145) is None


def _run(data, bam, out):
    main(["genotype", "-r", data["ref"], "-a", data["gff"], "-o", out, "-t", "2", bam])
    with open(out + ".genotypes.tsv") as fh:
        return {r["element_id"]: r for r in csv.DictReader(fh, delimiter="\t")}


@pytest.mark.parametrize("mode", ["full", "primary"])
def test_end_to_end(data, tmp_path, mode):
    res = _run(data, data[mode], str(tmp_path / mode))
    for eid, truth in data["truth"].items():
        r = res[eid]
        if eid == "E5_nested_outer_inner":   # flanks are near-identical family-B sequence: a call may be withheld
            assert r["genotype"] in (truth, "N/N", "F/N") or int(r["gq"]) < 20, (eid, r["genotype"])
            continue
        if eid in ("E5_nested_outer", "E9_internal_del"):
            # hap2 carries the element with another internal length (no inner insertion / an internal deletion):
            # its spanning reads carry both element ends, so they count as full and the site is flagged
            assert "full_other_length" in r["flags"] and int(r["n_F_other"]) > 0, (mode, eid, r["flags"])
            # E9's other-length reads were the only hap2 evidence (v0.1 called F/N); E5's nested outer element has
            # junction reads on both haplotypes and its F/F vs F/N rests on depth (identical haplotypes, 15x each)
            assert r["genotype"] == "F/F" if eid == "E9_internal_del" else r["genotype"] in ("F/F", "F/N")
            continue
        assert r["genotype"] == truth, (mode, eid, r["genotype"], r["gq"], r["n_F"], r["n_E"], r["n_S"], r["flags"])
        # F/F vs F/N rests on read depth alone here (identical haplotypes, no phasing): 15x per haplotype supports
        # only a weak GQ; empty and solo alleles are seen directly and must be confident
        assert int(r["gq"]) >= (3 if truth in ("F/F", "F/N") else 20), (mode, eid, r["gq"])
    assert os.path.exists(str(tmp_path / mode) + ".vcf.gz")


def test_split_rescue_matters(data, tmp_path):
    """In the primary-only BAM some empty-site reads are single pieces; they must still be counted."""
    full = _run(data, data["full"], str(tmp_path / "f2"))
    prim = _run(data, data["primary"], str(tmp_path / "p2"))
    e_full, e_prim = int(full["E1_het_empty"]["n_E"]), int(prim["E1_het_empty"]["n_E"])
    assert e_prim >= 0.8 * e_full


def test_reproducible_across_hash_seeds(data, tmp_path):
    """Same inputs, different Python hash seeds -> identical genotype tables (set ordering must not leak)."""
    import subprocess
    import sys
    outs = []
    for seed in ("1", "2"):
        out = str(tmp_path / f"h{seed}")
        env = dict(os.environ, PYTHONHASHSEED=seed)
        subprocess.run([sys.executable, "-m", "ltrkin.cli", "genotype", "-r", data["ref"], "-a", data["gff"],
                        "-o", out, "-t", "2", data["full"]], check=True, env=env, capture_output=True)
        outs.append(open(out + ".genotypes.tsv").read())
    assert outs[0] == outs[1]


def test_solo_with_unequal_ltrs():
    """A solo LTR keeps one of two LTRs of different length: either length change is solo (benchmark bug 1)."""
    from ltrkin.annot import Element
    from ltrkin.reads import Site
    el = Element("x", "c", 1000, 14000, "+", (1000, 2429), (13844, 14000))   # LTRs 1,429 and 156 bp
    st = Site(el, 5)
    L = 13000
    assert st.classify_delta(-(L - 1429)) == "S" and st.classify_delta(-(L - 156)) == "S"
    assert st.classify_delta(-(L - 800)) == "S"
    assert st.classify_delta(0) == "F" and st.classify_delta(-(L + 5)) == "E"
    assert st.classify_delta(-3000) == "O"


def test_anchor_inside_deletion_is_invalid():
    """A read whose anchor falls inside a large alignment deletion lacks that sequence (benchmark bug 2)."""
    from ltrkin.reads import in_deletion
    hdr = pysam.AlignmentHeader.from_dict({"SQ": [{"SN": "c", "LN": 100000}]})
    a = pysam.AlignedSegment(hdr)
    a.reference_id, a.reference_start, a.query_sequence = 0, 1000, "A" * 210
    a.cigarstring = "100M2000D100M10D10M"
    assert in_deletion(a, 1500) and in_deletion(a, 3099)
    assert not in_deletion(a, 1050) and not in_deletion(a, 3150) and not in_deletion(a, 3205)  # 10-bp deletion ignored


def test_deletion_at_interval():
    from ltrkin.reads import deletion_at
    hdr = pysam.AlignmentHeader.from_dict({"SQ": [{"SN": "c", "LN": 100000}]})
    a = pysam.AlignedSegment(hdr)
    a.reference_id, a.reference_start, a.query_sequence = 0, 1000, "A" * 200
    a.cigarstring = "100M2000D100M"
    assert deletion_at(a, 1500) == (1100, 3100) and deletion_at(a, 1050) is None and deletion_at(a, 3150) is None


def _site():
    from ltrkin.annot import Element
    from ltrkin.reads import Site
    # element 10,000-20,000; LTRs 500 bp: left LTR ends at a = 10,500, right LTR starts at b = 19,500
    el = Element("x", "c", 10000, 20000, "+", (10000, 10500), (19500, 20000))
    return Site(el, 5)


def _aln(start, cigar):
    hdr = pysam.AlignmentHeader.from_dict({"SQ": [{"SN": "c", "LN": 100000}]})
    a = pysam.AlignedSegment(hdr)
    a.reference_id, a.reference_start, a.mapping_quality = 0, start, 60
    a.cigarstring = cigar
    a.query_sequence = "A" * a.query_length
    return a


def test_junction_read_with_internal_deletion_is_full():
    """A read of a full allele with a >= 50-bp deletion just past the LTR still crosses the junction (v0.1 known
    issue: such reads were dropped because the base 100 bp into the internal region lay inside the deletion)."""
    from ltrkin.reads import _one_sided
    st = _site()
    # 2 kb of left flank, the whole left LTR, 20 bp internal, 80-bp deletion, 400 bp internal
    x = _aln(8000, "2000M500M20M80D400M")
    assert _one_sided(st, None, "c", [x], "L") == "F_left"


def test_solo_like_read_is_not_full():
    """A read that jumps from the LTR over the internal region (deletion) is not full-junction evidence."""
    from ltrkin.reads import _one_sided
    st = _site()
    x = _aln(8000, "2000M500M8990D50M")          # LTR, then deleted internal region and right LTR
    assert _one_sided(st, None, "c", [x], "L") != "F_left"
    y = _aln(8000, "1950M3000D300M")             # deletion over the junction (another structure)
    assert _one_sided(st, None, "c", [y], "L") is None or _one_sided(st, None, "c", [y], "L") != "F_left"


def test_low_mapq_only_is_no_call():
    """No informative read but reads placed with low MAPQ: a no-call, not a confident N/N (mappability)."""
    gt, gq, lls, mu = call({"F": 0, "S": 0, "E": 0, "lowq": 6}, RATES, _M(), 0.02)
    assert gt == "./." and gq == 0
    gt, gq, lls, mu = call({"F": 0, "S": 0, "E": 0, "lowq": 0}, RATES, _M(), 0.02)
    assert gt == "N/N"                         # no reads at all: the site is missing from both haplotypes


def test_phase_lower_bound_in_likelihood():
    """Two distinct haplotypes carrying the full element tip a borderline depth call to F/F (moderate weight:
    PH_ERR 0.05, so clear depth evidence still wins)."""
    c = {"F": 30, "S": 0, "E": 0}                    # F/N expects 24, F/F 48 reads
    assert call(c, RATES, _M(), 0.02)[0] == "F/N"
    assert call(dict(c, hap_F=2), RATES, _M(), 0.02)[0] == "F/F"
    gq0 = call({"F": 20, "S": 0, "E": 0}, RATES, _M(), 0.02)[1]
    gq2 = call({"F": 20, "S": 0, "E": 0, "hap_F": 2}, RATES, _M(), 0.02)[1]
    assert gq2 < gq0                                 # conflicting phase evidence lowers confidence


def test_duplicate_sample_names_get_file_names(data, tmp_path):
    """Two BAMs with the same read-group SM (read sets of one plant) become two samples named after their files."""
    b1, b2 = str(tmp_path / "first.bam"), str(tmp_path / "second.bam")
    for src, dst in ((data["full"], b1), (data["primary"], b2)):
        pysam.samtools.addreplacerg("-r", "ID:rg1", "-r", "SM:plant", "-o", dst, src, catch_stdout=False)
        pysam.index(dst)
    out = str(tmp_path / "multi")
    main(["genotype", "-r", data["ref"], "-a", data["gff"], "-o", out, "-t", "2", b1, b2])
    samples = {r["sample"] for r in csv.DictReader(open(out + ".genotypes.tsv"), delimiter="\t")}
    assert samples == {"first", "second"}
    hdr = [ln for ln in __import__("gzip").open(out + ".vcf.gz", "rt") if ln.startswith("#CHROM")][0].split("\t")
    assert len(set(hdr[9:])) == 2


def test_boundary_tolerance_without_tsd():
    """Empty and solo windows widen only by the requested extra (annotation error learned from the sample)."""
    from ltrkin.annot import Element
    from ltrkin.reads import Site
    el = Element("x", "c", 10000, 20000, "+", (10000, 10500), (19500, 20000))
    st = Site(el, 5)
    d = -(10000 + 5) + 80
    assert st.classify_delta(d) == "O"
    assert st.classify_delta(d, extra=60) == "E"
    assert st.classify_delta(0, extra=200) == "F" and st.classify_delta(400, extra=200) == "O"   # full unaffected


def test_boundary_tolerance_learned():
    """Exact ends -> no widening; offsets of ~40 bp at TSD-less elements -> about 3 x 40."""
    from ltrkin.annot import Element
    from ltrkin.reads import Site
    from ltrkin.genotype import boundary_tolerance, relabel_other
    sites, ev = {}, {}
    for i in range(30):
        el = Element(f"e{i}", "c", 10000, 20000, "+", (10000, 10500), (19500, 20000))
        sites[i] = Site(el, 5)
        exp = sites[i].delta["E"]
        ev[i] = {"E": 0, "S": 0, "O": 3, "other_delta": [exp + 40 * (-1) ** i] * 3, "es_delta": []}
    tol, n = boundary_tolerance(ev, sites)
    assert n == 30 and 100 <= tol <= 140
    assert relabel_other(ev, sites, tol) == 90 and ev[0]["E"] == 3 and ev[0]["O"] == 0
    exact = {i: {"E": 3, "S": 0, "O": 0, "other_delta": [], "es_delta": [("E", sites[i].delta["E"])] * 3}
             for i in range(30)}
    assert boundary_tolerance(exact, sites)[0] == 0


def test_site_calibration_recovers_haplotype_depth():
    """Full-read counts at sites with an empty/solo allele fix the per-haplotype depth at element sites, whatever
    the genome-wide estimate (which hemizygous sequence and overdispersion bias)."""
    import numpy as np
    from ltrkin.model import site_calibration
    rng = np.random.default_rng(3)
    rates = {"F": 1.5, "S": 1.0, "E": 1.0}
    recs = []
    for i in range(60):            # F/E sites: one full haplotype at d = 13
        recs.append(({"F": int(rng.poisson(13 * 1.5)), "S": 0, "E": int(rng.poisson(13))}, rates, "F/E", 60))
    for i in range(200):           # F/F sites carry no calibration information
        recs.append(({"F": int(rng.poisson(26 * 1.5)), "S": 0, "E": 0}, rates, "F/F", 60))
    d, k, n = site_calibration(recs, _M(d_hap=9.0))
    assert n == 60 and abs(d - 13) < 1.0 and k >= 100      # Poisson counts: little overdispersion
    assert site_calibration(recs[:20], _M()) is None       # too few sites: keep the genome-wide depth


def test_genotype_prior_learns_frequencies():
    """EM recovers genotype frequencies from per-site likelihoods; ties then follow the common genotype."""
    import math
    from ltrkin.model import genotype_prior, genotypes
    gts = genotypes(2)
    common = {g: (0.0 if g == "F/F" else -8.0) for g in gts}       # 80 sites clearly F/F
    rare = {g: (0.0 if g == "F/N" else -8.0) for g in gts}         # 20 sites clearly F/N
    tie = {g: (0.0 if g in ("F/F", "F/N") else -8.0) for g in gts} # a site that cannot tell them apart
    lp = genotype_prior([common] * 80 + [rare] * 20, gts)
    assert abs(math.exp(lp["F/F"]) - 81 / 110) < 0.02 and abs(math.exp(lp["F/N"]) - 21 / 110) < 0.02
    gt, gq, lls, mu = call({"F": 30, "S": 0, "E": 0}, RATES, _M(), 0.02, lp)
    assert max(tie, key=lambda g: tie[g] + lp[g]) == "F/F"
    assert genotype_prior([common] * 40 + [rare] * 9, gts) is None    # < 5 sites per class (50): flat prior
