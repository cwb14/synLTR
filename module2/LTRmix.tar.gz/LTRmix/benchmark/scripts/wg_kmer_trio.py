#!/usr/bin/env python3
"""Annotation-free comparator for any trio: the ltrmix single-copy k-mer statistic on whole assemblies (chromosomes
only). For trio R,S,D it counts, on D's 100-kb windows, the 21-mers present once in every genome that carries them and
shared by D with R only or with S only; D = (R - S) / (R + S) with a 5-Mb block jackknife. Holds at most three
genomes in memory (~130 GB with a 3.7-Gb genome)."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import argparse
import sys
import time

import numpy as np

sys.path.insert(0, "/data2/chris/maize_introgression/LTRmix")
sys.path.insert(0, "/data2/chris/maize_introgression/benchmark/scripts")
import ltrmix  # noqa: E402
from wg_kmer import read_chroms  # noqa: E402

T0 = time.time()


def log(m):
    print(f"[wg_kmer_trio {time.time() - T0:7.0f}s] {m}", file=sys.stderr, flush=True)


def load(path, label, win):
    seqs = read_chroms(path, label)
    if not seqs:
        sys.exit(f"ERROR: no '{label}_chrN' sequences in {path}")
    names, chunks, offs = [], [], [0]
    for c in sorted(seqs, key=lambda x: int(x.split("chr")[-1])):
        s = seqs[c]
        for w in range(0, len(s), win):
            chunks.append(s[w:w + win])
            names.append((c, w, min(w + win, len(s))))
            offs.append(offs[-1] + len(chunks[-1]))
    seq = np.frombuffer(b"".join(chunks), np.uint8)
    del seqs, chunks
    keys = ltrmix._keys_of(seq, np.asarray(offs, np.int64), ltrmix.K, ltrmix.RBITS)
    del seq
    keys.sort()
    u, st = ltrmix._runs(keys, ltrmix.RBITS)
    log(f"{label}: {len(names)} windows, {len(keys):,} k-mers")
    return dict(names=names, keys=keys, u=u, st=st)


def jack(a, b, blk):
    ub, inv = np.unique(blk, return_inverse=True)
    A, B = np.bincount(inv, a, len(ub)), np.bincount(inv, b, len(ub))
    D = (A.sum() - B.sum()) / (A.sum() + B.sum())
    jk = np.array([((A.sum() - A[i]) - (B.sum() - B[i])) / (A.sum() + B.sum() - A[i] - B[i]) for i in range(len(ub))])
    se = np.sqrt((len(jk) - 1) / len(jk) * ((jk - jk.mean()) ** 2).sum())
    return D, se, len(ub)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--genome", action="append", required=True, metavar="LABEL=FASTA",
                    help="assembly with seqids LABEL_chrN (others ignored); one per genome")
    ap.add_argument("--trio", action="append", required=True, metavar="R,S,D",
                    help="test whether R or S shares more with D (counted on D's windows); repeatable")
    ap.add_argument("--win", type=int, default=100_000, help="window size [100000]")
    ap.add_argument("--block", type=int, default=5_000_000, help="jackknife block size [5000000]")
    ap.add_argument("--out", required=True, help="output prefix: PREFIX.tsv (one row per trio), PREFIX.<trio>.tsv")
    a = ap.parse_args()
    fa = dict(g.split("=", 1) for g in a.genome)
    trios = [tuple(t.split(",")) for t in a.trio]
    for t in trios:
        if len(t) != 3 or any(x not in fa for x in t):
            sys.exit(f"ERROR: trio {t}: give R,S,D, each a --genome label")
    cache = {}
    rows = []
    for i, (R, S, D) in enumerate(trios):
        need = {R, S, D}
        for g in [g for g in cache if g not in need]:     # keep at most the three genomes of this trio
            del cache[g]
        for g in (D, R, S):
            if g not in cache:
                cache[g] = load(fa[g], g, a.win)
        d = cache[D]
        i1 = ltrmix._merge_idx(d["u"], cache[R]["u"])
        i2 = ltrmix._merge_idx(d["u"], cache[S]["u"])
        T = ltrmix._tally_single(d["keys"], d["st"], i1, cache[R]["st"], i2, cache[S]["st"], len(d["names"]),
                                 ltrmix.RBITS)
        tag = f"{R}_{S}_{D}"
        with open(f"{a.out}.{tag}.tsv", "w") as f:
            f.write(f"chrom\tstart\tend\tonly_{D}\twith_{R}\twith_{S}\twith_both\n")
            for (c, s, e), t in zip(d["names"], T):
                f.write(f"{c}\t{s}\t{e}\t" + "\t".join(map(str, t)) + "\n")
        blk = np.array([f"{c}:{s // a.block}" for c, s, _ in d["names"]])
        Dv, se, nb = jack(T[:, 1].astype(float), T[:, 2].astype(float), blk)
        rows.append((R, S, D, int(T[:, 1].sum()), int(T[:, 2].sum()), int(T[:, 3].sum()), Dv, se, Dv / se, nb))
        log(f"D({R},{S};{D}) = {Dv:+.4f} +- {se:.4f} (Z = {Dv / se:.1f}; {T[:, 1].sum():,} vs {T[:, 2].sum():,})")
    with open(f"{a.out}.tsv", "w") as f:
        f.write("R\tS\tD\tkmers_R_D\tkmers_S_D\tkmers_all3\tD_kmer\tSE\tZ\tn_blocks\n")
        for r in rows:
            f.write("\t".join(str(x) if not isinstance(x, float) else f"{x:.6g}" for x in r) + "\n")
    log("done")


if __name__ == "__main__":
    main()
