### Task 15: Stability: route, flank cap, block size

**Files** (in `benchmark_pav/plan3/real/stability/`): `{mm2,cap5k}/views/main`, `block/`, `RESULTS.md`; and
`real/memo.md` (append).

- [ ] **Step 1: Route and cap.** Make views `--trio B73,TIL01,TIL18` on `mm2/geno` and `cap5k/geno`, and run
  `compare_papers.py --run <view> --prefix <variant>` on each. Report, beside view `six/views/main`:
  - D_pav, dD;
  - n informative, spacing;
  - window r at 1 and 10 Mb;
  - resolved fractions;
  - per-block wall time and peak RSS (`/usr/bin/time -v`), and per-pair wall times from the genotype log.
- [ ] **Step 2: Block size.** In copies `block/b{1,2,5,10,20}` of view `six/views/main`, run
  `ltrpav-stats --trio B73,TIL01,TIL18 --block-size {1000000,2000000,5000000,10000000,20000000}`. In copies of
  `six/views/all`, rerun the direction rows. Report D_pav Z, dD Z and the direction Z under each.
- [ ] **Step 3: `RESULTS.md`.** One table, "varied and reported, not tuned" (DESIGN 10.4). Any change of verdict under a
  variant is stated plainly.
- [ ] **Step 4: Memo.** Append dates, commands and outputs to `real/memo.md`.

---

