# Task 9 report

## Part A (Steps 1-3, eval_run.py on Task 8's toy runs)

Status: **done**, including the controller's rulings I4, I3 and bins (progress.md "Task 9: Ruling"; see "Rulings
applied" below). evalib + tests (TDD), RULES.md (dated, sha256 below; untouched by the rulings), eval_run.py run on
both toy copies: every field filled or NA with a reason, score parity equal on both.

### Rulings applied (after the first hand-back)
- **I4 (head-to-head):** the painting is scored whenever the inferred recipient is A1 (identified), whatever the sister
  and donor. `wrong_trio` (= inferred scope is not A1,B1;C1) is a flag only. `wrong_recipient` is the brief's (R not
  A1, or a "sheet order" tie): recall 0, AUROC/precision/FDR NA. Exercised in-process: A1,B1;C1 -> 0/0, scored
  (AUROC 0.598228); A1,C1;B1 -> wrong_recipient 0, wrong_trio 1, scored as painted (on main there is no such
  painting: AUROC NA "no painted element for this trio", recall 0.0 from the empty painting).
- **I3 (sister-discovered truth D):** an A1 (B1) element counts as present in C1 only when C1 holds it P and
  `sim/C1.gff3` lists its eid (rule 8's "annotated intact copies"); blocks stay on each sister's own coordinates.
  New field `truth_d.sister_discovered.present_in_C1`. Plain csv join (GFF3 Names parsed directly) reproduces the
  counts: trio RD 33, SD 43. Values: null toy 41/23, D +0.281 (z 2.09, 43 blocks; was 51/29, +0.275);
  trio toy 33/43, D -0.132 (z -1.00, 44 blocks; was 41/49, -0.089). Donor-discovered truth D unchanged.
- **Bins:** recall by true length in informative loci (length / the painting's spacing_mean) on [0,1), [1,3),
  [3,10), [10,30), [30,inf) (`LOCI_BINS`), a named reporting heuristic stated in the docstring; stored as
  `accuracy.recall_by_loci.<all|q05>.<0-1|1-3|3-10|10-30|30-inf>.{n, found, recall}` beside `true_tracts`. In the
  wrong-recipient head-to-head (recall 0), the bins use A1's spacing_mean from main's A1,B1;C1 painting (the roles
  view has no A1 painting then). Rebinning the per-tract arrays independently gives the same counts (trio main:
  33/3, 4/0, 1/0, 0, 0).
- Also: AUROC NA reason "no painted element for this trio" when a trio's posterior is empty.
- Not touched: RULES.md (sha256 unchanged), evalib.py, the tests; sim/memo.md is Part B's (the bins belong there too).

Scratch: `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t9a/`
(toy copies in `runs/{null_s101,fn0.2_f0.18_r1}`, copied with `cp -a` from `.../scratchpad/toy2/runs/`; the originals
have no `eval/` and are untouched; QA scripts in `qa/`).

### Files
All under `/data2/chris/maize_introgression/benchmark_pav/plan3/`:

| File | Lines | sha256 |
|---|---|---|
| `common/evalib.py` | 322 | `f9f61a20734b5a4ca93245d6a7bea12ee83874334642e7f4e81b6dee516ea3da` |
| `common/test_evalib.py` | 151 | `cdb676bf3d8a577455376613cb88d478ab1e84773725de3f08f5ba94d7c65d56` |
| `sim/RULES.md` (read-only) | 74 | `4111826d6374508d9ffcd285a5f5ca5d3ffa9ece970290869caced3d0290a293` |
| `sim/eval_run.py` (executable) | 1093 | `145049f2c5d506c01c840db2effdc3122bffa23d63dbc35dbcb4963261af702a` (after the rulings) |

Not touched: `sim/memo.md`, `run_one.sh`, `run_grid.sh`, `common/env.sh` (Task 8 Part B edited env.sh at 01:37 and the
memo at 01:49 while I worked; eval_run.py ran with the new env.sh), `plan3/real/`, `plan3/sim/runs/` (the pilot's
`null_s101`, `f0.18_Ta5000_r1` exist; not opened), `main3*`, the repo (`git status` clean). The `.ruff_cache` dirs my
lint runs created were removed; no `__pycache__`/`.pytest_cache` written (env.sh's PYTHONDONTWRITEBYTECODE,
`-p no:cacheprovider`). Nothing installed.

### Step 1-2: TDD evidence and test output
Command (from `plan3/`): `. common/env.sh && python -W error -m pytest -q -p no:cacheprovider common/test_evalib.py`.
1. Tests written first (`common/test_evalib.py`: the brief's 8 tests plus `test_d_jackknife_blocks_never_span_sequences`).
   Run with no module: `ModuleNotFoundError: No module named 'evalib'` (collection error).
2. Stub `evalib.py` (every name raising NotImplementedError): **`9 failed in 0.23s`** (each test red on its own call).
3. Implementation: **`9 passed in 0.85s`**; final run under `-W error`: **`9 passed in 0.82s`**.
   `ruff check --no-cache --line-length 120` clean, run from each file's own directory (ruff's first-party detection of
   `evalib`/`make_grid` depends on the cwd; from `plan3/` it asks for another import grouping).
4. env ltrmix (no PYTHONPATH) imports evalib without ltrpav (`'ltrpav' in sys.modules` False) and runs auroc,
   tract_fdr, recall_by_length: Part B's eval_ltrmix.py can use it. Only `truth_d`/`d_jackknife` import the snapshot
   (lazily: its `stats.jackknife`, `block_ids`, `d_ratio`, and `common.why`/`common.guard`, the tool's testability rule).

Exact values tested: auroc 1.0 / 0.5 (all tied) / 0.0 / 0.875 (a partial tie) / nan (one class, empty); bp_overlap 5
(merged first: 20 not 25; touching 0; unsorted input); recall: 60-kb tract half covered -> 50k-200k found 1 of 1,
30,001-90,000 not found, two pieces reaching half found, another sequence not; precision 0.5 (bp 60,000, bp_true
30,000); tract_fdr (1, 3), touching (1, 1), none (0, 0); dfoil_direction C>A, A>C, A>C (P4=>P2 with p34 A),
unresolved (ancestral and "or" labels), none, ValueError on P5; truth_d 6 RD / 2 SD in 4 blocks -> D 0.5, n 8,
n_counted 9 (one uninformative), nblocks 4, se sqrt(1/12), z sqrt(3); outgroup-present element dropped, and without the
rule it enters (7/2, D 5/9, se sqrt(4/5 x 420/4900)); an empty class -> se, z nan, why "no S+D locus"; a counted element
without truth -> ValueError; d_jackknife one block per sequence, equal pseudovalues -> "the block pseudovalues do not
vary"; resign -z / z / nan; match_by_coords 10 bp match, 11 bp not, other sequence not, 2 unmatched, one-to-one
closest-first.

### Step 3: RULES.md
- `plan3/sim/RULES.md`, written **2026-11-13 01:47:41 EST** (mtime), dated "2026-11-13" in its header, before any run
  was scored (eval_run.py did not exist yet; no eval.json anywhere). Read-only (`chmod a-w`).
- **sha256 `4111826d6374508d9ffcd285a5f5ca5d3ffa9ece970290869caced3d0290a293`** (eval.json records it under
  `scripts.RULES.md`).
- Body = brief lines 110-172 copied with `sed` (no retyping); `diff` of the body minus the two R2 lines against the
  brief: identical. Header: date, "no rule changes after this date", NA-with-reason (R2), source.
- R2 sentence, rule 7's first sub-bullet: "(R2) Only the label of each prediction is predicted: a code with chance signs
  (`00+0`, `0-0-` in `direction_predictions.tsv`) still predicts "none"."
- Not in `sim/memo.md` (R1: Part B's). **Part B: add the date and sha256 to the memo.**

### eval_run.py
`. common/env.sh && python sim/eval_run.py RUN [--threads N (1-16, default 8)] [--coords-check] [-v]` -> `RUN/eval/
eval.json` (atomic tmp + rename) and `RUN/eval/score/<X>__<Y>.{score,confusion}.tsv` (`ltrpav-sim score`). Exit 1 with
one line on a missing input, a parity mismatch, an unexplained NA, or ltrpav not from the snapshot (checked:
`/nonexistent` -> "missing input .../sim.done", rc 1; `env -u SNAP` -> "ltrpav is not the snapshot's", rc 1).
Run time: null toy 6.9 s wall / 114 MB, trio toy 3.1 s / 108 MB (36 and 9 `ltrpav-sim score` calls, 8 at a time).

Reuse (R4): `stats.read_stats` (sentinel `part` rows skipped), `stats.block_size`, the jackknife/guard via evalib,
`make_grid.COLUMNS`/`scenario`, `popmodel.PULSES`, `score.STATES/CLASSES/TIER_SETS`, `read_samples`, `read_elements`,
`annotation.gff3.load_gff3`, `trio.GRADIENT/NOT_TESTABLE`, `direction.STATS`, `catalog.AGE_LABELS`, `Q_TRACT`/`Z_SIG`,
`SLOP_TSD_MULT * TSD_DEFAULT` (10 bp). NA reasons for nan se/z come from the tool's own stats.tsv note
("not testable by the block jackknife: ..."); skipped analyses take their findings.txt line as the reason.

How each brief item is read (interpretations flagged with **I**):
- **Design:** the grid row from `sim.done` (line 2, tab-split; cross-checked against params.json's f and pulse),
  scenario (`make_grid.scenario`), fractions.tsv per genome (fraction and lifted_fraction), A1's true tracts,
  `true_direction` (from PULSES: C>A, C>A1, C1>A1 -> "C>A"; A>C, A1>C1 -> "A>C"; f 0 -> "none").
- **Calibration (main):** D_pav per stratum (all, K=0, 0<K<0.01, K>=0.01, high_tier, nested_collapsed,
  no_outgroup_filter): D, se, z, n (informative), n_RD, n_SD, n_counted (the n_RD row's n); dD (D_pav_gradient); f4 with
  C2 (f, se, z, n, num, den) beside A1's fraction and lifted fraction; n counted and n informative.
- **Roles (roles):** the one roles row on {A1,B1,C1} -> R,S;D and source; sister_pair_ok, donor_ok, recipient_ok.
  **I1** true recipient: A1 for pulses into A1's lineage; f 0 -> NA; A>C / A1>C1 -> NA ("the true recipient is the
  donor-side genome, outside the sister pair; roles orient only within it"). **I2** source "sheet order" (a tie) =
  recipient not identified (recipient_ok false, wrong_recipient 1).
- **Truth D:** brief's block rule over every genome of the sheet (outgroup included, as Catalog.lengths). Donor-
  discovered: C1's annotated elements (the simulator's GFF3 names; genotyped names checked equal), R and S resolved,
  with and without O1 E; blocks on C1's element midpoints; every counted element in the jackknife (as the tool).
  Sister-discovered (LTRmix's D_ins loci): A1's annotated elements with truth state in C1 present (P/S/T) and in B1 E,
  against B1's with C1 present and A1 E; only these loci are counted (as LTRmix's x/1-x jackknife). **I3** blocks for
  the sister-discovered set lie on each sister's own coordinates: a C1 copy reading S or T has no position in C1's
  truth, so LTRmix's donor-coordinate blocks cannot be reproduced for all loci (named simplification; the genomes'
  coordinates differ by insertion growth, a few percent).
- **Head-to-head (roles):** inferred recipient for {A1,B1,C1}; scored from roles' `posterior.A1.tsv`/`tracts.A1.bed`
  filtered to sister B1, donor C1. **I4** scored only when the inferred trio is exactly A1,B1;C1: `wrong_recipient`
  (brief: R not A1, or unidentified) plus `wrong_trio` (also a wrong sister pair/donor, e.g. A1,C1;B1, which would paint
  A1 against B1); either gives recall 0 (bp and per bin), AUROC/precision/FDR NA with the reason. Exercised in-process
  (`qa/h2h_paths.py`): A1 inferred -> wrong 0/0, accuracy identical to models.main; A1,C1;B1 -> wrong_trio 1, recall 0.
- **Painting scores (head-to-head and models):** AUROC of `post` vs "element midpoint inside a true A1 tract" (all
  painted elements of the trio); bp precision/recall for all tracts and q <= 0.05; recall_by_length and
  precision_by_length (brief's bins 0-50k, 50k-200k, 200k-1M, 1M-inf) for both; tract FDR at q <= 0.05 (counts + ratio);
  excess beside A1's true fraction; per true tract arrays (length_bp, covered_bp_all, covered_bp_q05, spacing_mean_bp)
  for recall by length in informative loci. **I5** painting accuracy is scored wherever A1 has true tracts (pulses
  C>A, C>A1, C1>A1, f > 0), not only `C>A`: `design.pulse` lets summarize keep the brief's set. Models also carry
  e0/e1, emission, `degenerate` (e1_RD > 0.99 and e0_RS > 0.99), n_tracts, n_tracts_q05, n_decoy_tracts, excess,
  posterior means, pi, n_informative, spacing. Tract counts in the files are checked against stats.tsv (error if not).
- **Direction (roles):** the dfoil quartet of taxa A and C (any orientation; P1P2's and P3P4's taxa from the sheet's
  groups), signature, code rebuilt from the four Z at Z_SIG, `dfoil_direction`; prediction = the scenario's label read
  with the probe's quartet (P1 P2 = A1 A2, P3 P4 = C1 C2), `matches`; truth; `call` none / unresolved / right / wrong;
  D_dir (A>C) with n_XY, n_YX. Trio design -> NA.
- **Decision 11 (nodonor):** D_pav all (D, se, z, n, n_RD, n_SD, n_counted), discovery genomes parsed from findings.txt
  ("on N loci <G> discovers") and from the row's `disc=`, with `agree`.
- **Genotypes:** eval_run's own join (calls eid -> element Name -> truth row; missing call = U; "high" tier set:
  non-high = not_high), per state P S T E D O G and classes present/absent, tp/fp/fn/precision/recall, all and high;
  summary counts (n_scored, n_truth_resolved, n_correct_resolved(_high), n_unresolved_call, n_unannotated,
  n_missing_call); pooled, by target (O1 / ingroup), by backbone window (cNN with its region). **I6** LTRquest-annotated
  genomes (sheet annotation not `sim/<X>.gff3`) go to a separate `genotypes.coords` pool via match_by_coords (slop 10),
  with n_unmatched_elements; no `ltrpav-sim score` for them. Checked with `--coords-check` (QA: every genome by
  coordinates, to `eval/coords_check.json`, removed after): null 5,014 matches, all equal to the true eid, 0
  unmatched; trio 2,613, all equal, 0 unmatched; pooled counts identical to the eid join on both.
- **Identity (kind null):** identity_split s and its se, n_pairs, true s = 2 mu t_bc from params.json (0.0036).
- **Realism:** qc.tsv per-pair fractions (all pairs) and A1>C1 beside main3's B73->TIL18; outgroup_conflict per
  genome; D_pav counted and informative per Mb of A1's genome; painting n_informative, spacing_median; annotated and
  alive elements per Mb; the brief's main3 references verbatim.
- `scripts`: sha256 of eval_run.py, evalib.py, make_grid.py, RULES.md, eval_ltrmix.py (NA until Part B writes it).

### eval.json fields and NA reasons per toy
Top level: run, run_dir, created, snapshot, scripts, design, calibration, roles, block_rule, truth_d, head_to_head,
models, direction, decision11, genotypes, identity, realism, elapsed_s, na (path -> reason). Field list (`<..>` =
repeated key):
- design: name, scenario, kind, design, per_taxon, seed, f, ta, pulse, sub, ne, bottleneck, dropout_A1, dropout,
  windows, regions, true_direction, a1_is_recipient, true_fractions.<label>.{fraction, lifted_fraction, tract_bp,
  lifted_bp, backbone_bp, genome_bp}, A1_true_tracts.{n, bp}, genome_bp.<label>
- calibration: D_pav.<stratum>.{D, se, z, n, n_RD, n_SD, n_counted}, dD.{value, se, z, n}, f4.{f.{value, se, z, n},
  num, den, second_donor, A1_true_fraction, A1_true_lifted_fraction}, n_counted, n_informative
- roles: inferred.{R, S, D, source, scope}, true_sister_pair, true_donor, true_recipient, sister_pair_ok, donor_ok,
  recipient_identified, recipient_ok
- block_rule: smallest_genome_bp, brief_rule_bp, stats_block_size_bp, stats_tsv_block_bp, agree, used_bp, genomes
- truth_d: block_bp, {donor_discovered, donor_discovered_no_outgroup_filter, sister_discovered}.{D, se, z, n, n_RD,
  n_SD, n_counted, nblocks} (+ sister_discovered.blocks)
- head_to_head: inferred_recipient, inferred_scope, roles_source, wrong_recipient, wrong_trio, paint.{the model fields
  below}
- models.<main|any|decoy|anydecoy>: scope, n_tracts, n_tracts_q05, n_decoy_tracts, excess, posterior_mean,
  decoy_posterior_mean, pi, e0_RD, e0_RS, e1_RD, e1_RS, emission, degenerate, n_informative, spacing_median,
  spacing_mean, mean_tract_bp, n_posterior_elements, true_fraction_A1, true_lifted_fraction_A1, accuracy.{auroc,
  n_elements, n_elements_inside, true_bp, <all|q05>.{n_called, bp_called, bp_true_positive, bp_precision, bp_recall,
  recall_by_length.<bin>.{n, found, recall}, precision_by_length.<bin>.{n, bp, bp_true, precision}},
  tract_fdr_q05.{n_false, n_called, fdr}, true_tracts.{length_bp[], covered_bp_all[], covered_bp_q05[],
  spacing_mean_bp, found_rule}}
- direction: quartet, p12, p34, signature, code, statistics.<DFO|DIL|DFI|DOL>.{value, se, z, n}, direction,
  prediction.{code, label, direction, matches}, true_direction, call, D_dir.{value, se, z, n}, n_XY, n_YX
- decision11: D, se, z, n, n_RD, n_SD, n_counted, discovery_genomes, discovery_genomes_stats, agree
- genotypes: eid.{genomes, pooled, by_target.<O1|ingroup>, by_window.<cNN>(+region)} each {<all|high>.<label>.{tp, fp,
  fn, precision, recall}, summary.{n_scored, n_truth_resolved, n_correct_resolved, n_correct_resolved_high,
  n_unresolved_call, n_unannotated, n_missing_call, correct_resolved_frac, unresolved_frac}}; coords (same, plus
  n_unmatched_elements, slop_bp, match_equals_name); parity.{pairs, equal, checked, pooled_tp_fp_fn, pooled_summary}
- identity: s, se, true_s, true_s_brief, n_pairs
- realism: qc_pairs.<X>Y>.{frac_P..frac_U, resolved_frac, high_frac}, A1_to_C1, outgroup_conflict.<genome>.{frac_E, n},
  D_pav_counted(_per_Mb_A1), D_pav_informative(_per_Mb_A1), A1_genome_Mb, paint_n_informative,
  paint_spacing_median_bp, elements.<genome>.{annotated, annotated_per_Mb, alive_per_Mb}, main3.{...}

NA counts after the rulings: **null_s101 45** (unchanged), **fn0.2_f0.18_r1 106** (86 + 20:
`{head_to_head.paint, models.<4>}.accuracy.recall_by_loci.<all|q05>.{10-30, 30-inf}.recall` "no true tract in this
bin"). Lists below are from before the rulings; nothing else was added or removed.

**null_s101 (45 NA):**
- calibration.D_pav.K=0.{D, se, z}: not testable by the block jackknife: no A1+C1 and no B1+C1 locus (stats.tsv note)
- calibration.dD: Age gradient of D_pav(A1,B1;C1) skipped: no informative locus at K=0
- design.{pulse, ta}: no pulse: f = 0; design.{sub, ne, bottleneck}: not set in the grid row; design.dropout_A1: not
  set (A1 has --dropout 0.1)
- genotypes.coords: no genome annotated by an annotation other than the simulator's GFF3
- genotypes.eid.{pooled, by_target x2, by_window x5}.high.{T, O, G}.precision (24): no T/O/G call (high): the engine
  gives tier high to no T, O or G call on these runs
- head_to_head.paint.accuracy, models.<4>.accuracy: no true A1 tract: f = 0; head_to_head.{wrong_recipient,
  wrong_trio}: no true A1 tract (f = 0)
- roles.{true_recipient, recipient_ok}: no gene flow (f = 0)
- scripts.eval_ltrmix.py: not written yet (Task 9 Part B)

**fn0.2_f0.18_r1 (86 NA):**
- calibration.D_pav.K=0.{D, se, z} and calibration.dD as above
- calibration.f4.{f, num, den, second_donor}: f4-ratio skipped: no second donor (findings.txt; trio design has no C2)
- decision11: kind dropout: no nodonor view; direction: design trio (one genome per taxon); identity: kind dropout
- design.{sub, ne, bottleneck}: not set in the grid row
- genotypes.coords, genotypes...high.{T,O,G}.precision (24) as above
- head_to_head.paint.accuracy.{auroc, all/q05.bp_precision, all/q05.precision_by_length, tract_fdr_q05,
  true_tracts}: recipient B1 inferred, not A1; ...recall_by_length.1M-inf.recall (x2): no true tract in this bin
- models.<4>.accuracy: q05.bp_precision "no called tract (q <= 0.05)", tract_fdr_q05.fdr "no tract at q <= 0.05",
  q05.precision_by_length.<4 bins> and all.precision_by_length.1M-inf (+ main 200k-1M) "no called tract in this bin",
  all/q05.recall_by_length.1M-inf "no true tract in this bin"
- scripts.eval_ltrmix.py as above

Independent checks of the values (trio toy): bedtools 2 (env bioinfo) intersect of merged called vs merged true tracts
reproduces bp precision/recall for all four models exactly (main 302,537 / 1,227,724 / 3,251,230 -> 0.246421 /
0.093053; any 0.249590 / 0.182661; decoy 0.429661 / 0.126849; anydecoy 0.376809 / 0.228392) and recall by length
(main 0/23, 3/11, 0/4); scipy `mannwhitneyu` reproduces AUROC to all digits (main 0.598228, decoy 0.600132); a plain
csv join reproduces truth-D counts (outgroup rule: 415 counted, 31 RD, 39 SD; without: 617, 41, 50).

### Score parity
- After the rulings (rerun): null_s101 36 pairs equal, fn0.2_f0.18_r1 9 pairs equal.
- null_s101: **36 pairs, equal** (tp/fp/fn for P S T E D O G present absent x all/high, per pair and pooled;
  n_scored, n_unannotated, n_missing_call per pair). Pooled: n_scored 30,084, n_unannotated 3,222, n_missing_call 0.
- fn0.2_f0.18_r1: **9 pairs, equal**. Pooled: n_scored 7,839, n_unannotated 1,272, n_missing_call 0.
- Negative check (`qa/negative.py`): one tampered `ltrpav-sim score` file (A1__B1 E high tp + 1) stops with
  `score parity: A1__B1 state E tier set high: eval_run tp/fp/fn [171, 8, 39] vs ltrpav-sim score [172, 8, 39]`.
  `finalize` refuses a nan or None without a reason ("unexplained NA at a.b").
- Toy genotype readouts (pooled, high tier): null P precision 0.9977 (11,919/27), E 0.9953 (7,861/37); recall P 0.912,
  E 0.813.

### Block rule (R4)
The brief's rule `min(5 Mb, max(smallest // 100, 10 kb))` and `stats.block_size` (BLOCK_BP 5e6, BLOCK_FRAC 100,
BLOCK_MIN 1e4, over Catalog.lengths = every genome of the sheet, the outgroup included) are the same rule; eval.json
computes both plus the stats.tsv `jackknife block_bp` row: null 140,296 = 140,296 = 140,296 (smallest C2 14,029,639);
trio 147,709 = 147,709 = 147,709 (smallest A1 14,770,988). `agree` true on both; truth D uses the brief's (`used_bp`).

### Toy-scale artifacts (reported, not tuned to)
- Few loci per block: D_pav 46 informative loci in 92 blocks (null), 46 in 93 (trio); K=0 stratum empty on both, so dD
  is NA; sister-discovered truth D 80 loci in 46 blocks.
- The trio toy (f 0.18, Ta 5000, C>A) reads D_pav -0.17 (Z -0.96) and roles infers B1 as recipient (wrong_recipient 1).
  Truth agrees in sign: donor-discovered truth D -0.114 (31 vs 39), sister-discovered -0.089, and the simulator's own
  carrier table -0.072 (90 A1+C1 vs 104 B1+C1 insertions): the realized signal on 7.5 Mb is below the noise. Not a
  tool or scoring error.
- No tract at q <= 0.05 in any model on either toy (q05 precision/FDR NA). Trio-toy painting: AUROC 0.59-0.60, bp
  recall 0.09-0.23, precision 0.25-0.43 (all tracts).
- Null-toy truth D: donor-discovered +0.235 (Z 1.56), sister-discovered +0.275 (Z 2.04): one replicate.
- Realism at toy scale (for Part B's realism step, not a finding): A1>C1 P 0.44, E 0.26, D 0.07, O 0.065, U 0.014,
  resolved 0.785 (main3 B73->TIL18: 0.21, 0.21, 0.22, 0.17, 0.15, 0.46); D_pav informative 3.2/Mb (main3 0.97);
  outgroup conflict 0-0.013 (main3 0.027-0.032); painting spacing median 54.5 kb (main3 84 kb).
- identity (null toy): s 0.00340 (se 0.00054) vs true 0.0036.

### Concerns (and what Part B must know)
1. **eval.json is written whole by eval_run.py** (atomic). eval_ltrmix.py should write its own file (e.g.
   `eval/ltrmix.json`) or merge into eval.json after eval_run; run_one.sh runs eval_run first. eval.json's `scripts`
   records eval_ltrmix.py's sha256 once it exists (NA on the toys).
2. **I5:** painting accuracy is scored for every pulse into A1 (C>A, C>A1, C1>A1). summarize must filter
   `design.pulse == "C>A"` (and kinds) for the brief's head-to-head set and rule 5's "C>A power runs".
3. **I4 (ruled):** scored whenever A1 is the inferred recipient; `wrong_trio` is a flag for summarize to count.
4. **Bins (ruled):** loci bins [0,1), [1,3), [3,10), [10,30), [30,inf) applied; Part B records them in the memo.
5. **I3 (ruled):** present in C1 = P and listed in C1's GFF3; blocks on each sister's own coordinates (named
   simplification).
6. **I6:** LTRquest-annotated genomes go to `genotypes.coords`, kept apart from the parity-checked `genotypes.eid` pool.
   Whether they enter rule 3's pooled genotype bar is for Part B/controller. No grid row is LTRquest-annotated today
   (grid.tsv has no annotation column), so the branch is checked only through `--coords-check`.
7. **I1/I2:** for reverse pulses (A>C, A1>C1) the true recipient and recipient_ok are NA; a "sheet order" roles source
   counts as not identified (wrong_recipient 1).
8. High tier never holds T, O or G calls on these runs (engine property), so high-tier precision of T/O/G is NA with
   that reason; rule 3 reads P and E only.
9. D_pav per Mb uses A1's genome length; main3's 0.97/Mb denominator is not stated (2,041 / 2,182 Mb B73v5 = 0.94;
   / 2,132 Mb chr1-10 = 0.96).
10. Cost at full scale: eval_run uses up to 8 `ltrpav-sim score` processes (`--threads`, max 16); with run_grid's
    `-P 2`, at most 16 concurrently. Toy wall 3-7 s; ~13x the elements at 100 Mb, so roughly 1-2 min per run
    (estimate, not measured). eval/score/ holds 72 small files per 7-genome run.
11. Lint: run ruff from each file's directory (cwd-dependent import grouping).
12. Toy realism differs strongly from main3 (above); the pilot's realism step should check it at full scale.

## Part B (code): eval_run m1/m2, eval_ltrmix.py, summarize.py

Written as the work went (2026-11-13). Scratch:
`/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t9b/` (toy copies
in `runs/{null_s101,fn0.2_f0.18_r1}`, copied with `cp -a` from `scratchpad/toy2/runs/`; QA scripts in `qa/`; Part A's
eval_run.py kept as `qa/eval_run.partA.py`). The pilot (`plan3/sim/runs/`) was not opened.

### eval_run.py fixes (rulings m1, m2)
- **m1:** sister-discovered truth D now blocks each counted locus at the C1 copy of the same eid (C1's truth row,
  the `coords` map donor-discovered truth D already uses; every counted copy is P in C1 and listed in sim/C1.gff3 after
  I3, so it has a C1 position). The docstring's "each sister's own coordinates" simplification and its stale reason
  are gone; eval.json's `truth_d.sister_discovered.blocks` reads "C1's coordinates: the C1 copy of the same eid
  (ruling m1, as LTRmix's D_ins)".
- **m2:** `wrong_trio = not wrong_recipient and scope != "A1,B1;C1"`: recipient A1 identified, trio wrong. The two
  flags never both hold. Exercised in-process (`qa/m2_paths.py`, trio toy): A1,B1;C1 -> 0/0 (scored, AUROC 0.598228);
  A1,C1;B1 -> 0/1 (scored as painted: no painting of that trio on main, AUROC NA, recall 0.0); B1,A1;C1 -> 1/0;
  "sheet order" A1,B1;C1 -> 1/0 (I2).
- Effect on the toys (eval.json diffed field by field against Part A's copies, `qa/diff_eval.py`; nothing else
  changed but the script sha256):
  - null_s101: sister-discovered se 0.134325 -> 0.144446, z 2.0938 -> 1.9471 (D +0.28125, n 64, 43 blocks unchanged);
  - fn0.2_f0.18_r1: se 0.131526 -> 0.133392, z -1.0004 -> -0.9864, blocks 44 -> 51 (D -0.131579 unchanged);
    `head_to_head.wrong_trio` 1 -> 0 (recipient B1 inferred: wrong_recipient alone).
  - These equal the Part A reviewer's C1-coordinate figures (0.1444, 0.1334, 51 blocks).
- **Parity after the fixes:** null_s101 36 pairs equal, fn0.2_f0.18_r1 9 pairs equal (pooled n_scored 30,084 /
  7,839; n_unannotated 3,222 / 1,272; n_missing_call 0). NA counts unchanged: 45 and 106.
- eval_run.py sha256 `6fbe0794b2cfa784949931aef0298f7e8f15aeadb9cbc1957210038b46a2a367` (was 145049f2...).

### eval_ltrmix.py (env ltrmix)
`. common/env.sh && $LTRMIX_PY sim/eval_ltrmix.py RUN [-v]` -> `RUN/eval/eval_ltrmix.json` (atomic), as run_one.sh's
eval step calls it (after eval_run.py). Exit 1 with one line on a missing input or an unexplained NA.
- **Imports:** numpy and evalib (numpy only), plus `ltrpav.constants` (SLOP 10 bp). env ltrmix lacks mappy, so
  `ltrpav.sim` and `make_grid` cannot be imported there. The design (kind, f, pulse, a1_is_recipient, A1's true
  fraction) is read from eval_run.py's `eval/eval.json`, checked against sim.done's run name: one reading of the
  grid row for both tools. NA/finalize are a 30-line copy of eval_run.py's (named in the docstring).
- **Trio:** LTRmix's dir is `ltrmix/` with three libraries and `ltrmix/A1_B1_C1/` with four (labels taken from the
  root's orthologs files). R, S, D come from findings.txt's sister-pair line, checked against the hmm rows' sister and
  donor. `recipient_identified` is false when D_kmer is 0 or nan (R then falls to label order), mirroring I2.
- **D tests:** D_kmer, D_ins, D3_triples, D_self_outgroup (stratum "LTR sites"): D, se, z, nA, nB, nblocks, plus
  `D_A1` and `z_A1` re-signed with `evalib.resign(., R, "A1")` (sim_summary.py). NA reasons follow ltrmix.jackknife's
  cases (no locus, < 3 blocks, SE 0).
- **D_ins young/old:** eval_sim.py's classes, pooled over LTRmix's `D_ins_by_age` strata (LTRmix writes only strata
  with >= 10 loci); D and D_A1, nA, nB, strata used.
- **f-ratio:** `f_ratio_ins` (alpha, se, num, den, nblocks) and `f_ratio_identity` with C2, plus `f_lower_bound`, each
  for LTRmix's R (`for_recipient`), beside A1's true fraction. NA in the trio design (no C2 library), or when C2 fails
  LTRmix's second-donor check.
- **Head-to-head:**
  - for R = A1, per mode (ancestry: ancestry.A1.bed + post_ancestry_<D>; recent: tracts.A1.bed + post_recent_<D>):
    element AUROC, bp precision/recall all and q <= 0.05, recall and precision by length (evalib.BINS), and tract FDR
    at q <= 0.05. Also the hmm row (pi, tract counts, excess, donor_state). Tract counts are checked against the
    hmm row: an error if n_tracts differs; `n_tracts_q05_file` is kept beside the hmm row's count, since the file
    rounds q to 3 digits.
  - R not A1, or not identified: wrong_recipient 1, recall 0 (bp and per bin), AUROC/precision/FDR NA.
  - wrong_trio (m2): recipient A1 with a trio other than A1,B1;C1, scored as painted (I4).
  - A missing elements.A1.tsv is recorded (`elements_file` NA), never an error.
  - **Named convention:** "found" = called tracts cover >= 50% of the true tract (evalib, as for LTRpav). eval_sim.py
    counted any overlap; one definition serves both tools. Element midpoints are 0-based, as in eval_run.py.
- **Presence/absence (DESIGN 10.5):**
  - every ordered pair of LTRmix's libraries: `orthologs.<X>.<Y>.tsv.gz` status against `truth/<X>__<Y>.tsv`;
  - classes present = P S T and absent = E (as ltrpav.sim.score); "unresolved" is a missing call;
  - per pair, pooled, and the pooled truth state x status confusion.
  - **Join:** the truth rows hold the true spans, while the annotation, and so LTRmix's library, is jittered: about 5%
    of records (31-47 per genome) have no exact span in truth. Records therefore join through `sim/<X>.gff3`'s Name
    (the eid; the library's source, via gff3_to_ltrmix.py), as eval_run.py's genotype join does. A library not built
    from that GFF3 (LTRquest) falls back to `evalib.match_by_coords` (slop 10 bp). `join` and `n_unmatched_records`
    are recorded.
  - On both toys the eid join and match_by_coords give identical results (all fields equal), and a plain csv join
    (`qa/pa_check.py`) reproduces all 18 pairs.
  - Beside it, `ltrpav_same_pairs`: LTRpav's present/absent tp/fp/fn (tier sets all and high) on the same pairs, read
    from eval_run.py's `eval/score/<X>__<Y>.score.tsv`. `same_elements` checks that both tools scored the same element
    count per pair (true on both toys).
- **Identity (kind null):** rate_free_split.txt's s, its 95% block-bootstrap bounds, blocks and replicates, the
  mixture-model s, the exit code (with run_one.sh's note), and true s = 2 mu t_bc from params.json. A missing file or
  s line is NA with its reason.
- **Checks of the scored painting path:** neither toy has LTRmix painting A1 with true tracts (the null has no tracts;
  in the trio toy LTRmix chose B1). So a copy of the null toy (`qa/null_scored/`) gets a synthetic `tracts.A1.bed`
  (7 tracts in all 4 length bins), design f 0.18 C>A, and q = 0.01 on 2 tracts per mode.
  - bedtools (env bioinfo) and scipy `mannwhitneyu` (`qa/paint_check.py`) reproduce every count exactly: n called,
    merged bp called, bp TP, recall, found per bin, and FDR 0/2.
  - AUROC: ancestry 0.755749634, recent 0.774939731; 91 elements inside the true tracts.
  - In-process (`qa/mix_paths.py`): as run -> 0/0 scored; A1,C1;B1 -> wrong_trio 1, scored as painted; D_kmer 0 ->
    not identified, wrong_recipient 1, AUROC NA, recall 0.
- **eval_ltrmix.json on the toys** (`qa/pa_check.py`, `qa/paint_check.py`, `qa/mix_paths.py` are the checks above).
  The values are toy-scale artifacts, not findings.
  - **null_s101:**
    - LTRmix's trio is A1,B1;C1 (sister pair and donor right, recipient identified).
    - Z toward A1: D_kmer 0.806, D_ins 0.843 (72 vs 63 loci), D3 1.092, D_self 0.148. D_ins old D +0.054 (n 112).
    - f_ratio_ins 0.125 +- 0.226 (C2), identity ratio 0.347, f_lower_bound 0.202; the truth is 0.
    - rate_free_split: s 0.00112 [0.00097, 0.00337] (5 blocks, 200 replicates), mixture s 0.00357, exit 1; true s
      0.0036.
    - Presence/absence over 12 pairs: LTRmix present precision 0.950, recall 0.505; absent precision 0.378, recall
      0.974. On the same pairs LTRpav (all tiers) scores present 1.000 / 0.959 and absent 0.996 / 0.876.
    - Of LTRmix's 6,940 "absent" calls, 2,403 are truth P. Corrected after review m9: these are LTRmix orthology
      misses, not unannotated copies or annotation jitter (pair A1 -> B1: 82% of the truly-P elements called
      absent are annotated in B1, 95% of those with exact spans; young copies over-represented). This toy-scale
      value stands beside DESIGN 10.1's raw-assembly check (11-12%).
  - **fn0.2_f0.18_r1:**
    - LTRmix's trio is B1,C1;A1 (wrong sister pair; recipient B1), so wrong_recipient is 1 and recall 0.
    - Z toward A1: D_kmer -0.355, D_ins -0.790, D3 -0.363, D_self +0.207. f_lower_bound 0.221 (for B1).
    - Presence/absence: LTRmix present 0.943 / 0.492, absent 0.400 / 0.947; LTRpav (all) present 1.000 / 0.961,
      absent 0.986 / 0.833.
- **NA per toy.** Every NA has its reason in the file's `na` map.
  - **null_s101 (12):**
    - `d_ins_age.young.{D, D_A1, strata}`: no D_ins_by_age stratum of the young class (LTRmix writes strata with
      >= 10 loci).
    - `design.{dropout_A1, pulse, ta}`: eval.json's reasons (not set; no pulse at f = 0).
    - `head_to_head.paint.{ancestry,recent}.accuracy`: no true A1 tract (f = 0).
    - `head_to_head.{wrong_recipient, wrong_trio}`: no true A1 tract (f = 0); the head-to-head scores runs with gene
      flow into A1.
    - `trio.{recipient_ok, true_recipient}`: no gene flow (f = 0).
  - **fn0.2_f0.18_r1 (30):**
    - `d_ins_age.young.*` (3): as above.
    - `f_ratio.{alpha, alpha_identity, den, nblocks, num, se, second_donor}` (7): design trio, no C2 library.
    - `head_to_head.elements_file`: elements.A1.tsv missing (LTRmix paints only its recipient, B1).
    - `head_to_head.paint.<mode>.hmm` (2): no hmm row of A1, for the same reason.
    - `head_to_head.paint.<mode>.accuracy.{auroc, all/q05.bp_precision, all/q05.precision_by_length,
      tract_fdr_q05}` (12): recipient B1 inferred, not A1.
    - `head_to_head.paint.<mode>.accuracy.{all,q05}.recall_by_length.1M-inf.recall` (4): no true tract in this bin.
    - `identity`: kind dropout (rate_free_split runs only for kind null).
- eval_ltrmix.py sha256 `53318469f44dfedd1d3692444ad3181598c94942b031f07c71e9ebd7dbb63e03`. Run time 0.1-0.3 s per toy.
  ruff clean (run from sim/).

### summarize.py (env ltrpav)
`. common/env.sh && python sim/summarize.py [--runs DIR] [--grid TSV] [--out DIR] [-v]`. The defaults are sim/runs,
sim/grid.tsv and sim/tables. It prints every bar (`rule N | item | count of n, estimate [CI] | verdict | reason`) and
exits 1 with one line on an error. Its docstring names every reading.
- **Inputs:**
  - every grid row's `eval/eval.json` and `eval/eval_ltrmix.json`;
  - the `resolution` rows of `views/main/stats.tsv`, read through the snapshot's `read_stats` (ruling "resolution
    rows"), and only for runs whose LTRpav eval is current;
  - `direction_predictions.tsv` (each label read with `evalib.dfoil_direction`, as eval_run.py reads it);
  - `make_grid.scenario` for the scenario names.
- **Guards:**
  - RULES.md must hash to the registered `4111826d...a293`, or summarize stops;
  - an eval.json whose design (f, pulse) disagrees with its grid row stops the run.
- **Missing runs (never imputed):**
  - the grid defines the expected runs. Each run's eval file is classed as absent (no run directory), failed (run.exit
    not 0), unscored (no eval file), stale or ok, separately for LTRpav and LTRmix. `runs.tsv` lists the status of
    every row.
  - **Stale** means the file was made by another eval_run.py, evalib.py or RULES.md (or eval_ltrmix.py), names
    another run, or is older than the step markers of its inputs (sim/geno/views.done; ltrmix.done). This check
    caught my own edit of eval_ltrmix.py once on the toys.
  - A bar is NA ("n runs < required: k of N usable; m missing (absent a, stale s, ...); j NA (reasons)") when any of
    its runs is missing or NA. The exception is a count bar that the present runs already exceed: that is FAIL,
    "decided whatever they read".
- **Readings** (each follows RULES.md and the rulings; listed in the docstring):
  - **Run sets** come from the grid: nulls = kind null (30); bottleneck nulls = bneck with f 0; the C>A power runs
    = kind power with pulse C>A (I5); dropout nulls = dropout with f 0 (20); f 0.18 dropout runs; posctl. The
    head-to-head covers every run with pulse C>A (I5).
  - **Rule 1:**
    - |Z| > 3 is counted over the runs that have a Z, with a Clopper-Pearson 95% interval.
    - The bar applies only to D_pav on the 30 nulls. The other rows are "reported": truth D x3, LTRmix's four D
      (re-signed toward A1, over every null, as sim_summary.py), nodonor, and D_pav on the bottleneck nulls.
    - The no_outgroup_filter stratum stands beside LTRmix's D in null.tsv.
  - **Rule 2:**
    - The 95% chi-square interval of the SD (n - 1 df) must include 1, and |mean| <= 2 SE.
    - It is applied to D_pav, dD, truth D x3 and LTRmix x4. SD(D) is reported against the mean jackknife SE.
  - **Rule 3:**
    - The eid pool (ruling): high-tier tp / (tp + fp) of P and E, summed over every directed pair of every grid run.
    - PASS when both are >= 0.95. The Clopper-Pearson interval is shown but not used.
    - The split by target class and by backbone window (keyed by region across runs) is in genotype.tsv. The coords
      pool is reported apart (Task 10's runs).
  - **Rule 4:**
    - The count is `models.<m>.n_tracts_q05 > 0`, at most 1 of the 30 nulls.
    - The mean of `models.<m>.excess` must lie within 2 SE of 0.
    - For any and anydecoy, the same two tests also run on the 20 dropout nulls.
  - **Rule 5:**
    - The pooled FDR is sum n_false / sum n_called over the C>A power runs. It passes when FDR <= 0.05 and the
      Clopper-Pearson upper bound is <= 0.10.
    - The sign tests use bp recall and bp precision at q <= 0.05, variant against main. They run over the power runs,
      plus the f 0.18 dropout runs for any and anydecoy.
    - A run where either model has no q <= 0.05 tract is NA and dropped, and the NA count is reported (m3). Tied pairs
      are dropped and counted.
    - "Higher" means a one-sided p (variant > default) < 0.05. "Not lower" means the one-sided p for "lower" is
      >= 0.05.
    - Adoption follows RULES.md's clauses: decoy's default-fails-rule-4 clause, both only via anydecoy, otherwise the
      larger median recall gain, and a tie keeps the default.
    - **Named reading:** anydecoy is tested over `any`'s run set.
  - **Rule 6:**
    - Degenerate fits are counted per kind and model (variants.tsv), including the roles painting.
    - If fewer than 10% of main's fits in the C>A power runs are degenerate, the decoy decision is labeled "not
      tested in main3's regime (Plan 4 lead)". The label also appears in the adoption bar.
  - **Rule 7:**
    - The call is eval.json's `direction.direction`. The prediction comes from direction_predictions.tsv, label only
      (R2).
    - Confirmation requires every posctl run (pc_null included) to read its prediction's direction. The consequence
      text is RULES.md's.
    - **Named reading:** a false call in the nulls and the bottleneck nulls is any read other than "none"; directional
      and unresolved reads are counted apart.
    - In the maize-like gene-flow runs (power, reverse, ptlike, bneck with f > 0), wrong-direction calls count as
      false and right ones are reported. The ptlike reads carry the Task 13 note.
    - D_dir is compared with the nulls of its own regime (default Ne: null; bottleneck: bneck f 0; posctl: posctl
      f 0) and labeled exploratory.
  - **Rule 8 (gaps.tsv):**
    - D_pav is compared with donor-discovered truth D, and D_ins (re-signed toward A1, only in runs where LTRmix's
      sister pair is A1, B1) with sister-discovered truth D, per C>A, C>A1 or C1>A1 scenario and for "power (all)".
    - **Named reporting reading:** D_ins / D_pav is the ratio of means over runs, with a percentile bootstrap 95%
      interval (2,000 resamples, seed 1), plus whether 0.66 lies inside it. The verdict is "reported".
  - **Head-to-head (tracts.tsv):**
    - The tools are LTRpav (roles), LTRmix ancestry, LTRmix recent, and LTRpav main/any/decoy/anydecoy with A1 fixed.
    - Accuracy is conditioned on wrong_recipient == 0 (m2). wrong_recipient and wrong_trio are counted, and the
      unconditional recall (a wrong recipient scores 0) is shown beside it.
    - Metrics: mean AUROC; bp precision and recall (all and q05), both as means over runs and pooled; recall and
      precision by length (pooled found/n and bp_true/bp); recall by informative-loci bins (LTRpav); pooled tract FDR
      at q05 with its Clopper-Pearson interval; and the excess.
  - **Power (power.tsv):**
    - Per (f, ta) cell and test (D_pav, no_outgroup_filter, nodonor, LTRmix x4): mean and SD of Z, n with Z > 3, the
      fraction, and for D_pav the mean projected Z `Z_sim * sqrt(2041 / n_sim)`, labeled "projection ... assumes Z
      grows as sqrt(n)".
    - Per ta: a probit maximum-likelihood fit of P(Z > 3) on f, giving a, b, f80 and its profile-likelihood 95%
      interval (chi-square 1 df, b profiled on the log scale, searched within f in [0, 1]).
    - With no MLE (all fail, all succeed, or separation) f80 is NA with its reason, and for separation the bracket.
      With 2 runs per cell, separation is likely on the real grid.
    - LTRmix's power uses only runs where its sister pair is A1, B1 (sim_summary.py); the others count as NA "a flip".
  - **Realism (realism.tsv):**
    - Per kind: the A1>C1 state fractions beside main3's B73->TIL18, D_pav informative per Mb, painting
      n_informative and spacing, elements per Mb, and outgroup conflict (the mean over genomes).
    - The `resolution` rows (resolved_A1, resolved_B1) stand beside qc.tsv's C1>A1 and C1>B1 resolved fractions, with
      the note "not comparable: D_pav's loci (C1's elements with O1 E) vs every C1 element's call".
  - **Dropout (dropout.tsv):** per dropout_A1 x f: the D z values of both tools, LTRmix's sister-pair rate, the
    painting null counts and excess per model, and resolved_A1 - resolved_B1 (the one-sided dropout bias readout,
    review m6).
  - **Decision 11 (decision11.tsv):** nodonor D_pav beside main D_pav for the nulls and each power cell, with the
    discovery genomes and agreement.
  - **LTRmix (ltrmix.tsv):** per scenario: sister-pair and recipient rates, the four z_A1 and D_A1, D_ins young/old,
    f_ratio_ins and f_lower_bound (only where LTRmix's R = A1), A1's true fraction, LTRpav's f4, and
    rate_free_split s against the true s, beside LTRpav's identity_split s.
  - **Genotype (genotype.tsv):** the eid pool and coords pool (pooled, by target class, by window; every state and
    class; precision with its Clopper-Pearson interval; recall), plus "ltrmix pairs": LTRmix's presence/absence
    beside LTRpav's on the same pairs (all and high).
- **Tables written** on the toys (to scratch `tables/`, not sim/tables), rows x columns:
  - null 19 x 14, calibration 9 x 17, power 147 x 21, tracts 6,095 x 6 (long), direction 29 x 26;
  - dropout 72 x 11, variants 64 x 19, genotype 151 x 14, ltrmix 627 x 11, gaps 175 x 10, realism 133 x 12;
  - decision11 57 x 13, plus bars.tsv 56 x 14 and runs.tsv 144 x 9.
  - 1.8 s wall and 157 MB.
- summarize.py sha256 `afd525e1b3588b0677de32deaaed89e6949b81fb76d244fd15ad7e697f8ea792`. ruff clean (run from sim/;
  from plan3/ ruff asks for another import grouping, as Part A noted).

### Tests
`. common/env.sh && python -W error -m pytest -q -p no:cacheprovider sim/test_summarize.py` -> **12 passed in 6.5 s**.
test_summarize.py sha256 `c142be5b937d6b96b862d1a1e0f1ff943ae99bacc23dadf2a14587825872e14a`.
- **Pure helpers:**
  - Clopper-Pearson against closed forms: k = 0 and k = n give 1 - 0.025^(1/n); k = 1 gives lo = 1 - 0.975^(1/30)
    and binom.cdf(1, 30, hi) = 0.025. Pinned values: 0.000844 and 0.1722.
  - Chi-square SD interval: SD exactly 1 over 30 values gives [0.7964, 1.3443]; the calibration verdict changes for
    SD x 1.5 and for mean + 0.5 (2 SE = 0.365).
  - Sign test with NA and tie drops: 6 pairs -> 2 NA, 1 tie, +3 -0, p 0.125; 10 of 10 gives 0.5^10; all NA gives
    p 1.
  - Probit: a synthetic dose-response (a -2, b 10, 13 f values x 400 runs) recovers f80 0.284162 within 0.002. The
    profile interval contains it, is narrower than 0.03, and its ends sit on the chi-square cut (checked by a
    brute-force profile). Separation, all-fail and all-succeed give NA with the reason.
  - The ratio-of-means bootstrap.
  - Every `BAR` text is in RULES.md (whitespace normalized), and RULES.md hashes to the registered sha256.
- **Synthetic eval.json grids through `summarize()`:**
  - **Rule 1:** 1 of 30 -> PASS with the Clopper-Pearson bounds; one file removed -> NA "29 of 30 usable; 1 missing
    (unscored 1)"; a second |Z| > 3 -> FAIL "decided"; a file from another eval_run.py -> stale.
  - **Rule 2:** calibrated / not calibrated, with the interval.
  - **Rule 5 sign tests with NA drops:** 36 power runs, 5 NA pairs (no q <= 0.05 tract in either model), 2 ties,
    +25 -4 -> p = binom.sf(24, 29) PASS. Precision is lower in 20 of 31, p(lower) = 0.075, so "not lower" PASS.
  - **Rule 5 FDR:** decoy 3/340 PASS; any 1/25 = 0.04, but its Clopper-Pearson upper bound 0.2035 > 0.10 -> FAIL.
  - **Rule 5 adoption:** decoy is adopted, and carries rule 6's label.
  - **Rule 6:** 3 of 36 degenerate (8.3%) -> labeled; 4 of 36 (11.1%) -> no label.
  - **Power table:** the cell means, the projection 5 sqrt(2041/500), and a probit separation row.
- **Mutation check** (`qa/mutate.sh`, on scratch copies). All 10 mutations make at least one test fail:
  - Clopper-Pearson alpha not halved; chi-square quantiles swapped; 3 SE; ties counted as gains; NA read as 0;
    probit at 90%;
  - count bar `>=`; the 10% line at 12%; FDR without the Clopper-Pearson bound; m3 ignored.

### Each bar on the toys (bars.tsv; 2 of 144 grid runs present)
- **Verdicts:** 42 NA and 14 "reported"; none PASS or FAIL. Every NA reads "n runs < required" with its counts, as
  expected.
- **Rule 1:**
  - D_pav: 0 of 1 null, CP [0, 0.975], NA (29 missing).
  - Reported rows, 0 of 1 each: truth D x3, LTRmix x4 and nodonor. The bottleneck nulls have 0 of 0.
- **Rule 2:** NA on all 9 items (1 of 30 usable). dD is also NA in the null toy: "Age gradient ... skipped: no
  informative locus at K=0".
- **Rule 3:** P 14,194 / 14,230 = 0.99747 [0.99650, 0.99823]; E 10,264 / 10,320 = 0.99457 [0.99296, 0.99590]. NA:
  2 of 144 runs. These equal Part A's per-toy counts summed.
- **Rule 4:** every model has 0 of 1 nulls with a q <= 0.05 tract. The excess is NA (fewer than 2 runs). The dropout
  nulls are 0 of 20. All "holds the null" verdicts are NA.
- **Rule 5:**
  - FDR: NA (no power run).
  - Sign tests: NA. The any and anydecoy sets show "41 of 42 runs missing; 1 pair NA (no q <= 0.05 tract)": the
    trio toy, ruling m3.
  - Adoption: NA ("undecided: a component of rules 4-5 is NA").
- **Rule 6:** NA (0 of 36 power runs).
- **Rule 7:**
  - posctl confirmation NA (0 of 8), so the consequence is NA.
  - Reported: false calls in the nulls 0 of 1 (0 directional, 0 unresolved); bottleneck nulls 0 of 0; maize-like
    gene-flow runs 0 of 50; PT-like 0 of 3 (with the Task 13 note).
- **Rule 8:** reported, "no interval (< 2 paired runs)". gaps.tsv, null toy: D_pav 0.174 vs donor-discovered truth D
  0.235; D_ins 0.067 vs sister-discovered truth D 0.281 (one replicate).

### Concerns, and what the pilot-scoring dispatch must do
1. **Memo entries (sim/memo.md belongs to Task 8 Part B; not edited here).** The pilot-scoring dispatch adds:
   - RULES.md: dated 2026-11-13, sha256 `4111826d6374508d9ffcd285a5f5ca5d3ffa9ece970290869caced3d0290a293`,
     read-only.
   - The named bins: recall by informative-loci length [0,1), [1,3), [3,10), [10,30), [30,inf) (eval_run.py
     LOCI_BINS); length bins 0-50k, 50k-200k, 200k-1M, 1M-inf (evalib.BINS).
   - The script hashes: eval_run.py 6fbe0794..., eval_ltrmix.py 53318469..., evalib.py f9f61a20..., summarize.py
     afd525e1....
   - The commands: `run_one.sh NAME --from eval` per pilot row (runs eval_run.py, then eval_ltrmix.py), then
     `python sim/summarize.py` (writes sim/tables/).
2. **Pilot scoring steps:**
   - Run `run_one.sh --from eval` on both pilot rows once the pilot's ltrmix step is done (ltrmix.done). Then run
     summarize.py with the defaults.
   - Expect almost every bar NA (2 of 144 runs). With 10 windows, check the realism rows against main3.
   - summarize marks any eval file older than its step markers, or made by other scripts, as stale. A rerun of
     eval_run.py after any code change is required (1-2 min per run).
3. **eval_run.py changed (m1, m2).** Any eval.json made by Part A's eval_run.py (145049f2) is now stale for
   summarize. None exists outside scratch.
4. **Readings that summarize names but RULES.md does not spell out** (no rule or threshold changed):
   - rule 5: anydecoy tested over `any`'s run set; tied pairs dropped;
   - rule 7: a non-"none" read in a null is a false call, with unresolved reads counted apart;
   - rule 8: the bootstrap interval for "reproduces 0.66";
   - LTRmix power and rule 8 use only the runs where LTRmix's sister pair is A1, B1 (flips counted);
   - LTRmix's null bars use every null;
   - a decided FAIL with runs missing.
   - The controller may want to confirm these before the grid is scored.
5. **Probit separation.** With 2 runs per (f, ta) and 6 f values per ta, a 0/1 separation in P(Z > 3) is likely. f80
   is then NA with its bracket, which is honest but uninformative. The pooled-over-ta fit is not a RULES.md item, so
   it is not done.
6. **LTRmix's presence/absence join.** The truth rows hold true spans and the libraries jittered ones, so about 5%
   of records have no exact span in truth. The GFF3-Name (eid) join is exact by construction; match_by_coords (slop
   10 bp) gave identical results on both toys. LTRquest-built libraries (Task 10) fall back to match_by_coords.
7. **LTRmix's "absent" on the toys:** 35% (null) and 30% (trio) of its absent calls are truth P. This is toy-scale
   (few chromosomes, short libraries), so it is not a finding. Note it for the full-scale head-to-head (DESIGN
   10.1's 11-12% raw-assembly check).
8. **eval_ltrmix.py reads eval_run.py's eval.json and eval/score/** (the design and LTRpav's same-pair counts).
   run_one.sh already runs them in that order. eval_ltrmix fails with one line if eval.json is missing or names
   another run.
9. **Not done here (out of scope):** pilot scoring, the memo, sim/tables. No package was installed, and nothing
   outside scratch changed except the 3 new sim/ files and eval_run.py. RULES.md, the pilot, real/, main3/,
   LTRmix/ and benchmark/ were untouched.

### Fix round 1 (review task-9b-review.md: 1 Important, 10 Minor)
RULES.md untouched (4111826d...a293). The pilot (plan3/sim/runs/) was not opened and sim/tables was not written; every
run was on scratch copies (p3t9b/runs, p3t9b/qa/mut2).

**Files now** (plan3/sim/):

| File | sha256 |
|---|---|
| eval_run.py | `6fbe0794b2cfa784949931aef0298f7e8f15aeadb9cbc1957210038b46a2a367` (unchanged) |
| eval_ltrmix.py | `3287f3d0b54871f63dca3bcdfb217827aea4a6796c703ca860a0462ad6fbf285` |
| summarize.py | `c0c9dd3ab598c034ebed4f895acf06a679bab3ef1ed1af0e9c77cbbe48a944bb` |
| test_summarize.py | `4100464d0065f2493335e4c057e08ebb15a49aaba872154439b2f7f090050d6a` |
| test_eval_ltrmix.py (new) | `3b449b85de3b15e17df0f0a97e0a426da7cb74982f44808a3cfd68de4e554ab4` |

**Test line:** `. common/env.sh && python -W error -m pytest -q -p no:cacheprovider sim/test_summarize.py
sim/test_eval_ltrmix.py common/test_evalib.py` -> **36 passed in 16.2 s** (summarize 22, eval_ltrmix 5, evalib 9).
ruff clean on all five sim/ files, run from sim/.

**Mutants: 20 of 20 caught.**
- The reviewer's 10 were reconstructed from the review's list, since their mutant file had been restored to the
  original: rule 3's bar at 0.96, larger median gain swapped, tie rule removed, "both" mapped to any, default-fails
  clause inverted, posctl all -> any, unresolved not counted false, 0.66 -> 0.5, power set widened to the reverse
  runs, rule 4 dropping the dropout nulls. Each makes 1-6 tests fail.
- My round-0 set of 10 still fails 1-3 tests each.
- Harness: `qa/mutate.sh` with `qa/mutations_review.txt` and `qa/mutations.txt`, on copies in `qa/mut2/`.

**Findings:**
- **I1 (fixed): LTRmix's sister-pair fraction is now reported wherever it decides inclusion.**
  - power.tsv: every LTRmix row, cell and probit, carries `n_flip` (runs whose LTRmix sister pair is not A1, B1,
    excluded) and `frac_right_pair` (of the runs with an LTRmix file). The cell's n_na no longer counts flips, and
    its reason names them: "1 flip(s) excluded: 1 of 2 runs with an LTRmix file have sister pair A1, B1 (...)". The
    probit row gives the ta's totals.
  - Rule 8 bar: `count` = n_flip, plus the columns `n_flip` and `frac_right_pair`, and the reason "LTRmix runs with
    sister pair A1, B1: k of n; m flip(s) excluded". The printed line reads "n N paired; m flip(s),
    frac_right_pair x".
  - gaps.tsv's D_ins rows carry the same columns and note. The docstring no longer names a column that did not exist.
  - On the toys, the trio toy's flip (LTRmix B1,C1;A1) shows in gaps.tsv as fn0.2_f0.18 "0 of 1; 1 flip(s)
    excluded".
  - Pinned by `test_rule8_ratio_and_flips` (4 flips of 36: count 4, frac 32/36) and `test_power_ltrmix_flip_columns`.
- **m1 (fixed): the reviewer's probes are now tests**, on a real-grid `World` adapted from their synth.py, with exact
  verdicts:
  - `test_rule3_genotype_bar`: P exactly 0.95 PASS, E 0.949 FAIL, bar FAIL; one run missing -> NA.
  - `test_rule5_adoption_clauses`:
    - all four pass -> "any + decoy (anydecoy)";
    - anydecoy fails rule 4 on the nulls -> any, by the larger gain;
    - equal gains -> default;
    - anydecoy fails only the dropout nulls -> any;
    - 4 of 36 degenerate -> "no label".
  - `test_rule5_default_fails_clause`: main fails rule 4 -> decoy by the clause; decoy's FDR 2/36 (CP 0.187)
    failing -> default.
  - `test_rule5_fdr_boundary_and_sign_test`: FDR 180/3,600 PASS and 181 FAIL; a missing run -> NA. The sign test
    drops 5 NA pairs and 2 ties, +20 -9, p = 0.030714 PASS; precision 20 lower of 29 -> FAIL.
  - `test_rule7_direction`:
    - confirmed with its consequence text;
    - one posctl run missing -> NA;
    - posctl null reads C>A -> not confirmed, also with a run missing (decided);
    - C1>A1 read unresolved -> not confirmed;
    - false calls in the nulls 3 (2 directional, 1 unresolved);
    - gene-flow runs 3 false, 4 right, 2 unresolved, 41 none of 50;
    - PT-like 1 of 3.
  - `test_rule8_ratio_and_flips`: the ratio of means equals the hand value 0.66, with n 32 of 36.
- **m2 (fixed):** the sign tests name each NA pair's reason ("no q <= 0.05 tract (ruling m3) x5; pulse into A1 but
  no tract survived in A1 x1"), pinned in the test. The empty-A1-truth power run edge stays as the review describes
  it: rule 5's FDR is NA there. It is unlikely at full scale; left.
- **m3 (fixed):** decided outcomes are now reported decided.
  - Rule 6: "no label" when k/36 >= 10% already, "label" when (k + missing)/36 < 10%, otherwise NA. Pinned with
    4+1 missing -> no label, 3+1 -> NA, 1+1 -> label.
  - posctl: a present run that misreads gives "not confirmed" whatever the missing runs read.
- **m4 (fixed): staleness.**
  - An absent step marker (sim.done, geno.done, views.done; ltrmix.done for LTRmix) now makes the eval file stale.
    run_one.sh clears a step's marker when a rerun starts, so a failed rerun can no longer be scored from old eval
    files.
  - eval_ltrmix.py now records `inputs.eval.json` (the sha256 of the eval.json it read). summarize marks
    eval_ltrmix.json stale unless that equals the current eval.json's sha256.
  - This is a precise form of the review's run.done suggestion: a LTRmix-only rerun does not invalidate LTRpav's
    eval.json.
  - Pinned by `test_staleness_markers_and_eval_json_tie`.
  - The toys' eval_ltrmix.json were regenerated; a field-by-field diff shows only `inputs` and the script hash
    changed.
- **m5 (left, for the controller):** the sign tests are one-sided (variant > default for recall, variant < default
  for "not lower"). With 36 pairs, one-sided p < 0.05 needs 24 positives and two-sided needs 25. This reading is
  named in the docstring but was not among the readings put to the controller: please confirm.
- **m6 (fixed):** the PT-like bar reads its prediction from direction_predictions.tsv (the Task 13 note only when it
  is "none"). The gene-flow bar counts unresolved and none reads too.
- **m7 (fixed):** quasi-complete separation has its own message: "quasi-complete separation: no MLE (none below
  f = x reached Z > 3, every run above it did, k of n at f = x); f80 lies between <next f below> and <next f
  above>". Pinned.
- **m8 (fixed):**
  - tracts.tsv adds `A1_true_fraction_mean` beside `excess_mean`, over the same runs.
  - gaps.tsv keeps a run in the D_pav vs truth-D comparison when only its LTRmix file is missing. Pinned: D_pav n 36,
    D_ins n 31 with 1 missing.
- **m9 (fixed in the report):** the toy statement now says the absent-but-present calls are LTRmix orthology misses
  (the reviewer's check), not unannotated copies. To be checked at full scale before the presence/absence
  head-to-head is read.
- **m10 (fixed):** new `sim/test_eval_ltrmix.py` (5 tests; it runs in env ltrpav, since eval_ltrmix needs only
  numpy, evalib and ltrpav.constants). It uses a tiny synthetic run whose truth spans sit 1 bp off the annotation:
  - trio and D tests: z_A1, the < 3-block NA reason, D_ins young/old pooling, f_lower_bound, trio-design f-ratio NA;
  - painting: AUROC 0.75 and 1.0 worked by hand, bp precision/recall, the >= 50% found rule, FDR;
  - presence/absence through the eid join: 6/1/0 and 5/0/1, 6 unannotated, confusion;
  - a D_kmer tie -> not identified, wrong_recipient 1, and a missing elements.A1.tsv recorded;
  - rate_free_split parsing, and a missing s line as NA.

**Toy rerun:** summarize on the toys still gives 42 NA and 14 reported, with 2 of 144 runs ok/ok.

**What the pilot-scoring dispatch must know (in addition to the earlier list):**
- Its memo entries use the new hashes above.
- Every pilot run must carry its step markers. run_one.sh writes them, so `run_one.sh NAME --from eval` produces
  usable files.
- Any eval_ltrmix.json made before this round lacks `inputs` and reads as stale.

## Step 4 (pilot scoring)

Done 2026-11-13 03:52-04:15 by the post-pilot dispatch (post-pilot-brief.md). Paths are under
`benchmark_pav/plan3/`. RULES.md is unchanged (sha256 4111826d...a293, r--r--r--). summarize.py is unchanged
(c0c9dd3a). No rule or threshold was added or changed.

### First: the test addition (re-review m1), before scoring
Three tests were appended to `sim/test_summarize.py`, which now hashes 1768cc3b81cb0d0eaaab64ae414d470c1f365aab03006e35c9826f662002325a
(was 4100464d). It is a test-only change.
- **The helper `at_k_se(n, k, scale)`** builds n values with SD exactly `scale` (ddof 1) and mean exactly k SE, where
  SE = scale / sqrt(n). Each test takes k = +1.999, -1.999 (inside the line) and +2.001, -2.001 (outside).
- **`test_two_se_line_helpers`:**
  - `calibration` (rule 2) with SD 1 and n 30: SD, SE 1/sqrt(30) and the mean are pinned. sd_includes_1 is True, and
    mean_within_2se = calibrated = the side.
  - `within_2se` (rule 4) at scale 0.01: mean and SE pinned, ok = the side. It raises on a single value.
- **`test_rule2_mean_half_at_two_se`:** a 30-null synthetic grid through `summarize()`. The D_pav rule-2 bar reads
  "calibrated" inside and "not calibrated" outside, with SD exactly 1. The reason line is pinned too
  ("mean Z +0.365 (2 SE 0.365)").
- **`test_rule4_excess_half_at_two_se`** uses the real-grid `World` (30 nulls, 20 one-sided dropout nulls). No null
  has a q <= 0.05 tract, so the count half passes throughout and "holds the null" moves with the excess half alone.
  - Nulls at +-1.999 / +-2.001 SE, all four models: the excess bar is PASS or FAIL, with estimate = k SE and interval
    (k -+ 2) SE; holds the null is PASS or FAIL.
  - Dropout nulls at the same four points, with the nulls at 0: any and anydecoy flip on their dropout bar and on
    holds the null; main and decoy stay PASS (those nulls are not theirs).
- **Mutants**, on scratch copies (`.../scratchpad/p3post/mut/plan3`, with `p3post/mutate.sh` and `mutations.txt`):

| mutant | old tests (4100464d) | new tests |
|---|---|---|
| within_2se always ok (review) | 22 passed (survives) | 2 failed |
| within_2se SD in place of SE (review) | 22 passed (survives) | 2 failed |
| within_2se at 2.5 SE (review) | 22 passed (survives) | 2 failed |
| rule 2 line at 2.2 SE (review) | 22 passed (survives) | 2 failed |
| rule 2 at 2.5 SE; rule 2 SD for SE; within_2se 2.2 SE; within_2se without abs; within_2se ddof 0 | - | 2-3 failed each |
| rule 4 "holds the null" on the count half alone; rule 2's mean half dropped | - | 1 and 3 failed |

  The reviewer's mutant files had been restored to the original (mut, mut1, mut2 all equal summarize.py), so the four
  were rebuilt from the review's description. All 11 are caught.
- **Test line:** `. common/env.sh && python -W error -m pytest -q -p no:cacheprovider sim/test_summarize.py
  sim/test_eval_ltrmix.py common/test_evalib.py` gives **39 passed in 18.8 s** (summarize 25, eval_ltrmix 5,
  evalib 9). `ruff check --no-cache test_summarize.py`, run from sim/: all checks passed.

### Scoring commands
```bash
cd $P/benchmark_pav/plan3/sim     # detached (setsid -f nohup), one run at a time; 8 score processes each
for n in null_s101 f0.18_Ta5000_r1; do timeout 15m ./run_one.sh $n --from eval --windows 5 --grid grid.tsv; done
. ../common/env.sh && python summarize.py > pilot/summarize.out 2> pilot/summarize.err
```
- Directory check: `--windows 5 --grid grid.tsv` matches sim.done's signature (row text, backbone, windows=5).
- eval took 14 s and 15 s (load ~155), exit 0, run.done written. Log: `sim/pilot/score.{log,status,exit}`.
- Scripts as scored (each eval file records them): eval_run.py 6fbe0794, evalib.py f9f61a20, eval_ltrmix.py 3287f3d0,
  make_grid.py 5c6a541b, RULES.md 4111826d.

### Every field filled, or NA with its reason
- Every None in the four eval files has its reason in the file's `na` map: 0 unexplained, 0 empty reasons.
  - eval.json: 44 NA (null_s101) and 79 NA (f0.18_Ta5000_r1).
  - eval_ltrmix.json: 9 and 14.
- The NA classes:
  - design fields not set (no bottleneck, sub, ne; no pulse at f 0);
  - the K=0 stratum and dD "not testable by the block jackknife" (no B1+C1 locus at K = 0; stats.tsv note);
  - high-tier T, O and G precision "no call" (those states are never high tier);
  - the coords pool (no LTRquest annotation);
  - at f 0: no true A1 tract and no true recipient;
  - in the power run, every q <= 0.05 painting field: no tract at q <= 0.05 in any model or tool, so q05 precision,
    FDR and per-bin precision are NA, while q05 recall is 0.0;
  - per-bin "no true / no called tract in this bin";
  - identity: kind power.
- Score parity (eval_run.py against `ltrpav-sim score`) is equal, per pair and pooled, in both runs.
- summarize: 144 grid runs; ok/ok 2, absent 142. Of the 56 bars, 42 are NA ("n runs < required", with counts) and 14
  are "reported". None reads PASS or FAIL, as expected at 2 of 144.

### Headline per run (50 Mb; one replicate each: readouts, not findings)

| field | null_s101 | f0.18_Ta5000_r1 (C>A, Ta 5000; A1 true fraction 0.196) |
|---|---|---|
| D_pav (main, A1,B1;C1, all) | D -0.003, **Z -0.05**, n 315 | D +0.098, **Z 1.34**, n 286 (projection x sqrt(2041/n): 3.59) |
| D_pav no_outgroup_filter | Z -0.08 (n 436) | Z 1.27 (n 412) |
| truth D: donor / donor, no filter / sister | Z -0.46 / -0.69 / -0.11 | **Z 2.51 / 2.87 / 2.71** (D 0.149 / 0.157 / 0.155) |
| nodonor D_pav (disc C2) | Z -0.58 (n 185) | Z 2.09 (n 161) |
| f4 (C2) | -0.028 +- 0.088 | 0.142 +- 0.072 (true 0.196) |
| roles (view roles) | B1,A1;C1: sister pair and donor right; no true recipient at f 0 | **A1,B1;C1: all right** |
| high-tier precision P / E (eid pool) | **0.99705 / 0.99676** | **0.99692 / 0.99787** |
| painting (LTRpav, roles = main) | recipient B1 painted: NA (f 0); main's fit degenerate (e1_RD 0.990, e0_RS 0.995); 0 q <= 0.05 tracts in all 4 models; excess main +0.002 | **AUROC 0.565**; bp recall 0.177, precision 0.280 (all tracts); 0 q <= 0.05 tracts, so q05 recall 0, precision and FDR NA; excess 0.014; not degenerate (e0_RS 0.980) |
| LTRmix trio and recipient | A1,B1;C1 (recipient A1; none true) | **A1,B1;C1, recipient A1 (right)** |
| LTRmix z toward A1: D_kmer / D_ins / D3 / D_self | 0.73 / 0.89 / -0.35 / 0.16 | **1.45 / 1.94 / 0.98 / 2.33** |
| LTRmix painting, ancestry / recent | NA (f 0); 0 q <= 0.05 tracts | AUROC 0.781 / 0.798; bp recall 0.545 / 0.463, precision 0.431 / 0.524; 0 q <= 0.05 tracts |
| LTRmix f_ratio_ins (C2) | 0.053 +- 0.101 | 0.194 +- 0.078 (true 0.196) |
| direction (DFOIL-alt) | none (predicted none); D_dir -0.225, z -1.81 | none (predicted none; truth C>A); D_dir -0.310, z -2.14 |
| identity s (true 0.0036) | LTRpav 0.00224 +- 0.00066; rate_free_split 0.00078 [0.00037, 0.00237] (mixture 0.00357; exit 1 as expected) | - |

- Rule 3, pooled over the 2 runs (NA: 2 of 144): P 160,122 / 160,606 = 0.99699 [0.99671, 0.99725], E 107,470 /
  107,759 = 0.99732 [0.99699, 0.99762].
- Rule 8 (reported): D_ins / D_pav = 0.070 / 0.098 = 0.70 on the one power run, against the real 0.66. No interval
  (fewer than 2 paired runs).

### Observations for the grid (reported, not tuned; no rule touched)
1. **No q <= 0.05 tract in either tool at f 0.18, Ta 5000**, in any of LTRpav's four models or LTRmix's two modes.
   So the rule 5 FDR and sign tests and the q05 head-to-head will rest on the runs that do call tracts. The all-tract
   readouts are filled.
2. **Painting skill:** LTRpav's element AUROC is 0.565, against LTRmix's 0.78-0.80 on the same run. One replicate.
3. **LTRpav's main fit is degenerate in the null run** (e1_RD 0.990, e0_RS 0.995: rule 6's regime) but not in the
   power run. Rule 6 counts this over the C>A power runs only.
4. **LTRmix's presence/absence at 50 Mb:** 62% of its "absent" calls are truth-present (30,816 of 49,585 in the null;
   30,409 of 48,959 in f0.18). Its present precision is 0.95 with recall 0.49-0.50. LTRpav on the same pairs: absent
   precision 0.996-0.998, present 0.9998-0.99994. At toy scale (review m9) the share was 30-35%, and it rises at 50
   Mb. This needs the m9-style check (orthology misses or annotation) before the presence/absence head-to-head is
   read.
5. **The realism gap** (Task 8 Step 10): the simulations resolve 0.74-0.78 of elements against main3's 0.44-0.52, and
   they have 3.4-4.0x its D_pav informative loci per Mb. The projection column rescales by locus count only.

### Files written by this step
- `sim/runs/{null_s101,f0.18_Ta5000_r1}/eval/` (eval.json, eval_ltrmix.json, score/), eval.{log,time,mem.tsv},
  eval.done, run.done;
- `sim/tables/*.tsv` (15 files);
- `sim/pilot/{summarize.out,summarize.err,score.log,score.status,score.exit}`;
- `sim/test_summarize.py` (3 tests appended);
- sim/memo.md's Task 9 section.
