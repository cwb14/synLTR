# fig1_painting — LTR-RT libraries alone paint B73's mexicana ancestry and its inversions

date: 2026-11-07
purpose: Fig. 1 of the LTRmix benchmark (SPEC.md block "Fig. 1 `fig1_painting`")
env: `source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix` (python 3.11, matplotlib, pandas, numpy,
  scipy, samtools, mafft); fonts Liberation Sans / Liberation Mono registered from /usr/share/fonts/truetype/liberation
inputs (read-only, /data2/chris/maize_introgression): benchmark/results/main3/{elements.B73v5.tsv, blocks.tsv,
  orthologs.B73v5.TIL18.tsv.gz, orthologs.B73v5.TIL01.tsv.gz, benchmark_real.tsv, benchmark_chromosomes.tsv,
  stats.tsv}; benchmark/truth/elai_summary.v5.tsv (B73.amp); run/<G>_LTRs_depth*_clean_ltr.tsv (LTR bounds, TSD,
  K2P, family, domains); inputs/<G>.fa (+.fai) for the triple

## Layout sketches (chosen: 1)
1. Vertical ideograms, examples/fig1 style (chosen)
```
key: P = parviglumis TIL01 | B = B73 | M = mexicana TIL18 ; ticks ; traces ; ribbons ; inverted block
A  chr1        chr2   ...  chr10          (one bp scale, Mb axis at left)
   P  ribbons |[B73]| ribbons  M          B73 drawn as a narrow box holding the traces
   |  ///////|| ~~ ||\\\\\\\\  |          (x = mexicana ancestry 0 -> 1, left -> right: ELAI green, posterior black)
   |  \\\\\\\||  ~ ||////////  |          blue ticks (near-identical to TIL01) on B's P side,
   |  X Inv1n||~~  ||\\\\\\\\  |          vermillion ticks (near-identical to TIL18) on B's M side;
                                          inverted ortholog pairs dark, inverted blocks as bow-ties
B  3-Mb zoom (chr6): TIL01 lane / links (blue = near-identical) / B73 elements by class / traces / links
   (vermillion) / TIL18 lane; every element a box to size, own Mb axis per genome, zoom lines from A
C  one ortholog triple: 5' and 3' junctions at bp (shared TSD), the three copies to scale with every
   differing site, and a bp stretch of the LTR where B73 = TIL18 != TIL01 with the other LTR as outgroup
D  per chromosome: LTR-RT posterior vs ELAI (10 points)   E  Spearman r vs window size, null band
```
Changes after render-inspect rounds (4 rounds): traces in A use the benchmark's 5-Mb windows (r = 0.31), 2-Mb
traces were too jagged to read at 4 Mb/mm; A->B zoom is shown by labeled boxes on all three chr6 genomes instead
of connector lines (lines from chr6 would cross the chr2-chr5 columns); the window correlation got its own letter
(E, skill: one letter per panel) and F (element-level ECDF, AUROC) was added so D-F read as chromosome / window /
element scale; A's key sits in A's empty lower-right corner; D's left axis and F's right edge share B/C's
x = 23 / 169 mm edges.
2. Horizontal rows (one chromosome per row: TIL01 above, B73 center with ticks above/below and traces,
   TIL18 below). Positions read well, but 10 rows x 3 genomes + ribbons need ~180 mm of height and the
   B73-coordinate trace cannot sit next to B73 without crossing a ribbon band; rejected for page budget.
3. Circos (three genomes on a ring, near-identical links as chords, posterior/ELAI as inner rings):
   striking, but positions and inversions are hard to read and the skill keeps position claims linear.
Why 1: every chromosome of all three genomes at one bp scale, with the control (TIL01) a full partner on the
other side of B73; the traces sit inside B73 with the 0 -> 1 axis running from the parviglumis side to the
mexicana side, so a swing of the trace points toward the genome whose ticks cause it; inversions show as twists
of the ribbons themselves.

## Example selection (SPEC rule) and checks
Region for B (rule from SPEC, implemented in `select_example()`; window definition = benchmark/scripts/eval_real.py
`windows()`: non-overlapping windows from 0, length-weighted mean posterior, mean ELAI dosage over >= 5 SNPs):
- 3-Mb windows with >= 30 informative elements (near_donor, donor_only, near_sister, sister_only): 514
- of these with ELAI ancestry (dosage/2) above the genome mean 0.1695: 265
- middle 50% of both posterior (0.275-0.547) and ELAI (0.182-0.257): 67 candidates; 62 outside inverted blocks
  (windows touching an inverted block excluded: the inversion, not ancestry, would drive the view)
- chosen = closest to both medians (percentile distance 0.033): B73 chr6:141-144 Mb, posterior 0.428, ELAI 0.217,
  59 informative of 168 elements; next candidates chr2:57-60 (touches TIL01 inverted block), chr3:201-204
- inside: a 0.45-Mb block (142.39-142.83 Mb) of near_donor/donor_only elements (posterior ~1) flanked by
  near_sister/sister_only blocks (posterior ~0); ELAI 0.27 in the block vs 0.19 / 0.23 on either side
Triple for C (structural checks, `triple_data()`; re-extracted with samtools faidx +-50 bp, mafft G-INS-i):
- window has 5 elements with orthologs in all three genomes: 1 near_donor, 1 near_sister, 3 shared (older);
  C needs B73 = TIL18 != TIL01 sites, so the near_donor one: SIRE (Copia) fam00001
  B73v5_chr6:142407372-142416245 (+) / TIL18_chr6:174620822-174629720 / TIL01_chr6:139673199-139682085
- TSD GCTTA at both ends in all three copies (assembly) = library TSD; 5' flank identical in all three
- ends TG..CA in all three
- self-LTR K2P re-aligned 0.0150 / 0.0158 / 0.0142 vs annotation 0.0142 / 0.0158 / 0.0125 (within 1.96 SE,
  ltrmix SELF_Z rule; SE ~0.0035)
- length 8,874 bp; family median 9,304 bp (18th percentile; long tail = nested composites)
- p-distance B73-TIL18 0.00089 (8 subst.) vs B73-TIL01 0.0084 (75); table div 0.00079 / 0.0083
- polarized LTR sites (other LTR as outgroup, identical in all three copies; ltrmix D_self rule): ABBA 8,
  BABA 0, BBAA 0; TIL01-only 8, TIL18-only 2, B73-only 1
- TIL18 copy flagged nest-inner of a 25-kb annotation (TIL18_chr6:174619446-174644614); its own TSD, ends and
  K2P are intact, the flanks match B73 and TIL01, so it is used

## Commands
```bash
source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix
cd /data2/chris/maize_introgression/benchmark/figures/fig1_painting
python fig1_painting.py -v            # uses ./work caches (~1 min)
python fig1_painting.py --rebuild -v  # clears ./work/*.pkl and work/triple, recomputes everything: 1 min 12 s wall, 1.6 GB RSS (7+ min when the server load is ~150)
# detached on the shared server (session-bound background jobs are blocked here):
setsid -f nohup bash -c 'source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix; \
  timeout 15m python fig1_painting.py --rebuild -v' > work/rebuild.log 2>&1 < /dev/null
```
Triple re-extraction inside the script (flank 50 bp), then mafft G-INS-i on full copies and on the six LTRs:
```bash
samtools faidx inputs/B73v5.fa B73v5_chr6:142407322-142416295
samtools faidx inputs/TIL18.fa TIL18_chr6:174620772-174629770
samtools faidx inputs/TIL01.fa TIL01_chr6:139673149-139682135
mafft --globalpair --maxiterate 1000 --quiet --thread 2 work/triple/{full3,ltrs6}.fa
```

## Outputs
- fig1_painting.pdf: p1 figure (180 x 233 mm), p2 short legend (207 words), p3 long legend (~980 words); text as
  text (fonttype 42, Liberation Sans / Mono embedded; no fallback glyphs)
- fig1_painting.png: 300 dpi, figure only (2125 x 2751 px)
- fig1_painting_numbers.tsv: every legend number with its source (table value or "computed here")
- work/: caches (*.pkl, triple/), working plots (dotplot_check.png, zoom_check.png, plain_check.png) and the
  exploration scripts that produced them (not needed for the rebuild)

## Panels
A: 10 chromosomes x (TIL01 | B73 | TIL18) at one bp scale; one gray line per 1:1 ortholog pair on homologous
   chromosomes (31,314 B73-TIL01, 23,927 B73-TIL18), dark when inside an inverted block, black bow-tie for inverted
   blocks >= 2 Mb; ticks = near_sister (blue, 4,056) / near_donor (vermillion, 3,890); inside B73 the 5-Mb posterior
   (black) and ELAI (green) traces, x = 0 (parviglumis side) to 1 (mexicana side); Inv1n / Inv4m labeled; zoom marks
B: chr6:141-144 Mb, every element of all three genomes to size (rows where overlapping), B73 boxes by class,
   ortholog links (near-identical colored), per-element posterior + per-SNP ELAI on the B73 axis
C: the triple: three copies at one scale (LTRs, domains, TSDs), every substitution vs the B73 copy, the 8
   B73+TIL18 shared-derived LTR sites; bp blocks: 5' junction (TSD), 43-bp 3'-LTR stretch with the 5' LTR as
   outgroup, 3' junction (TSD)
D: per-chromosome posterior vs ELAI (benchmark_chromosomes.tsv); chr5/8/9 filled; chr1 without Inv1n (gray)
E: Spearman r vs window size (benchmark_real.tsv values, reproduced exactly), circular-shift null band (recomputed
   with eval_real.py logic, seed 1, 1,000 shifts)
F: ECDF of element posterior for ELAI dosage >= 1 vs <= 0.2 (+-20 kb, >= 3 SNPs), pooled curve as reference

## Gotchas
- benchmark_real.tsv Inv1n row "TIL18-TIL01: 2 inverted blocks, 48.1 Mb, 238 anchors" sums the Inv1n block
  (TIL18 62.9-99.6 Mb, 21 anchors) and a separate pericentromeric block (TIL18 122.7-134.1 Mb, 217 anchors) caught
  by the +-20 Mb tolerance; the legend states the blocks from blocks.tsv instead. REPORT.md repeats the 48.1/238.
- ELAI B73 dosage > 1.8: 0.75% of called SNPs (688,686 on chr1-10); the SPEC/REPORT 0.6% matches all 877,471 rows
  including missing calls as denominator. Legend uses 0.75% of called SNPs.
- Inside Inv1n (B73 chr1 60.95-108.99 Mb) TIL01 carries the inverted arrangement: 97% of informative elements are
  donor-like (posterior 0.79), ELAI 0.34 (2x genome mean). Without it: per-chromosome rho 0.61 (vs 0.64), window r
  0.25 / 0.31 at 1 / 10 Mb (vs 0.28 / 0.36).
- circular-shift null keeps each chromosome's mean, so it sits above 0 (2.5-97.5%: 0.01-0.07 at 0.1 Mb,
  0.06-0.23 at 10 Mb); drawn as the band in E rather than a line at 0.
- "r" in benchmark_real.tsv is Spearman (eval_real.py shift_test uses spearmanr).
- Liberation fonts lack U+207B/U+2078 (superscript minus/8): legend engine draws ^{...} as raised small text.
- matplotlib itertuples renames the 'class' column; use zip over columns.
- Session-bound background jobs are blocked by a hook here: launch with setsid nohup, wait with Monitor.

## Honesty check (skill): plain plot vs showcase
work/plain_check.png: 5-Mb windows, posterior vs ELAI scatter (Spearman 0.31, Pearson 0.38, n = 431) and both
along the genome. Panel A's traces show the same moderate co-variation (they visibly diverge in many places; the
posterior sits above ELAI); A does not look stronger than the plain plot. Panel B shows a sharp posterior block
while ELAI rises only slightly (0.27 vs 0.19 / 0.23); the legend says so.

## Figure check (answered by the figure agent)
1. Panel A in genome coordinates, every element drawn: yes. A: every 1:1 ortholog pair on homologous chromosomes
   is a ribbon line, every near-identical B73 element a tick (302 near_both not ticked, stated); B: every element of
   all three genomes drawn to size.
2. Raw evidence for a real, typical, verified example: yes. C: base-pair alignment of the triple re-extracted from
   the three assemblies (shared TSD, every substitution, polarized LTR sites); region chosen by the SPEC rule,
   triple passed TSD / ends / self-K2P / length checks (asserted in the script).
3. Control as a full partner at the same scale: yes. TIL01 drawn beside B73 at one bp scale in A and B with its own
   ribbons and links; its copy at the same scale in C.
4. Every null drawn: mostly. E: circular-shift null band + 0 line; F: pooled ECDF (no-information curve). D: the
   chance of the exact lowest-three match (1/120) and rho are in the legend, not drawn (10 points).
5. On-figure text only letters, axis labels, ticks, direct labels, keys, n: yes (n only in F; Inv1n/Inv4m,
   "null", "all", line-end labels are direct labels; one key in A's empty corner).
6. Full-resolution crops clean, one grid, reading order, no empty bands: yes (crops of A left/right, key, B, C,
   D-F inspected at 300 dpi; smallest text 5.5 pt; B, C, D-left and F-right share the x = 23 / 169 mm edges;
   ribbons are a deliberate faint texture, inverted pairs darker).
7. Each panel answers a different question; legend pages follow the rules: yes. A where along the genome +
   inversions; B what one typical region looks like element by element; C the base-pair mechanism; D chromosome
   scale; E window scale vs size; F single elements. Short legend 207 words, long ~980 words, last line Analysis.
