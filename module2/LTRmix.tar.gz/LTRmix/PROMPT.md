# Original request (2026-11-07)

The request that started LTRmix, verbatim:

> Read the two PDF papers here. I ran LTRquest on B73, parviglumis, and mexicana. Im wondering if the admixture/introgressions described in these two papers could have been discovered using LTR-RTs alone. See if you can develop a method to discover/characterize admixture/introgressions using LTR-RTs alone. You may use "ltrharvest_phasing10.py" and/or https://github.com/kjenike/panagram for methodological inspiration (but by no means do you need to use those). Treat the B73/parviglumis/mexicana data as a benchmarking dataset and develop an approach to classify admixture/introgressions using LTR-RTs. Benchmark it fully.

The two papers: Yang N. et al. 2023, Two teosintes made modern maize, *Science* 382:eadg8940
(https://doi.org/10.1126/science.adg8940); Barnes A.C. et al. 2022, An adaptive teosinte *mexicana* introgression
modulates phosphatidylcholine levels and is associated with maize flowering time, *PNAS* 119:e2100036119
(https://doi.org/10.1073/pnas.2100036119).

The plan approved before any code was written, including the benchmark bars fixed in advance, is in `PLAN.md`.
