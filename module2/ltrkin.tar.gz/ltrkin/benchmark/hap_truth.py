#!/usr/bin/env python3
"""Read-independent truth for reference LTR-RTs from a haplotype-resolved assembly pair.

For every intact element annotated on the reference haplotype R, find the state of its orthologous site on the
other haplotype O, from a whole-genome alignment of R (query) to O (target):
  minimap2 -cx asm20 --eqx --secondary=no O.fa R.fa > R_on_O.paf   (asm20: haplotypes of outcrossers diverge)
Two anchor points are lifted from R to O: pL, the last base before the first TSD copy, and pR, the first base after
the second. The allele-length change at the site is delta = |O distance| - |R distance| between the lifted points
(the same quantity a spanning read measures). Junction checks lift the 200 bp on each side of each element end.

States on O (anchors = nearest aligned bases outside the TSDs; "moved" = distance they had to move):
  F  anchors within MOVE, element present (both junctions intact, or both element ends aligned inside
     the O segment), delta ~ 0                                                         (full)            -> F/F
  S  anchors within MOVE, a junction intact, delta in the solo window                 (solo LTR)        -> F/S
  E  anchors within MOVE, delta ~ -(L + TSD): one TSD copy left between the flanks    (empty site)      -> F/E
  Fx anchors within MOVE, element present, other delta (internal indel or nested difference)         -> F/F
  Fn anchors moved further, both element ends aligned inside the O segment (flank differs next to it) -> F/F
  Nd O lacks the element and flanking sequence (deletion larger than the element)                    -> F/N
  Nr O has unrelated sequence instead (no element end aligned)                                        -> F/N
  Nt O carries both flanks elsewhere (rearranged; flank remapping pass)                                unscored
  O  anything else (partial deletion, truncation)                                                     unscored
  U  no colinear pair of anchors within LIMIT                                                         unscored
  X  WGA and the junction test disagree (third pass)                                                 unscored
Tolerances are reported with each call (delta, residuals) so a stricter or looser truth can be rebuilt.
A second, independent line: the LTR-RT annotation of O (if given) at the lifted site.

Optional passes (--ref-fasta R.fa --other-fasta O.fa): (2) elements without an orthologous site have their own
flanks remapped to the whole other haplotype (remap_flanks); (3) the allele junctions themselves are searched in
the other haplotype and the final state needs WGA and junctions to agree (junction_check; column truth_source).
Usage: hap_truth.py --paf R_on_O.paf.gz --gff R.gff3 [--other-gff O.gff3] [--ref-fasta R.fa --other-fasta O.fa] -o truth.tsv
"""
import argparse
import bisect
import gzip
import re
import sys
from collections import defaultdict

import numpy as np

JUNC = 200          # bp on each side of an element end lifted for the junction check
MOVE = 300          # anchors moved further than this to reach an aligned base mean the flanks differ on O
LIMIT = 100_000     # nearest aligned base searched within this distance
TOL_ABS = 30        # length tolerance (bp) of the state windows; assemblies are near base-accurate
TOL_REL = 0.01      # relative tolerance (fraction of the reference allele)
MAX_GAP = 200_000   # lifted anchors further apart than reference span + this are rearranged (U)
FLANK_ID = 10_000   # bp of flank on each side used for the local haplotype identity
FLANK_MAP = 2000    # bp of flank remapped to the whole other haplotype for sites the WGA left unplaced
JX_W = 1000         # bp on each side of an allele junction in the junction queries
JX_SIDE = 200       # aligned bp needed on each side of the junction point
JX_ID = 0.85        # identity (matches / columns incl. gaps) of a junction hit: haplotypes differ by up to 5-7% here
JX_COV = 0.7        # query fraction a junction hit must cover (the junction itself is checked separately)
JX_W_SHORT = 300    # second, short junction query (bp per side) when the long one finds nothing
JX_SIDE_SHORT = 100 # aligned bp needed on each side of the junction in the short query


def op(path):
    return gzip.open(path, "rt") if path.endswith(".gz") else open(path)


def attrs(c):
    d = {}
    for kv in c.strip().strip(";").split(";"):
        if "=" in kv:
            k, v = kv.split("=", 1)
            d[k] = v
    return d


def read_elements(path):
    """Intact elements (two long_terminal_repeat children) -> list of dicts, 0-based half-open."""
    feats, ltrs = [], defaultdict(list)
    with op(path) as fh:
        for line in fh:
            if line.startswith("##FASTA"):
                break
            if line.startswith("#") or not line.strip():
                continue
            x = line.rstrip("\n").split("\t")
            a = attrs(x[8])
            if x[2].lower().endswith("ltr_retrotransposon"):
                feats.append((x[0], int(x[3]) - 1, int(x[4]), x[6], a))
            elif x[2] == "long_terminal_repeat":
                for p in a.get("Parent", "").split(","):
                    ltrs[p].append((int(x[3]) - 1, int(x[4])))
    out = []
    for c, s, e, strand, a in feats:
        ls = sorted(ltrs.get(a.get("ID"), []))
        if len(ls) < 2:
            continue
        tsd = a.get("tsd", "")
        t = len(tsd) if re.fullmatch(r"[ACGTacgt]{3,8}", tsd) else 5
        out.append(dict(id=a["ID"], chrom=c, start=s, end=e, l5=ls[0][1] - ls[0][0], l3=ls[-1][1] - ls[-1][0],
                        lltr=ls[0], rltr=ls[-1], tsd=t, depth=a.get("depth", "."), clade=a.get("clade", "."),
                        family=a.get("family", "."), k2p=a.get("K2P_d", ".")))
    return out


class Rec:
    """One primary PAF record with a parsed CIGAR for query -> target lifting."""
    __slots__ = ("q", "qs", "qe", "strand", "t", "ts", "te", "blen", "mapq", "ops", "qcum", "tcum", "nm_eq", "cg")

    def __init__(self, x):
        self.q, self.qs, self.qe, self.strand = x[0], int(x[2]), int(x[3]), x[4]
        self.t, self.ts, self.te = x[5], int(x[7]), int(x[8])
        self.blen, self.mapq = int(x[10]), int(x[11])
        self.cg = next(f[5:] for f in x[12:] if f.startswith("cg:Z:"))
        self.ops = None

    def parse(self):
        ops, qc, tc = [], [0], [0]
        for n, o in re.findall(r"(\d+)([MIDNSHP=X])", self.cg):
            n = int(n)
            ops.append((o, n))
            qc.append(qc[-1] + (n if o in "M=XI" else 0))
            tc.append(tc[-1] + (n if o in "M=XD" else 0))
        self.ops, self.qcum, self.tcum = ops, qc, tc

    def lift(self, x):
        """Target coordinate aligned to query base x, or None if x is unaligned (inside an insertion)."""
        if not (self.qs <= x < self.qe):
            return None
        if self.ops is None:
            self.parse()
        qo = x - self.qs if self.strand == "+" else self.qe - 1 - x
        i = bisect.bisect_right(self.qcum, qo) - 1
        while i < len(self.ops) and self.ops[i][0] in "DN":   # zero-query-length ops at this offset
            i += 1
        if i >= len(self.ops):
            return None
        o, n = self.ops[i]
        if o == "I":
            return None
        return self.ts + self.tcum[i] + (qo - self.qcum[i])

    def identity(self, x0, x1):
        """(matches, aligned columns incl. gaps) over query [x0, x1) of this record."""
        if self.ops is None:
            self.parse()
        if self.strand == "+":
            a, b = x0 - self.qs, x1 - self.qs
        else:
            a, b = self.qe - x1, self.qe - x0
        a, b = max(a, 0), min(b, self.qe - self.qs)
        m = cols = 0
        for i, (o, n) in enumerate(self.ops):
            q0, q1 = self.qcum[i], self.qcum[i + 1]
            if o in "DN":
                if a < q0 <= b and q0 > a:
                    cols += n
                continue
            lo, hi = max(q0, a), min(q1, b)
            if hi <= lo:
                if q0 >= b:
                    break
                continue
            cols += hi - lo
            if o == "=":
                m += hi - lo
        return m, cols


def load_paf(path, names):
    recs = defaultdict(list)
    with op(path) as fh:
        for line in fh:
            x = line.split("\t")
            if x[0] not in names:
                continue
            if not any(f == "tp:A:P" for f in x[12:]):
                continue
            recs[x[0]].append(Rec(x))
    for v in recs.values():
        v.sort(key=lambda r: r.qs)
    return recs


def nearest(r, x, direction):
    """(query pos, target pos) of the aligned base of record r nearest to x on side `direction` (-1: <= x,
    +1: >= x), or None."""
    if direction < 0 and r.qe <= x:
        y = r.qe - 1
    elif direction > 0 and r.qs > x:
        y = r.qs
    elif r.qs <= x < r.qe:
        y = x
    else:
        return None
    for _ in range(50):                      # step over adjacent unaligned stretches
        tp = r.lift(y)
        if tp is not None:
            return y, tp
        qo = y - r.qs if r.strand == "+" else r.qe - 1 - y
        i = bisect.bisect_right(r.qcum, qo) - 1
        a, b = r.qcum[i], r.qcum[i + 1]      # insertion offsets [a, b)
        lo, hi = (r.qs + a, r.qs + b) if r.strand == "+" else (r.qe - b, r.qe - a)
        y = lo - 1 if direction < 0 else hi
        if not (r.qs <= y < r.qe):
            return None
    return None


def anchors(recs, arr, x, direction):
    """Nearest aligned bases to x on one side, one per record within LIMIT: list of (moved bp, rec, qpos, tpos)."""
    qs, qe = arr
    if direction < 0:
        idx = np.nonzero((qs <= x) & (qe > x - LIMIT))[0]
    else:
        idx = np.nonzero((qe > x) & (qs < x + LIMIT))[0]
    out = []
    for i in idx:
        r = recs[i]
        p = nearest(r, x, direction)
        if p is not None:
            out.append((abs(x - p[0]), r, p[0], p[1]))
    out.sort(key=lambda z: (z[0], -z[1].blen))
    return out[:8]


def classify(el, recs, arrs):
    q, s, e, t = el["chrom"], el["start"], el["end"], el["tsd"]
    L = e - s
    pL, pR = s - t - 1, e + t
    res = dict(o_chrom=".", o_strand=".", o_left=-1, o_right=-1, delta="", moved_left="", moved_right="",
               o_seg="", same_rec=False, junc_left=False, junc_right=False, ends_on_other=0, flank_identity="",
               state="U", note="")
    rq = recs.get(q, [])
    if not rq:
        res["note"] = "no_alignment"
        return res
    cl, cr = anchors(rq, arrs[q], pL, -1), anchors(rq, arrs[q], pR, +1)
    if not cl or not cr:
        res["note"] = "no_left" if not cl else "no_right"
        return res
    best = None
    for ml, rl, ql, tl in cl:
        for mr, rr, qr, tr in cr:
            if rl.t != rr.t or rl.strand != rr.strand:
                continue
            ref_d = qr - ql
            o_d = (tr - tl) if rl.strand == "+" else (tl - tr)
            if o_d <= 0 or o_d > ref_d + MAX_GAP:
                continue
            score = (ml + mr, rl is not rr)
            if best is None or score < best[0]:
                best = (score, rl, rr, ql, qr, tl, tr, ml, mr, o_d - ref_d, o_d - 1)
    if best is None:
        res["note"] = "inconsistent_anchors"
        return res
    _, rl, rr, ql, qr, tl, tr, ml, mr, delta, o_seg = best
    lo_t, hi_t = min(tl, tr), max(tl, tr)
    res.update(o_chrom=rl.t, o_strand=rl.strand, o_left=lo_t, o_right=hi_t, delta=delta, moved_left=ml,
               moved_right=mr, o_seg=o_seg, same_rec=rl is rr)

    def junction(r, x0, x1):
        """No indel > 20 bp between x0 and x1 in record r (nearest aligned bases within 50 bp of each point)."""
        a, b = nearest(r, x0, -1), nearest(r, x1, +1)
        if a is None or b is None or x0 - a[0] > 50 or b[0] - x1 > 50:
            return False
        return abs(abs(b[1] - a[1]) - (b[0] - a[0])) <= 20
    jl = any(junction(r, s - JUNC, s + JUNC) for r in (rl, rr))
    jr = any(junction(r, e - JUNC, e + JUNC) for r in (rl, rr))
    ends = 0
    for x in (s + 50, e - 51):              # element ends (inside the LTRs) aligned inside the other segment
        for r in (rl, rr):
            tp = r.lift(x)
            if tp is not None and lo_t < tp < hi_t:
                ends += 1
                break
    res.update(junc_left=jl, junc_right=jr, ends_on_other=ends)
    m = c = 0
    for x0, x1 in ((max(0, s - t - FLANK_ID), s - t), (e + t, e + t + FLANK_ID)):
        for r in (rl, rr) if rl is not rr else (rl,):
            mm, cc = r.identity(x0, x1)
            m, c = m + mm, c + cc
    res["flank_identity"] = round(m / c, 5) if c else ""
    tol = max(TOL_ABS, TOL_REL * (L + 2 * t))
    lo_s, hi_s = -(L - min(el["l5"], el["l3"])), -(L - max(el["l5"], el["l3"]))
    present = (jl and jr) or ends == 2
    if ml <= MOVE and mr <= MOVE:
        if abs(delta + L + t) <= tol:      # one TSD copy left (any TSD length 0-2t gives -(L + t) +- t)
            res["state"] = "E"
        elif present and abs(delta) <= tol:
            res["state"] = "F"
        elif (jl or jr) and lo_s - tol <= delta <= hi_s + tol:
            res["state"] = "S"
        elif present:
            res["state"] = "Fx"
        elif delta < -(L + t) - tol:
            res["state"] = "Nd"
        else:
            res["state"] = "O"
    elif ends == 2:
        res["state"] = "Fn"                 # present; flanking sequence differs next to it (neighbor polymorphism)
    elif o_seg <= t + TOL_ABS:
        res["state"] = "Nd"                 # other haplotype lacks the element and flanking sequence
    elif ends == 0:
        res["state"] = "Nr"                 # replaced by other sequence (no element end aligned)
    else:
        res["state"] = "O"
    return res


def remap_flanks(els, res, fa, al):
    """Second pass for elements the WGA left without an orthologous site (Nd, Nr, O, U): map each element's own
    flanks (FLANK_MAP bp outside the TSDs) to the whole other haplotype. Both flanks unique and colinear: the
    orthologous site was missed by the WGA chain -> reclassify by delta (note 'remapped'). Both unique but not
    colinear: the other haplotype carries this sequence elsewhere (rearranged) -> 'Nt' (reads of both haplotypes
    map here). Neither maps: absence confirmed (note 'flanks_absent'). Otherwise unchanged (note says why)."""
    def hit(seq):
        hs = [h for h in al.map(seq) if h.is_primary]
        if not hs:
            return None, "none"
        h = max(hs, key=lambda h: h.mlen)
        if h.mapq < 20:
            return None, "repeat"
        if h.mlen / max(1, h.blen) < 0.9 or (h.q_en - h.q_st) < 0.8 * len(seq):
            return None, "weak"
        return h, "ok"
    for el, r in zip(els, res):
        if r["state"] not in ("Nd", "Nr", "O", "U"):
            continue
        c, s0, e0, t = el["chrom"], el["start"], el["end"], el["tsd"]
        L = fa.get_reference_length(c)
        if s0 - t - FLANK_MAP < 0 or e0 + t + FLANK_MAP > L:
            continue
        ls = fa.fetch(c, s0 - t - FLANK_MAP, s0 - t).upper()
        rs = fa.fetch(c, e0 + t, e0 + t + FLANK_MAP).upper()
        (hl, kl), (hr, kr) = hit(ls), hit(rs)
        if hl is None and hr is None:
            if kl == "none" and kr == "none":
                r["note"] = "flanks_absent"
            else:
                r["note"] = f"flanks_{kl}_{kr}"
            continue
        if hl is None or hr is None:
            r["note"] = f"one_flank_{kl}_{kr}"
            continue
        colinear = hl.ctg == hr.ctg and hl.strand == hr.strand
        if colinear:
            if hl.strand == 1:
                li, ri = hl.r_en + (FLANK_MAP - hl.q_en), hr.r_st - hr.q_st
            else:
                li, ri = hl.r_st - (FLANK_MAP - hl.q_en), hr.r_en + hr.q_st
            between = (ri - li) if hl.strand == 1 else (li - ri)
            colinear = -FLANK_MAP < between < (e0 - s0) + MAX_GAP
        if not colinear:
            r["state"], r["note"] = "Nt", "flanks_elsewhere"
            continue
        Le = e0 - s0
        delta = between - (Le + 2 * t)
        tol = max(TOL_ABS, TOL_REL * (Le + 2 * t))
        lo_s, hi_s = -(Le - min(el["l5"], el["l3"])), -(Le - max(el["l5"], el["l3"]))
        if abs(delta + Le + t) <= tol:
            st = "E"
        elif abs(delta) <= tol:
            st = "F"
        elif lo_s - tol <= delta <= hi_s + tol:
            st = "S"
        elif delta < -(Le + t) - tol:
            st = "Nd"
        else:
            st = "O"
        r.update(state=st, note="remapped", delta=delta, o_chrom=hl.ctg, o_strand="+" if hl.strand == 1 else "-",
                 o_left=min(li, ri), o_right=max(li, ri))


def junction_hits_ms(al, fetch, jx_fn):
    """Multi-scale junction search: JX_W bp per side first; if nothing is found, JX_W_SHORT per side (a structural
    difference a few hundred bp from the junction on the other haplotype defeats the long query only)."""
    for w, side in ((JX_W, JX_SIDE), (JX_W_SHORT, JX_SIDE_SHORT)):
        q = jx_fn(w)
        h = junction_hits(al, q, w, side)
        if h:
            return h
    return []


def junction_hits(al, seq, jpos, side=None):
    """Hits of a junction query that contain the junction contiguously: identity >= JX_ID over >= JX_COV of the
    query, >= JX_SIDE aligned bp on both sides of the junction and no indel >= 30 bp within 100 bp of it.
    Returns a list of (contig, target position of the junction)."""
    out = []
    for h in al.map(seq):
        if h.mlen / max(1, h.blen) < JX_ID or (h.q_en - h.q_st) < JX_COV * len(seq):
            continue
        side = JX_SIDE if side is None else side
        if not (h.q_st <= jpos - side and h.q_en >= jpos + side):
            continue
        # walk the alignment in query order (mappy reports the CIGAR along the target; reverse for - strand)
        ops = h.cigar if h.strand == 1 else h.cigar[::-1]
        q, t, ok, tj = h.q_st, 0, True, None
        for ln, op in ops:
            if op in (0, 7, 8):
                if tj is None and q <= jpos < q + ln:
                    tj = t + (jpos - q)
                q += ln
                t += ln
            elif op == 1:
                if ln >= 30 and abs(q - jpos) <= 100:
                    ok = False
                q += ln
            elif op == 2:
                if ln >= 30 and abs(q - jpos) <= 100:
                    ok = False
                t += ln
        if ok and tj is not None:
            pos = h.r_st + tj if h.strand == 1 else h.r_en - tj
            out.append((h.ctg, pos))
    return out


def junction_check(els, res, fa, al):
    """Direct test of the allele junctions in the other haplotype (independent of the WGA chain): the empty-site
    junction (flank + one TSD + flank), and the two flank-element junctions, JX_W bp on each side. Final state:
    WGA and junctions agree -> kept ('confirmed'); WGA without an orthologous site (Nd, Nr, Nt, O, U) but the
    junctions show an empty site or a present element at one locus -> junction state ('rescued'; S/F/Fx split by
    the distance between the two flank-element junctions); disagreement otherwise -> 'X' (conflict, unscored)."""
    for el, r in zip(els, res):
        c, s0, e0, t = el["chrom"], el["start"], el["end"], el["tsd"]
        Lc = fa.get_reference_length(c)
        r["wga_state"] = r["state"]
        if s0 - t - JX_W < 0 or e0 + t + JX_W > Lc or e0 - s0 < 2 * JX_SIDE:
            r["jx"] = "edge"
            continue
        def f_e(w):
            return fa.fetch(c, s0 - w, s0).upper() + fa.fetch(c, e0 + t, e0 + t + w).upper()

        def f_l(w):
            return fa.fetch(c, s0 - w, s0 + w).upper()

        def f_r(w):
            return fa.fetch(c, e0 - w, e0 + w).upper()
        hE, hL, hR = (junction_hits_ms(al, fa, f) for f in (f_e, f_l, f_r))
        r["jx"] = f"E{len(hE)}L{len(hL)}R{len(hR)}"
        Le = e0 - s0
        js = None
        if len(hE) == 1 and not hL and not hR:
            js = "E"
        elif not hE and len(hL) == 1 and len(hR) == 1 and hL[0][0] == hR[0][0]:
            d = abs(hR[0][1] - hL[0][1])            # distance between the element ends on the other haplotype
            tol = max(TOL_ABS, TOL_REL * Le)
            lo_s, hi_s = min(el["l5"], el["l3"]), max(el["l5"], el["l3"])
            if abs(d - Le) <= tol:
                js = "F"
            elif lo_s - tol <= d <= hi_s + tol:
                js = "S"
            else:
                js = "Fx"
        elif not hE and not hL and not hR:
            js = "N"
        r["jx_state"] = js or "?"
        w = r["state"]
        agree = {"E": ("E",), "F": ("F", "Fx"), "Fx": ("F", "Fx"), "Fn": ("F", "Fx"), "S": ("S",),
                 "Nd": ("N",), "Nr": ("N",)}
        if js is not None and js in agree.get(w, ()):
            r["truth_source"] = "confirmed"
        elif w in ("Nd", "Nr", "Nt", "O", "U") and js in ("E", "F", "S", "Fx"):
            r["state"], r["truth_source"] = js, "rescued"
        elif w in ("O", "U", "Nt"):
            r["truth_source"] = "unscored"
        elif js is None:
            r["truth_source"] = "wga_only"         # junction test inconclusive (repetitive or partial): WGA state kept
        else:
            r["state"], r["truth_source"] = "X", "conflict"


def other_annotation(path):
    by = defaultdict(list)
    for el in read_elements(path):
        by[el["chrom"]].append((el["start"], el["end"], el["id"]))
    for v in by.values():
        v.sort()
    return by


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--paf", required=True, help="reference haplotype (query) on other haplotype (target), cg:Z eqx")
    ap.add_argument("--gff", required=True, help="LTR-RT GFF3 of the reference haplotype")
    ap.add_argument("--other-gff", help="LTR-RT GFF3 of the other haplotype (second line of evidence)")
    ap.add_argument("--ref-fasta", help="reference haplotype FASTA (with --other-fasta: flank remapping pass)")
    ap.add_argument("--other-fasta", help="other haplotype FASTA")
    ap.add_argument("-t", "--threads", type=int, default=8)
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    els = read_elements(a.gff)
    recs = load_paf(a.paf, {e["chrom"] for e in els})
    arrs = {c: (np.array([r.qs for r in v]), np.array([r.qe for r in v])) for c, v in recs.items()}
    oth = other_annotation(a.other_gff) if a.other_gff else None
    cols = ["element_id", "chrom", "start", "end", "length", "ltr5_len", "ltr3_len", "tsd_len", "depth", "clade",
            "family", "k2p", "o_chrom", "o_strand", "o_left", "o_right", "delta", "moved_left", "moved_right", "o_seg",
            "same_rec", "junc_left", "junc_right", "ends_on_other", "flank_identity", "state", "note", "other_annot",
            "other_annot_offset", "wga_state", "jx", "jx_state", "truth_source"]
    n = defaultdict(int)
    with open(a.out, "w") as fo:
        fo.write("\t".join(cols) + "\n")
        res = [classify(el, recs, arrs) for el in els]
        if a.ref_fasta and a.other_fasta:
            import mappy
            import pysam
            fa = pysam.FastaFile(a.ref_fasta)
            al = mappy.Aligner(a.other_fasta, preset="asm20", n_threads=a.threads)
            if not al:
                sys.exit(f"cannot index {a.other_fasta}")
            remap_flanks(els, res, fa, al)
            junction_check(els, res, fa, al)
        for el, r in zip(els, res):
            n[r["state"]] += 1
            oa, off = ".", ""
            if oth is not None and r["o_chrom"] != ".":
                lo, hi = r["o_left"], r["o_right"]
                best = None
                for s, e, i in oth.get(r["o_chrom"], ()):
                    if e < lo - 100 or s > hi + 100:
                        continue
                    d = abs(s - (lo + 1 + el["tsd"])) + abs(e - (hi - el["tsd"]))
                    if best is None or d < best[0]:
                        best = (d, i)
                if best is not None:
                    oa, off = best[1], best[0]
            row = [el["id"], el["chrom"], el["start"] + 1, el["end"], el["end"] - el["start"], el["l5"], el["l3"],
                   el["tsd"], el["depth"], el["clade"], el["family"], el["k2p"], r["o_chrom"], r["o_strand"],
                   r["o_left"] + 1 if r["o_left"] >= 0 else -1, r["o_right"] + 1 if r["o_right"] >= 0 else -1,
                   r["delta"], r["moved_left"], r["moved_right"], r["o_seg"], int(r["same_rec"]), int(r["junc_left"]),
                   int(r["junc_right"]), r["ends_on_other"], r["flank_identity"],
                   r["state"], r["note"] or ".", oa, off, r.get("wga_state", r["state"]), r.get("jx", "."),
                   r.get("jx_state", "."), r.get("truth_source", ".")]
            fo.write("\t".join(map(str, row)) + "\n")
    print(f"{a.out}: {len(els)} elements; " + ", ".join(f"{k} {v}" for k, v in sorted(n.items())), file=sys.stderr)


if __name__ == "__main__":
    main()
