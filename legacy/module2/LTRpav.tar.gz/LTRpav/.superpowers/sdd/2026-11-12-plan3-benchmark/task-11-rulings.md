# Task 11: controller rulings (draft; finalize when the grid ends)

These bind as much as task-11-brief.md, and override it where the two conflict.

## R1. Carry-overs from Tasks 6-9 (ledger)
- **The pilot's realism readout:**
  - the simulations are easier than main3: resolved 0.74-0.77 against 0.46, U 1.5% against 14.6%, and 3.6-4x the
    informative loci per Mb;
  - G calls are 5.5-6.1% against 0.02%;
  - the K of outgroup-shared elements is 0.095 against 0.060;
  - there is more nesting.

  SIM_RESULTS.md section 10 names each gap and states its effect. Power is optimistic for the real data beyond the
  locus-count projection. Never present simulated power as transferable without that caveat.
- **LTRmix's "absent" calls:** 62% are truly present at 50 Mb. Attribute them to their causes before the
  presence/absence comparison is read: orthology misses, annotation dropout, S/T states, or library-only intactness.
- **Task 6 C3:** the decoy is used twice, as the emission anchor and as the null. Rule 5's realized FDR is the test.
- **Task 6 m2:** `test_decoy_null_no_tract` cannot fail at toy scale. It is not null evidence.
- **Task 7 m1:** a stats rerun with `--block-size` but without `--identity` deletes identity.tsv. So any block-size
  check runs in its own view.
- **Task 9:**
  - rule 5's sign tests are one-sided (m5);
  - LTRmix power and rule 8 report n_flip and frac_right_pair;
  - NA runs drop from the sign tests, with their counts.
- **The pilot:** neither tool called a q <= 0.05 tract at f 0.18, Ta 5000. Rule 5 may rest on few runs; state the
  counts.

## R2. Code step (Step 4)
- **First commit.** Task 7's review minors m2-m5, a separate commit before any decision commit:
  - the stale-variant rerun advice must not tell users to replace a variant painting with the default;
  - DESIGN 7.4: e* rows are NA when the fit collapsed or the painting was skipped;
  - wrap paint.py:28;
  - a test that `--block-size` reaches direction and identity.
- **Snapshot 2.** If `src/` changed for any reason, these minors included, take snapshot 2 for Tasks 13-16 and check
  that its engine fingerprints equal snapshot 1's.

## R3. Science rules (CLAUDE.md, Biological Analyses)
- Every bar is PASS or MISS by RULES.md as written. Never change a bar or a rule, and never present a null as a
  finding.
- Each MISS gets a dead_ends.md entry, investigated with truth D and the per-pair scores.
- SIM_RESULTS.md ends with the headline test: one sentence on the process, the mechanism, how general it is, and what
  it predicts. A method-validation result may honestly be the outcome; say so plainly.

## R4. Rulings from Part P (2026-11-14; ledger has the reasons)
- Empty A1 truth (f0.02_Ta50_r1, r2): the realized FDR is n_false = n_called (all calls false); recall NA for both
  tools whatever the recipient; rule 5's pooled FDR reads all 36 C>A power runs.
- Presence/absence head-to-head: one binary truth for both tools (present P/S/T; absent E/D/O; G excluded and
  counted), with the strict E-only reading beside it, labeled. The pilot's "62% truth-present" was 62% not-E; the
  truly present share is ~38%.
- LTRmix absent-but-present causes, by the library first: in library but unpaired = orthology miss; not in library:
  S/T, or P = annotation dropout.
- LTRquest runs: a small comparison table (lq/<name> vs runs/<name>) for SIM_RESULTS section 7.
- Rescore: rescore_all.sh --jobs 4, detached.
- Rule 5 with no calls: a variant with no q <= 0.05 tract in any C>A power run has realized FDR 0/0 and
  Clopper-Pearson upper bound 1, so its FDR bar FAILs (MISS in SIM_RESULTS) with that reason, never NA; it is adopted
  under neither clause. On the finished runs this applies to `any` and `decoy`.
- Skipped painting (Part Q): a painting LTRpav records as skipped for the scored scope is scored as zero tracts
  called, accuracy fields NA "painting skipped by LTRpav: <reason>" (the posctl nulls pc_null_r1/r2: no RD locus).
