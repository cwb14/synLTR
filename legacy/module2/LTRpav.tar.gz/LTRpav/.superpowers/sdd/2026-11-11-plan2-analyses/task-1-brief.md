### Task 1: Foundations — dependencies, constants, catalog loader, toy runs

**Files:**
- Modify: `pyproject.toml` (dependencies), `environment.yml`, `environment.lock.yml`, `tests/conftest.py`,
  `docs/DESIGN.md` (section 12)
- Create: `src/ltrpav/analysis/__init__.py`, `src/ltrpav/analysis/constants.py`, `src/ltrpav/analysis/catalog.py`,
  `src/ltrpav/plot/__init__.py` (empty docstring), `tests/catalog_toy.py`, `tests/test_catalog.py`

**Interfaces:**
- Consumes:
  - `outputs.tables.write_loci_tsv`, `write_qc`;
  - `loci.Locus`, `GenomeState`;
  - `elements.Element`, `make_eid`, `read_elements`, `write_elements`;
  - `classify.CALL_COLUMNS`, `genotype.tsv_field`;
  - `samples.Sample`, `read_samples`, `PAIR_SEP`, `seqio.Fasta`;
  - `checkpoint.file_checksum`, `package_fingerprint`, `stage_key`, `STAGE_MODULES` (the engine's per-stage module
    sets).
- Produces, `analysis/catalog.py`:

```python
STATE_CODE = {"P": 1, "S": 2, "T": 3, "E": 4, "D": 5, "O": 6, "G": 7, "U": 8}   # 0 = no call
TIER_CODE = {".": 0, "low": 1, "medium": 2, "high": 3, "annot": 4}
FLAGS = ("inv", "nestB", "host_empty", "inherit", "tsd_match", "solo_tsd", "adjacent", "small_ins", "filler",
         "conflict", "annot_conflict", "no_call")
FLAG_BIT = {f: 1 << i for i, f in enumerate(FLAGS)}   # other flag words are ignored
AGE_LABELS = ("K=0", "0<K<0.01", "K>=0.01")
class AnalysisError(ValueError): ...
@dataclass
class Catalog:
    outdir: Path; samples: list[Sample]; sheet: Path; sheet_sha: str    # sheet path and its sha256
    labels: tuple[str, ...]; ingroup: tuple[str, ...]; outgroups: tuple[str, ...]   # sheet order; role "outgroup"
    annotated: dict[str, bool]; groups: dict[str, str | None]
    seqids: dict[str, tuple[str, ...]]; lengths: dict[str, np.ndarray]   # fai order, from seqio.Fasta (work/fai cache)
    # loci.tsv, merged across discoverers: any-discovery descriptions only
    lid: np.ndarray                    # (n,) str, loci.tsv order
    state: np.ndarray                  # (n, G) uint8 STATE_CODE
    tier: np.ndarray                   # (n, G) uint8 TIER_CODE
    seq: np.ndarray                    # (n, G) int32 fai index; -1 = no coordinates
    start: np.ndarray; end: np.ndarray # (n, G) int64, 1-based inclusive; 0 = none
    strand: np.ndarray                 # (n, G) int8: +1, -1, 0 (unknown or none)
    k: np.ndarray                      # (n, G) float64: a member's K2P, else nan
    flags: np.ndarray                  # (n, G) uint32 FLAG_BIT mask
    member: np.ndarray                 # (n, G) bool: the genome's annotation holds the locus (its discovery)
    eid: np.ndarray                    # (n, G) object: the member eid, else None
    family: np.ndarray; superfamily: np.ndarray; tsd: np.ndarray   # (n,) object, None = unknown (loci.tsv columns)
    length: np.ndarray; ltr_len: np.ndarray       # (n,) int64 (loci.tsv `length`, `ltr_len`)
    top: dict[str, dict[str, str]]     # genome -> member eid -> eid of its outermost annotated ancestor (itself at level 0)
    # each annotated genome A's own calls: pairs/<A>__<B>.calls.tsv.gz joined on eid[:, g(A)] (extra members ignored);
    # A's own column holds its member element (P, tier high); rows where A has no member hold "no call"
    proj: dict[str, np.ndarray]        # A -> (n, G) uint8 STATE_CODE of A's call into each genome; 0 = no call
    ptier: dict[str, np.ndarray]       # same shape: TIER_CODE of those calls
    pseq: dict[str, np.ndarray]        # same shape: int32 fai index of the call's site in that genome; -1 = none
    pstart: dict[str, np.ndarray]; pend: dict[str, np.ndarray]   # same shape: int64, 1-based inclusive; 0 = none
    pstrand: dict[str, np.ndarray]     # same shape: int8, the element's strand at the site (b_strand turned as loci.py does)
    def g(self, label: str) -> int
    def cls(self, label: str) -> np.ndarray   # (n,) int8 from the merged state: 1 = P/S/T, 0 = E, -1 = D/O/G/U
    def mid(self, label: str) -> np.ndarray   # (n,) float64 (start + end) / 2 of the merged site; nan without one
    def pcls(self, disc: str, label: str) -> np.ndarray   # (n,) int8 from proj[disc]: 1 P/S/T, 0 E, -1 D/O/G/U or no call
    def pcls_by(self, gstar: np.ndarray, label: str) -> np.ndarray    # (n,) int8: row i read from genome gstar[i]; -1 if < 0
    def ptier_by(self, gstar: np.ndarray, label: str) -> np.ndarray   # (n,) uint8: likewise from ptier; 0 if gstar[i] < 0
    def proj_site(self, gstar: np.ndarray, label: str) -> tuple[np.ndarray, np.ndarray]
        # (fai index, mid) of label's site in row i's call from genome gstar[i]; (-1, nan) where there is none
def load_catalog(outdir: Path, samples: list[Sample], sheet: Path) -> Catalog
def age_bin(k: np.ndarray) -> np.ndarray     # int8: 0 K == 0; 1 0 < K < AGE_EDGES[1]; 2 K >= AGE_EDGES[1]; -1 nan
def cluster_keys(cat: Catalog, gstar: np.ndarray, rows: np.ndarray) -> np.ndarray
    # object, one per selected row (catalog order): (label of gstar, top eid of that genome's member element)
```

- Produces, `analysis/constants.py`: the block in Step 5.
- Produces, `tests/catalog_toy.py`:
  - `ToyLocus`, `ToyRun` (with `.load() -> Catalog`), `loc`, `write_run`, `simulate_run`, `dmat`, `read_tsv`,
    `GENOMES`, `TRACTS` (Step 3);
  - the conftest fixture `toy_fastas` (session-scoped directory of N-only FASTAs, written once per seqid layout).

- [ ] **Step 1: Branch and environment.**
  - Check the preconditions:
    - `plan1-engine` is the reviewed head of `plan1-final-fixes`;
    - `pgrep -af 'ltrpav|run_variant|bakeoff'` prints nothing;
    - `git status` is clean.
  - Branch: `git checkout -b plan2-analyses plan1-engine`.
  - Run `mamba install -n ltrpav -c conda-forge scipy matplotlib`.
  - Add `scipy` and `matplotlib` to `environment.yml`, and `scipy>=1.11`, `matplotlib>=3.8` to pyproject `dependencies`.
  - Refresh the lock by commit 84c8088's portable procedure:

```bash
mamba env export -n ltrpav | sed -e '/^  - pip:$/,$d' -e '/^prefix:/d' > environment.lock.yml
echo '# ltrpav itself is not locked: install it from this repository into the environment (pip install -e .)' \
  >> environment.lock.yml
! grep -qE '^prefix:|ltrpav==' environment.lock.yml && grep -qE '^  - scipy=' environment.lock.yml
```

  - Leave `ltrpav_bench` untouched (Global Constraints).

- [ ] **Step 2: Write the failing tests** (`tests/test_catalog.py`)

```python
def test_load_roundtrip(tmp_path, toy_fastas):
    run = write_run(tmp_path, [
        loc(10_001, "R:P* S:E D:P* O:E", k=0.0, calls={("D", "S"): "U"}),
        loc(20_001, "R:U S:P* D:P* O:P", k=0.02),
        loc(5_001, "R:P* S:D D:E O:E", seqid="chr2", k=None, length=6000, flags={"S": ["inherit"]}),
        loc(9_001, "R:P* S:P D:G O:U", seqid="chr2", parent=2)], fasta_dir=toy_fastas)
    cat = run.load()
    assert cat.labels == ("R", "S", "D", "O") and cat.outgroups == ("O",) and cat.ingroup == ("R", "S", "D")
    assert cat.sheet == run.sheet and len(cat.sheet_sha) == 64 and cat.tsd[0] == "ACGTA"
    assert cat.cls("S").tolist() == [0, 1, -1, 1] and cat.cls("D").tolist() == [1, 1, 0, -1]
    assert cat.member[:, cat.g("D")].tolist() == [True, True, False, False]
    assert cat.k[0, cat.g("D")] == 0.0 and np.isnan(cat.k[0, cat.g("S")])         # K only for members
    assert cat.flags[2, cat.g("S")] & FLAG_BIT["inherit"]
    assert cat.top["R"][cat.eid[3, cat.g("R")]] == cat.eid[2, cat.g("R")]         # nested in locus 2's element
    assert cat.lengths["R"].tolist() == [1_000_000] * 4
    # the discoverer's own calls: D's call into S is U although the merged S is E (R's call)
    assert cat.pcls("D", "S")[0] == -1 and cat.pcls("R", "S")[0] == 0 and cat.pcls("D", "D")[0] == 1
    assert cat.ptier["D"][0, cat.g("R")] == TIER_CODE["high"]                     # a member's call tier, never "annot"
    assert cat.pcls("S", "R")[0] == -1                                            # S has no member at locus 0: no call
    gstar = np.array([cat.g("D"), cat.g("D"), -1, -1], dtype=np.int16)
    assert cat.pcls_by(gstar, "S").tolist() == [-1, 1, -1, -1]
    seq, mid = cat.proj_site(gstar, "D")
    assert seq.tolist()[:2] == [0, 0] and mid[0] == pytest.approx(10_001 + 149 / 2) and seq[2] == -1

def test_missing_or_mismatched_run(tmp_path, toy_fastas):
    run = write_run(tmp_path, [loc(10_001, "R:P* S:E D:P* O:E")], fasta_dir=toy_fastas)
    loci = run.outdir / "loci.tsv"
    text = loci.read_text()
    loci.rename(run.outdir / "loci.bak")
    with pytest.raises(AnalysisError, match="ltrpav-merge"):
        run.load()
    loci.write_text(text)
    with pytest.raises(AnalysisError, match="X"):
        load_catalog(run.outdir, [replace(s, label="X") if s.label == "O" else s for s in run.samples], run.sheet)
    loci.write_text(text.replace("\tE\t", "\tQ\t", 1))
    with pytest.raises(AnalysisError, match="line 2"):
        run.load()
    loci.write_text(text)
    pair = run.outdir / "pairs" / "D__S.calls.tsv.gz"
    with gzip.open(pair, "wt") as fh:
        fh.write("eid\tstate\n")
    with pytest.raises(AnalysisError, match="D__S.*CALL_COLUMNS"):
        run.load()
    pair.unlink()
    with pytest.raises(AnalysisError, match="D__S"):
        run.load()

def test_age_bin():
    assert age_bin(np.array([0.0, 0.004, 0.01, 0.05, np.nan])).tolist() == [0, 1, 2, 2, -1]

def test_simulate_run_deterministic(tmp_path, toy_fastas):
    a = simulate_run(tmp_path / "a", seed=3, fasta_dir=toy_fastas)
    b = simulate_run(tmp_path / "b", seed=3, fasta_dir=toy_fastas)
    assert (a.outdir / "loci.tsv").read_bytes() == (b.outdir / "loci.tsv").read_bytes()
    cat = a.load()
    assert len(cat.lid) > 4000 and cat.member.any(axis=1).all()     # every locus has a discoverer
    with pytest.raises(ValueError, match="spacing"):                # 998_000 // 4000 = 249 bp < 2 x 150 bp
        simulate_run(tmp_path / "c", seed=3, n_per_seq=4000, fasta_dir=toy_fastas)

def test_analysis_edit_keeps_engine_keys(tmp_path):
    src = tmp_path / "src"
    shutil.copytree(Path(ltrpav.__file__).parent, src / "ltrpav", ignore=shutil.ignore_patterns("__pycache__"))
    prog = ("import ltrpav.checkpoint as c\n"                          # fresh process: fingerprints are cached
            "print(c.package_fingerprint('ltrpav.analysis'))\n"
            "print(' '.join(c.stage_key(s, {}, {}) for s in sorted(c.STAGE_MODULES)))\n")   # every engine stage key
    def prints():
        r = subprocess.run([sys.executable, "-c", prog], env={**os.environ, "PYTHONPATH": str(src)},
                           capture_output=True, text=True, check=True)
        return r.stdout.splitlines()
    a0, e0 = prints()
    with open(src / "ltrpav" / "analysis" / "catalog.py", "a") as fh:
        fh.write("\n# an edit to an analysis module\n")
    a1, e1 = prints()
    assert a1 != a0 and e1 == e0                                    # every engine stage key unchanged
    assert stage_key("stats", {}, {}, fingerprint=a0) != stage_key("stats", {}, {}, fingerprint=a1)
```

- [ ] **Step 3: Write `tests/catalog_toy.py`.**
  - `GENOMES = [("R", "taxR", None, True), ("S", "taxS", None, True), ("D", "taxD", None, True), ("O", "taxO",
    "outgroup", False)]`: label, group, role, annotated.
  - `TRACTS = [("chr1", 100_001, 400_000), ("chr2", 500_001, 800_000), ("chr3", 200_001, 500_000)]`.
  - `ToyLocus`, a dataclass:

```python
@dataclass
class ToyLocus:
    seqid: str; pos: int; states: dict[str, str]                       # loci.tsv (merged) states
    members: frozenset[str] = frozenset()
    k: float | None = 0.01; length: int = 150; ltr: int = 40           # LTRs = the first and last `ltr` bp
    family: str = "famA"; superfamily: str = "Gypsy"
    parent: int | None = None                                          # index of the host locus in the list
    flags: dict[str, list[str]] = field(default_factory=dict)          # genome -> extra flags
    evidence: dict[str, tuple[int, int, int]] = field(default_factory=dict)   # genome -> (dl, dr, b_ins) in pair files
    calls: dict[tuple[str, str], str] = field(default_factory=dict)    # (A, B) -> state of A's call into B
    strand: dict[str, str] = field(default_factory=dict)               # genome -> strand ("+" by default)
    wid: int | None = None                                             # pair-file wid; None: the locus index
```

  - **`loc(pos, spec, seqid="chr1", **kw) -> ToyLocus`.** `spec` is space-separated `G:X`, X a state letter, with `*`
    after it marking a member: `"R:P* S:E D:P* O:E"`. Other keywords go to `ToyLocus`.
  - **Default calls.** A member B's default call is `P`, tier `high` ("annot" is a `loci.tsv` tier, not a call tier); a
    non-member B's default call is its `loci.tsv` state.
  - **`dmat(pairs, default, labels) -> np.ndarray`:** a symmetric (G, G) distance matrix, 0 on the diagonal, `pairs`
    maps `(a, b)` to a distance, everything else `default`.
  - **`read_tsv(path) -> list[dict[str, str]]`:** a header-keyed reader; a leading `#` on the header is dropped.

  `write_run(tmp, loci, genomes=GENOMES, seqids=("chr1", "chr2", "chr3", "chr4"), seq_len=1_000_000, seq_lens=None,
  fasta_dir=None, fastas=None, inversion=None, prefix=False) -> ToyRun(outdir, sheet, samples, loci, truth={})` writes:
  - **FASTAs:** `<fasta_dir>/<layout>/<label>.fa`, N only, written once per layout. `seq_lens` overrides single seqids'
    lengths, and `fastas` (label -> path) overrides whole genomes with real sequences. `prefix=True` names each genome's
    seqids `<label>_<seqid>`.
  - **`samples.tsv`:** relative paths; annotation `ann/<label>.gff3` for annotated genomes (never opened), `.` otherwise.
  - **`loci.tsv`:** through `write_loci_tsv`, lids `L0000001...` in list order. Per genome:

    | case | GenomeState |
    |---|---|
    | member | `P`, tier `annot`, the locus coordinates, strand, `k`, flags |
    | other P/S/T | tier `high`, coordinates, strand |
    | E | tier `high`, the site `pos-5..pos-1`, strand, flags `tsd_match` (+ given) |
    | D | tier `medium`, coordinates |
    | O, G, U | tier `medium` for O, `.` for G and U; no coordinates |

    An `inversion=(label, seqid, a, b)` mirrors that genome's loci whose start lies in `[a, b]`: new start = `a + b -
    end`, new end = `a + b - start`, strand `-`.
  - **`work/elements/<label>.tsv`:** through `write_elements`, one `Element` per member:
    - `eid=make_eid(...)`;
    - LTRs = the first and last `ltr` bp; TSD `ACGTA`;
    - `k`, family and superfamily as given;
    - `parent` = the host locus's member eid in that genome, with `level` set.
  - **`pairs/<A>__<B>.calls.tsv.gz`:** for each annotated A and every other B, one `CALL_COLUMNS` row per A element
    (gzip, `tsv_field` values):
    - the call's state (defaults above, `calls` overrides), tier `high` (`.` for G and U), flags, the B site as in the
      table, `wid`;
    - reason `no_anchor` for U;
    - `dl dr b_ins` from `evidence`, else E `0 0 0`, D `300 0 0`, O `2 -1 500`;
    - `tsd_a` `ACGTA`; other evidence `.`.
  - **`qc.tsv`:** through `write_qc`: `annot_sensitivity 0.9` per annotated genome, and `skipped_malformed_coordinates
    2` for the first one (a reason the loaders emit).
  - **`manifest.json`:** `{}`.

  `simulate_run(tmp, *, seed, tracts=(), inversion=None, p_missing: float | dict[str, float] = 0.15, p_member: float |
  dict[str, float] = 0.9, n_per_seq=1500, k_known=True, prefix=False, fasta_dir=None) -> ToyRun` draws loci with
  `np.random.default_rng(seed)` and writes them with `write_run`. A dict for `p_missing` or `p_member` sets the listed
  genomes; the others keep the default.
  - **Layout:** `n_per_seq` loci per seqid on chr1-chr4 (1 Mb each), at `1001 + j * 998_000 // n_per_seq`, 150 bp each,
    LTRs 40 bp. Spacing must be >= 2 × the element length, else ValueError naming the spacing; `n_per_seq` <= 3000
    keeps 332 bp.
  - **Pattern** over (R, S, D), with the K values each drawn with probability 1/2:

    | pattern | p | K | O |
    |---|---|---|---|
    | 111 | 0.24 | 0.02 | E |
    | 110 | 0.15 | 0.01, 0.02 | E |
    | 101 | 0.06 | 0.004, 0.02 | E |
    | 011 | 0.06 | 0.004, 0.02 | E |
    | 100, 010, 001 | 0.11 each | 0.0, 0.004 | E |
    | old (all four present) | 0.16 | 0.03 | P |

  - **Inside a tract** (an R interval): R's presence := D's presence. A pattern left empty everywhere is dropped.
  - **True states:** a present genome is P (0.9), S (0.05) or T (0.05), drawn once per locus and genome; a member is P;
    an absent genome is E.
  - **Members:** each present annotated genome is a member with probability `p_member[g]`; a locus with no member is
    dropped.
  - **Calls**, the engine's behavior in miniature: each member A's call into each other genome B (members included)
    resolves to B's true state with probability `1 - p_missing[B]`, else U.
  - **`loci.tsv` merges like `loci.py`:**
    - a member is P/annot whatever the calls say;
    - a non-member takes the first resolved call among the members (sheet order), else U.
  - **K:** `k_known=False` sets K to None everywhere.
  - **Truth:** `{"tracts": tracts, "n_rd_tract": <D-private loci copied into R>}`.

  Add the session fixture `toy_fastas` to `tests/conftest.py`: one `tmp_path_factory` directory, shared.

- [ ] **Step 4: Run** `python -m pytest -W error tests/test_catalog.py`. Expected: FAIL (ImportError).

- [ ] **Step 5: Implement.**
  - `src/ltrpav/analysis/constants.py`, with its docstring "Analysis constants; each has a one-line reason. Nothing here
    is tuned to a dataset.":

```python
BLOCK_BP = 5_000_000       # jackknife block: >> LD in outcrossing grasses, hundreds of blocks per genome (LTRmix)
BLOCK_FRAC = 100           # or 1/100 of the smallest genome, so a small genome still gives ~100 blocks (DESIGN 7.3)
BLOCK_MIN = 10_000         # LTRmix's floor on the block size
AGE_EDGES = (0.0, 0.01)    # age bins by LTR-LTR K2P: identical, below 1%, older (DESIGN 7.3: few bins, by LTR differences)
Z_SIG = 3.0                # |Z| >= 3 counts as significant: the bar of every D test in DESIGN 10
P_WARN = 0.05              # conventional level of the sister-pair and lineage-sorting symmetry tests
RESOLVE_WARN = 0.1         # heuristic (LTRmix donor_resolved): warn when two genomes' resolved fractions differ by > 0.1
PI_MAX = 0.5               # donor-like fraction <= 1/2: a recipient more donor-like than sister-like is the donor's sister
BF_TRACT = 3.0             # tract loci need posterior odds >= 3x prior odds (Kass & Raftery 1995, "positive")
HMM_L_GRID = (1e4, 5e7, 41)  # mean tract lengths tried by EM: 10 kb-50 Mb, 41 log steps (LTRmix)
HMM_ITERS = 100            # EM rounds at most (LTRmix)
HMM_TOL = 1e-7             # EM stops when the log-likelihood moves by < 1e-7 of itself (LTRmix)
INV_MIN_LOCI = 5           # heuristic: shortest reversed run reported as an inverted block; named in findings.txt
```

  - `load_catalog`:
    - Fail fast without `outdir/manifest.json` or `loci.tsv`.
    - Read `loci.tsv` in two passes: count the rows, then fill preallocated arrays with the csv module. Never collect
      per-field Python lists.
    - Stream each pair file once (every annotated A against every other genome) into `proj`, `ptier`, `pseq`, `pstart`,
      `pend` and `pstrand`. Fail fast on a missing file or a header other than `CALL_COLUMNS`, naming it.
    - `sheet_sha` = `file_checksum(sheet, outdir/"work"/CHECKSUM_CACHE)`.
    - Lengths and seqid order come from `Fasta(s.fasta, cache_dir=outdir/"work"/"fai").lengths()`.
    - `top` comes from each annotated genome's `work/elements/<label>.tsv`, by walking `parent` links.
    - Never call an engine-fingerprint check.

- [ ] **Step 6: Run** `python -m pytest -W error tests/test_catalog.py && ruff check .`. Expected: PASS, clean.

- [ ] **Step 7: Record the builder calls.** In DESIGN.md section 12, add "Build decisions (plan 2)" with the twelve calls
  above, one line each. Call 11 reads: "Fallback discovery uses only annotated ingroup genomes that split with D from
  the sisters (four-point condition on PAV distances). Controller ruling 2026-11-11 while the user was away (a discovery
  genome inside the sisters' clade biases the null D_pav: +0.35, Z +6.7 in a coalescent probe); user to confirm."

- [ ] **Step 8: Commit.**
  `git add -A && git commit -m "Add analysis catalog loader, constants and toy runs"`
---

