"""Tests for LTRmix/ltrmix_plot.py on a small synthetic ltrmix trio output (no real data).

run (from the LTRmix directory, env from environment.yml): pytest -q tests/
"""
import os
import re
import sys

import numpy as np
import pandas as pd
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))   # LTRmix/ (tests live in LTRmix/tests/)
import ltrmix_plot as lp  # noqa: E402

R, S, D = "Rx", "Sx", "Dx"
CLASSES = ["near_donor", "donor_only", "near_sister", "sister_only", "shared", "private", "near_both", "unresolved"]


def make_run(out, nchrom=3, nscaf=2, n_per=300, tracts=True):
    """A synthetic trio directory with every file ltrmix writes for a trio."""
    os.makedirs(out, exist_ok=True)
    rng = np.random.default_rng(7)
    rows = []
    seqs = [(f"{R}_chr{i}", 4_000_000 + 500_000 * i, n_per) for i in range(1, nchrom + 1)]
    seqs += [(f"{R}_scaf_{i}", 60_000, 5) for i in range(1, nscaf + 1)]
    for chrom, length, n in seqs:
        st = np.sort(rng.integers(0, length - 12_000, n))
        for s0 in st:
            e0 = s0 + int(rng.integers(3_000, 11_000))
            cls = str(rng.choice(CLASSES))
            inD = "absent" if cls == "sister_only" else ("unresolved" if cls == "unresolved" else "present")
            inS = "absent" if cls == "donor_only" else ("unresolved" if cls == "unresolved" else "present")
            dD = float(rng.choice([0.0, 0.001, 0.01, 0.03])) if inD == "present" else np.nan
            dS = float(rng.choice([0.0, 0.001, 0.01, 0.03])) if inS == "present" else np.nan
            pa, pr = rng.random(), rng.random()
            rows.append((chrom, s0, e0, f"{chrom}:{s0}-{e0}#LTR/Gypsy/x", 0.01, inD, ".", dD, inS, ".", dS, cls,
                         round(pa, 4), round(pr, 4)))
    el = pd.DataFrame(rows, columns=["chrom", "start", "end", "name", "k2p", f"in_{D}", f"ortholog_{D}", f"div_{D}",
                                     f"in_{S}", f"ortholog_{S}", f"div_{S}", "class", f"post_ancestry_{D}",
                                     f"post_recent_{D}"])
    el.to_csv(os.path.join(out, f"elements.{R}.tsv"), sep="\t", index=False, na_rep="nan")
    hdr = "#chrom\tstart0\tend\tname\tscore\tn_elements\tmean_post\tsum_post\tq\tp_decoy\n"
    for fn, lab in ((f"tracts.{R}.bed", "recent"), (f"ancestry.{R}.bed", "ancestry")):
        with open(os.path.join(out, fn), "w") as fo:
            fo.write(hdr)
            if tracts:
                for i, (q, conf) in enumerate(((0.04, "high"), (0.12, "medium"), (0.4, "low"), (0.04, "high"))):
                    c = f"{R}_chr{1 + i % nchrom}"
                    fo.write(f"{c}\t{1_000_000 + 400_000 * i}\t{1_150_000 + 400_000 * i}\t{D}-{lab}:{conf}\t900\t"
                             f"{5 + i}\t0.9\t{4.5 + i}\t{q}\t0.01\n")
    with open(os.path.join(out, f"decoy_tracts.{S}.bed"), "w") as fo:
        fo.write("#chrom\tstart0\tend\tname\tscore\tn_elements\tmean_post\tsum_post\n")
        fo.write(f"{S}_chr1\t2000000\t2100000\tdecoy\t800\t3\t0.8\t2.4\n")
    with open(os.path.join(out, "blocks.tsv"), "w") as fo:
        fo.write("genome_a\tchrom_a\tstart_a\tend_a\tgenome_b\tchrom_b\tstart_b\tend_b\tsign\tn_anchor\n")
        for i, (_, length, _) in enumerate(seqs[:nchrom], 1):
            for g in (S, D):
                fo.write(f"{R}\t{R}_chr{i}\t1000\t{length - 20_000}\t{g}\t{g}_chr{i}\t1000\t{length}\t1\t300\n")
        fo.write(f"{R}\t{R}_chr1\t5000\t50000\t{D}\t{D}_scaf_9\t100\t40000\t1\t40\n")   # a scaffold, not a homolog
    st = []

    def add(test, stratum, **kw):
        st.append(dict(test=test, stratum=stratum, **kw))

    add("D_kmer", "all", D=0.1, SE=0.02, Z=5.0, nA=1000, nB=800, nblocks=40)
    add("D_ins", "all", D=0.15, SE=0.03, Z=5.0, nA=300, nB=220, nblocks=40)
    for lab, dv in (("K2P 0", 0.4), ("K2P (0.002,0.005]", 0.2), ("K2P (0.01,0.02]", 0.1), ("K2P >0.1", 0.0)):
        add("D_ins_by_age", lab, D=dv, SE=0.05, Z=dv / 0.05, nA=50, nB=40, nblocks=30)
    for i in range(1, nchrom + 1):
        add("D_kmer_by_chrom", f"{D}_chr{i}", D=0.05 * i, SE=0.03, Z=1.6 * i, nA=100, nB=90, nblocks=8)
        add("D_ins_by_chrom", f"{D}_chr{i}", D=0.04 * i - 0.05, SE=0.04, Z=1.0, nA=50, nB=45, nblocks=8)
    add("D_kmer_by_chrom", f"{D}_scaf_9", D=0.9, SE=0.5, Z=1.8, nA=10, nB=2, nblocks=2)
    add("completeness_ratio", f"{R}/{S} on {D} K2P>0.05", ratio=1.02, SE=0.01, n=500)
    bins = [0, 1e-9, 2.5e-4, 5e-4, 1e-3, 2e-3, 4e-3, 8e-3, 1.6e-2, 3.2e-2, 6.4e-2, 1.0]
    for i in range(len(bins) - 1):
        add("identity_spectrum", f"d in [{bins[i]:.2g},{bins[i + 1]:.2g})", n_target=[30, 0, 20, 25, 40, 80, 200,
            300, 250, 90, 5][i], n_mirror=[3, 0, 2, 4, 10, 60, 190, 290, 240, 95, 4][i], ratio_calibrated=1.0)
    add("f_lower_bound", "identity_spectrum", f=0.1, n_target=1000, n_mirror=900, calibration=1.05)
    add("D3_triples", "all", D=0.03, SE=0.01, Z=3.0, nA=10, nB=9, nblocks=40)
    add("D_self_outgroup", "LTR sites", D=0.2, SE=0.05, Z=4.0, nA=600, nB=400, nblocks=40)
    for mode, nt, nd in (("ancestry", 4, 3), ("recent", 4, 1)):
        add(f"hmm_{mode}", R, sister=S, donor=D, pi=0.3, mean_tract_bp=50000, loglik=-10, n_tracts=nt,
            n_decoy_tracts=nd, n_tracts_q05=2, posterior_mean=0.3, decoy_posterior_mean=0.2, excess_over_decoy=0.1,
            near_threshold="0.003", classes="x", e1="x", e0="x", donor_state=True)
    pd.DataFrame(st).to_csv(os.path.join(out, "stats.tsv"), sep="\t", index=False)
    with open(os.path.join(out, "findings.txt"), "w") as fo:
        fo.write(f"Sister pair (most single-copy k-mers shared): {R} + {S}; third genome: {D}.\n"
                 f"D(single-copy k-mers; {R},{S};{D}) = +0.1000 +- 0.0200 (Z = 5.0, 40 blocks of 5 Mb on {D}).\n")
    return out


def n_pages(pdf):
    return len(re.findall(rb"/Type\s*/Page[^s]", open(pdf, "rb").read()))


def test_full_run_writes_three_files_and_three_pages(tmp_path):
    out = make_run(str(tmp_path / "run"))
    paths = lp.overview(out)
    assert [os.path.basename(p) for p in paths] == ["overview.png", "overview.pdf", "overview_numbers.tsv"]
    assert all(os.path.getsize(p) > 0 for p in paths)
    assert n_pages(paths[1]) == 3
    nums = pd.read_csv(paths[2], sep="\t")
    assert {"name", "value", "source"} == set(nums.columns)
    assert (nums["name"] == "n_tracts").any() and (nums["name"] == "D_self_outgroup_Z").any()


def test_missing_optional_files_still_draw(tmp_path):
    out = make_run(str(tmp_path / "run"))
    for f in (f"tracts.{R}.bed", f"ancestry.{R}.bed", f"decoy_tracts.{S}.bed", "blocks.tsv", "findings.txt"):
        os.remove(os.path.join(out, f))
    paths = lp.overview(out)
    assert n_pages(paths[1]) == 3


def test_header_only_tract_files(tmp_path):
    out = make_run(str(tmp_path / "run"), tracts=False)
    paths = lp.overview(out)
    assert os.path.getsize(paths[0]) > 0


def test_required_stats_missing_fails(tmp_path):
    out = make_run(str(tmp_path / "run"))
    os.remove(os.path.join(out, "stats.tsv"))
    with pytest.raises(FileNotFoundError):
        lp.overview(out)


def test_chromosomes_natural_order_scaffolds_dropped(tmp_path):
    out = make_run(str(tmp_path / "run"), nchrom=11, n_per=40)
    d = lp._load(out)
    keep, ext, dropped, n_drop = lp._chromosomes(d)
    assert keep == [f"{R}_chr{i}" for i in range(1, 12)]
    assert sorted(dropped) == [f"{R}_scaf_1", f"{R}_scaf_2"] and n_drop == 10


def test_many_sequences_fit_the_page(tmp_path):
    out = make_run(str(tmp_path / "run"), nchrom=24, n_per=30)
    lp.overview(out)
    from PIL import Image
    w, h = Image.open(os.path.join(out, "overview.png")).size
    assert h / 300 * 25.4 <= 241 and w / 300 * 25.4 <= 181


def test_scaffold_never_placed_in_panel_B(tmp_path):
    out = make_run(str(tmp_path / "run"))
    d = lp._load(out)
    fwd, rev = lp._homologs(d["blocks"], D, R), lp._homologs(d["blocks"], R, D)
    assert fwd[f"{D}_scaf_9"] == f"{R}_chr1" and rev[f"{R}_chr1"] == f"{D}_chr1"


def test_short_names_and_natural_key():
    assert lp._short(["B73v5_chr1", "B73v5_chr10"]) == {"B73v5_chr1": "chr1", "B73v5_chr10": "chr10"}
    assert lp._short(["chr1", "chr2"]) == {"chr1": "chr1", "chr2": "chr2"}
    assert sorted(["chr10", "chr2", "chr1"], key=lp._nat) == ["chr1", "chr2", "chr10"]


def test_cli(tmp_path):
    out = make_run(str(tmp_path / "run"))
    lp.main([out, "--mu", "3e-8"])
    assert os.path.exists(os.path.join(out, "overview.pdf"))
