"""Statistics core shared by the analyses: result rows (stats.tsv), jackknife blocks, the Poisson upper bound,
the resolution-symmetry warning and findings.txt lines.

Every analysis imports `u95` (the chi2 bound) and `resolution` (the warning) from here.
The jackknife is the unweighted delete-one form.
"""
from __future__ import annotations

import csv
import math
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from ..genotype import tsv_field
from .catalog import Catalog
from .constants import BLOCK_BP, BLOCK_FRAC, BLOCK_MIN, JK_MIN_BLOCKS, RESOLVE_WARN

STATS_COLUMNS = ("layer", "test", "scope", "stratum", "statistic", "value", "se", "z", "n", "loci", "note")
# the test of stats.tsv's sentinel rows: report.assemble writes one per stage part, scope the stage, statistic "key"
# (value: the stage key the part was made under, its rows following) or "left_out" (value: why it is not there)
PART = "part"


@dataclass
class StatRow:
    """One line of stats.tsv; "." is a missing text field, nan a missing number."""
    layer: str
    test: str
    scope: str
    stratum: str
    statistic: str
    value: float | int | str
    se: float = math.nan
    z: float = math.nan
    n: int | None = None
    loci: str = "."
    note: str = "."


@dataclass(frozen=True)
class Jk:
    """A delete-one block jackknife: estimate, standard error, z = est / se, and the number of blocks."""
    est: float
    se: float
    z: float
    nblocks: int


def block_size(cat: Catalog, override: int | None = None) -> int:
    """Jackknife block length: `override` (ltrpav-stats --block-size), an integer of at least BLOCK_MIN (else a
    ValueError); without it the smaller of BLOCK_BP and 1/BLOCK_FRAC of the smallest genome (at least
    BLOCK_MIN). The rule on a catalog without genomes raises a bare ValueError (min of nothing)."""
    if override is not None:
        if isinstance(override, bool) or not isinstance(override, (int, np.integer)) or override < BLOCK_MIN:
            raise ValueError(f"jackknife block size {override!r}: an integer of at least {BLOCK_MIN} bp "
                             "is needed")
        return int(override)
    smallest = min(int(np.sum(v, dtype=np.int64)) for v in cat.lengths.values())
    return min(BLOCK_BP, max(smallest // BLOCK_FRAC, BLOCK_MIN))


def block_ids(seq: np.ndarray, mid: np.ndarray, size: int) -> np.ndarray:
    """int64 block id (seq << 32) | (mid // size): a block never spans two sequences. seq >= 0."""
    return (np.asarray(seq).astype(np.int64) << 32) | (np.asarray(mid) // size).astype(np.int64)


def jackknife(stat: Callable[[np.ndarray], float], blocks: np.ndarray) -> Jk:
    """Delete-one block jackknife of `stat`, a function of a boolean keep-mask over the rows.

    est = stat(all rows); a pseudovalue stat(blocks != b) per distinct block, non-finite ones dropped;
    se = sqrt((m - 1) / m * sum((p - mean)^2)) over the m finite pseudovalues, and exactly 0 when they are all
    equal (their float mean can be off by an ulp, which would give se ~1e-17); se and z are nan with fewer
    than JK_MIN_BLOCKS (3) distinct blocks (counted before dropping), with fewer than 2 finite
    pseudovalues, and at once, with no pseudovalue computed, when the estimate is nan; z =
    est / se when se > 0.
    """
    blocks = np.asarray(blocks)
    est = float(stat(np.ones(len(blocks), dtype=bool)))
    uniq = np.unique(blocks)
    nb = len(uniq)
    if math.isnan(est) or nb < JK_MIN_BLOCKS:
        return Jk(est, math.nan, math.nan, nb)
    p = np.array([stat(blocks != b) for b in uniq], dtype=float)
    p = p[np.isfinite(p)]
    m = len(p)
    if m < 2:
        return Jk(est, math.nan, math.nan, nb)
    # identical pseudovalues: no variation among the blocks (equal ratios of counts are the same double, so
    # the test is exact and needs no tolerance)
    se = 0.0 if p.min() == p.max() else math.sqrt((m - 1) / m * float(((p - p.mean()) ** 2).sum()))
    z = est / se if se > 0 else math.nan
    return Jk(est, se, z, nb)


def d_ratio(a: np.ndarray, b: np.ndarray) -> Callable[[np.ndarray], float]:
    """keep -> (sum a - sum b) / (sum a + sum b) over the kept rows; nan when the denominator is 0."""
    a = np.asarray(a)
    b = np.asarray(b)

    def stat(keep: np.ndarray) -> float:
        sa, sb = float(a[keep].sum()), float(b[keep].sum())
        return (sa - sb) / (sa + sb) if sa + sb else math.nan
    return stat


def u95(d: np.ndarray, n: np.ndarray) -> np.ndarray:
    """One-sided 95% upper bound of a Poisson rate from d events in n trials: chi2.ppf(0.95, 2(d + 1)) / 2 / n
    (exact, Garwood); d = 0 gives about 3 / n."""
    from scipy.stats import chi2
    d = np.asarray(d)
    return chi2.ppf(0.95, 2 * (d + 1)) / 2 / np.asarray(n)


def resolution(test: str, scope: str, fracs: dict[str, float], n: int, loci: str, findings: Findings,
               section: str) -> list[StatRow]:
    """One row resolved_<genome> per genome (layer pav, stratum all). Warns in `findings` when the largest and
    smallest resolved fractions differ by more than RESOLVE_WARN (a heuristic): a test
    that compares genomes of unequal resolution is biased toward the better-resolved one."""
    rows = [StatRow("pav", test, scope, "all", f"resolved_{g}", f, n=n, loci=loci) for g, f in fracs.items()]
    if fracs and max(fracs.values()) - min(fracs.values()) > RESOLVE_WARN:
        spread = ", ".join(f"{g} {f:.2f}" for g, f in fracs.items())
        findings.warn(section, f"{test} {scope}: resolved fractions differ by more than {RESOLVE_WARN} "
                               f"({spread}); the comparison favors the better-resolved genome "
                               f"(heuristic threshold)")
    return rows


def format_row(r: StatRow) -> str:
    """One stats.tsv line (`tsv_field` values), with its newline."""
    return "\t".join(tsv_field(getattr(r, c)) for c in STATS_COLUMNS) + "\n"


def write_stats(rows: list[StatRow], path: Path) -> None:
    """stats.tsv: a header row of STATS_COLUMNS only, then one line per row (`format_row`)."""
    with open(path, "w", newline="") as fh:
        fh.write("\t".join(STATS_COLUMNS) + "\n")
        fh.writelines(format_row(r) for r in rows)


def _num(s: str) -> float:
    return math.nan if s == "." else float(s)


def read_stats(path: Path) -> list[StatRow]:
    """Inverse of `write_stats` (values to 6 significant digits; a non-numeric value stays text). A sentinel row
    (test PART) keeps its value as text: a stage key may look like a number. Every other value is read as an int,
    else a float ("." as nan), else text, so a text value that looks like a number comes back as one ("12" -> 12)
    and an integral float as an int when written so; no row writes such a text value."""
    rows = []
    with open(path, newline="") as fh:
        rd = csv.reader(fh, delimiter="\t")
        if tuple(next(rd)) != STATS_COLUMNS:
            raise ValueError(f"{path}: not a stats.tsv (header is not {STATS_COLUMNS})")
        for f in rd:
            if len(f) != len(STATS_COLUMNS):
                raise ValueError(f"{path}: expected {len(STATS_COLUMNS)} fields, got {len(f)}: {f}")
            if f[1] == PART:
                value: float | int | str = f[5]
            else:
                try:
                    value = int(f[5])
                except ValueError:
                    try:
                        value = _num(f[5])
                    except ValueError:
                        value = f[5]
            rows.append(StatRow(*f[:5], value, _num(f[6]), _num(f[7]), None if f[8] == "." else int(f[8]),
                                f[9], f[10]))
    return rows


SECTIONS = ("Run", "Relationships", "Trio tests", "Painting", "Dating", "Direction (exploratory)", "Inversions",
            "Mechanisms", "Sequence-identity layer (outside the PAV-only core)")


class Findings:
    """Lines for findings.txt, each under one of SECTIONS, kept in insertion order."""

    def __init__(self) -> None:
        self._items: list[tuple[str, str]] = []

    def add(self, section: str, text: str) -> None:
        self._items.append((section, text))

    def warn(self, section: str, text: str) -> None:
        self._items.append((section, "WARNING: " + text))

    def extend(self, other: Findings) -> None:
        self._items.extend(other._items)

    def items(self) -> list[tuple[str, str]]:
        return list(self._items)
