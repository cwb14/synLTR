### Task 10: Stages, assembly and commands

**Files:**
- Create: `src/ltrpav/analysis/report.py`, `src/ltrpav/analysis/cli.py`, `tests/test_cli_analysis.py`
- Modify:
  - `src/ltrpav/cli.py`: the single engine hook (below);
  - `pyproject.toml`: scripts `ltrpav-stats = "ltrpav.analysis.cli:stats_main"` and
    `ltrpav-paint = "ltrpav.analysis.cli:paint_main"`, then `pip install -e . --no-deps` in the env;
  - `docs/DESIGN.md` section 8 (checkpointing).

**Interfaces:**
- Consumes:
  - every module above; `checkpoint.file_checksum`, `package_fingerprint`, `stage_key`, `is_done`, `mark_done`,
    `clear_done`;
  - `ltrpav.cli._execute`, `_options`, `CliError` (imported, not edited).
- Produces:

```python
# analysis/report.py
STAGES = ("stats", "paint")
def stage_inputs(cat: Catalog, stage: str, identity: bool) -> dict[str, str]   # file name -> checksum
def analysis_fingerprint(stage: str) -> str
    # package_fingerprint("ltrpav.analysis", *READER_MODULES); the plot stage adds "ltrpav.plot"
    # (not the engine's checkpoint.stage_fingerprint, which covers engine stages only)
def write_part(outdir: Path, stage: str, rows: list[StatRow], findings: Findings) -> list[Path]
def assemble(outdir: Path) -> tuple[Path, Path]                                # stats.tsv, findings.txt
def run_stats(cat: Catalog, trio: tuple[str, str, str] | None, identity: bool, threads: int) -> list[Path]
def run_paint(cat: Catalog, trio: tuple[str, str, str] | None) -> list[Path]
# analysis/cli.py
def stats_main(argv: list[str] | None = None) -> int     # ltrpav-stats --samples --outdir [--trio R,S,D] [--identity] [--threads N] [-v]
def paint_main(argv: list[str] | None = None) -> int     # ltrpav-paint --samples --outdir [--trio R,S,D] [-v]
def run_analyses(samples_path: Path, outdir: Path, trio: tuple[str, str, str] | None, identity: bool,
                 threads: int) -> None                    # the stats, paint (and, from Task 11, plot) stages in order
```

Rules:

- **Stage inputs** (checksums through `file_checksum`, with the cache in `work/checksums.json`):
  - **stats:** `cat.sheet_sha`, `loci.tsv`, `qc.tsv`, every pair file and element TSV, and the FASTAs with
    `--identity`.
  - **paint:** `cat.sheet_sha`, `loci.tsv`, `qc.tsv`, the element TSVs, every pair file, and `identity.tsv` when
    present.
- **Keys:** `stage_key(stage, inputs, {"trio": ..., "identity": ...}, fingerprint=analysis_fingerprint(stage))`. They hold
  the analysis package's own fingerprint and the checksums of the engine outputs read, never the engine fingerprint.
- **Markers:** `work/analysis/<stage>.done.json`.
  - Each lists exactly the files its stage writes. stats: `inversions.tsv`, `mechanisms.tsv`, `identity.tsv` (with
    `--identity`) and its two part files. paint: the painting files and its two part files.
  - `stats.tsv` and `findings.txt` are assembled outputs that any stage rewrites, so no marker lists them, and a later
    stage never breaks an earlier one's "done, skip".
  - A finished stage logs `<stage>: done, skip` (logger `ltrpav.analysis`).
- **`run_stats` order:**
  1. `run_summary`, `relations`.
  2. `trios`, then `trio_tests` per trio.
  3. `inverted_blocks`, `write_inversions` (`inversions.tsv`), `inversion_rows`.
  4. `direction`.
  5. `mechanisms`, `write_mechanisms` (`mechanisms.tsv`).
  6. `identity`, per trio with D annotated (`identity.tsv`). Without `--identity`, a stale `identity.tsv` is deleted,
     and one findings line says that DESIGN 7.5's counts of shared insertions younger than the split need `--identity`.

  It writes the `stats` part.
- **`run_paint`:**
  - `relations` (for `dist`), `trios` and `inverted_blocks` are recomputed, their rows discarded;
  - `identity.tsv`'s self rows are read as `self_counts` when the file exists;
  - then `paint` per trio, `write_paintings`, and the `paint` part.
- **Parts:** `work/analysis/<stage>.rows.tsv` (`STATS_COLUMNS`) and `<stage>.findings.tsv` (section, line).
- **`assemble`** rewrites both files, each atomically:
  - `stats.tsv`: the header row `STATS_COLUMNS`, then the parts' rows in `STAGES` order. No other header line.
  - `findings.txt`: a first line with the version and the run directory; the lines grouped in `SECTIONS` order, each
    section under its name; a closing "Warnings" section repeating every WARNING line.
- **`analysis/cli.py`:**
  - Builds its parsers with the engine's `_options` and runs them through `_execute` (exit 0 / 1 / 2).
  - Imports scipy, matplotlib, the analysis modules and `ltrpav.plot` inside the stage functions only, so that
    `import ltrpav.analysis.cli` needs neither scipy nor matplotlib.
  - An ImportError of scipy or matplotlib becomes `CliError("analyses need scipy and matplotlib: run ltrpav-stats and
    ltrpav-paint in the ltrpav env")`: one error line, exit 1.
  - It never calls `_check_pair_files` or any other engine-fingerprint check.
  - Fail fast:
    - no `manifest.json` gives CliError "no finished merge in OUTDIR (manifest.json missing): run ltrpav run or
      ltrpav-merge first";
    - `--trio` must name three distinct sheet labels, none an outgroup.
- **The engine hook** (`src/ltrpav/cli.py`, the only engine edit of Plan 2):
  - `ltrpav run` gains `--trio R,S,D` and `--identity`.
  - After `_merge`, `_run` imports `ltrpav.analysis.cli` and calls `run_analyses(args.samples, args.outdir, args.trio,
    args.identity, args.threads)`. The engine's outputs are already complete at that point; an analysis error ends the
    run with one error line, and the outputs are kept.
  - With per-stage engine fingerprints, this edit invalidates no genotyping stage.
- **DESIGN 8:** add to the checkpointing item:
  - resuming `ltrpav run` in an outdir finished by an older engine recomputes every stage whose engine modules changed,
    genotyping included;
  - the analysis commands read a finished run as data, are keyed on their own package's fingerprint, and never check
    engine fingerprints.

- [ ] **Step 1: Write the failing tests**

```python
def _args(run):
    return ["--samples", str(run.sheet), "--outdir", str(run.outdir)]

@needs_lastz                                       # from tests/test_cli.py: `ltrpav run` aligns with LASTZ
def test_run_includes_analyses(tmp_path, caplog):
    w = make_world(tmp_path / "w")                   # tests/test_cli.py: A, B annotated; C genotype-only
    out, argv = tmp_path / "out", ["run", "--samples", str(w.sheet), "--outdir", str(tmp_path / "out")]
    assert main(argv) == 0
    assert all((out / f).is_file() for f in ("stats.tsv", "findings.txt", "inversions.tsv", "mechanisms.tsv"))
    assert "Trio tests" in (out / "findings.txt").read_text().splitlines()
    caplog.clear()
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert main(argv) == 0
    assert "stats: done, skip" in caplog.text and "paint: done, skip" in caplog.text

def test_stats_then_paint(tmp_path, toy_fastas):
    run = simulate_run(tmp_path, seed=1, tracts=TRACTS, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0
    assert {"sharing", "D_pav", "paint"} <= {r.test for r in read_stats(run.outdir / "stats.tsv")}
    assert (run.outdir / "stats.tsv").read_text().splitlines()[0].split("\t") == list(STATS_COLUMNS)
    lines = (run.outdir / "findings.txt").read_text().splitlines()
    assert lines[0].startswith("ltrpav ") and str(run.outdir) in lines[0]
    heads = [l for l in lines if l in SECTIONS]
    assert heads == sorted(heads, key=SECTIONS.index) and (run.outdir / "tracts.R.bed").is_file()

def test_stats_skip_after_paint(tmp_path, toy_fastas, caplog):
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0      # paint re-assembles stats.tsv
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert stats_main(_args(run)) == 0
    assert "stats: done, skip" in caplog.text

def test_rerun_after_sheet_change(tmp_path, toy_fastas, caplog):
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0
    run.sheet.write_text(run.sheet.read_text().replace("\toutgroup", "\t."))
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert stats_main(_args(run)) == 0
    assert "stats: done, skip" not in caplog.text

def test_trio_validation(tmp_path, toy_fastas, capsys):
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    for bad in ("R,R,D", "R,S,X", "R,S,O"):
        assert stats_main([*_args(run), "--trio", bad]) == 1
        err = capsys.readouterr().err
        assert err.strip().splitlines()[-1].startswith("error:") and "Traceback" not in err

def test_missing_merge(tmp_path, toy_fastas, capsys):
    run = simulate_run(tmp_path, seed=1, fasta_dir=toy_fastas)
    (run.outdir / "manifest.json").unlink()
    assert stats_main(_args(run)) == 1
    assert "ltrpav-merge" in capsys.readouterr().err.strip().splitlines()[-1]

def test_help_is_short(capsys):
    for fn in (stats_main, paint_main):
        with pytest.raises(SystemExit):
            fn(["--help"])
        assert len(capsys.readouterr().out.splitlines()) < 40

@needs_lastz
def test_cli_imports_without_scipy(tmp_path):
    block = "import sys; sys.modules['scipy'] = None; sys.modules['matplotlib'] = None; "
    for mod in ("ltrpav.cli", "ltrpav.analysis.cli"):
        assert subprocess.run([sys.executable, "-c", block + f"import {mod}"], capture_output=True).returncode == 0
    w, out = make_world(tmp_path / "w"), tmp_path / "out"
    code = block + f"from ltrpav.cli import main; sys.exit(main(['run', '--samples', {str(w.sheet)!r}, " \
                   f"'--outdir', {str(out)!r}]))"
    r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
    lines = r.stderr.strip().splitlines()                      # INFO log lines come first (C4)
    assert r.returncode == 1 and "Traceback" not in r.stderr and (out / "loci.tsv").is_file()
    assert lines[-1] == ("error: analyses need scipy and matplotlib: run ltrpav-stats and ltrpav-paint in the "
                         "ltrpav env") and sum(l.startswith("error:") for l in lines) == 1

def test_stats_shared_seqids(tmp_path, toy_fastas):        # Review Focus 1
    a = simulate_run(tmp_path / "a", seed=1, tracts=TRACTS, fasta_dir=toy_fastas)
    b = simulate_run(tmp_path / "b", seed=1, tracts=TRACTS, prefix=True, fasta_dir=toy_fastas)
    for run in (a, b):
        assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0
    norm = lambda run: [re.sub(r"\b[RSDO]_(chr\d)\b", r"\1", l)
                        for l in (run.outdir / "stats.tsv").read_text().splitlines()]
    assert norm(a) == norm(b)

def test_run_two_genomes(tmp_path, toy_fastas):            # Review Focus 5
    run = write_run(tmp_path, [loc(1000 * i, "R:P* S:E O:E") for i in range(1, 20)],
                    genomes=[GENOMES[0], GENOMES[1], GENOMES[3]], fasta_dir=toy_fastas)
    assert stats_main(_args(run)) == 0 and paint_main(_args(run)) == 0
    assert "Trio tests skipped: fewer than three ingroup genomes" in (run.outdir / "findings.txt").read_text()
    assert (run.outdir / "mechanisms.tsv").is_file()
```

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_cli_analysis.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** `python -m pytest -W error -m "not slow" && ruff check .`. Expected: everything passes.
- [ ] **Step 5: Smoke on real data.**
  - Copy the finished chr10 run `/data2/chris/maize_introgression/benchmark_pav/bakeoff/chr10/runs/flank-mm2_2k/` into
    the scratchpad: `loci.tsv`, `qc.tsv`, `manifest.json`, `pairs/`, `work/elements/`, and the sheet
    `bakeoff/chr10/samples.tsv` with absolute FASTA paths. Never write into `benchmark_pav/bakeoff/`.
  - Check `ls .../bakeoff/chr10/fasta/*.fai`. If any index is missing, copy the FASTAs too and point the sheet at the
    copies.
  - Run `ltrpav-stats` and `ltrpav-paint` there, with `/usr/bin/time -v`.
  - Report the wall time, peak RSS, the roles and D_pav. The data is one chromosome with no outgroup: a smoke test, not a
    result.
- [ ] **Step 6: Commit.** `"Add analysis stages, report assembly, ltrpav-stats and ltrpav-paint"`
---

