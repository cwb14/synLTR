### Task 1: Branch, msprime extra and the population model

**Files:**
- Create: `src/ltrpav/sim/popmodel.py`, `tests/test_popmodel.py`, `tests/poptoy.py`.
- Modify:
  - `pyproject.toml`, `environment.yml`, `environment.lock.yml`, `.github/workflows/ci.yml`;
  - `src/ltrpav/sim/__init__.py`, so that msprime is not imported at import time;
  - `docs/DESIGN.md` section 12: a "Build decisions (plan 3)" block, one line per call in `plan3-draft-summary.md`,
    including "simulator calibration is not method tuning".

**Interfaces:**
- Produces, in `popmodel.py` (msprime and tskit are imported inside functions):

```python
MSPRIME_HELP = "msprime is required for `ltrpav-sim pop`: pip install 'ltrpav[sim]'"
@dataclass(frozen=True)
class Demog:            # LTRmix sim_ltr_admix.py (diploid Ne; generations) + an outgroup + optional lineage populations
    ne_a: float = 30_000; ne_b: float = 100_000; ne_c: float = 70_000; ne_bc: float = 150_000
    ne_o: float = 150_000; ne_root: float = 150_000
    t_ab: float = 9_000; t_bc: float = 60_000; t_o: float = 900_000   # t_o: measured in the benchmark (DESIGN 12)
    f: float = 0.0; ta: float = 5_000.0
    pulse: str = "C>A"                       # "C>A" | "A>C" | "C>A1" | "C1>A1" | "A1>C1"
    sub_a: tuple[float, float] | None = None  # (split generations, Ne) of A1's own lineage population "A1p"
    sub_c: tuple[float, float] | None = None  # (split generations, Ne) of "C1p"
    bottleneck: tuple[float, float] | None = None   # (Ne, generations) of A right after t_ab
    per_taxon: int = 2
@dataclass(frozen=True)
class Rates:            # per bp (or per element) per generation
    mu: float = 3e-8; r: float = 1e-8; r_low: float = 1e-9; low: tuple[float, float] = (0.3, 0.7)
    lam: float = 1.2e-10; delta: float = 1 / 900_000; indel: float = 3e-9; copy_noise: float = 0.005
    loss_split: tuple[float, float, float, float] = (0.123, 0.164, 0.511, 0.202)  # solo, del_flank, del_partial,
                                                       # replace; drafting measurement (DESIGN 12)
    replace_mean: float = 13_538                       # mean replacement length, bp; drafting measurement (DESIGN 12)
def sample_labels(d: Demog) -> list[tuple[str, str]]        # (label, group): A1..An, B1.., C1.., O1 (group "O")
def demography(d: Demog) -> "msprime.Demography"
def ancestry(d: Demog, rates: Rates, length: int, seed: int) -> "tskit.TreeSequence"
def tracts(ts, d: Demog) -> dict[int, list[tuple[int, int]]]  # sample index -> merged introgressed [l, r) on this
                                                             # chromosome (one call per chromosome)
def demog_from_json(path: Path) -> tuple[Demog, Rates]       # fields named as above; unknown field -> ValueError
```

- Rules:
  - **Populations.** A, B, C and O are extant. B and O get `initially_active=True` (LTRmix's gotcha). Lineage
    populations are extant and derived.
  - **Splits.** In msprime terms:
    - `population_split(t_ab, ["A"], "B")`;
    - `(t_bc, ["B", "C"], "BC")`;
    - `(t_o, ["BC", "O"], "ROOT")`;
    - `sub_a` adds `(split, ["A1p"], "A")`, and `sub_c` adds `(split, ["C1p"], "C")`.

    A1 is sampled from `A1p` when `sub_a` is set, and C1 from `C1p` when `sub_c` is set.
  - **Pulse.** `add_mass_migration(ta, source=<recipient>, dest=<donor>, proportion=f)`. The populations are backward in
    time; `C>A1` uses `A1p` as the recipient.
  - **Bottleneck.** `add_population_parameters_change(t_ab - gens, population="A", initial_size=ne)`.
  - **Recombination.** A `RateMap` with `r` outside and `r_low` on `[low[0]*L, low[1]*L)`. This is LTRmix's
    per-chromosome rule, applied to each 10-Mb window: a heuristic that keeps LTRmix's 40% low-recombination share.
  - **Ancestry.** `sim_ancestry(samples=[SampleSet(n, pop, ploidy=1)...], ploidy=2, record_migrations=True)`.
  - **Tracts of sample s:** the union of the pulse's migration records (time `ta`, recipient to donor) over the intervals
    where the record's node is s or an ancestor of s (`tree.samples(node)`).
  - **Fail fast,** with ValueError, on any of:
    - `f` outside [0, 1];
    - `ta >= t_ab` when `f > 0`;
    - a lineage pulse without its `sub_*`, or `ta` not below the lineage split;
    - an unknown pulse code;
    - `per_taxon < 1`;
    - a bottleneck longer than `t_ab`.

- [ ] **Step 1: Branch and environment.**
  - Preconditions:
    - `plan1-engine` is at 12d3e6c, with Plan 2 merged (or at a later reviewed head);
    - `pgrep -af 'ltrpav|lastz|ltrmix'` prints nothing;
    - `git status` is clean.
  - `git checkout -b plan3-benchmark plan1-engine`.
  - `mamba install -n ltrpav -c conda-forge "msprime>=1.3"`.
  - pyproject: `[project.optional-dependencies] sim = ["msprime>=1.3"]`.
  - `environment.yml`: `- msprime`.
  - CI: `pip install -e ".[dev,sim]"`.
  - Confirm that PyPI has msprime wheels for Python 3.10, 3.12 and 3.13 (`pip download msprime --only-binary=:all:
    --python-version 3.13`). If 3.13 has none, the CI step installs GSL first; say so in the commit.
  - Refresh the lock (84c8088 procedure), then check:
    - `grep -qE '^  - msprime=' environment.lock.yml` succeeds;
    - the file holds neither `prefix:` nor `ltrpav==`.
  - Record the build decisions in DESIGN 12.
- [ ] **Step 2: Write the failing tests** (`tests/test_popmodel.py`, starting with `pytest.importorskip("msprime")`).
  `poptoy.small_demog()` runs in under a second on 200 kb.

```python
def test_sample_times_zero():            # every sample node time 0; labels A1 A2 B1 B2 C1 C2 O1
def test_no_pulse_no_tracts():           # f=0 -> tracts == {} for every pulse code (sub_a/sub_c supplied for the
                                         # lineage codes; the fail-fast stays strict)
def test_full_pulse_covers_recipient():  # f=1, ta=100, "C>A": A1, A2 tracts cover [0, L); B, C, O none
def test_reverse_direction():            # f=1, ta=100, "A>C": C samples covered, A none
def test_lineage_pulse():                # sub_a=(2000,1000), sub_c=(30000,1000), "C1>A1", f=1, ta=500: A1 covered, A2 none
def test_tract_through_ancestor():       # ne_a=5, ta=1000, f=0.5, seed 3: tracts(A1) == tracts(A2) != []
def test_fraction_matches_f():           # L=2 Mb, f=0.18, ta=500, seeds 1-20: mean A1 fraction within 0.18 +- 3 SE
def test_bottleneck_sizes():             # demography(bottleneck=(5000, 2000)).debug(): A 30000 at t=1000, 5000 at t=8000
def test_recombination_map():            # rate 1e-9 at 0.5 L, 1e-8 at 0.1 L
def test_demog_from_json(tmp_path):      # round trip of every field; an unknown key -> ValueError
def test_bad_demog_fails():              # ta=9000 with f>0; pulse "A-C"; f=1.5; "C1>A1" without sub_c -> ValueError
def test_import_without_msprime(monkeypatch):  # sys.modules["msprime"]=None: import ltrpav.sim, ltrpav.cli work;
                                                # ancestry(...) raises RuntimeError(MSPRIME_HELP)
```

- [ ] **Step 3: Run** `python -m pytest -W error tests/test_popmodel.py`. Expected: FAIL (module missing).
- [ ] **Step 4: Implement** `popmodel.py` as the Interfaces block states.
- [ ] **Step 5: Run** the file, then the suite and ruff.
- [ ] **Step 6: Commit:** `"Add the population model for ltrpav-sim pop (msprime extra)"`.

---

