"""ltrkin source on a planted genealogy with known answers."""
import csv

import numpy as np
import pytest

from ltrkin.annot import read_gff3
from ltrkin.cli import main

BASES = np.frombuffer(b"ACGT", dtype=np.uint8)


def _mut(rng, a, n):
    a = a.copy()
    pos = rng.choice(len(a), n, replace=False)
    a[pos] = (a[pos] + rng.integers(1, 4, n)) % 4
    return a, set(pos.tolist())


@pytest.fixture(scope="module")
def files(tmp_path_factory):
    d = tmp_path_factory.mktemp("src")
    rng = np.random.default_rng(3)
    ltr0, int0 = rng.integers(0, 4, 500).astype(np.uint8), rng.integers(0, 4, 5000).astype(np.uint8)
    cps = {}
    for i in range(6):                                   # background fixed copies (consensus = ancestor)
        cps[f"bg{i}"] = (ltr0, ltr0, _mut(rng, int0, 12)[0], "F/F")
    M_int, m_priv = _mut(rng, int0, 5)                  # master: 5 private mutations
    M_l3, _ = _mut(rng, ltr0, 3)                        # master LTRs differ at 3 sites (older)
    cps["master"] = (ltr0, M_l3, M_int, "F/F")
    cps["child"] = (M_l3, M_l3, _mut(rng, M_int, 2)[0], "F/E")      # copied from master after its mutations
    P_int, _ = _mut(rng, int0, 3)                        # lost parent with 3 private mutations
    cps["sibA"] = (ltr0, ltr0, _mut(rng, P_int, 4)[0], "F/F")
    cps["sibB"] = (ltr0, ltr0, _mut(rng, P_int, 4)[0], "F/E")
    T_int, _ = _mut(rng, int0, 6)
    cps["twin1"], cps["twin2"] = (ltr0, ltr0, T_int, "F/F"), (ltr0, ltr0, T_int.copy(), "F/F")
    cps["twin_child"] = (ltr0, ltr0, _mut(rng, T_int, 1)[0], "F/E")
    R1_int, _ = _mut(rng, int0, 15)                      # two fixed parents and a template-switch child
    R2_int, _ = _mut(rng, int0, 15)
    cps["rp1"], cps["rp2"] = (ltr0, ltr0, R1_int, "F/F"), (ltr0, ltr0, R2_int, "F/F")
    cps["rchild"] = (ltr0, ltr0, np.concatenate([R1_int[:2500], R2_int[2500:]]), "F/E")
    H_int, _ = _mut(rng, int0, 7)                        # fixed host with a new copy of master nested inside
    inner_el = np.concatenate([M_l3, _mut(rng, M_int, 1)[0], M_l3])
    t_in = H_int[2000:2005]
    cps["host"] = (ltr0, ltr0, np.concatenate([H_int[:2005], inner_el, t_in, H_int[2005:]]), "F/F")
    D_int, _ = _mut(rng, int0, 8)
    cps["dup_src"] = (ltr0, ltr0, D_int, "F/F")
    cps["dup_copy"] = (ltr0, ltr0, D_int.copy(), "F/E")
    flank_dup = rng.integers(0, 4, 800).astype(np.uint8)
    seq, gff, gts = [], [], []
    pos = 0
    tsd_dup = rng.integers(0, 4, 5).astype(np.uint8)
    for name, (l5, l3, internal, gt) in cps.items():
        dup = name.startswith("dup")
        sp = rng.integers(0, 4, 4000).astype(np.uint8)
        fl = flank_dup if dup else rng.integers(0, 4, 800).astype(np.uint8)
        tsd = tsd_dup if dup else rng.integers(0, 4, 5).astype(np.uint8)
        el = np.concatenate([l5, internal, l3])
        s = pos + len(sp) + len(fl) + 5
        e = s + len(el)
        seq += [sp, fl, tsd, el, tsd, fl[::-1].copy()]
        pos = e + 5 + len(fl)
        gff.append(f"chr1\tt\tLTR_retrotransposon\t{s + 1}\t{e}\t.\t+\t.\tID={name};family=famX;clade=cl")
        gff.append(f"chr1\tt\tlong_terminal_repeat\t{s + 1}\t{s + 500}\t.\t+\t.\tID={name}.l;Parent={name}")
        gff.append(f"chr1\tt\tlong_terminal_repeat\t{e - 499}\t{e}\t.\t+\t.\tID={name}.r;Parent={name}")
        gts.append(f"{name}\ts1\t{gt}\t99\tPASS")
        if name == "host":                               # annotate the nested inner element (new)
            i0 = s + 500 + 2005
            i1 = i0 + len(inner_el)
            gff.append(f"chr1\tt\tLTR_retrotransposon\t{i0 + 1}\t{i1}\t.\t+\t.\tID=inner;family=famX;clade=cl")
            gff.append(f"chr1\tt\tlong_terminal_repeat\t{i0 + 1}\t{i0 + 500}\t.\t+\t.\tID=inner.l;Parent=inner")
            gff.append(f"chr1\tt\tlong_terminal_repeat\t{i1 - 499}\t{i1}\t.\t+\t.\tID=inner.r;Parent=inner")
            gts.append("inner\ts1\tF/E\t99\tPASS")
    seq.append(rng.integers(0, 4, 3000).astype(np.uint8))
    s = BASES[np.concatenate(seq)].tobytes().decode()
    (d / "g.fa").write_text(">chr1\n" + "\n".join(s[i:i + 80] for i in range(0, len(s), 80)) + "\n")
    (d / "g.gff3").write_text("##gff-version 3\n" + "\n".join(gff) + "\n")
    (d / "gt.tsv").write_text("element_id\tsample\tgenotype\tgq\tflags\n" + "\n".join(gts) + "\n")
    return dict(dir=d, fa=str(d / "g.fa"), gff=str(d / "g.gff3"), gt=str(d / "gt.tsv"))


def _source(files, out, gff=None, gt=None):
    main(["source", "-r", files["fa"], "-a", gff or files["gff"], "-g", gt or files["gt"], "-o", out, "-t", "2"])
    with open(out + ".sources.tsv") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


@pytest.fixture(scope="module")
def genome(files):
    return _source(files, str(files["dir"] / "out"))


def _by(rows, new):
    return [r for r in rows if r["new_id"] == new]


def test_parent_found_with_shared_mutations(genome):
    (r,) = _by(genome, "child")
    assert r["source_id"] == "master"
    assert int(float(r["shared_derived"])) == 5 and int(float(r["source_private"])) == 0
    assert r["source_older"] == "True" and r["flags"] == "PASS"


def test_sibling_has_source_private_mutations(genome):
    (r,) = _by(genome, "sibB")
    assert r["source_id"] == "sibA"
    assert int(float(r["shared_derived"])) == 3 and int(float(r["source_private"])) == 4


def test_ties_share_weight(genome):
    rs = _by(genome, "twin_child")
    assert {r["source_id"] for r in rs} == {"twin1", "twin2"}
    assert all(float(r["weight"]) == 0.5 and "tied" in r["flags"] for r in rs)


def test_segmental_duplication_flagged(genome):
    (r,) = _by(genome, "dup_copy")
    assert r["source_id"] == "dup_src" and "segdup" in r["flags"] and r["same_tsd"] == "True"


def test_two_parent_mosaic(genome):
    rs = _by(genome, "rchild")
    assert rs and all("recombinant" in r["flags"] for r in rs)
    r = rs[0]
    assert {r["mosaic_left"], r["mosaic_right"]} == {"rp1", "rp2"}
    assert 1500 <= float(r["mosaic_breakpoint"]) <= 3500


def test_single_parent_not_mosaic(genome):
    for new in ("child", "sibB", "twin_child"):
        assert all("recombinant" not in r["flags"] for r in _by(genome, new)), new


def test_nested_host_is_never_the_source(genome):
    rs = _by(genome, "inner")
    assert rs and all(r["source_id"] != "host" for r in rs)
    assert any(r["source_id"] == "master" for r in rs)


# ---- inputs and caching (pre-release audit) ----------------------------------------------------------------------
def _gt_rows(files):
    return list(csv.reader(open(files["gt"]), delimiter="\t"))


def test_no_new_copies_gives_empty_tables(files, tmp_path):
    """No new copy is a result, not an error: header-only tables."""
    rows = _gt_rows(files)
    gt = tmp_path / "allF.tsv"
    gt.write_text("\n".join("\t".join(r if i == 0 else [r[0], r[1], "F/F"] + r[3:]) for i, r in enumerate(rows)) + "\n")
    out = str(tmp_path / "none")
    assert _source(files, out, gt=str(gt)) == []
    for suf in (".sources.tsv", ".copies.tsv", ".locality.tsv"):
        assert len(open(out + suf).readline().split("\t")) > 3, suf


def test_genotypes_of_another_annotation_are_rejected(files, tmp_path):
    rows = _gt_rows(files)
    gt = tmp_path / "other.tsv"
    gt.write_text("\n".join("\t".join(r if i == 0 else ["x_" + r[0]] + r[1:]) for i, r in enumerate(rows)) + "\n")
    with pytest.raises(SystemExit, match="annotation used for genotyping"):
        _source(files, str(tmp_path / "o"), gt=str(gt))


def test_moved_coordinates_are_rejected(files, tmp_path):
    els = {e.id: e for e in read_gff3(files["gff"])}
    lines = ["element_id\tchrom\tstart\tend\tsample\tgenotype\tgq\tflags"]
    for r in _gt_rows(files)[1:]:
        e, sh = els[r[0]], (100 if r[0] == "child" else 0)
        lines.append("\t".join([r[0], e.chrom, str(e.start + 1 + sh), str(e.end + sh)] + r[1:]))
    gt = tmp_path / "moved.tsv"
    gt.write_text("\n".join(lines) + "\n")
    with pytest.raises(SystemExit, match="other coordinates"):
        _source(files, str(tmp_path / "m"), gt=str(gt))


def test_no_fixed_relative_in_any_family(files, tmp_path):
    """Every new copy alone in its family: nothing to assign, and no crash."""
    new = {r[0] for r in _gt_rows(files)[1:] if r[2] == "F/E"}
    lines = []
    for ln in open(files["gff"]):
        eid = ln.split("ID=")[1].split(";")[0] if "\tLTR_retrotransposon\t" in ln else None
        lines.append(ln.replace("family=famX", f"family=fam_{eid}") if eid in new else ln)
    g = tmp_path / "alone.gff3"
    g.write_text("".join(lines))
    assert _source(files, str(tmp_path / "a"), gff=str(g)) == []


def test_work_cache_follows_family_labels(files, tmp_path):
    """A rerun with the same prefix after relabeling a family must not reuse the earlier alignments."""
    out = str(tmp_path / "c")
    assert any(r["new_id"] == "child" for r in _source(files, out))
    g = tmp_path / "relabel.gff3"
    g.write_text(open(files["gff"]).read().replace("ID=child;family=famX", "ID=child;family=famY"))
    rerun = _source(files, out, gff=str(g))
    assert rerun == _source(files, str(tmp_path / "fresh"), gff=str(g))
    assert not any(r["new_id"] == "child" for r in rerun)
