#!/usr/bin/env python3
"""Summarize the read check of the assembly truth (truth_reads_check.py output) per truth state.
Depth = primary MAPQ >= 20 reads of the other haplotype at the flank points 200 bp outside the element ends (the
smaller of the two). Present: >= 5 reads; absent: 0 reads (as in findings.md for C. amara hap1).
Expected: reads at F/Fx/Fn/E/S sites (the other haplotype keeps the flanks), none at Nr (flanks replaced). Nd is
not diagnostic at 200 bp (the deletion may end closer to the element).
usage: truth_check_summary.py <S> <ref> [...] -> TSV on stdout"""
import sys

import pandas as pd

rows = []
for S, ref in zip(sys.argv[1::2], sys.argv[2::2]):
    t = pd.read_csv(f"{S}/truth/{ref}_truth.tsv", sep="\t")
    r = pd.read_csv(f"{S}/truth/{ref}_truth_readcheck.tsv", sep="\t")
    d = r.drop(columns="state").merge(t[["element_id", "state", "truth_source"]], on="element_id")
    for src, x in [("confirmed", d[d.truth_source == "confirmed"]), ("all", d)]:
        for st, y in x.groupby("state"):
            rows.append(dict(species=S, ref=ref, truth=src, state=st, n=len(y),
                             frac_present=round((y.depth_min >= 5).mean(), 3),
                             frac_absent=round((y.depth_min == 0).mean(), 3),
                             median_depth=y.depth_min.median()))
pd.DataFrame(rows).to_csv(sys.stdout, sep="\t", index=False)
