# Task 2 review (3cb7c3e..6682dd3)

## Spec Compliance
- ✅ Interfaces, constants, SECTIONS, Findings, STATS_COLUMNS match the brief; all 8 brief tests present (identical to brief).
- ✅ Jackknife vs LTRmix (ltrmix.py:893): same delete-one formula, same m<3 rule on distinct blocks before dropping, same se = sqrt((m'-1)/m' * SS), z only when se>0. Hand check: a=[1,1,0], b=[0,0,1], blocks 0,1,2: pseudovalues 0,0,1; se = sqrt(2/3 * 6/9) = 2/3; probe gave 0.66667, z 0.5. Block size follows decision 26 (fai totals, 10-kb floor, brief formula).
- ✅ u95 is the exact (Garwood) one-sided 95% upper bound of a Poisson mean given d events, chi2.ppf(0.95, 2(d+1))/2, divided by n. Probe: Poisson cdf(d; u95*n) = 0.05 for d = 0, 2, 7; d=0 gives 2.9957/n. Written once.
- ✅ Block ids: int64 shift; probe with seq 3000 and mid 4.99e9 gives correct ids; seq 2**31-1 is recovered by >>32; mid float input (x.5) floors correctly; blocks never span sequences. Sequence ends need no special handling (floor division).
- ✅ Toy carry-over: U writes wid (i or given), no inv, reason no_anchor; D site `pos-1 .. pos+b_ins` (b_ins None -> 0); docstring reasons corrected (D medium is engine-possible). Matches Task 1 N1-N3 and the engine description there. test_catalog U assertion changed to "2" is the right consequence (wid i = locus 2).
- ✅ Round trip probed for int, float, 1e-07, nan, inf, None, np.int64/float64, text with spaces, n=2**40, n=None, note: all survive (see Minor 1-2 for edge cases). Deterministic output, `.` for nan/None.
- Brief deviations (all benign, disclosed): nan se/z also with <2 finite pseudovalues (LTRmix would give se 0 for one finite, divide by zero for none; ported is safer); read_stats int/float/text parsing; ruff reorder.
- Not re-run: suite (not allowed). Only probes.

## Strengths
- Faithful, small; jackknife generic over a keep-mask; verified numerically against hand calculation and LTRmix algebra.
- Findings/resolution text names the threshold a heuristic as required; header validation and field-count checks in read_stats.

## Issues
### Critical
none
### Important
none
### Minor
1. stats.py:read_stats (value parse): a text value that looks numeric ("12", "nan", "inf") or is "." / None round-trips to int/float/nan, so a numeric-looking string statistic changes type, and value None/"." reads back as nan not text. Also a float that is integral (5.0) reads back as int 5, and 6-significant-digit rounding applies to large float counts (documented only for 6 digits). Fix: document that value text must not look numeric, or have callers use int for counts; no code change needed for current rows.
2. stats.py block_size: `min()` over an empty `cat.lengths` (no genomes) raises a bare ValueError; Catalog always has genomes, so negligible.
3. stats.py jackknife: with est nan but >=3 blocks it still evaluates every block's stat (cost only; result nan). Cost is O(blocks * rows) per call, fine at 100s of blocks but quadratic-ish for large row counts; d_ratio could be vectorized with bincount later (as LTRmix does) if Task 3+ profiles slowly.
4. tests: no test of the <2 finite pseudovalue choice, nor of a non-finite pseudovalue being dropped, nor of the u95 against array n; the added behavior is untested. Add one tiny test each.
5. tests/test_stats_core.py: block_size test uses SimpleNamespace, never a real Catalog.lengths (dict of int64 arrays; same shape, so fine).

## Assessment
Spec: compliant. Task quality: Approved.
