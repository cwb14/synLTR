# Task 22 — controller rulings (bind as much as the brief; override it where they conflict)

Purpose: the simulator produces genome pairs with KNOWN truth for the aligner bake-off (Task 24) and later benchmarks.
Truth must be biological (what happened), computed from per-base provenance, never from the classifier.

## SimGenome and provenance
1. `SimGenome(seq: bytearray, prov: np.ndarray[int64], elements: dict[str, SimElement])`. Ancestral backbone bases
   get ids 0..n-1. Every inserted payload gets a fresh id range from a counter shared by both genomes of a simulation
   (so ids never collide); a TSD copy gets the SAME ids as the target bases it duplicates. N gaps keep provenance.
2. `SimElement`: eid, start, end (0-based half-open), ltr_left, ltr_right (0-based half-open intervals), strand,
   tsd (str), k (float), family, superfamily, origin ("backbone" | "shared" | "A" | "B"), parent (eid | None),
   events (list[str], e.g. "solo", "del_flank", "del_partial", "inv"), alive (bool).
3. Edits lift every element after each edit:
   - insert at pos: elements with start >= pos shift; an element with start < pos < end grows (nested insertion);
     an LTR interval containing pos grows (LTRquest semantics: the LTR span includes the inner element); the inserted
     element's parent = the smallest alive element containing it.
   - delete [d0, d1): elements entirely inside -> alive False; partial overlap -> clipped (event "del_partial" when
     the deletion is inside the element, the element stays alive); containing elements shrink.
   - invert [i0, i1): boundaries chosen at positions not inside any element (move outward to the nearest free
     position); contained elements get mirrored coordinates, flipped strand, event "inv".
   - gap [g0, g1): bases -> N.
   - mutate(sub_rate, indel_rate, rng): one pass; substitutions change the base; small insertions (new ids) and
     deletions with geometric lengths (mean 3); element coordinates lifted through the cumulative offsets.
4. Young copy of a donor for an insertion with age K: both LTRs = the donor's left LTR, internal = donor's internal;
   then each LTR and the internal region mutated independently at rate K/2. TSD length 5 (copy of the 5 target bases).

## simulate_pair(backbone, backbone_elements, donors, params, seed)
5. Order: ancestor = backbone with its elements (origin "backbone"); shared insertions (origin "shared", K from
   k_shared); split into A and B (deep copies; same id counter continues); per branch X: insertions (origin X, K from
   k_branch), solo-LTR events on alive pre-split elements (hybrid LTR at a random crossover, both TSDs kept), flank
   deletions (element + a flank of U(50, 2000) bp on at least one side), partial deletions (a contiguous 20-60% of the
   internal region of an element with internal >= 1 kb), mutate, gaps (100-bp N runs; a third placed within 20 bp of an
   element end, the rest uniform); then one inversion of inv_len in B. Counts are per 6 Mb of backbone and multiplied
   by `scale` (rounded); targets uniform over the current sequence (nesting arises naturally); everything driven by
   one `np.random.default_rng(seed)`.

## Truth (compute_truth(X, Y, label_x, label_y) -> list[dict], exposed for tests)
6. For each alive element e of X (w = 2 * 5 = 10):
   - G if Y has any N within REFINE_PAD of e's site (the Y positions of e's flank ids) or within e's image in Y.
   - Inserted in X after the split (origin == X label):
     - if an ancestor with origin == X exists: the outermost such ancestor's truth, plus flag "host_empty" when it is E;
     - E if Y holds, in order and contiguous, the w ids left of e's left TSD copy, the 5 TSD ids, and the w ids right of
       e's right TSD copy, with nothing inserted between them;
     - O if those flanks are contiguous except that Y-specific sequence (ids absent from X) sits between them;
     - otherwise D.
   - Present before the split (origin backbone/shared):
     - S if e has event "solo" in Y's branch (the event is recorded on Y's copy of e);
     - P if >= COV_PRESENT of e's own ids (excluding children's ids) and of each LTR's ids are present in Y
       (flag "inv" when Y's copy has event "inv");
     - T if >= MIN_SEG of e's own ids are present; otherwise D.
   Row fields: genome (X label), eid, name (= eid), seqid, start, end (1-based inclusive in X), origin, state,
   flags (comma-joined or "").

## Outputs and CLI
7. write_pair(outdir, A, B, truth, params, seed): A.fa, B.fa (seqid "chr1" in both — a shared seqid is fine, labels
   namespace them), A.gff3, B.gff3 via annotation.gff3.write_gff3 from alive elements converted to Element (1-based;
   tsd read from the genome sequence; k; family; Name = eid) with dropout (each element dropped with probability
   `dropout`, seeded) and jitter (with probability `jitter`, start and end each shifted by U{-3..3}, LTR bounds moved
   with them); truth.tsv (all truth rows, both directions); samples.tsv ready for `ltrpav run` (A and B annotated);
   params.json (params, seed, backbone source/region).
8. CLI `ltrpav-sim pair --fasta FA --region SEQ:START-END --annotation ANNOT --outdir DIR [--seed N] [--scale X]
   [-v]`: backbone = Fasta.fetch of the region; backbone elements = load_annotation(ANNOT) elements lying wholly in the
   region (shifted to region coordinates); donors = up to 2000 level-0, childless, confidence "high" elements of the
   same annotation (any seqid), sampled with the seed, sequences fetched from FA. Fail fast on a bad region.
9. Performance target: a 6-Mb backbone with scale 1 simulates in under ~2 minutes and < 4 GB.

## Tests (tests/test_sim.py, small synthetic backbone ~400 kb random + 10 planted elements; donors from toy elements)
10. The brief's five tests, plus: provenance invariants (every TSD pair shares ids; A and B share all backbone ids
    except deleted ones), an engineered-event test that applies each event through SimGenome methods directly and
    checks compute_truth for E, O, D, P, S, T, G and host_empty, and the inversion flag.
