# Task 12 report: real inputs and the genotyping queue

Status: DONE_WITH_CONCERNS (queue launched from snapshot 12d3e6c, healthy start confirmed; concerns below)

`$P=/data2/chris/maize_introgression`, `$R=$P/benchmark_pav/plan3/real`, `$SNAP=$P/benchmark_pav/plan3/snap/12d3e6c`.

## Files
Snapshot:
- `$SNAP/` — `git -C $P/LTRpav archive 12d3e6c | tar -x -C $SNAP`; `$SNAP/SHA` = 12d3e6cbaea279ec4d8111cc9366d0bf975631af

In `$R/`:
- `edta_prep.py` — EDTA GFF3 -> structural LTR-RT GFF3.gz on the FASTA's seqids, plus `<label>.prep.json` (kept, dropped by seqid)
- `test_edta_prep.py` — 3 tests on a toy EDTA GFF3 (seqid `1`, .fai `Zn_chr1`); `test_edta_prep.out` holds the run
- `annot_counts.py` — expected vs kept vs loader counts, and the qc_fixed cross-check -> `annot_edta/counts.tsv`, `annot_counts.log`
- `annot_edta/{B73,TIL18,TIL01,TIL25,Zh,Zn}.gff3.gz` (+ `.prep.json`, `counts.tsv`); `annot_edta.prep.log`
- `check_sheets.py` — the six sheets against the brief, parsed by `ltrpav.samples.read_samples` -> `check_sheets.log`
- `{six,genus,citrus,edta}/samples.tsv`, `stability/{mm2,cap5k}/samples.tsv`
- `cap_variant.py` — sets `route.cap` on what `ltrpav.cli.get_route` returns (and `flanks.FLANK_CAP`), asserts the snapshot import, writes `variant.json`, calls `ltrpav.cli.genotype_main`
- `mem_sampler.sh` — main3's sampler, parameterized (root, output, stop file, optional limit with an overrun file and a tree kill)
- `genotype_all.sh` — the queue (markers, pause point, `--dry-run`, snapshot assertions, .fai snapshots, 250 GB guard)
- `memo.md` — CLAUDE.md memo with the "Outcome (controller)" placeholder
- `checksums.sha256` — sha256 of `annot_edta/*.gff3.gz` and every `samples.tsv` at launch
- `preflight.txt`, `fai.preflight.tsv`, `launch.txt`, `queue.log`, `fai.start.1794525622.tsv`; per block at run time `<step>.{log,time,mem.tsv,done}`, `block.done`

Nothing was written in `$P/LTRpav` except this report (checked: no new `.pyc` under `$P/LTRpav` since 18:05).

## Test output
```
$ PATH=/home/chris/bin/mambaforge/envs/ltrpav/bin:$PATH NUMPY_MADVISE_HUGEPAGE=0 PYTHONPATH=$P/benchmark_pav/plan3/snap/12d3e6c/src python -m pytest -q -W error -p no:cacheprovider real/test_edta_prep.py
...                                                                      [100%]
3 passed in 0.09s
```
(run from `$P/benchmark_pav/plan3`; `-p no:cacheprovider` keeps `.pytest_cache` out of plan3/.) Tests: (1) the brief's
case: one element on `Zn_chr1` through `load_annotation` (LTRs (105,300)/(905,1100), TSD GTTTT from the host line), the
homology line dropped (`skipped_lines: not_structural=1`), the unknown seqid counted (`dropped_by_seqid {ctg_9: 1}`);
(2) a bare `1` keeps `Zn_1` when that form is in the .fai; (3) reruns are byte-identical. `ruff check` on the five
Python files: all checks passed.

## Annotation counts
`annot_edta/counts.tsv` (annot_counts.py exit 0; loader = the snapshot's `load_annotation`):

| label | expected structural | kept structural (LTRs) | dropped records / LTR-RTs / seqids | loader elements (top-level) | loader skipped | loader on main3 qc_fixed | check |
|---|---|---|---|---|---|---|---|
| B73 | - | 52,648 (105,296) | 0 / 0 / 0 | 52,630 (51,290) | duplicate=18 | 52,630 | loader == qc_fixed |
| TIL18 | 51,214 | 51,214 (102,428) | 0 / 0 / 0 | 51,206 (50,001) | duplicate=8 | 51,206 | kept == expected; loader == qc_fixed |
| TIL01 | 58,346 | 58,346 (116,692) | 0 / 0 / 0 | 58,332 (56,852) | duplicate=14 | 58,332 | kept == expected; loader == qc_fixed |
| TIL25 | 48,503 | 48,503 (97,006) | 0 / 0 / 0 | 48,495 (47,403) | duplicate=8 | - | kept == expected |
| Zh | 55,801 | 55,801 (111,602) | 0 / 0 / 0 | 55,788 (54,437) | duplicate=13 | - | kept == expected |
| Zn | 60,696 | 60,696 (121,392) | 86,649 / 28,883 / 3,107 | 60,679 (59,063) | duplicate=17 | - | kept == expected |

Mismatches, each explained:
- Kept vs expected: none (all five equal).
- Loader vs qc_fixed (B73, TIL18, TIL01): none (equal; also equal to main3's decompose.log).
- Loader vs expected structural: lower by 8-18 per genome. Every one is the loader's `duplicate` skip: EDTA emits the
  same seqid:start-end twice, under two consecutive repeat_region parents (checked on TIL18: exactly 8 duplicated host
  spans, e.g. LTRRT_4951/4952 at chr1:192977323-192988793); the loader keeps one. Not a prep loss.
- Zn: 28,883 structural LTR-RTs on 3,107 seqids are dropped by the brief's rule. They sit on contigs EDTA names by bare
  number (e.g. `100353`); only `1`..`10` map to `Zn_chrN`. LTRmix's genus run dropped the same records (60,696 =
  60,696). See Concerns.

## Sheet checks
`check_sheets.py` exit 0 (`check_sheets.log`): every sheet parses with the engine's `read_samples` (unique labels,
FASTAs exist, roles valid); rows, order, annotation sources, groups and roles equal the brief's; every FASTA is
`inputs/<label>.fa` (B73: `inputs/B73v5.fa`) with its `.fai`; every path absolute; every annotation resolves to files
(`annotation_files`: LTRquest prefixes 4-11 tables, GFF3 1 file).

| sheet | genomes (annotated) | outgroup | directed pairs |
|---|---|---|---|
| six: B73, PT, TIL25, TIL11, TIL18, TIL01 (LTRquest), Zd | 7 (6) | Zd | 36 |
| genus: TIL01, TIL18, TIL25, Zh, Zn (annot_edta), Zd (no role) | 6 (5) | - | 25 |
| citrus: CsA, CsB, Cr (ltrquest_a), Cm, CaM, CaP (ltrquest_b) | 6 (6) | - | 30 |
| edta: B73, TIL18, TIL01 (annot_edta), Zd | 4 (3) | Zd | 9 |
| stability/mm2, stability/cap5k: B73, TIL18, TIL01 (LTRquest), Zd | 4 (3) | Zd | 9 + 9 |

Groups: six maize, maize, mexicana, parviglumis, mexicana, parviglumis, diploperennis; genus parviglumis, mexicana,
mexicana, huehuetenangensis, nicaraguensis, diploperennis; citrus sweet, sweet, mandarin, pummelo, sour, sour; edta and
stability maize, mexicana, parviglumis, diploperennis. 118 directed pairs in all.

## Snapshot assertion output
From `queue.log` (the launched queue, before the first block):
```
2026-11-12 18:20:22 snapshot: python imports $SNAP/src/ltrpav/__init__.py
2026-11-12 18:20:23 snapshot: ltrpav-genotype (/home/chris/bin/mambaforge/envs/ltrpav/bin/ltrpav-genotype) --help ok; loads 60 ltrpav files, all under $SNAP/src, cli from $SNAP/src/ltrpav/cli.py
2026-11-12 18:20:24 snapshot: ltrpav-merge (/home/chris/bin/mambaforge/envs/ltrpav/bin/ltrpav-merge) --help ok; loads 60 ltrpav files, all under $SNAP/src, cli from $SNAP/src/ltrpav/cli.py
2026-11-12 18:20:24 fingerprint: elements a78af75d7a7cc6c5e0f88878b143d014c47f7aa1a4aadfb998842c0c6b4c8dab
2026-11-12 18:20:24 fingerprint: anchor ebbfd97f3b749402f57347d075019e44100713ea2faa5c00d26ab322b71c977d
2026-11-12 18:20:24 fingerprint: raw ebbfd97f3b749402f57347d075019e44100713ea2faa5c00d26ab322b71c977d
2026-11-12 18:20:24 fingerprint: blastdb ebbfd97f3b749402f57347d075019e44100713ea2faa5c00d26ab322b71c977d
2026-11-12 18:20:24 fingerprint: mm2_index 28f6fc7945c99c187c5e9b7dcb03e777b6ef02168cb6f9258dfab6bd06822a02
2026-11-12 18:20:24 fingerprint: genotype_pair 52071c27df67dee419bfb5d8187ca882a46fbf46ac362dc57c67501b2f38b361
2026-11-12 18:20:24 fingerprint: genotype_chunk 52071c27df67dee419bfb5d8187ca882a46fbf46ac362dc57c67501b2f38b361
2026-11-12 18:20:24 tools: lastz (version 1.04.60 released 20260928); minimap2 2.31-r1302
```
How: `python -c 'import ltrpav; print(ltrpav.__file__)'` must lie under `$SNAP/src/`; for each console script,
`--help` must succeed, and `PYTHONVERBOSE=1 <script> --help` must load `$SNAP/src/ltrpav/cli.py` and no ltrpav package
file outside `$SNAP/src` (negative control with `PYTHONPATH=$P/LTRpav/src`, no bytecode written: 60 outside paths
flagged). `cap_variant.py` asserts its own import the same way (negative control: "error: ltrpav imported from
$P/LTRpav/src/ltrpav/__init__.py, not from the snapshot", exit 1). Also: `git diff --stat 12d3e6c plan3-benchmark`
(committed head 42607ad) over the engine, cli, loci, outputs and samples modules is empty.

## Queue design and its dry tests
- Blocks six, genus, citrus, edta, stability/mm2, stability/cap5k, sequential, `--threads 32`; each step under
  `/usr/bin/time -v` with the tree-PSS sampler every 5 s; markers `<step>.done` and `block.done`.
- stability/mm2: `--pair B73,TIL18` alone first (`genotype_first`), then the full block (that pair skipped by its
  checkpoint), then merge.
- 250 GB guard (`LIMIT_KB=244140625`, the plan's memory budget, GB = 1e9 bytes, in smaps KiB): applied to every step.
  Over it, the sampler writes `<block>/overrun.txt`, TERMs the step's tree (KILL after 30 s), the block stops, the
  queue goes on; a relaunch skips that block until the file is removed. The queue logs an `OVERRUN:` line; the
  dead_ends.md entry and telling the user are left to the controller (the script does not write dead_ends.md).
- Pause (R3): `queue.pause` checked before each block not yet done -> "paused before <block>", `queue.exit` 0, no
  `queue.done`. Stop now: `kill -TERM -- -<queue PID>`.
- cap5k: `cap_variant.py --flank-cap 5000 genotype ...`; the route's `params()` holds `cap: 5000`, so the anchor key
  differs from the default's; a route without a cap (mm2) is rejected (exit 1).

Tests on a scratch copy (scratchpad `p3t12/q`, toy `ltrpav-genotype`/`ltrpav-merge` whose `--help` is the real one,
so the snapshot assertion ran unchanged), no real genotyping:
- A `--dry-run` (also run in `$R`): prints all 13 step commands, writes no file, exit 0.
- B `queue.pause` before launch: "paused before six", queue.exit 0, queue.done absent, .fai unchanged.
- C full toy run: all blocks done, queue.done, queue.exit 0.
- D1 resume: six skipped by marker, genus genotype skipped, genus merge and citrus run, rest skipped.
- D2 pause mid-queue: six/genus/citrus skipped, "paused before edta", exit 0, no queue.done. D3 relaunch without
  the pause file resumes at edta, then queue.done.
- E1 failing step (exit 1): queue stops, queue.exit 1, no marker.
- E2 overrun (toy limit 30,000 KiB, toy steps touch 80 MiB): in every block the first toy ltrpav step was killed at
  about 167,000 KiB (exit 143; cap5k at its merge, as the toy cap_variant allocates nothing), overrun.txt written, the
  queue went on and ended exit 0 without queue.done; no toy process left. E3 relaunch skipped all six blocks as
  "overrun recorded".
- F `kill -TERM -- -<pgid>` on a detached toy queue: process group empty, queue.exit 143, "terminated by signal".

## Pre-launch snapshot
`preflight.txt` (2026-11-12 18:20:17 EST):
```
pgrep -af 'ltrpav|lastz|run_variant'    (nothing)
18:20:17 up 55 days,  1:32,  5 users,  load average: 175.85, 175.03, 192.97
Mem: total 1007, used 476, free 504, buff/cache 26, available 525 (GiB); Swap 15 total, 6 used
nproc 8; affinity 0-255
```
`fai.preflight.tsv` (name, size, mtime, sha256; 15 files; identical to the queue's own `fai.start.1794525622.tsv`):
```
B73v5.fa.fai	26050	1794000492	8213f0f4c94b81460dcf667c3742c9b77e58dbbb091fda6291c4b5b3fa1fbd77
CaM.fa.fai	297	1794090053	0981dc29ed8eaf03334b097610e583dafbeebff33cc2adaff0d8a98f54bfdac9
CaP.fa.fai	297	1794090054	60e2ea46f881d72c726293f0fe8898145e4e2d9469c8e0f6acc766008af56f80
Cm.fa.fai	287	1794090052	cc127e79241dbd395532d55d899ffeef795a109ec70788805a0240e7b626b0f3
Cr.fa.fai	287	1794089877	1d627f2165aecb252c15b22f555af75ae5cc3c25217eb95380e6fca5b89ec6d1
CsA.fa.fai	297	1794089875	b9d3e8ee9392d064799f588abf4d03594def3ad87e4015932db0155d014d80cd
CsB.fa.fai	297	1794089876	4109c971a2da6d7a24eae50c609271a883eb06a5cffd5f2994e28640aa315063
PT.fa.fai	479	1794095139	8ef804efeba437932211408171d56589e710a5ed4ada8b3d926255cc88b419b1
TIL01.fa.fai	8657	1794000519	132ce810b42c0ef9199a54f2816aebbbefc8ac7289b328d91660118373fd585b
TIL11.fa.fai	22965	1794095150	3340f91a3fb559d4ee1114c59adef653de4acc061bde251ce88e8e033c387a72
TIL18.fa.fai	5776	1794104574	4fda5cbecf339ba40991bf458193fdfc9d9c52c6d04d816c740df70f5b6fe561
TIL25.fa.fai	4043	1794090708	a5ccbe58c7a62bbbc957782e36155f44f7bc66834672482ceba24cc6c9996a1b
Zd.fa.fai	355242	1794421770	a4ba153597eaec207069bbaed379e9540057467e237b1d02378c541255d8566c
Zh.fa.fai	56252	1794090686	2aa7f13e74a7a99e3b6ae3cb7fcacf18aa35a632ca10c2eb2f6c7aad0f556cb2
Zn.fa.fai	175666	1794090700	afa3b0cc4cc9b6ff6d09153b6b4d042365623c20a62ba73f2390b74b162e11c4
```

## Launch PID check
```
$ cd $R && setsid -f nohup bash genotype_all.sh > queue.log 2>&1 < /dev/null      # 2026-11-12 18:20:22 EST
$ pgrep -af 'bash genotype_all.sh'
1563670 bash genotype_all.sh
$ ps -o pid,ppid,sid,pgid,cmd -p 1563670
    PID    PPID     SID    PGID CMD
1563670       1 1563670 1563670 bash genotype_all.sh
```
SID = PID = 1563670, PPID 1; cwd `$R`.

## Healthy-start evidence
Watched with Monitor until-loops on `six/genotype.log` (no foreground sleep), 18:20:22 to 18:28:28 (8 min of the
15 allowed). All three R4 conditions hold:
- **The six block's first directed pair started:** `18:22:08 INFO pair 1/36: B73 vs PT`, after the six annotated
  genomes' elements loaded (B73 127,636, PT 124,384, TIL25 119,210, TIL11 134,021, TIL18 124,641, TIL01 137,847;
  0 records skipped; B73, TIL18 and TIL01 equal main3's).
- **Anchor and alignment progress:**
  ```
  18:22:10 INFO B73 vs PT (flank-mm2): anchoring
  18:23:44 INFO PT: indexed in 81.6 s                      (minimap2 asm20 index, peak RSS 8.0 GB)
  18:26:31 INFO B73 vs PT (flank-mm2): 152860 pieces, 413077 raw blocks, 248.3 s
  18:26:45 INFO B73 vs PT (flank-mm2): 413077 raw blocks -> 110967 netted, 173.7 Mb of A anchored, d = 0.0221
  18:28:04 DEBUG chunk 194: 639 calls                       (window alignment: 32 workers, about 27 lastz)
  ```
  By 18:28:28, 32 chunks were done. The piece count equals main3's B73 pairs (152,860), and d = 0.022 for B73 vs PT
  (two maize lines) sits below main3's B73 vs TIL18 (0.033), as expected.
- **No error lines:** `grep -ciE 'error|traceback|killed' six/genotype.log` = 0; WARNING lines 0; no queue.exit.
- Memory: peak tree PSS so far 9,399,268 KiB (9.6 GB; the PT index). The queue still runs as PID 1563670 (PPID 1,
  SID 1563670). The controller watches the rest (`queue.done` / `queue.exit`).

## Concerns
1. **Zn genus annotation is chromosome-only (32% of Zn's structural LTR-RTs dropped).** The brief's rule keeps
   60,696 of 89,579 structural LTR-RTs (= LTRmix's genus count, so the comparison stays like-for-like). The other
   28,883 sit on 3,107 contigs that EDTA names by a bare number; each number maps to exactly one FASTA contig
   (`Zn_ctg_N` 416, `Zn_alt-ctg_N` 2,691, none to both), and every EDTA feature on these 4,260 numeric contig seqids
   ends within that contig's length. So a `ctg_N`/`alt-ctg_N` rule would very likely recover them, but it is a guess
   at EDTA's naming and would break parity with LTRmix. I followed the brief. Effect: Zn's own elements (Zn as A) are
   chromosome-only; Zn as B is unaffected (the whole FASTA is aligned). The controller decides whether to keep it.
2. **The 250 GB guard covers every step and kills at the threshold** (the brief names it for mm2's first pair).
   Killing, rather than letting a step finish and checking the peak afterward, keeps the plan's 250 GB budget on a
   shared server; the price is that an overrun's true peak is unmeasured (`overrun.txt` holds the first sample above
   250 GB, a lower bound). On overrun the queue logs `OVERRUN:` and goes on; it does not write dead_ends.md or tell
   the user: the controller does both, and decides whether the cause is a defect (engine-fix task) or a cost (DESIGN 9).
3. **The pause point is per block.** Blocks are long (six: 36 pairs; main3 averaged about 14 min per maize pair, so
   about 8-9 h). To free threads mid-block for Task 8's pilot, use `kill -TERM -- -1563670` (the queue's process
   group); a relaunch resumes from the pair and chunk checkpoints, losing only the running chunks.
4. **The sampler's real interval is about 20-26 s while 32 window workers run**, not 5 s: reading `smaps_rollup` of
   large forked workers is slow (main3's mem.tsv averaged 10.4 s). The 250 GB guard can therefore react up to about
   half a minute late, and short spikes between samples go unseen.
5. **Duration estimate:** 118 directed pairs; at main3's per-pair times (490-1,440 s, mean about 860 s) this is
   roughly 20-24 h, longer if the load (176 now, about 100 during main3) stays high. Disk: one minimap2 index per B
   genome per block (PT's: 4.0 GB, peak RSS 8 GB); /data2 has 129 TB free.
6. **Brief path error:** `bakeoff/run_variant.py` is not in the repo at 12d3e6c (`git show` fails); I read
   `$P/benchmark_pav/bakeoff/run_variant.py` instead. cap_variant.py follows it (patch `cli.get_route` so the
   returned route's `cap` is set; also set `flanks.FLANK_CAP`), but fails on a route without a cap instead of
   ignoring it.
7. **Do not edit genotype_all.sh while the queue runs** (bash reads scripts as it goes), and do not change env
   ltrpav (lastz, minimap2, mappy versions enter the stage keys). The env already carries `ltrpav-sim` from Plan 3's
   editable install; PYTHONPATH overrides it, and the queue asserts this before the first block.
8. Six-sheet order follows the brief's list (B73, PT, TIL25, TIL11, TIL18, TIL01, Zd), not the plan's prose order;
   it sets only the pair order and the output column order.
9. Files beyond the brief's list: `annot_counts.py`, `check_sheets.py` (to make the checks rerunnable), and the run
   records (`preflight.txt`, `fai.preflight.tsv`, `launch.txt`, logs).
