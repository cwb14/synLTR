import gzip
import os

import pysam
import pytest

from ltrpav.seqio import Fasta, n_runs, revcomp


def test_fetch_plain_and_bgzip(tmp_path):
    fa = tmp_path / "g.fa"
    fa.write_text(">s1\nACGTNNNNacgt\n>s2\nGGGG\n")
    gz = tmp_path / "g2.fa.gz"
    pysam.tabix_compress(str(fa), str(gz))
    for p in (fa, gz):
        with Fasta(p, cache_dir=tmp_path / "cache") as f:
            assert f.lengths() == {"s1": 12, "s2": 4}
            assert f.fetch("s1", 0, 12) == "ACGTNNNNACGT"
            assert f.fetch("s1", 10, 99) == "GT"


def test_fetch_uppercases(tmp_path):
    fa = tmp_path / "g.fa"
    fa.write_text(">s1\nacgtACGT\n")
    with Fasta(fa) as f:
        assert f.fetch("s1", 0, 4) == "ACGT"


def test_fetch_clipping_and_unknown(tmp_path):
    fa = tmp_path / "g.fa"
    fa.write_text(">s1\nACGT\n")
    with Fasta(fa) as f:
        assert f.fetch("s1", -5, 2) == "AC"
        assert f.fetch("s1", 3, 3) == ""
        assert f.fetch("s1", 9, 12) == ""
        with pytest.raises(KeyError):
            f.fetch("nope", 0, 1)


@pytest.mark.skipif(os.geteuid() == 0, reason="root ignores directory permissions")
def test_index_into_cache_when_dir_readonly(tmp_path):
    d = tmp_path / "ro"
    d.mkdir()
    fa = d / "g.fa"
    fa.write_text(">s1\nACGT\n")
    d.chmod(0o555)
    try:
        with Fasta(fa, cache_dir=tmp_path / "cache") as f:
            assert f.fetch("s1", 1, 3) == "CG"
        assert any((tmp_path / "cache").glob("*.fai"))
        with Fasta(fa, cache_dir=tmp_path / "cache") as f:  # reuse
            assert f.fetch("s1", 0, 1) == "A"
    finally:
        d.chmod(0o755)


@pytest.mark.skipif(os.geteuid() == 0, reason="root ignores directory permissions")
def test_unwritable_cache_is_named(tmp_path):
    """An index cache that cannot be created is named as the cause, not the FASTA."""
    d, out = tmp_path / "ro", tmp_path / "out"
    d.mkdir()
    out.mkdir()
    (d / "g.fa").write_text(">s1\nACGT\n")
    d.chmod(0o555)
    out.chmod(0o555)
    try:
        with pytest.raises(OSError, match="cannot create the FASTA index cache .*out/work/fai"):
            Fasta(d / "g.fa", cache_dir=out / "work" / "fai")
    finally:
        d.chmod(0o755)
        out.chmod(0o755)


@pytest.mark.skipif(os.geteuid() == 0, reason="root ignores directory permissions")
def test_readonly_dir_without_cache_raises(tmp_path):
    d = tmp_path / "ro"
    d.mkdir()
    fa = d / "g.fa"
    fa.write_text(">s1\nACGT\n")
    d.chmod(0o555)
    try:
        with pytest.raises(ValueError, match="cache"):
            Fasta(fa)
    finally:
        d.chmod(0o755)


def test_plain_gzip_rejected(tmp_path):
    gz = tmp_path / "g.fa.gz"
    gz.write_bytes(gzip.compress(b">s1\nACGT\n"))
    with pytest.raises(ValueError, match="recompress with bgzip"):
        Fasta(gz, cache_dir=tmp_path / "cache")


def test_n_runs_and_revcomp():
    assert n_runs("ACNNNGTnA") == [(2, 5), (7, 8)]
    assert n_runs("ACGT") == []
    assert revcomp("ACGTN") == "NACGT"
    assert revcomp("acgRYk") == "mRYcgt"
    assert revcomp("ACGTRYKMBVDHNacgtrykmbvdhn") == "ndhbvkmryacgtNDHBVKMRYACGT"  # the full IUPAC table


@pytest.mark.skipif(os.geteuid() == 0, reason="root ignores directory permissions")
def test_cached_bgzip_index_follows_the_fasta(tmp_path):
    """A bgzip FASTA in a read-only directory is indexed (.fai and .gzi) in the cache, under a
    name keyed by the FASTA's size and mtime, so a rewritten FASTA is never read through its old index."""
    d = tmp_path / "ro"
    d.mkdir()
    gz, cache = d / "g.fa.gz", tmp_path / "cache"
    pysam.tabix_compress(str(_plain(tmp_path, ">s1\nACGTACGT\n")), str(gz))
    d.chmod(0o555)
    try:
        with Fasta(gz, cache_dir=cache) as f:
            assert f.lengths() == {"s1": 8} and f.fetch("s1", 2, 5) == "GTA"
        assert len(list(cache.glob("*.fai"))) == len(list(cache.glob("*.gzi"))) == 1
        d.chmod(0o755)
        gz.unlink()
        pysam.tabix_compress(str(_plain(tmp_path, ">s1\nAC\n>s2\nGGG\n")), str(gz))
        d.chmod(0o555)
        with Fasta(gz, cache_dir=cache) as f:
            assert f.lengths() == {"s1": 2, "s2": 3}
        assert len(list(cache.glob("*.fai"))) == 2
    finally:
        d.chmod(0o755)


def _plain(tmp_path, text):
    p = tmp_path / "plain.fa"
    p.write_text(text)
    return p


def test_index_build_is_atomic_and_errors_name_the_file(tmp_path):
    """The index is built under a temporary name and renamed (nothing else is left); a FASTA htslib cannot index
    is a ValueError naming it (not pysam's SamtoolsError, which workers would not catch); close() closes."""
    fa = tmp_path / "g.fa"
    fa.write_text(">s1\nACGT\n")
    f = Fasta(fa)
    assert sorted(p.name for p in tmp_path.iterdir()) == ["g.fa", "g.fa.fai"]
    f.close()
    with pytest.raises(ValueError, match="closed"):
        f.fetch("s1", 0, 2)
    bad = tmp_path / "bad.fa"
    bad.write_text(">s1\nACGT\nACGTACGT\nAC\n")  # lines of unequal length
    with pytest.raises(ValueError, match=r"bad\.fa: cannot index the FASTA"):
        Fasta(bad)
    assert not list(tmp_path.glob("*.tmp"))
