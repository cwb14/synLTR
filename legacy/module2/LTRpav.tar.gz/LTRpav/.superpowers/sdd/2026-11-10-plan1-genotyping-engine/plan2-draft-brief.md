# Draft Plan 2 (analyses) for LTRpav

Plan 1 (genotyping engine, simulator, bake-off, whole-genome QC) is finishing. Plan 2 implements DESIGN section 7,
"Analyses from the PAV matrix", together with the analysis outputs of section 6 and the overview figure. This is
item 3 of DESIGN section 11's order of work. You draft the plan; the controller reviews it and executes it later,
subagent-driven, on a new branch `plan2-analyses` cut from `plan1-engine` once Plan 1 is complete.

## Load and follow the writing-plans skill
Invoke `superpowers:writing-plans` and follow it: the header, Global Constraints, Review Focus, task structure,
Interfaces blocks, step granularity and self-review. Two deviations:
- Skip its execution handoff. The user is away and asked for independent work, so you return the plan path to
  the controller and ask nobody anything.
- Save the plan to `/data2/chris/maize_introgression/LTRpav/docs/plans/2026-11-11-plan2-analyses.md`. That
  directory is gitignored on purpose: agent-workflow files stay out of the published repo.

## Read
- `docs/DESIGN.md` in full. It is the spec, approved by the user. Sections 1-3, 6, 7, 10 and 11-14 matter most.
  Section 7 is the scope; section 10 gives the bars the later plans test against.
- `docs/lit_review.md`, for LTRmix's methods: D statistic with block jackknife, painting HMM with target-decoy
  q-values, the rate-free split, f4-ratio, and the role rules.
- **LTRmix's code,** read-only at `/data2/chris/maize_introgression/LTRmix/`. DESIGN asks Plan 2 to port the HMM
  with target-decoy, the jackknife and the role rules from it; read them and decide what to port and how.
- **Plan 1,** `docs/plans/2026-11-10-plan1-genotyping-engine.md`, as the house format: its Global Constraints and
  Review Focus style. Do not copy its tasks.
- **The engine's real outputs and code:**
  - `src/ltrpav/loci.py` (`loci.tsv`, `pav_matrix.tsv`, `qc.tsv`) and `src/ltrpav/outputs/`;
  - `src/ltrpav/classify.py` (CALL_COLUMNS, the states, flags and reasons; rule 5a's `unanchored` U);
  - `src/ltrpav/elements.py` (element fields including K2P and family);
  - `src/ltrpav/cli.py` (the existing commands);
  - the simulator `src/ltrpav/sim/` and scorer, usable for test fixtures and checks.

  For an example of real outputs, see a finished run dir such as
  `/data2/chris/maize_introgression/benchmark_pav/bakeoff/runs/R1_s1/mm2/` (sims) or the chr10 runs when they exist.

## What the plan must cover
DESIGN 7.1-7.8:
- discovery rules and resolution symmetry;
- relationships and roles (shared-derived counts, the NJ tree, sister pair, outgroup handling and its error-rate
  estimate);
- trio tests: D_pav with a 5-Mb block jackknife, the age split, nested-cluster collapse as a check, and the
  f4-ratio;
- painting: a two-state HMM with EM, a fitted tract length, posterior tracts and target-decoy q-values;
- dating: the age gradient, the youngest donor-shared insertion per tract, and the optional sequence-identity
  layer;
- direction: n(X->Y), DFOIL-style, KKSC/4-LIST cross-checks; exploratory until simulations confirm it;
- inversions;
- mechanisms.

It must also cover:
- the outputs `stats.tsv`, `findings.txt`, `tracts.<R>.bed`, `posterior.<R>.tsv`, `inversions.tsv`,
  `mechanisms.tsv` and `overview.{png,pdf}` with `_numbers.tsv`, plus the CLI entry points;
- a final task that runs the analyses on Plan 1's whole-genome outputs:
  - the genomes are B73v5, TIL18 (parviglumis), TIL01 (mexicana) and Zd (Zea diploperennis outgroup, no
    annotation), under `/data2/chris/maize_introgression/benchmark_pav/main3/` when Task 25 has run;
  - results are reported as preliminary, because the published-claims bars belong to a later plan;
  - this answers the user's question directly: could LTR-RT PAVs have discovered the mexicana introgression into
    maize that the two papers in `/data2/chris/maize_introgression/*.pdf` describe?
  - the task names what to compare against those papers, and how.

## Facts from Plan 1 the plan must respect
- **States and classes.** P/S/T are present; E is absent; D/O/G/U are missing. D and O are never "absent" in
  sharing statistics.
- **O includes complex events** (DESIGN 5.4). The calls carry dl, dr and b_ins, so the mechanisms analysis can
  separate O at the site (|dl|, |dr| <= w) from complex O. Use them.
- **U reasons** include the window statuses, `flank_unaligned`, `inv_site`, `ambiguous` and `unanchored` (rule
  5a). An element nested in a host that is D/O/G/U inherits the host's state with `inherit`.
- **Real chr10 QC** (bake-off, provisional): about 15-25% of elements remain U after the engine fixes.
  `e_in_annot` is about 20% on real data, against 2-9% in sims; it is mostly correct nested E, because the host is
  annotated in only one genome.
  - Analyses must treat missingness explicitly: resolution symmetry, per-test resolved fractions, and no
    imputation.
- **The anchoring net is syntenic.** Transpositions under 1 Mb and orthologs on unplaced scaffolds come out
  missing.
- **The default anchoring route** is being decided by the bake-off now. Plan 2 must not depend on which route
  wins.
- **Global constraints carried from CLAUDE.md and Plan 1:**
  - Python 3, with a mamba env and `environment.yml`.
  - Streaming and indexed access; never load whole genomes.
  - pytest with small synthetic fixtures.
  - argparse with concise help and `-v`; fail fast on bad input.
  - Thresholds are principled, never tuned to known answers.
  - Few options.
  - Every figure follows the `making-figures` skill, and the plan must tell the executor to load it.
  - American English.
  - The user is the sole author: no AI attribution anywhere (commits, pyproject, README, CITATION).
  - Commits are local only; never push.

## Report back
Write the plan, then self-review it as the skill says. Then write a short summary file next to this brief,
`plan2-draft-summary.md`, with:
- the plan path and the number of tasks;
- one line per task;
- every decision you made that DESIGN does not settle, each as "decision — reason — what changes if wrong";
- any conflict between DESIGN and LTRmix's code or the engine's outputs, with how you resolved it.

Constraints:
- Read-only on everything except those two files.
- No subagents.
- Run no long jobs; quick reads of outputs are fine. Export `NUMPY_MADVISE_HUGEPAGE=0` for any Python.
- Bake-off batches are running. Do not touch `benchmark_pav/bakeoff/`, except to read finished outputs.

Return ONLY:
- the plan path;
- the task count;
- the number of decisions;
- conflicts found;
- the summary path.
