#!/usr/bin/env python3
"""Compare a per-element donor/sister score against ELAI truth in genomic windows (quick evaluator).

Input table: name (chrom:start-end#class) and two count columns (--don, --sis). Per window: score = don/(don+sis).
Reports Spearman r with the mean ELAI B73 dosage at several window sizes, with a circular-shift null that keeps
the autocorrelation of both tracks, plus the per-chromosome table (Yang et al.: chr 5, 8, 9 depleted).
"""
import argparse, re, numpy as np, pandas as pd
from scipy.stats import spearmanr


def load_truth(path, col):
    t = pd.read_csv(path, sep="\t", usecols=["chrom_v5", "pos_v5", col], dtype={"chrom_v5": str})
    t = t[t[col] > -900]
    t = t[t.chrom_v5.isin([str(i) for i in range(1, 11)])]
    t["chrom"] = "chr" + t.chrom_v5
    return t.rename(columns={"pos_v5": "pos", col: "dos"})[["chrom", "pos", "dos"]]


def parse_names(names):
    m = names.str.extract(r"^(?:[^_]+_)?(chr\d+):(\d+)-(\d+)")
    return m[0], pd.to_numeric(m[1]), pd.to_numeric(m[2])


def windows(d, truth, win):
    rows = []
    for c in sorted(truth.chrom.unique(), key=lambda x: int(x[3:])):
        tt = truth[truth.chrom == c]
        dd = d[d.chrom == c]
        n = int(max(tt.pos.max(), dd.mid.max() if len(dd) else 0) // win) + 1
        ti = (tt.pos.values // win).astype(int)
        di = (dd.mid.values // win).astype(int)
        tm = np.bincount(ti, tt.dos.values, minlength=n)
        tn = np.bincount(ti, minlength=n)
        don = np.bincount(di, dd.don.values, minlength=n)
        sis = np.bincount(di, dd.sis.values, minlength=n)
        rows.append(pd.DataFrame(dict(chrom=c, w=np.arange(n), tm=tm, tn=tn, don=don, sis=sis)))
    return pd.concat(rows)


def corr(w, min_snp=5, min_ct=1, nperm=500, seed=1):
    w = w.copy()
    w["truth"] = w.tm / w.tn.replace(0, np.nan)
    w["score"] = w.don / (w.don + w.sis).replace(0, np.nan)
    ok = (w.tn >= min_snp) & ((w.don + w.sis) >= min_ct)
    x = w[ok]
    if len(x) < 10:
        return np.nan, np.nan, len(x)
    r = spearmanr(x.score, x.truth).correlation
    rng = np.random.default_rng(seed)
    null = []
    for _ in range(nperm):
        parts = []
        for c, g in w.groupby("chrom", sort=False):
            k = rng.integers(1, len(g)) if len(g) > 1 else 0
            s = np.roll(g.score.values, k)
            parts.append(pd.DataFrame(dict(score=s, truth=g.truth.values, tn=g.tn.values, ct=np.roll((g.don + g.sis).values, k))))
        p = pd.concat(parts)
        q = p[(p.tn >= min_snp) & (p.ct >= min_ct)]
        null.append(spearmanr(q.score, q.truth).correlation)
    null = np.array(null)
    return r, (1 + (null >= r).sum()) / (1 + nperm), len(x)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("table")
    ap.add_argument("--don", required=True)
    ap.add_argument("--sis", required=True)
    ap.add_argument("--truth", default="/data2/chris/maize_introgression/benchmark/truth/elai_summary.v5.tsv")
    ap.add_argument("--col", default="B73.amp")
    ap.add_argument("--wins", default="100000,500000,1000000,2000000,5000000,10000000")
    ap.add_argument("--nperm", type=int, default=200)
    a = ap.parse_args()
    d = pd.read_csv(a.table, sep="\t")
    d["chrom"], s, e = parse_names(d.name)
    d = d[d.chrom.notna()].copy()
    d["mid"] = (s + e) // 2
    d["don"] = d[a.don]
    d["sis"] = d[a.sis]
    t = load_truth(a.truth, a.col)
    print(f"donor total {d.don.sum()}  sister total {d.sis.sum()}  genome-wide don/(don+sis) {d.don.sum()/(d.don.sum()+d.sis.sum()):.4f}")
    for win in [int(x) for x in a.wins.split(",")]:
        w = windows(d, t, win)
        r, p, n = corr(w, nperm=a.nperm)
        print(f"win {win/1e6:6.1f} Mb  n={n:6d}  spearman r={r:+.3f}  circular-shift p={p:.4f}")
    ct = d.groupby("chrom")[["don", "sis"]].sum()
    ct["score"] = ct.don / (ct.don + ct.sis)
    ct["elai_anc"] = t.groupby("chrom").dos.mean() / 2
    ct = ct.loc[sorted(ct.index, key=lambda x: int(x[3:]))]
    print(ct.round(4).to_string())
    print("per-chromosome spearman:", round(spearmanr(ct.score, ct.elai_anc).correlation, 3))


if __name__ == "__main__":
    main()
