# Task 3 report: one-pass genome builder and assembly gaps

Branch plan3-benchmark, BASE 42607ad. Commits (user identity, no trailers, not pushed):
- `0a3c0ba` Clarify removed()'s flank and host conventions (Task 2 review N1, N2; docstring only)
- `7f5cedb` Build simulated genomes in one pass with per-element copy records

Status: DONE_WITH_CONCERNS (concerns at the end; none blocks Task 4).

## Files
- `src/ltrpav/sim/popevents.py`: docstring only (0a3c0ba).
  - N1: removed()'s flank example now states its condition. The flank stops short of the solo LTR's far part when
    it is no longer than the host bases between its start and that part. That always holds when the host's removed
    stretch (ltr + internal bp) is at least the flank's length. A longer flank takes far-part bases too.
  - N2: "removed with its host" is now defined in removed()'s docstring and in the module docstring's coordinates
    paragraph. The host counts as removed when its own anchor is removed by the junction rule, or its own host is,
    up the chain. A host's own loss removes a nested insertion only through the bases it takes: a solo leaves one in
    the LTR it keeps, while a del_flank or replace takes the whole body.
- `src/ltrpav/sim/popbuild.py` (new, 885 lines):
  - `Copy`, `PopGenome`, `Lift`, `FATES`;
  - `build_chrom`, `lift_pos`, `add_gaps`;
  - internals: `_Chrom` (checks, draws, `sample(s)`), `_Sample`, interval helpers.
  - It imports nothing from msprime or tskit at module level.
- `tests/test_popbuild.py` (new, 22 tests).
- `tests/test_popmodel.py`: one line. `ltrpav.sim.popbuild` is added to test_import_without_msprime's import list,
  so the builder is proven to import without the extra.
- No engine module is touched. `git diff --stat 42607ad HEAD` shows only the four files above.

## Tests and what each pins
All use `toy_ts` exact trees (TREE7, or 2- and 3-leaf trees) on 200-kb toy backbones with hand-placed events, and
exact expected sequences unless marked statistical. Fixed donors have bodies of 2,600, 2,000 and 3,300 bp. One of
them has unequal donor LTRs (250/260), which pins "the left LTR twice".

| Test | Pins |
|---|---|
| test_tsd_both_sides | mu 0. A carrier's whole sequence is `bb[:p] + body + TSD + bb[p:]` on both strands, with `seq[start-5:start] == seq[end:end+5] == tsd`, the image coordinates, strand and target. A non-carrier's sequence equals the backbone, with fate absent, `site == p - 5`, and the target bases at `site`. |
| test_tsd_at_insertion_time | The second TSD copy holds the target bases at the insertion time. A SNP whose derived samples strictly include the carriers is in both copies. One below the insertion, or one the carriers do not share, is only in the first (left) copy. Statistical: a SNP derived in exactly the carriers lies above the insertion with share 8/9 = (top - t)/(top - bottom); 300 insertions, within 3 SE. |
| test_identical_ltrs_and_k2p | mu 0 with copy noise: k2p == 0 and the two LTR images are byte-identical, on both strands. Statistical: mu 1e-6, age 1e4, 2 leaves, 80 copies with 1-kb LTRs; mean k2p within 3 SE of 2·mu·age. |
| test_orthologous_copies_share_mutations | Statistical, 3-SE. Copies differ from the inserted body at JC p(mu·15,000), and from each other at JC p(mu·10,000): shared branches carry shared mutations. Independent paths would give p(mu·30,000). |
| test_copy_noise | Statistical: body vs donor over the left LTR and internal region differs at 0.005 ± 3 SE. Both carriers hold identical bodies (one draw per insertion). LTRs are identical and k2p is 0. |
| test_snp_bases_applied | draw_events SNPs (more than 1,000 sites): every sample holds snp_base at every site and the backbone elsewhere; derived bases occur only where snp_base differs. |
| test_copy_coordinates_hold_payload | `seq[start:end]` equals an independent recursive expectation: nesting to depth 2, strands +/−/+, a same-offset pair (youngest first), and indels in the flank shifting coordinates exactly (59,999). Also: genome strands through the host chain; two primaries at one backbone position (youngest first, exact sequence); absent nested copies' sites inside their host's image; Copy.tsd in genome orientation; then every intact copy of a drawn landscape with nesting and indels (more than 100 copies). |
| test_lift_pos | Exact values: before and after an insertion; inside and at the edges of a replaced span (deletion plus insertion at one break); inside and after an indel deletion; after an indel insertion; inside a del_flank; L maps to the genome length. Every 997th kept position holds the backbone base at `lift_pos`. Identity on an untouched sample. A position past L raises. |
| test_site_window_ignores_other_insertion | The window is exactly [p − 15, p + 10). Removals of its first base (sample 1) or its last base (samples 2, 3) give −1; removals stopping one base short on either side keep the site (samples 5, 6). An insertion 4 bp past the target, one inside the target, a SNP in the target and a small indel deletion inside the window all keep it. An indel insertion before the window shifts the site by 1. |
| test_solo_structure | Backbone and simulated (−) solos give the exact sequence, with one LTR-length segment between two TSD copies. Fate solo, `ltr_left == ltr_right == image`, own_kept, `ltr_kept` in genome order ((150, 100) on strand −), events. |
| test_solo_then_covered | A solo'd element whose remains a younger del_flank of its neighbor covers is "deleted", with events ["solo", "deleted"]. |
| test_flank_deletion | del_flank a=300 b=0: the element and 300 bp before it are gone, exactly. For an insertion, its start-side flank takes the target bases while the TSD copy stays. b=400 on another lineage. Fate deleted, image −1, events. |
| test_partial_deletion | Two overlapping del_partials: own_kept == own − union (2,300), plus the exact sequence. An insertion's del_partial: own_kept == len − 800, image bytes, k2p 0. A small indel deletion inside an element lowers own_kept but leaves the fate intact. |
| test_replace | Backbone and simulated replace: exact flanks, the replacing bases' image, own_kept 0, and the replacing sequence shared by carriers. A nested element's replacing sequence that its host's younger solo covers is "deleted". own excludes a nested backbone span. |
| test_deletion_takes_nested | A host's del_flank takes a nested insertion. A solo of a backbone element takes a primary insertion inside it. Exact sequence; fates and events. |
| test_nested_in_solo_ltr_stays | Task 2's C4a: a nested insertion in the LTR a solo leaves stays (exact sequence) and keeps its own younger replace. |
| test_indel_against_removal | An indel deletion overlapping a removal above it (carriers inside the removal's) does not happen. One from above the removal (carriers including the removal's) goes on outside it. An indel insertion inside the removed stretch is gone. Indel insertions at both junction edges stay, and so does an LTR insertion anchored before the first removed base. |
| test_site_lost | (a) draw_events on a dense del_flank toy: ins_after_loss ≥ 1; no Copy for any discarded iid; Copy keys equal elements plus kept insertions in every sample; no fate site_lost. (b) Hand-built insertion below an older del_flank: ValueError matching "existence". |
| test_backbone_k2p_adds_snps | Exact: K 0.02 plus 3 derived SNPs in a 300-bp LTR gives JC((p(0.02) + 3/300)) > 0.02, and 0.02 without SNPs. With a known transition share (2 transitions and 1 transversion between the source LTRs), the round trip keeps K and the value differs from JC's. No source K gives None. |
| test_gap_rate_and_near_share | 1 Mb, per_mb 50: 50 runs of 100 N; the sequence is unchanged outside them. Statistical: the near share is within 3 SE of 1/3 at 50 gaps and again at 300 (the tighter check). Two genomes with equal streams get identical gaps. |
| test_deterministic_and_order_free | msprime landscape with indels: the same seed gives identical bytes, copies and lifts. Building samples in reversed order is identical. Another seed differs. |
| test_bad_input_fails | Length mismatch, a loss of an unknown element, and an unknown host each raise ValueError. |

## TDD evidence
- RED 1: the module was missing (ImportError at collection).
- RED 2: against an interface-only stub (dataclasses, plus functions raising NotImplementedError), all 21 tests
  then written failed one by one with NotImplementedError. Log:
  `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t3/red.log`.
- GREEN: after implementation, 20/21 passed. The one failure was a test-helper bug, not a builder bug: the expected
  payload included a nested insertion that the sample does not carry. The helper now takes the sample.
- Mutant check (`mutants.py`, `mutants.log` in the scratch directory): 25 mutants of popbuild.py.
  - First run: 20/25 killed. The five survivors marked rules no test pinned:
    - oldest first at one backbone anchor;
    - the junction rule read as "base p removed";
    - a window one base narrower;
    - "partial" from indel deletions;
    - a solo not "deleted" when covered.
  - I added cases for each, one of them the new test_solo_then_covered.
  - Second run: 25/25 killed.
  - What the tests do not distinguish: substitution probability mu·t versus the JC form at the probed rates. The
    difference is 0.2 SE.

## Choices where the brief and rulings left room
1. **Payload substitutions.** I use JC69 per branch segment: `substitute(c, 3/4 (1 − exp(−4/3 mu t)))`. That is
   exactly "each base changes at mu per generation" with changes to a uniform other base, and it equals mu·t to
   first order. Content evolves depth first down the event's subtree, starting from the event time, with segments
   split at nested event points.
   - Memory: each insertion keeps its inserted content once, and each carrier only its differences.
   - Random draws happen once per chromosome, in a fixed order, before any sample is built: indel bases (event
     order), replacing sequences (loss order), then per insertion (hosts first, input order within a depth) its
     copy noise, any TSD coin flip, and its subtree walk.
2. **Target bases at the insertion time** (Copy.tsd and the second TSD copy).
   - A nested insertion reads its host's evolving content at its own point (exact).
   - A primary insertion reads the backbone, adjusted per SNP site in the target:
     - the derived base is used when every carrier holds it and the derived samples strictly include the carriers
       (the mutation lies above the insertion);
     - when the derived samples equal the carriers, the mutation is on the insertion's own branch: a coin with
       P(above) = (top − time)/(top − bottom);
     - otherwise the backbone base is used.
   - Named approximation: ChromEvents has no SNP times, so this assumes one mutation per site.
   - Indels in the target window are treated as younger, so they change only the in-place copy.
3. **Indels against removals** (indel events have no time).
   - A deletion overlapping a removal whose carriers include the indel's counts as "above it" and does not happen,
     on any carrier. This is thin_events' one-tree reading. Equal carriers count as above; that is a named
     approximation of a few bp per event.
   - Otherwise the deletion goes on, so its bases outside the removal are deleted too.
   - Indel insertions follow the junction rule.
   - Indels never touch payloads. A deletion over an insertion's anchor leaves the payload in place.
   - At one anchor, indel bases go after the LTR payloads, which keeps target bases adjacent to the copy.
4. **Order at one anchor.** The youngest insertion goes first, nearest the target bases. The left TSD copy must be
   adjacent: it is "those bases, in place", per R1 and popevents' convention.
5. **Replacing sequence.**
   - It sits in place of the span or body: after whatever is anchored at its start and before whatever is anchored
     at its end.
   - For a simulated insertion it goes with the insertion. For a backbone element it goes when the sample's other
     removals cover the whole replaced span; they took its place.
   - The junction rule alone would keep a nested element's replacing sequence under its host's solo when the two
     share an end. The cover rule is stated in the docstring.
   - Replacing sequence receives no insertions (Task 2's named simplification; nothing was "fixed").
6. **Fates**, in order: absent; replaced (its own replace, replacing bases kept; else deleted); deleted (own
   del_flank, an insertion's anchor or host removed, a backbone element's whole span or an insertion's whole body
   removed); solo; partial (a structural removal took own bases); intact.
   - Small indel deletions lower own_kept, never the fate.
   - A solo whose remains are later covered is deleted.
7. **Images.** Each image runs from the first to the last kept base of the span or body, nested content included.
   - A replaced copy's image is its replacing bases, for Task 4's G check on "image in Y".
   - A solo's LTRs equal its image (Plan 1).
   - LTR images, ltr_own and ltr_kept are in genome order (left = lower coordinates). On strand − the body's right
     LTR is genome-left.
   - own follows Plan 1's nested_spans order for backbone elements. For an insertion it is its donor body.
8. **site** (absent copies only, per the brief).
   - It is the genome coordinate of the first target base in genome order. On the backbone this is
     `lift_pos(p − 5)`, so an indel-deleted base maps to the next kept one. In a payload it is the lowest image of
     the five target bases; on a − host that is offset pos − 1.
   - The window is [pos − 15, pos + 10) in the host's system. For a nested insertion it is clipped to the host's
     body [0, len): it does not run into the host's TSD copy or its host's host. Named; it affects insertions
     within 15 bp of a body end.
   - An absent or removed host gives −1.
9. **K2P.**
   - Insertions: position by position over kept bases, A/C/G/T pairs only. None when saturated or when nothing is
     comparable.
   - Backbone: the source p is solved from K by bisection at the source's transition share. The share is read
     position by position from its two backbone LTRs when they have equal length and differ; otherwise JC 1/3,
     "unknown".
   - Derived SNPs are counted on kept own LTR bases and divided by the mean own LTR length.
   - None when the source K is None.
10. **Copy additions.** I added `strand`, `family` and `superfamily`, with defaults after the brief's fields. Task 4's
    `annotate(g, ...)` needs them and receives only the PopGenome; without them it would have to re-derive strands
    through host chains, which Task 4 R2 forbids.
    - Copy.tsd is in genome orientation.
    - Copy.host is None for backbone elements; the annotation parent is not carried.
    - events lists its own loss kinds carried, oldest first, plus "deleted" (gone other than by its own del_flank)
      or "clipped" (another element's removal took own bases).
11. **Lift representation.** It is the backbone tiled into pieces, each piece's start in backbone and genome
    coordinates, plus (L, genome length).
    - A deleted piece carries the genome start of the next entry.
    - This is the brief's "start of every kept piece" plus deleted pieces and a sentinel, with the same type.
    - Starts alone cannot tell where a kept piece ends when a deletion and an insertion share a break (a replace),
      so deleted pieces are needed.
    - lift_pos maps a kept position base by base, a deleted one to the next kept base, and L to the genome length.
      It raises outside [0, L].
12. **add_gaps** follows Plan 1, per genome.
    - n = round(per_mb × genome length / 1 Mb); near = round(n/3).
    - Near targets are the ends of intact or partial copies (Plan 1's "alive" analog) and the sites of absent
      copies.
    - Uniform gaps start where a full run fits; the chromosome is chosen by length. Near gaps are clipped at
      chromosome ends.
    - Copy.chrom indexes seqs. The N runs are written into seqs and gaps records (chrom, start, end).
13. **Input checks (fail fast).**
    - lengths and shapes; sorted SNP positions; indel bounds;
    - duplicate ids; unknown hosts or elements; host-chain depths; carriers outside the samples;
    - nested points off their host's subtree; carriers that are not the samples below the point.
    - thin_events runs once per chromosome inside build_chrom.

### Where removed() and the brief's "Losses" paragraph differ (R1: removed() wins)
- **del_flank of an insertion.** removed() counts the second TSD copy as the first TSD_DEFAULT bp of the end-side
  flank, so the host loses b − 5 bp after it; with b = 0 the TSD copy stays. The brief says "a and b flank bases in
  its host".
- **solo.** The brief says "everything between is deleted, nested insertions included". removed() plus the junction
  rule keep an insertion in the LTR a solo leaves (C4a), and keep one anchored exactly at the crossover junction.
- **del_partial.** Two overlapping del_partials remove their union in original coordinates. The brief is silent.
- **site_lost** is gone (R1); the existence check raises instead.

## 5-Mb probe (R3)
Script and log: `.../scratchpad/p3t3/probe5mb.py`, `probe5mb.log`, `probe5mb.time`.

Landscape: Task 2's 5-Mb landscape.
- Demog(f = 0.18), ancestry seed 11, 57,794 trees, 7 samples.
- Elements every ~5 kb with LTR 1 kb, source K set to 0.01. 50 donors. Default Rates. chrom 3.
- Run in the foreground under `timeout 15m`, with 4 BLAS/OMP threads.

Events: 2,325 insertions (depth 1,458/669/198), 1,926 losses, 476,015 SNPs, 50,247 indels.

| Step | Wall |
|---|---|
| ancestry | 29.8 s |
| draw_events | 3.1 s |
| prepare (checks, thin check, all draws and subtree walks) | 2.2 s |
| per sample | 0.32 / 0.25 / 0.27 / 0.30 / 0.24 / 0.30 / 0.25 s |
| build total | 4.1 s |
| build_chrom end to end, second call | 3.8 s (identical output to the per-sample build) |

- Genome lengths: 7.40–8.22 Mb.
- Peak memory per sample build (tracemalloc): 26.7–28.8 MB.
- Process peak RSS: 0.39 GB (/usr/bin/time: 392,940 kB), dominated by msprime ancestry. RSS did not rise across the
  seven sample builds (0.38 GB before and after).
- Total wall time: 1:07.

Audits on the built genomes, all clean:
- inherited ↔ non-absent agreement for every insertion and sample;
- for every kept backbone piece, the base at `lift_pos` (first, middle, last) equals the sample's base, backbone or
  SNP;
- LTR images lie in order inside the element image for every intact or partial copy.

Fates over all samples: intact 2,892, partial 1,295, deleted 2,557, solo 564, replaced 797, absent 10,417.

Other readings:
- Intact simulated copies: the TSD copies differ in 11.0% (expected: substitutions after insertion).
- K2P of intact simulated copies against 2·mu·age:
  - ratio of sums 1.0005, with bootstrap over insertions SE 0.008 and 95% interval [0.985, 1.018];
  - the mean of per-copy ratios (0.98) is lower only because very young copies make that ratio heavy-tailed.
- Backbone K2P with source K 0.01: median 0.081 (0.035–0.154). See concern 1.

## Engine fingerprints
`scratchpad/p3t3/fingerprints.sh 12d3e6c 7f5cedb`: all 7 STAGE_MODULES fingerprints IDENTICAL, each commit imported
alone from a git-archive snapshot (log: `fingerprints.log`).

## Suite
- Full suite: still running at handback (detached, setsid, PID 3438168, session leader 3438150 with PPID 1). It
  was about 35% through with no failure.
  - Log: `scratchpad/p3t3/suite.log`. The exit code goes to `scratchpad/p3t3/suite.done`.
  - The controller should read both files.
- Ran before the commit: `tests/test_popbuild.py`, `tests/test_popevents.py` and `tests/test_popmodel.py` with
  `-W error -m "not slow"` gave 63 passed. `ruff check .`: All checks passed.

## Concerns (Task 4 and the controller)
1. **Backbone elements age by about 2·mu·T_root in every sample.**
   - The backbone is the root state, so each sample's LTRs of a backbone element gain the derived SNPs of the whole
     root-to-sample path.
   - In the probe, source K 0.01 becomes median 0.081 at the default demography (T_root around 1M generations).
   - This is the brief's rule applied as written, and it is physical if the backbone is the root genome. But any
     K-based reading of backbone elements (annotation K2P, age bins, the scorer's K columns) will sit far above the
     source annotation's K.
   - Controller's call: whether DESIGN 12 meant this, or meant source K as present-day divergence.
2. **Named approximations from missing event times.**
   - TSD SNP inference assumes one mutation per site, with the same-branch coin.
   - An indel deletion that overlaps a removal with equal carriers is taken as younger; a few bp per event.
   - Both are stated in the module docstring.
3. **For Task 4.**
   - Use `lift_pos` only: the Lift arrays include deleted pieces and a sentinel (choice 11).
   - Copy has `strand`, `family` and `superfamily` (choice 10).
   - Copy.site is the first target base in genome order. It is set only for absent copies whose window is intact,
     else −1. R1's D reading applies to absent with site −1.
   - A replaced copy's image is its replacing bases.
   - Absent copies have own = body length, own_kept 0, ltr_kept (0, 0) and image −1.
   - Copy.tsd is in genome orientation.
   - Target overlap for O compares (host, pos) through `Copy.target`.
4. **Nested windows are clipped to the host body**: they are shorter within 15 bp of a body end. This is rare (about
   0.3% of nested offsets).
5. **Memory scale.** build_chrom returns every sample's sequence of one chromosome at once (here 7 × ~7.7 Mb).
   Task 5 should build and write chromosome by chromosome. Payload memory is one inserted content per insertion plus
   per-carrier differences.
6. **Gap near targets** are intact or partial copies' ends and absent copies' sites. Solo and replaced images are not
   targeted, as in Plan 1, which targeted alive elements only.
