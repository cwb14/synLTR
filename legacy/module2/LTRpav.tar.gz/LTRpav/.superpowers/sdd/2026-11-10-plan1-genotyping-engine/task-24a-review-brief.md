# Task 24 phase A: file-based review (ledger ruling R8; there is no repo diff)

You are the task reviewer for phase A of the aligner bake-off. Phase A changed nothing in the repo: its
deliverables are scripts and documents outside the repo, plus detached runs that are still in progress. Give both
verdicts.
- **Spec compliance:** were the phase-A requirements met?
- **Quality:** are the scripts correct, so that the numbers they produce can be trusted?

## Requirements
These files sit in the same directory as this brief.
- `task-24-brief.md`: the task. Phase A covers Steps 1-4, Step 6's setup and launch, and Step 7's read-out
  classification. Scoring, metrics, dotplots and the decision belong to phase B and are out of scope.
- `task-24-rulings.md`: controller rulings 1-12. They bind as much as the brief and override it where the two
  conflict. Rules 13-16 belong to phase B.
- `task-24a-report.md`: the implementer's report and its concerns. Verify its claims; do not trust them.

## Files under review
All in `D = /data2/chris/maize_introgression/benchmark_pav/bakeoff/`: `PARAMS.md`, `backends.py`,
`backend_check.py` (and `backend_check.log`), `bakeoff.py`, `run_variant.py`, `01_sim.sh`, `02_run_sims.py`,
`chr10_inputs.py`, `04_chr10.sh`, `06_anchorwave_readout.py`, `memo_bakeoff.md`.

Engine code they call lives in `/data2/chris/maize_introgression/LTRpav/src/ltrpav/`: `localign.py` (mappy
backend, `alnmap_from_hits`, `register_backend`), `genotype.py` (`_Genotyper.rows`), `classify.py`
(`classify_window`, `call_row`, CALL_COLUMNS), `blocks.py` and `read_paf`, `chain.py`, `window.py`, `cli.py`,
`routes`, `flanks`.

## Review focus (most likely to bite first)
1. **`06_anchorwave_readout.py`**
   - MAF minus-strand coordinates. A MAF `s` line's start is 0-based on the reverse complement for strand `-`;
     the plus-strand start is srcSize - start - size.
   - Conversion from segments to a per-window AlnMap, including strand -1 windows, where the caller
     reverse-complements B. Do the AlnMap coordinates match that reverse-complemented B window?
   - The PAF's `cg:Z` =/X CIGAR, strand and coordinates, against what `read_paf` expects.
   - Whether it really mirrors `_Genotyper.rows`.
   - Streaming, so that no more than one block pair is held in memory.
2. **`backends.py`**
   - LASTZ and WFA hit coordinates, strands and CIGAR operations, converted into the convention
     `alnmap_from_hits` expects. Compare against the mappy backend: which sequence is query and which is
     reference, how minus-strand hits are represented, and off-by-one errors.
   - The WFA guard and the penalty conversion.
3. **`run_variant.py`**
   - The patches (backend, flank cap via `route.cap`, MAPPY_BEST_N, CHUNK_WINDOWS) take effect in the forked
     workers.
   - mm2_N50 changes anchoring only, as PARAMS.md claims.
4. **`bakeoff.py`**
   - Wall time, max RSS, and the sampled process-tree RSS/PSS: is the PSS sum right, and is the sampling likely
     to miss peaks?
   - Timeout handling: are the whole process group and its forked workers killed, leaving no orphans?
   - Status classification and the runs table.
5. **`02_run_sims.py` and `04_chr10.sh`**
   - Resumability. Is any deletion confined to the run's own outdir?
   - The thread budget of rule 10 (the 64-thread run waits for the sims batch).
   - Per-run timeouts (rules 8 and 10), done and exit markers, and failure recording.
6. **`chr10_inputs.py`:** the seqid filtering and the element-set identity check (rule 9).
7. **`PARAMS.md`**
   - Is every parameter reasoned from the use case, with no choice depending on sim scores?
   - Are the variants declared?
   - Is the list of wrapper patches complete?
   - Check its factual claims about minimap2 2.31 presets (for example "asm presets set -N 50"), mappy's
     keyword support and FastGA defaults against the installed tools or their sources, where you can.

For each finding, say whether it affects runs that are already done or running, and which runs would need a
rerun. That cost decides whether a fix happens before phase B.

## Constraints
- **Read-only:** the repo and everything under `D`, except your own scratch directory `D/review24a/`.
- **Running jobs:** two batches are running detached, PIDs 3523920 (sims) and 662846 (chr10). Never signal them
  and never write into their outdirs.
- **Probes:** at most 2 threads, each bounded with `timeout 15m` in the foreground. Use env `ltrpav_bench` and
  export `NUMPY_MADVISE_HUGEPAGE=0` for every Python process.
- No subagents. American English.

## Report
Write `task-24a-review.md` in this directory:
- **Spec:** ✅ or ❌, with the unmet requirements listed;
- **Quality:** Approved or Changes needed;
- **Findings:** Critical, Important or Minor, each with file:line, evidence (probe output or reasoning), the fix,
  and the runs affected.

Return ONLY:
- the two verdicts;
- finding counts by severity, plus one line per Critical or Important finding;
- the report path.
