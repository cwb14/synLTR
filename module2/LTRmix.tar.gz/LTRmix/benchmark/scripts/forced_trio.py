#!/usr/bin/env python3
"""Benchmark helper (post hoc): run one ltrmix trio with the donor fixed by the user instead of inferred from the data.
ltrmix calls the pair sharing the most single-copy k-mers the sisters; with strong gene flow that pair can be the
admixed one (here B73 + TIL18), so a hypothesis such as 'maize -> mexicana gene flow, with two mexicana genomes as
sisters' needs the roles set by hand. Everything else is ltrmix's own code: same tests, painting and outputs."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import argparse
import os
import sys
import time

sys.path.insert(0, "/data2/chris/maize_introgression/LTRmix")
import ltrmix  # noqa: E402


class ForcedTrio(ltrmix.Trio):
    def __init__(self, libs, idx, orth, trio, threads, outdir, donor):
        self.libs, self.idx, self.orth, self.threads = libs, idx, orth, threads
        self.out = outdir
        os.makedirs(outdir, exist_ok=True)
        self.rows, self.find = [], []
        T, share = ltrmix.kmer_tallies(libs, idx, trio)
        sis = tuple(x for x in trio if x != donor)
        don = donor
        o1, o2, td = T[don]
        a_, b_ = (1, 2) if o1 == sis[0] else (2, 1)
        blk = ltrmix.block_ids(libs[don], ltrmix.np.arange(libs[don].n))
        d = ltrmix.jackknife(td[:, a_], td[:, b_], blk)
        R, S = (sis[0], sis[1]) if d["D"] >= 0 else (sis[1], sis[0])
        if d["D"] < 0:
            a_, b_ = b_, a_
            d = ltrmix.jackknife(td[:, a_], td[:, b_], blk)
        self.R, self.S, self.D = R, S, don
        self.share, self.T = share, T
        self.td_ab = (td[:, a_], td[:, b_])
        self.add("sharing", "single_copy_kmers", **{f"{'+'.join(sorted(k))}": v for k, v in share.items()})
        self.add("D_kmer", "all", **d)
        top = max(share.items(), key=lambda kv: kv[1])[0]
        self.find.append(f"Sisters set by the user: {R} + {S}; donor {don} (the data's own sister pair: "
                         f"{' + '.join(sorted(top))}).")
        self.find.append(f"D(single-copy k-mers; {R},{S};{don}) = {d['D']:+.4f} +- {d['SE']:.4f} (Z = {d['Z']:.1f}, "
                         f"{d['nblocks']} blocks of {ltrmix.BLOCK_BP / 1e6:.0f} Mb on {don}).")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--genome", action="append", required=True, metavar="LABEL=LIB", help="exactly three, as ltrmix")
    ap.add_argument("--donor", required=True, help="label of the genome to treat as the donor")
    ap.add_argument("--outdir", required=True)
    ap.add_argument("-t", "--threads", type=int, default=16)
    a = ap.parse_args()
    specs = [g.split("=", 1) for g in a.genome]
    labels = [l for l, _ in specs]
    if len(specs) != 3 or a.donor not in labels:
        sys.exit("ERROR: give three --genome and a --donor among them")
    ltrmix.ARGS = argparse.Namespace(verbose=True, threads=a.threads, no_figure=False)
    ltrmix.ARGS_THREADS[0] = a.threads
    t0 = time.time()
    libs = {lab: ltrmix.load_library(lab, sp) for lab, sp in specs}
    idx = {lab: ltrmix.Index(l) for lab, l in libs.items()}
    ltrmix.set_block_size(libs)
    orth = {}
    for i in range(3):
        for j in range(i + 1, 3):
            orth[(labels[i], labels[j])] = ltrmix.orthology(libs[labels[i]], libs[labels[j]], idx[labels[i]],
                                                            idx[labels[j]])
    os.makedirs(a.outdir, exist_ok=True)
    ltrmix.write_blocks(orth, a.outdir)
    tr = ForcedTrio(libs, idx, orth, labels, a.threads, a.outdir, a.donor)
    ltrmix.log(f"forced trio: sisters {tr.R},{tr.S}; donor {tr.D}")
    tr.patterns()
    tr.divergences()
    tr.paint(tr.R, tr.S)
    tr.inversions()
    tr.write()
    try:
        ltrmix.overview_figure(tr)
    except Exception as e:
        ltrmix.log(f"WARNING: figure failed: {e}")
    ltrmix.log(f"done ({(time.time() - t0) / 60:.1f} min)")


if __name__ == "__main__":
    main()
