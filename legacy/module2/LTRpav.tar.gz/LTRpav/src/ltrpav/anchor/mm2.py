"""Route "mm2" (whole genome): A mapped onto an index of B in-process with mappy, minimap2's binding (asm20).

A is read in chunks, so memory stays bounded on multi-Gb genomes, and mapped by a thread pool. The chunk
cores tile A; each chunk is mapped with MM2_OVERLAP bp of context on both sides of its core, and its hits are
clipped to the core, so every A position is reported by exactly one chunk, aligned in full context. minimap2
aligns through indels up to its 10-kb chaining gap (an element insertion included), so each hit is also cut
at its indels of >= SPLIT_INDEL bp: a TE-sized indel lies between blocks, where chaining bridges it, never
inside one, where the linear A-to-B map and the divergence would absorb it.
"""
from __future__ import annotations

import logging
import shutil
import subprocess
import threading
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

import mappy
import numpy as np

from ..blocks import BLOCK_DTYPE, blocks_from_rows, split_cigar
from ..checkpoint import (
    CHECKSUM_CACHE,
    atomic_path,
    clear_done,
    file_checksum,
    is_done,
    mark_done,
    marker,
    stage_key,
    tool_version,
)
from ..constants import ANCHOR_MIN, MAPPY_BEST_N, MM2_CHUNK, MM2_OVERLAP, MM2_PRESET, SPLIT_INDEL

if TYPE_CHECKING:
    from collections.abc import Iterator

    from . import PairContext

log = logging.getLogger("ltrpav.anchor")

PRESET = MM2_PRESET  # the anchoring preset (constants), also read by the flank routes
_QUEUED = 2  # chunks in flight per thread: keeps every worker busy while bounding memory
_EQX = 0x4000000  # minimap2's MM_F_EQX: CIGAR with =/X, so matches are counted per piece


@dataclass
class _Skipped:
    chunks: int = 0


class Mm2Route:
    """Whole-genome route: A, in chunks, mapped onto B's minimap2 index (built once per B FASTA)."""

    name = "mm2"
    whole_genome = True
    reads_elements = False

    def params(self, ctx: PairContext) -> dict:
        return {"preset": PRESET, "chunk": MM2_CHUNK, "overlap": MM2_OVERLAP, "min_acgt": ANCHOR_MIN,
                "best_n": MAPPY_BEST_N, "split_indel": SPLIT_INDEL, **index_versions()}

    def raw_blocks(self, ctx: PairContext) -> np.ndarray:
        """Every hit of every chunk of A on B, cut into pieces (`_pieces`), as unchained blocks.

        Chunks are read in this thread (pysam handles are not thread-safe; see `_chunks`). A chunk maps A[core
        start - MM2_OVERLAP, core end + MM2_OVERLAP) and keeps only the parts of its hits inside its core: a
        hit crossing a core boundary is cut there with exact B coordinates, and the neighboring chunk, which
        sees the same hit in its own context, reports the rest, abutting on A and B. Context on both sides
        matters: an alignment is only found in full where its seeds are, so a fragment just past a core end
        (homology ending 100 bp later, or 1 kb before an insertion) would be lost by a chunk starting at that
        core end. (Keeping a crossing hit whole instead would let the next chunk report its tail a second
        time, with alignment ends that can differ by a few bp: neither contained nor chainable, a false
        competitor.)
        A hit inside its chunk's core without an indel of >= SPLIT_INDEL bp is one block with matches = mlen
        and alen = blen (plus any ambiguous-base columns, which blen leaves out).
        """
        t0 = time.perf_counter()
        aligner = _aligner(ctx)
        b_index = {name: i for i, name in enumerate(ctx.b_fa.lengths())}
        local = threading.local()

        def work(job: tuple[int, int, int, int, str]) -> np.ndarray:
            ai, w0, start, core_end, seq = job
            buf = getattr(local, "buf", None)
            if buf is None:
                buf = local.buf = mappy.ThreadBuffer()
            rows = map_rows(aligner, buf, seq, ai, w0, b_index, start - w0, core_end - w0)
            return blocks_from_rows(rows)

        threads = max(1, ctx.threads)
        skipped = _Skipped()
        parts: list[np.ndarray] = []
        pending: deque = deque()
        n_chunks = 0
        with ThreadPoolExecutor(threads) as pool:
            for job in _chunks(ctx, skipped):
                pending.append(pool.submit(work, job))
                n_chunks += 1
                if len(pending) >= _QUEUED * threads:  # results are collected in chunk order: deterministic
                    parts.append(pending.popleft().result())
            parts.extend(f.result() for f in pending)
        raw = np.concatenate(parts) if parts else np.zeros(0, dtype=BLOCK_DTYPE)
        if skipped.chunks:
            log.info("%s: skipped %d chunk(s) with fewer than %d non-N bases", ctx.a.label, skipped.chunks,
                     ANCHOR_MIN)
        log.debug("%s vs %s (mm2): mapped %d chunks with %d threads, %d raw blocks, %.1f s",
                 ctx.a.label, ctx.b.label, n_chunks, threads, len(raw), time.perf_counter() - t0)
        return raw


def map_rows(aligner: mappy.Aligner, buf: mappy.ThreadBuffer, seq: str, ai: int, w0: int,
             b_index: dict[str, int], begin: int, stop: int) -> list[tuple]:
    """Block rows (A seqid index, A start, A end, B seqid index, B start, B end, strand, matches, alen) of the
    hits of `seq` (A[w0, w0 + len(seq)) of seqid index `ai`), kept on seq positions [begin, stop). Shared by
    the whole-genome route (chunks) and the flank routes (pieces)."""
    rows = []
    for h in aligner.map(seq, buf=buf):
        bi = b_index[h.ctg]
        for q0, q1, r0, r1, matches, alen in _pieces(h.cigar, h.q_st, h.r_st, h.r_en, h.strand, begin, stop):
            rows.append((ai, w0 + q0, w0 + q1, bi, r0, r1, h.strand, matches, alen))
    return rows


def _pieces(cigar: list, q_st: int, r_st: int, r_en: int, strand: int, begin: int,
            stop: int) -> list[tuple[int, ...]]:
    """One mappy hit as (q0, q1, r0, r1, matches, alen) pieces in query order: `split_cigar` at SPLIT_INDEL,
    kept on query positions [begin, stop) (the chunk's core). The aligner reports =/X (EQX), so matches are
    exact '=' counts; an M op raises ValueError."""
    pieces, has_m = split_cigar(cigar, q_st, r_st, r_en, strand, SPLIT_INDEL, begin=begin, stop=stop)
    if has_m:
        raise ValueError("CIGAR op M: mappy must report =/X ops (EQX)")
    return pieces


def _chunks(ctx: PairContext, skipped: _Skipped) -> Iterator[tuple[int, int, int, int, str]]:
    """(A seqid index, window start, core start, core end, window sequence) of each chunk of A, in fai order.

    The cores [k * MM2_CHUNK, (k + 1) * MM2_CHUNK) tile each sequence; the last core runs to the end once that
    is at most MM2_CHUNK + MM2_OVERLAP bp away. A window is its core plus up to MM2_OVERLAP bp on each side. A
    core with fewer than ANCHOR_MIN non-N bases cannot yield an anchor: that chunk is skipped.
    """
    for ai, (name, length) in enumerate(ctx.a_fa.lengths().items()):
        start = 0
        while start < length:
            last = start + MM2_CHUNK + MM2_OVERLAP >= length
            core_end = length if last else start + MM2_CHUNK
            w0 = max(0, start - MM2_OVERLAP)
            seq = ctx.a_fa.fetch(name, w0, core_end + MM2_OVERLAP)
            core = seq[start - w0:core_end - w0]
            if len(core) - core.count("N") < ANCHOR_MIN:
                skipped.chunks += 1
            else:
                yield ai, w0, start, core_end, seq
            if last:
                break
            start += MM2_CHUNK
        log.debug("%s: queued %s (%d bp)", ctx.a.label, name, length)


def index_versions() -> dict[str, str | None]:
    """The versions of what builds and reads B's index: the minimap2 binary (when on PATH) and mappy. Part of
    the index's key and of the mm2 and flank-mm2 routes' params."""
    return {"minimap2": tool_version("minimap2"), "mappy": mappy.__version__}


def _aligner(ctx: PairContext) -> mappy.Aligner:
    """mappy aligner on B's asm20 index, built once per B FASTA at <workdir>/anchors/<B>.asm20.mmi.

    Built by the minimap2 binary if on PATH, else by mappy; both write the same single-part index.
    """
    fasta = ctx.b_fa.path
    names = list(ctx.b_fa.lengths())
    mmi = ctx.workdir / "anchors" / f"{ctx.b.label}.{PRESET}.mmi"
    done = marker(mmi)
    sha = file_checksum(fasta, ctx.workdir / CHECKSUM_CACHE)
    key = stage_key("mm2_index", {"B": sha}, {"preset": PRESET, **index_versions()})
    if is_done(done, key):
        log.debug("%s: reusing index %s", ctx.b.label, mmi)
        aligner = _load(mmi)
    else:
        clear_done(done)
        mmi.parent.mkdir(parents=True, exist_ok=True)
        t0 = time.perf_counter()
        aligner = None
        with atomic_path(mmi) as tmp:
            if shutil.which("minimap2"):
                _minimap2_index(fasta, tmp, sum(ctx.b_fa.lengths().values()), max(1, ctx.threads))
            else:
                log.info("%s: indexing %s with mappy (no minimap2 on PATH)", ctx.b.label, fasta)
                # a failed build raises inside the block, so no partial index is left behind
                aligner = _usable(mappy.Aligner(fn_idx_in=str(fasta), preset=PRESET, best_n=MAPPY_BEST_N,
                                                extra_flags=_EQX, n_threads=max(1, ctx.threads),
                                                fn_idx_out=str(tmp)), fasta, mmi)
        if aligner is None:
            aligner = _load(mmi)
        if aligner:
            mark_done(done, key, [mmi])
            log.debug("%s: indexed in %.1f s", ctx.b.label, time.perf_counter() - t0)
    aligner = _usable(aligner, fasta, mmi)
    if list(aligner.seq_names) != names:
        clear_done(done)  # rebuilt on the next run
        raise RuntimeError(f"index {mmi} does not hold the sequences of {fasta} (in order)")
    return aligner


def _usable(aligner: mappy.Aligner | None, fasta: Path, mmi: Path) -> mappy.Aligner:
    """`aligner`, or the one error of an index that could not be built or loaded."""
    if not aligner:
        raise RuntimeError(f"could not build or load the minimap2 index of {fasta} ({mmi})")
    return aligner


def _load(mmi: Path) -> mappy.Aligner:
    """The mapping aligner on index `mmi`: asm20, MAPPY_BEST_N secondaries, =/X CIGARs."""
    return mappy.Aligner(fn_idx_in=str(mmi), preset=PRESET, best_n=MAPPY_BEST_N, extra_flags=_EQX)


def _minimap2_index(fasta: Path, out: Path, total_bp: int, threads: int) -> None:
    """Index `fasta` with minimap2 -x asm20 -d.

    -I above the genome size keeps the index in one part: mappy loads only the first part of an index.
    """
    cmd = ["minimap2", "-x", PRESET, "-t", str(threads), "-I", str(max(total_bp, 1)),
           "-d", str(out), str(fasta)]
    log.debug("indexing: %s", " ".join(cmd))
    res = subprocess.run(cmd, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
    if res.returncode != 0:
        raise RuntimeError(f"minimap2 could not index {fasta} (exit {res.returncode}): "
                           f"{res.stderr.strip()[-2000:]}")
    log.debug("minimap2: %s", res.stderr.strip())
