### Task 6: Decoy-anchored emission model for the painting

**Files:**
- Modify: `src/ltrpav/analysis/paint.py`, `src/ltrpav/analysis/constants.py`, `tests/test_paint.py`.

**Interfaces:**
- Consumes: `classes`, `fit_hmm`, `paint` and `HmmFit` (paint.py); `tests/catalog_toy` (`ToyRun`, `loc`).
- Produces:
  - in `constants.py`:
    - `PAINT_DISCOVERY = "recipient"`, DESIGN 7.1's default;
    - `PAINT_EMISSION = "em"`, the default until Task 11 rules;
    - `EMISSIONS = ("em", "decoy")`. `paint.DISCOVERY` stays the one source of the discovery choices, and the CLI reads
      it;
  - `fit_hmm(pos, emit, starts, e0, e1, fix_e0: bool = False) -> HmmFit`. With `fix_e0`, EM never updates e0.
  - `paint(cat, trio, blocks, discovery=PAINT_DISCOVERY, emission=PAINT_EMISSION, self_counts=None)`.
  - New paint rows per trio:
    - `StatRow("pav", "paint", scope, "all", "emission", <"em"|"decoy">)`;
    - numeric rows `e0_RD`, `e0_RS`, `e1_RD`, `e1_RS`: the fitted emissions, beside `donor_state`; NA for a skipped or
      collapsed painting.
- **The model.**
  - With `emission="decoy"`, e0 is fixed at the decoy's informative class frequencies, using the EM update's
    pseudocounts: `e0 = ((n_D + 0.5) / (n + 1), (n_X + 0.5) / (n + 1))`.
    - n_D and n_X are the decoy's donor-like and recipient-like loci (`classes(cat, Y, X, D, discovery)`), and n their
      sum.
    - Reason: under the target-decoy design the sister carries no D introgression, so its class mix is the empirical
      sister-like background.
  - e1 starts at `e0 * (5, 0.2)` normalized. EM updates e1, pi and L.
  - The donor-like state needs `e1[RD] > e0[RD]`.
  - Without a decoy, the model falls back to `em`, with one WARNING naming why. That covers a sister unannotated under
    recipient discovery, and a decoy with no informative locus.
  - The q-values are unchanged in definition. Whether the decoy's double use keeps them honest is measured in Task 11
    (realized FDR).

- [ ] **Step 1: Write the failing tests.** Build degenerate input directly; do not rely on a seed. A failing seeded test
  is investigated by Plan 2's rule: seeds 6-25, at most 1 of 20.

```python
def test_decoy_e0_fixed():              # emission="decoy": fit.e0 == ((n_D+0.5)/(n+1), (n_X+0.5)/(n+1))
def test_em_degenerates_decoy_does_not():  # ToyRun with sparse loci in perfectly class-segregated runs (10 RD runs of
                                            # 3 loci, 10 RS runs of 3, 200 kb apart): default fit e1[RD] > 0.99 and
                                            # e0[RS] > 0.99; decoy fit on the same input: its posteriors are not
                                            # 0/1 copies of the classes (some locus has 0.05 < post < 0.95)
def test_emission_rows():               # every painted trio has emission, e0_RD, e0_RS, e1_RD, e1_RS rows; e* sum to 1
def test_decoy_null_no_tract():         # simulate_run seed 5, no planted tract: no target tract at q <= 0.05
def test_decoy_planted_tract():         # seed 5, one planted 2-Mb RD-rich tract: mean posterior over its loci > 0.5
def test_decoy_without_decoy_falls_back():  # sister unannotated: emission row "em", one WARNING naming the reason
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement** the model as specified.
- [ ] **Step 4: Run.** Expected: PASS; then the suite. On a scratch copy of the main3_analyses view, the default
  painting's rows must be byte-identical before and after. The new emission and e* rows and the stage sentinel rows are
  excluded from the comparison: sentinels hold the stage key, which the analysis fingerprint changes.
- [ ] **Step 5: Commit:** `"Add a decoy-anchored emission model to the painting (option, off by default)"`.

---

