# Task 2: controller ruling on concern 1 (events on removed sequence)

These rulings bind as much as task-2-brief.md, and override it where they conflict. They are applied before the task
review, so the reviewer sees the final design.

## Rule: an event exists only on sequence that is present on its lineage at its time
Task 2 owns which events exist. A truth table (Task 4) must never list an insertion that cannot exist, and Task 3's
builder must not need a second copy of this rule. So the thinning happens at draw time, in Task 2.

Exactness: a Poisson process thinned by a set fixed by older events is a Poisson process on what remains. Drawing as
now and discarding the events on removed sequence therefore keeps insertions at exactly `lam` per present bp per
generation. Keep the brief's draws, including `B_X`, and add the discard step.

## 1. One definition of what a loss removes
- Add one public function in `popevents.py`. It is the only definition of what each loss kind removes, and Task 3's
  builder will import it. Suggested shape:
  `removed(loss, ...) -> list[tuple[str | None, int, int]]`, giving half-open intervals `[start, end)` in a coordinate
  system: `None` for backbone coordinates, or the iid of the simulated insertion whose body they index.
  Whether the loss ends the element is a property of its kind.
- Use the conventions in your concern:
  - solo: `[ltr_left0 + x, ltr_right0 + x)`;
  - del_flank: `[start - a, end + b)`;
  - replace: `[start, end)`;
  - del_partial: its internal interval.
- **Primary insertion X, host None, at backbone pos p.**
  - An ending loss removes X's body, in X's coordinates.
  - del_flank also removes the backbone flanks beside p.
  - replace removes no backbone sequence.
  - Define the flank interval consistently with Plan 1's pair simulator and the TSD, and state it in the docstring.
- **Two del_partials of one element on one lineage may overlap.** The removed sequence is their union, in the
  element's original coordinates. `PARTIAL_MIN` is checked against the element's original internal region. State
  this in the docstring.

## 2. Existence, oldest first
- **What exists.** An element exists at a point q on the tree (node, time) when all of the following hold:
  - q lies below its origin (for a backbone element, everywhere);
  - no surviving ending loss of the element lies on the path from q to its origin;
  - its host exists at q (recursively);
  - no surviving loss older than q on that path removed its position in the host's coordinates. That includes a
    del_partial of the host, and a backbone loss covering a host-None position.
- **Which events are kept.**
  - An insertion at point q is kept only when two things hold: its host exists at q (none needed for the backbone),
    and none of its target bases `[pos, pos + TSD_DEFAULT)` lies in an interval removed above q.
  - A loss is kept only when its element exists at the loss's point.
  - A discarded event removes nothing.
- **Order.** Each event's existence depends only on older events, so deciding events from the oldest down gives a
  unique answer. Use any implementation that gives the same answer.
- **Insertions older than a removal.** An insertion older than a loss that later removes its position is kept. It is
  then gone on the lineages below that loss. Its own younger losses and nested insertions there are discarded by the
  rule above.

## 3. Counters
- `dropped["ins_after_loss"]`: primary insertions.
- `dropped["nested_after_loss"]`: nested insertions, at any depth, for any cause in the host chain. This extends the
  brief's counter.
- `dropped["loss_after_loss"]`: losses.
- Rerun your 5-Mb probe and report each count before and after the change.

## 4. Not thinned here
SNPs and small indels create and remove no element, so they are not thinned.
- Task 3's builder writes only the sequence present on each sample's lineage, so a SNP in removed sequence vanishes
  there.
- An indel that overlaps a removed interval on a lineage is Task 3's to handle. Its brief will say so.

## 5. Tests
Use `toy_ts` exact genealogies, with expected values.
- **Primary insertion below a solo.** The target lies in a backbone element's internal region, and the insertion is
  below that element's solo: it is discarded. The same insertion on the sister branch is kept.
- **Older insertion, younger solo.** An insertion inside that internal region that is older than the solo is kept.
  Its younger loss below the solo is discarded, and `removed()` covers its host-None position.
- **Depth 2.** A depth-2 insertion below an ending loss of its host's host is discarded.
- **Nested loss.** A loss of a nested insertion below its host's ending loss is discarded.
- **del_flank.** A primary insertion inside the backbone flank removed by a simulated insertion's del_flank, below
  that loss, is discarded. One above it is kept.
- **Density.** A fixed fraction of sequence is removed on fixed branches. The kept primary count falls within 3 SD
  of `lam * (present bp x branch length)`.
- **Overlapping del_partials.** Two overlapping del_partials on one lineage: `removed()` intervals whose union is the
  expected interval.
- Rerun your mutation check on the new code and report how many mutants survive.

## Process
- **Commit.** One new commit on plan3-benchmark: "Thin simulated events on sequence an older loss removed". Use the
  existing identity, set nothing and add no trailers. The user is the sole author. Never push.
- **Checks.**
  - Run the suite detached with the env bin on PATH, as before.
  - `ruff check .` must pass.
  - Engine `STAGE_MODULES` fingerprints must be identical to 12d3e6c.
- **Report.** Append "Concern 1 ruling" to task-2-report.md, covering:
  - `removed()`'s conventions, with the del_flank flank interval for host-None insertions;
  - the counts before and after;
  - the tests.
- **Return only:**
  - status;
  - the commit;
  - the test line;
  - the before/after counts;
  - concerns.
