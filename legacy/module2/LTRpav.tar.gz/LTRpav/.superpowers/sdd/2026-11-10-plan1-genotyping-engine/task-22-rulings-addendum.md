# Task 22 — controller rulings after the implementer's report (bind like task-22-rulings.md)

The implementer listed ten deliberate deviations from the literal truth wording (report section "Deviations").
The controller rules on them as follows. A reviewer should check that each is implemented correctly and
consistently, not flag it as a spec violation.

## Accepted (truth stays biological: what happened, from provenance)
1. Site-test flanks Lf/Rf = the nearest w ids both genomes can share (born before the split, not point-mutation
   noise, each counted once, skipping e's TSD). Adjacent lineage-only insertions are therefore both E.
2. Point mutations are noise, not events: ids created or removed by `mutate` (either genome) are transparent to the
   E/O/D site test. Reason: `mutate` models point divergence; the structural events (insertions, solo, flank and
   partial deletions, gaps, inversion) define the states. Known consequence, accepted: a rare point deletion that
   removes the 5-bp target leaves truth E where the classifier may call D.
3. S requires Y to keep >= COV_PRESENT of an LTR's worth of e's ids; a solo LTR later removed falls to T or D.
4. The inv flag is relative: set when exactly one of the two copies is inverted (both directions), also on E/O
   when the site matches reversed, and on S/T.
5. A host's own ids exclude every nested element that still spans sequence, dead remains included.
6. An element dies when a deletion leaves either LTR below COV_PRESENT of its pre-edit length (an element without
   two LTRs is no longer an intact LTR-RT, so it leaves the truth and the GFF3).
7. Solo, flank deletions and partial deletions all target alive pre-split elements; solo skips elements with
   something nested inside an LTR span.
8. inv_len scales with backbone length (per 6 Mb), not with `scale`.
9. Gap targets: a third within 20 bp of an alive element end or of an empty site (the brief's wording).
10. API additions accepted: truth.tsv columns `events_x`, `events_y`; `SimElement.tsd_ids`; SimGenome extras;
    `write_pair(..., meta=None)`; `invert` returns the interval actually inverted.

## New requirement (concern 2: O never arises) — to be implemented in fix round 1, do not flag its absence
11. `PairParams.n_same_site: int = 10` (per 6 Mb per branch, multiplied by `scale` like the other counts). After
    both branches' insertions and structural events and before `mutate`, each branch X receives n_same_site extra
    insertions (origin X, K from k_branch, donors sampled as usual). Each goes to the empty site of a distinct,
    randomly chosen alive lineage-only element of the other genome Y whose site X still holds empty: insertion
    point = X's position of that element's target-site start + an offset drawn from U{0..L-1} (L = 5), so the two
    targets overlap ("same site"). One-line reason in code: parallel (hotspot) insertions at one site;
    over-represented relative to nature so that O recall is measurable. Expected truth: both elements O in the
    other genome (unless G). Test: O occurs in both directions of a default simulation; the engineered a4/b1 case
    keeps passing.
