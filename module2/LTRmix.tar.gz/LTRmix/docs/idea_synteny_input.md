# Idea (not implemented): optional synteny input for distant donors

Status: discussed 2026-11-12, not built. LTRmix stays library-only by default; this would be an optional extra.

## Problem
With a donor diverged by ~100 kyr or more, LTRmix's own synteny (built from shared intact LTR-RTs) collapses, and the
insertion test (D_ins) breaks. Wild *Zea* run (`benchmark/genus/`, PanAnd EDTA libraries), TIL18 vs *Z. nicaraguensis*:
- 3.4 M candidate pairs, 16,686 reciprocal-best pairs, but only 2,117 pass the clock test (most are paralogs) and only
  233 anchors form collinear blocks: 6 blocks on 6 of 10 chromosome pairs.
- Whole chromosomes unresolved (24,092 TIL18 elements); inside the sparse blocks, anchors Mb apart give huge search
  windows, so true orthologs lose to same-family copies: 246 orthologs vs 26,876 "absent" calls.
- Uneven placement between sisters: 0.58 of Zn's elements placeable in TIL18 vs 0.35 in TIL25. This unevenness, not
  low power, made the TIL18-vs-TIL25 control fail (D_ins Z = 3.3; it should be ~0).
- Root cause: in library-only mode, the genome that shares more with the donor gets denser anchors, so the ability
  to count insertions is entangled with the gene-flow signal being measured.

## Proposal
One optional input per genome pair, e.g. `--synteny A,B=FILE`: gene anchors as position pairs
(chromA posA chromB posB), e.g. converted from JCVI/MCscan `.anchors` + the two `.bed` files (example run:
`/data2/chris/polyploid_genomes_v2/Poa_annua/subgenome_identity/run/`). Add them to the LTR-RT anchors before
`chain_blocks`; the existing block and window logic (`_status_and_window`) then works with dense anchors.
Chromosome names must match the libraries (the Poa run renames them; see its `*_chrIDs.txt`).

Expected gains: elements placed on every chromosome; search windows of tens of kb (gene to gene) instead of Mb,
recovering missed orthologs; equal placement for both sisters, independent of the transposon signal. Deeper splits
also suit the rate-free per-element test (`benchmark/scripts/rate_free_split.py`), which worked in citrus
(split 1.0% LTR divergence) but not in maize (0.05-0.07%).

## What it would not fix
- "Absent" still means "no intact copy in the library": old insertions decay into solo LTRs or fragments. A real
  empty-site check needs the genome sequence (as `benchmark/scripts/absence_check.py` does); a natural companion
  option, since anyone with a synteny file has the genomes.
- Beyond the lifetime of intact LTR-RTs (roughly Myr) nothing shared remains to count: e.g. *Poa annua* subgenomes
  A vs B (genome-wide Ks 0.077) are likely too deep. Useful range: donors ~100 kyr to ~1 Myr away.
- Detection already works without it (single-copy k-mers: Z = 6-18 for the wild *Zea* exchange); the payoff is
  stronger confirmation (insertion tests, age pattern, per-element certificates).

## Test if built
Rerun the wild *Zea* trios with and without the file (EDTA libraries for Zh, Zn, TIL18, TIL25, TIL01). Success:
the TIL18-vs-TIL25 control flat (|Z| < 3); similar resolved fractions for both sisters (`donor_resolved` in
`stats.tsv`); huehuetenangensis and parviglumis still show excess sharing with *Z. nicaraguensis* (Chen et al. 2022).
Plus a pytest fixture: a synthetic distant donor whose LTR-RT anchors are too sparse to chain, rescued by gene anchors.
