# Task 14 report: state classifier (`classify.py`)

Status: DONE_WITH_CONCERNS
Commit: `de3d500 Add state classifier with nested hierarchy` (branch plan1-engine, existing git identity, no trailers)

## What I implemented

`src/ltrpav/classify.py`, following the brief and the rulings (rulings take precedence where they differ):
- Public: `STATES`, `CALL_COLUMNS` (29 columns, `reason` included), `Call`, `classify_window`, `call_row`, and
  `tsd_allowance(L, k, ident)` (public so the formula can be tested directly).
- Elements visited level by level from `win.eids` through `children` (parents first). Each element runs the rules
  in order; the first that matches wins. There is one small function per rule group, and each docstring names its
  rule: `_inherit` (0), `_window_rule` (1), `_flank_rule` (2, R3b), `_gap_rule` (3, R10, before any refinement),
  `_absent` (4a-4g), `_balanced` (4e), `_explained` (4f), `_empty_site` (4h), `_present` (5).
- The spans of children are left out of every coverage and aligned-bp count (overlapping sibling spans are merged
  first). The LTR intervals come from `ltr_left`/`ltr_right`, converted to window coordinates. `ident` =
  `identity(s - IDENT_FLANK, t + IDENT_FLANK)`; NaN counts as "not >= IDENT_MIN" for tiers and as d = 0 in the
  TSD allowance.
- Tier is "high" when both placement and evidence hold, "medium" when one holds, "low" when neither; G and U get
  ".". The `inv` flag goes on every call from a strand -1 window. B coordinates are genome, 1-based inclusive;
  intervals are flipped on strand -1 windows (`genome = b_end - 1 - local`).
- `call_row` returns raw Python values: numpy scalars are converted, None marks a missing value, flags are
  comma-joined or None. It raises if the call and the element have different eids.
- Fail-fast checks (ValueError): an element outside its window span; for "ok" windows, sequence lengths that do
  not match the window spans, or a strand other than ±1; an eid in the window or in `children` that is missing
  from `elements`.
- `constants.py`: added `IDENT_FLANK = 1000`, with a one-line reason (global constraint: thresholds live in
  constants).
- `docs/DESIGN.md` 5.4 now has the three ruled items: (1) the TSD allowance max(1, floor(L(K + d) + 0.5)), with d
  = local A-B divergence and a pointer to build decision 4; (2) E/D is evaluated on the balanced placement within
  the deletion's equivalent-placement range; (3) the exact TSD-copy read.

### Interpretations and additions (decisions the rulings did not fix)
1. **"Other elements lying inside the gap" (4f)** means inside the gap's equivalent-placement range
   `[g.a0, g.a1 + g.slide)`, i.e. deleted in some equally scoring placement. The strict reading (inside the
   leftmost or balanced gap) fails at the brief's own seed 7. There, chance microhomology shifts the adjacent_E
   leftmost gap 1 bp left (`[3004, 12614)`), so e2 `[7815, 12615)` lies outside it, and e1 would become D. This
   reading follows rule 4e: the outcome must not depend on which placement is reported. An element that is only
   partly deleted does not explain an overhang. `test_adjacent_requires_neighbor_inside_gap` pins this: B keeps
   e2[300:], so e1 is D.
2. **An inherited U copies the host's reason.** `test_window_status_propagates` requires reason "breakpoint" on
   descendants. Inherited calls carry the element's own coverage/ident evidence; dl/dr/b_ins/tsd_b/tsd_mm are None.
3. **An E with no readable TSD copy** (rule 4h "unknown") takes as its B site the junction: the last aligned B
   base before the gap through the first after it, the same as D. Junction sites are clamped to the B window.
4. **Overhang explanation sees only this window's elements** (`win.eids` plus their descendants), not the whole
   `elements` dict.
5. `tsd_allowance` treats a NaN K like a missing K (0). Without this, `math.floor(nan)` would raise.

## Tests and results

`tests/test_classify.py`: 192 passed, 1 strict xfail, in 2.4 s.
- Brief tests: `test_case_state` (21 cases × 7 seeds, every element's state, one call per element);
  `test_flags_and_tiers` (all required flags, forbidden flags, tiers and reasons; G/U tier "."; only U has a
  reason); `test_window_status_propagates` (host_E, nested_E, adjacent_E, P; "breakpoint" status with aln None
  and with an alignment: all U, reason breakpoint, tier ".", no site, children flagged `inherit`);
  `test_minus_strand_window_flags_inv` (case E with B reverse-complemented inside a larger genome at offset 1000,
  strand -1: E + tsd_match + inv, b_strand "-", the flipped coordinates hold revcomp(TSD); the strand +1 control
  holds the TSD).
- Rule tests: B coordinates for each state with a B offset (P/S/T image, E TSD copy, D 2-base junction, O
  insertion, G none); the evidence values and the `call_row` contract (types, column order, None/flags);
  inheritance copies the host's state, tier and site; no_alignment; the `tsd_allowance` formula; K = 0.3 rescues
  E_mm2's `tsd_match`; small_ins (O) and filler (D); balanced placement: hand-built maps reporting the deletion at
  each of 16 placements (2995-3010) all give the same E, dl/dr and site; flank loss beyond w is D; adjacency needs
  the neighbor inside the gap; a zero-length gap is U ambiguous (host gone, child aligned); flank rules (too few
  aligned bp; aligned bp only in pieces too short to form a run); inverted-hit length and overlap; tiers drop with
  low margin; a window offset (a_start = 10 kb) gives the same calls; elements outside the window are ignored;
  an element outside the window span raises.
- Seeds `(7, 0, 4, 6, 9, 11, 14)` were chosen to exercise chance microhomology, measured with refine_gap: 4, 9
  and 14 shift E's leftmost gap 1 bp left of the TSD copy (14 also gives an 8-bp slide); 6 and 7 shift
  adjacent_E's gap 2 and 1 bp left; 11 shifts nested_E's gap 2 bp left. The two seeds where `solo_tsd` fails (15,
  115) sit in a strict xfail test (`test_solo_tsd_placement_dependence`, concern 1). They are not in SEEDS.

### Per-case table over the 7 test seeds (state, flags, tier, reason: count)

| case | element | expected | observed |
|---|---|---|---|
| P | e | P | P - high: 7 |
| P_nestB | e | P +nestB | P nestB high: 7 |
| S | e | S +solo_tsd | S solo_tsd high: 7 |
| S_notsd | e | S -solo_tsd | S - medium: 7 |
| T | e | T | T - medium: 7 |
| E | e | E +tsd_match, high | E tsd_match high: 7 |
| E_mm1 | e | E +tsd_match | E tsd_match high: 7 |
| E_mm2 | e | E -tsd_match, medium | E - medium: 7 |
| D_left | e | D | D - high: 7 |
| D_both | e | D | D - high: 7 |
| O | e | O | O - medium: 7 |
| G | e | G | G - .: 7 |
| G_near | e | G | G - .: 7 |
| G_far | e | E | E tsd_match high: 7 |
| U_flank | e | U flank_unaligned | U - . flank_unaligned: 7 |
| inv_site | e | U inv_site | U - . inv_site: 7 |
| nested_E | h | P | P - high: 7 |
| nested_E | c | E | E tsd_match high: 7 |
| host_E | h | E | E tsd_match high: 7 |
| host_E | c | E +host_empty | E host_empty high: 7 |
| host_S | h | S | S solo_tsd high: 7 |
| host_S | c | D | D - medium: 7 |
| host_G | h | G | G - .: 7 |
| host_G | c | G +inherit | G inherit .: 7 |
| adjacent_E | e1 | E +adjacent | E adjacent medium: 4; E adjacent,tsd_match high: 3 |
| adjacent_E | e2 | E +adjacent | E adjacent,tsd_match high: 7 |

### Robustness scan: 200 seeds × 21 cases (not in the suite; about 1 min)
Every **state** is correct in every seed (5,000+ calls). The only mismatches with the labels are on the
`solo_tsd` flag:
- S: `solo_tsd` missing in 15/200 seeds (7.5%: 15, 30, 35, 43, 97, 103, 106, 115, 127, 160, 172, 175, ...).
- S_notsd: `solo_tsd` wrongly present in 2/200 seeds (125, 126).
- adjacent_E e1 (no label at stake): `tsd_match` missing in 49/200 seeds, so the tier is medium instead of high.

Scan (the script is in the session scratchpad: `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/scan_all.py`);
the core loop:
```python
for name in toy.CASES:
    for seed in range(200):
        c = toy.case(name, random.Random(seed)); calls = {x.eid: x for x in run_case(c)}  # run_case from test_classify
        # compare each call's state, required/forbidden flags, tier and reason with c.expect/flags/noflags/tiers/reasons
```
`cd /data2/chris/maize_introgression/LTRpav && mamba run -n ltrpav python <scratchpad>/scan_all.py 200`

## TDD evidence

RED (test file written, no module yet):
```
$ mamba run -n ltrpav python -m pytest tests/test_classify.py -q
ERROR collecting tests/test_classify.py
E   ModuleNotFoundError: No module named 'ltrpav.classify'
!!!!!!!!!!!!!!!!!!!! Interrupted: 1 error during collection !!!!!!!!!!!!!!!!!!!!
```
First run after implementing: 1 failure. `test_evidence_and_row` expected the call_row mismatch error to mention
"eid"; I reworded the message. GREEN:
```
$ mamba run -n ltrpav python -m pytest tests/test_classify.py -rxX
XFAIL tests/test_classify.py::test_solo_tsd_placement_dependence - solo_tsd reads mappy's placement: ...
191 passed, 1 xfailed in 2.42s
```
With `--runxfail`, the xfail fails for the documented reason (`state='S', flags=[]`), not with an error. Final,
after the review fixes:
```
$ mamba run -n ltrpav python -m pytest tests/test_classify.py   -> 192 passed, 1 xfailed in 2.41s
$ mamba run -n ltrpav python -m pytest                          -> 386 passed, 1 xfailed in 21.27s (no warnings)
$ mamba run -n ltrpav ruff check src tests                      -> All checks passed!
```

## Files changed
- `src/ltrpav/classify.py` (new, 423 lines)
- `tests/test_classify.py` (new, 394 lines)
- `src/ltrpav/constants.py` (+1: `IDENT_FLANK`)
- `docs/DESIGN.md` (5.4: allowance with d, balanced placement, exact TSD read; the paragraph reflowed)

## Self-review findings (fixed before commit)
- Junction B sites (D, and E without a readable copy) could fall outside the B window if a refined deletion
  reaches the window start. They are now clamped.
- `tsd_allowance` would raise on NaN K. It is now treated as unknown (0).
- `state in "GU"` was a substring test. It is now a tuple.
- `_measure` had a redundant membership filter; children are already validated in `_Ctx`.
- Test cleanup: an unclear conditional-expression assertion was made explicit; added
  `test_inheritance_copies_host_site`; the xfail docstring no longer points outside the repo.

## Concerns (for a ruling; none changes a toy state at the test seeds)

1. **`solo_tsd` depends on the placement mappy reports (rule 5), both ways.** `aligned_bp(s-L, s) >= L-1`
   reads mappy's placement of the internal deletion. When the internal region's end matches the TSD's end by
   chance, the leftmost placement moves 2 or more bp into the left TSD copy, and S loses the flag (7.5% of seeds).
   When the LTR's end matches the TSD's end, the absent right copy looks aligned, and S_notsd gains the flag (1%;
   seeds 125/126, whose LTRs end in `TCTC`). "Aligned in some placement" fixes the first case and breaks the
   second. "In every placement" does the reverse. A placement-free option is to read B's L bases on each side of
   the solo LTR's image (the image of the fully aligned A LTR, or its span extrapolated from its aligned bases)
   and match them to A's TSD within `tsd_allowance`, as rule 4h does for E. A scratch check on the real
   sequences (`scratchpad/solo_fix_check.py`) confirms the read: it gives `CTCTC`/`CTCTC` for S seeds 15 and 115
   (flag kept) and `CTCTC`/`AGGGC` and `CTCTC`/`GCTGT` for S_notsd seeds 125 and 126 (flag correctly absent),
   and the seed-7 controls agree. It is not implemented.
2. **The signed overhang test (4g, `dl' <= w and dr' <= w`) can call a false high-tier E.** A gap that ends
   *inside* the element gives a negative overhang, and a negative overhang always passes. B = L T e[:50] T R (B
   keeps 50 bp of the element between its TSD copies) is called **E + tsd_match, tier high**, with dl = -49..-50.
   The same holds for e[-50:] and e[:70] (checked on seeds 7, 1, 2). Fifty exact bp of LTR are not chance, and
   they show that the insertion happened, while E is the "ancestral absence" state that the sharing statistics
   count. Suggested fix: also require dl', dr' >= -w, i.e. |dl'|, |dr'| <= w. Element remnants larger than that
   would then be D.
3. **The exact TSD read (4h) returns "unknown" whenever the leftmost gap overlaps both TSD copies.** For
   adjacent_E's e1 this happens in 49/200 seeds (4 of the 7 test seeds): the leftmost gap starts 1-2 bp left of
   e1 and ends past it. These calls lose `tsd_match` and drop to tier medium; the state stays E. The rule 4e
   principle would suggest a copy that lies outside the gap at some placement in `[g.a0, g.a0 + g.slide]`. For
   example, T1 is outside at placement `g.a0 + (s - g.a0)` whenever `s - g.a0 <= g.slide`.
4. **The flag list in DESIGN.md 5.4 is now incomplete.** It does not name `adjacent`, `inherit`, `small_ins` or
   `filler`, and `boundary_offset` exists only as the dl/dr evidence columns. I left this alone, because the
   rulings scope the 5.4 edit to the three items.
5. **Window scope of rule 4f.** An adjacent element whose own window failed (an unresolved neighbor) is not in
   this window, so it cannot explain an overhang. That element pair would then give D instead of E + adjacent.
   This is a note for the pipeline task that builds windows.
6. **Known flag failures and seed choice.** The test seeds were chosen to exercise junction microhomology. The
   known `solo_tsd` failure seeds are deliberately kept out of SEEDS and recorded as a strict xfail, so the suite
   is green while showing the defect. When concern 1 is fixed, the xfail will XPASS and fail strictly, which is
   the signal to remove its marker.

---

# Fix report: controller rulings on the Task 14 concerns

Commit: `1520fa5 Read solo-LTR TSDs from B; bound E overhangs; TSD read over the slide range`
Status: **BLOCKED on one acceptance criterion.** All five rulings are implemented and committed, and every test
passes. Ruling 1 also asked that S_notsd pass over the 200-seed scan. Under the ruled rule it passes 197/200. The
3 failures are chance TSD matches that the ruled allowance itself permits (details below), and passing all 200
would mean changing the rule. That needs a ruling.

## Changes
1. **Ruling 1, `solo_tsd` read from B** (`_solo_tsd`, rule 5). [bmin, bmax] is the min/max of a2b over the
   element's aligned LTR bases (LTR intervals with child spans removed: `_Site.ltr_pieces`, new helper
   `_pieces`). The flag is set when both `b[bmin-L:bmin]` and `b[bmax+1:bmax+1+L]` are within `tsd_allowance`
   (the same allowance as E) of A[s-L:s] or A[t:t+L]. A shared `_Site.tsd_mm` / `_Site.allowance` now serves both
   E and S. `_b_image` returns None when nothing is aligned. The strict xfail is removed.
2. **Ruling 2, overhangs bounded on both sides** (rule 4f/4g). A side is within when `-w <= d' <= w`, or when
   `d' > w` and the overhang is explained (adjacency still applies only to positive overhangs). Otherwise the
   rule-4g order is unchanged: with b_ins < MIN_SEG, both sides within gives E (or O small_ins if b_ins > w), and
   anything else gives D (+ filler if b_ins > w).
3. **Ruling 3, TSD read over the slide range** (rule 4h). If `g.a1 <= t`, T2's image is read at x = 0, as
   before. Else, if `s - g.a0 <= g.slide`, T1 is read as `b[g.b0 + x - L : g.b0 + x]` with x = s - g.a0; when
   x <= 0 this is the old T1 branch. Else the copy is unknown.
4. **Ruling 5, `docs/DESIGN.md` 5.4.** The flag list gains `inherit`, `adjacent`, `small_ins` and `filler`, in
   the same inline style. The `tsd_match` and `solo_tsd` entries now name the allowance and the read from B. The
   E/D paragraph gains the -w..w condition (ruling 2) and the slide-range TSD read (ruling 3).
5. Module and rule docstrings are updated to match.

## Tests
- Removed: `test_solo_tsd_placement_dependence` (strict xfail). It XPASSed after ruling 1, as intended.
- Added `test_solo_tsd_read_from_b`, parametrized over the previously failing seeds. S at 15, 30 and 115
  (deletion reported 2-3 bp into the left TSD copy) keeps the flag at tier high. S_notsd at 125 and 126 (LTR ends
  in TCTC) gets no flag.
- Added `test_element_remnant_is_d_not_e`, the ruled test. On seeds 7 and 1, B = L T piece T R with piece = e[:50],
  e[-50:], e[:70] or e[-70:] gives D, tier high, min(dl', dr') < -w, no tsd_match, b_ins 0. Under the old rule
  these were E + tsd_match, tier high.
- Added `test_tsd_read_over_slide_range` on adjacent_E seeds 6 and 7, where the leftmost gap starts 2 or 1 bp left
  of e1. Both elements get E + tsd_match at tier high. e1 reads T at B 3001-3005 and e2 reads T2 at B 3006-3010,
  both with tsd_mm 0. Under the old rule e1 was unknown, at tier medium.

## Commands and output
```
$ mamba run -n ltrpav python -m pytest tests/test_classify.py            -> 200 passed in 2.44s
$ mamba run -n ltrpav python <scratchpad>/scan_all.py 200                 -> table below (45 s)
$ mamba run -n ltrpav python -m pytest                                    -> 394 passed in 21.58s (no warnings)
$ mamba run -n ltrpav ruff check src tests                                -> All checks passed!
```
Scratchpad: `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/`
(`scan_all.py`, `table.py`, `notsd_fp.py`, `seed75.py`).

## 7-seed table (7, 0, 4, 6, 9, 11, 14)
Every case matches its labels. The rows that changed:
| case | element | expected | observed |
|---|---|---|---|
| S | e | S +solo_tsd | S solo_tsd high: 7 |
| S_notsd | e | S -solo_tsd | S - medium: 7 |
| host_S | h | S | S solo_tsd high: 7 |
| adjacent_E | e1 | E +adjacent | E adjacent,tsd_match high: 7 (was 4 medium / 3 high) |
| adjacent_E | e2 | E +adjacent | E adjacent,tsd_match high: 7 |

## 200-seed scan (21 cases × seeds 0-199): state, flags, tier, reason: count
| case | element | observed |
|---|---|---|
| P | e | P - high: 200 |
| P_nestB | e | P nestB high: 200 |
| S | e | S solo_tsd high: **200** (was 185) |
| S_notsd | e | S - medium: **197**; S solo_tsd high: **3** (seeds 75, 77, 107) |
| T | e | T - medium: 200 |
| E | e | E tsd_match high: 200 |
| E_mm1 | e | E tsd_match high: 200 |
| E_mm2 | e | E - medium: 200 |
| D_left / D_both | e | D - high: 200 / 200 |
| O | e | O - medium: 200 |
| G / G_near | e | G - .: 200 / 200 |
| G_far | e | E tsd_match high: 200 |
| U_flank | e | U - . flank_unaligned: 200 |
| inv_site | e | U - . inv_site: 200 |
| nested_E | h / c | P - high: 200 / E tsd_match high: 200 |
| host_E | h / c | E tsd_match high: 200 / E host_empty high: 200 |
| host_S | h / c | S solo_tsd high: 200 / D - medium: 200 |
| host_G | h / c | G - .: 200 / G inherit .: 200 |
| adjacent_E | e1 | E adjacent,tsd_match high: **200** (was 151; unknown TSD reads: **0**/200, was 49) |
| adjacent_E | e2 | E adjacent,tsd_match high: 200 |

E calls with an unknown TSD read, counting only E calls that read their own TSD (inherited host_empty calls never
read one): **0** in every case. The only calls that disagree with a label are the 3 S_notsd calls.

## The unmet criterion: S_notsd 197/200 (needs a ruling)
B = L T LTR R lacks the second TSD copy, so the read beside the LTR's right end sees random flank. With allowance
max(1, ...) = 1 on L = 5, a random 5-mer matches CTCTC by chance with probability (1 + 5×3)/4^5 = 16/1024 = 1.6%
per seed. That predicts 3.1 false flags per 200 seeds; 3 were observed.
- Seeds 77 and 107: R[:5] is `CTGTC` or `CTCTA`, 1 mismatch from `CTCTC`. A pure chance match.
- Seed 75: the LTR ends in `C`, the same as the TSD's last base. The leftmost placement leaves the LTR's last
  base unaligned (A's T2 base takes its place), so bmax is 1 bp short. The read then starts on that `C`, giving
  `CTCTT`, 1 mismatch from `CTCTC`.

Any allowance of at least 1 mismatch on a 5-bp read gives this rate, so no reading of ruling 1 passes all 200
S_notsd seeds. I have not changed the rule. Options for the controller:
- (a) Treat S_notsd's "no solo_tsd" label as holding up to the allowance's chance rate. The scan would then check
  the rate (3/200 vs 3.1 expected) instead of 0.
- (b) Extrapolate bmin/bmax to the full span of the aligned LTR copy, i.e. the LTR's annotated ends. This removes
  the seed-75 type, where chance microhomology shortens the image, but not 77 and 107.
- (c) Use a separate, principled allowance for the solo-LTR read. The E read sits at a geometrically fixed
  junction, while a solo-LTR flank on the TSD-less side is free sequence; for example, an allowance that keeps
  the chance rate per side below a stated level. This would be a rule redesign and is the controller's call.
The suite's fixed seeds (SEEDS, plus 125 and 126 in the regression test) do not include 75, 77 or 107. They are
recorded here, not in a test.

---

# Fix report 2: option (b), solo-LTR reads anchored to the annotated LTR ends

Commit: `f99565c Anchor solo-LTR TSD reads to the LTR's annotated ends`
Status: DONE. The block is resolved by the controller's ruling: S_notsd's false-`solo_tsd` count now only has to
be consistent with chance.

## Change
`_solo_tsd` (rule 5) now anchors both reads to the LTR's annotated ends. The first aligned LTR base, in A order
over the element's own LTR pieces, is extrapolated back to the first base of the LTR that holds it:
`bmin = b(af) - (af - ltr_start)`. The last aligned LTR base is extrapolated forward to its LTR's last base:
`bmax = b(al) + (ltr_end - 1 - al)`. The reads `b[bmin-L:bmin]` and `b[bmax+1:bmax+1+L]` therefore sit right
beside the solo LTR. The allowance is unchanged (the E allowance).

Supporting code changes:
- New helper `_aligned_ends`, which returns the (A, B) pair of the first and of the last aligned position in an
  interval. `_b_image` now uses it.
- `_Site` keeps `ltrs` (the clipped LTR intervals) and `holes` in place of `ltr_pieces`.
The call's own S site, the aligned image of [s, t), is unchanged. DESIGN.md is unchanged: its `solo_tsd` entry
("read from B beside the solo LTR") still describes the rule.

## Tests
- Added `test_solo_tsd_reads_beside_the_annotated_ltr_ends`. It uses case S at seed 7 with two hand-built maps,
  one where the left LTR's last base is unaligned and one where its first base is unaligned. Both give S +
  solo_tsd at tier high. As a precondition, the test asserts that reads starting one base off (at the last
  aligned base) would miss the TSD by >= 4 mismatches.
- `test_solo_tsd_read_from_b` now also covers S_notsd seed 75, the systematic 1-bp offset seen with the real
  alignment.
- RED check: with only `classify.py` reverted to `1520fa5` (`git stash push src/ltrpav/classify.py`), both new
  tests fail (`test_solo_tsd_read_from_b[S_notsd-75]`,
  `test_solo_tsd_reads_beside_the_annotated_ltr_ends`). With the change restored, all 7 selected tests pass.

## Commands and output
```
$ mamba run -n ltrpav python -m pytest tests/test_classify.py      -> 202 passed in 2.56s
$ mamba run -n ltrpav python <scratchpad>/scan_all.py 200           -> table below
$ mamba run -n ltrpav python -m pytest                              -> 396 passed in 21.84s (no warnings)
$ mamba run -n ltrpav ruff check src tests                          -> All checks passed!
```

## 200-seed scan (seeds 0-199, all 21 cases)
Every case matches its labels in 200/200 seeds, except S_notsd:
- S: solo_tsd high 200/200.
- S_notsd: no flag (medium) 198; **false solo_tsd 2/200**, seeds 77 and 107.
  - Both are pure chance. R[:5] is `CTGTC` or `CTCTA`, 1 mismatch from `CTCTC`, within the allowance of 1.
  - Seed 75 is fixed: its read now sees `TCTTA`, 4 mismatches.
  - Chance expectation: 200 × 16/1024 = 3.1. For a Poisson count with that mean, P(X <= 2) = 0.40, and the
    central 95% range is roughly 0-7. **2 is consistent with chance.**
- adjacent_E e1 and e2: E adjacent,tsd_match high 200/200.
- E calls with an unknown TSD read (own reads only): 0 in every case.
- Unchanged from fix report 1: P, P_nestB, T, E, E_mm1, E_mm2, D_left, D_both, O, G, G_near, G_far, U_flank,
  inv_site, nested_E, host_E, host_S, host_G.

## 7 fixed test seeds (7, 0, 4, 6, 9, 11, 14)
All cases pass. The fixed seeds plus the regression seeds (S: 15, 30, 115; S_notsd: 75, 125, 126) all pass.
The chance seeds 77 and 107 are reported here, not tested, as ruled.
