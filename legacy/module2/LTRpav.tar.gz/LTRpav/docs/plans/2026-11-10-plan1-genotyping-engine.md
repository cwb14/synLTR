# LTRpav Plan 1: Genotyping Engine, Bake-off and Three-Genome QC Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** An installable, tested genotyper (`ltrpav run`) that calls the state of every annotated LTR-RT insertion
(P/S/T/E/D/O/G/U) at its orthologous site in every other genome, with its default anchoring route chosen by a
bake-off and its accuracy measured on simulations and on B73/TIL18/TIL01 + *Z. diploperennis*.

**Architecture:** Two tiers per ordered genome pair (A annotated, B target). Anchoring (pluggable route -> PAF-like
blocks -> one shared chain + 1:1 net) finds *where* each site is. A fixed local step (mappy window alignment, exact
junction DP, rule classifier) reads *what* is there. Elements resolve outermost-first inside their host's window.
Calls from all pairs merge into a locus catalog written as TSV, VCF, GFF3/BED and QC tables, with stage checkpoints.

**Tech Stack:** Python >=3.10 (env 3.12), numpy, numba, pysam, mappy 2.31. External: minimap2 2.31, FastGA
1.5.20260729, BLAST 2.17.0, LASTZ 1.04.60, bcftools 1.25. AnchorWave 1.3.1 and pywfa 0.6.0 for the bake-off only.
pytest, ruff, hatchling.

**Spec:** `/data2/chris/maize_introgression/LTRpav/docs/DESIGN.md` (approved 2026-11-10); literature in
`docs/lit_review.md`.

**Plan series:** 1 (this) engine, pair simulator, bake-off, three-genome QC -> 2 analyses (DESIGN 7, overview
figure) -> 3 population simulator and benchmark (DESIGN 10.2-10.4) -> 4 head-to-head, report, release (10.5,
packaging). Each later plan is written when the previous one finishes, from its results.

**Builder calls made here (Task 1 records them in DESIGN.md section 12):**
1. Engine before bake-off: the bake-off scores routes through the full pipeline, so it needs the engine first.
2. W-minimap2 runs in-process (mappy) on 100-kb query chunks. That bounds memory (the 545-GB run aligned whole
   chromosomes as queries) and removes the chromosome-pair pass.
3. Flank uniqueness: flank pieces exclude annotated LTR-RTs and N runs; placement uniqueness comes from the mapper
   plus the 1:1 net margin. This replaces genome-wide k-mer counting.
4. E's TSD allowance adds the local A-B divergence d: `max(1, floor(L*(K + d) + 0.5))`. This reduces to DESIGN's
   `max(1, round(5K))` when d is about 0, and covers mismatches the A-B split adds.
5. VCF `INFO/AA` holds the REF base where an empty site is observed. VCF 4.3 defines AA as an allele sequence,
   so the design's `AA=0` would not be valid.
6. The alternative local aligners (LASTZ, WFA2, AnchorWave MAF) live in the bake-off code, through a
   `register_backend` hook. The package ships only the winner (DESIGN: the local step is fixed).

## Global Constraints

- Python `>=3.10`; CI matrix 3.10, 3.12, 3.13; package `ltrpav`, src layout, hatchling, `GPL-3.0-or-later`.
- Author everywhere: `Chris Benson <oulab.osu@gmail.com>` (as in `code/LTRquest/pyproject.toml`). No AI attribution in
  any file, commit message or trailer. Commit with the existing global git identity; never set author/committer.
- Commits are local, on branch `plan1-engine`; never push.
- `os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")` runs before numpy is imported (`src/ltrpav/__init__.py`).
- Never load a whole genome: FASTA access only through `seqio.Fasta.fetch` (pysam random access).
- Real-data jobs: <= 64 threads and <= 250 GB RAM; anything over 15 min runs as
  `setsid -f nohup <cmd> > log 2>&1 < /dev/null`, PID verified (`pgrep -af`, then `ps -o pid,ppid,sid,cmd`).
- `run/`, `inputs/` and every LTRmix result are read-only. Real-run outputs go under
  `/data2/chris/maize_introgression/benchmark_pav/`.
- Thresholds come from `src/ltrpav/constants.py` (one line of reason each); never tune one against a truth set.
- Coordinates: internal 0-based half-open; every file a user reads is 1-based inclusive (GFF3, TSV, VCF), except BED.
- CLI: argparse, short help, `-v/--verbose`; default log = start, milestones, done, errors.
- American English in code, docs and messages.

## Review Focus

1. Two genomes that use the same seqids (both "chr1") must stay apart in blocks, calls and loci. Test: Task 21
   `test_run_shared_seqids`.
2. Soft-masked (lowercase) FASTA must give the same calls as uppercase. Tests: Task 3 `test_fetch_uppercases`,
   Task 16 `test_pair_lowercase_target`.
3. An element within a few bp of a sequence end gets `U` (`no_left_anchor`/`no_right_anchor`) and TSD `None`,
   never an exception. Tests: Task 8 `test_infer_tsd_at_sequence_start`, Task 11 `test_window_at_sequence_start`.
4. Partially overlapping (not nested) annotated elements are both top-level and share one merged window.
   Tests: Task 8 `test_nesting_partial_overlap`, Task 11 `test_windows_merge_overlap`.
5. A pair with no alignment at all gives every element `U` (`no_anchor`) plus a warning, and the run completes.
   Test: Task 16 `test_pair_unrelated_genomes`.

## File Structure

```
LTRpav/
  pyproject.toml  environment.yml  environment.lock.yml  LICENSE  README.md  .gitignore
  .github/workflows/ci.yml
  src/ltrpav/
    __init__.py        version; THP env guard
    constants.py       every fixed threshold, one-line reason each
    seqio.py           Fasta random access (index fallback to cache), revcomp, N runs
    samples.py         samples sheet -> list[Sample]
    elements.py        Element record, eid, elements TSV I/O
    annotation/
      __init__.py      load_annotation dispatcher, nesting, TSD inference, validation
      ltrquest.py      LTRquest PREFIX_depth*_clean_ltr.tsv
      gff3.py          GFF3 reader (LTRquest + EDTA conventions) and writer
      bed.py           BED reader, find_ltrs
    blocks.py          block dtype, PAF reader, linear A->B mapping, npz I/O
    chain.py           chaining DP (numba) and 1:1 net with margins
    window.py          anchors -> windows, U reasons, window merging
    localign.py        AlnMap, mappy window alignment, backend hook
    junction.py        exact junction refinement (numba Gotoh, split DP)
    classify.py        state rules, hierarchy, flags, evidence, tier
    anchor/
      __init__.py      PairContext, Route registry, anchor_pair (cache, chain, net)
      mm2.py           W route: in-process mappy, chunked queries
      paf.py           W route: external PAF (any whole-genome aligner)
      fastga.py        W route: FastGA
      flanks.py        flank pieces; F routes (mappy, BLAST); hybrid
    checkpoint.py      checksums, stage keys, .done.json markers
    genotype.py        one ordered pair: windows -> workers -> calls
    loci.py            union-find loci, per-genome states, conflicts, QC counters
    outputs/
      tables.py        loci.tsv, pav_matrix.tsv, qc.tsv
      vcf.py           pav.vcf.gz + .tbi, pav.unplaced.tsv
      tracks.py        <label>.pav.gff3 / .bed
      manifest.py      manifest.json
    cli.py             ltrpav run, ltrpav-anchor, ltrpav-genotype, ltrpav-merge
    sim/
      genome.py        SimGenome: edits with provenance tracking
      pair.py          two-genome simulator on a real backbone, truth
      score.py         calls vs truth
      cli.py           ltrpav-sim pair
  tests/  toy.py (synthetic builders) + one test file per module
benchmark_pav/bakeoff/   (outside the repo) bake-off scripts, PARAMS.md, REPORT.md
benchmark_pav/main3/     (outside the repo) whole-genome run, QC.md
```

---

### Task 1: Repository scaffold and environment

**Files:**
- Create: `LTRpav/pyproject.toml`, `LTRpav/environment.yml`, `LTRpav/LICENSE`, `LTRpav/README.md`,
  `LTRpav/.gitignore`, `LTRpav/.github/workflows/ci.yml`, `LTRpav/src/ltrpav/__init__.py`,
  `LTRpav/src/ltrpav/constants.py`, `LTRpav/tests/test_smoke.py`
- Modify: `LTRpav/docs/DESIGN.md` (section 12: add "Build decisions (plan 1)" with the six builder calls above)

**Interfaces:**
- Produces: `ltrpav.__version__ = "0.1.0.dev0"`; `ltrpav.constants` with exactly these names and values:

```python
TSD_DEFAULT = 5            # most LTR-RTs make 4-6-bp TSDs; 5 bp is the common case
SLOP_TSD_MULT = 2          # E needs the gap within ~2 TSD lengths of the element ends (DESIGN 5.4)
COV_PRESENT = 0.8          # Wicker et al. 2007 80-80-80 rule: >=80% of a part aligned = present
SOLO_LEN = (0.8, 1.2)      # a solo-LTR is one LTR's worth of aligned sequence, same 80% rule
MIN_SEG = 80               # Wicker's 80-bp minimum: less aligned sequence counts as none
IDENT_MIN = 0.8            # flank identity below the 80% rule: site placement not trusted
MARGIN_HIGH = 0.5          # orthologous chain outscores any competitor 2:1
ANCHOR_MIN = 100           # FastGA's default minimum alignment length; shorter anchors not trusted
WINDOW_PAD = 500           # anchored sequence kept at each window end so the local aligner can seed
WINDOW_CAP = 500_000       # runtime guard on window span (A and B); bake-off reports its cost
CHAIN_MAX_GAP = 1_000_000  # no chaining across >1 Mb without alignment
CHAIN_INDEL_COST = 0.05    # per bp of diagonal shift: a 30-kb insertion is bridged by >=1.5 kb of alignment
CHAIN_OVERLAP = 100        # tolerated overlap of consecutive blocks (chunk and seed edges)
CHAIN_LOOKBACK = 200       # predecessors examined per block in the chaining DP
MIN_CHAIN_SCORE = 1000     # a chain must carry >=1 kb of aligned sequence
REFINE_PAD = 150           # junction refinement half-width; covers local-aligner end error
SCORE = (1, 4, 6, 2)       # match, mismatch, gap open, gap extend: minimap2 asm20 short-gap scoring
MM2_CHUNK = 100_000        # query chunk for in-process whole-genome mapping; bounds memory
MM2_OVERLAP = 10_000       # chunk overlap so no alignment is lost at a chunk edge
FLANK_TARGET = 2000        # unique flank bases collected per side (DESIGN 5.1: >=1-2 kb)
FLANK_CAP = 10_000         # farthest a flank may reach (bake-off varies 2/5/10/20 kb)
FLANK_PIECE_MIN = 200      # shorter flank pieces seed poorly and multi-map
CHUNK_WINDOWS = 2000       # windows per worker task: bounds memory, sets resume granularity
DEFAULT_ROUTE = "mm2"      # provisional; Task 24 sets it from the bake-off
```

- [ ] **Step 1: Create the repo and branch.** `cd /data2/chris/maize_introgression/LTRpav && git init && git checkout -b plan1-engine`.
  Check `git config user.name` prints the user's name (global config exists); never pass `--author` or `-c user.*`.
- [ ] **Step 2: Write `tests/test_smoke.py`**

```python
import os

def test_import_sets_thp_guard_and_version():
    import ltrpav
    assert ltrpav.__version__ == "0.1.0.dev0"
    assert os.environ["NUMPY_MADVISE_HUGEPAGE"] == "0"

def test_constants_are_numbers():
    from ltrpav import constants as c
    assert c.SLOP_TSD_MULT * c.TSD_DEFAULT == 10
    assert 0 < c.COV_PRESENT < 1 and c.SOLO_LEN == (0.8, 1.2) and c.DEFAULT_ROUTE == "mm2"
```

- [ ] **Step 3: Write `pyproject.toml`.** Model it on `code/LTRquest/pyproject.toml`: hatchling, `[tool.hatch.version] path = "src/ltrpav/__init__.py"`,
  `requires-python = ">=3.10"`, license `GPL-3.0-or-later`, the author above, dependencies `numpy>=1.26`, `numba>=0.60`,
  `pysam>=0.22`, `mappy>=2.28`; extra `dev = ["pytest>=8", "ruff>=0.5"]`; scripts `ltrpav = "ltrpav.cli:main"`,
  `ltrpav-anchor = "ltrpav.cli:anchor_main"`, `ltrpav-genotype = "ltrpav.cli:genotype_main"`,
  `ltrpav-merge = "ltrpav.cli:merge_main"`, `ltrpav-sim = "ltrpav.sim.cli:main"`; pytest marker `slow` (real data or
  long runs); ruff `line-length = 110`, `target-version = "py310"`. URLs: `https://github.com/cwb14/LTRpav`.
- [ ] **Step 4: Write `environment.yml`** (name `ltrpav`; channels conda-forge, bioconda): `python=3.12`, `numpy`,
  `numba=0.68.1`, `pysam`, `mappy=2.31`, `minimap2=2.31`, `fastga=1.5.20260729`, `blast=2.17.0`, `lastz=1.04.60`,
  `bcftools=1.25`, `htslib`, `pytest`, `ruff`, `hatchling`, `pip`, and pip `-e .`. Then run
  `mamba env create -f environment.yml && mamba env export -n ltrpav > environment.lock.yml`.
- [ ] **Step 5: Write `src/ltrpav/__init__.py`** (THP guard first, then `__version__`) and `constants.py` (module
  docstring "Fixed internal constants; each has a one-line reason. Nothing here is tuned to a dataset." + the block above).
- [ ] **Step 6: Write the rest.** LICENSE (copy `code/LTRquest/LICENSE`); README stub (one paragraph, "under development").
  `.gitignore`: `__pycache__/ *.egg-info/ .pytest_cache/ .ruff_cache/ docs/plans/ /out/`. Plans stay unpublished.
  CI: copy the `code/LTRquest/.github/workflows/ci.yml` structure, matrix `["3.10", "3.12", "3.13"]`, test command
  `pytest -m "not slow" -q`, lint job `ruff check --output-format github .` (drop shellcheck).
  Finally add the DESIGN.md section 12 subsection.
- [ ] **Step 7: Verify.** `mamba run -n ltrpav pytest -q && mamba run -n ltrpav ruff check .`. Expected: 2 passed, ruff clean.
- [ ] **Step 8: Commit.** `git add -A && git commit -m "Scaffold package, environment and CI"`

---

### Task 2: Launch the AnchorWave yardstick on chr10 (runs while the engine is built)

**Files:** Create (outside repo): `benchmark_pav/bakeoff/env_bench.yml`, `benchmark_pav/bakeoff/anchorwave/run.sh`,
`benchmark_pav/bakeoff/anchorwave/README.md`

- [ ] **Step 1: Create the bench env.** Write `env_bench.yml`: name `ltrpav_bench`, the Task 1 dependencies plus
  `anchorwave=1.3.1`, `samtools`, `pywfa=0.6.0`, and pip `-e /data2/chris/maize_introgression/LTRpav`. Then run
  `mamba env create -f env_bench.yml`.
- [ ] **Step 2: Write `run.sh`** (`set -euo pipefail`, `cd` to its own dir). Steps:
  - `samtools faidx inputs/B73v5.fa B73v5_chr10 | sed '1s/.*/>chr10/' > B73_chr10.fa`, and the same for
    `TIL18_chr10`. genoAli pairs chromosomes by name.
  - `zcat benchmark_data/annot/Zm-B73-REFERENCE-NAM-5.0_Zm00001eb.1.gff3.gz | awk '/^#/ || $1=="chr10"' > genes_chr10.gff3`
    (2,705 genes).
  - `anchorwave gff2seq -i genes_chr10.gff3 -r B73_chr10.fa -o cds.fa`
  - `minimap2 -x splice -t 8 -k 12 -a -p 0.4 -N 20 TIL18_chr10.fa cds.fa > cds.sam`, and the same against
    `B73_chr10.fa` into `ref.sam`.
  - `/usr/bin/time -v anchorwave genoAli -i genes_chr10.gff3 -as cds.fa -r B73_chr10.fa -a cds.sam -ar ref.sam -s TIL18_chr10.fa -n anchors -o anchorwave.maf -f anchorwave.f.maf -IV -t 8`
  - Write `done.flag` at the end.
- [ ] **Step 3: Launch detached.** From the anchorwave dir:
  `setsid -f nohup mamba run -n ltrpav_bench bash run.sh > run.log 2>&1 < /dev/null`. Then check `pgrep -af genoAli`
  (or `pgrep -af run.sh`) and `ps -o pid,ppid,sid,cmd -p <pid>`. Expected: SID = PID and PPID = 1.
- [ ] **Step 4: Record.** In `README.md` write memo-style lines: date, purpose, env, commands, PID, expected outputs
  (`anchorwave.maf`, `done.flag`). Not committed; it lives outside the repo.

---

### Task 3: FASTA access (`seqio.py`)

**Files:** Create `src/ltrpav/seqio.py`, `tests/test_seqio.py`

**Interfaces:**
- Produces: `class Fasta(path: str | Path, cache_dir: Path | None = None)` with `.lengths() -> dict[str, int]`
  (fai order), `.fetch(seqid: str, start: int, end: int) -> str` (0-based half-open, clipped to the sequence,
  uppercase), `.close()`; `revcomp(seq: str) -> str`; `n_runs(seq: str) -> list[tuple[int, int]]` (0-based
  half-open runs of N/n). Raises `ValueError` for plain-gzip (not bgzip) FASTA with the hint "recompress with bgzip".

- [ ] **Step 1: Write the failing tests**

```python
def test_fetch_plain_and_bgzip(tmp_path):
    fa = tmp_path / "g.fa"; fa.write_text(">s1\nACGTNNNNacgt\n>s2\nGGGG\n")
    gz = tmp_path / "g2.fa.gz"; pysam.tabix_compress(str(fa), str(gz))
    for p in (fa, gz):
        f = Fasta(p, cache_dir=tmp_path / "cache")
        assert f.lengths() == {"s1": 12, "s2": 4}
        assert f.fetch("s1", 0, 12) == "ACGTNNNNACGT"
        assert f.fetch("s1", 10, 99) == "GT"

def test_fetch_uppercases(tmp_path): ...       # soft-masked "acgt" -> "ACGT" (Review Focus 2)

def test_index_into_cache_when_dir_readonly(tmp_path):
    d = tmp_path / "ro"; d.mkdir(); fa = d / "g.fa"; fa.write_text(">s1\nACGT\n"); d.chmod(0o555)
    f = Fasta(fa, cache_dir=tmp_path / "cache")
    assert f.fetch("s1", 1, 3) == "CG" and any((tmp_path / "cache").glob("*.fai"))

def test_n_runs_and_revcomp():
    assert n_runs("ACNNNGTnA") == [(2, 5), (7, 8)]
    assert revcomp("ACGTN") == "NACGT"
```

- [ ] **Step 2: Run** `pytest tests/test_seqio.py -v`. Expected: FAIL (ImportError).
- [ ] **Step 3: Implement.** Use `pysam.FastaFile(path, filepath_index=..., filepath_index_compressed=...)`.
  - If `<path>.fai` exists (plus `.gzi` for bgzip), use it.
  - Else, if the directory is writable, let pysam build the index.
  - Else build it with `pysam.faidx(path, "--fai-idx", fai, "--gzi-idx", gzi)` into
    `cache_dir/<sha1(abs path)[:12]>.<name>.fai`.
  - Detect plain gzip by the magic bytes `1f8b` plus a `pysam` open failure, and raise the ValueError.
- [ ] **Step 4: Run** `pytest tests/test_seqio.py -v`. Expected: PASS.
- [ ] **Step 5: Commit** `git commit -am "Add FASTA random access with index fallback"` (add the new files first).

---

### Task 4: Samples sheet (`samples.py`)

**Files:** Create `src/ltrpav/samples.py`, `tests/test_samples.py`

**Interfaces:**
- Produces: `@dataclass(frozen=True) class Sample: label: str; fasta: Path; annotation: str | None; group: str | None; role: str | None`;
  `read_samples(path: Path) -> list[Sample]`; `class SampleSheetError(ValueError)`.

- [ ] **Step 1: Write the failing tests.** Sheet = TSV with header `label fasta annotation group role` (`group`,
  `role` optional columns; `.` = none; `#` lines skipped; relative paths resolved against the sheet's directory).

```python
def test_read_valid_sheet(tmp_path): ...       # 3 rows; annotation "." -> None; role "outgroup" kept; paths absolute
def test_errors(tmp_path):
    # each must raise SampleSheetError whose message names the problem:
    # duplicate label; label not matching ^[A-Za-z0-9_.-]+$ ("B 73", "a|b"); missing fasta file;
    # fewer than 2 rows; no row with an annotation; unknown role (only "outgroup" allowed)
```

- [ ] **Step 2: Run** the tests. Expected: FAIL.
- [ ] **Step 3: Implement** `read_samples` (csv module, tab-delimited). Report every missing file in one error.
  Annotation paths are resolved but not checked here (an LTRquest prefix is not a file; Task 8 checks them).
- [ ] **Step 4: Run** the tests. Expected: PASS.
- [ ] **Step 5: Commit** `"Add samples sheet parser"`.

---

### Task 5: Element record and LTRquest loader

**Files:** Create `src/ltrpav/elements.py`, `src/ltrpav/annotation/__init__.py` (empty for now),
`src/ltrpav/annotation/ltrquest.py`, `tests/test_annot_ltrquest.py`

**Interfaces:**
- Produces:

```python
@dataclass(frozen=True, slots=True)
class Element:
    genome: str; eid: str; name: str; seqid: str
    start: int; end: int; strand: str                 # 1-based inclusive; strand '+', '-' or '.'
    ltr_left: tuple[int, int]; ltr_right: tuple[int, int]   # genome orientation, 1-based inclusive
    tsd: str | None; k: float | None
    family: str | None; superfamily: str | None; clade: str | None; confidence: str | None
    parent: str | None = None; level: int = 0         # filled by assign_nesting (Task 8); 0 = top-level
def make_eid(genome: str, seqid: str, start: int, end: int) -> str   # f"{genome}|{seqid}:{start}-{end}"
ELEMENT_COLUMNS: tuple[str, ...]                     # field order; tuples written "a-b", None written "."
def write_elements(elements: list[Element], path: Path) -> None
def read_elements(path: Path) -> list[Element]
def load_ltrquest(prefix: str, genome: str) -> tuple[list[Element], Counter]   # Counter of skip reasons
```

- [ ] **Step 1: Write the failing tests.** The fixture writes `X_depth0_clean_ltr.tsv` and `X_depth1_clean_ltr.tsv`
  with the real header (`#seq_id seq_len status ltr5_start ... nest_status`, 34 columns, copied from
  `run/B73v5_LTRs_depth0_clean_ltr.tsv`). Use the two real rows (`B73v5_chr1:60664-70130#LTR/Copia/SIRE` at depth 0,
  `B73v5_chr1:51712-70182#LTR/Copia/SIRE` at depth 1) plus one row with `status` = `fail`.

```python
def test_load_ltrquest(tmp_path):
    els, skipped = load_ltrquest(str(tmp_path / "X"), "B73")
    inner = next(e for e in els if e.start == 60664)
    assert (inner.seqid, inner.end, inner.strand) == ("B73v5_chr1", 70130, "-")
    assert inner.ltr_left == (60664, 61985) and inner.ltr_right == (68826, 70130)
    assert inner.tsd == "CACTC" and inner.k == 0.0 and inner.family == "merged_fam00001"
    assert (inner.superfamily, inner.clade, inner.confidence) == ("Copia", "SIRE", "high")
    assert inner.eid == "B73|B73v5_chr1:60664-70130" and inner.name == "B73v5_chr1:60664-70130#LTR/Copia/SIRE"
    host = next(e for e in els if e.start == 51712)
    assert host.ltr_left == (51712, 53005) and host.ltr_right == (59462, 70182)   # rLTR span includes the inner element
    assert skipped["status_not_pass"] == 1

def test_elements_tsv_round_trip(tmp_path): ...  # write_elements then read_elements returns equal objects
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - Glob `f"{prefix}_depth*_clean_ltr.tsv"` and sort by the depth integer.
  - Parse `seq_id` with `^(?P<seqid>.+):(?P<start>\d+)-(?P<end>\d+)#(?P<cls>.+)$`.
  - Absolute LTR bounds = `start + rel - 1`. The `ltr5_*` columns are the genome-left LTR and `ltr3_*` the right one
    (verified against the GFF3 for the real host).
  - `k` comes from `k2p` (`NA` -> None). Superfamily and clade are parts 2 and 3 of `cls` (`unknown` -> None).
  - Skip rows whose `status` is not `pass`.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add Element record and LTRquest loader"`.

---

### Task 6: GFF3 reader and writer

**Files:** Create `src/ltrpav/annotation/gff3.py`, `tests/test_annot_gff3.py`

**Interfaces:**
- Produces: `load_gff3(path: Path, genome: str) -> tuple[list[Element], Counter]`;
  `write_gff3(elements: list[Element], path: Path) -> None` (LTRquest convention: one `LTR_retrotransposon` line +
  two `long_terminal_repeat` children `ID=<id>.lLTR/.rLTR`; attributes `Name`, `tsd`, `K2P_d`, `family`,
  `superfamily`, `clade`, `confidence`; gzip if the path ends in `.gz`).

- [ ] **Step 1: Write the failing tests.** Use three inline fixtures:
  - **LTRquest convention:** the real host line `B73v5_chr1 ... LTR_retrotransposon 51712 70182 ... ID=B73v5_LTRs_LTRRT_95050;...;tsd=CACCT;K2P_d=0.00340137;...`
    plus its `lLTR 51712-53005` and `rLTR 59462-70182` children.
  - **EDTA convention:** `repeat_region_1` holding `lTSD 60659-60663`, `lLTR 60664-61985`,
    `Copia_LTR_retrotransposon 60664-70130 (ltr_identity=1.0000;tsd=GAGTG;Classification=LTR/Copia;Method=structural)`,
    `rLTR 68826-70130` and `rTSD 70131-70135`, all children of the region (siblings of the element).
  - **EDTA homology fragment:** an `LTR_retrotransposon` line with `Method=homology` and no LTRs.

```python
def test_ltrquest_convention(tmp_path):
    (e,), _ = load_gff3(p, "B73")
    assert (e.start, e.end, e.ltr_left, e.ltr_right, e.tsd) == (51712, 70182, (51712, 53005), (59462, 70182), "CACCT")
    assert abs(e.k - 0.00340137) < 1e-9 and (e.superfamily, e.clade) == ("Copia", "SIRE")

def test_edta_convention_and_fragment(tmp_path):
    els, skipped = load_gff3(p, "B73")
    assert len(els) == 1 and els[0].ltr_right == (68826, 70130) and els[0].tsd == "GAGTG"
    assert els[0].k == 0.0 and els[0].superfamily == "Copia" and els[0].family is None
    assert skipped["no_ltr_pair"] == 1

def test_write_read_round_trip(tmp_path): ...   # write_gff3(els) then load_gff3 returns the same fields
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - An element is any feature whose type ends in `LTR_retrotransposon`.
  - Its LTRs are its `long_terminal_repeat` children, or else `long_terminal_repeat` siblings (same `Parent`) inside
    its span. Skip it unless there are exactly two.
  - `k`: `K2P_d`, else JC69 from `ltr_identity` (`p = 1 - id`; `-0.75*ln(1 - 4p/3)`), else None.
  - Superfamily and clade: the attribute, else split `classification` / `Classification`.
  - `name`: `Name` or `ID`. Read gzip transparently and unescape `%XX`.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add GFF3 reader/writer for LTRquest and EDTA conventions"`.

---

### Task 7: BED reader with LTR finding

**Files:** Create `src/ltrpav/annotation/bed.py`, `tests/test_annot_bed.py`

**Interfaces:**
- Produces: `find_ltrs(seq: str) -> tuple[int, int] | None` (left and right LTR lengths);
  `load_bed(path: Path, genome: str, fasta: Fasta) -> tuple[list[Element], Counter]`.

- [ ] **Step 1: Write the failing tests**

```python
def test_find_ltrs_planted():
    rng = random.Random(1); ltr = toy.rand_seq(400, rng); el = ltr + toy.rand_seq(3000, rng) + toy.mutate(ltr, 0.005, rng)
    l5, l3 = find_ltrs(el); assert abs(l5 - 400) <= 5 and abs(l3 - 400) <= 5

def test_find_ltrs_random_is_none():
    assert find_ltrs(toy.rand_seq(4000, random.Random(2))) is None

def test_load_bed(tmp_path): ...   # 0-based BED start -> 1-based Element.start; strand col 6 optional; no-LTR row skipped
```

(`tests/toy.py` is created in this task with `rand_seq(n, rng)` and `mutate(seq, rate, rng)`; Task 12 extends it.)
- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement `find_ltrs`.**
  - `n = min(len(seq)//2, 6000)`. Index `seq[-n:]` with `mappy.Aligner(seq=..., preset="asm20")` and map `seq[:n]`.
  - Accept a `+` hit with `q_st <= 20`, `r_en >= n - 20`, `mlen/blen >= COV_PRESENT` and both lengths `>= MIN_SEG`.
  - Return `(hit.q_en, n - hit.r_st)`.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add BED reader with LTR self-alignment"`.

---

### Task 8: Annotation dispatcher, nesting, TSD inference

**Files:** Modify `src/ltrpav/annotation/__init__.py`; Create `tests/test_annotation.py`

**Interfaces:**
- Consumes: `load_ltrquest`, `load_gff3`, `load_bed`, `Fasta`, `Element`.
- Produces: `load_annotation(spec: str, genome: str, fasta: Fasta) -> list[Element]` (sorted by fai seqid order,
  start, -end); `assign_nesting(elements: list[Element]) -> list[Element]`;
  `infer_tsd(fasta: Fasta, e: Element) -> str | None`; `class AnnotationError(ValueError)`.

- [ ] **Step 1: Write the failing tests**

```python
def test_nesting_and_levels():
    # e1 [100,10000] contains e2 [2000,5000] contains e3 [2500,3000]
    out = {e.name: e for e in assign_nesting([...])}
    assert out["e2"].parent == out["e1"].eid and out["e3"].parent == out["e2"].eid
    assert [out[n].level for n in ("e1", "e2", "e3")] == [0, 1, 2]

def test_nesting_partial_overlap():            # Review Focus 4
    # e1 [100,10000] and e4 [9000,12000] overlap but neither contains the other
    assert out["e4"].parent is None and out["e4"].level == 0

def test_infer_tsd(tmp_path):                  # "ACGTA" + element + "ACGTA" -> "ACGTA"; no direct repeat -> None
def test_infer_tsd_at_sequence_start(tmp_path):  # element starting at base 2: returns None, no exception (Review Focus 3)
def test_unknown_seqid_fails_fast(tmp_path):   # AnnotationError message lists the missing seqid(s) (first 5 + count)
def test_duplicates_dropped(tmp_path):         # identical (seqid,start,end) twice -> one element, warning logged
def test_dispatch_by_format(tmp_path):         # .gff3/.gff3.gz -> gff3; .bed -> bed; prefix with depth files -> ltrquest;
                                               # anything else -> AnnotationError("cannot detect annotation format")
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - **Nesting:** sweep the elements sorted by (seqid, start, -end) with a stack. Pop while `top.end < e.start`. The
    parent is the topmost stack entry with `end >= e.end` (it contains `e`); partially overlapping entries stay on
    the stack. `level = parent.level + 1`.
  - **`infer_tsd`:** try L = 5, 4, 6 in that order. Return the first L where `A[s-1-L, s-1) == A[end, end+L)`, both
    have full length and neither contains N.
  - **Validation:** a seqid absent from the FASTA, or an end beyond the sequence length, raises AnnotationError.
  - Log each Counter of skip reasons as one warning line.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add annotation dispatcher, nesting and TSD inference"`.

---

### Task 9: Alignment blocks and PAF reader

**Files:** Create `src/ltrpav/blocks.py`, `tests/test_blocks.py`

**Interfaces:**
- Produces:

```python
BLOCK_DTYPE = np.dtype([("a_chrom", "i4"), ("a_start", "i8"), ("a_end", "i8"), ("b_chrom", "i4"),
    ("b_start", "i8"), ("b_end", "i8"), ("strand", "i1"), ("matches", "i4"), ("alen", "i4"),
    ("chain", "i4"), ("chain_score", "f8"), ("margin", "f4")])     # 0-based half-open; chain=-1, margin=nan until set
def read_paf(path: Path, a_index: dict[str, int], b_index: dict[str, int], swap: bool = False) -> np.ndarray
def a_to_b(block: np.void, apos: int) -> int
def swap_blocks(blocks: np.ndarray) -> np.ndarray     # exchange A and B roles (minus-strand coords stay valid)
def save_blocks(path: Path, blocks: np.ndarray, a_names: list[str], b_names: list[str]) -> None
def load_blocks(path: Path) -> tuple[np.ndarray, list[str], list[str]]
```

- [ ] **Step 1: Write the failing tests**

```python
def test_read_paf_and_map(tmp_path):
    # PAF query = A (col 1); line: a1 1000 100 200 + b1 5000 1000 1100 95 100 60
    bl = read_paf(p, {"a1": 0}, {"b1": 0})
    assert a_to_b(bl[0], 150) == 1050
def test_minus_strand_mapping():
    # block A[100,200) -> B[1000,1100) on '-': a_to_b(100) == 1099, a_to_b(199) == 1000
def test_swap_and_unknown_names(tmp_path): ...   # swap=True puts target in A; unknown seqids skipped and counted (logged)
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - Stream the PAF (gzip aware).
  - `a_to_b` scales by `r = (b_end-b_start)/(a_end-a_start)`. Plus strand: `b_start + round((apos-a_start)*r)`.
    Minus strand: `b_end - 1 - round((apos-a_start)*r)`.
  - `.npz` stores the blocks plus both name lists.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add alignment block model and PAF reader"`.

---

### Task 10: Chaining and 1:1 orthologous net

**Files:** Create `src/ltrpav/chain.py`, `tests/test_chain.py`

**Interfaces:**
- Consumes: `BLOCK_DTYPE`, `a_to_b`, constants `CHAIN_*`, `MIN_CHAIN_SCORE`, `ANCHOR_MIN`.
- Produces: `chain_blocks(blocks: np.ndarray) -> np.ndarray` (sets `chain`, `chain_score`; drops blocks of chains
  below `MIN_CHAIN_SCORE`); `net_blocks(blocks: np.ndarray) -> np.ndarray` (1:1 trimmed blocks with `margin`,
  sorted by `(a_chrom, a_start)`).

- [ ] **Step 1: Write the failing tests**

```python
def test_chain_bridges_insertion():   # A[0,5000)->B[0,5000) and A[15000,20000)->B[5000,10000): one chain id
def test_chain_breaks_on_far_gap():   # second block 2 Mb further on both genomes: two chains
def test_minus_strand_chain():        # three '-' blocks with decreasing B: one chain
def test_net_drops_paralog():
    # chain 1: A[0,20000)->B chr0, score 20000; block A[5000,6000)->B chr1, matches 900
    out = net_blocks(chain_blocks(bl))
    assert set(out["b_chrom"]) == {0}
    m = out[(out["a_start"] <= 5000) & (out["a_end"] >= 6000)]["margin"][0]
    assert abs(m - (1 - 900 / 20000)) < 1e-3
def test_net_trims_b_overlap():       # two A regions claiming the same B interval: the lower-scoring one is trimmed on A
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.** This algorithm is fixed here; implement it as written.

```
group blocks by (a_chrom, b_chrom, strand); sort each group by a_start
y0, y1 = (b_start, b_end) if strand > 0 else (-b_end, -b_start)      # collinear = increasing in both
@njit DP over the group: f[i] = matches[i]; p[i] = -1
  for j in i-1 .. max(0, i-CHAIN_LOOKBACK):
      if a_start[i] - a_start[j] > CHAIN_MAX_GAP + maxlen: break
      da = a_start[i] - a_end[j]; db = y0[i] - y1[j]
      if da < -CHAIN_OVERLAP or db < -CHAIN_OVERLAP or da > CHAIN_MAX_GAP or db > CHAIN_MAX_GAP: continue
      gain = matches[i] - max(0, -min(da, db))                   # do not count overlapped bases twice
      s = f[j] + gain - (CHAIN_INDEL_COST*abs(da-db) + log2(1 + max(0, min(da, db))))
      if s > f[i]: f[i], p[i] = s, j
extract: visit blocks by f descending; backtrack via p until a used block or -1; chain score = f[end] - f[stop]
  (0 if stop == -1); keep chains with score >= MIN_CHAIN_SCORE
net: visit chains by score descending; keep per-chrom claimed A and B interval lists (sorted, with owner block)
  for each block: free A parts -> map to B (a_to_b) -> remove claimed B parts -> map back -> keep parts >= ANCHOR_MIN
  every claimed interval the block overlaps (A or B): comp[owner] = max(comp[owner], this chain's score)
  if the kept parts' matches (scaled by kept fraction) sum >= MIN_CHAIN_SCORE: claim them; else drop the chain
margin[k] = 1 - comp[k] / chain_score[k]   (1.0 if never challenged)
```

- [ ] **Step 4: Run.** Expected: PASS. Also time 10^6 random blocks (one-off check, not a test). Expected: under 60 s.
- [ ] **Step 5: Commit** `"Add chaining DP and 1:1 orthologous net"`.

---

### Task 11: Windows

**Files:** Create `src/ltrpav/window.py`, `tests/test_window.py`

**Interfaces:**
- Consumes: `Element`, netted blocks, `a_to_b`, `WINDOW_PAD`, `WINDOW_CAP`, `ANCHOR_MIN`.
- Produces:

```python
@dataclass
class Window:
    wid: int; a_seqid: str; a_start: int; a_end: int              # 0-based half-open
    b_seqid: str | None; b_start: int; b_end: int; strand: int    # +1/-1; B window revcomp'd when -1
    eids: list[str]                                               # top-level elements (descendants implied)
    status: str            # "ok" | "no_anchor" | "no_left_anchor" | "no_right_anchor" | "breakpoint" | "span_cap"
    anchor_left: int; anchor_right: int; margin: float            # bp from element to anchor; min anchor margin
def make_windows(elements: list[Element], blocks: np.ndarray, a_names: list[str], b_names: list[str],
                 b_lengths: dict[str, int]) -> list[Window]
```

- [ ] **Step 1: Write the failing tests**

```python
def test_window_basic():                 # blocks either side, same chain: status ok, B coords from a_to_b, pads applied
def test_window_breakpoint():            # left anchor on B chr0, right on chr1 -> "breakpoint"
def test_window_missing_right():         # no block right of the element -> "no_right_anchor"
def test_window_span_cap():              # anchors 600 kb apart in B -> "span_cap"
def test_windows_merge_overlap():        # two adjacent top-level elements with overlapping windows -> one window, both eids
def test_window_minus_strand():          # '-' chain: strand -1, b_start < b_end, element image inside
def test_window_at_sequence_start():     # element at A position 3: "no_left_anchor", no exception (Review Focus 3)
def test_no_blocks_on_seqid():           # A seqid without any block -> "no_anchor"
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.** For each top-level element `[s0, t0)`:
  - **Left anchor:** the nearest block with `a_start < s0`, clipped to end at `<= s0`, whose clipped length is
    `>= ANCHOR_MIN`. **Right anchor:** the same rule mirrored at `t0`.
  - **Consistency:** both anchors on the same `b_chrom`, same strand, B order consistent with the strand, and both
    spans `<= WINDOW_CAP`. If not, try up to 3 next-nearest blocks per side, then give the U reason.
  - **Windows:** A `[aL - WINDOW_PAD + 1, aR + WINDOW_PAD)` and B from the anchor images, both clipped.
  - **Merging:** merge "ok" windows that overlap in A, share `b_seqid` and strand, have overlapping or adjacent B
    intervals, and stay within `WINDOW_CAP`.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add anchor-to-window construction"`.

---

### Task 12: Window alignment (`localign.py`) and toy builders

**Files:** Create `src/ltrpav/localign.py`, `tests/test_localign.py`; Modify `tests/toy.py`

**Interfaces:**
- Produces:

```python
@dataclass
class Gap: a0: int; a1: int; b0: int; b1: int            # A-unaligned [a0,a1), B-unaligned [b0,b1), window coords
class AlnMap:                                             # collinear gap-free segments, sorted by A
    seg_a: np.ndarray; seg_b: np.ndarray; seg_len: np.ndarray; seg_mm: np.ndarray
    inv: list[tuple[int, int, int, int]]                  # inverted hits (a0, a1, b0, b1)
    def aligned_bp(self, a0: int, a1: int) -> int
    def a2b(self, a: int) -> int | None
    def gap_around(self, a: int, min_seg: int = MIN_SEG) -> Gap | None   # flanking segments >= min_seg around A pos a
    def b_gaps_within(self, a0: int, a1: int) -> list[Gap]               # B insertions between segments inside [a0,a1)
    def identity(self, a0: int, a1: int) -> float                        # 1 - mm/len over segments overlapping [a0,a1)
def align_window(a_seq: str, b_seq: str, preset: str = "asm20", backend: str = "mappy") -> AlnMap
def register_backend(name: str, fn: Callable[[str, str, str], AlnMap]) -> None   # bake-off hook (Task 24)
def preset_for_divergence(d: float) -> str     # <=0.001 asm5; <=0.01 asm10; else asm20 (minimap2 manual)
```

- `tests/toy.py` adds the following:
  - `make_element(rng, ltr_len, int_len) -> tuple[str, int, int]` (seq, left and right LTR lengths).
  - `CASES: list[str]` and `case(name, rng) -> ToyCase`. `ToyCase` has fields `a`, `b` (window strings),
    `elements` (list of `Element`, seqid "a", 1-based, k = 0.0) and `expect` (dict eid -> state).
  - `build_pair(rng, cases=CASES) -> ToyPair`: every case laid end to end on seqid `chr1` with 20-kb random spacers.
    Fields `a`, `b`, `elements`, `expect`.
- Toy case constructions (they fix the classifier tests in Task 14):
  - **Shared pieces:** `L`, `R` = 3 kb random flanks; `T = "CTCTC"`; `e = LTR(400) + INT(4000) + LTR` with identical
    LTRs.
  - **Host `h`:** `LTRh + INTh[:2000] + T2 + c + T2 + INTh[2000:] + LTRh`, where `c` is a 3-kb element and
    `T2 = "GAGAG"`.
  - **Random fillers:** `X` = random sequence of the stated length; `N100` = 100 Ns.

| case | A | B | expected |
|---|---|---|---|
| P | L T e T R | A mutated 1% | P |
| P_nestB | L T e T R | L T e[:2400] X3k e[2400:] T R | P + nestB |
| S | L T e T R | L T LTR T R | S + solo_tsd |
| S_notsd | L T e T R | L T LTR R | S |
| T | L T e T R | L T LTR INT[:1600] LTR T R | T |
| E | L T e T R | L T R | E + tsd_match, high |
| E_mm1 / E_mm2 | L T e T R | L T' R, T' with 1 / 2 mismatches | E + tsd_match / E, medium |
| D_left | L T e T R | L[:-500] R | D |
| D_both | L T e T R | L[:-300] R[400:] | D |
| O | L T e T R | L T X2k T R | O |
| G | L T e T R | L T N100 R | G |
| G_near / G_far | L T e T R | N50 placed 20 / 500 bp before the junction in L, then T R | G / E |
| U_flank | L T e T R | L T X3k | U, reason flank_unaligned |
| inv_site | L T e T R | L T revcomp(e) T R | U, reason inv_site |
| nested_E | L T h T R | L T h-without-c (one T2) T R | h P; c E |
| host_E | L T h T R | L T R | h E; c E + host_empty |
| host_S | L T h T R | L T LTRh T R | h S; c D |
| host_G | L T h T R | L T N100 R | h G; c G + inherit |
| adjacent_E | L T e1 T T2 e2 T2 R | L T T2 R | e1 E, e2 E, both + adjacent |

- [ ] **Step 1: Write the failing tests**

```python
def test_identical_one_segment():          # 20-kb identical: aligned_bp(0, 20000) >= 19950
def test_insertion_makes_gap():            # A = B + 6-kb element at 10 kb: gap_around(13000) spans the element +-50 bp
def test_divergence_identity():            # mutate 2%: identity(0, len) within 0.98 +- 0.005
def test_inversion_recorded():             # 3-kb inverted piece in B: inv non-empty and not in the collinear segments
def test_preset_for_divergence():          # 0.0005 -> asm5, 0.005 -> asm10, 0.02 -> asm20
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement the alignment.**
  - Use `mappy.Aligner(seq=b_seq, preset=preset, best_n=5)` and keep every hit.
  - On `+` hits, run a collinear chain DP that maximizes `mlen`. `-` hits go to `inv`.
  - Each kept hit's CIGAR (M, =, X, I, D) becomes gap-free segments. Count mismatches on M runs by comparing bytes
    with numpy.
  - `backend` looks up the registry; `"mappy"` is the only built-in.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add window alignment map and toy builders"`.

---

### Task 13: Exact junction refinement

**Files:** Create `src/ltrpav/junction.py`, `tests/test_junction.py`

**Interfaces:**
- Consumes: `Gap`, constants `SCORE`, `REFINE_PAD`.
- Produces: `refine_gap(a_seq: str, b_seq: str, gap: Gap, pad: int = REFINE_PAD) -> Gap`. It returns the input
  unchanged when `gap.b1 - gap.b0 > 2*pad` (large B insertion: O, no boundary needed).

- [ ] **Step 1: Write the failing tests.** Use `L`, `R` = 2 kb of random sequence, element `e` (5 kb, starts "TG",
  ends "CA") and TSD `T = "CTCTC"`. Start each test from a perturbed gap (edges moved by about 40 bp). Deleted
  lengths must be exact (they are the same under any equivalent placement); positions within the stated slack.

```python
def test_empty_site():      # A = L+T+e+T+R, B = L+T+R
    g = refine_gap(a, b, perturbed)
    assert g.a1 - g.a0 == len(e) + 5 and g.b1 == g.b0 and len(L) - 5 - 3 <= g.a0 <= len(L) + 3
def test_flank_deletion():  # B = L[:-300] + R
    assert g.a1 - g.a0 == 300 + 5 + len(e) + 5 and g.b1 == g.b0
def test_filler():          # B = L + "GATTACA" + R
    assert g.b1 - g.b0 == 7
def test_large_b_insertion_unchanged(): ...
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.** This algorithm is fixed here.

```
Al = a[a0-pad : min(a1, a0+pad)]    (start aL0)      Ar = a[max(a0+pad, a1-pad) : a1+pad]  (start aR0)
Bj = b[b0-pad : b1+pad]             (start bj0)      all clipped to sequence bounds
F = Gotoh(Al, Bj) global at both starts (match +1, mismatch -4, open -6, extend -2)  -> Fbest[j] = max_i F[i][j]
R = Gotoh on reversed strings (global at both ends)                                  -> Rbest[j] = max_k R[k][j]
best = argmax over j1 <= j2 of Fbest[j1] + Rbest[j2] - (0 if j2 == j1 else 6 + 2*(j2-j1))
ties: smallest j2-j1, then smallest i, then smallest k
return Gap(aL0 + i*, aR0 + k*, bj0 + j1*, bj0 + j2*)
```

  The A sequence between the two parts is deleted at no cost (it is the element). Numba-jit both DPs.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add exact junction refinement"`.

---

### Task 14: Classifier

**Files:** Create `src/ltrpav/classify.py`, `tests/test_classify.py`; Modify `docs/DESIGN.md` (5.4: the TSD
allowance with d, builder call 4)

**Interfaces:**
- Consumes: `Window`, `AlnMap`, `refine_gap`, `Element`, `n_runs`, constants.
- Produces:

```python
STATES = ("P", "S", "T", "E", "D", "O", "G", "U")
@dataclass
class Call:
    eid: str; state: str; tier: str; flags: list[str]     # tier "high" | "medium" | "low" | "." (G, U)
    b_seqid: str | None; b_start: int | None; b_end: int | None; b_strand: str | None   # genome coords, 1-based
    ev: dict[str, float | int | str]                      # keys = CALL_COLUMNS evidence names
CALL_COLUMNS = ("eid", "a_seqid", "a_start", "a_end", "parent", "level", "state", "tier", "flags", "reason",
    "b_seqid", "b_start", "b_end", "b_strand", "wid", "cov_left", "cov_right", "cov_int", "cov_elem", "dl", "dr",
    "b_ins", "tsd_a", "tsd_b", "tsd_mm", "ident", "anchor_left", "anchor_right", "margin")
# reason: U cause (window status, "flank_unaligned", "inv_site") or "."
def classify_window(win: Window, aln: AlnMap | None, a_seq: str, b_seq: str,
                    elements: dict[str, Element], children: dict[str, list[str]]) -> list[Call]
def call_row(call: Call, e: Element, win: Window) -> dict    # one CALL_COLUMNS row
```

- [ ] **Step 1: Write the failing tests.** One test per `toy.case` (table in Task 12). A test helper `run_case(c)`
  runs `classify_window(win, align_window(c.a, c.b), c.a, c.b, {e.eid: e for e in c.elements}, children)`, with
  `win = Window(wid=0, a_seqid="a", a_start=0, a_end=len(c.a), b_seqid="b", b_start=0, b_end=len(c.b), strand=1, eids=<top-level eids>, status="ok", anchor_left=0, anchor_right=0, margin=1.0)`.

```python
@pytest.mark.parametrize("name", toy.CASES)
def test_case_state(name):
    c = toy.case(name, random.Random(7)); calls = {x.eid: x for x in run_case(c)}
    for eid, state in c.expect.items():
        assert calls[eid].state == state, (name, eid)
def test_flags_and_tiers():               # every flag, tier and reason in the Task 12 table's "expected" column
def test_window_status_propagates():      # status "breakpoint": every element and descendant U, reason "breakpoint"
def test_minus_strand_window_flags_inv(): # case E with B reverse-complemented and strand=-1: E + "inv", B coords flipped
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.** Rules are fixed here. Notation: `L = len(e.tsd) or TSD_DEFAULT`, `w = SLOP_TSD_MULT*L`;
  the parts (left LTR, internal, right LTR, whole) exclude the spans of `e`'s annotated descendants; `ident` =
  `aln.identity(s-1000, t+1000)`.

```
visit elements outermost-first (level order) within the window
0 inheritance: parent E -> E + host_empty; parent D/O/G/U -> same state + inherit (tier copied); parent P/S/T -> go on
1 if win.status != "ok" or aln is None: U (reason = status)
2 g = aln.gap_around(midpoint of e); no segment on a side -> U "flank_unaligned"
3 an inverted hit overlapping [s-w, t+w) -> U "inv_site"
4 B region between the flanking segments' images, widened by REFINE_PAD each side, contains N -> G
5 aligned element bp < MIN_SEG -> absent branch:
     g = refine_gap(...); b_ins = g.b1-g.b0; dl = s-g.a0; dr = g.a1-t
     overhang on a side is "explained" if other annotated elements (not ancestors of e, inside the gap), each
       widened by its own L, cover all but <= w of it -> treat that side as within w, flag adjacent
     b_ins >= MIN_SEG -> O
     elif dl <= w and dr <= w:  E if b_ins <= w (read TSD) else O (flag small_ins)
     else -> D (flag filler if b_ins > w)
6 else present branch:
     cov_left, cov_right, cov_elem >= COV_PRESENT -> P (+ nestB if aln.b_gaps_within(s, t) has one >= MIN_SEG)
     elif internal aligned bp < max(MIN_SEG, (1-COV_PRESENT)*len(internal)) and
          SOLO_LEN[0]*mean_ltr <= ltr aligned bp <= SOLO_LEN[1]*mean_ltr -> S (+ solo_tsd if both A TSD copies have
          >= L-1 bases aligned)
     else -> T
TSD read (E): B copy = b[g.b1 : g.b1+L] if g.a0 <= s - L/2 else b[g.b0-L : g.b0];
     tsd_mm = min Hamming(B copy, A[s-L:s]), Hamming(B copy, A[t:t+L]);
     tsd_match if tsd_mm <= max(1, floor(L*((e.k or 0) + (1-ident)) + 0.5))
tier: placement = win.margin >= MARGIN_HIGH and ident >= IDENT_MIN;
     evidence = P: true | S: solo_tsd | E: tsd_match | D: refined | T, O: false
     high if both, medium if one, low if neither; G and U get "."
B coords: window -> genome (strand -1: b = win.b_end - 1 - local); 1-based. P/S/T: image of the aligned element;
     E: the B TSD copy; D: last aligned B base before and first after; O: the B insertion; G/U: None
flag inv on every call from a strand -1 window (site inside an inverted block)
```

- [ ] **Step 4: Run.** Expected: PASS (all cases exact).
- [ ] **Step 5: Commit** `"Add state classifier with nested hierarchy"`.

---

### Task 15: Route interface, in-process minimap2 route, external PAF route

**Files:** Create `src/ltrpav/anchor/__init__.py`, `src/ltrpav/anchor/mm2.py`, `src/ltrpav/anchor/paf.py`,
`src/ltrpav/checkpoint.py`, `tests/test_routes.py`, `tests/test_checkpoint.py`

**Interfaces:**
- Produces:

```python
@dataclass
class PairContext:
    a: Sample; b: Sample; a_fa: Fasta; b_fa: Fasta
    a_elements: list[Element]; b_elements: list[Element] | None
    workdir: Path; threads: int
class Route(Protocol):
    name: str
    def raw_blocks(self, ctx: PairContext) -> np.ndarray     # unchained blocks, A indices = ctx.a_fa fai order
def get_route(spec: str) -> Route        # "mm2" | "fastga" | "flank-mm2" | "flank-blast" | "hybrid" | "paf:<dir>"
class Mm2Route: name = "mm2"             # anchor/mm2.py
class PafRoute:                          # anchor/paf.py; PafRoute(dirpath: Path), name = "paf"
    # reads <dir>/<A>__<B>.paf[.gz] (A = column 1) or <dir>/<B>__<A>.paf[.gz] (swapped)
def anchor_pair(ctx: PairContext, route: Route) -> tuple[np.ndarray, list[str], list[str], float]
    # netted blocks, a_names, b_names, divergence d; cached at workdir/anchors/<A>__<B>.<route>.npz
# checkpoint.py
def file_checksum(path: Path, cache: Path) -> str     # sha256, cached by (abs path, size, mtime_ns) in a JSON file
def stage_key(stage: str, inputs: dict[str, str], params: dict) -> str
def is_done(marker: Path, key: str) -> bool
def mark_done(marker: Path, key: str, outputs: list[Path]) -> None   # writes .done.json last
```

- [ ] **Step 1: Write the failing tests**

```python
def test_checkpoint_roundtrip(tmp_path): ...   # key changes when an input checksum or a param changes
def test_mm2_route_covers_shared_sequence(tmp_path):
    # toy genomes A, B: 300 kb shared random backbone, B mutated 1%, 10 element insertions in A only
    bl, an, bn, d = anchor_pair(ctx, get_route("mm2"))
    assert covered_fraction(bl, shared_intervals) >= 0.95 and 0.005 < d < 0.02
def test_paf_route(tmp_path):            # <dir>/A__B.paf read; <dir>/B__A.paf read with swap
def test_w_route_reused_both_directions(tmp_path):  # second direction loads the raw cache (no new mapping; spy)
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - **`Mm2Route`:**
    - Index B once. If `shutil.which("minimap2")`, run `minimap2 -x asm20 -t T -d <B>.asm20.mmi` (cached by the
      FASTA checksum); otherwise use `mappy.Aligner(fn_idx_in=fasta)`. Load with
      `mappy.Aligner(fn_idx_in=mmi, preset="asm20", best_n=5)`.
    - Map A in chunks of `MM2_CHUNK + MM2_OVERLAP` stepping `MM2_CHUNK`, skipping chunks that are >50% N, with a
      `ThreadPoolExecutor(T)` and one `mappy.ThreadBuffer` per thread.
    - Each hit becomes a block (`matches = mlen`, `alen = blen`).
  - **Raw-block cache:** W routes cache raw blocks for the unordered pair (labels in sheet order); the reverse
    direction loads them and runs `swap_blocks`.
  - **`anchor_pair`:** `chain_blocks` then `net_blocks`. Divergence `d = 1 - sum(matches)/sum(alen)` over the
    netted blocks. Save with a checkpoint marker.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add route interface, mm2 and PAF routes, checkpoints"`.

---

### Task 16: Pair genotyping orchestration

**Files:** Create `src/ltrpav/genotype.py`, `tests/test_genotype.py`

**Interfaces:**
- Consumes: `anchor_pair`, `make_windows`, `align_window`, `preset_for_divergence`, `classify_window`, `call_row`,
  checkpoint functions.
- Produces: `genotype_pair(ctx: PairContext, route: Route, backend: str = "mappy") -> Path`. It writes
  `outdir/pairs/<A>__<B>.calls.tsv.gz` (CALL_COLUMNS, 1-based) and the windows in
  `workdir/windows/<A>__<B>.tsv.gz`. Chunks go to `workdir/calls/<A>__<B>/chunk_<n>.tsv.gz` with `.done.json`.

- [ ] **Step 1: Write the failing tests**

```python
def test_pair_end_to_end(tmp_path):
    # toy.build_pair(): every toy case laid out on one 'chr1' with 20-kb random spacers; GFF3 via write_gff3
    path = genotype_pair(ctx, get_route("mm2"), backend="mappy")
    got = read_calls(path)
    for eid, state in toy_pair.expect.items():
        assert got[eid] == state                       # exact, every case
def test_pair_lowercase_target(tmp_path):            # B FASTA lowercased: identical calls (Review Focus 2)
def test_pair_repetitive_flank_decoy(tmp_path):
    # the E case's 6-kb site region (L and R) is also pasted, with the element inside, 100 kb away in B
    # (a paralog, out of collinear order): the call follows the collinear ortholog -> E, not P

def test_pair_unrelated_genomes(tmp_path, caplog):   # B random: all U "no_anchor", warning logged (Review Focus 5)
def test_resume(tmp_path):
    # run; delete chunk_0 output + marker; rerun -> only chunk_0 recomputed (mtimes), final file byte-identical
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - Windows are grouped in A fai order and split into chunks of `CHUNK_WINDOWS`. Run
    `multiprocessing.get_context("fork").Pool(threads)` with an initializer that opens both `Fasta` objects in each
    worker and receives the elements and children maps.
  - Worker per window: fetch A and B (revcomp B when `strand == -1`), `align_window` with the preset from `d`, then
    `classify_window`.
  - Elements in no window get U `no_anchor`.
  - Concatenate the chunks in order, then mark the pair done.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add pair genotyping with chunked workers and resume"`.

---

### Task 17: FastGA route

**Files:** Create `src/ltrpav/anchor/fastga.py`; Modify `tests/test_routes.py`

**Interfaces:**
- Produces: `FastgaRoute` (`name = "fastga"`), registered in `get_route`.

- [ ] **Step 1: Write the failing test** (`@pytest.mark.skipif(shutil.which("FastGA") is None, ...)`):

```python
def test_fastga_route(tmp_path):     # toy pair: blocks non-empty; every PAF col-1 name is an A seqid (orientation check)
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - Symlink both FASTAs into `workdir/fastga/` as `<label>.fa` (or `.fa.gz`), so the `.1gdb`/`.gix` files land there
    and never next to user data.
  - Run `FastGA -paf -T<threads> -P<workdir/tmp> -k <A> <B>` with `cwd` set to that dir, streaming stdout through
    gzip into `<A>__<B>.fastga.paf.gz`. `-k` keeps the indexes for other pairs.
  - Raw blocks come from `read_paf`, cached per unordered pair as in Task 15.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add FastGA anchoring route"`.

---

### Task 18: Flank routes and hybrid

**Files:** Create `src/ltrpav/anchor/flanks.py`, `tests/test_flanks.py`

**Interfaces:**
- Produces: `@dataclass Piece: seqid: str; start: int; end: int` (0-based);
  `flank_pieces(elements: list[Element], fasta: Fasta, cap: int = FLANK_CAP, target: int = FLANK_TARGET) -> list[Piece]`;
  routes `FlankMm2Route(cap)`, `FlankBlastRoute(cap)`, `HybridRoute(primary: Route)`. `get_route` maps
  `"flank-mm2"`, `"flank-blast"` and `"hybrid"`; hybrid's primary is fastga if installed, otherwise mm2.

- [ ] **Step 1: Write the failing tests**

```python
def test_pieces_skip_elements_and_ns():   # pieces never overlap any annotated element or N run; each >= FLANK_PIECE_MIN
def test_pieces_nearest_first_and_capped():  # collected outward until >= target bp; never beyond cap
def test_flank_mm2_resolves_toy(tmp_path):   # genotype_pair with flank-mm2 recovers the toy expectations for P/E/D cases
def test_hybrid_fills_unanchored(tmp_path):
    # primary = PafRoute whose PAF lacks blocks within 15 kb of one element -> primary window "no_anchor";
    # hybrid -> that element resolved with its expected state
@pytest.mark.skipif(shutil.which("blastn") is None, reason="BLAST not installed")
def test_flank_blast_blocks(tmp_path): ...   # blocks produced; strand from sstart > send
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - **Pieces:** walk outward from each top-level element and dedupe pieces by coordinates.
  - **`FlankMm2Route`:** the same B index as Task 15, mapping pieces with `best_n=5`.
  - **`FlankBlastRoute`:**
    - Build the database with `makeblastdb -dbtype nucl` into `workdir/blastdb/<B>`. Decompress bgzip input
      through `Fasta` into a temp FASTA first.
    - Search with `blastn -task megablast -outfmt "6 qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore nident" -evalue 1e-20 -max_target_seqs 50 -max_hsps 20 -num_threads T`.
    - Each hit is a block with `matches = nident` and `alen = length`.
  - **`HybridRoute.raw_blocks`:** take the primary's raw blocks, compute provisional windows, gather pieces only for
    elements whose window is not ok, map them with the flank-mm2 method, and return the union.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add flank-mapping routes and hybrid"`.

---

### Task 19: Locus catalog

**Files:** Create `src/ltrpav/loci.py`, `tests/test_loci.py`

**Interfaces:**
- Produces:

```python
@dataclass
class GenomeState:
    state: str; tier: str; seqid: str | None; start: int | None; end: int | None; strand: str | None
    k: float | None; flags: list[str]
@dataclass
class Locus:
    lid: str; members: dict[str, str]          # genome -> eid (annotated copies)
    discovery: list[str]; family: str | None; superfamily: str | None; clade: str | None
    length: int; ltr_len: int; tsd: str | None; states: dict[str, GenomeState]
QcRow = tuple[str, str, float]                  # (scope, metric, value)
def build_loci(samples: list[Sample], elements: dict[str, list[Element]],
               call_paths: dict[tuple[str, str], Path]) -> tuple[list[Locus], list[QcRow]]
```

- [ ] **Step 1: Write the failing tests** (synthetic call tables; genomes A and B annotated, C unannotated, both A and
  B use seqid "chr1").

```python
def test_link_and_states():       # a1->B call P whose image overlaps b1 >= 80% reciprocal: one locus {A: a1, B: b1};
                                  # C state from a1->C and b1->C calls; member states "P", tier "annot"
def test_conflict_rules():        # a1->C E/high vs b1->C D/high -> C "U" + "conflict"; E/high vs D/medium -> E
def test_annotation_conflict():   # a2->B E/high but B annotation linked to the locus -> B stays P + "annot_conflict"
def test_unannotated_genome():    # C appears only through projections; never a member
def test_shared_seqid_names():    # A chr1:1000-2000 and B chr1:1000-2000 unlinked by calls -> two loci
def test_lid_deterministic():     # same inputs in another order -> same lids (L0000001...)
def test_qc_counters():           # n_loci, n_conflict, n_multi_member reported as QcRows
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - **Linking:** union-find over `(genome, eid)`. A P/S/T call whose B image overlaps a B element with reciprocal
    overlap `>= COV_PRESENT` links the two.
  - **States:** members get `P` (tier `annot`). Other genomes take the highest-tier call; tied different states give
    U + `conflict`. Member-vs-projection disagreement adds `annot_conflict`.
  - **Lids:** sort loci by the first sheet genome with coordinates, then its fai seqid order, then start.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add locus catalog across genome pairs"`.

---

### Task 20: Output files

**Files:** Create `src/ltrpav/outputs/{__init__,tables,vcf,tracks,manifest}.py`, `tests/test_outputs.py`

**Interfaces:**
- Consumes: `Locus`, `GenomeState`, `QcRow`, `Sample`, `Fasta`.
- Produces: `write_loci_tsv(loci, samples, path)`; `write_pav_matrix(loci, samples, path)`;
  `write_qc(rows: list[QcRow], path)` (columns `scope metric value`); `write_vcf(loci, samples, ref_label: str, fasta: Fasta, path: Path) -> tuple[Path, Path]`
  (vcf.gz with `.tbi`, and the unplaced TSV); `write_tracks(loci, samples, outdir)`;
  `write_manifest(path, argv, params, samples, checksums, started, finished)`.

- [ ] **Step 1: Write the failing tests**

```python
def test_vcf_encoding(tmp_path):
    v = pysam.VariantFile(write_vcf(loci, samples, "A", fa, tmp_path / "pav.vcf.gz")[0])
    rec = next(iter(v))
    assert rec.alts == ("<INS:ME:LTR>",) and rec.info["SVTYPE"] == "INS"
    assert [rec.samples[s]["GT"] for s in ("A", "B", "C")] == [(1,), (0,), (None,)]
    assert [rec.samples[s]["ST"] for s in ("A", "B", "C")] == ["P", "E", "D"]
    assert rec.info["AA"] == rec.ref                     # an empty site is observed
def test_vcf_pos_conventions(tmp_path):  # present in ref genome: POS = start-1; E in ref genome: POS = last base of the TSD copy
def test_unplaced_side_file(tmp_path):   # ref-genome state D -> row in pav.unplaced.tsv, not in the VCF
@pytest.mark.skipif(shutil.which("bcftools") is None, reason="bcftools missing")
def test_bcftools_reads_vcf(tmp_path):   # `bcftools view -H` exit 0 with the expected record count
def test_tracks(tmp_path):               # <label>.pav.gff3 types: P/S/T LTR_retrotransposon, E insertion_site,
                                         # D deletion_junction; attribute states=A:P,B:E,C:D (every genome);
                                         # BED6+3 columns state, tier, family
def test_matrix_and_loci_tsv(tmp_path): ...
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - **VCF:** pysam `VariantHeader` with contigs from the reference genome's fai. INFO `SVTYPE`, `SVLEN`, `END`,
    `FAM`, `SF`, `K`, `DISC`, `NE` (number of E genomes), `AA`; FORMAT `GT` (haploid), `ST`, `TR`;
    `##ALT=<ID=INS:ME:LTR,...>`. Sort the records, then `pysam.tabix_index(..., preset="vcf", force=True)`.
  - **GT:** 1 for P/S/T, 0 for E, missing for D/O/G/U.
  - **GFF3:** `##gff-version 3` plus `##sequence-region` lines.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add TSV, VCF, GFF3/BED and manifest outputs"`.

---

### Task 21: Command-line interface and QC metrics

**Files:** Create `src/ltrpav/cli.py`, `tests/test_cli.py`; Modify `src/ltrpav/loci.py` (QC metrics below)

**Interfaces:**
- Produces: `main()` (`ltrpav run ...`), `anchor_main()`, `genotype_main()`, `merge_main()`. Shared options:
  `--samples SHEET --outdir DIR [--threads N (default 8)] [--anchor ROUTE (default constants.DEFAULT_ROUTE)] [-v]`.
  Single-stage commands also take `[--pair A,B]`; run and merge take `[--vcf-ref LABEL (default: first sheet row)]`.
  Pairs genotyped = (annotated A, any other B). Outputs land in `--outdir`, cache in `--outdir/work`.
- QC metrics added to `build_loci`, all as QcRows:
  - **Per ordered pair:** `frac_<state>`, `resolved_frac` (P/S/T/E), `high_frac`, `annot_agree` (calls whose B
    coordinates overlap a B element not linked to an ancestor of the A element: fraction P/S/T), `e_in_annot`
    (E calls inside such an element / all E calls).
  - **Per annotated unordered pair:** `reciprocity` (links seen in both directions / links seen in either).
  - **Per genome:** `annot_sensitivity` (loci projected P/high here that have a member here), `gap_rate`, and
    `skipped_<reason>` counts from annotation loading (DESIGN 8: warn-and-skip counts are reported).

- [ ] **Step 1: Write the failing tests**

```python
def test_run_toy_three_genomes(tmp_path):   # A, B annotated + C genotype-only: every output file exists; manifest has
                                            # version, argv, sha256 of each input; qc.tsv has reciprocity for A~B
def test_run_shared_seqids(tmp_path):       # all three genomes use "chr1": loci and VCF correct (Review Focus 1)
def test_rerun_skips(tmp_path, caplog):     # second identical run logs "skip" for every stage, outputs unchanged
def test_help_is_short(capsys):             # `ltrpav --help` < 40 lines
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - Logging: `logging` at INFO, DEBUG with `-v`.
  - Fail fast: SampleSheetError, AnnotationError, a missing external binary for the chosen route.
  - Every `Fasta` is opened with `cache_dir=outdir/work/fai`, so FASTAs without an index (Zd) work in place.
  - Normalized elements go to `work/elements/<label>.tsv`; stages are checkpointed.
  - On a pair with `resolved_frac < 0.01`, log a warning ("no orthologous alignment between A and B?").
- [ ] **Step 4: Run.** Expected: PASS. Then run `pytest -q && ruff check .`; everything passes.
- [ ] **Step 5: Commit** `"Add CLI, QC metrics and end-to-end run"`.

---

### Task 22: Pair simulator on a real backbone

**Files:** Create `src/ltrpav/sim/{__init__,genome,pair,cli}.py`, `tests/test_sim.py`

**Interfaces:**
- Produces:

```python
class SimGenome:                       # seq: bytearray; prov: np.ndarray[int64] (ancestral id per base, new ids for inserts)
    def insert(self, pos: int, payload: bytes, prov: np.ndarray) -> None
    def delete(self, start: int, end: int) -> None
    def invert(self, start: int, end: int) -> None
    def gap(self, start: int, end: int) -> None          # replace with N, provenance kept
    def mutate(self, sub_rate: float, indel_rate: float, rng: np.random.Generator) -> None   # one-pass rebuild
    elements: dict[str, SimElement]                      # coordinates lifted after every edit
@dataclass
class Donor: seq: str; ltr_left: int; ltr_right: int; family: str | None; superfamily: str | None
@dataclass
class PairParams:      # defaults per 6 Mb, Zea-like; scale multiplies every count
    sub_rate: float = 0.006; indel_rate: float = 0.0006
    n_shared: int = 150; n_branch: int = 200; k_shared: tuple = (0.01, 0.03); k_branch: tuple = (0.0, 0.01)
    n_solo: int = 40; n_del_flank: int = 30; n_del_partial: int = 20; n_gap: int = 15; inv_len: int = 300_000
    dropout: float = 0.1; jitter: float = 0.05; scale: float = 1.0
def simulate_pair(backbone: str, backbone_elements: list[Element], donors: list[Donor], params: PairParams,
                  seed: int) -> tuple[SimGenome, SimGenome, list[dict]]   # truth rows, both directions
def write_pair(outdir: Path, A: SimGenome, B: SimGenome, truth: list[dict], params: PairParams, seed: int) -> None
    # A.fa, B.fa, A.gff3, B.gff3 (write_gff3; dropout, jitter), truth.tsv, samples.tsv, params.json
```

- CLI: `ltrpav-sim pair --fasta FA --region SEQ:START-END --annotation ANNOT --outdir DIR [--seed N] [--scale X]`.
  Donors are level-0, childless, high-confidence elements of the same annotation; up to 2000 are sampled with the
  seed.
- Truth rules: element `e` of X in the other genome Y, using provenance. Here `w = 2L`, and "contiguous" means
  Y keeps the ids of the w bases on each side of `e`'s target site in order, with only the target copy between them.

| e's history | condition in Y (checked in this order) | truth |
|---|---|---|
| any | an N run within REFINE_PAD of the site or over e's image | G |
| inserted in X after the split | an X-specific ancestor exists | that ancestor's truth (+ host_empty if E) |
| inserted in X after the split | site contiguous, nothing else inserted there | E |
| inserted in X after the split | site contiguous, a Y-specific insertion there | O |
| inserted in X after the split | otherwise | D |
| present before the split | solo event on e in Y's branch | S |
| present before the split | >= 80% of e's ids and of each LTR in Y | P (+ inv if inside the inversion) |
| present before the split | >= MIN_SEG of e's ids in Y | T |
| present before the split | otherwise | D |

- [ ] **Step 1: Write the failing tests** (small backbone: 400 kb random with 10 planted pre-existing elements).

```python
def test_inserted_element_and_tsds():    # A.fa holds the payload at the reported coords; equal 5-bp TSDs both sides
def test_solo_keeps_one_ltr_and_tsds():  # solo'd element in B: one LTR-length segment between the two TSD copies
def test_truth_engineered_events():      # one of each engineered event -> expected truth (E, P, S, D, T, G, host_empty)
def test_seed_determinism(tmp_path):     # same seed -> identical FASTA and truth bytes
def test_gff3_loads(tmp_path):           # load_annotation(A.gff3) count == elements * (1 - dropout) +- 3 sd
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.** Sequence of events:
  1. Ancestor = backbone.
  2. Shared insertions (positions uniform over the current sequence, so nesting arises naturally).
  3. Split.
  4. Per branch: insertions; solo-LTRs (hybrid LTR at a random crossover, both TSDs kept); flank deletions (50-2000
     bp beyond at least one end); internal partial deletions (20-60% of the internal region); `mutate`; gaps
     (100-bp N runs, a third of them within 20 bp of an element end or an empty site).
  5. One inversion in B.

  Young copies: both LTRs equal the donor's left LTR, then each mutated at K/2.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add real-backbone pair simulator with provenance truth"`.

---

### Task 23: Scoring calls against truth

**Files:** Create `src/ltrpav/sim/score.py`, `tests/test_score.py`

**Interfaces:**
- Produces: `score(calls_path: Path, elements_path: Path, truth_path: Path) -> list[dict]`. Rows carry
  `state`, `tier_set` ("all" or "high"), `tp`, `fp`, `fn`, `precision`, `recall`, plus one summary row with
  `correct_resolved_frac`, which is (call == truth and truth in P/S/T/E) / (truth in P/S/T/E), and
  `unresolved_frac`. Calls join truth through `eid -> Element.name`.

- [ ] **Step 1: Write the failing test.** A tiny table gives known counts, e.g. P precision 2/3 and E recall 1/2.
- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.** Use the csv module.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add simulation scoring"`.

---

### Task 24: Aligner bake-off and default route

**Files (outside repo):** `benchmark_pav/bakeoff/{PARAMS.md, 01_sim.sh, 02_run_sims.py, 03_score_sims.py, 04_chr10.sh, 05_chr10_metrics.py, 06_anchorwave_readout.py, backends.py, REPORT.md}`.
**Repo:** Modify `src/ltrpav/constants.py` (`DEFAULT_ROUTE`) and `docs/DESIGN.md` (section 9 outcome).

- [ ] **Step 1: Interrogate parameters before any run.** Write `PARAMS.md`. For each parameter: what it does, its
  default, the choice and why.
  - **minimap2/mappy:** `-x asm5/10/20`, `-U`, `-f`, `-z`, `-r`, `-N`/`best_n`, `-p`, `--secondary`.
  - **FastGA:** `-f`, `-c`, `-s`, `-l`, `-i`, soft masks `-M`, `-S`.
  - **BLAST:** `-task`, `word_size`, `-dust`, `-evalue`, `-max_target_seqs` (returns the first N hits, not the
    best N), `-max_hsps`.
  - **LASTZ:** `lastz_32`, `--step`, `--seed`, `--chain`, `--gapped`, `--hspthresh`, `--ydrop`, `--ambiguous=iupac`.
  - **AnchorWave:** `-IV`, `-t`.
- [ ] **Step 2: Add the alternative local backends.** `backends.py` registers `lastz`, `wfa` (pywfa, gap-affine-2p,
  whole window) and `maf` (AnchorWave alignment sliced per window) through `register_backend`. Unit-check each on
  three toy cases (P, E, D) in a scratch test. Expected: correct states.
- [ ] **Step 3: Simulate.** `01_sim.sh`: `ltrpav-sim pair` on three B73 chr10 backbones with seeds 1 and 2:
  - R1 `B73v5_chr10:2000001-8000000` (arm)
  - R2 `B73v5_chr10:48000001-54000000` (the CentC cluster at 49-52 Mb in `inputs/annot_B73v5/te.gff3.gz`)
  - R3 `B73v5_chr10:140000001-146000000` (arm)
- [ ] **Step 4: Run routes on the sims.** `02_run_sims.py`, both directions, 32 threads:
  - Routes: `mm2`, `fastga`, `flank-mm2` with caps 2/5/10/20 kb, `flank-blast` at 10 kb, `hybrid`. Local backend:
    mappy.
  - Then the best two routes with the `lastz` and `wfa` backends.
  - Record wall time and peak RSS with `/usr/bin/time -v`. Each batch over 15 min runs detached.
- [ ] **Step 5: Score.** `03_score_sims.py` writes per-state precision and recall (all tiers and high tier),
  `correct_resolved_frac`, `unresolved_frac`, time and RSS.
- [ ] **Step 6: Real chr10.** `04_chr10.sh` builds chr10-only FASTAs and annotations for B73, TIL18 and TIL01 (GFF3
  filtered from `run/*_all_depth_LTR_cleaned.gff3`), then runs every route detached. `05_chr10_metrics.py` reports
  `resolved_frac`, `annot_agree`, `e_in_annot`, `reciprocity`, time and RSS. Whole-genome cost is extrapolated by
  the genome/chr10 length ratio.
- [ ] **Step 7: AnchorWave read-out** (once `anchorwave/done.flag` exists). `06_anchorwave_readout.py` classifies
  B73->TIL18 chr10 with the `maf` backend and reports per-state agreement with every route. Inspect at least 20
  disagreements with window dotplots, using the making-figures skill's quick-plot rules, and write what each shows.
- [ ] **Step 8: Decide by the rule fixed in DESIGN section 9.** Winner = best `correct_resolved_frac` among routes
  that meet:
  - the cost bar: whole-genome pair about 2 h wall at 32 threads, <= 250 GB;
  - the precision bar: high tier >= 0.95 for P and E on the sims.

  The local backend is chosen the same way. Write `REPORT.md` with tables, the decision and misses (misses also go
  to `benchmark_pav/dead_ends.md`).
- [ ] **Step 9: Record the decision.** Set `DEFAULT_ROUTE` to the winner, add the outcome to DESIGN section 9, run
  `pytest -q`, then commit `"Set default anchoring route from bake-off"`. Send the user a two-line note. Stop and
  ask only if the result changes the design, for example no route meets the cost bar.

---

### Task 25: Whole-genome run on B73, TIL18, TIL01 + Zd and QC against DESIGN 10.1

**Files (outside repo):** `benchmark_pav/main3/{samples.tsv, run.log, qc_report.py, QC.md}`,
`/data2/chris/maize_introgression/memo_ltrpav.md`, `benchmark_pav/dead_ends.md`

- [ ] **Step 1: Write the samples sheet.**
  - `B73 inputs/B73v5.fa run/B73v5_LTRs maize .`
  - `TIL18 inputs/TIL18.fa run/TIL18_LTRs mexicana .`
  - `TIL01 inputs/TIL01.fa run/TIL01_LTRs parviglumis .`
  - `Zd inputs/Zd.fa . diploperennis outgroup`

  Use absolute paths. Zd has no `.fai`; the tool indexes it into `work/`.
- [ ] **Step 2: Launch.** `setsid -f nohup /usr/bin/time -v mamba run -n ltrpav ltrpav run --samples samples.tsv --outdir . --threads 32 > run.log 2>&1 < /dev/null`.
  Verify the PID (SID = PID, PPID = 1). Check `run.log` milestones while it runs.
- [ ] **Step 3: QC report.** `qc_report.py` writes `QC.md` with one row per DESIGN 10.1 bar and a plain pass or miss:
  - reciprocity >= 0.95
  - `annot_agree` >= 0.95 and `e_in_annot` <= 2%
  - the sim high-tier precision (from Task 24)
  - independent annotator: agreement of calls with the EDTA structural elements in `inputs/annot_*` (reported)
  - outgroup impossible patterns: ingroup E at loci where Zd is P/S/T (reported as an error-rate estimate)
  - LTRmix comparison: `benchmark/results/main3/elements.B73v5.tsv` `in_TIL18`/`in_TIL01` against LTRpav P/E for
    the same element names (reported)
  - runtime and RSS per pair against the cost bar
- [ ] **Step 4: Write up.** Each miss gets a short `dead_ends.md` entry and an investigation note. Misses are never
  tuned away; a rule changes only for a reason independent of the truth, then gets rechecked.
  Write `memo_ltrpav.md` (CLAUDE.md format): date, purpose, env and versions, inputs, exact commands, outputs,
  gotchas, `claude --resume` name.
- [ ] **Step 5: Hand off.** Report the QC table to the user. Plan 2 (analyses) is written next, from these outputs.
