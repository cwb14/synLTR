import gzip
import logging
from dataclasses import replace

from ltrpav.annotation.gff3 import load_gff3, write_gff3
from ltrpav.constants import RECORD_WARNINGS
from ltrpav.elements import Element, make_eid

LTRQUEST = (
    "##gff-version 3\n"
    "B73v5_chr1\tLTRquest\tLTR_retrotransposon\t51712\t70182\t.\t-\t.\t"
    "ID=B73v5_LTRs_LTRRT_95050;Name=B73v5_chr1:51712-70182;classification=LTR/Copia/SIRE;order=LTR;"
    "superfamily=Copia;clade=SIRE;family=merged_fam00001;depth=1;identity=0.99661;K2P_d=0.00340137;"
    "motif=tg...ca;tsd=CACCT;confidence=high;strand_source=tesorter\n"
    "B73v5_chr1\tLTRquest\tlong_terminal_repeat\t51712\t53005\t.\t-\t.\t"
    "ID=B73v5_LTRs_LTRRT_95050.lLTR;Parent=B73v5_LTRs_LTRRT_95050\n"
    "B73v5_chr1\tLTRquest\tlong_terminal_repeat\t59462\t70182\t.\t-\t.\t"
    "ID=B73v5_LTRs_LTRRT_95050.rLTR;Parent=B73v5_LTRs_LTRRT_95050\n"
)

EDTA = (
    "##gff-version 3\n"
    "chr1\tEDTA\trepeat_region\t60659\t70135\t.\t-\t.\tID=repeat_region_1\n"
    "chr1\tEDTA\ttarget_site_duplication\t60659\t60663\t.\t-\t.\tID=lTSD_1;Parent=repeat_region_1\n"
    "chr1\tEDTA\tlong_terminal_repeat\t60664\t61985\t.\t-\t.\tID=lLTR_1;Parent=repeat_region_1;Name=x;"
    "Classification=LTR/Copia;ltr_identity=1.0000;Method=structural;motif=TGCA;tsd=GAGTG\n"
    "chr1\tEDTA\tCopia_LTR_retrotransposon\t60664\t70130\t.\t-\t.\tID=Copia_1;Parent=repeat_region_1;"
    "Name=x;Classification=LTR/Copia;Sequence_ontology=SO:0002264;ltr_identity=1.0000;"
    "Method=structural;motif=TGCA;tsd=gagtg\n"
    "chr1\tEDTA\tlong_terminal_repeat\t68826\t70130\t.\t-\t.\tID=rLTR_1;Parent=repeat_region_1;"
    "Classification=LTR/Copia;ltr_identity=1.0000;Method=structural\n"
    "chr1\tEDTA\ttarget_site_duplication\t70131\t70135\t.\t-\t.\tID=rTSD_1;Parent=repeat_region_1\n"
    "chr2\tEDTA\tLTR_retrotransposon\t100\t900\t.\t+\t.\tID=frag1;Name=frag1;Classification=LTR/Gypsy;"
    "Method=homology\n"
)


def test_ltrquest_convention(tmp_path):
    p = tmp_path / "a.gff3"
    p.write_text(LTRQUEST)
    (e,), skipped = load_gff3(p, "B73")
    assert (e.start, e.end, e.ltr_left, e.ltr_right, e.tsd) == (51712, 70182, (51712, 53005), (59462, 70182), "CACCT")
    assert abs(e.k - 0.00340137) < 1e-9 and (e.superfamily, e.clade) == ("Copia", "SIRE")
    assert (e.family, e.confidence, e.strand, e.seqid) == ("merged_fam00001", "high", "-", "B73v5_chr1")
    assert e.name == "B73v5_chr1:51712-70182" and e.eid == make_eid("B73", "B73v5_chr1", 51712, 70182)
    assert not skipped


def test_edta_convention_and_fragment(tmp_path):
    p = tmp_path / "e.gff3"
    p.write_text(EDTA)
    els, skipped = load_gff3(p, "B73")
    assert len(els) == 1 and els[0].ltr_right == (68826, 70130) and els[0].tsd == "GAGTG"
    assert els[0].ltr_left == (60664, 61985)
    assert els[0].k == 0.0 and els[0].superfamily == "Copia" and els[0].family == "x"
    assert els[0].clade is None and els[0].confidence is None
    assert skipped["no_ltr_pair"] == 1


def test_jc69_and_escapes_and_fasta_stop(tmp_path):
    p = tmp_path / "j.gff3"
    p.write_text(
        "##gff-version 3\n# comment\n"
        "c\tX\tLTR_retrotransposon\t1\t100\t.\t.\t.\tID=a%3Bb;ltr_identity=0.9\n"
        "c\tX\tlong_terminal_repeat\t1\t10\t.\t.\t.\tID=a1;Parent=a%3Bb\n"
        "c\tX\tlong_terminal_repeat\t91\t100\t.\t.\t.\tID=a2;Parent=a%3Bb\n"
        "##FASTA\n"
        "c\tX\tLTR_retrotransposon\t1\t50\t.\t.\t.\tID=after\n"
        "c\tX\tlong_terminal_repeat\t1\t5\t.\t.\t.\tID=z1;Parent=after\n"
        "c\tX\tlong_terminal_repeat\t45\t50\t.\t.\t.\tID=z2;Parent=after\n"
    )
    els, _ = load_gff3(p, "G")
    assert len(els) == 1  # the feature after ##FASTA is not read
    (e,) = els
    assert e.name == "a;b" and e.strand == "."
    assert abs(e.k - 0.107326) < 1e-5


def _els():
    a = Element("G", make_eid("G", "chr1", 10, 200), "n;1=x", "chr1", 10, 200, "+", (10, 30), (180, 200),
                "ACGTA", 0.1 + 0.2, "fam,1", "Gypsy", "Tekay", "high")
    b = Element("G", make_eid("G", "chr2", 5, 99), "chr2:5-99", "chr2", 5, 99, "-", (5, 14), (90, 99),
                None, None, None, None, None, None)
    return [a, b]


def test_write_read_round_trip(tmp_path):
    els = _els()
    for name in ("o.gff3", "o.gff3.gz"):
        p = tmp_path / name
        write_gff3(els, p)
        got, skipped = load_gff3(p, "G")
        assert got == els and not skipped
    text = (tmp_path / "o.gff3").read_text().splitlines()
    assert text[0] == "##gff-version 3" and len(text) == 7
    assert "\tLTR_retrotransposon\t" in text[1] and "ID=G|chr1:10-200.lLTR;Parent=G|chr1:10-200" in text[2]
    with gzip.open(tmp_path / "o.gff3.gz", "rt") as fh:
        assert fh.read() == (tmp_path / "o.gff3").read_text()


def test_gz_deterministic_and_parent_level_ignored(tmp_path):
    els = [replace(e, parent="x", level=2) for e in _els()]
    write_gff3(els, tmp_path / "1.gz")
    write_gff3(els, tmp_path / "2.gz")
    assert (tmp_path / "1.gz").read_bytes() == (tmp_path / "2.gz").read_bytes()
    got, _ = load_gff3(tmp_path / "1.gz", "G")
    assert got == _els()


def test_multi_parent_and_escaped_comma(tmp_path):
    p = tmp_path / "m.gff3"
    p.write_text(
        "c\tX\tLTR_retrotransposon\t1\t100\t.\t+\t.\tID=h1\n"
        "c\tX\tlong_terminal_repeat\t1\t10\t.\t+\t.\tID=l1;Parent=h1,other\n"
        "c\tX\tlong_terminal_repeat\t91\t100\t.\t+\t.\tID=l2;Parent=other,h1\n"
    )
    (e,), skipped = load_gff3(p, "G")
    assert (e.ltr_left, e.ltr_right) == ((1, 10), (91, 100)) and not skipped
    a = Element("G,x", make_eid("G,x", "chr,1", 10, 200), "n", "chr,1", 10, 200, "+", (10, 30), (180, 200),
                None, None, None, None, None, None)
    write_gff3([a], tmp_path / "c.gff3")
    got, skipped = load_gff3(tmp_path / "c.gff3", "G,x")
    assert got == [a] and not skipped


# ---------------------------------------------------------------- malformed records

GOOD = ("c\tX\tLTR_retrotransposon\t1001\t2000\t.\t+\t.\tID=ok\n"
        "c\tX\tlong_terminal_repeat\t1001\t1100\t.\t+\t.\tParent=ok\n"
        "c\tX\tlong_terminal_repeat\t1901\t2000\t.\t+\t.\tParent=ok\n")


def test_malformed_records_are_skipped_with_file_and_line(tmp_path, caplog):
    """A malformed LTR-RT or LTR line is skipped with a warning naming the file and line; a malformed line of a
    feature type the loader never uses (a gene) is not even read: no warning, no count, no abort."""
    p = tmp_path / "bad.gff3"
    p.write_text(
        "##gff-version 3\n"
        "c\tX\tgene\t20000\t2O100\t.\t+\t.\tID=g1\n"  # line 2: unused type, bad coordinate
        "c\tX\tmRNA\t5\n"  # line 3: unused type, too few columns
        + GOOD  # lines 4-6
        + "c\tX\tLTR_retrotransposon\t3001\t4OOO\t.\t+\t.\tID=b1\n"  # line 7: bad coordinate
        "c\tX\tLTR_retrotransposon\t6000\t5001\t.\t+\t.\tID=b2\n"  # line 8: start > end
        "c\tX\tLTR_retrotransposon\t7001\t8000\t.\t+\t.\tID=b3\n"  # line 9: its LTRs are malformed
        "c\tX\tlong_terminal_repeat\t7001\t7100\t.\t+\n"  # line 10: 7 columns
        "c\tX\tlong_terminal_repeat\t0\t8000\t.\t+\t.\tParent=b3\n"  # line 11: start < 1
    )
    with caplog.at_level(logging.WARNING, logger="ltrpav.annotation"):
        els, skipped = load_gff3(p, "G")
    assert [e.name for e in els] == ["ok"]
    assert skipped == {"malformed_coordinates": 3, "malformed_columns": 1, "no_ltr_pair": 1}
    warned = [r.getMessage() for r in caplog.records]
    assert [w.split(": ")[0] for w in warned] == [f"{p}:{n}" for n in (7, 8, 10, 11)]
    assert "malformed_coordinates" in warned[0] and "'4OOO'" in warned[0] and "malformed_columns" in warned[2]


def test_malformed_record_warnings_are_capped(tmp_path, caplog):
    p = tmp_path / "many.gff3"
    p.write_text(GOOD + "".join(f"c\tX\tLTR_retrotransposon\t{i}x\t9\t.\t+\t.\tID=b{i}\n" for i in range(12)))
    with caplog.at_level(logging.WARNING, logger="ltrpav.annotation"):
        els, skipped = load_gff3(p, "G")
    assert len(els) == 1 and skipped == {"malformed_coordinates": 12}
    assert len(caplog.records) == RECORD_WARNINGS and "only counted" in caplog.records[-1].getMessage()


def test_ltr_pair_negatives_crlf_nan_k2p_and_escaped_seqid(tmp_path):
    """Three LTRs or one LTR is no_ltr_pair; CRLF line ends are read; a K2P of nan is unknown; a seqid is
    percent-decoded (GFF3 escapes column 1)."""
    p = tmp_path / "n.gff3"
    p.write_text(
        "c\tX\tLTR_retrotransposon\t1\t100\t.\t+\t.\tID=three\n"
        + "".join(f"c\tX\tlong_terminal_repeat\t{s}\t{s + 9}\t.\t+\t.\tParent=three\n" for s in (1, 45, 91))
        + "c\tX\tLTR_retrotransposon\t201\t300\t.\t+\t.\tID=one\n"
        "c\tX\tlong_terminal_repeat\t201\t210\t.\t+\t.\tParent=one\n"
        "chr%2C9\tX\tLTR_retrotransposon\t401\t500\t.\t-\t.\tID=crlf;K2P_d=nan\r\n"
        "chr%2C9\tX\tlong_terminal_repeat\t401\t410\t.\t-\t.\tParent=crlf\r\n"
        "chr%2C9\tX\tlong_terminal_repeat\t491\t500\t.\t-\t.\tParent=crlf\r\n")
    (e,), skipped = load_gff3(p, "G")
    assert skipped == {"no_ltr_pair": 2}
    assert (e.seqid, e.strand, e.k, e.ltr_right) == ("chr,9", "-", None, (491, 500))


def test_edta_family_from_name(tmp_path):
    """EDTA keeps the family in Name and a unique ID: a record with Classification and no `family` takes Name
    as its family and ID as its name; superfamily comes from Classification."""
    p = tmp_path / "edta.gff3"
    p.write_text(
        "##gff-version 3\n"
        "chr1\tEDTA\trepeat_region\t100\t900\t.\t+\t.\tID=repeat_region_1\n"
        "chr1\tEDTA\tlong_terminal_repeat\t100\t199\t.\t+\t.\tID=lLTR_1;Parent=repeat_region_1;"
        "Name=TE_00000123;Classification=LTR/Gypsy\n"
        "chr1\tEDTA\tLTR_retrotransposon\t100\t900\t.\t+\t.\tID=Gypsy_1;Parent=repeat_region_1;"
        "Name=TE_00000123;Classification=LTR/Gypsy;Method=structural\n"
        "chr1\tEDTA\tlong_terminal_repeat\t801\t900\t.\t+\t.\tID=rLTR_1;Parent=repeat_region_1;"
        "Name=TE_00000123;Classification=LTR/Gypsy\n")
    (e,), skipped = load_gff3(p, "G")
    assert (e.family, e.superfamily, e.name) == ("TE_00000123", "Gypsy", "Gypsy_1")
    assert not skipped
