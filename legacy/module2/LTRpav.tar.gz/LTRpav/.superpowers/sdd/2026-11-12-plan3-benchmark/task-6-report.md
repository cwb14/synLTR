# Task 6 report: decoy-anchored emission model for the painting (and Task 5's review minors)

Status: DONE_WITH_CONCERNS. BASE 78abe50; branch plan3-benchmark; nothing pushed.
Scratch: `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t6/` (`$S` below).

## Commits

| sha | subject |
|---|---|
| 2c4db4b | Pop review minors: realized indels, seed range, stale outdir, subprocess determinism |
| c7ccacd | Add a decoy-anchored emission model to the painting (option, off by default) |

Both use the global identity (cwb14). No trailers, no AI attribution, nothing set.

## Files

- 2c4db4b: `src/ltrpav/sim/{pop.py,popbuild.py,cli.py}`, `tests/test_pop_cli.py`, `tests/test_popbuild.py` (sim modules only).
- c7ccacd: `src/ltrpav/analysis/paint.py`, `src/ltrpav/analysis/constants.py`, `tests/test_paint.py`: the brief's file list.
  `tests/catalog_toy.py`, report.py, the CLI and DESIGN.md are untouched.

## Commit 1: Task 5's review minors (rulings in progress.md)

- **m1.** popbuild exposes it cheaply.
  - `_Chrom` records, as each sample is built, the indels it holds:
    - a deletion that is not in `indel_skip`;
    - inserted bases whose junction the carrier keeps.
  - `build_chrom(..., *, held=None)` adds them to the set it is given.
  - pop's `realized` now counts only held indels: `indels`, `indel_insertions` and `indel_deletions`.
  - A new dropped counter, `indel_in_no_genome`, keeps requested = realized + dropped.
  - The pop docstring names the rule. It also covers the case the review did not name: inserted bases that every
    carrier loses with both junction bases.
  - Effect size on the test toy (module run's arguments, threads 3; `$S/m1/out/params.json`): 368 of 2,842, 460 of
    2,954 and 183 of 1,465 drawn indels are in no genome on c01-c03 (13-16%). These were previously counted as
    realized.
- **m3.** `MAX_SEED = 2**32 - 1`.
  - `sim/cli._seed` (shared by `pop` and `pair`) rejects seeds outside [0, MAX_SEED] with a usage error (exit 2).
  - `simulate_pop` raises ValueError.
  - The pop docstring states the aliasing reasons.
  - The stream words are now named, `_GAPS, _ANNOT = 100, 200`, with a module assert `MAX_CHROMS < _GAPS < _ANNOT`.
    Values are unchanged.
- **m4.** `check_outdir`: a missing outdir, or a directory holding nothing but `fai/` (CACHE, a directory), passes.
  Anything else raises one ValueError, which is one `error:` line and exit 1.
  - `_pop` calls it before simulating, and `write_pop` calls it first.
  - The `<label>.fa.fai` unlink in write_pop is gone: an outdir that must be empty cannot hold one.
- **m5.** New coverage, listed under tests below.
- **m6.** A subprocess determinism test.

## Commit 2: the model (c7ccacd)

- constants.py:
  - `PAINT_DISCOVERY = "recipient"`;
  - `PAINT_EMISSION = "em"`;
  - `EMISSIONS = ("em", "decoy")`.
  Each has a one-line reason. `paint.DISCOVERY` stays the only source of the discovery choices.
- `fit_hmm(..., fix_e0=False)`: with `fix_e0`, the e0 update is skipped and EM still fits e1, pi and L. The em path
  is unchanged line for line.
- `paint(cat, trio, blocks, discovery=PAINT_DISCOVERY, emission=PAINT_EMISSION, self_counts=None)`.
  - An unknown emission raises ValueError.
  - Under "decoy", e0 = (decoy counts + 0.5) / (n + 1), from `classes(cat, Y, X, D, discovery)`. e1 = e0 * (5, 0.2),
    normalized.
  - No decoy means fallback to em. `Painting.fallback` holds `_no_decoy_text`, which covers both an unannotated
    sister under recipient discovery and a decoy without an informative locus.
  - `Painting` gains `emission` (the model fitted; the one asked for when skipped) and `fallback`.
- Rows, placed right after `donor_state`:
  - `emission` (string);
  - `e0_RD`, `e0_RS`, `e1_RD`, `e1_RS`.
  They are NA for a collapsed painting, and for a skipped painting that writes rows. A skipped painting with no loci
  still writes no rows, as before.
  - Under decoy, the e0 rows declare the decoy's loci (`n` = the decoy's informative loci, `disc=<S>`), since e0 is
    computed from them. The other rows keep the target's declaration.
- Findings:
  - one WARNING on fallback;
  - under decoy, one line giving n_D, n_X, e0 and e1.
  The default (em) findings are unchanged.

## Tests and what each pins

Commit 1:
- `test_popbuild.py::test_held_indels`: `held` excludes a deletion that a solo above it pre-empts. It also excludes
  inserted bases that every carrier loses inside the solo. It includes a happening deletion and inserted bases kept on
  one carrier, or at the stretch's edge. Sequences are identical to a build without `held`.
- `test_pop_writes_outputs`, extended:
  - the dropped key set includes `indel_in_no_genome`;
  - requested indels = realized + `indel_in_no_genome`, and realized = insertions + deletions;
  - backbone counts pinned by construction: 40 annotation elements; c01 14 (one nested), c02 13, c03 6 before the cut,
    with each region and length;
  - fractions.tsv: `backbone_bp` = the regions' bp; `genome_bp` = the FASTA's bases;
    `fraction` = tract_bp / backbone_bp; `lifted_fraction` = lifted_bp / genome_bp (to 6 decimals).
- `test_pop_deterministic_across_processes` (m6): two subprocesses with PYTHONHASHSEED 0 and 12345, at threads 1 and 2,
  on 2 x 60 kb. Every output file is byte-identical (tracts present).
- `test_pop_flags_override_json` (m5): `--pulse A>C --bottleneck 2000,500 --per-taxon 1 --f 0.5 --ta 1000` override
  the JSON's C>A, null bottleneck, 2, 0.1 and 3000. Only C1 gets a tract file.
- `test_pop_lineage_pulse` (m5): C>A1 with sub_a at f = 1 gives `tracts.A2.bed` empty. A1's tracts span its whole
  genome: fraction 1.000000, A2 tract_bp 0.
- `test_pop_seed_range` (m3):
  - 2^32 and -1 give exit 2 with one error line naming `--seed` and the bound, for both `pop` and `pair`;
  - `simulate_pop(seed=2^32)` raises ValueError;
  - seed 2^32 - 1 runs and is recorded.
- `test_pop_refuses_stale_outdir` (m4):
  - an outdir holding `truth/tracts.A2.bed` gives exit 1 and one error line naming the outdir, before simulating
    (simulate_pop monkeypatched to fail);
  - the outdir is untouched, and `write_pop` refuses it too;
  - `fai/` alone passes and is kept; a missing outdir passes;
  - a file named `fai` is refused, and a file as the outdir is refused.

Commit 2 (the brief's six, in `tests/test_paint.py`):
- `test_decoy_e0_fixed`:
  - the constants' values, and PAINT_DISCOVERY in DISCOVERY;
  - `fit.e0` is exactly ((n_D+0.5)/(n+1), (n_X+0.5)/(n+1)), from `classes(cat, "S", "R", "D")`, on seed 1 with
    TRACTS; donor_state holds;
  - `fit_hmm(fix_e0=True)` returns e0 as given while e1, pi and L move, and the default fit moves e0;
  - an unknown emission raises ValueError.
- `test_em_degenerates_decoy_does_not`: the degenerate input, built directly (`_segregated`, choice 1).
  - em: e1[RD] 0.9956 > 0.99 and e0[RS] 0.9956 > 0.99; no informative posterior lies in (0.05, 0.95).
  - decoy: e0 = (0.5, 0.5); RD posteriors 0.759-0.787 (120 loci in (0.05, 0.95)).
- `test_emission_rows`:
  - for em and decoy on seed 1 with TRACTS, the five rows sit right after donor_state, the e* values equal the fit's,
    and each pair sums to 1;
  - seed 1's null (em, collapsed) gives NA e* rows with emission "em";
  - a skipped painting (no RS) gives NA e* rows.
- `test_decoy_null_no_tract`: simulate_run seed 5, no tract, decoy: no tract at q <= 0.05 (1 tract, 0 decoy tracts).
- `test_decoy_planted_tract`: seed 5 with a planted 2-Mb tract (choice 2), decoy: mean posterior inside is 1.000,
  outside 0.000 (> 0.5 required).
- `test_decoy_without_decoy_falls_back`, run for (a) S unannotated and (b) S annotated whose own loci are all private:
  - emission "em" and no scale;
  - posteriors and e0 identical to the default painting;
  - the emission row is "em";
  - exactly one WARNING mentioning "emission", naming "decoy" and the reason. The default painting has none.

## TDD evidence

- Task 6:
  - The six tests were written first. Collection failed on the missing constants, so I added the three constants
    only and reran.
  - All six then failed for the right reasons (`$S/tdd_step2.log`): five on `TypeError: paint() got an unexpected
    keyword 'emission'`, and `test_em_degenerates...` on `AttributeError` (`.emission`).
  - After implementing, test_paint ran 32 of 32. paint + cli_analysis + overview ran 135, exit 0.
- Minors: implemented first (review fixes), then shown to fail at BASE. I ran the new tests against a BASE git-archive
  snapshot with import shims for the new names (`$S/tdd_minors_base.log`):
  - FAILED `test_pop_writes_outputs` (dropped keys and invariants);
  - FAILED `test_pop_seed_range` (DID NOT RAISE SystemExit);
  - FAILED `test_pop_refuses_stale_outdir`;
  - FAILED `test_held_indels` (`build_chrom() got an unexpected keyword`).
  The m5 and m6 tests pass at BASE, as expected: they pin behavior that already worked.

## Choices

1. **The degenerate input repeats the brief's pattern on each of the four toy sequences.**
   - The EM update's +0.5 pseudocounts cap an emission at (n + 0.5) / (n + 1). With the brief's 10 RD runs and 10 RS
     runs of 3 in total (30 loci per class), the em fit reaches only 0.983. My probe on one chain, runs 200 kb apart
     (`$S/probe/degenerate.py`, V4), gave e1[RD] = e0[RS] = 0.9829, so the brief's "> 0.99" is unreachable.
   - I kept every value and put the pattern on each of chr1-chr4 (4.1 Mb each): 120 loci per class, cap 0.996.
   - "200 kb apart" is read as the run spacing; loci are 10 kb apart inside a run.
   - The decoy is S's own loci, one midway between runs, alternating D-like and R-like (40 + 40). It is a background
     with no class bias and no runs, so e0 = (0.5, 0.5).
   - Robustness (`$S/probe/robust.py`, not tuning): with that decoy, every within-run spacing from 1 to 60 kb gives
     degenerate em (> 0.994) and intermediate decoy posteriors.
   - With an RS-skewed decoy mix (0.3/0.7) and runs tighter than 10 kb, the decoy's RD posteriors reach 0.95-0.99.
     Three adjacent RD loci against a 30% RD background are strong evidence, so this is correct behavior, not
     degeneracy. The test pins the balanced case.
2. **"One planted 2-Mb tract" is chr1 and chr2 whole.** The toy's sequences are 1 Mb (simulate_run is fixed), so a
   single 2-Mb interval cannot exist. Two whole sequences give 2 Mb; catalog_toy.py was left untouched.
3. **Seeds.** Both seed-5 tests pass, so Plan 2's rule needed no investigation. For information only, seeds 6-25
   (`$S/seeds.log`) gave 0 of 20 failures for both em and decoy: no null tract at q <= 0.05, and the planted mean
   posterior was 1.000 every time.
4. **e0 pseudocounts.** Under decoy, e0 uses counts + 0.5 (the brief). Under em, the initial e0 stays at LTRmix's
   counts + 1. Both are one expression (`counts + (0.5 if fix_e0 else 1.0)`), and the em path is bit-identical (main3
   below).
5. **NA cases.**
   - Collapsed: all four e* are NA, even e0 under decoy, as the brief says.
   - Skipped: e* are NA; the emission row holds the model asked for, with a note that nothing was fitted.
6. **New sim names.** `CACHE = "fai"` is the outdir's own FASTA-index cache (the CLI uses it). `INDEL_DROPPED =
   "indel_in_no_genome"`. `DROPPED` (draw_events' counters) is unchanged.
7. **No new threshold.** Test-only constants (10 kb, 4.1 Mb, the balanced decoy) are layout choices with the reasons
   above. No package constant beyond the brief's three was added.

## main3 byte identity (Step 4)

- Setup:
  - Three scratch copies of the view (`cp -a`; symlinks copied as links): `$S/m3/{base,head,base_noid}`.
  - `work/analysis/paint.done.json` was removed in each. BASE's analysis fingerprint (0397e094...) equals the view's
    stored key, so the BASE paint would otherwise skip.
  - BASE ran from a `git archive 78abe50` snapshot on PYTHONPATH, with `ltrpav.__file__` asserted (`$S/m3/paint_at.sh`).
  - HEAD ran from the working tree, whose src diff hash I confirmed unchanged at commit c7ccacd.
- Sanity: the BASE rerun reproduces the view's own files byte for byte: paint.rows.tsv, paint.findings.tsv,
  tracts.B73.bed, posterior.B73.tsv, decoy_tracts.TIL01.bed and decoy_posterior.TIL01.tsv.
- `$S/m3/cmp_base_head.log` (compare.py excludes the five new rows and the sentinel rows):
  - work/analysis/paint.rows.tsv: 2,236 rows each side, **identical**;
  - stats.tsv's paint, paint_resolution and paint_seqid rows: 2,236 each, **identical**;
  - posterior.B73.tsv and decoy_posterior.TIL01.tsv: identical;
  - the two BEDs: identical except the youngest_u95 column.
- Why youngest_u95 differs: HEAD's new analysis fingerprint makes the stats part stale, so the paint stage ignores
  identity.tsv (one WARNING). BASE, current, reads it. This is the stage machinery's documented behavior, not Task 6.
- `$S/m3/cmp_noid_head.log`: BASE with identity.tsv removed vs HEAD. All four painting files are **byte-identical**.
  Findings differ only by HEAD's "identity.tsv is ignored" WARNING; no emission line appears in the default.
- Repeated from a `git archive c7ccacd` snapshot (`$S/headsnap`, `ltrpav.__file__` asserted; copy `$S/m3/headsnap`).
  Its 5 output files are byte-identical to the working-tree run, and both comparisons repeat
  (`$S/m3/cmp_{base,noid}_headsnap.log`): rows identical (2,236 / 2,236); against base_noid, all four painting files
  identical.
- Guards:
  - nothing under `benchmark_pav/main3` or `main3_analyses` is newer than the guard marker (`find -newer`: 0);
  - the 15 `inputs/*.fai` files are unchanged in size, mtime and sha256 (`$S/m3/fai.{before,after}.tsv`).

## What the decoy model gives on main3 (description only; `$S/m3/decoy_describe.log`)

Trio B73,TIL01;TIL18 (R B73, S TIL01, D TIL18). Same catalog, trios and blocks as run_paint; nothing written.

| | em (default) | decoy |
|---|---|---|
| e0 (RD, RS) | 0.000486, 0.999514 (fitted) | 0.2352, 0.7648, fixed from TIL01's 1,495 RD + 4,863 RS loci |
| e1 (RD, RS) | 0.999324, 0.000676 | 0.999427, 0.000573 |
| pi; L | 0.359; 301.7 kb | 0.292; 571.5 kb |
| informative loci with 0.05 < post < 0.95 | 6 of 7,515 | 1,299 of 7,515 |
| posterior mean; decoy; excess | 0.370; 0.317; +0.053 | 0.278; 0.222; +0.056 |
| tracts; decoy tracts | 770; 599 | 389; 285 |
| tract bp | 470.5 Mb | 402.8 Mb |
| top tract sum_post (target / decoy) | 350, 334, 310 / 213, 168, 141 | 714, 670, 285 / 225, 188, 188 |
| q: min; 10%; median | 0.20; 0.58; 0.76 | 0.25; 0.53; 0.69 |
| tracts at q <= 0.05 | 0 | 0 |

- Under decoy, the e0 rows declare `n=6358`, `disc=TIL01;present=TIL01;res=B73,TIL18;outgroup=not_present`.
- The findings line under decoy reads: "e0 (the TIL01-like state) fixed at the decoy TIL01's informative class mix,
  1495 RD ... and 4863 RS ... loci ...".

## Engine fingerprint check

- Every `checkpoint.STAGE_MODULES` fingerprint was computed from git-archive snapshots of 12d3e6c and c7ccacd
  (`$S/fp/*.tsv`). All 7 are equal: anchor, blastdb, raw ebbfd97f...; elements a78af75d...; genotype_chunk and
  genotype_pair 52071c27...; mm2_index 28f6fc79....
- `git diff 12d3e6c c7ccacd -- src/ltrpav/constants.py src/ltrpav/checkpoint.py` is empty.
- The analysis fingerprint changed, as expected: paint 0397e094... becomes 6dd78572....

## Suite

- Full suite, detached after both commits (HEAD c7ccacd), at server load about 205 of 256 cores.
  - Launcher: bash PID 2457262, PPID 1, SID 2457262; pytest PID 2457264.
  - Log `$S/suite/suite.log`; exit code in `$S/suite/suite.done`.
  - Result: **exit 0; 1,273 passing tests** (Task 5's 1,261 plus the 12 added here). The log has no F, E, s or x
    mark and, as in Task 5's review, no summary line, so the count is of progress marks. Wall time about 13 minutes.
- `ruff check .`: All checks passed (after each commit).
- Targeted runs before the commits:
  - test_pop_cli + test_popbuild: 44 passed;
  - test_paint + test_cli_analysis + test_overview: 135 passed, exit 0.

## Concerns

1. **The brief's degenerate-test numbers cannot hold as written** (choice 1). The fix keeps every value but
   repeats the pattern on four sequences. The controller may prefer instead to relax 0.99 to 0.98 with the pattern
   once.
2. **"2-Mb tract" on 1-Mb toy sequences** (choice 2).
   - The test's tract is two whole sequences, with no sister-like flanks.
   - Both models fit L at the grid's maximum (5e7) and pi 0.461.
   - With only 2 tracts, q has a floor of 1/2, so the test pins the posterior only, as the brief asks.
3. **The decoy is used twice, and in my toys that favored the target.**
   - Under decoy, every toy null that had target tracts (seeds 12, 14, 15 and 22 of 6-25; seed 5 also) had 0 decoy
     tracts. Under em, the decoy got tracts in some of them (seeds 12, 14, 22).
   - The decoy defines e0, so painted under it, it looks like pure background.
   - The +1 correction kept q at 1 there (1-2 tracts). With many tracts, the asymmetry could push q downward.
   - On main3 the target/decoy tract ratio is similar under both models (389/285 = 1.36 under decoy, 770/599 = 1.29 under em). This is exactly Task
     11's realized-FDR question; I report it as a lead, not a finding.
   - Against it: on sparser toy nulls (n_per_seq 300, seeds 6-25; `$S/sparse_null.log`), decoy called no tract at all,
     target or decoy. em called 14 target and 11 decoy tracts there, none at q <= 0.05.
4. **On main3, anchoring e0 does not stop state 1 being pure RD** (e1[RD] 0.9994). It makes state 0 a mixed
   background: the posteriors become graded (1,299 vs 6 intermediate loci), and tracts fewer and longer.
5. **Collapsed under decoy:** e0 rows are NA (the brief). The fixed e0 then appears only in the findings line, not in
   the rows.
6. **No CLI or report option for emission yet.** `run_paint` uses the defaults; the files outside the brief's list
   were not changed. Task 7 or 11 must wire `emission` (and `discovery`) through report.py and the CLI, and include
   them in the paint stage's params key. Otherwise a non-default painting would be skipped as done.
7. **DESIGN.md is not updated** (not in the file list). DESIGN 7.4, or 12's Plan 3 build decisions, may want one
   line naming the option and its default.
8. **Sim side effects to note:**
   - `--seed` is also bounded for `ltrpav-sim pair`, through the shared `_seed`;
   - params.json gains `indel_in_no_genome` in dropped;
   - Task 8 must give `ltrpav-sim pop` an empty outdir (per the ruling, its run_one clears it).
