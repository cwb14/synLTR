#!/usr/bin/env bash
# Rehearse the exact real command on 6 Mb of each genome, at low thread count, before committing 120 threads.
# Writes state/preflight_ok.<commit> only if ltrquest exits 0 and every expected output is non-empty.
set -euo pipefail
. "$(dirname "$0")/run.env"
activate
D=$PROJECT/preflight_$COMMIT; S=$PROJECT/state; mkdir -p "$S" "$D/in"; cd "$D"
# Lines 20-26 Mb into chr1 (chr1 is the first record). Same labels and prefix scheme as the real inputs.
for spec in B73v5:80 TIL18:60 TIL01:60; do
  l=${spec%:*}; w=${spec#*:}; s=$((20000000/w)); e=$((26000000/w))
  [[ -s in/$l.fa ]] || awk -v id="${l}_chr1" -v s=$s -v e=$e 'NR==1{print ">" id; next} /^>/||NR>e+1{exit} NR>s+1' "$PROJECT/inputs/$l.fa" > in/$l.fa
done
rc=0
ltrquest --genome in/B73v5.fa in/TIL18.fa in/TIL01.fa --proteins "$PROJECT/inputs/B73v5.proteins.fa.gz" \
  --threads 8 "${EXTRA_FLAGS[@]}" > preflight.log 2>&1 || rc=$?
echo "ltrquest rc=$rc"
[[ $rc == 0 ]] || { echo "PREFLIGHT_FAIL rc=$rc"; exit 1; }
miss=0
for f in merged_all_ltr.tsv {B73v5,TIL18,TIL01}_LTRs_depth0_clean_ltr.tsv {B73v5,TIL18,TIL01}_LTRs_all_depth_protein_LTR_cleaned.gff3 {B73v5,TIL18,TIL01}_LTRs_reboundary.tsv; do
  if [[ -s $f ]]; then echo "ok   $f $(wc -l < "$f")"; else echo "MISS $f"; miss=1; fi
done
[[ $miss == 0 ]] || { echo "PREFLIGHT_FAIL missing outputs"; exit 1; }
touch "$S/preflight_ok.$COMMIT"
echo PREFLIGHT_OK
