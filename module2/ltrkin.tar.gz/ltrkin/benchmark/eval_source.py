#!/usr/bin/env python3
"""Score `ltrkin source` against a simulated genealogy (sim_source.py).

For each truly new copy with an assigned source, the relation of the source to the new copy in the true genealogy:
parent, ancestor (grandparent or older), sibling (same parent), other (more distant: cousin etc.), descendant.
Weighted by tie weight. Stratified by the true parent's state (alive and fixed / alive and new / lost) and by the
assignment's divergence. Also: precision of the 'source older' and 'closer non-fixed relative' flags, shared derived
mutations for parent vs non-parent assignments, and the locality null (copies are placed at random: O/E ~ 1).
Usage: eval_source.py --sim DIR --prefix LTRKIN_SOURCE_PREFIX [-o out.tsv]
"""
import argparse

import numpy as np
import pandas as pd


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sim", required=True)
    ap.add_argument("--prefix", required=True)
    ap.add_argument("-o", "--out", default=None)
    a = ap.parse_args()
    G = pd.read_csv(f"{a.sim}/genealogy.tsv", sep="\t").set_index("copy_id")
    T = pd.read_csv(f"{a.sim}/truth.tsv", sep="\t").set_index("element_id")
    S = pd.read_csv(f"{a.prefix}.sources.tsv", sep="\t")
    par = G.parent.to_dict()

    def ancestors(x):
        out = []
        while par.get(x, ".") != ".":
            x = par[x]
            out.append(x)
        return out

    def relation(n, s):
        p = par.get(n, ".")
        if s == p:
            return "parent"
        an = ancestors(n)
        if s in an:
            return "ancestor"
        if n in ancestors(s):
            return "descendant"
        if par.get(s, ".") == p and p != ".":
            return "sibling"
        return "other"

    S["relation"] = [relation(n, s) for n, s in zip(S.new_id, S.source_id)]
    S["parent_state"] = [("lost" if not G.at[par[n], "alive"] else T.at[par[n], "status"]) if par.get(n, ".") != "."
                         else "none" for n in S.new_id]
    S["div_bin"] = pd.cut(S.divergence, [-1, 0.001, 0.002, 0.005, 0.01, 1], labels=["<=0.1%", "0.1-0.2%", "0.2-0.5%", "0.5-1%", ">1%"])
    w = S.groupby(["parent_state", "relation"]).weight.sum().unstack(fill_value=0)
    lines = ["# source assignment vs truth (weights of tied candidates; one unit per new copy)",
             f"new copies with an assigned source: {S.new_id.nunique()} of {(T.status == 'new').sum()} truly new",
             "\nby true parent state (rows) and relation of the assigned source (columns):", w.round(1).to_string()]
    tot = w.sum(1)
    lines.append("\nfraction exact parent: " + ", ".join(f"{k} {w.loc[k].get('parent', 0) / tot[k]:.3f} (n {tot[k]:.0f})" for k in w.index))
    lines.append("fraction parent or ancestor (lineage): " + ", ".join(
        f"{k} {(w.loc[k].get('parent', 0) + w.loc[k].get('ancestor', 0)) / tot[k]:.3f}" for k in w.index))
    fx = S[S.parent_state == "fixed"]
    wd = fx.groupby(["div_bin", "relation"], observed=False).weight.sum().unstack(fill_value=0)
    lines += ["\nparent alive and fixed: relation by divergence of the assignment:", wd.round(1).to_string()]
    lines.append("\ntied candidates contain the parent (parent fixed): "
                 f"{fx.groupby('new_id').apply(lambda d: (d.relation == 'parent').any()).mean():.3f}")
    S["is_parent"] = S.relation == "parent"
    S["closer"] = S["flags"].str.contains("closer_nonfixed")
    lines.append("\nflag closer_nonfixed_relative: P(flag | parent not fixed) "
                 f"{S[S.parent_state != 'fixed'].groupby('new_id').closer.any().mean():.3f}; "
                 f"P(flag | parent fixed) {S[S.parent_state == 'fixed'].groupby('new_id').closer.any().mean():.3f}")
    for lab, d in (("assigned = parent", S[S.is_parent]), ("assigned != parent", S[~S.is_parent])):
        lines.append(f"{lab}: n {len(d)}; source_older {d.source_older.mean():.3f}; shared_derived>0 "
                     f"{(d.shared_derived > 0).mean():.3f}; source_private median {d.source_private.median()}")
    loc = pd.read_csv(f"{a.prefix}.locality.tsv", sep="\t")
    lines += ["\nlocality (random placement: expect obs/exp ~ 1):",
              loc[loc.level == "clade"][["max_divergence", "n_new", "same", "expected", "obs_exp", "p"]].to_string(index=False)]
    txt = "\n".join(lines)
    print(txt)
    if a.out:
        open(a.out, "w").write(txt + "\n")
        S.to_csv(a.out.replace(".txt", "") + ".pairs.tsv", sep="\t", index=False)


if __name__ == "__main__":
    main()
