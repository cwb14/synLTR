#!/usr/bin/env python3
"""Write hap_truth.py truth as an ltrkin genotypes TSV (the columns `ltrkin source` reads), so that `source` can be
run on assembly-truth status and compared with a run on ltrkin's own calls.
Truth genotype F/<state>: F, Fx, Fn -> F/F; E -> F/E; S -> F/S; Nd, Nr -> F/N; other states are written as N/N with
GQ 0 (no status). usage: truth_to_genotypes.py truth.tsv sample_name out.tsv [--confirmed]"""
import sys

import pandas as pd

TG = {"F": "F/F", "Fx": "F/F", "Fn": "F/F", "E": "F/E", "S": "F/S", "Nd": "F/N", "Nr": "F/N"}
t = pd.read_csv(sys.argv[1], sep="\t")
conf = "--confirmed" in sys.argv
gt = t.state.map(TG)
ok = gt.notna() & ((t.truth_source == "confirmed") if conf else True)
out = pd.DataFrame(dict(element_id=t.element_id, sample=sys.argv[2], genotype=gt.where(ok, "N/N"),
                        gq=ok.map({True: 99, False: 0}), flags="PASS"))
out.to_csv(sys.argv[3], sep="\t", index=False)
print(out.genotype.value_counts().to_dict(), file=sys.stderr)
