#!/usr/bin/env python3
"""Validate a finished LTRquest multi-genome run and summarize its clean tables.

Checks coordinates against the assembly .fai, ID uniqueness, and the seq_len field;
then reports per-genome counts, superfamilies, ages, TSDs and family sharing.
Usage: python3 -I 07_qc_summary.py --run run/ --genome LABEL=asm.fa.gz.fai [...]
"""
import argparse
import collections
import glob
import os
import re
import statistics as st
import sys

ID = re.compile(r"^(?P<chrom>.+):(?P<start>\d+)-(?P<end>\d+)#(?P<cls>.+)$")


def read_fai(path, label):
    with open(path) as fh:
        return {f"{label}_{row.split()[0]}": int(row.split()[1]) for row in fh}


def scan_genome(run_dir, label, sizes):
    """Stream one genome's depth tables; return its summary and its family set."""
    n_depth = collections.Counter()
    sup = collections.Counter()
    conf = collections.Counter()
    k2p, lengths, seen, families = [], [], set(), set()
    tsd = bases = bad_coord = bad_len = dupes = malformed = 0
    paths = sorted(glob.glob(f"{run_dir}/{label}_LTRs_depth*_clean_ltr.tsv"),
                   key=lambda p: int(re.search(r"depth(\d+)_", p).group(1)))
    if not paths:
        sys.exit(f"ERROR: no clean depth tables for {label} in {run_dir}")
    for path in paths:
        depth = int(re.search(r"depth(\d+)_", path).group(1))
        with open(path) as fh:
            col = {name.lstrip("#"): i for i, name in enumerate(fh.readline().rstrip("\n").split("\t"))}
            for line in fh:
                f = line.rstrip("\n").split("\t")
                m = ID.match(f[col["seq_id"]])
                if not m:
                    malformed += 1
                    continue
                chrom, start, end = m["chrom"], int(m["start"]), int(m["end"])
                key = (chrom, start, end)
                dupes += key in seen
                seen.add(key)
                if chrom not in sizes or start < 1 or end > sizes[chrom] or start >= end:
                    bad_coord += 1
                span = int(f[col["seq_len"]])
                bad_len += span != end - start + 1
                n_depth[depth] += 1
                parts = m["cls"].split("/")
                sup[parts[1] if len(parts) > 1 else parts[0]] += 1
                conf[f[col["confidence"]]] += 1
                tsd += f[col["tsd"]] not in ("NA", "", ".")
                lengths.append(span)
                bases += span
                if f[col["k2p"]] not in ("NA", ""):
                    k2p.append(float(f[col["k2p"]]))
                if f[col["family"]] not in ("NA", "", "."):
                    families.add(f[col["family"]])
    total = sum(n_depth.values())
    genome_bp = sum(sizes.values())
    return {
        "label": label, "elements": total, "per_Mb": total / (genome_bp / 1e6),
        "span_Gb_with_nesting_overlap": bases / 1e9, "depths": dict(sorted(n_depth.items())),
        "superfamilies": dict(sup.most_common(5)), "confidence": dict(conf.most_common()),
        "with_TSD_frac": tsd / total, "median_len": st.median(lengths),
        "median_k2p": st.median(k2p), "families": len(families),
        "problems": {"bad_coord": bad_coord, "bad_seq_len": bad_len, "duplicate_loci": dupes,
                     "malformed_id": malformed},
    }, families


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--run", required=True, help="finished run directory")
    ap.add_argument("--genome", nargs="+", required=True, metavar="LABEL=FAI",
                    help="genome label and its original .fai")
    args = ap.parse_args()
    fam_by_genome = {}
    for spec in args.genome:
        label, fai = spec.split("=", 1)
        if not os.path.exists(fai):
            sys.exit(f"ERROR: missing .fai: {fai}")
        summary, fams = scan_genome(args.run, label, read_fai(fai, label))
        fam_by_genome[label] = fams
        for key, value in summary.items():
            print(f"{label}\t{key}\t{value:.4g}" if isinstance(value, float) else f"{label}\t{key}\t{value}")
    labels = list(fam_by_genome)
    everything = set().union(*fam_by_genome.values())
    print(f"families\tany_genome\t{len(everything)}")
    print(f"families\tall_{len(labels)}_genomes\t{len(set.intersection(*fam_by_genome.values()))}")
    for label in labels:
        others = set().union(*(fam_by_genome[o] for o in labels if o != label))
        print(f"families\tprivate_to_{label}\t{len(fam_by_genome[label] - others)}")


if __name__ == "__main__":
    main()
