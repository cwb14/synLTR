# Plan 2: final whole-branch review (12279a1..4b73977)

Reviewer: final-wave reviewer. Date: 2026-11-12. Branch `plan2-analyses`: 35 commits, 36 files, +12,911 lines.

Scope and method. I reviewed the range in passes:
1. The engine boundary: `cli.py`, `checkpoint.py`, `loci.py`, pyproject, the env and lock files.
2. The analysis modules: catalog, stats, relations, trio, inversions, paint, direction, mechanisms and identity.
3. `report.py` and `analysis/cli.py`.
4. `plot/overview.py`, all 2,950 lines.
5. The tests.
6. The real run in `benchmark_pav/main3_analyses/`.
7. Targeted probes, kept in `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p2final/probes/`.

I checked the code against DESIGN sections 6-8, 10 and 12, the plan's Global Constraints and Review Focus, every "Ruling:" line in the ledger, the making-figures skill, and the user's science rules. I did not run the suite. I rely on the ledger's `-W error` runs (1,121 passed at 2c2e639). The commits after 2c2e639 touch only DESIGN.md.

Independent checks run for this review:
- **Engine stage keys.** I computed every `checkpoint.STAGE_MODULES` fingerprint at 12279a1 (a worktree, since removed) and at 4b73977. All seven stages are byte-identical, and so are their module sets.
- **D_pav from raw files.** I recounted main3 from `loci.tsv` and TIL18's pair files, without ltrpav code: 14,067 counted loci, n_RD 1,317, n_SD 724, D +0.2905. The age bins also match: K=0 32/8, 0<K<0.01 320/77, K>=0.01 965/639.
- **KKSC and the outgroup filter.** The same raw recount gives KKSC 2,763 / 1,495 and the filter's 99,549 of 123,019 (0.809). Each equals `stats.tsv`.
- **Import isolation.** `ltrpav.cli`, `ltrpav.analysis.cli`, `.catalog`, `.stats` and `.report` all import with scipy and matplotlib blocked.
- **Probes.** Six probes drove the commands on toy runs (the test suite's own writers):
  1. `--trio` roles with D_pav < 0;
  2. a genotype-only sister;
  3. a genotype-only recipient;
  4. `ltrpav-paint`, then `ltrpav-plot`, with no stats stage;
  5. six ingroup genomes;
  6. nine ingroup genomes.

## Strengths

- **Engine isolation holds exactly.**
  - Plan 2 edits only three engine files: docstrings in `checkpoint.py` and `loci.py`, which are in no engine stage set, and the one ruled hook in `cli.py`.
  - Engine keys are unchanged (verified above).
  - Analysis keys use `analysis_fingerprint(stage)`.
  - No analysis command runs `_check_pair_files` or a stage fingerprint.
  - scipy and matplotlib load inside the stage functions only.
- **Discovery discipline.**
  - `relations.discover` is the one discovery function. Every rule-bound statistic reads the discoverer's own calls (`pcls_by`).
  - Merged states appear only in the uses the plan declares `disc=any`.
  - Missing states never count as absent in any sharing count, class or event I traced: catalog `_CLS`, trio, paint `classes`, direction, Dollo, overview panel B and the no-trio panel.
  - Every `StatRow` declares its loci, and each test carries resolution rows.
- **Testability guards are principled and consistent.**
  - `_why` and `_guard` (trio.py:121-142) cover an empty compared class, fewer than 3 blocks, non-varying pseudovalues and an undefined estimate.
  - The same rule serves D_pav, its strata, dD, f, D_young, the split se, D_dir and DFOIL.
  - A NaN Z is never read as a verdict, in findings.txt or in the figure (`_direction`, overview.py:2016).
- **Staleness machinery.**
  - Every stage writes its marker last, and every writer is atomic.
  - `stale_parts` recomputes each part's key from the options its marker recorded and names why a part is stale.
  - Exit 3 keeps the genotyping outputs.
  - The plot stage's `probe_tools=False` ruling is sound: drawing never runs LASTZ.
- **Real-data honesty.**
  - findings.txt brackets the derived share of absences and never measures it.
  - A collapsed painting fit is reported as NA, not as pseudocount numbers.
  - The KKSC p is labeled anti-conservative.
  - Every PASS and MISS in `prelim_papers.tsv` carries "(prelim)": 19 PASS, 5 MISS.
  - PRELIM.md withdraws its refuted dilution mechanism and states the missing null.
- **Tests.**
  - The toys are written through Plan 1's own writers and merge, so they hold only engine-possible states.
  - Expected values are exact.
  - The ledger records seeded null checks, port-fidelity checks against LTRmix and mutant-killing tests.
  - The one slow test is marked.
- **The rulings I examined are sound.** They do not tune to known answers, and each rests on how the engine defines its outputs:
  - Task 3: the conflict bound from discoverers' calls.
  - Task 4: not testable, and the discovering second donor.
  - Task 5: the seed change rejected.
  - Task 6: the faithful EM port kept on real data.
  - Task 8: the shown-remnant classes.
  - Task 9: padding and the call's b_strand.
  - Task 10: exit 3.
  - Task 11: the plot's currency check.
  - Decision 11: the four-point fallback.

## Issues by severity

### Critical

**C1. The inversion caller reports chromosome-scale artifacts as inversions.**
- *Where:* inversions.py:121-144, `_find` 70-103. Deferred from Task 11; still applies.
- *Cause:*
  - Loci are grouped by every (x sequence, y sequence) pair, including pairs between non-homologous sequences that hold a handful of misplaced loci.
  - In such a group the "dominant direction" is noise.
  - Any 5 reversed loci with distinct y form a block, however sparse.
- *Effect on main3:*
  - 28 of 523 blocks span more than 1 Mb per locus, and 27 of those lie between differently numbered chromosomes.
  - They make up 1.22 Gb of TIL18~TIL01's reported 1.69 Gb `bp_inverted_x`, in stats.tsv, and 756 of TIL01~Zd's 945 Mb.
  - findings.txt lists them as the "largest" block of four of the six pairs (B73~Zd, TIL18~TIL01, TIL18~Zd, TIL01~Zd). For example, "B73 B73v5_chr3:83459-236926295 (7 loci, 0 discordant)" against Zd_chr6:0.23-1.43 Mb, and "TIL18_chr4:11.5-227.3 Mb (7 loci)" against TIL01_chr2.
- *Why it matters:*
  - inversions.tsv and its rows are DESIGN 7.7 results, with DESIGN 10.3 bars (Inv4m, Inv1n).
  - On normal input they are dominated by forced calls on weak evidence, an anti-goal in DESIGN 2.
- *What it does not affect:* the painting's `inv` flags inherit the noise (31,473 TIL01 decoy loci flagged, Task 11), but no admixture statistic reads them, and panel A draws only blocks with at least one locus per display bin.
- *Fix needed:* a principled rule, not a tuned density. Two candidates:
  - keep only each x sequence's dominant syntenic partner(s), as `overview._partners` already defines them;
  - require a block to be contiguous on both genomes, with no other group locus inside its y extent.
  - Then rerun PRELIM item 10.

### Important

**I1. The age-gradient verdict ignores D_pav's sign.**
- *Where:* trio.py:473-480; overview.py:2614-2616.
- *What goes wrong:*
  - Under `--trio` roles where S, not R, carries the donor-shared excess (D_pav < 0), a young-concentrated excess gives dD < 0.
  - findings.txt then says "significant at |Z| >= 3, toward older insertions: not the age signature of gene flow".
  - The long legend of panel F says "Youngest minus oldest: -0.60 (Z -67.8): concentrated in old insertions".
  - Both are backwards: the excess, S's, sits in young insertions, which is the gene-flow signature, for gene flow into S.
- *Reproduced end to end:* `probes/probe_gradient.py`, with `ltrpav-stats`, `ltrpav-paint` and `ltrpav-plot` using `--trio R,S,D`. The results:
  - D_pav -0.23, Z -55;
  - D(K=0) -0.60 (40/160), against D(K>=0.01) 0.00 (160/160).
- *Reach:* `--trio` is a documented option, and DESIGN 10.3-10.4 call for fixed roles: the negative control, and TIL25 as donor. Roles from the data are safe, since D_pav >= 0 there.
- *Fix:* read the gradient in the direction of the overall excess (sign(D)·dD), or name whose excess it is, in both places. Add a test with D < 0 and a testable gradient.

**I2. `ltrpav-plot` draws a false "no trio" figure when the stats stage never ran, or failed.**
- *Where:* report.py:232-237, 390-408 and 480-481; analysis/cli.py:184-186.
- *Cause:*
  - A stage without a marker is invisible to `stale_parts`.
  - `assemble` leaves its part out without a WARNING.
  - So `left_out_parts` finds nothing, and the plot only checks that stats.tsv exists.
- *Reproduced:* `probes/probe_paint_only.py`. On a fresh run, `ltrpav-paint` then `ltrpav-plot` both exit 0. The legend reads: "With fewer than three ingroup genomes (R, S, D) there is no trio, so no donor-sharing test or painting ... 3 of them ingroup: fewer than the three a trio needs". That is false, self-contradictory, and drawn beside an existing painting.
- *Other route:* a stats rerun that fails or is interrupted gives the same result. Its marker is cleared first, and the failure path reassembles without the part.
- *Spec:* DESIGN 6 promises that "a `stats.tsv` assembled without a part is refused too".
- *Fix:* refuse to draw unless the stats part is finished and present in stats.tsv itself. One way: each part writes a sentinel row that the plot checks. The same fix closes the deferred findings.txt fail-open.

**I3. Panel H does not scale to DESIGN's v1 run sizes.**
- *Where:* overview.py:1890-1911, width at 1895, titles at 1905.
- *What goes wrong:*
  - One small multiple per trio, side by side, at (180 - 17 - 2(n - 1)) / n mm each.
  - Six ingroup genomes, the DESIGN 10.4 six-genome benchmark (20 trios), give 6 mm per trio. Trio labels collide into one unreadable string, and the last multiple is clipped at the right edge (`probes/trios6_panelH.png`).
  - Nine ingroup genomes (84 trios), within "up to ~10 genomes per run", give a negative width. `ltrpav-plot` exits 1 with "error: Width and height specified must be non-negative" (`probes/probe_many_trios.py`).
- *Under `ltrpav run`:* this is only a WARNING. No figure is drawn, and the previous overview stays in place (see M3).
- *Fix:* stack the multiples in a grid of rows, or show the lead trio plus a compact all-trios forest with one row per trio. Test with 6 and 9 ingroup genomes.

**I4. The headline states "gene flow ..., not incomplete lineage sorting" on an uncalibrated test.**
- *Where:* overview.py:2214. Deferred from Task 12; still applies, and shows in main3's short legend.
- *Why it overclaims:*
  - D_pav's null under lineage sorting, and under unequal resolution or annotation, is not yet simulated. DESIGN 10.2's bar, |Z| > 3 in at most 5% of null runs, is Plan 3.
  - DESIGN's own Plan 2 outcome calls every result preliminary.
  - The controller ruled the wording "consistent with gene flow ... rather than incomplete lineage sorting alone".
- *Why Important:* it is the first sentence a reader sees, on the default path of every run.

### Minor

**Wrong text on generality paths:**
- **M1. Legend text that fails a genotype-only sister or recipient.** Probe `probes/probe_unannotated.py`.
  - *Genotype-only sister* (no decoy):
    - the long legend of panel A says the HMM was "fitted on R and applied unchanged to S" and that tracts are "black when q ≤ 0.05 against the decoy", though no decoy exists (overview.py:2309, 2312);
    - a collapsed painting fit is never mentioned in the figure.
  - *Genotype-only recipient*:
    - panel A says S is "painted the same way as a control", though nothing was painted;
    - panel E's legend reads "colored as in panels A and A" (overview.py:2542: `self.L.get('B', self.L['A'])`).
- **M5. The headline drops caveats that bear on its verdict.**
  - With several trios, the lead trio is the largest |Z| of n trios (`_lead`, overview.py:308-322), and the headline gives its verdict without noting that selection.
  - An ambiguous sister pair (p_top >= 0.05) is only counted among "further warnings" (overview.py `warnings`). The verdict depends on the topology.
- **M6. Hard-coded "chromosomes".** The short legend says "R's chromosomes" and "chromosome pairs" for whatever sequences are drawn, scaffolds included (overview.py:2268, 2685).

**Stale or lost files:**
- **M2. The paint stage can read a stale identity.tsv.**
  - *Where:* report.py:372-373.
  - *Route:* after the run changes, rerun `ltrpav-paint` alone, without `ltrpav-stats`.
  - *Cause:* paint reads identity.tsv whenever it exists, and its key includes only that file's checksum.
  - *Effect:* lids are renumbered by position (loci.py:32), so `youngest_u95` in `tracts.<R>.bed` and its Dating line come from other loci. The stats part's WARNING does not say that identity.tsv, inversions.tsv and mechanisms.tsv are stale too.
  - *Duration:* it lasts until stats reruns.
- **M3. A refused or failed plot stage leaves the previous figure in place.**
  - `clear_done` removes only the marker (checkpoint.py:216-222), so overview.png, overview.pdf and overview_numbers.tsv from an earlier run remain.
  - Under `ltrpav run` a figure failure is a WARNING with exit 0, so the outdir can show a stale figure beside current results. Delete the plot outputs before drawing.
- **M4. `write_paintings` deletes by glob.**
  - *Where:* paint.py:500-502. It deletes every `tracts.*.bed`, `posterior.*.tsv`, `decoy_tracts.*.bed` and `decoy_posterior.*.tsv` in the run directory.
  - A genome labeled `tracts` or `decoy_tracts` loses the engine's `<label>.pav.bed`, and a user's own matching file is deleted.
  - Delete only files named for the run's labels, or those listed in the previous paint marker.
- **M8. Resuming without `--identity` throws away the identity layer.** Resuming `ltrpav run` without `--identity` reruns stats and deletes identity.tsv, about 20 minutes of LASTZ on main3 (report.py:358-360). Only a findings line says so. Warn in the log, naming what is deleted.

**Code:**
- **M7. Direction blocks mix coordinate systems.**
  - *Where:* direction.py:183-191, 216, 265-272.
  - *What happens:* the jackknife blocks fall back to another genome's coordinates, but block ids carry no genome, so a fallback row can share a block id with unrelated loci.
  - *Impact:* exploratory, and skipped on main3.

**Tests:**
- **M9. Test gaps.**
  - `test_cli_imports_without_scipy` is gated on lastz (test_cli_analysis.py:101), though its import half needs none. So the Global Constraint's import check never runs where LASTZ is absent, as in the current CI.
  - The legend-honesty tests skip without pdftotext.
  - No test covers:
    - D < 0 with a testable gradient (I1);
    - a plot after markerless stats (I2);
    - more than four trios (I3).

**Deferred items** (each re-checked; all still apply):
- **M10. The short legend gives thresholds and test statistics.** "none of B73's reach q ≤ 0.05" (overview.py:2316) and "D +0.60 at K = 0 against +0.20 at K ≥ 0.01" (overview.py:2631). The making-figures skill bars both.
- **M11. The last line names a module, not a script path.** "Script: ltrpav.plot.overview" (overview.py:2785).
- **M12. The PNG is not byte-deterministic.** `fm.findSystemFonts()` is unsorted (overview.py:204), and this host has two LiberationSans-Regular.ttf files. The env and lock provide no Liberation font, so elsewhere the figure falls back to DejaVu, against the skill's font rule. Register sorted paths, and add a Liberation font package to the env.
- **M13. The left-out guard reads findings.txt and fails open.** A deleted or edited findings.txt lets the plot draw without a part (report.py:253-267, 399-401).
- **M14. `stale_parts` can raise KeyError.** `params["backend_version"]` raises on a hand-edited marker (report.py:285-286). Use `.get`.
- **M15. Task 2 statistics-core leftovers.**
  - `read_stats` coerces "12" to an int and 5.0 to 5, and reads "." as NaN (stats.py:158-166). This is benign today: no row writes a bare label as its value.
  - `block_size` raises a bare ValueError with no genomes (stats.py:68). This cannot happen.
  - The jackknife re-evaluates on a NaN estimate (stats.py:87-92).
  - Three rules are untested: fewer than 2 finite pseudovalues, the dropping of non-finite pseudovalues, and u95 with a multi-element n.
- **M16. Modules import each other's private helpers.**
  - trio.py:68 imports relations' `_check_trio` and `_fallback_reasons`.
  - direction.py:36, 38 import `_first_member`, `_fmt`, `_guard` and `_why`.
  - identity.py:99 imports `_blocks`, `_fmt`, `_guard`, `_patterns` and `_why`.

## Recommendations

1. **Fix C1 first, then rerun PRELIM item 10.** Use a synteny or two-genome contiguity rule fixed by principle, not by matching Inv4m or Inv1n. Report the old and new block counts.
2. **Fix I1 to I4 as one figure and findings round.**
   - Make the gradient verdict sign-aware in trio.py and panel F.
   - Make the plot refuse when the stats part is absent from stats.tsv; this also closes M13.
   - Lay out panel H in rows.
   - Use the controller's headline wording.
   - Fold in M1, M3, M5, M6, M10 and M11 while those functions are open.
3. **Add regression tests** for each Important item:
   - `--trio` with D < 0;
   - paint-only, then plot;
   - six and nine ingroup genomes.
   - Ungate the import half of `test_cli_imports_without_scipy`.
4. **Low-cost Minors:**
   - M2: paint uses identity.tsv only when the stats marker is current;
   - M4: delete only the run's own painting files;
   - M12: sorted font registration and a Liberation font in the env;
   - M14: `.get`;
   - M16: a public helper module.
5. **Rerun Task 12's comparisons after the fixes.** Rerun `compare_papers.py` (which also picks up Task 12's N5), then re-render main3's figure so PRELIM quotes the final legend.

## Declined to judge

- **The simulated null and power of D_pav, the painting and direction (DESIGN 10.2).** Plan 3.
- **Whether decision 11's four-point fallback should replace DESIGN 7.1's wider fallback.** It awaits the user's confirmation. I judged only that the ruling is sound.
- **The s gap (0.074% against LTRmix's 0.048%) and the D_pav against D_ins gap.** Open science questions that PRELIM leaves to Plan 3 and 4.
- **A decoy-anchored emission model for painting.** The Task 6 lead, for Plan 3.
- **The engine's states, tiers and the qc_fixed QC that the analyses read.** Plan 1, already reviewed.
- **The internals of compare_papers.py and investigate_misses.py.** They are outside the repo and Task 12's review covered them; I checked only PRELIM's statements against stats.tsv and findings.txt.
- **The CI workflow's environment.** It is pip only, without LASTZ or poppler. CI is Plan 4; the resulting test gap is noted in M9.
- **Italic taxon names in the figure.** A Task 11 ruling: the tool cannot tell taxa from labels.
- **Catalog memory at pangenome scale.** About 24 bytes per locus, per genome, per annotated genome. Scale beyond v1 is DESIGN's v2 goal.
- **Terminal-branch counts of the Dollo placement on merged states.** They are inflated by missingness and annotation depth, but the plan declares them a description.
- **Choices ported from LTRmix by design:**
  - the unweighted delete-one jackknife;
  - `posterior_mean` over all painted loci, including the interpolated ones;
  - the tract rule.
  - (DESIGN 7.3, 7.4: "as LTRmix".)
- **`ltrpav run` exiting 1 after complete genotyping in envs without scipy or matplotlib.** A controller ruling; a `--no-analyses` switch would be a feature request.
- **Concurrent analysis commands writing one outdir.** Not a stated use case.
- **numba `cache=True` on read-only installs.** Plan 4 packaging.
- **The comparison bars, weights and shift counts of Task 12's paper comparison.** Reviewed in Task 12.

## Deferred items, re-checked

| Item (source) | Still applies? | Severity | Evidence |
|---|---|---|---|
| read_stats coerces "12"→int, 5.0→5, "."→NaN (Task 2) | Yes, stats.py:158-166 | Minor (M15) | No current row writes a bare numeric label as its value; benign today |
| block_size bare ValueError with no genomes (Task 2) | Yes, stats.py:68 | Minor (M15) | Cannot happen: a sheet needs >= 2 genomes |
| jackknife re-evaluates on NaN estimates (Task 2) | Yes, stats.py:87-92 | Minor (M15) | Wasted work; the output is NaN anyway |
| Untested: < 2 finite pseudovalues, non-finite dropping, u95 with an array n (Task 2) | Yes, none in test_stats_core.py; u95 only on length-1 arrays | Minor (M15) | Test gap |
| Private helper imports across modules (Task 4 M6, Task 7) | Yes, trio.py:68, direction.py:36-38, identity.py:99 | Minor (M16) | Maintainability |
| stale_parts KeyError on a hand-edited marker (Task 10 N1) | Yes, report.py:285-286 | Minor (M14) | `params["backend_version"]` |
| Sparse inversion blocks (Task 11, from Task 5) | Yes, inversions.py unchanged | **Critical (C1)** | 28 blocks > 1 Mb per locus (27 between differently numbered chromosomes); 1.22 of TIL18~TIL01's 1.69 Gb; "largest" block of 4 of 6 pairs is a 5-8-locus artifact |
| PNG nondeterminism, two Liberation versions (Task 11) | Yes, overview.py:204 | Minor (M12) | Two LiberationSans-Regular.ttf on this host; no Liberation font in the env |
| Left-out-parts guard reads findings.txt, fails open (Task 11) | Yes, report.py:253-267, 399-401 | Minor (M13) | Its markerless sibling is I2 (Important) |
| Short legend gives thresholds and test statistics (Task 12, line 7) | Yes, overview.py:2316, 2631 | Minor (M10) | Both present in main3's short legend |
| Headline "gene flow ..., not incomplete lineage sorting" (Task 12, line 7) | Yes, overview.py:2214 | **Important (I4)** | Present in main3's short legend |
| Last line names a module, not a script (Task 12, line 7) | Yes, overview.py:2785 | Minor (M11) | "Script: ltrpav.plot.overview" |

## Assessment

**Ready to merge? With fixes.**

The core of Plan 2 is sound:
- The engine is untouched in every key.
- The discovery rules read the discoverer's own calls, and missing states are never absent.
- D_pav, KKSC and the outgroup filter reproduce exactly from the raw files.
- The testability guards, staleness machinery and exit codes do what DESIGN 8 and decisions 12-13 say.
- PRELIM.md stays preliminary throughout.

Five issues should be fixed before merge:
- C1: the inversion caller reports artifacts as the run's largest inversions.
- I1: a sign error in the gradient verdict under fixed roles.
- I2: a false "no trio" figure from a reachable command order.
- I3: a figure that fails at v1 run sizes.
- I4: the overclaiming headline that the controller has already ruled must change.

Each fix is local: inversions.py, trio.py's gradient lines, run_plot's guard, panel H's layout and one legend sentence. None needs redesign. The Minor items can ride along or wait for Plan 3.

## Re-review (fix wave)

Scope: the fix wave 4b73977..3eae543 (18 commits), read once. I judged it against `final-fix-brief.md`'s rulings and the implementer's `final-fix-report.md`, and checked the refreshed main3 view read-only.

Checks run (scratch: `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p2final/`):
- **My four probes, re-run at 3eae543:**
  - `probe_gradient.py`, end to end with `--trio R,S,D`;
  - `probe_paint_only.py`;
  - `probe_many_trios.py` at 6 and 9 ingroup genomes;
  - `probe_unannotated.py`.
- **The inversion search re-run on main3** through a scratch symlink view, `p2final/view` (nothing is written into main3 or the analyses view):
  - `probes/inv_dropped.py`: the runs the contiguity rule drops;
  - `probes/inv_foreign_where.py`: where their "foreign" loci lie;
  - `probes/inv_mutual.py`: whether each dropped run's pair is mutually dominant.
- **Page heights:** `probes/probe_page_height.py`, and `_h_layout` computed with the six benchmark labels.
- **The fix wave's new tests:** run as a focused subset with `-W error`. 15 passed in test_inversions, test_stats_core and test_direction; 28 passed and 1 skipped in test_trio, test_overview, test_cli_analysis and test_paint.

### Verdicts

| Finding | Verdict | Evidence |
|---|---|---|
| C1 inversion artifacts | ADDRESSED | Groups are syntenic partners only (`inversions.syntenic_pairs`, shared with `overview._partners`). main3 now has 402 blocks, none over 1 Mb per locus (28 before). The largest block of every pair is dense. TIL18~TIL01 falls from 1,687 to 246 Mb. Inv4m and Inv1n are unchanged. Tests have exact expected blocks. The extra contiguity rule introduces N1 (below). |
| I1 gradient sign | ADDRESSED | Probe, `--trio R,S,D` (D_pav -0.231, dD -0.60). findings.txt: "read in the direction of the excess, S's ...: that excess is concentrated in young insertions, consistent with gene flow ... into S". Panel F: "read in the direction of the excess, S's: concentrated in young insertions". The headline names S's young excess. main3's Dating line reads B73's excess correctly. |
| I2 false no-trio figure | ADDRESSED | Probe, paint then plot: exit 1, "the stats part: its stage has not finished ...". No overview file is left. main3's stats.tsv holds the two sentinel rows (stats, paint) under their marker keys. |
| I3 panel H scale | ADDRESSED, residual N2 | 6 genomes (20 trios) and 9 genomes (84 trios) render with exit 0. Full-resolution crops show one row per trio, sorted, no label collision and nothing clipped. Page size is N2 (Q3). |
| I4 headline overclaim | ADDRESSED | main3's short legend: "consistent with gene flow from TIL18-like donors into B73 rather than incomplete lineage sorting alone". |
| M1 genotype-only texts | ADDRESSED | Probe. Genotype-only sister: "fitted on R", "with no decoy painting ..., no tract has a q-value", and the collapsed fit said in both legends. Genotype-only recipient: "nothing is painted", "R has no annotation ...". Panel E reads "panel A". |
| M2 stale identity.tsv | ADDRESSED | `identity_usable` (stats part finished and current) gates the read, and the paint key follows it. The stale side files are named. A test covers it. |
| M3 stale figure stays | ADDRESSED | `run_plot` deletes the figure files before checking and again on failure. The paint-only probe left none. |
| M4 glob deletion | ADDRESSED | Only label-named painting files and those the last marker listed. A test uses a genome labeled `tracts`. |
| M5 headline caveats | ADDRESSED | "the strongest of the run's n trios" or "named by the user". The uncertain-sister sentence appears (genotype-only-sister probe: "R and S share 144 insertions, R and D 120, a difference within chance"). |
| M6 "chromosomes" | PARTLY | See Q4: the size rule still calls large unplaced and alt scaffolds chromosomes. |
| M7 direction block ids | ADDRESSED | `coord_blocks` keys rows by (genome, sequence, bin). |
| M8 silent identity.tsv deletion | ADDRESSED | One WARNING names the file and the `--identity` fix. |
| M9 test gaps | ADDRESSED | The import half runs without LASTZ. Legend tests read the generator's text without pdftotext. The I1-I3 tests exist. |
| M10 short-legend statistics | ADDRESSED | main3's short legend has no q, Z, D or threshold. Panel A: "none of B73's stands out from the control's tracts". |
| M11 script path | ADDRESSED | The last line gives `/data2/chris/maize_introgression/LTRpav/src/ltrpav/plot/overview.py`. |
| M12 PNG nondeterminism | ADDRESSED | Fonts are registered sorted, newest version first. A byte-identical test runs two hash seeds. Conda-forge has no Liberation font package, so a fallback gives one WARNING, noted in DESIGN 6. |
| M13 findings.txt guard | ADDRESSED | `plot_refusals` reads only markers and stats.tsv's sentinels. |
| M14 KeyError | ADDRESSED | `.get`; a hand-edited marker reads as stale. Tested. |
| M15 statistics core | ADDRESSED as ruled (in part) | A NaN estimate now short-circuits. The three missing tests are added. The coercion and the unreachable error are documented, not changed. |
| M16 private helpers | ADDRESSED | `analysis/common.py`, module-qualified calls. The fingerprint closure test is green. |

### The coordinator's questions

**1. `INV_FOREIGN_MAX = 1.0`: principled, or tuned to main3? Can it drop a real inversion?**

The rule is principled in intent, and its value is not tuned:
- An inverted segment is one stretch of each genome. "Fewer loci placed elsewhere than its own" is a majority rule. It parallels the merge rule's tolerance (an interruption shorter than what it interrupts) and is not fitted to anything.
- The toy that motivates it (a scaffold spread along a chromosome) is real.

But yes, it drops real inversions, many of them on main3. It counts as "foreign" any locus in the block's extent placed on another sequence, including a second copy of the same region in the other assembly (an alt haplotig or duplicated scaffold), and that copy is itself a syntenic partner of the same sequence. See N1.

**2. C1's stated cost (an inversion inside a translocated piece that is the minor share of both sequences is missed).**
- **Acceptable, as far as it goes.**
  - It is narrow: a piece that is a minority of both its sequences.
  - It follows from defining homology by reciprocal dominance.
  - It is pinned by `test_reciprocal_translocation_keeps_both_partners` and stated in DESIGN 7.7, the module docstring and findings.txt.
  - Transpositions of that kind are also rare, and the engine's syntenic net already treats short ones as paralogs.
- **But the stated cost is incomplete.** The contiguity rule's own cost (N1) is larger on main3 and is stated nowhere: DESIGN 7.7, findings.txt and PRELIM.md item 10 and section 5 give only a count of dropped runs.

**3. I3's page height at 20 trios: within ~240 mm? No.**
- Panel H at 20 trios with the six benchmark labels is 2 columns of 10 rows, 38.0 mm tall (`_h_layout`).
- Added to main3's own layout (A with 10 chromosomes, then B, C, D and E-G: 220.6 mm, measured from overview.png) plus one 5-mm gap, the page is about 264 mm.
- That is beyond the skill's ~240 mm. Its 180:264 shape (0.68) is also narrower than the skill's 3:4.
- My six-genome toy page is 209 mm only because it lacks the base-pair panel C and has smaller panels.
- At 84 trios panel H is 56 mm (about 282 mm in a main3-like page); at 120 trios, 74 mm (about 300 mm), as the implementer reported. This is N2 (Minor).

**4. M6's "chromosome-scale by the drawing rule". It does call large unplaced scaffolds chromosomes.**
- On the four main3 assemblies, sequences of at least 2% of the longest are:
  - B73: 10, all chromosomes;
  - TIL18: 11, including TIL18_alt-scaf_20 (13 Mb);
  - TIL01: 14, including TIL01_alt-scaf_19 (17 Mb), scaf_20 (14 Mb), scaf_21 (9 Mb) and scaf_22 (6 Mb);
  - Zd: 18, including 8 alt scaffolds of 6-20 Mb.
- Each count is at most 24, so with TIL01 or TIL18 as recipient (Plan 3's six-genome trios include such roles) the legend would say "TIL01's chromosomes" above rows labeled "TIL01 scaf_20".
- The rule is the brief's own wording, implemented faithfully. On the merits the word is still wrong whenever a large scaffold is drawn, hence PARTLY (Minor).
- Remedy: say "chromosomes" only when no drawn sequence is much smaller than the others, or always say "largest sequences". No name check is needed for either.

**5. My probes, re-run.**

All four now behave as they should (I1, I2, I3 and M1 above).
- `probe_gradient`: the findings and legend read S's young excess.
- `probe_paint_only`: refused, exit 1, no figure left.
- `probe_many_trios` 6 and 9: both exit 0 and are readable.
- `probe_unannotated`: no false decoy text; the collapsed fit is said; "panel A"; no None, nan or inf.

### New findings

**N1 (Important, introduced by C1's contiguity rule). `INV_FOREIGN_MAX` drops reversals that three independent genomes confirm.**
- **Where:** inversions.py, `_search`.
- **Scale on main3:** 63 reversed runs are dropped.
  - 39 of them lie on mutually dominant, homologous pairs.
  - 16 have at least 10 loci with at least half of their loci also showing inverted element strands (the pre-wave inversions.tsv's `n_strand`, an independent orientation signal).
- **Clearest case: Zd chr10:49.05-50.82 Mb.**
  - It is reversed against all three ingroup genomes, with matching spans: B73 24 loci (17 strand-confirmed), TIL18 30 (21), TIL01 32 (23).
  - All three blocks were reported before the wave, and all three are dropped now.
  - The "foreign" loci in each ingroup stretch (41-42) lie on Zd_alt-scaf_26 at 4.15-5.91 Mb: the same region's second copy in Zd's assembly. That scaffold is itself a syntenic partner of B73 chr10 (87 loci).
- **The same pattern** recurs at Zd chr1:130.5-135.4 Mb: TIL01 53 loci, 45 strand-confirmed, spans 4.7 against 4.9 Mb, with 127 foreign loci on Zd_alt-scaf_19, a partner holding 636 loci. B73 (12 loci) and TIL18 (11) show it too.
- **Why it matters:**
  - Any assembly that keeps alt haplotigs or duplicated scaffolds (all of PanAnd's here) silently loses its inversions in those regions.
  - The cost is stated nowhere.
  - PRELIM item 10 reports "both found" without it.
- **Fix options:**
  - Option, untested beyond these numbers: on a mutually dominant pair, do not count as foreign the loci placed on another syntenic partner of the same sequence; keep the full count on pairs kept from one side only. The scaffold toy is one-sided, so its artifact is still dropped, while the Zd chr10 and chr1 runs would return. The sparse within-pair runs, such as TIL18 chr2:285.2 Mb against TIL01 chr2:21-299 Mb (ratio 75), have foreign loci on non-partner sequences, so they stay dropped.
  - Add an alt-haplotig toy as the regression test.
  - At the least, state the cost in DESIGN 7.7, findings.txt and PRELIM, and list the dropped runs in a side table.

**N2 (Minor). Panel H pushes the page past the skill's size.**
- A main3-like page reaches about 264 mm at 20 trios, about 282 mm at 84 and about 300 mm at 120 (Q3).
- Nothing is clipped, but the page leaves the skill's ~240 mm and 3:4 bounds.
- Options: give panel H its own figure page in the PDF and its own PNG, or shrink panel A when H is present.

**Residual for M6.** See Q4. Minor.

**Diff inspection:** apart from N1, I found no new breakage in the 18 commits.
- Engine modules are untouched; the implementer verified the seven stage keys.
- The sentinel rows are harmless to readers that select by test name, as compare_papers.py and the overview do.
- `run_stage` reads the old paint marker before clearing it.
- `identity_usable` changes the paint key only when identity.tsv's usability changes.

Cosmetic: in panel H, "no result" rows let the dashed zero line show at the label's edge.

### Re-review verdict

- C1, I1-I4: all ADDRESSED.
- 14 Minor items ADDRESSED, M15 ADDRESSED as ruled (in part), M6 PARTLY.
- New: N1 Important, N2 Minor.

**Approved with one fix before merge: N1.** Either make the contiguity count ignore a second partner copy on mutually dominant pairs, with an alt-haplotig test, or at minimum state the cost and list the dropped runs. Then refresh PRELIM item 10's account. N2 and the M6 residual can wait for Plan 3.
