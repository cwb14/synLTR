# Task 19 report: locus catalog (`loci.py`)

Status: DONE_WITH_CONCERNS (the concerns are interpretations to confirm, not defects)
Commit: `4f18c30 Add locus catalog across genome pairs` (branch plan1-engine; no trailers; existing identity)

## What was implemented

`src/ltrpav/loci.py`, public API: `GenomeState`, `Locus`, `QcRow`,
`build_loci(samples, elements, call_paths, seq_order) -> (list[Locus], list[QcRow])` (ruling 8 signature).

- **Reading (ruling 1).** Each pair file is streamed line by line with `gzip`. A line is split only through
  `b_strand` (`split("\t", 14)`), so the evidence columns are never parsed. The parsed columns are eid, state,
  tier, flags, reason, b_seqid, b_start, b_end and b_strand. Each call is stored in compact per-pair columns
  (`bytearray` and `array`, about 30 bytes per call) indexed by A's element. Flags and reason strings are
  interned as small integers. b_seqid is stored as its fai index from `seq_order`, which also validates it.
- **Linking (ruling 2).** Union-find over integer nodes, one per (genome, eid), with union by size and path
  compression. Each genome keeps its elements' spans per seqid, sorted by start (all levels). A P, S or T call
  is linked by bisect to every B element with reciprocal overlap `>= COV_PRESENT`. The scan is bounded
  exactly: a partner must start within `[qs - (1-f)/f*n, qs + (1-f)*n]`, widened by 1 bp for rounding. So
  each lookup is O(log n + k) and nothing is compared all-against-all. Overlap fractions use division, as
  classify's coverage test does, so 800/1000 = 0.8 passes and 0.79 fails.
- **Members (ruling 3).** `members[g]` is g's first member element, ordered by fai seqid index, start, end,
  then eid. Any others go to `extra[g]`, and `Locus.flags = ["multi_member"]`.
- **States (ruling 4).** A member genome is `P`/`annot` at its first member, with that element's strand and
  k; it gets `annot_conflict` if a member element of another genome calls it E, D or O. Any other genome:
  among the member elements' calls the highest tier wins (high > medium > low > "."). Different states at
  that tier give `U` + `conflict` at that tier. One state gives that state with the site, flags and reason
  of the first top-tier candidate, ordered by sheet then position. No candidate gives `U`, ".", `no_call`.
- **Attributes (ruling 5).** discovery is the member genomes in sheet order. family, superfamily and clade
  are majorities with ties going to the first in sheet then position order. length and ltr_len are medians
  rounded half up. tsd is taken from the first member element.
- **lids (ruling 6).** Loci are sorted by (sheet index of the first genome with coordinates, that genome's
  fai seqid index, start, end, then the first member element's key) and numbered `L0000001`, ... The key is
  unique, so the order is total and input order cannot change lids.
- **QC (ruling 7).** One small function per metric: n_loci, n_conflict, n_multi_member, n_annot_conflict.
  They are registered in `_QC_METRICS`, so Task 21 adds a function and a line.
- **Fail fast.** These raise `ValueError` naming the file and line:
  - a header that is not CALL_COLUMNS, or a short line;
  - a corrupt or truncated gzip (the path is added, which a bare `EOFError` would not give);
  - a call of an element A does not have, an element called twice, or an element with no call;
  - an unknown state, tier or b_strand, or a B seqid not in seq_order;
  - a non-integer B site, a duplicate eid, or an element seqid not in seq_order;
  - a call_paths pair with an unknown genome, a genome against itself, or an unannotated A.

  Ordered pairs missing from call_paths only log a warning; their genomes become `U no_call`.
- **Logging.** Info lines at start, after reading (calls, links, time) and at the end (QC values, time).
  Per-pair counts are at debug level.

## Tests and results

`tests/test_loci.py` has 62 tests. Pair files are real gzip files in the CALL_COLUMNS format, written with
`genotype.tsv_field`; A and B are annotated, C is not, and both use chr1.

- The brief's seven tests:
  - `test_link_and_states`
  - `test_conflict_rules` (8 cases: E/high vs D/high gives U conflict, E/high vs D/medium gives E, G vs U,
    P vs T, same-state ties, a lower tier losing), plus a sheet-order case for the first candidate
  - `test_annotation_conflict` (E, D, O flag it; U, G, T do not)
  - `test_unannotated_genome`
  - `test_shared_seqid_names`
  - `test_lid_deterministic` (3 seeds shuffle element lists, the rows inside every pair file and the
    call_paths order; the output must be identical)
  - `test_qc_counters`
- Extras the task asked for:
  - `test_multi_member`
  - `test_no_call` (also checks the warning)
  - majority family plus a tie in both sheet orders (None never votes)
  - median length and LTR length, odd and even counts (half-up rounding)
  - lid order under two fai orders, including loci sorted by an empty site in A and by B
  - the reciprocal-overlap threshold at 0.79 vs 0.80: element side, call side, shifted both ways, and the
    element starting before or after the call
- Also covered: link states (P, S, T link; E, D, O do not), a different seqid, a nested B element (any
  level links; reciprocal overlap keeps the host out), projected strand, U reason, and 10 input-check tests.

### TDD evidence

- RED 1, before the module existed: `ModuleNotFoundError: No module named 'ltrpav.loci'` at collection.
- RED 2, with an interface-only stub whose `build_loci` raises `NotImplementedError`:
  `58 failed in 0.41s`, every one `NotImplementedError`.
- GREEN after implementing: `58 passed in 0.44s`. The final count is `62 passed in 0.49s` after adding the
  right-bound threshold cases, corrupt file, missing-pair warning and duplicate-element tests.
- Mutation check: I seeded eight bugs and every one fails tests. The number of failing tests per bug:

  | Seeded bug | Failing tests |
  |---|---|
  | strict `> COV_PRESENT` | 3 |
  | conflict detection removed | 5 |
  | lid by first member only | 1 |
  | no strand turn | 3 |
  | annot_conflict on any state | 9 |
  | a tie going to the last candidate | 8 |
  | no left bisect widening | 2 |
  | no right bisect widening | 1 (caught only after adding the two cases where the element starts after the call) |

### Commands and output

```
mamba run -n ltrpav python -m pytest tests/test_loci.py -p no:cacheprovider -o addopts="" -q
  62 passed in 0.49s
mamba run -n ltrpav python -m pytest -p no:cacheprovider -o addopts="--strict-markers" -q -W error
  567 passed in 67.43s (0:01:07)        # 505 before this task + 62; no warnings (-W error)
mamba run -n ltrpav ruff check src tests
  All checks passed!
mamba run -n ltrpav ruff check --select E,F,W,I,B,UP,C4,RUF --line-length 110 src/ltrpav/loci.py tests/test_loci.py
  All checks passed!
```

## Scale check

The data are synthetic. Genomes A, B and C are annotated with 100,118, 100,090 and 99,739 elements; D is not
annotated. Each annotated genome has 3 pairs, so there are 9 pair files with 899,841 calls as full 29-column
rows (28 MB gzip). There are 166,667 truth loci on 10 chromosomes of 300 Mb, each present per genome with
p = 0.6. Calls are P/S/T (image ±30 bp) or U where the locus is present, and E/D/U/G where it is absent.

| Measure | Result |
|---|---|
| `build_loci` time | 10.2 s (reading and setup 4.2 s, assembling loci 6.0 s) |
| Output | 153,619 loci, 350,776 links |
| Peak RSS | 656 MB in total: 340 MB with the inputs loaded, and `build_loci` added 316 MB |
| Python heap | the returned catalog is 241 MB (about 1.6 KB per locus with 4 genomes); transient state peaks at 126 MB (compact calls, union-find, spans, eid maps) |
| Invariants | every element is in exactly one locus, lids are contiguous, and every member state is annot |
| Determinism | shuffled element lists and call_paths order give identical output (`== True`) |

Projection to real scale: 130,000 elements per genome and about 1.6M calls with 4 genomes should take about
20 s and add about 0.6 GB, mostly the returned `Locus`/`GenomeState` objects. Profiling led to two changes:
a plain dict replaced `Counter` in `_majority`, and calls are indexed `calls[A][B]` instead of a dict with
tuple keys. Time went from 11.2 s to 10.2 s.

The scripts are in the session scratchpad (`scale_gen.py <dir>`, `scale_run.py <dir>`, `scale_check.py
<dir>`, `scale_mem.py <dir>`, run with `mamba run -n ltrpav python -I`). The generator is seeded with
`random.Random(19)`.

## Files changed

- `src/ltrpav/loci.py`: new, 519 lines
- `tests/test_loci.py`: new, 445 lines

## Self-review findings (all fixed before the commit)

- No test exercised the right bisect bound. I added two threshold cases where the element starts after the
  call, and the mutation is now caught.
- A truncated pair file raised a bare `EOFError` without a path. It is now a `ValueError` that names the file.
- Hot spots in assembling the loci (`Counter`, tuple-keyed dict lookups and a method call per element per
  genome) were replaced.
- Lines were wrapped to the 110-column convention. I fixed ruff RUF023, C408 and RUF059 under the project
  config, and RUF043 and B905 under a stricter pass.
- Weak error-message matches in the tests were tightened, and an unused helper parameter was removed.

## Concerns: interpretations for the controller to confirm

1. **`GenomeState.reason` was added** as an optional trailing field, default None. Ruling 1 parses `reason`
   but GenomeState had no field for it. It holds the winning call's reason, which explains why a U is
   unresolved. Code that builds a GenomeState with the brief's 8 positional fields still works.
2. **The strand of a non-member genome is turned.** It is the calling element's strand, reversed when
   `b_strand` is "-". `b_strand` is the window's orientation, not the copy's strand, so a raw `b_strand`
   would report the wrong strand for "-" elements. With this choice the field has one meaning in every
   genome ("the element's strand here"), matching members. The raw orientation is still in the `inv` flag.
   If the raw value is wanted, it is a one-line change.
3. **Sites and flags.** `conflict` and `no_call` states have no site; `no_call` has tier ".". When one state
   wins, the flags and reason come from the first top-tier candidate only, not a union of candidates.
4. **"Member elements" means every element in the locus**, extras included. Extras' calls are candidates and
   can raise annot_conflict, and extras vote in the family majority and the medians. The alternative is the
   first member per genome only.
5. **None never votes** in family, superfamily or clade. tsd is the first member element's (sheet, then
   position order) that has one. A literal "first member's tsd" would give None when that member lacks one.
6. **Literal ruling 4 marks two kinds of disagreement as conflict:**
   - P vs T or S at the same top tier becomes `U + conflict`, although all three mean present. Different
     reference copies (length or internal indels) will produce this on real data, and presence is lost.
   - G vs U at tier "." becomes `U + conflict` and inflates n_conflict with disagreements between two
     missing states.

   I did not change either, because the ruling binds. Options: compare collapsed classes (present, E,
   missing) before declaring a conflict, or leave the "." tier out of conflict.
7. **Memory at larger scale.** The output objects dominate memory, and they grow with genomes × loci. At
   26-genome scale the in-memory catalog would be several GB, so a streaming writer may be needed later.
   This is fine for the planned 4-genome runs.
8. **API details:**
   - `GenomeState` and `Locus` use `@dataclass(slots=True)`, about 3× smaller per object. Later tasks must
     declare fields rather than attach attributes ad hoc.
   - QC values are ints (counts), which typing accepts where float is annotated.
   - `seq_order` is a required argument. The caller builds it as
     `{s.label: {n: i for i, n in enumerate(Fasta(s.fasta).lengths())} for s in samples}`.

---

## Fix report: controller ruling on concern 3 (the conflict rule)

Commit: `fb050c2 Count locus conflicts on the collapsed genotype`. The controller accepted concerns 1, 2, 4,
5 and 6 as implemented.

### Ruling implemented

A non-member genome's top-tier candidates (highest tier, high > medium > low > ".") conflict only when they
hold more than one collapsed genotype class (DESIGN 5.4): present P/S/T, absent E, missing D/O/G/U.

- Different classes give `U` at that tier, flag `conflict`, and no site, as before.
- One class gives its most frequent state. Ties go by P > S > T or D > O > G > U.
- The site, flags and reason come from the first candidate of the chosen state, in sheet-genome then
  start order. Before, they came from the first candidate overall.

### Changes

- `src/ltrpav/loci.py`:
  - New constants `_CLASSES`, `_CLASS` (state -> class) and `_PRIORITY` (tie order within a class).
  - `_state` now collects the top-tier candidates, declares a conflict only across classes, and otherwise
    takes the most frequent state at its first candidate.
  - The module docstring, the `_state` docstring and the `_n_conflict` docstring are updated.
- `tests/test_loci.py`:
  - `test_conflict_rules` now has 14 cases. The four the ruling asked for:
    - P vs T at the same tier gives P, no conflict;
    - G vs U at tier "." gives G, no conflict (also tested with the order reversed);
    - P vs E gives U + conflict;
    - E vs D gives U + conflict.
  - Also added: T vs D gives a conflict; S > T; D > O; T then P takes the site of the first P candidate.
  - New `test_most_frequent_state` with three members across A, B and D (TTP gives T; PTT gives T at the
    first T; DOO gives O): frequency comes before the tie order.

### Tests

- `tests/test_loci.py`: `71 passed in 0.47s`.
- Full suite, run once: `576 passed in 67.37s` with `-W error`. That is 567 before plus the 9 new
  parametrized cases.
- Ruff, project config and the stricter pass at 110 columns: `All checks passed!`

Mutation check. Each variant was restored afterwards:

| Variant | Failing tests |
|---|---|
| The old rule (any state difference conflicts) | 9: the 6 single-class cases and the 3 frequency cases |
| Tie order only, no frequency | 3: the frequency cases |
| Site from the first candidate overall | 5 |

Commands:

```
mamba run -n ltrpav python -m pytest tests/test_loci.py -p no:cacheprovider -o addopts="" -q
mamba run -n ltrpav python -m pytest -p no:cacheprovider -o addopts="--strict-markers" -q -W error
mamba run -n ltrpav ruff check src tests
```

### Scale re-run

Same synthetic data: 300k elements, 900k calls.

- n_conflict fell from 11,960 to 6,183, because P/S/T and G/U mixes no longer count.
- Time was 11.4 s (10.2 s before; the extra cost is collecting the top-tier candidates, plus server noise).
- Peak RSS was unchanged; build_loci still adds 317 MB.
- Every element is still in exactly one locus, and shuffled inputs still give identical output.
