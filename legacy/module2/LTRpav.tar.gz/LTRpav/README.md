# LTRpav

LTRpav calls every annotated LTR retrotransposon insertion present or absent in each genome assembly you give it, and it checks each call in the assembly itself: an insertion counts as absent only where the empty target site, with a single copy of its target-site duplication, is seen. It then tests for gene flow with the insertions a donor genome carries, asking whether a recipient shares more of them than its sister does (D_pav), and maps donor-like stretches along the recipient. A simulator that evolves genomes with known insertions and known gene flow is included, for testing the method and estimating power.

How it works, in full: [docs/METHODS.md](docs/METHODS.md).

## Install

From the repository root (the environment installs this checkout, so create it there):

```bash
git clone https://github.com/cwb14/LTRpav
cd LTRpav
mamba env create -f environment.yml    # env "ltrpav": Python 3.12, LASTZ, minimap2, FastGA, BLAST, msprime
mamba activate ltrpav
ltrpav --version
```

Or with pip, on Python 3.10 to 3.13, with LASTZ installed separately (bioconda package `lastz`):

```bash
pip install -e ".[sim]"       # [sim] adds msprime for ltrpav-sim pop and the quick start; [dev] adds the tests
```

pip builds mappy (the minimap2 binding) from source, which needs a C compiler and zlib headers.

POSIX systems only (it forks worker processes); tested on Linux.

| Needed for | Program |
|---|---|
| genotyping (`ltrpav run`, `ltrpav-genotype`) and `--identity` | LASTZ (required) |
| the default anchoring | nothing more: minimap2 runs through its Python binding (the `minimap2` program is optional) |
| `--anchor fastga`, and `hybrid` when FastGA is installed | FastGA |
| `--anchor flank-blast` | `blastn`, `makeblastdb` |
| `ltrpav-sim pop` | msprime |

## Quick start

```bash
bash examples/quickstart.sh       # about a minute at 4 threads; writes ./ltrpav_quickstart
```

It builds a toy genome, simulates four genomes on it (A1, B1, C1 and the outgroup O1, with a pulse of gene flow from C into A), runs `ltrpav run`, reruns the analyses for the trio A1,B1,C1, scores the calls against the simulated truth, and repeats the genotyping one stage at a time. The toy is a smoke test: it is far too small to show gene flow (D_pav +0.50 ± 0.57, Z 0.88, on 4 informative insertions).

## Inputs

A samples sheet, tab-separated, with this header line:

```
label	fasta	annotation	group	role
B73	genomes/B73.fa	annot/B73_LTRs	maize	.
TIL18	genomes/TIL18.fa.gz	annot/TIL18.gff3	mexicana	.
TIL01	genomes/TIL01.fa	annot/TIL01.bed	parviglumis	.
Zd	genomes/Zd.fa	.	diploperennis	outgroup
```

- `label`, `fasta` and `annotation` are required columns; `group` (a taxon name, used by the direction test and shown in the figure) and `role` (only `outgroup`) are optional. Every row needs a FASTA. In `annotation`, `group` and `role`, `.` or an empty field means none: a genome without an annotation is genotyped only, which suits outgroups and distant donors.
- At least two genomes and one annotation, which gives genotyping, the mechanism and inversion tables, the PAV distances and the run summary. Labels use `A-Z a-z 0-9 _ . -`, with no `__`, no leading or trailing `_`, and not `all`. Relative paths resolve against the sheet's folder; `#` starts a comment line.
- What each analysis needs beyond that: D_pav needs three ingroup genomes, with the donor annotated (or annotated relatives that split with it); the painting needs three ingroup genomes with the recipient annotated, and the sister annotated for its decoy. An outgroup (`role` `outgroup`) sets aside insertions older than the ingroup split and roots the tree. The direction test needs an outgroup and two genomes in each of two groups. `findings.txt` says what was skipped.
- FASTA: plain or bgzip (plain gzip is refused). The `.fai` index goes beside the FASTA when that folder is writable, else under `OUTDIR/work/fai`. Sequence names may repeat across genomes.
- Annotation, recognized by its name:
  - **LTRquest**: the output prefix (all `<prefix>_depth*_clean_ltr.tsv` tables); rows with status `pass`.
  - **GFF3** (`.gff3` or `.gff`, optionally `.gz`): features whose type ends in `LTR_retrotransposon`, each with exactly two `long_terminal_repeat` features, as its children or, as EDTA writes them, as its siblings. Records without them, such as EDTA's homology-based ones, are skipped. Attributes read: `ID`, `Name`, `tsd`, `K2P_d` (else `ltr_identity`), `family`, `superfamily`, `clade`, `Classification`, `confidence`. A record with `Classification` and no `family` (EDTA) takes its family from `Name`.
  - **BED** (`.bed`, optionally `.gz`; 0-based, half-open): chrom, start, end, then optional name and strand (column 6). The LTRs are found by aligning each element's two ends; an element whose LTRs are not found is skipped. BED gives no LTR divergence (K2P), family or clade, so that genome's insertions have no age strata, no K-based dating and no family in any table.
  - In every format a missing target-site duplication (TSD) is looked for in the FASTA (an exact 5-, 4- or 6-bp repeat beside the element), and malformed records are skipped with a warning and counted in `qc.tsv`.

## Commands

| Command | What it does |
|---|---|
| `ltrpav run` | everything: genotype every pair, merge the calls into loci, write the outputs, run the analyses, draw the figure |
| `ltrpav-anchor` | anchor each ordered genome pair (one with `--pair A,B`) |
| `ltrpav-genotype` | genotype each ordered pair (anchoring it first if needed) |
| `ltrpav-merge` | merge the finished pair files into loci and write the outputs |
| `ltrpav-stats` | relationships, trio tests (D_pav), inversions, direction, mechanisms; `--identity` adds the sequence-identity layer, `--block-size` sets the jackknife block |
| `ltrpav-paint` | paint each trio's recipient, with its sister painted as a decoy |
| `ltrpav-plot` | the overview figure |
| `ltrpav-sim pop`, `ltrpav-sim score` | simulate genomes with known truth; score one pair's calls against it |

```bash
ltrpav run --samples samples.tsv --outdir out --threads 32
ltrpav run --samples samples.tsv --outdir out --threads 32 --trio B73,TIL01,TIL18 --identity
```

`ltrpav run` options: `--threads` (default 8), `--anchor` (default `flank-mm2`; also `mm2`, `fastga`, `flank-blast`, `hybrid`, `paf:<dir>`), `--vcf-ref` (the VCF's coordinate genome; default the first row), `--trio R,S,D` (recipient, sister, donor; default every trio, roles from the data), `--identity`, `-v`. Each ordered pair is an annotated genome against any other genome; to spread a large run over jobs, run `ltrpav-genotype --pair A,B` for each, then `ltrpav-merge`, `ltrpav-stats`, `ltrpav-paint` and `ltrpav-plot`. A rerun skips finished stages, each keyed on its inputs' checksums, options, code and tool versions. Exit status: 0 done; 1 an error (one `error:` line, plus the traceback with `-v`); 2 a usage error; 3 (`ltrpav run` only) the genotyping finished but the analyses failed; 130 interrupted.

## Outputs

In `OUTDIR`:

| File | What it holds | Coordinates |
|---|---|---|
| `loci.tsv` | one row per insertion (locus): family, length, TSD, discovering genomes; per genome its state, tier, position, strand, K2P and flags | 1-based, closed |
| `pav_matrix.tsv` | loci × genomes, states only | |
| `qc.tsv` | per pair and genome: state fractions, resolved fraction, reciprocity, agreement with the target's own annotation, skipped records | |
| `pav.vcf.gz` (+ `.tbi`) | one site per locus placed in the `--vcf-ref` genome; haploid GT 1 = P/S/T, 0 = E, `.` = D/O/G/U; per-sample `ST` (state) and `TR` (tier) | VCF, 1-based; POS is the base before the insertion |
| `pav.unplaced.tsv` | loci the VCF cannot place, with the reason | |
| `<label>.pav.gff3` | each genome's P, S, T, E and D sites, with every genome's state | 1-based, closed |
| `<label>.pav.bed` | the same sites (BED6 plus state, tier, family) | 0-based, half-open |
| `pairs/<A>__<B>.calls.tsv.gz` | each element of A, its call in B and the evidence | 1-based, closed |
| `stats.tsv`, `findings.txt` | every statistic with its SE, Z and the loci it counts; the results in plain words, with warnings | |
| `tracts.<R>.bed`, `decoy_tracts.<S>.bed` | donor-like tracts of recipient R, and of its sister S painted as a control | 0-based, half-open (`start0`) |
| `posterior.<R>.tsv`, `decoy_posterior.<S>.tsv` | per insertion: class, posterior, and its tract as `seqid:start-end` | 1-based, closed (the `tract` string too) |
| `inversions.tsv` | inverted blocks between genome pairs | 1-based, closed |
| `mechanisms.tsv` | what each pair's absences are (empty sites, deletions, replacements) by family and age; losses placed on the tree | |
| `identity.tsv` | with `--identity`: LTR divergence of shared insertions | |
| `overview.png`, `overview.pdf`, `overview_numbers.tsv` | the overview figure (the PDF with short and long legends) and every number in it | |
| `manifest.json` | versions, command, parameters, input checksums; written last, so it marks a finished merge | |
| `work/` | the cache a rerun resumes from | |

The figure uses Liberation Sans (or Arial) and Liberation Mono from the host, else DejaVu Sans and DejaVu Sans Mono with a WARNING (Arial alone leaves the monospace text in DejaVu Sans Mono); install `fonts-liberation`, which provides both Liberation fonts, for the intended look.

`ltrpav-sim pop` writes truth tables `truth/<X>__<Y>.tsv` (1-based, closed), `truth/insertions.tsv` (`pos` 0-based) and `truth/tracts.<label>.bed` (0-based, half-open).

## Reading the results

**States.** Each annotated element of genome A is called in every other genome B:

| State | What B holds at the site | Counts as |
|---|---|---|
| P | an intact copy (both LTRs, ≥ 80% of the element aligned) | present |
| S | a solo LTR | present |
| T | a truncated copy | present |
| E | an empty site: the flanks join through one TSD copy | absent: the insertion never happened in B's line, since retrotransposons do not excise precisely |
| D | a deletion: the element is gone and the junction is not a clean empty site | missing |
| O | other sequence in its place | missing |
| G | an assembly gap at the site | missing |
| U | unresolved (no anchors, an ambiguous placement, a rearrangement; the pair file's `reason` says which) | missing |

A deletion never shows that B lacked the insertion (one that leaves part of the element shows B carried it), so D, O, G and U are missing data, never absence. **Tiers:** a call is high when its placement is sure (the orthologous alignment outscores rivals 2:1, ≥ 80% identity around the element) and its state has its own evidence (always for P; the TSD pair beside the solo LTR for S; a matching TSD copy for E; an exact junction for D; none for T and O), medium when one holds, low when neither. G and U have no tier; a genome whose annotation holds the insertion has tier `annot`.

**D_pav and Z.** For a trio (R recipient, S sister, D donor), D_pav = (n_RD − n_SD) / (n_RD + n_SD), counted on the insertions D's annotation found and D carries that are resolved in R and S and empty in every outgroup: n_RD are present in R and empty in S, n_SD the reverse. Lineage sorting alone gives 0 on average; gene flow from D into R makes it positive. Z is D_pav over its block-jackknife SE (5-Mb blocks, or 1/100 of the smallest genome if shorter), and |Z| ≥ 3 is read as significant. Since the loci come from the donor's annotation, how well each sister is annotated cannot bias the count (an unannotated donor's loci come from annotated relatives; see the methods). `stats.tsv` repeats D_pav by insertion age, on high-tier calls only, with nested insertions counted once, and without the outgroup filter.

**Painting.** Along R, each insertion R's annotation found is donor-like (in D, not in S) or sister-like (in S, not in D). A two-state hidden Markov model gives each a posterior of lying in a donor-like stretch; a tract is a run with posterior > 0.5 and posterior odds at least 3 times the prior odds. The sister, taken to have received no gene flow from the donor, is painted the same way as a decoy, and a tract's q estimates its false discovery rate against the decoy's tracts.

**What to trust.** Trust a D_pav whose Z is well above 3 and stays there in the check strata and at other block lengths. Read a Z near 3 with caution: rerun `ltrpav-stats` with blocks of 1 to 20 Mb (in bp, e.g. `--block-size 10000000`; it replaces the statistics, and a rerun without it restores the default). Treat every tract as a lead. q ≤ 0.05 is rarely reached, and its false discovery rate is not validated: in the one simulated gene-flow run (of 36) that reached it, 3 of 25 tracts were false. The direction test is exploratory and not validated. Read `findings.txt`'s warnings, for example when the two sisters are resolved at different rates.

## Resources

- The toy quick start: about a minute at 4 threads.
- The real runs below used development versions of LTRpav shortly before 0.1.0, on a shared 256-core server running other jobs (load 70-245), so their wall times are upper bounds; the six-genome run was split over four sessions.
- Maize, four genomes (B73 2.18 Gb, TIL18 2.49 Gb and TIL01 2.62 Gb annotated, plus an unannotated 3.29-Gb outgroup), 9 pairs: 2 h 11 min at 32 threads; 11.9 GiB maximum resident memory, 19.6 GiB at peak across all processes. On these genomes `ltrpav-stats --identity` took about 20 min at 32 threads.
- Six annotated maize and teosinte genomes plus the same outgroup, 36 pairs: 11.4 h at 32 threads, 19.8 GiB at peak across all processes. Pairs run one at a time, so memory follows genome size and threads more than the number of genomes.
- The whole-genome route `--anchor mm2` needs more memory: 24.4 GiB maximum resident memory for the four maize genomes at 32 threads.
- Disk: about 2.4 GB of minimap2 index per Gb of assembly (`work/anchors/*.mmi`), which can be deleted once the run has finished.

## How well it works

Measured with development versions of LTRpav shortly before 0.1.0, on 144 simulated genome sets with known truth and on real genomes with known or expected gene flow ([docs/METHODS.md](docs/METHODS.md) has the design).

- **Detection.** D_pav found the gene flow in all three real cases: *mexicana* into maize B73 against *parviglumis* (D_pav +0.290, Z 7.39), *Zea nicaraguensis* into *Z. mays* ssp. *huehuetenangensis* (Z 6.36), and mandarin ancestry in sweet orange's pummelo-derived haplotype (Z 16.85). In 60 simulated sets without gene flow the largest |Z| was 3.14, and none of the 30 with the default demography reached |Z| > 3.
- **Power is limited.** On a 50-Mb simulated backbone, D_pav reached Z > 3 in 10 of 36 gene-flow runs (all 6 with half the recipient's lineages moved, at most 2 of 6 at smaller fractions), and about as often with perfect genotypes (11 of 36), so the number of informative insertions limits it. Real maize genomes give about 6 times as many, but they resolve fewer calls (below), so simulated power is still optimistic. A Z below 3 does not show the absence of gene flow: the 2.9% pummelo ancestry of sweet orange's mandarin-derived haplotype gave Z 0.95.
- **Uneven annotation.** In 20 simulated sets without gene flow, with one sister annotated 10 or 30 points less completely than the other, D_pav gave no false signal, while a statistic that counts each sister's own annotated insertions, from LTRmix (the author's library-based method, unpublished), gave a false signal in 18 of 20 (McNemar p 8 × 10⁻⁶).
- **Genotypes.** In simulations, 99.7% of high-tier P and E calls were right. Real genomes are harder: 46% of B73's elements were resolved in TIL18, against 76% in the simulations.
- **Painting is coarse.** It covered 4 of sweet orange's 5 known tracts (1.7-23.8 Mb) but cannot see maize's tracts of about 10 kb: there, informative insertions lie a median 85 kb apart, and an insertion inside a published *mexicana* stretch outranks one outside 71% of the time (0.5 is chance). No tract reached q ≤ 0.05 in the paintings with a known answer.
- **Controls.** Controls expected to show no excess stayed below |Z| 3 in the *Zea* genus (Z −0.68) and in sweet orange (Z 2.61 and −0.54). In six maize genomes, D_pav gave a positive control (highland maize) and a negative control (two *parviglumis*) the same excess (+0.139 and +0.145, Z 3.16 and 3.20) where SNP-based D separates them, and with 10-Mb blocks both fell below 3 (Z 2.92 and 2.80). Verdicts near Z = 3 are fragile.
- **Direction is not validated.** In its simulated positive control the direction test read the expected direction in 2 of 8 runs, and both were runs without gene flow.
- **Stable where strong.** With EDTA's annotation instead of LTRquest's, maize D_pav is +0.305 (Z 5.94); across anchoring routes, flank lengths and jackknife blocks of 1-20 Mb, Z stays 6.0-8.4.
- The null spread of Z is narrower than a standard normal in simulations without a bottleneck (SD 0.72) and wider with one (SD 1.29), so Z is a guide, not an exact probability.

## Limitations

- Elements on unplaced scaffolds end mostly unresolved: 70-83% U in maize (measured with a development version shortly before 0.1.0), against 13-18% on chromosomes.
- Built for up to about 10 genomes per run; the largest run tested had 7. Every annotated genome is genotyped against every other one, so time grows with the square of the genome count.
- Assemblies only, LTR retrotransposons only (other transposon orders are untested). The haplotypes of a phased assembly can be given as separate genomes, as sweet orange's were.
- One set of analysis results per run folder: rerunning with other options (`--trio`, `--block-size`) replaces them, and `ltrpav run` always uses the default block size. Rerunning `ltrpav-stats` or `ltrpav run` without `--identity` deletes `identity.tsv` (with a warning); repeat `--identity` to keep it.
- `manifest.json` and the PDF's long legend record the host name and absolute paths; `findings.txt` records the run's absolute path in its first line, and `ltrpav-sim pop`'s `params.json` records the input paths.

## Tests

```bash
pytest -m "not slow"        # in the ltrpav env; with pip, first: pip install -e ".[dev,sim]"
```

Tests that need LASTZ, FastGA, BLAST, bcftools, poppler (`pdftotext`) or msprime skip when it is missing. Plain `pytest` adds three slow tests.

## Citation

There is no paper yet. Please cite the software: Chris Benson, LTRpav, version 0.1.0, https://github.com/cwb14/LTRpav ([CITATION.cff](CITATION.cff)).

## License

GPL-3.0-or-later ([LICENSE](LICENSE)).
