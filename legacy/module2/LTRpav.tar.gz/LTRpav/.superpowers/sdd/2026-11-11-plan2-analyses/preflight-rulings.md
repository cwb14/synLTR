# Plan 2 pre-flight: controller rulings on the scan (preflight-scan.md)
These are applied to `docs/plans/2026-11-11-plan2-analyses.md` before Task 1. Each ruling names the scan row.

## The engine fingerprint (rows C1, C2, C3)
Plan 1's final fix wave keys every engine stage on a fingerprint of the engine's own modules. Subpackages in
`checkpoint.NON_ENGINE` (now `("sim",)`) are excluded.

- **C1. Register the analysis packages.** Task 1 adds every new analysis or plot subpackage to NON_ENGINE, and puts
  all Plan 2 code inside those subpackages. A test asserts that an edit to an analysis module leaves every engine
  stage key unchanged.
- **C2. Stay out of engine modules.**
  - Plan 2 never edits engine modules for its own needs. Analysis constants go in the analysis package's own
    constants module, each with a one-line reason. The analysis CLI entry points (`ltrpav-stats`, `ltrpav-paint`,
    `ltrpav-plot`) live in the analysis package and are registered in pyproject.
  - The one accepted exception is a single hook in `cli.py` (Task 10), so that `ltrpav run` calls the analysis
    stages after the merge. That edit changes the engine fingerprint once.
  - The analysis commands read a finished run's files as data. They must never call `_check_pair_files` or any
    other engine-fingerprint check, so Task 12 runs them on main3 (engine 7d71073) without re-genotyping.
  - Say in DESIGN 8 that resuming `ltrpav run` in an outdir finished by an older engine recomputes genotyping.
- **C3. Analysis stage keys.** They use an analysis fingerprint (the analysis packages' sources) plus the checksums
  of the engine output files they read, never the engine fingerprint. An engine edit reruns an analysis only when
  the outputs it reads change.

## Other engine rows
- **C4.** Task 10's error test asserts that stderr ends in exactly one `error:` line with no traceback. It does not
  assert one stderr line in total, because INFO logging goes to stderr.
- **C5.** The identity layer realigns with the engine's default backend (`constants.DEFAULT_BACKEND`, LASTZ), which
  is "the same aligner as the engine". The text must not call mappy the engine's aligner.
- **C6.** Task 1 updates the lock file by commit 84c8088's portable procedure. It never uses a raw `mamba env
  export`, which reintroduces `prefix:` and a pip-pinned ltrpav.
- **C7.** The suite command is `python -m pytest -W error` with no extra `-q`, because pyproject's addopts already
  has one.
- **C8.** `plan2-analyses` is cut from `plan1-engine` after the controller fast-forwards it to the reviewed head of
  `plan1-final-fixes`. Correct the plan's Global Constraints line accordingly.
- **C9.** Task 10's chr10 smoke test uses a scratch copy of
  `benchmark_pav/bakeoff/chr10/runs/flank-mm2_2k/`, which has qc.tsv, not `runs/flank-mm2`.

## Plan-text defects (rows A, B, D)
- **A4/D1.** ToyLocus's dict fields use `field(default_factory=dict)`.
- **A5.** Toy spacing must exceed the element length: choose `n_per_seq` so that spacing >= 2 x the element length.
  Fix every test that depends on it.
- **A10.** `assemble`'s header line with the version goes into findings.txt only. stats.tsv keeps a pure header
  row.
- **A12/D2.** One discovery function, with the outgroup rule as a parameter. D_pav keeps "outgroup E"
  (DESIGN 7.1). KKSC keeps "no outgroup present", the set-aside rule of DESIGN 7.2. Each row's `loci` column states
  its rule.
- **B3.** `test_kksc_reads_the_third_genomes_calls` gets a fixture whose sister pair is (R, S) and whose donor is
  D, so that D's own calls are what is read. State its expected counts.
- **A18.** Inversion blocks and painting key sequences as (genome, seqid index), per Review Focus 1. InvBlock
  carries indexes, with names only for output.
- **B5/D7.** `test_block_found`, rewritten as valid code that selects the pair under test, with the S~O block
  accounted for.
- **A19.** `inversion_rows` goes into `run_stats`'s order.
- **A21 and the T6/T9 dependency.**
  - T6 reports each tract's youngest insertion from the annotation's K of R's copy.
  - `youngest_u95` (exact counts) exists only when the identity layer (T9, `--identity`) has run. T9 fills it, and
    T6 leaves it NA.
  - Define identity.tsv's row kinds explicitly in T9:
    - self rows: one per annotated copy with two alignable LTRs;
    - pair rows: one per locus with two P copies.
  - Loci with neither get no row.
- **D4.** The chi2 u95 formula is written once, in Task 2's statistics core, and imported by T6 and T9.
- **D3.** The resolution-symmetry warning is one helper in Task 2, used by every test that needs it.
- **A24/D13.** Compare like with like. Task 12 compares LTRmix's tract length (its L) with LTRpav's L under the
  same name. LTRpav's L/(1-pi), if reported, gets a different name.
- **A30/A31/A32.** Catalog carries the samples-sheet path and its checksum. Each stage marker lists exactly the
  files the stage writes, so that "done, skip" works. Add a test of the skip.
- **A35.** main3's labels are B73, TIL18, TIL01 and Zd. Use the sheet's labels; B73v5 is only the LTRmix/LTRquest
  element-name prefix.
- **A36.** Re-bin LTRpav's counts into LTRmix's right-closed bins, not the reverse.
- **A37.** Task 12 computes the outgroup-pattern estimate itself from the catalog (ingroup E at loci Zd carries,
  reported as an upper bound, decision 18). It does not quote QC.md.
- **D5.** Every test step carries real assertions with the expected values, as the writing-plans skill requires:
  no signature plus comment, no `...` body. Where an expected value comes from a simulation, give the seed and the
  value. Task 4's `test_null_and_admixed`, and any other incomplete test, gets complete code.
- **D8.** `test_paint_null` must fail if painting is broken. Assert that the null run has 0 tracts at q < 0.05 and
  that the fitted proportion stays below the decoy-calibrated bound. Add a positive control in the same test: an
  admixed toy with known tracts recovers them.
- **D9.** `test_dfoil_alt_signatures_from_branch_lengths` carries its expected counts inline, derived from the
  plan's own branch-length rule. No external table.
- **D10.** For BED annotations (strand "."), the identity layer takes orientation from the alignment. If an
  orientation cannot be inferred, it counts and reports the skip in findings, never silently.
- **D12.** The PNG dpi assertion allows Pillow's rounding: >= 299.5.

## Process
- **Who applies these:** the drafter applies all of them, re-runs the writing-plans self-review, and lists each
  ruling with the plan lines it changed in `preflight-applied.md` in this directory.
- **No re-scan.** Task reviews are the net for anything left over.
