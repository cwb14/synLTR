#!/usr/bin/env python3
"""Annotation-robustness test input: shift each element's two ends by independent uniform offsets in [-J, J] bp
(the outer LTR boundaries move with them, the inner LTR boundaries stay), and drop TSD attributes, mimicking an
annotator with less precise boundaries. Element IDs are kept so calls can be matched.
usage: jitter_gff.py in.gff3 J seed > out.gff3"""
import random
import sys

path, J, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
rng = random.Random(seed)
shift = {}
lines = open(path).read().splitlines()
for ln in lines:                              # first pass: draw offsets per element ID
    x = ln.split("\t")
    if len(x) == 9 and x[2].lower().endswith("ltr_retrotransposon"):
        eid = dict(kv.split("=", 1) for kv in x[8].strip(";").split(";") if "=" in kv)["ID"]
        shift[eid] = (rng.randint(-J, J), rng.randint(-J, J))
out = []
for ln in lines:
    x = ln.split("\t")
    if len(x) != 9:
        out.append(ln)
        continue
    a = dict(kv.split("=", 1) for kv in x[8].strip(";").split(";") if "=" in kv)
    s, e = int(x[3]), int(x[4])
    if x[2].lower().endswith("ltr_retrotransposon"):
        d0, d1 = shift[a["ID"]]
        x[3], x[4] = str(s + d0), str(e + d1)
        x[8] = ";".join(f"{k}={v}" for k, v in a.items() if k.lower() != "tsd")
    elif x[2] == "long_terminal_repeat" and a.get("Parent") in shift:
        d0, d1 = shift[a["Parent"]]
        if a.get("ID", "").endswith("lLTR"):
            x[3] = str(s + d0)
        else:
            x[4] = str(e + d1)
    out.append("\t".join(x))
print("\n".join(out))
