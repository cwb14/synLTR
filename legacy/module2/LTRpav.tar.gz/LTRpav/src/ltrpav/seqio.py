"""Random-access FASTA reading (plain or bgzip) that never loads a genome."""

from __future__ import annotations

import contextlib
import hashlib
import os
import re
from pathlib import Path

import pysam

from .checkpoint import atomic_path

COMP_FROM, COMP_TO = "ACGTRYKMBVDHNacgtrykmbvdhn", "TGCAYRMKVBHDNtgcayrmkvbhdn"  # IUPAC letters and complements
_COMP = str.maketrans(COMP_FROM, COMP_TO)
_N_RUN = re.compile(r"[Nn]+")


def revcomp(seq: str) -> str:
    """Reverse complement (IUPAC-aware, case preserved)."""
    return seq.translate(_COMP)[::-1]


def n_runs(seq: str) -> list[tuple[int, int]]:
    """0-based half-open runs of N/n in `seq`."""
    return [m.span() for m in _N_RUN.finditer(seq)]


def _build_index(path: Path, fai: Path, gzi: Path | None) -> None:
    """Index `path` into `fai` (and `gzi` for bgzip), under temporary names renamed into place, the .gzi first:
    a reader that finds the .fai finds a complete index."""
    with contextlib.ExitStack() as stack:   # leaves in reverse: the .gzi is renamed first
        tmp_fai = stack.enter_context(atomic_path(fai))
        tmp_gzi = None if gzi is None else stack.enter_context(atomic_path(gzi))
        pysam.faidx(str(path), "--fai-idx", str(tmp_fai), *(["--gzi-idx", str(tmp_gzi)] if tmp_gzi else []))


def _gzip_kind(path: Path) -> str | None:
    """None (not gzip), "bgzip" (BGZF 'BC' extra field) or "gzip" (plain)."""
    with open(path, "rb") as fh:
        head = fh.read(14)
    if head[:2] != b"\x1f\x8b":
        return None
    return "bgzip" if head[12:14] == b"BC" else "gzip"


class Fasta:
    """Indexed FASTA. Coordinates are 0-based half-open; output is uppercase.

    The index (.fai, plus .gzi for bgzip) is used if present next to the FASTA, built there if the directory is
    writable, else built in `cache_dir` under a name keyed by the FASTA's path, size and mtime (a changed FASTA
    gets a new index, never a stale one). An index is built under temporary names and renamed, so concurrent
    runs never read a partial one. Plain gzip is rejected up front (htslib reads only bgzip); an index pysam
    cannot build is a ValueError naming the file.
    """

    def __init__(self, path: str | Path, cache_dir: Path | None = None):
        self.path = Path(path)
        self.cache_dir = None if cache_dir is None else Path(cache_dir)  # kept: workers reopen alike
        if not self.path.is_file():
            raise FileNotFoundError(self.path)
        self._fh = self._open(cache_dir)
        self._lengths = dict(zip(self._fh.references, self._fh.lengths))

    def _open(self, cache_dir: Path | None) -> pysam.FastaFile:
        path = self.path
        kind = _gzip_kind(path)
        if kind == "gzip":
            raise ValueError(f"{path} is gzip-compressed but not bgzip; recompress with bgzip")
        gz = kind is not None
        fai, gzi = Path(f"{path}.fai"), Path(f"{path}.gzi")
        try:
            if fai.exists() and (gzi.exists() or not gz):
                return pysam.FastaFile(str(path))
            if os.access(path.parent, os.W_OK):
                _build_index(path, fai, gzi if gz else None)
                return pysam.FastaFile(str(path))
            if cache_dir is None:
                raise ValueError(f"no index for {path} and its directory is not writable; the index cannot be "
                                 "written, pass a cache directory")
            cache_dir = Path(cache_dir)
            try:
                cache_dir.mkdir(parents=True, exist_ok=True)
            except OSError as exc:  # the cache (an outdir's work/fai), not the FASTA, is at fault: say so
                raise OSError(f"cannot create the FASTA index cache {cache_dir}: {exc}") from exc
            st = path.stat()
            tag = hashlib.sha1(f"{path.resolve()}\0{st.st_size}\0{st.st_mtime_ns}".encode()).hexdigest()[:12]
            fai = cache_dir / f"{tag}.{path.name}.fai"
            gzi = cache_dir / f"{tag}.{path.name}.gzi"
            if not fai.exists() or (gz and not gzi.exists()):
                _build_index(path, fai, gzi if gz else None)
            return pysam.FastaFile(str(path), filepath_index=str(fai),
                                   filepath_index_compressed=str(gzi) if gz else None)
        except pysam.SamtoolsError as exc:  # not an OSError or ValueError: callers would not catch it
            raise ValueError(f"{path}: cannot index the FASTA: {exc}") from exc

    def lengths(self) -> dict[str, int]:
        """Sequence lengths in index (file) order."""
        return dict(self._lengths)

    def fetch(self, seqid: str, start: int, end: int) -> str:
        """Uppercase sequence [start, end), clipped to the sequence."""
        if seqid not in self._lengths:
            raise KeyError(seqid)
        start = max(start, 0)
        end = min(end, self._lengths[seqid])
        if start >= end:
            return ""
        return self._fh.fetch(seqid, start, end).upper()

    def close(self) -> None:
        self._fh.close()

    def __enter__(self) -> Fasta:  # noqa: PYI034 (typing.Self needs py3.11)
        return self

    def __exit__(self, *exc) -> None:
        self.close()
