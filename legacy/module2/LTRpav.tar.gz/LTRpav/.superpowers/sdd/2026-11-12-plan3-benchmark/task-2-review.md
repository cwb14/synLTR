# Task 2 review: events on the genealogy, thinning, and Task 1's minors (3bf2833..41f70b6)

Reviewed at head 41f70b6 (branch plan3-benchmark; working tree clean, read-only). Line numbers are those of
41f70b6. Probes (scratch, read-only on the repo):
`/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t2review/`
(oracle.py, oracle_c4a.py, probe_nested_n.py, nested_rate.py, replace_deficit.py, junction.py).
Focused runs: `tests/test_popevents.py` 25 passed; `tests/test_popmodel.py -k "flat_fields or bad_demog or
through_ancestor or three_per_taxon or import_without"` 5 passed.

## Spec Compliance

### Brief (task-2-brief.md)
- ✅ Files: `src/ltrpav/sim/popevents.py`, `tests/test_popevents.py`; `tests/poptoy.py` gains `toy_ts` (poptoy.py:31-59)
  and `toy_backbone` (poptoy.py:80-98).
- ✅ Interfaces: `Ins`, `Loss` and `ChromEvents` carry the brief's fields verbatim (popevents.py:97-140). The
  `draw_events` signature adds only keyword `chrom` (popevents.py:425-426), which the controller carried into Task 3.
- ✅ Constants are read only: `MIN_SEG`, `SLOP_TSD_MULT` and `TSD_DEFAULT` (popevents.py:73);
  `FLANK_DEL`, `PARTIAL` and `PARTIAL_MIN` (popevents.py:75).
- ✅ The backbone is upper-cased (popevents.py:434).
- ✅ Rule 1, primary insertions:
  - binary model, continuous genome, keep=False (popevents.py:454-455);
  - pos = floor (popevents.py:459);
  - ins_end, symmetric 15 bp (popevents.py:460-461);
  - ins_n on [pos-5, pos) (popevents.py:462-463);
  - donor uniform, strand 1/2 (popevents.py:471-472);
  - carriers = the samples below the mutation's node (popevents.py:473);
  - host None inside backbone elements.
- ✅ Rule 2, losses:
  - each backbone element is read on the tree at its start (popevents.py:466-467, 476-478); each insertion on the
    tree at its position, and nested ones on their host's tree (popevents.py:488-491, 512-516);
  - a Poisson process per branch at delta, oldest first (popevents.py:207-211);
  - ending kinds stop the lineage (popevents.py:230-237).
  - Plan 1's parameters, checked against pair.py:254-280 and genome.py:254-265:
    - solo U{1..min-1} (popevents.py:214-217);
    - del_flank side 1/3 with FLANK_DEL (popevents.py:218-221);
    - del_partial round(U(PARTIAL) x internal) at a uniform start, on the original internal region
      (popevents.py:222-226);
    - replace max(MIN_SEG+1, round(Exp)) (popevents.py:227-228).
- ✅ Rule 3, nested insertions:
  - count Poisson(lam x len(body) x B_X), with B_X excluding the parts below X's ending losses
    (popevents.py:494-496);
  - point uniform by length (popevents.py:500-503) and offset U{0..len-1} (popevents.py:504);
  - carriers below the point (popevents.py:510);
  - depth at most 2 (popevents.py:492).
  - I checked the law by probe (nested_rate.py; TREE16, 40 seeds, delta = 0): depth 1 observed 15,763 against
    15,828 expected (z -0.52); depth 2 observed 9,260 against 9,142 (z +1.23).
- ✅ Rule 4, SNPs:
  - JC69 on a discrete genome, keep=False (popevents.py:523-524);
  - the permutation table (popevents.py:90-94) sends the ancestral base to the backbone base and keeps the order of
    the other three, applied at popevents.py:537;
  - non-ACGT sites are dropped and counted in snp_n (popevents.py:532-536).
- ✅ Rule 5, indels:
  - binary model on a discrete genome (popevents.py:540-541);
  - carriers per mutation, in table order (popevents.py:543-552);
  - insertion or deletion 1/2, geometric `_INDEL_P` = 1/3 (popevents.py:554-555; genome.py:28);
  - backbone positions only.
- ✅ The three mutation calls run separately, each on the mutation-free ts with its own seed (popevents.py:433,
  454-455, 523-524, 540-541). The test spy asserts both (test_popevents.py:55-62).
- ✅ All ten of the brief's tests exist under the brief's names (test_popevents.py:92-396), plus five extras.
- ✅ The commit messages follow the brief and the ruling; user identity; no trailers.

### Concern-1 ruling (task-2-concern-ruling.md) and rulings C1-C4
- ✅ There is one public `removed()` (popevents.py:270-310), exported (popevents.py:81-82). `thin_events` is its only
  consumer of interval geometry (popevents.py:395-397). Each kind's interval matches Plan 1:
  - solo: `delete(a + x, c + x)` (genome.py:254-265);
  - del_flank: `delete(e.start - left, e.end + right)`, with e.start/e.end the body and the TSD copy after it
    (pair.py:262-264; genome.py:204-220);
  - del_partial: pair.py:277-279.
- ✅ del_flank of a host-None insertion (popevents.py:305-309):
  - X's body and, when b > 0, its second TSD copy;
  - [p - a, p), with the target bases first;
  - [p, p + b - 5), after the TSD copy.
  - The total removed is a + body + b, as in Plan 1. I checked the spill into the host's host, + and - strand
    (`_spill`, popevents.py:246-267), by hand against test_popevents.py:531-554.
- ✅ Overlapping del_partials remove their union, in original coordinates; PARTIAL_MIN is checked on the original
  internal region (popevents.py:19-21, 222-226, 283).
- ✅ Oldest first, unique (popevents.py:373-397). Ties are broken by input index (measure zero for drawn events).
  - A discarded loss registers nothing (popevents.py:389-391).
  - A discarded insertion never enters `kept_ins`, so its losses and nested events fail `exists`
    (popevents.py:365, 371, 378).
- ✅ Independent check: a per-sample replay oracle (oracle.py) keeps its own removed intervals, ended set and carried
  insertions per sample, applies the same rule, and calls only `removed()` from the module.
  - On the implementer's landscape: 0 disagreements at 2 Mb (1,449 insertions, 1,090 losses) and at 5 Mb (3,711
    insertions, 2,919 losses).
  - The 5-Mb counts reproduce the report exactly: ins_after_loss 623, nested_after_loss 724, loss_after_loss 912;
    2,364 insertions and 2,007 losses kept.
- ✅ Counters `ins_after_loss`, `nested_after_loss` (any depth, any cause) and `loss_after_loss`
  (popevents.py:356, 386, 390).
- ✅ C2 ("any carrier"): `c & carriers` in hits (popevents.py:332) and a per-sample cover for backbone elements
  (popevents.py:361-363).
- ✅ C3: the target bases are [pos - 5, pos) everywhere: primaries (popevents.py:462), nested (popevents.py:505),
  thinning (popevents.py:379), docstring (popevents.py:47-48).
- ✅ C4b: a backbone element is gone only when its whole span is covered (popevents.py:359-363).
- ✅ C4c: a nested del_flank continues into its host's host (popevents.py:246-267).
- ⚠️ The ruling's tests were written after the code, so no RED run exists. Their evidence is exact expected values
  (I re-derived each by hand), the implementer's mutant check, and my oracle.
- ⚠️ I cannot tell from the diff whether the fixed seeds of the statistical tests were searched. None of
  test_popevents' tests scans seeds.

### Global constraints (plan lines 206-281)
- ✅ The diff touches no engine module. `src/` changes only `sim/popevents.py` and `sim/popmodel.py`
  (`git diff --stat 3bf2833 41f70b6 -- src/ltrpav`).
- ✅ No maize names appear in popevents.py (word grep: 0).
- ✅ The test module starts with `pytest.importorskip("msprime")` (test_popevents.py:7). The no-msprime import
  test now also covers popevents (test_popmodel.py, the import line in test_import_without_msprime).
- ✅ Heuristics are named in the docstring: the replace shape (popevents.py:19-21) and mechanisms an element cannot
  take (popevents.py:21-22). Two that the docstring does not name: Important 2 and Minor 2.

### Task 1 minors M1-M5 (a91987a)
- ✅ M1: the ta-against-split check runs only when f > 0 (popmodel.py:114). The f = 0 cases are accepted at
  test_popmodel.py:263-264, and the f > 0 counterparts still raise (test_popmodel.py:247-258).
- ✅ M2: test_tracts_three_per_taxon (test_popmodel.py:161), with per_taxon 3, 10 seeds, against an independent
  MIGRANT-node walk (test_popmodel.py:139-158). It asserts `moved == {0, 1, 2}`.
- ✅ M3: test_tract_through_ancestor asserts coordinates equal to the merged union of the pulse records
  (test_popmodel.py:113-136). The seed scan is conditioned on the event, and every scanned seed is checked, so the
  scan is legitimate.
- ✅ M4: `flat_fields` raises on a shared field (popmodel.py:275-284). It is called on import (popmodel.py:287), used
  by demog_from_json (popmodel.py:299) and tested (test_popmodel.py:234).
- ✅ M5: a DESIGN 12 "Environment (Task 1)" note on the bcftools 1.24 pin (DESIGN.md:798).

**Spec verdict: ✅** (rulings applied; C4a pending by design).

## Strengths
- `removed()` is one short, readable table of the four kinds, and it matches Plan 1's `delete` arithmetic exactly.
  The strand handling in `_spill` is right on both sides; I traced it through the TSD copies.
- Thinning is exact on what it covers. An independent per-sample oracle agrees on every event at 2 and 5 Mb.
  Determinism holds:
  - the same seed gives identical events (test);
  - a reversed `elements` list gives identical events (probe);
  - sets are read only in all()/any() tests.
- The ruling's tests are true unit tests: hand-placed events on named TREE7 nodes, with exact lists and counters,
  and edge cases at both ends of every interval (14,404/14,405; 10,100/14,400; 100,495/100,500; 13,102/13,105).
- The test spy checks the msprime contract on every call: no mutations in, keep=False, distinct seeds.
- test_target_boundaries pins the primary target window exactly, by planting a mutation at every half base.
- The M2/M3 test hardening is real: the truth is independent and the coordinates are exact.

## Issues

### Critical
None.

### Important

1. **test_nested_target_not_on_n asserts a window the code no longer uses, and passes by seed luck.**
   - Where: test_popevents.py:353; comment test_popevents.py:338. Code: popevents.py:505.
   - What:
     - 41f70b6 changed the nested non-ACGT check from 7bcdb96's ±5 bp to the target [pos-5, pos).
     - The test still asserts that `body[pos-5:pos+5]` is clean, and its comment still says "within 5 bp".
     - A correct insertion at pos in [blockstart-4, blockstart] has a clean target, but N in [pos, pos+5).
   - Evidence (probe_nested_n.py): the test's own setup at seeds 1-80 makes its assertion fail in 35 of 80 seeds,
     while the code's rule holds in all 80. Seed 17 passes by chance.
   - Why it matters:
     - The test fails correct code once the random stream moves. That can come from any change to the draw order,
       or from another msprime build that changes the insertion call's output (the report's concern 4).
     - No test pins the nested target window. A mutant that checks [pos, pos+5) for nested insertions passes
       unless an insertion lands in the 5 bp after the block.
   - Fix:
     - Assert the code's window, `body[max(0, i.pos - TSD_DEFAULT):i.pos]`, and correct the comment.
     - Add a deterministic one-sided check, so that the rule holds for any seed. For example, give a donor a
       periodic body (such as `"ACGTAC" + "N"` repeated) and assert two things:
       - every kept nested offset has a clean [pos-5, pos);
       - some kept offset has an N in [pos, pos+5).

2. **The replacing sequence gets no insertions, so the stated law "lam per present bp per generation" fails on a
   third of the present sequence-time (plan-mandated).**
   - Where: popevents.py:28-33 (the docstring's exactness claim); popevents.py:301-302 (replace removes the span or
     body, and the new sequence enters no coordinate system).
   - Mandate: brief rule 1 draws primaries on backbone coordinates; DESIGN 12 items 4 and 7 put insertions only on
     the backbone and in simulated insertions. The concern-1 ruling's exactness argument repeats the claim.
   - What:
     - A kept replace puts `a` bp of new sequence (mean 13,538) on every lineage below it.
     - That sequence is present, but no primary or nested process draws on it.
   - Size (replace_deficit.py, the report's 5-Mb probe): sum over kept replaces of lam x a x (branch length below
     the replace) = 479 expected insertions. That is 33% of the 1,462 kept primaries, about 25% of all present
     sequence-time.
     - Replaces sit high in the tree, and replacements are longer than what they replace.
     - For comparison, C4a's named simplification (solo-LTR remnants of simulated insertions) is 8.3.
   - Why it matters:
     - DESIGN 12 item 4 reports densities against main3, and C1 says density comparisons use kept counts. The kept
       density will sit well below lam x present sequence, and nothing records why.
     - The docstring states the process law as exact.
   - Fix (controller's call), either of:
     - (a) Name it as a simplification in the module docstring, with the measured share, next to C4a's solo-LTR
       one, and carry it into the Task 6/7 density readout.
     - (b) Model the replacing sequence as a coordinate system with a subtree process (lam x a x B below the
       replace, as for B_X), with its own target and thinning rules.

### Minor

1. **The nested rate law has no test.** No test checks the nested count Poisson(lam x len(X) x B_X). A mutant that
   uses `len(d.seq)`, or that drops lam from the nested rate, passes the suite. The code is right (nested_rate.py,
   z -0.52 and +1.23). Fix: add a TREE16 test with delta = 0 that compares the depth-1 count with
   sum(lam x len(body) x B_X) at 3 SD (popevents.py:494-496).

2. **C2's side effects are not named in the docstring** (popevents.py:56-58).
   - The "any carrier" rule is stated, but not called an approximation, as C2's ruling records it.
   - It has a second effect beyond the 159 primaries. A discarded *ending* loss still truncated the draw below it,
     so on the carriers whose lineage still holds the element, that element gets no later losses and no nested
     insertions there.
   - Oracle counts at 5 Mb: 8 such ending losses, 17 del_partials and 74 insertions discarded although present on
     some carriers.
   - Fix: one docstring sentence naming both effects as the cost of reading an element on one tree.

3. **Junction edges where one contiguous deletion is split into intervals** (popevents.py:53-55, 305-309).
   - A del_flank of X at p is stored as [p-a, p) and [p, p+b-5) of the host, plus (X, 0, len+5).
   - An insertion W at the same host pos p survives X's del_flank: in junction.py, W's younger replace below the
     flank is kept, although Plan 1's deletion is contiguous through p.
   - A nested insertion at body offset 0 sits at the edge of (X, 0, len+5) the same way.
   - Nested offsets 0-4 have truncated targets (popevents.py:379, 505). Their true target bases are the host's left
     TSD, which is not checked.
   - Frequency is low: 0 shared positions and 2 offset-0 nested insertions in the 5-Mb probe.
   - Fix: state in removed()'s docstring that X's own position and body offset 0 count as inside X's del_flank or
     replace, or drop offsets 0-4. Task 3 must read the same rule.

4. **Stale or loose test comments.**
   - test_popevents.py:214 says the elements are "too far for their losses to remove one another". A del_flank
     reaches 2,000 bp and the gap is 600 bp. They are kept because of the whole-span rule (C4b), not distance.
   - test_popevents.py:338: see Important 1.

5. **`Ins.time` is `np.float64` for nested insertions** (popevents.py:503). Primaries get a Python float
   (`tolist()`, popevents.py:469). Equality and JSON are unaffected, but reprs and types differ. Fix:
   `t = float(...)`.

## C4a (pending, not counted): current behavior and what the change touches

- **Now:**
  - `exists()` recurses into the host chain with each host's own ending-loss check (popevents.py:367, 371).
  - A nested y whose position survives its host's solo therefore loses every younger event below the solo.
  - test_thin_nested_in_solo_ltr pins this (test_popevents.py:500-511): y's replace on sample 0 is discarded, and
    so is a depth-2 insertion there.
- **Size:** an oracle variant without the host-chain ending check (oracle_c4a.py) keeps 1 more insertion and 4 more
  losses at 5 Mb.
- **Other places the change touches:**
  - test_thin_nested_in_solo_ltr's expected lists and counters flip.
  - test_nested_carriers_and_offsets asserts that no nested insertion lies below an ending loss of its host's
    host (test_popevents.py:323-327). Under C4a a depth-2 z in y, with y in x's surviving LTR, may lie below x's
    solo, so this assertion must narrow to the direct host.
  - The docstring needs editing: "and its host exists there" (popevents.py:58-60) and rule 4 (popevents.py:28-33).
    It must also name the B_X simplification that C4a asks for.
  - With the host-ending check gone, existence rests on the position check alone. So Minor 3's offset-0 edge
    becomes reachable: a nested insertion at offset 0 would survive its host's del_flank or replace.
  - removed() measures a nested del_flank in its host's original coordinates (popevents.py:308-309). For y in x's
    surviving solo LTR, y's end-side flank then runs into x's already-removed [a, len-ltr+a) and stops short of
    the 3' remnant. This is reachable only after C4a. Decide whether that is the intended convention, as it is for
    del_partial unions.
  - The report's audit line "0 nested insertions below an ending loss of a host in their chain" changes.

## Assessment

**Task quality: Needs fixes.**

Reasoning:
- The process law, the thinning and `removed()` are correct. An independent per-sample oracle agrees on every
  event at 2 and 5 Mb, the nested rate checks out by probe, and the conventions match Plan 1's pair simulator.
  Determinism holds, the engine is untouched, and M1-M5 are all fixed.
- Two Important items remain:
  - One test asserts a stale window and fails correct code in 35 of 80 seeds. It is a cheap fix.
  - The docstring states an exactness that does not hold on the replacing sequence, which is a third of the
    present sequence-time in the probe. That item is plan-mandated: the controller decides whether to name it or
    model it.
- Both items, and C4a, can go into fix round 1.

---

## Re-review (fix round 1)

Scope: commit 42607ad on 41f70b6 (diff `review-41f70b6..42607ad.diff`), against the rulings in task-2-fix-1.md.
Line numbers are those of 42607ad. The working tree is clean and was not modified.

Checks run:
- `tests/test_popevents.py`: 27 passed.
- Updated oracle (`p3t2review/oracle_fix1.py`): C4a (no ending check up the host chain); the junction rule on the
  per-sample union of removals; a new insertion's direct host must exist.
- Dense-landscape stress oracle (`p3t2review/stress_fix1.py`).
- `replace_deficit.py`, rerun at HEAD.

The commit uses the user identity and has no trailers. Its diff touches only `sim/popevents.py`,
`tests/test_popevents.py` and `docs/DESIGN.md`, so no engine module changed.

### Findings

**C4a (ruling): addressed.**
- `present()` (popevents.py:378-387) checks four things:
  - the element is below its event;
  - its carriers lie within the element's carriers;
  - its anchor survives the junction rule;
  - its host is present, recursively.
- `exists()` adds only the element's own ending losses (popevents.py:395).
- A new insertion needs its direct host to exist (popevents.py:402), as the original ruling's "its host exists"
  says. B_X still stops at X's ending losses, and this is named as a simplification (popevents.py:34-37).
- Everything the C4a section listed is updated:
  - test_thin_nested_in_solo_ltr is flipped and exact (test_popevents.py:536-553). I re-derived each expected value:
    - y at 50 keeps both its losses and the depth-2 z;
    - y2 at 1,000 loses its loss below the solo;
    - x_new, an insertion into x's solo LTR, is discarded.
  - test_nested_carriers_and_offsets is narrowed to the direct host (test_popevents.py:326-329).
  - The docstring's existence paragraph is rewritten (popevents.py:61-66).
  - The report's audit line is updated.
- The original-coordinates convention for a nested del_flank is stated (popevents.py:298-300). New Minor N1 notes
  one over-broad clause in that statement.

**I1 (stale nested-target test): addressed.**
- test_nested_target_not_on_n (test_popevents.py:339-357) now uses 7-bp periodic donors and asserts three things:
  - the code's window [pos-5, pos) (:354);
  - an exact offset class, pos mod 7 in {5, 6} (:355);
  - a one-sided case, some kept offset at 6 mod 7, whose next base is non-ACGT (:356).
- This holds for any seed: given over 50 nested insertions, the chance that none falls at 6 mod 7 is about 2^-50.
- The comment is fixed.

**I2 (replacing sequence, plan-mandated): addressed as ruled (named, not modeled).**
- Rule 4 no longer says "exactly" and names both simplifications (popevents.py:33-37).
- DESIGN 12 item 7 carries the numbers (DESIGN.md:742-745).
- My rerun of replace_deficit.py reproduces the report's figures: 460.3 expected insertions missing in replacing
  sequence (31.6% of 1,458 kept primaries) and 8.9 in simulated solo LTRs.

**Minor findings: all five addressed.**
- **M1 (nested-rate test):** test_nested_rate (test_popevents.py:360-384).
  - It uses TREE16, delta 0 and 5 seeds, at 3 SD.
  - The donors' body (8,000 bp) differs from their seq (5,100 bp), so a rate using len(seq) fails.
  - The rate is now lam x (len - 5) x B_X (popevents.py:520), consistent with offsets in [5, len)
    (popevents.py:528).
- **M2 (C2 side effects):** the module docstring now names both effects (popevents.py:67-72). My oracle's counts
  match the report: 79 insertions, 13 ending losses and 17 del_partials.
- **M3 (junction rule):** addressed.
  - Code: popevents.py:382-386.
  - Statement in removed()'s docstring: popevents.py:301-306. Nested offsets: popevents.py:528.
  - test_thin_same_position_del_flank (test_popevents.py:556-572) covers four cases with exact outcomes, each
    re-derived by hand: two-sided (w goes), end side only, start side only, and replace (w stays in the last three).
  - Drawn nested offsets now start at 5; there are no offsets under 5 at 5 Mb.
- **M4 (comment):** fixed (test_popevents.py:215-216).
- **M5 (float times):** fixed (popevents.py:527), and type-asserted for insertions and losses
  (test_popevents.py:319).

### Regression checks
- **Presence and the junction rule across host chains.**
  - On the 5-Mb probe, my updated oracle gives 0 disagreements over 3,673 drawn insertions and 2,867 drawn losses.
  - The kept and dropped counts reproduce the report: 2,325 insertions and 1,926 losses kept; dropped 627 / 721 /
    941.
  - The drawn landscape has no shared positions, so I also ran a dense stress test (stress_fix1.py):
    - a 4-kb backbone on TREE16, 60 seeds, three loss mixes;
    - 14,092 shared-position pairs, 13,775 kept depth-2 insertions, and 119 kept losses below a host's solo (C4a
      cases);
    - result: 0 disagreements between the oracle and `thin_events`.
  - The junction rule reduces to the old strict-inside rule for a single interval. It differs only where removals
    are adjacent or overlapping.
- **Test exactness.** All the changed thinning tests still assert exact lists and counters. The two statistical
  tests, test_nested_rate and test_thin_density, use 3 SD with fixed seeds.
- **removed()'s docstring for Task 3.** It is consistent with the code, with two precision gaps (N1, N2 below).

### New issues

**Critical:** none. **Important:** none.

**Minor**
- **N1. The flank example in removed()'s docstring states a conditional result as if it always held**
  (popevents.py:299-300).
  - It says a flank of an insertion in its host's solo LTR "stops ... short of the LTR's far part".
  - In original coordinates that holds only while b - TSD_DEFAULT is shorter than the solo's removed stretch
    (ltr + internal of the host).
  - A host with ltr + internal under about 2,000 bp (a short internal region, possible with real donor libraries)
    lets a 2,000-bp flank reach the far part.
  - Fix: "usually short of the far part", or state the condition.
- **N2. "Removed with its host" is not defined in removed()'s docstring** (popevents.py:60, 302).
  - Task 3's builder reads that docstring. It should say that the host counts as removed when its own anchor is
    removed by the same rule one level up, and that a host's ending loss alone (a solo) removes only the bases it
    takes.
  - The existence paragraph says this (popevents.py:65-66), but removed()'s docstring does not.
  - Fix: one clause in removed()'s docstring.

### Verdict

**Approved.** C4a, both Important findings and all five Minor findings are addressed as ruled. An independent
oracle confirms the presence and junction rules on the 5-Mb probe and on a dense stress landscape, with 0
disagreements. The changed tests remain exact. The two new items are docstring precision for Task 3 and can ride
along with Task 3's brief.
