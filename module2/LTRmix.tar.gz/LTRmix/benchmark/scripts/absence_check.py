#!/usr/bin/env python3
"""Validate ltrmix's library-only presence/absence calls against the partner's raw assembly (benchmark only).

For each element of genome A (status in B from orthologs.A.B.tsv.gz): junction k-mers (21-mers spanning either
element-flank boundary in A's genome) and empty-site k-mers (A's flanks joined across one 5-bp TSD copy = the
pre-insertion allele). In B's whole-genome k-mer set: junction k-mers on both sides -> 'occupied' (insertion
present in B); empty-site k-mers -> 'empty' (true absence); otherwise 'undetermined' (SNPs near the junction,
deletion, assembly gap). Reports the outcome by ltrmix status."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import argparse
import gzip
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, "/data2/chris/maize_introgression/LTRmix")
import ltrmix  # noqa: E402

K = ltrmix.K
CODE = np.full(256, 4, np.uint8)
for i, c in enumerate(b"ACGT"):
    CODE[c] = i
for i, c in enumerate(b"acgt"):
    CODE[c] = i


def read_genome(path):
    seqs, name, buf = {}, None, []
    with open(path, "rb") as f:
        for line in f:
            if line.startswith(b">"):
                if name:
                    seqs[name] = b"".join(buf)
                name, buf = line[1:].split()[0].decode(), []
            else:
                buf.append(line.strip())
    if name:
        seqs[name] = b"".join(buf)
    return seqs


def kmer_set(seqs):
    """Distinct canonical k-mers of a genome: each sequence indexed as a single record (index 0, so the packed key
    equals the k-mer when no record bits are used)."""
    parts = []
    for n in list(seqs):
        seq = np.frombuffer(seqs.pop(n), np.uint8)
        k = ltrmix._keys_of(seq, np.array([0, len(seq)], np.int64), K, 0)
        parts.append(np.unique(k))
    return np.unique(np.concatenate(parts))


def canon_kmers(s):
    out = []
    for i in range(len(s) - K + 1):
        w = s[i:i + K]
        c = CODE[np.frombuffer(w, np.uint8)]
        if (c > 3).any():
            continue
        f = 0
        r = 0
        for j, x in enumerate(c):
            f = (f << 2) | int(x)
            r |= (3 - int(x)) << (2 * j)
        out.append(min(f, r))
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--ortho", required=True, help="orthologs.A.B.tsv.gz from ltrmix")
    ap.add_argument("--genome-a", required=True)
    ap.add_argument("--genome-b", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--max", type=int, default=20000, help="elements per status class (random subset)")
    ap.add_argument("--names", help="file of element names (genome A) to check, one per line; no sampling")
    a = ap.parse_args()
    o = pd.read_csv(a.ortho, sep="\t")
    stcol = [c for c in o.columns if c.startswith("status_in_")][0]
    if a.names:
        want = set(x.strip() for x in open(a.names) if x.strip())
        o = o[o.iloc[:, 0].isin(want)].copy()
        if len(o) < len(want):
            print(f"warning: {len(want) - len(o)} names not in {a.ortho}", file=sys.stderr)
    else:
        parts = []
        for stv, g in o.groupby(stcol):
            parts.append(g.sample(min(len(g), a.max), random_state=1))
        o = pd.concat(parts)
    ga = read_genome(a.genome_a)
    J, E = [], []
    for c, s, e in zip(o.chrom, o.start, o.end):
        seq = ga.get(c)
        if seq is None or s < 40 or e + 40 > len(seq):
            J.append(([], [])), E.append([])
            continue
        left = seq[s - 1 - 20:s - 1 + 20]           # flank 20 bp | element 20 bp
        right = seq[e - 20:e + 20]                   # element 20 bp | flank 20 bp
        empty = seq[s - 1 - 25:s - 1] + seq[e + 5:e + 5 + 25]   # left flank incl. TSD + right flank after 2nd TSD
        J.append((canon_kmers(left), canon_kmers(right)))
        E.append(canon_kmers(empty[25 - K + 1:25 + K - 1]))     # only k-mers spanning the join
    del ga
    kb = kmer_set(read_genome(a.genome_b))
    print(f"B genome: {len(kb):,} distinct k-mers", file=sys.stderr, flush=True)

    def present(lst):
        if not lst:
            return 0.0
        q = np.array(lst, np.uint64)
        i = np.searchsorted(kb, q)
        i = np.clip(i, 0, len(kb) - 1)
        return float((kb[i] == q).mean())
    jl = [present(x[0]) for x in J]
    jr = [present(x[1]) for x in J]
    ee = [present(x) for x in E]
    o["junction_left"], o["junction_right"], o["empty_site"] = jl, jr, ee
    occ = (o.junction_left >= 0.5) & (o.junction_right >= 0.5)
    emp = o.empty_site >= 0.5
    o["genome_state"] = np.where(occ & ~emp, "occupied", np.where(emp & ~occ, "empty",
                                 np.where(occ & emp, "both", "undetermined")))
    o.to_csv(a.out + ".tsv.gz", sep="\t", index=False)
    tab = pd.crosstab(o[stcol], o.genome_state, normalize="index").round(3)
    tab["n"] = o.groupby(stcol).size()
    print(tab.to_string())
    tab.to_csv(a.out + ".summary.tsv", sep="\t")


if __name__ == "__main__":
    main()
