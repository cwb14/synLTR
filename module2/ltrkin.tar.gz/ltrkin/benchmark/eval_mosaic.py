#!/usr/bin/env python3
"""Score the two-parent (recombinant) test of `ltrkin source` on a simulated genealogy with template switches.
Truth: genealogy.tsv partner != '.' -> the copy's internal region = parent[:bp] + partner[bp:].
Reports detection among truly recombinant new copies (by parent-partner differences, which bound what any test can
see) and the false-positive rate among single-parent new copies. Usage: eval_mosaic.py SIMDIR LTRKIN_PREFIX"""
import sys
import mappy
import numpy as np
import pandas as pd
import pysam

sim, prefix = sys.argv[1], sys.argv[2]
G = pd.read_csv(f"{sim}/genealogy.tsv", sep="\t").set_index("copy_id")
if "partner" not in G:
    G["partner"] = "."
T = pd.read_csv(f"{sim}/truth.tsv", sep="\t").set_index("element_id")
S = pd.read_csv(f"{prefix}.sources.tsv", sep="\t")
flag = S.groupby("new_id")["flags"].apply(lambda f: f.str.contains("recombinant").any())
new = T[T.status == "new"].index
fa = pysam.FastaFile(f"{sim}/genome.fa")
gff = pd.read_csv(f"{sim}/elements.gff3", sep="\t", comment="#", header=None)
el = gff[gff[2] == "LTR_retrotransposon"]
lt = gff[gff[2] == "long_terminal_repeat"]
ids = el[8].str.extract(r"ID=([^;]+)")[0]
ltr_len = (lt[4] - lt[3] + 1).groupby(lt[8].str.extract(r"Parent=([^;]+)")[0]).first()
coords = {i: (c, s - 1 + ltr_len[i], e - ltr_len[i]) for i, c, s, e in zip(ids, el[0], el[3], el[4])}


def internal(i):
    c, s, e = coords[i]
    return fa.fetch(c, s, e)


def ndiff(a, b):
    h = next(iter(mappy.Aligner(seq=a, preset="asm5", best_n=1).map(b)), None)
    return h.NM if h else np.nan


rows = []
for n in new:
    if n not in flag.index:
        continue
    p, q = G.at[n, "parent"], G.at[n, "partner"]
    rec = q != "."
    pq = ndiff(internal(p), internal(q)) if rec and p in coords and q in coords else np.nan
    rows.append((n, rec, bool(flag[n]), pq))
d = pd.DataFrame(rows, columns=["id", "recombinant", "flagged", "parent_partner_diffs"])
r = d[d.recombinant]
print(f"new copies scored {len(d)}; truly recombinant {len(r)}; single-parent {(~d.recombinant).sum()}")
print(f"detection (recombinant flagged): {r.flagged.mean():.3f}; false positives (single-parent flagged): {d[~d.recombinant].flagged.mean():.3f}")
rr = r.dropna(subset=["parent_partner_diffs"]).copy()
rr["b"] = pd.cut(rr.parent_partner_diffs.astype(float), [-1, 5, 10, 20, 50, 1e9], labels=["<=5", "6-10", "11-20", "21-50", ">50"])
print("detection by parent-partner differences (both alive):")
for b, x in rr.groupby("b", observed=True):
    print(f"  {b}: n {len(x)}, detected {x.flagged.mean():.3f}")
print(f"recombinant with a parent or partner lost: {r.parent_partner_diffs.isna().sum()} (detection {r[r.parent_partner_diffs.isna()].flagged.mean():.3f})")
