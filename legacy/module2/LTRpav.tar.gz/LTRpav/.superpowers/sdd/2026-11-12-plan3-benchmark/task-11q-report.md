# Task 11 Part Q report: eval_run.py scores a painting LTRpav skipped

## What changed (sim/eval_run.py)
- painting_skip(st, R, S, D): matches findings.txt lines "[Painting: ]WARNING: Painting of R (sister S, donor D) skipped: <why>" for exactly that recipient, sister and donor (wording from snap paint.py line 642 and the run's findings.txt; both the detail and the "Painting: " summary forms match).
- paint_section: when the record exists it returns skipped_paint_section (n_tracts 0, n_tracts_q05 0, tract_fdr_q05 {n_false 0, n_called 0, fdr NA}; auroc, n_elements, n_elements_inside, true_bp, all, q05, recall_by_loci, true_tracts and n_posterior_elements NA "painting skipped by LTRpav: <why>"; stats rows kept; a nonzero stats n_tracts contradicting the record is an EvalError). The record takes priority over file presence, because posterior.A1.tsv can exist holding other trios' rows. No record: unchanged, including "missing input".
- Both callers (roles view via head_to_head_section, model views) go through paint_section, so no other change.
- sim/test_eval_run.py: 8 new test functions (12 cases).

## RED / GREEN
Scratch tree: /tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3t11q/tree (sim copies, symlinked common/ and snap/). RED (old eval_run.py): 6 failed, 12 passed (the 6 positive tests; the "no record -> missing input" and "other scope -> missing input" tests pin existing behavior and passed both before and after). Output: /tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3t11q/red.txt.
GREEN: test_eval_run.py 18 passed with python -W error. All sim tests, python -W error -m pytest test_*.py in the scratch tree: 78 passed.

## Real check (copy of runs/pc_null_r1 in /tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3t11q/run/pc_null_r1: views copied, geno/lib/ltrmix/sim symlinked; nothing written in runs/)
- eval_run.py --threads 4 -v: exit 0, "done: eval/eval.json (199 NA fields, 12.3 s)", parity ok ($S/real_eval_run.txt)
- eval_ltrmix.py -v (ltrmix env): exit 0, "done: eval/eval_ltrmix.json (13 NA fields)" ($S/real_eval_ltrmix.txt)
- eval.json fields that read the skip: head_to_head.paint and models.{main,any,decoy,anydecoy}: scope A1,B1;C1, n_tracts 0, n_tracts_q05 0, accuracy.tract_fdr_q05 0 of 0 (fdr NA), accuracy.auroc and the other accuracy fields NA with "painting skipped by LTRpav: no RD locus (C1 present, B1 E) in A1's own calls at the 4938 loci of A1: the HMM needs both classes"; head_to_head inferred_recipient NA (sheet order), wrong_recipient and wrong_trio NA (f = 0). e0_*/e1_* stay NA from stats.tsv. eval_ltrmix.py reads no painting file of LTRpav, so it needed no change.

## Install (atomic: written beside as .NAME.q.new, live sha256 checked against memo, then mv), 2026-11-14 12:58:26
- eval_run.py: 3dd0ca38238c5ba775957ea2a90dc95176b43dcbc2e19def3d0f71be891c6316 -> 52c05f127fe90bf2a93e80449ceb73c68f4dced0f69a88f1c91163deb8f43f77
- test_eval_run.py: 7764fc5603136d32bcebb01fa3c1dff47aa4ede291009cdf3a20eef1788c9337 -> 8112936e9101f8135c88394f845cc291fd918e0e82d1c695aa269268853b34b9
- sim/memo.md: entry appended in "Scoring fixes after the Part P smoke test".
Review package: /data2/chris/maize_introgression/LTRpav/.superpowers/sdd/2026-11-12-plan3-benchmark/task-11q-review-package.diff

## Concerns
- accuracy is a dict (auroc etc. NA, tract_fdr_q05 0 of 0) rather than one NA, so that 0 of 0 is recorded where summarize.py reads it; all its other keys are NA with the reason. Say so if a single NA was meant.
- A skipped painting with a true A1 tract and the right recipient is NA, not recall 0, as ruled. A wrong recipient with a true tract keeps the old recall-0 branch.
- Runs already finished with eval failure (pc_null_r1, r2) need a rescore (rescore_all.sh or the eval step); I did not touch them.
- The old eval.json files record the older eval_run.py sha256 (the consequence note in the memo applies).
