# Task 8 Part B review (Steps 9-11): pilot, realism, gate, and the harness changes

Reviewed 2026-11-13, 03:50-04:10. Sources:
- task-8-brief.md, Steps 9-11;
- task-8-rulings.md: R4, R5 and R9;
- progress.md:112-113, the rule-3 ruling and the like-for-like ruling;
- plan lines 147-205, "Compute budget";
- task-8a-review.md.

Paths are under `$P/benchmark_pav/plan3/` unless they are absolute. Testing:
- **Environment.** The checks ran in env ltrpav after sourcing a scratch copy of `common/env.sh`. They ran on copies
  or new outputs in `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t8breview/`:
  - the harness copy in `plan3/`, with `snap` symlinked read-only and its own numba cache;
  - copies of Part A's toy runs in `runs/`.
- **Read-only.** Nothing in plan3/, main3/, inputs/ or run/ was written. Every run of the real `run_one.sh` or
  `run_grid.sh` used `--dry-run`, which exits before any lock or write (run_one.sh:178-188, run_grid.sh:50-53). A
  `find -newer` over plan3/ shows no file from this review.
- **No drift.** The seven reviewed files have the same bytes at the end of the review as at its start.
- **Limits.** Nothing was installed, and every probe stayed at or below 16 threads.

## Spec Compliance

| Requirement | Verdict | Evidence |
|---|---|---|
| R9 m1: env ltrpav's bin always first on PATH; checks the `python` the scripts call | ✅ | env.sh:22-23 always prepends the bin and drops any later copy. env.sh:26-31 runs `python` from PATH and asserts `realpath(sys.prefix)` is the env. I tested these in `env -i` shells: (1) with the ltrmix bin first on PATH, `python` resolves to ltrpav's; (2) sourcing twice leaves PATH identical; (3) the script passes under `set -euo pipefail`; (4) a missing env (LTRPAV_ENV moved) gives rc 1, and with only ltrmix's python on PATH the message is `python on PATH is .../ltrmix/bin/python ... not env ltrpav's`. See m5 and m6 for two small gaps. |
| R9 m2: exclusive flock on `<rundir>/.lock`, one error line, nothing touched | ✅ | run_one.sh:194-195 runs before `rm -f run.exit` (:196) and before the trap (:197). I held the lock from another process. A second `run_one.sh` gave rc 1 and one line, and `run.exit` kept its planted value 7. The TSV lock (run_grid.sh:55-56) was refused the same way, and no marker was removed. |
| m2 semantics under `xargs -P 2` | ✅ | During a live toy grid, `lsof` shows each run's `.lock` held only by its own run_one, the GNU time process, the step shell and LTRmix (two disjoint sets), and both ran concurrently. After `kill -TERM` or `kill -KILL` of the whole group, no process was left. The `.lock` files remain but `flock -n` gets them at once, so a rerun is not blocked. |
| R9 m4: `--dry-run` runs the run-directory check | ✅ | `check_rundir` (run_one.sh:168-176) is called at :179 before anything is printed. The real pilot rows, dry-run without `--windows 5`, were refused with "simulated from another row or backbone". With `--windows 5`, they were accepted. |
| R9 measurement: tree PSS per step beside GNU peak RSS; load at each step's start | ✅ | run_one.sh:215-234; mem_sampler.sh:9-18 is real/mem_sampler.sh:7-14 without :15-25 (limit and kill); run_grid.sh:61-67. The pilot run.logs carry all four values per step. |
| R9 queue stop (PID 2932602) | ✅ (report) | task-8-report.md:330-340: stopped 01:41:43, 20 of 36 pair files, verified empty. plan3/real/ was not opened to recheck: the queue now runs as PID 2732713. |
| Step 9: pilot.tsv = two grid rows verbatim; detached launch; PID check | ✅ | `pilot.tsv` rows are byte-identical to grid.tsv's (`cat -A`). Launch and PID check: report:346-350. |
| Step 9: per-step wall and peak RSS; nodonor; realized counts vs estimates | ✅ | run.log in all four run directories. nodonor: memo, "discovery falls back to C2 in all four runs". I confirmed this in `runs/null_s101/views/nodonor/stats.tsv` (`disc=C2;present=C1`). Counts: report:374-382 (100 Mb) and the memo (50 Mb: 36 pair files, genomes 95.6-100.7 Mb). |
| Step 10 / R4: realism metrics, main3 side read from the right rows | ✅ | See "main3 side, rechecked" below: all 81 qc values, conflict, D_pav, paint, K, lengths and densities match my own recount. |
| Step 10 / R4: K of shared elements; named deficit sum(lam x a x B_R) over kept replaces | ✅ | realism.py:179-201: called P in A1>O1, plus truth P in all six others. deficit_replay.py:58-69 is line for line Task 2's reviewed replace_deficit.py, over `ev.losses` after thinning. The stream is replayed as pop.py:231-233 draws it. On my toy copy (5 x 1.5 Mb), the replay matches the run on every chromosome: 709.3 missing of 2,195 primaries (32.3%). |
| Like-for-like ruling (progress.md:113): conflict from the trio view, labeled | ✅ | realism.py:155-158 reads `views/main`. The discovery-set size goes into the item (`frac_E[disc=5 genomes]` against main3's `disc=2`), and the memo states "not like-for-like". |
| Step 11 / plan: the formula exactly | ✅ | gate.py:21-35: (N7 x h7 + 26 x h_trio)/2 + 3 x 1.4 + 22, with N7 = 88 + 30, then 88 + 10, each tested `<= 96` in rule order. |
| Gate outputs recomputed from the run logs | ✅ | See "Gate recomputation" below: 98.4 h with 10 nulls at 100 Mb, so the fallback; 70.1 h with 30 nulls at 50 Mb, so 30 nulls. |
| h7 "as defined before the pilot ran" | ⚠️ | The operational definition (gate.py:9-14; memo:82-85) is the plan's "measured 7-genome run": summed step walls, mean of the two runs, eval left out. It was written at 01:47 (gate.py mtime), which is after the launch (01:41:56) and after the sim times were logged. That is before any run's h7 existed (genotyping ended 02:44). The 100-Mb decision depends on the mean (Minor m4). |
| Rule-3 ruling (progress.md:112): measure at 50 Mb, do not extrapolate | ✅ | runs/<name>.100Mb moved aside. pilot_50Mb.log reran the same rows with `--windows 5`, and gate_50Mb.tsv was computed from them. |
| Grid regenerated with `--bneck-nulls N` | ✅ | I regenerated `make_grid.py --bneck-nulls 30 --out <scratch>`, and `cmp` shows it identical to grid.tsv. That gives 144 rows: null 30, power 36, reverse 8, ptlike 3, bneck 33, posctl 8, dropout 26. |
| The launch command accepts the pilot rows as done | ✅ | `run_grid.sh grid.tsv --windows 5 --dry-run` over the real runs/ ran 144 rows: 0 errors; null_s101 and f0.18_Ta5000_r1 skip every step (both now hold run.done after the other agent's eval); 142 rows get exactly 5 `--region`s. |

### main3 side, rechecked (realism.py:91-126 against the sources)
- **qc.** I extracted every `X>Y` row of `main3/qc_fixed/qc.tsv` with a `frac_*` or `resolved_frac` metric, 81
  rows, and joined them to realism's main3 rows. There were 0 differences (for example, B73>TIL18 resolved_frac
  0.463639, frac_O 0.173329).
- **stats.tsv** (`main3_analyses/stats.tsv`):
  - outgroup_conflict frac_E: B73 0.0267723 (n 11,990), TIL18 0.0323232, TIL01 0.031446, each with
    `disc=` two genomes.
  - D_pav `B73,TIL01;TIL18`, stratum all: D 0.290544, with n 2,041 informative loci. The n_RD row has n 14,067
    counted loci. Per Mb of TIL18 (2,493.69 Mb) that is 0.818 and 5.641.
  - Paint: n_informative 7,515 (3.444 per Mb of B73, 2,182.08 Mb); spacing_median 84,400; pi 0.35908.
  - main3 has exactly one D_pav scope and one paint scope, so the missing scope filter (m10) does not change any
    value today.
- **Lengths and densities.** Genome lengths come from the `.fai` files main3's samples.tsv points to. My recount of
  `main3/work/elements` gives:
  - B73: 127,636 elements (91,517 at level 0), 58.49 per Mb;
  - TIL18: 124,641, 49.98 per Mb;
  - TIL01: 137,847, 52.68 per Mb.
- **K.** B73 elements called P in `B73__Zd`: n 6,336, median 0.0603327, mean 0.0808582. At level 0: n 5,717, median
  0.0625362. All equal realism's values.

### Gate recomputation
I parsed the run.logs separately from gate.py, using the start and done timestamps as well as the "done in N s"
values. They agree to the second. Genotype time is the span from the ltrpav-genotype stamp to the ltrpav-merge stamp
in geno.log.

| backbone | run | steps (s) | genotype (s) | h7 (h) | h_trio (h) | 30 nulls (h) | 10 nulls (h) |
|---|---|---|---|---|---|---|---|
| 100 Mb | null_s101 | 240+3,484+455+711 = 4,890 | 3,466 | 1.3583 | 0.6362 | 114.61 | 101.03 |
| 100 Mb | f0.18_Ta5000_r1 | 233+3,573+163+628 = 4,597 | 3,547 | 1.2769 | 0.5380 | 108.53 | 95.76 |
| 100 Mb | mean | | | 1.3176 | 0.5871 | 111.57 | 98.40 |
| 50 Mb | null_s101 | 197+1,695+229+427 = 2,548 | 1,688 | 0.7078 | 0.3561 | 72.59 | 65.51 |
| 50 Mb | f0.18_Ta5000_r1 | 182+1,705+84+327 = 2,298 | 1,697 | 0.6383 | 0.2848 | 67.56 | 61.18 |
| 50 Mb | mean | | | 0.6731 | 0.3205 | 70.08 | 63.35 |

- **100 Mb.** Rules 1 and 2 both fail on the mean, so rule 3 (the 50-Mb fallback) applies.
- **50 Mb.** Rule 1 passes (70.1 ≤ 96), so 30 bottleneck nulls. This holds for each run alone and for the slower
  run, and it would still hold with eval (14-15 s per run) included: about +0.25 h. The margin is 25.9 h, or 26 min
  of h7 per run.
- **Grid estimate.** The grid alone is (118 x 0.673 + 26 x 0.320)/2 = 43.9 h, matching the brief's "about 44 h".

## Strengths
- **The run signature makes the fallback hard to get wrong.**
  - The signature holds the row text, backbone, window count and regions (run_one.sh:79, :173-175, :233).
  - The 50-Mb pilot rows are accepted only with `--windows 5`, and refused loudly without it.
  - The whole-grid dry-run passes cleanly.
- **The failure and rerun cycle is correct.** I tested it end to end on toy copies:
  - **Injected failures.** I put a plain file at `views/any` in the trio run and removed `sim/C2.gff3` in the null
    run. Both rows failed: `.failed` listed them with exit 1, `run.exit` was 1, and the markers stopped at the last
    good step.
  - **Repair and rerun.** After the repair, the views step reused `views/main` and `views/roles`; stats and paint
    were skipped by their own markers. ltrmix reran from a clean `lib/`. Both rows ended with `.done`, exit 0,
    and no leftover process.
  - **Killed runs.** Runs killed with TERM and with KILL, in the middle of LTRmix, reran to `.done` from their
    markers.
- **The locks are well placed.**
  - The lock is taken before `run.exit` is cleared and before the trap is set, so a refused launch changes nothing.
  - The steps inherit fd 9, so an orphaned step keeps its directory locked.
  - Both samplers are started with the lock's fd closed (`9>&-` and `8>&-`).
- **The measurement is cheap and faithful.**
  - The sampler is real/mem_sampler.sh's tree walk and Pss sum, with the guard removed.
  - On a 41-process synthetic tree (8.3 GB PSS) one pass cost about 0.35-0.45 s of CPU. That is about 8% of one
    core per sampler, and under 1% of the grid's 32 threads for the three samplers.
  - Pilot intervals average 5.8-7.2 s at load 150-216, so no sample loop stalled.
  - The sampler exits within one interval after its target is reaped, and the stop file stops it at once.
- **The rule-3 measurement replaced an extrapolation.** The 50-Mb h7 is measured, and those two runs are grid rows
  the grid now skips, so no compute was wasted.
- **The deficit replay checks itself.** It refuses to report unless the replayed trees, insertions, losses and SNPs
  equal the run's own per-chromosome record (deficit_replay.py:111-127). It also checks Demog and Rates against
  params.json (:88-89).

## Issues

### Critical
None.

### Important
None.

### Minor
- **m1. A TERM kill writes exit 0 to `run.exit` and `<TSV>.exit`.**
  - **Cause.** In bash, an EXIT trap that runs on a fatal signal sees `$?` as the last finished command's status,
    not 143. The traps at run_one.sh:197 and run_grid.sh:59 record `$?`. This bug was already present in Part A.
  - **Reproduced.** I sent `kill -TERM -- -PGID` to a toy grid during ltrmix. Afterward:
    - both rows' `run.exit` read 0;
    - `toy.tsv.exit` read 0;
    - neither `.done` nor `.failed` was written.

    A minimal `bash -c 'trap … EXIT; sleep 30 & wait $!'` killed by TERM also shows rc=0 in the trap, while the shell
    exits 143.
  - **What it does not break.** No marker is written, reruns skip by markers, and `.done` cannot be faked.
    summarize.py:330-332 would label such a run "unscored" instead of "failed".
  - **What it does break.** A Monitor keyed on `grid.tsv.exit` would read success after a group kill, and group
    kill is the documented stop method (R2).
  - **Fix (before launch).** Add `trap 'exit 143' TERM; trap 'exit 130' INT` before each EXIT trap.
- **m2. Forgetting `--windows 5` would cost days, and the harness guards only the two pilot rows.**
  - **Cause.** The window count lives only on the command line: WINDOWS defaults to 10 (run_one.sh:34) and is
    passed on at run_grid.sh:47.
  - **Effect.** Without the option, null_s101 (row 1) and f0.18_Ta5000_r1 are refused in the first second. The
    other 142 rows run at 100 Mb, about 111 h.
  - **Fix.** Have the controller run the dry-run first:
    `run_grid.sh grid.tsv --windows 5 --dry-run 2>&1 | grep -c error` must print 0 (I ran it: 0), and the two pilot
    rows must show "marker exists: skip". Then check that the first lines of the real log are skips. A stronger fix
    is for run_grid to refuse to start when any existing `sim.done` has another signature.
- **m3. Steps now run in the background, so they ignore SIGINT and SIGQUIT.**
  - **Cause.** run_one.sh:218-219 starts each step with `&` in a non-interactive shell, and bash then sets SIGINT and
    SIGQUIT to ignored. I measured `SigIgn: 0x6` on such jobs and on `/usr/bin/time`'s child. Python keeps an
    inherited ignored SIGINT.
  - **Effect.** Ctrl-C on a hand-run `run_one.sh`, or `kill -INT` to the group, kills run_one but leaves the step
    running. The orphan keeps the lock, so a relaunch is refused until it ends. Group TERM still stops everything
    (tested).
  - **Fix.** Document TERM as the stop signal, or run `trap - INT QUIT` inside the step's `bash -c`.
- **m4. The 100-Mb fallback rests on the mean of the two runs, which is not recorded as a sensitivity.**
  - **The split.** In gate_100Mb.tsv:2-3, the two runs disagree: the null run alone gives the fallback, while the
    f0.18 run alone gives 10 nulls at 100 Mb (95.8 h ≤ 96). That is still 95.96 h with its 15-s eval.
  - **Why the mean is acceptable.**
    - It is the natural estimator.
    - It was fixed (gate.py:14) before any h7 existed.
    - The plan's "the pilot's measured 7-genome run" does not choose between the runs.
  - **What is missing.** The memo's 100-Mb line (memo:143-144) gives only the mean.
  - **Fix.** Add the per-run split to the 100-Mb line. Also state that the definition was fixed after launch and
    before genotyping ended, not "before any pilot time" (progress.md:111).
- **m5. A missing env is reported, but not named.** With LTRPAV_ENV absent and no other `python` on PATH, the
  message is `env.sh: <path>/env.sh: line 40: python: command not found` (env.sh:26, :40). A check such as
  `[[ -x $LTRPAV_ENV/bin/python ]] || { echo "env.sh: env ltrpav not found at $LTRPAV_ENV" >&2; return 1; }` would
  name it. A wrong `SNAP_SHA` gives a Python traceback instead of a one-line error.
- **m6. PATH dedup misses adjacent duplicates (env.sh:22).** Given `…:X:X:…`, the global `${//":X:"/":"}`
  replacement consumes the shared colon, so one later copy of X survives. Tested: `/usr/bin:X:X:/bin` became
  `X:/usr/bin:X:/bin`. This is harmless, since X is first. Repeated sourcing is stable.
- **m7. The PSS summary can abort a run after a very short step.** run_one.sh:228 runs `awk` on `$s.mem.tsv` under
  `set -e`, before the rc check at :229. If a step ends before the sampler writes its header, awk fails. The run then
  exits 2, without the "FAILED" line, or reads a stale file from an earlier attempt. Real steps take at least 14 s,
  so the grid is not affected. Fix: `pss=$(awk … 2>/dev/null || echo "NA")`.
- **m8. run_one's samplers keep the grid lock's fd (run_one.sh:223 closes only fd 9).** The orphaned `sleep 5` of a
  sampler killed at the end of a step holds `<TSV>.lock` for up to 5 s, as `lsof` shows. A relaunch within 5 s of
  the grid's end would be refused. Add `8>&-`.
- **m9. run_grid clears every row's `run.exit` before it holds the rows' locks (run_grid.sh:58).** A second
  run_grid on another TSV that shares rows can delete a finished row's `run.exit` under a live grid. The live grid
  would then list that row as failed (`none`). This needs two concurrent grids, so it does not arise with one grid
  launch.
- **m10. gate.py and realism.py: small inconsistencies.**
  - **eval timing.** gate.py:41's regex includes eval, while its docstring (:10-11) says eval is not measured. A
    rerun now, after the other agent's eval, adds about 15 s per run: 70.1 h becomes about 70.4 h, and the decision
    is unchanged.
  - **The fallback label.** gate.py prints "50-Mb fallback" when `decide` is None, even when it is run on 50-Mb
    runs, where no further fallback exists (:70, :74, :78).
  - **Scope filters.** realism.py:110 and :118 do not filter main3's D_pav and paint rows by scope; the values are
    correct today (one scope each).
- **m11. Analyses rerun inside a moved-aside 100-Mb view would read the 50-Mb genomes.**
  - **Cause.** view.sh writes absolute paths. In `runs/null_s101.100Mb/views/main/`, both `samples.tsv` and `.view`
    point at `runs/null_s101/sim/*` and `runs/null_s101/geno`, which now hold the 50-Mb run. The views' pair and
    loci links are relative, so they still point inside `.100Mb`.
  - **Effect.** Existing outputs are intact. realism.py reads only run-relative files, so its 100-Mb numbers are
    correct. But any later stats, paint or eval rerun in those views would mix 100-Mb loci with 50-Mb sequence.
  - **Fix.** Keep them read-only, as the memo says, and add this reason to the memo.

## Observations (not defects)
- **Memory.** Memory is no longer guarded, which R9 permits: it asked for measurement. The grid's measured peak
  summed PSS is 11.06 GB at 50 Mb and 22.29 GB at 100 Mb, against the 250-GB cap.
- **The real-genome queue.** It is running again (PID 2732713). The memo (memo:157) leaves stopping it before the
  grid launch to the controller. Running both would exceed 32 threads.
- **Gap calls in the simulations.** The realism readout shows frac_G 5.5-6.1% in the simulations against 0.02% in
  main3. This is reported and not tuned, as R4 requires. It is outside this harness review, but worth a sentence
  when the realism table is read.

## Assessment
**Approved.**
- **Spec compliance** passes. There is one ⚠️: the h7 definition was fixed after the launch but before h7 existed
  (m4, documentation only).
- **Correctness.** There are no Critical or Important issues. The command `run_grid.sh grid.tsv --windows 5`:
  - runs the 144 rows at 50 Mb;
  - skips both pilot rows;
  - keeps two independent locks under `xargs -P 2`;
  - recovers from step failures and kills by marker.
- **Gate.** Both gate decisions reproduce from the logs.
- **Before the launch.**
  - Fix m1: two `trap` lines.
  - Run m2's dry-run check, and stop the real-genome queue.
- **The other Minors** can wait.
