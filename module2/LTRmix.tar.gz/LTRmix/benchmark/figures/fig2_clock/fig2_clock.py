#!/usr/bin/env python3
"""Fig. 2 (fig2_clock): the LTR clock separates gene flow from lineage sorting (maize B73, parviglumis TIL01,
mexicana TIL18). Rebuilds everything from the result tables (numbers) and the raw data (drawings):
fig2_clock.pdf (figure + short legend + long legend), fig2_clock.png (300 dpi, figure only), fig2_clock_numbers.tsv.

Run:  source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix; python fig2_clock.py [-v]
"""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import argparse
import glob
import json
import os
import re
import subprocess
import sys
import tempfile

import edlib
import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.backends.backend_pdf import PdfPages  # noqa: E402
from matplotlib.patches import FancyArrowPatch, Polygon, Rectangle  # noqa: E402

ROOT = "/data2/chris/maize_introgression"
MAIN = f"{ROOT}/benchmark/results/main3"
EDTA = f"{ROOT}/benchmark/edta/out/stats.tsv"
SIM = f"{ROOT}/benchmark/sim/eval"
WGK = f"{ROOT}/benchmark/wgk"
GSNP = f"{ROOT}/benchmark/gene_snp/run_gene_snp.log"
ABS = f"{ROOT}/benchmark/absence/B73v5.TIL01.tsv.gz"
RUN = f"{ROOT}/run"
FA = {g: f"{ROOT}/inputs/{g}.fa" for g in ("B73v5", "TIL18", "TIL01")}
OUT = os.path.dirname(os.path.abspath(__file__))
STEM = "fig2_clock"
DATE = "2026-11-07"

MU = 3e-8                      # substitutions per site per year (age = K2P / 2 mu)
KYR = 1.0 / (2 * MU) / 1e3     # kyr per unit K2P
EDGES = [0, 1e-9, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1]          # ltrmix age strata (right-closed)
STRATA = ["K2P 0", "K2P (0,0.002]", "K2P (0.002,0.005]", "K2P (0.005,0.01]", "K2P (0.01,0.02]",
          "K2P (0.02,0.05]", "K2P (0.05,0.1]", "K2P >0.1"]

# the example (selection rule and checks in memo.md): one young B73+TIL18 insertion absent from TIL01
EX = dict(B="B73v5_chr1:300732131-300741649#LTR/Gypsy/Retand", M="TIL18_chr1:324713252-324722768#LTR/Gypsy/Retand")
WIN = dict(B73v5=("B73v5_chr1", 300_695_001, 300_800_000), TIL18=("TIL18_chr1", 324_676_122, 324_781_121),
           TIL01=("TIL01_chr1", 312_035_001, 312_095_000))

# colors (fixed across the figures of this project)
MEX, PAR, MZ, CTX = "#D55E00", "#0072B2", "#333333", "#BBBBBB"
MEX_L, PAR_L = "#F4C7AB", "#A9CCE6"
VERBOSE = False


def log(*a, v=False):
    if VERBOSE or not v:
        print(*a, file=sys.stderr, flush=True)


# ---------------------------------------------------------------------------------------------------------------------
# data
# ---------------------------------------------------------------------------------------------------------------------
def read_lib(g, cols=("#seq_id", "k2p")):
    fs = sorted(glob.glob(f"{RUN}/{g}_LTRs_depth*_clean_ltr.tsv"))
    if not fs:
        sys.exit(f"error: no LTR library tables for {g} in {RUN}")
    x = pd.concat([pd.read_csv(f, sep="\t", usecols=list(cols)) for f in fs]).drop_duplicates("#seq_id")
    return x.set_index("#seq_id")


def stats_table(path):
    s = pd.read_csv(path, sep="\t", low_memory=False)
    return s


def shared_insertions(k18):
    """Every insertion shared by a sister and TIL18 and absent from the other sister, exactly as ltrmix counts them
    (recipient-side records; the clock is the donor copy's LTR-LTR K2P)."""
    r = lambda f: pd.read_csv(f"{MAIN}/{f}", sep="\t")
    b18, b01 = r("orthologs.B73v5.TIL18.tsv.gz"), r("orthologs.B73v5.TIL01.tsv.gz")
    t18, tb = r("orthologs.TIL01.TIL18.tsv.gz"), r("orthologs.TIL01.B73v5.tsv.gz")
    assert (b18.B73v5.values == b01.B73v5.values).all() and (t18.TIL01.values == tb.TIL01.values).all()
    A = b18.loc[(b18.TIL18 != ".") & (b01.status_in_TIL01 == "absent"), ["B73v5", "chrom", "start", "end", "TIL18",
                                                                          "divergence", "same_tsd"]].copy()
    B = t18.loc[(t18.TIL18 != ".") & (tb.status_in_B73v5 == "absent"), ["TIL01", "TIL18", "divergence"]].copy()
    # symmetric resolution (ltrmix): the donor copy must also be absent from the other sister through TIL18's own
    # synteny with it, so both patterns need TIL18's synteny with both sisters
    d01 = r("orthologs.TIL18.TIL01.tsv.gz").set_index("TIL18").status_in_TIL01
    d73 = r("orthologs.TIL18.B73v5.tsv.gz").set_index("TIL18").status_in_B73v5
    A = A[d01.reindex(A.TIL18).values == "absent"].copy()
    B = B[d73.reindex(B.TIL18).values == "absent"].copy()
    for X in (A, B):
        X["k2p"] = k18.reindex(X.TIL18).values
        if X.k2p.isna().any():
            sys.exit("error: donor copies without K2P in the TIL18 library")
        X["stratum"] = np.digitize(X.k2p.values, EDGES[1:], right=True)
    return A, B


def null_sims():
    rows = []
    for f in sorted(glob.glob(f"{SIM}/null_s1*.json")):
        s = open(f).read().strip()
        if s:
            rows.append(json.loads(s))
    x = pd.DataFrame(rows)
    if len(x) != 30:
        log(f"warning: {len(x)} null simulation runs (expected 30)")
    sgn = np.where(x.recipient_called == "B", 1.0, -1.0)       # sign toward the true recipient B
    x["youngB"], x["oldB"] = sgn * x.Dins_young, sgn * x.Dins_old
    return x


def jack(a, b, blk):
    """5-Mb delete-one-block jackknife of D = (A - B) / (A + B), as in benchmark/scripts/eval_wgk.py."""
    ub, inv = np.unique(blk, return_inverse=True)
    A, B = np.bincount(inv, a, len(ub)), np.bincount(inv, b, len(ub))
    D = (A.sum() - B.sum()) / (A.sum() + B.sum())
    jk = np.array([((A.sum() - A[i]) - (B.sum() - B[i])) / (A.sum() + B.sum() - A[i] - B[i]) for i in range(len(ub))])
    return D, np.sqrt((len(jk) - 1) / len(jk) * ((jk - jk.mean()) ** 2).sum())


def comparators():
    out = {}
    for kind, lab in (("all", "wgk_all"), ("noLTR", "wgk_noLTR")):
        d = pd.read_csv(f"{WGK}/wgk_{kind}.TIL18.tsv", sep="\t")
        D, se = jack(d.with_B73v5.values.astype(float), d.with_TIL01.values.astype(float),
                     (d.chrom + ":" + (d.start // 5_000_000).astype(str)).values)
        out[lab] = (D, se, f"{WGK}/wgk_{kind}.TIL18.tsv (5-Mb jackknife as eval_wgk.py)")
    m = re.search(r"D = ([+-][\d.]+) \+- ([\d.]+) \(Z = ([\d.]+)\)", open(GSNP).read())
    out["gene_snp"] = (float(m.group(1)), float(m.group(2)), GSNP)
    return out


def faidx(g, region):
    s = subprocess.run(["samtools", "faidx", FA[g], region], capture_output=True, text=True, check=True).stdout
    return "".join(s.split("\n")[1:]).upper()


def parse_name(n):
    m = re.match(r"^(.+):(\d+)-(\d+)#", n)
    return m.group(1), int(m.group(2)), int(m.group(3))


def example():
    """Re-extract the example's two copies and the TIL01 site from the assemblies and verify its structure."""
    libB = read_lib("B73v5", ("#seq_id", "k2p", "tsd", "motif", "ltr5_len", "ltr3_len", "seq_len", "family",
                              "confidence", "nest_status"))
    libM = read_lib("TIL18", ("#seq_id", "k2p", "tsd", "motif", "ltr5_len", "ltr3_len", "seq_len", "family",
                              "confidence", "nest_status"))
    rb, rm = libB.loc[EX["B"]], libM.loc[EX["M"]]
    cB, sB, eB = parse_name(EX["B"])
    cM, sM, eM = parse_name(EX["M"])
    F = 20
    seqB = faidx("B73v5", f"{cB}:{sB - F - 5}-{eB + 5 + F}")
    seqM = faidx("TIL18", f"{cM}:{sM - F - 5}-{eM + 5 + F}")
    elB, elM = seqB[F + 5:-(F + 5)], seqM[F + 5:-(F + 5)]
    tsdB = (seqB[F:F + 5], seqB[-(F + 5):-F])
    tsdM = (seqM[F:F + 5], seqM[-(F + 5):-F])
    L = int(rb.ltr5_len)
    chk = {}
    chk["tsd_B73_both_ends"] = tsdB[0] == tsdB[1] == rb.tsd
    chk["tsd_TIL18_both_ends"] = tsdM[0] == tsdM[1] == rm.tsd == rb.tsd
    chk["TG..CA_B73"] = elB[:2] == "TG" and elB[-2:] == "CA"
    chk["TG..CA_TIL18"] = elM[:2] == "TG" and elM[-2:] == "CA"
    ltrB = edlib.align(elB[:L], elB[-L:], task="path")
    ltrM = edlib.align(elM[:int(rm.ltr5_len)], elM[-int(rm.ltr3_len):], task="path")
    chk["LTRs_identical_B73"] = ltrB["editDistance"] == 0
    chk["LTRs_identical_TIL18"] = ltrM["editDistance"] == 0
    cp = edlib.align(elB, elM, task="path")
    nice = edlib.getNiceAlignment(cp, elB, elM)
    diffs, pos = [], 0
    for x, y in zip(nice["query_aligned"], nice["target_aligned"]):
        if x != "-":
            pos += 1
        if x != y:
            diffs.append((pos, "indel" if "-" in (x, y) else "sub"))
    # TIL01 empty site: B73's flanks joined across one TSD copy, searched in the syntenic TIL01 window
    lf, rf = seqB[:F], seqB[-F:]
    c01, s01, e01 = WIN["TIL01"]
    w01 = faidx("TIL01", f"{c01}:{s01}-{e01}")
    probe = lf[-10:] + rb.tsd + rf[:10]
    hits = [m.start() for m in re.finditer(probe, w01)]
    chk["TIL01_empty_site_unique"] = len(hits) == 1
    h = hits[0] - (F - 10)
    site01 = w01[h:h + F + 5 + F]
    pos01 = s01 + h                       # 1-based start of the 20-bp left flank in TIL01
    chk["TIL01_single_TSD"] = site01[F:F + 5] == rb.tsd
    ab = pd.read_csv(ABS, sep="\t").set_index("B73v5")
    chk["absence_table_empty"] = ab.loc[EX["B"], "genome_state"] == "empty"
    if not all(chk.values()):
        sys.exit(f"error: example failed structural checks: {chk}")
    flank_snps = [i for i in range(F) if not (seqB[i] == seqM[i] == site01[i])]
    rfl = [i for i in range(F) if not (seqB[-F + i] == seqM[-F + i] == site01[F + 5 + i])]
    return dict(seqB=seqB, seqM=seqM, site01=site01, pos01=pos01, F=F, tsd=rb.tsd, L=L, lenB=len(elB),
                lenM=len(elM), diffs=diffs, n_sub=sum(1 for d in diffs if d[1] == "sub"),
                n_indel=sum(1 for d in diffs if d[1] == "indel"), checks=chk, family=rb.family,
                flank_snps=flank_snps, rflank_snps=rfl, strand="-", libB=libB, libM=libM,
                kB=float(rb.k2p), kM=float(rm.k2p), ltr_len=(int(rb.ltr5_len), int(rb.ltr3_len)))


def window_elements(g):
    c, s, e = WIN[g]
    lib = read_lib(g, ("#seq_id", "seq_len", "ltr5_end", "ltr3_start", "k2p", "strand", "tsd", "nest_status"))
    nm = lib.index.to_series()
    m = nm.str.extract(r"^(.+):(\d+)-(\d+)#")
    w = lib[(m[0] == c).values & (m[2].astype(float) > s).values & (m[1].astype(float) < e).values].copy()
    pm = w.index.to_series().str.extract(r"^(.+):(\d+)-(\d+)#")
    w["s"], w["e"] = pm[1].astype(int).values, pm[2].astype(int).values
    return w.sort_values("s")


def cs_blocks(paf_line, min_indel=50):
    """Collinear gap-free blocks of a minimap2 PAF line (split at indels >= min_indel), with mismatch positions."""
    f = paf_line.rstrip("\n").split("\t")
    cs = [x for x in f[12:] if x.startswith("cs:Z:")][0][5:]
    q, t = int(f[2]), int(f[7])
    out, bq, bt, mism = [], q, t, []
    for op, val in re.findall(r"([:*+\-~])([0-9a-z]+)", cs):
        if op == ":":
            q += int(val)
            t += int(val)
        elif op == "*":
            mism.append(t)
            q += 1
            t += 1
        else:
            n = len(val)
            if n >= min_indel:
                out.append((bq, q, bt, t, mism))
                bq, bt, mism = (q + n, t, []) if op == "+" else (q, t + n, [])
                if op == "+":
                    q += n
                else:
                    t += n
            elif op == "+":
                q += n
            else:
                t += n
    out.append((bq, q, bt, t, mism))
    return out


def window_alignments():
    """Align the TIL18 and TIL01 windows to the B73 window (minimap2 asm10); returns blocks in absolute coords."""
    res = {}
    with tempfile.TemporaryDirectory(dir=OUT) as tmp:
        for g in WIN:
            c, s, e = WIN[g]
            with open(f"{tmp}/{g}.fa", "w") as fo:
                fo.write(f">{g}\n{faidx(g, f'{c}:{s}-{e}')}\n")
        for g in ("TIL18", "TIL01"):
            p = subprocess.run(["minimap2", "-t", "2", "-cx", "asm10", "--cs", f"{tmp}/B73v5.fa", f"{tmp}/{g}.fa"],
                               capture_output=True, text=True, check=True).stdout
            bl = []
            for line in p.strip().split("\n"):
                if line and line.split("\t")[4] == "+":
                    for qs, qe, ts, te, mm in cs_blocks(line):
                        if te - ts >= 300:
                            bl.append((WIN[g][1] + qs, WIN[g][1] + qe, WIN["B73v5"][1] + ts, WIN["B73v5"][1] + te,
                                       [WIN["B73v5"][1] + x for x in mm]))
            res[g] = sorted(bl, key=lambda b: b[2])
    return res


def load():
    st = stats_table(f"{MAIN}/stats.tsv")
    ed = stats_table(EDTA)
    k18 = read_lib("TIL18").k2p
    A, B = shared_insertions(k18)
    ag = st[st.test == "D_ins_by_age"].set_index("stratum").reindex(STRATA)
    # the per-element listing must reproduce the table's counts exactly
    nA = np.bincount(A.stratum, minlength=8)
    nB = np.bincount(B.stratum, minlength=8)
    if not ((nA == ag.nA.astype(int).values).all() and (nB == ag.nB.astype(int).values).all()):
        sys.exit(f"error: per-element counts {nA}/{nB} differ from stats.tsv {ag.nA.values}/{ag.nB.values}")
    log(f"shared insertions: {len(A)} B73+TIL18, {len(B)} TIL01+TIL18 (match stats.tsv per stratum)", v=True)
    # identity spectrum (table) and a raw-data check of its counts
    idn = st[st.test == "identity_spectrum"].copy()
    fl = st[(st.test == "f_lower_bound")].iloc[0]
    # ltrmix uses donor copies resolved in both sisters (symmetric coverage)
    rT = pd.read_csv(f"{MAIN}/orthologs.B73v5.TIL18.tsv.gz", sep="\t")
    rM = pd.read_csv(f"{MAIN}/orthologs.TIL01.TIL18.tsv.gz", sep="\t")
    s01 = pd.read_csv(f"{MAIN}/orthologs.TIL18.TIL01.tsv.gz", sep="\t").set_index("TIL18").status_in_TIL01
    s73 = pd.read_csv(f"{MAIN}/orthologs.TIL18.B73v5.tsv.gz", sep="\t").set_index("TIL18").status_in_B73v5
    rawT = rT.divergence[(rT.TIL18 != ".").values & (s01.reindex(rT.TIL18).values != "unresolved")]
    rawM = rM.divergence[(rM.TIL18 != ".").values & (s73.reindex(rM.TIL18).values != "unresolved")]
    bins = np.array([0, 1e-9, 2.5e-4, 5e-4, 1e-3, 2e-3, 4e-3, 8e-3, 1.6e-2, 3.2e-2, 6.4e-2, 1.0])
    hT = np.histogram(rawT.dropna(), bins)[0]
    hM = np.histogram(rawM.dropna(), bins)[0]
    if not ((hT == idn.n_target.astype(int).values).all() and (hM == idn.n_mirror.astype(int).values).all()):
        log("warning: raw ortholog divergences do not reproduce the identity-spectrum counts exactly")
    d = dict(st=st, ed=ed, A=A, B=B, ag=ag, idn=idn, fl=fl, bins=bins, sims=null_sims(), comp=comparators())
    d["near_thr"] = float(st.loc[st.test == "hmm_recent", "near_threshold"].iloc[0])
    log("example: re-extracting and verifying", v=True)
    d["ex"] = example()
    d["win"] = {g: window_elements(g) for g in WIN}
    d["aln"] = window_alignments()
    # every B73 element in the window: status in TIL18 / TIL01 and the donor copy's K2P
    b18 = pd.read_csv(f"{MAIN}/orthologs.B73v5.TIL18.tsv.gz", sep="\t").set_index("B73v5")
    b01 = pd.read_csv(f"{MAIN}/orthologs.B73v5.TIL01.tsv.gz", sep="\t").set_index("B73v5")
    w = d["win"]["B73v5"]
    w["in18"], w["orth18"] = b18.status_in_TIL18.reindex(w.index).values, b18.TIL18.reindex(w.index).values
    w["div18"] = b18.divergence.reindex(w.index).values
    w["in01"], w["orth01"] = b01.status_in_TIL01.reindex(w.index).values, b01.TIL01.reindex(w.index).values
    w["div01"] = b01.divergence.reindex(w.index).values
    w["k18"] = k18.reindex(w.orth18).values
    return d


# ---------------------------------------------------------------------------------------------------------------------
# drawing helpers (all layout in mm)
# ---------------------------------------------------------------------------------------------------------------------
W, H = 180.0, 232.0
PANELS = dict(A=(0, 0, 60, 64), B=(62, 0, 118, 64), C=(0, 67, 180, 41), D=(0, 111, 180, 66),
              E=(0, 180, 84, 52), F=(90, 180, 90, 52))


def setup_rc():
    from matplotlib import font_manager
    for f in sorted(glob.glob("/usr/share/fonts/truetype/liberation*/Liberation*.ttf")):
        font_manager.fontManager.addfont(f)
    names = {f.name for f in font_manager.fontManager.ttflist}
    if "Liberation Sans" not in names or "Liberation Mono" not in names:
        sys.exit("error: Liberation Sans / Liberation Mono fonts not found")
    plt.rcParams.update({
        "font.family": "Liberation Sans", "font.size": 7, "axes.linewidth": 0.6, "axes.labelsize": 7,
        "xtick.labelsize": 6.5, "ytick.labelsize": 6.5, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "xtick.major.size": 2.2, "ytick.major.size": 2.2, "xtick.minor.size": 1.2, "ytick.minor.size": 1.2,
        "xtick.minor.width": 0.5, "pdf.fonttype": 42, "ps.fonttype": 42, "mathtext.fontset": "custom",
        "mathtext.rm": "Liberation Sans", "mathtext.it": "Liberation Sans:italic", "mathtext.bf": "Liberation Sans:bold",
        "mathtext.cal": "Liberation Sans", "mathtext.sf": "Liberation Sans", "mathtext.tt": "Liberation Mono",
        "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False})


def ax_mm(fig, x, y, w, h, **kw):
    """Axes whose top-left corner is (x, y) mm from the figure's top-left."""
    return fig.add_axes([x / W, 1 - (y + h) / H, w / W, h / H], **kw)


def canvas(fig, x, y, w, h):
    """Axes in mm data coordinates (origin bottom-left), no frame."""
    a = ax_mm(fig, x, y, w, h)
    a.set_xlim(0, w)
    a.set_ylim(0, h)
    a.axis("off")
    return a


def letter(fig, k):
    x, y, _, _ = PANELS[k]
    fig.text((x + 0.2) / W, 1 - (y + 0.2) / H, k, fontsize=10, fontweight="bold", va="top", ha="left")


def it(s):
    """Italic run inside mathtext (spaces escaped)."""
    return r"$\mathit{" + s.replace(" ", r"\ ") + "}$"


def element(ax, s, e, y, ltr5, ltr3, strand, col_ltr, col_int, h=2.4, hi=1.3, lw=0.0, ec="none", z=3):
    """An LTR-RT drawn to size: internal region (thin) and two LTRs (pentagons pointing along the strand)."""
    ax.add_patch(Rectangle((s, y - hi / 2), e - s, hi, fc=col_int, ec="none", lw=0, zorder=z))
    tip = min(0.35 * (ltr5 if ltr5 > 0 else 1), 0.0)
    for a_, b_ in ((s, s + ltr5), (e - ltr3, e)):
        if strand in "+-":
            d = (b_ - a_) * 0.35
            if strand == "+":
                pts = [(a_, y - h / 2), (b_ - d, y - h / 2), (b_, y), (b_ - d, y + h / 2), (a_, y + h / 2)]
            else:
                pts = [(b_, y - h / 2), (a_ + d, y - h / 2), (a_, y), (a_ + d, y + h / 2), (b_, y + h / 2)]
            ax.add_patch(Polygon(pts, closed=True, fc=col_ltr, ec="none", lw=0, zorder=z + 1))
        else:
            ax.add_patch(Rectangle((a_, y - h / 2), b_ - a_, h, fc=col_ltr, ec="none", zorder=z + 1))
    if lw:
        ax.add_patch(Rectangle((s, y - h / 2 - 0.35), e - s, h + 0.7, fc="none", ec=ec, lw=lw, zorder=z + 2))
    return tip


# ---------------------------------------------------------------------------------------------------------------------
# panel A: the logic (schematic, flat cartoon)
# ---------------------------------------------------------------------------------------------------------------------
def panel_A(fig):
    x0, y0, w, h = PANELS["A"]
    axl = canvas(fig, x0 + 1, y0 + 3, w - 1, h - 3)              # time guides and labels
    ax = canvas(fig, x0 + 2.2, y0 + 3, w - 2.2, h - 3)           # tree and clock, 1.2 mm to the right
    tube_fc, tube_ec = "#EFEFEF", "#A6A6A6"
    yp, ys, yd, y0t = 58.5, 45.5, 33.5, 22.0          # past, split, domestication, present
    outline = [(22, yp), (50, yp), (50, ys), (56, ys), (56, y0t), (43, y0t), (43, ys), (38.5, ys), (38.5, y0t),
               (29.5, y0t), (29.5, yd), (25.5, yd), (25.5, y0t), (16, y0t), (16, ys), (22, ys)]
    ax.add_patch(Polygon(outline, closed=True, fc=tube_fc, ec=tube_ec, lw=0.6, zorder=1))
    # time guides
    for yy, lab in ((ys, "split\n30–60 kya"), (yd, "domestication\n~9 kya")):
        axl.plot([1.8, 16.6], [yy, yy], ls=(0, (2, 1.5)), lw=0.5, color="#888888", zorder=0)
        axl.text(1.9, yy + 0.5, lab, fontsize=6, color="#555555", va="bottom", ha="left", linespacing=1.0)
    axl.annotate("", xy=(0.7, y0t + 0.5), xytext=(0.7, yp), arrowprops=dict(arrowstyle="-|>", lw=0.6,
                                                                           color="#555555", mutation_scale=5))
    axl.text(1.9, yp - 0.2, "past", fontsize=6, color="#555555", va="top")
    axl.text(1.9, y0t + 0.6, "present", fontsize=6, color="#555555", va="bottom")

    def lineage(pts, col, lw=0.9, z=3):
        xs, ys_ = zip(*pts)
        ax.plot(xs, ys_, color=col, lw=lw, solid_capstyle="round", solid_joinstyle="round", zorder=z)

    old = "#6E6E6E"
    # old insertion 1: polymorphic before the split, sorted into parviglumis and mexicana
    lineage([(28, 55.5), (28, 51.5), (22.5, ys), (20.5, yd), (20.5, y0t)], old)
    lineage([(28, 51.5), (45.0, ys), (46.0, y0t)], old)
    # old insertion 2: sorted into maize and mexicana
    lineage([(39, 56.5), (39, 52.5), (33, ys), (33.5, yd), (33.5, y0t)], old)
    lineage([(39, 52.5), (48.0, ys), (49.0, y0t)], old)
    # young insertion: arises in mexicana after the split, carried into maize by gene flow
    lineage([(53.5, 40.5), (53.5, y0t)], MEX, lw=1.1, z=4)
    ax.add_patch(FancyArrowPatch((53.5, 28.5), (36.2, 27.0), arrowstyle="-|>", mutation_scale=6, lw=1.0,
                                 color=MEX, connectionstyle="arc3,rad=0.25", zorder=5))
    lineage([(36.2, 27.0), (36.2, y0t)], MEX, lw=1.1, z=4)
    for (xx, yy), col in (((28, 55.5), old), ((39, 56.5), old), ((53.5, 40.5), MEX)):
        ax.plot(xx, yy + 0.9, marker="v", ms=4.2, mec="white", mew=0.4, color=col, zorder=6)
    ax.text(33.5, yp + 1.0, "old insertions", fontsize=6, color=old, ha="center", va="bottom")
    ax.text(53.0, 46.6, "young\ninsertion", fontsize=6, color=MEX, ha="center", va="bottom", linespacing=1.0)
    ax.text(45.0, 31.0, "gene flow", fontsize=6, color=MEX, ha="center", va="bottom")
    # tips
    for xx, g, tx in ((20.75, "TIL01", "parviglumis"), (34.0, "B73", "maize"), (49.5, "TIL18", "mexicana")):
        ax.text(xx, y0t - 1.0, g, fontsize=6.5, ha="center", va="top")
        ax.text(xx, y0t - 3.9, tx if tx == "maize" else it(tx), fontsize=6.5, ha="center", va="top")
    # the clock: an element at insertion and later
    def elem(yy, ticks):
        ax.add_patch(Rectangle((9, yy - 0.55), 16, 1.1, fc=MEX_L, ec="none", zorder=2))
        for a_ in (4, 25):
            ax.add_patch(Rectangle((a_, yy - 1.1), 5, 2.2, fc=MEX, ec="none", zorder=3))
        for t in ticks:
            ax.plot([t, t], [yy - 1.1, yy + 1.1], color="black", lw=0.7, zorder=4)
    elem(11.5, [])
    elem(4.0, [5.2, 7.6, 26.4, 28.6])
    ax.text(32.0, 11.5, "at insertion:\nidentical LTRs", fontsize=6, va="center", ha="left", linespacing=1.0)
    ax.text(32.0, 4.0, "later: differences = age;\nother LTR = outgroup", fontsize=6, va="center", ha="left",
            linespacing=1.05)
    ax.text(6.5, 13.9, "LTR", fontsize=6, ha="center", va="bottom", color=MEX)
    ax.text(27.5, 13.9, "LTR", fontsize=6, ha="center", va="bottom", color=MEX)
    ax.annotate("", xy=(17, 5.7), xytext=(17, 9.9), arrowprops=dict(arrowstyle="-|>", lw=0.6, color="#555555",
                                                                    mutation_scale=5))


# ---------------------------------------------------------------------------------------------------------------------
# panel B: the region around the example, three genomes at one bp scale
# ---------------------------------------------------------------------------------------------------------------------
VIEW_B = (300_701_000, 300_797_000)
OFF18 = WIN["TIL18"][1] - WIN["B73v5"][1]                       # TIL18 = B73 + OFF18 (collinear block)
ID_LO, ID_HI = 0.98, 1.0                                        # ribbon shading range (sequence identity)


def id_color(idt):
    t = np.clip((idt - ID_LO) / (ID_HI - ID_LO), 0, 1)
    lo, hi = np.array([0.95, 0.95, 0.95]), np.array([0.60, 0.60, 0.60])
    return tuple(lo + (hi - lo) * t)


def panel_B(fig, d):
    x0, y0, w, h = PANELS["B"]
    ax = ax_mm(fig, x0 + 15, y0 + 3, w - 15, h - 4)
    ax.set_xlim(*VIEW_B)
    ax.set_ylim(0, h - 4)
    ax.axis("off")
    ex, win, aln = d["ex"], d["win"], d["aln"]
    cB, sB, eB = parse_name(EX["B"])
    cen = (sB + eB) / 2
    site01 = ex["pos01"] + ex["F"] + 2                           # centre of TIL01's single TSD copy
    off01 = site01 - cen
    yc = dict(TIL01=50.0, B73v5=26.5, TIL18=13.5)
    band = {g: (y - 1.45, y + 4.45) for g, y in yc.items()}
    # ribbons (sequence alignment, shaded by identity in ~1-kb pieces)
    for g, (ya, yb) in (("TIL01", (band["B73v5"][1] + 0.15, band["TIL01"][0] - 0.15)),
                        ("TIL18", (band["B73v5"][0] - 0.15, band["TIL18"][1] + 0.15))):
        off = off01 if g == "TIL01" else OFF18
        for qs, qe, ts, te, mm in aln[g]:
            mm = np.array(mm)
            n = max(1, int(round((te - ts) / 1000)))
            cuts = np.linspace(ts, te, n + 1)
            for a_, b_ in zip(cuts[:-1], cuts[1:]):
                if b_ < VIEW_B[0] or a_ > VIEW_B[1]:
                    continue
                qa = qs + (a_ - ts) * (qe - qs) / (te - ts)
                qb = qs + (b_ - ts) * (qe - qs) / (te - ts)
                idt = 1 - ((mm >= a_) & (mm < b_)).sum() / (b_ - a_)
                pts = [(a_, ya), (b_, ya), (qb - off, yb), (qa - off, yb)]
                ax.add_patch(Polygon(pts, closed=True, fc=id_color(idt), ec=id_color(idt), lw=0.15, zorder=1))
    # wedges: B73 insertions with no counterpart in TIL01 (the alignment closes to one point = the empty site)
    bl = aln["TIL01"]
    wedges = []
    for (qs1, qe1, ts1, te1, _), (qs2, qe2, ts2, te2, _) in zip(bl[:-1], bl[1:]):
        hit = [n for n in d["win"]["B73v5"].index[d["win"]["B73v5"].in01 == "absent"]
               if parse_name(n)[1] >= te1 - 50 and parse_name(n)[2] <= ts2 + 50]
        if ts2 - te1 >= 1000 and abs(qs2 - qe1) < 100 and hit:
            wedges.append((te1, ts2, (qe1 + qs2) / 2 - off01))
    for a_, b_, xq in wedges:
        focal = a_ <= cen <= b_
        ax.add_patch(Polygon([(a_, band["B73v5"][1] + 0.15), (b_, band["B73v5"][1] + 0.15),
                              (xq, band["TIL01"][0] - 0.15)], closed=True, fc=MEX, alpha=0.55 if focal else 0.28,
                             ec="none", zorder=2))
        ax.plot(xq, band["TIL01"][0] - 0.05, marker="v", ms=3.0, color=MEX, mec="white", mew=0.3, zorder=6)
    # elements
    wB = win["B73v5"]
    flow = set(wB.index[(wB.in18 == "present") & (wB.in01 == "absent")])
    flow18 = set(wB.loc[list(flow), "orth18"])
    ages = {}
    for g, off in (("TIL01", off01), ("B73v5", 0), ("TIL18", OFF18)):
        el = win[g]
        outer = {n for n, r in el.iterrows() if str(r.nest_status).startswith("nest-outer")}
        for n, r in el.iterrows():
            s, e = r.s - off, r.e - off
            if e < VIEW_B[0] or s > VIEW_B[1]:
                continue
            hot = (n in flow) if g == "B73v5" else (n in flow18) if g == "TIL18" else False
            yy = yc[g] + (3.0 if n in outer else 0.0)
            focal = n in (EX["B"], EX["M"])
            element(ax, s, e, yy, int(r.ltr5_end), int(r.seq_len - r.ltr3_start + 1), str(r.strand),
                    MEX if hot else "#8C8C8C", MEX_L if hot else "#D9D9D9", lw=0.6 if focal else 0, ec="black")
            if g == "TIL18" and hot:
                ages[n] = ((s + e) / 2, float(r.k2p) * KYR)
    # ages of the donor copies (the clock used in D)
    for n, (xm, a_) in ages.items():
        ax.text(xm, band["TIL18"][0] - 0.6, f"{a_:.0f}", fontsize=6, color=MEX, ha="center", va="top")
    xs = sorted(v[0] for v in ages.values())
    ax.text(xs[-1] + 2600, band["TIL18"][0] - 0.6, "kyr", fontsize=6, color=MEX, ha="left", va="top")
    ax.text(cen, yc["B73v5"] + 1.9, "C", fontsize=7.5, fontweight="bold", ha="center", va="bottom")
    # track labels and coordinates
    for g, lab, tx, col in (("TIL01", "TIL01", "parviglumis", PAR), ("B73v5", "B73", "maize", MZ),
                            ("TIL18", "TIL18", "mexicana", MEX)):
        tr = matplotlib.transforms.blended_transform_factory(ax.transAxes, ax.transData)
        ax.text(-0.012, yc[g] + 2.4, lab, transform=tr, ha="right", va="bottom", fontsize=7)
        ax.text(-0.012, yc[g] + 2.4, tx if tx == "maize" else it(tx), transform=tr, ha="right", va="top",
                fontsize=7)
    # baselines
    for g, off in (("TIL01", off01), ("B73v5", 0), ("TIL18", OFF18)):
        a_, b_ = (bl[0][0] - off01, bl[-1][1] - off01) if g == "TIL01" else VIEW_B
        a_, b_ = max(a_, VIEW_B[0]), min(b_, VIEW_B[1])
        ax.plot([a_, b_], [yc[g], yc[g]], color="#777777", lw=0.5, zorder=2)
    # keys: identity ramp, empty site, scale bar
    kx, ky = 300_766_000, 57.5
    grad = np.linspace(ID_LO, ID_HI, 40)
    for i, g_ in enumerate(grad[:-1]):
        ax.add_patch(Rectangle((kx + i * 250, ky - 0.9), 250, 1.8, fc=id_color(g_), ec="none"))
    ax.text(kx - 400, ky, "98%", fontsize=6, ha="right", va="center")
    ax.text(kx + 39 * 250 + 400, ky, "100%", fontsize=6, ha="left", va="center")
    ax.text(kx + 39 * 125, ky + 1.3, "sequence identity", fontsize=6, ha="center", va="bottom")
    ax.add_patch(Polygon([(kx, ky - 4.6), (kx + 2200, ky - 4.6), (kx + 1100, ky - 2.6)], closed=True, fc=MEX,
                         alpha=0.45, ec="none"))
    ax.text(kx + 2900, ky - 3.6, "insertion absent\nfrom TIL01", fontsize=6, va="center", ha="left",
            linespacing=1.0)
    ax.plot([VIEW_B[0] + 1_000, VIEW_B[0] + 11_000], [4.0, 4.0], color="black", lw=0.8)
    ax.text(VIEW_B[0] + 6_000, 4.6, "10 kb", fontsize=6, ha="center", va="bottom")
    return dict(off01=off01, ages=ages, wedges=wedges)


# ---------------------------------------------------------------------------------------------------------------------
# panel C: the example element, both copies, and its junctions at base-pair resolution
# ---------------------------------------------------------------------------------------------------------------------
def panel_C(fig, d):
    x0, y0, w, h = PANELS["C"]
    ax = canvas(fig, x0 + 1, y0 + 2, w - 1, h - 2)
    ex = d["ex"]
    L = ex["L"]
    xa, xb = 34.0, 150.0
    sc = (xb - xa) / ex["lenB"]
    yB, yM = 31.5, 25.0
    for yy, lab, n in ((yB, "B73 copy", ex["lenB"]), (yM, "TIL18 copy", ex["lenM"])):
        element(ax, xa, xa + n * sc, yy, L * sc, L * sc, "-", MEX, MEX_L, h=2.6, hi=1.4)
        ax.text(xa - 1.5, yy, lab, fontsize=7, ha="right", va="center")
    # arcs joining each copy's two LTRs (the clock reads zero: identical)
    t = np.linspace(0, np.pi, 80)
    c1, c2 = xa + L * sc / 2, xb - L * sc / 2
    for yy, sgn in ((yB + 1.5, 1), (yM - 1.5, -1)):
        ax.plot(c1 + (c2 - c1) * (1 - np.cos(t)) / 2, yy + sgn * 2.6 * np.sin(t), color=MEX, lw=0.7)
        ax.text((c1 + c2) / 2, yy + sgn * 2.85, f"LTRs identical ({L} of {L} bp)", fontsize=6, color=MEX,
                ha="center", va="bottom" if sgn > 0 else "top")
    # differences between the two copies
    ax.add_patch(Rectangle((xa, yM + 1.9), xb - xa, yB - yM - 3.8, fc="#E4E4E4", ec="none", zorder=1))
    for p_, kind in ex["diffs"]:
        xx = xa + p_ * sc
        if kind == "sub":
            ax.plot([xx, xx], [yM + 1.9, yB - 1.9], color="black", lw=0.6, zorder=2)
        else:
            ax.plot(xx, (yB + yM) / 2, marker="v", ms=2.6, color="black", mew=0, zorder=2)
    ax.text(xb + 1.5, (yB + yM) / 2, "differences\nbetween copies", fontsize=6, ha="left", va="center",
            linespacing=1.0, color="#444444")
    ax.plot([xb + 2.0, xb + 2.0 + 1000 * sc], [yB + 2.2, yB + 2.2], color="black", lw=0.7)
    ax.text(xb + 2.0 + 500 * sc, yB + 2.7, "1 kb", fontsize=6, ha="center", va="bottom")
    # junctions, base by base
    F, tsd = ex["F"], ex["tsd"]
    K = 12
    cw = 1.42
    lx, rx = 17.0, 103.0
    rows = (("B73", ex["seqB"], 13.0), ("TIL18", ex["seqM"], 8.6), ("TIL01", None, 4.2))
    mono = dict(family="Liberation Mono", fontsize=6.4)
    left_cols = F + 5 + K
    for lab, seq, yy in rows:
        ax.text(lx - 2.0, yy, lab, fontsize=7, ha="right", va="center")
        if seq is not None:
            left = seq[:F + 5 + K]
            right = seq[-(K + 5 + F):]
        else:
            s01 = ex["site01"]
            left = s01[:F + 5] + "-" * K
            right = "-" * (K + 5) + s01[F + 5:]
        for i, ch in enumerate(left):
            xx = lx + (i + 0.5) * cw
            inl = F + 5 <= i and ch != "-"
            if inl:
                ax.add_patch(Rectangle((lx + i * cw, yy - 1.5), cw, 3.0, fc=MEX, ec="none", zorder=1))
            ax.text(xx, yy, ch, ha="center", va="center", color="white" if inl else ("#999999" if ch == "-" else
                                                                                        "black"), **mono, zorder=3)
        for i, ch in enumerate(right):
            xx = rx + (i + 0.5) * cw
            inl = i < K and ch != "-"
            if inl:
                ax.add_patch(Rectangle((rx + i * cw, yy - 1.5), cw, 3.0, fc=MEX, ec="none", zorder=1))
            ax.text(xx, yy, ch, ha="center", va="center", color="white" if inl else ("#999999" if ch == "-" else
                                                                                        "black"), **mono, zorder=3)
        # TSD boxes
        ax.add_patch(Rectangle((lx + F * cw, yy - 1.6), 5 * cw, 3.2, fc="none", ec="black", lw=0.7, zorder=4))
        if seq is not None:
            ax.add_patch(Rectangle((rx + K * cw, yy - 1.6), 5 * cw, 3.2, fc="none", ec="black", lw=0.7, zorder=4))
            mid = f"… {len(seq) - 2 * (F + 5) - 2 * K:,} bp …"
            ax.text((lx + left_cols * cw + rx) / 2, yy, mid, fontsize=6.4, ha="center", va="center")
        else:
            ax.text((lx + left_cols * cw + rx) / 2, yy, "empty site", fontsize=6.4, ha="center", va="center",
                    color=PAR)
    # the flank site where B73 and TIL18 share a base that TIL01 lacks
    for i in ex["flank_snps"]:
        ax.add_patch(Rectangle((lx + i * cw, 2.4), cw, 12.4, fc="#D9D9D9", ec="none", zorder=0))
    for i in ex["rflank_snps"]:
        ax.add_patch(Rectangle((rx + (K + 5 + i) * cw, 2.4), cw, 12.4, fc="#D9D9D9", ec="none", zorder=0))
    ax.text(lx + (F + 2.5) * cw, 15.4, "TSD", fontsize=6, ha="center", va="bottom")
    ax.text(rx + (K + 2.5) * cw, 15.4, "TSD", fontsize=6, ha="center", va="bottom")
    ax.text(lx + (F + 5 + K / 2) * cw, 15.4, "LTR", fontsize=6, ha="center", va="bottom", color=MEX)
    ax.text(rx + (K / 2) * cw, 15.4, "LTR", fontsize=6, ha="center", va="bottom", color=MEX)
    ax.text(lx + (F / 2) * cw, 15.4, "flank", fontsize=6, ha="center", va="bottom", color="#555555")
    ax.text(rx + (K + 5 + F / 2) * cw, 15.4, "flank", fontsize=6, ha="center", va="bottom", color="#555555")
    # connectors from the element's ends to the junctions
    for xe, xj in ((xa, lx + (F + 5) * cw), (xb, rx + K * cw)):
        ax.plot([xe, xj], [yM - 1.6, 17.6], color="#999999", lw=0.5, zorder=0)


# ---------------------------------------------------------------------------------------------------------------------
# panel D: every shared insertion on the age axis, and D per age stratum with its nulls
# ---------------------------------------------------------------------------------------------------------------------
AGE_LO, AGE_HI = 4.0, 12_000.0
SPLIT = (30.0, 60.0)                                            # published maize-mexicana split (kyr)


def age_axes(fig, y, h, x0=0.0):
    """A narrow axis for K2P = 0 (identical LTRs) beside a log axis of age in kyr; same vertical band."""
    a0 = ax_mm(fig, x0 + 25.0, y, 5.5, h)
    a1 = ax_mm(fig, x0 + 33.0, y, 145.5, h)
    a0.set_xlim(0, 1)
    a1.set_xscale("log")
    a1.set_xlim(AGE_LO, AGE_HI)
    for a in (a0, a1):
        a.tick_params(axis="x", which="both", bottom=False, labelbottom=False)
    a1.spines["left"].set_visible(False)
    a1.tick_params(axis="y", left=False, labelleft=False)
    return a0, a1


def panel_D(fig, d, bmarks):
    x0, y0, w, h = PANELS["D"]
    A, B, ag = d["A"], d["B"], d["ag"]
    rng = np.random.default_rng(7)
    edges_kyr = [e * KYR for e in EDGES[2:]]
    ys0 = y0 + 6.5
    sh = 9.0
    strips = []
    for i, (X, col, lab) in enumerate(((A, MEX, "B73 + TIL18\n(not TIL01)"), (B, PAR, "TIL01 + TIL18\n(not B73)"))):
        a0, a1 = age_axes(fig, ys0 + i * (sh + 0.6), sh)
        k = X.k2p.values
        z = k <= 1e-9
        yy = rng.uniform(0.06, 0.94, len(k))
        a0.scatter(rng.uniform(0.1, 0.9, z.sum()), yy[z], s=0.6, c=col, alpha=0.6, lw=0, rasterized=True)
        a1.scatter(k[~z] * KYR, yy[~z], s=0.6, c=col, alpha=0.32, lw=0, rasterized=True)
        for a in (a0, a1):
            a.set_ylim(0, 1)
            a.set_yticks([])
            for sp in ("left", "bottom"):
                a.spines[sp].set_visible(False)
        a0.text(-0.5, 0.5, lab, transform=a0.transAxes, ha="right", va="center", fontsize=6.5, color=col,
                linespacing=1.05)
        if i == 0:
            hl = np.isin(X.B73v5.values, list(bmarks))
            kh = np.sort(k[hl])
            yh = np.resize([0.3, 0.72, 0.5], len(kh))
            for kk_, yy_ in zip(kh, yh):
                if kk_ <= 1e-9:
                    a0.scatter([0.5], [yy_], s=9, fc=MEX, ec="black", lw=0.6, zorder=5)
                else:
                    a1.scatter([kk_ * KYR], [yy_], s=9, fc=MEX, ec="black", lw=0.6, zorder=5)
        for e in edges_kyr:
            a1.axvline(e, color="#9A9A9A", lw=0.4, ls=(0, (2, 2)), zorder=0)
        a1.axvspan(*SPLIT, color="#E9E9E9", zorder=-1, lw=0)
        strips.append((a0, a1))
    # n per stratum, above (B73+TIL18) and below (TIL01+TIL18) the strips
    mids = [None] + [np.sqrt(a * b) for a, b in zip([AGE_LO] + edges_kyr, edges_kyr + [AGE_HI])][1:]
    mids[1] = np.sqrt(AGE_LO * edges_kyr[0])
    mids = [None, np.sqrt(8 * edges_kyr[0])] + [np.sqrt(a * b) for a, b in zip(edges_kyr[:-1], edges_kyr[1:])] + \
           [np.sqrt(edges_kyr[-1] * AGE_HI)]
    for j, s in enumerate(STRATA):
        nA, nB = int(ag.loc[s, "nA"]), int(ag.loc[s, "nB"])
        for (a0, a1), n, yy, va, col in ((strips[0], nA, 1.04, "bottom", MEX), (strips[1], nB, -0.04, "top", PAR)):
            if j == 0:
                a0.text(0.5, yy, f"{n:,}", transform=a0.transAxes, ha="center", va=va, fontsize=6, color=col)
            else:
                a1.text(mids[j], yy, f"{n:,}", transform=a1.get_xaxis_transform(), ha="center", va=va,
                        fontsize=6, color=col)
    # D per stratum
    dy = ys0 + 2 * sh + 0.6 + 4.6
    dh = 30.0
    b0, b1 = age_axes(fig, dy, dh)
    for a in (b0, b1):
        a.set_ylim(-0.3, 0.68)
        a.axhline(0, color="black", lw=0.6, zorder=1)
        for e in edges_kyr:
            if a is b1:
                a.axvline(e, color="#9A9A9A", lw=0.4, ls=(0, (2, 2)), zorder=0)
    b1.axvspan(*SPLIT, color="#E9E9E9", zorder=-1, lw=0)
    b1.text(np.sqrt(SPLIT[0] * SPLIT[1]), -0.285, "maize–\n" + it("mexicana") + "\nsplit", fontsize=6, ha="center",
            va="bottom", color="#555555", linespacing=0.95)
    b0.set_yticks([-0.2, 0, 0.2, 0.4, 0.6])
    b0.set_ylabel("excess B73–TIL18 sharing,\nD (± 2 SE)", labelpad=2)
    b0.yaxis.set_label_coords(-2.2, 0.5)
    # null: 30 simulations without gene flow, young (K2P <= 0.005) and old (K2P > 0.02) insertions pooled
    sims = d["sims"]
    for col_, lo, hi, xc in (("youngB", None, edges_kyr[1], 17.0), ("oldB", edges_kyr[3], AGE_HI, 1700.0)):
        m_, s_ = sims[col_].mean(), sims[col_].std()
        if lo is None:
            b0.axhspan(m_ - 2 * s_, m_ + 2 * s_, color="#BDBDBD", alpha=0.45, lw=0, zorder=0)
            b1.fill_between([AGE_LO, hi], m_ - 2 * s_, m_ + 2 * s_, color="#BDBDBD", alpha=0.45, lw=0, zorder=0)
        else:
            b1.fill_between([lo, hi], m_ - 2 * s_, m_ + 2 * s_, color="#BDBDBD", alpha=0.45, lw=0, zorder=0)
        jit = 10 ** rng.uniform(-0.09, 0.09, len(sims))
        b1.scatter(xc * jit, sims[col_], s=2.2, c="#8A8A8A", lw=0, zorder=2)
    # observed (LTRquest library) and the EDTA library
    ed = d["ed"]
    eag = ed[ed.test == "D_ins_by_age"].set_index("stratum")
    for j, s in enumerate(STRATA):
        r = ag.loc[s]
        kk = np.concatenate([d["A"].k2p.values[d["A"].stratum.values == j], d["B"].k2p.values[d["B"].stratum.values == j]])
        xm = np.median(kk) * KYR
        for src, row, mk, fc, dx in (("ltrquest", r, "o", "black", 0.0), ("edta", eag.loc[s] if s in eag.index else None,
                                                                           "o", "white", 1.0)):
            if row is None or not np.isfinite(float(row["D"])):
                continue
            D_, se = float(row["D"]), float(row["SE"])
            if j == 0:
                xx, a = 0.38 + 0.3 * dx, b0
            else:
                xx, a = xm * (1.22 if dx else 1.0), b1
            a.errorbar(xx, D_, yerr=2 * se, fmt=mk, ms=3.6 if dx == 0 else 3.2, mfc=fc, mec="black",
                       mew=0.7, color="black" if dx == 0 else "#666666", elinewidth=0.8, capsize=0, zorder=4 - dx)
    # axes labels
    b1.tick_params(axis="x", which="both", bottom=True, labelbottom=True)
    b1.set_xticks([10, 100, 1000, 10000])
    b1.set_xticklabels(["10", "100", "1,000", "10,000"])
    b1.spines["bottom"].set_visible(True)
    b0.tick_params(axis="x", which="both", bottom=True, labelbottom=True)
    b0.set_xticks([0.5])
    b0.set_xticklabels(["0"])
    b1.set_xlabel("insertion age (kyr, at 3 × 10$^{-8}$ substitutions per site per year)", labelpad=2)
    # key
    kx = 2600.0
    b1.errorbar([kx], [0.60], yerr=[0.035], fmt="o", ms=3.6, mfc="black", mec="black", color="black", elinewidth=0.8)
    b1.text(kx * 1.25, 0.60, "LTRquest library", fontsize=6, va="center")
    b1.errorbar([kx], [0.51], yerr=[0.035], fmt="o", ms=3.2, mfc="white", mec="black", mew=0.7, color="#666666",
                elinewidth=0.8)
    b1.text(kx * 1.25, 0.51, "EDTA library", fontsize=6, va="center")
    b1.add_patch(Rectangle((kx / 1.13, 0.395), kx * 0.25, 0.05, color="#BDBDBD", alpha=0.45, lw=0))
    b1.scatter([kx * 1.0], [0.42], s=2.2, c="#8A8A8A", lw=0)
    b1.text(kx * 1.25, 0.42, "30 simulations without\ngene flow (mean ± 2 SD)", fontsize=6, va="center",
            linespacing=1.0)
    b1.scatter([kx], [0.31], s=9, fc=MEX, ec="black", lw=0.6)
    b1.text(kx * 1.25, 0.31, "insertions in B", fontsize=6, va="center")
    return (b0, b1)


# ---------------------------------------------------------------------------------------------------------------------
# panel E: identity spectrum
# ---------------------------------------------------------------------------------------------------------------------
def panel_E(fig, d):
    x0, y0, w, h = PANELS["E"]
    ax = ax_mm(fig, x0 + 25, y0 + 4, w - 27, h - 17)
    idn, cal = d["idn"], float(d["fl"]["calibration"])
    t = idn.n_target.astype(float).values
    m = idn.n_mirror.astype(float).values / cal
    pos = np.array([-1.0] + list(range(0, 10)), float)          # bin 0 (identical) set apart
    xl = np.array([-1.35] + list(range(0, 10)), float)
    xr = np.array([-0.35] + list(range(1, 11)), float)
    for vals, col, lw in ((m, PAR, 1.0), (t, MEX, 1.0)):
        ax.stairs(vals[1:], np.arange(0, 11), color=col, lw=lw, baseline=None, zorder=3)
        ax.plot([xl[0], xr[0]], [vals[0], vals[0]], color=col, lw=lw, zorder=3)
        ax.plot([xl[0], xl[0]], [0, vals[0]], color=col, lw=lw, zorder=3)
        ax.plot([xr[0], xr[0]], [0, vals[0]], color=col, lw=lw, zorder=3)
    # near-identical excess (divergence < 0.2%), shaded
    near = np.arange(len(t)) < 5
    for i in np.where(near)[0]:
        if t[i] > m[i]:
            ax.add_patch(Rectangle((xl[i], m[i]), xr[i] - xl[i], t[i] - m[i], fc=MEX, alpha=0.3, lw=0, zorder=1))
    ax.set_xlim(-1.6, 10.2)
    ax.set_ylim(0, 6800)
    ax.set_xticks([-0.85] + list(range(1, 10)))
    ax.set_xticklabels(["0", "0.25", "0.5", "1", "2", "4", "8", "16", "32", "64"], fontsize=6.5)
    ax.set_yticks([0, 2000, 4000, 6000])
    ax.set_yticklabels(["0", "2,000", "4,000", "6,000"])
    ax.set_xlabel("differences per kb between orthologous copies", labelpad=2)
    ax.set_ylabel("orthologs", labelpad=2)
    ax.text(8.15, 3300, "B73–TIL18", color=MEX, fontsize=6.5, ha="left", va="center")
    ax.text(8.15, 2650, "TIL01–TIL18", color=PAR, fontsize=6.5, ha="left", va="center")
    ax.text(1.6, 3300, "near-identical\nexcess", color=MEX, fontsize=6.2, ha="center", va="bottom", linespacing=1.0)
    return ax


# ---------------------------------------------------------------------------------------------------------------------
# panel F: genome-wide D, LTR-RT-only tests and comparators
# ---------------------------------------------------------------------------------------------------------------------
def panel_F(fig, d):
    x0, y0, w, h = PANELS["F"]
    ax = ax_mm(fig, x0 + 45, y0 + 4, w - 47, h - 17)
    st, ed, comp = d["st"], d["ed"], d["comp"]
    g = lambda T, test: T[T.test == test].iloc[0]
    rows = [("header", "LTR-RT libraries only"),
            ("ltr", "single-copy k-mers", "D_kmer"), ("ltr", "insertions", "D_ins"),
            ("ltr", "ortholog-triple divergence", "D3_triples"), ("ltr", "LTR sites, other LTR as outgroup",
                                                                   "D_self_outgroup"),
            ("header", "whole assemblies"),
            ("cmp", "single-copy k-mers", "wgk_all"), ("cmp", "same, LTR-RTs masked", "wgk_noLTR"),
            ("cmp", "gene-space SNPs, " + it("Z. diploperennis") + " outgroup", "gene_snp")]
    y = len(rows)
    tr = matplotlib.transforms.blended_transform_factory(ax.transAxes, ax.transData)
    out = []
    for r in rows:
        y -= 1
        if r[0] == "header":
            ax.text(-0.02 - 0.0, y + 0.05, r[1], transform=tr, ha="right", va="center", fontsize=6.5,
                    color="#555555", fontstyle="italic" if False else "normal", fontweight="bold")
            continue
        ax.text(-0.04, y, r[1], transform=tr, ha="right", va="center", fontsize=6.5)
        if r[0] == "ltr":
            a, b = g(st, r[2]), g(ed, r[2])
            ax.errorbar(float(a.D), y + 0.17, xerr=2 * float(a.SE), fmt="o", ms=3.6, mfc="black", mec="black",
                        color="black", elinewidth=0.9, capsize=0)
            ax.errorbar(float(b.D), y - 0.17, xerr=2 * float(b.SE), fmt="o", ms=3.2, mfc="white", mec="black",
                        mew=0.7, color="#666666", elinewidth=0.9, capsize=0)
        else:
            D_, se, _ = comp[r[2]]
            ax.errorbar(D_, y, xerr=2 * se, fmt="D", ms=3.0, mfc=MZ, mec=MZ, color=MZ, elinewidth=0.9, capsize=0)
    ax.axvline(0, color="black", lw=0.6)
    ax.set_ylim(-0.6, len(rows) - 0.4)
    ax.set_yticks([])
    ax.spines["left"].set_visible(False)
    ax.set_xlim(-0.05, 0.6)
    ax.set_xticks([0, 0.2, 0.4, 0.6])
    ax.set_xticklabels(["0", "0.2", "0.4", "0.6"])
    ax.set_xlabel("excess B73–TIL18 sharing, D (± 2 SE)", labelpad=2)
    # key
    ax.errorbar([0.40], [len(rows) - 1.0], xerr=[0.03], fmt="o", ms=3.6, mfc="black", mec="black", color="black",
                elinewidth=0.9)
    ax.text(0.45, len(rows) - 1.0, "LTRquest", fontsize=6, va="center")
    ax.errorbar([0.40], [len(rows) - 1.65], xerr=[0.03], fmt="o", ms=3.2, mfc="white", mec="black", mew=0.7,
                color="#666666", elinewidth=0.9)
    ax.text(0.45, len(rows) - 1.65, "EDTA", fontsize=6, va="center")
    return ax


# ---------------------------------------------------------------------------------------------------------------------
# assembly
# ---------------------------------------------------------------------------------------------------------------------
def draw_figure(d):
    fig = plt.figure(figsize=(W / 25.4, H / 25.4))
    panel_A(fig)
    bres = panel_B(fig, d)
    panel_C(fig, d)
    panel_D(fig, d, set(d["win"]["B73v5"].index[(d["win"]["B73v5"].in18 == "present") &
                                                (d["win"]["B73v5"].in01 == "absent")]))
    panel_E(fig, d)
    panel_F(fig, d)
    for k in PANELS:
        letter(fig, k)
    return fig, bres




# ---------------------------------------------------------------------------------------------------------------------
# example selection (rule and typicality, reproduced) and region numbers
# ---------------------------------------------------------------------------------------------------------------------
def screen_examples(d):
    """Candidates for the example: K2P = 0 (donor copy) insertions shared by B73 and TIL18 and absent from TIL01,
    checked against TIL01's raw assembly (absence table), both copies with identical LTRs, the same TSD at both
    ends, TG..CA ends, high-confidence and not nested. Also returns typicality context."""
    A, ex = d["A"], d["ex"]
    libB, libM = ex["libB"], ex["libM"]
    c = A[A.k2p <= 1e-9].copy()
    ab = pd.read_csv(ABS, sep="\t").set_index("B73v5")
    c["state"] = ab.genome_state.reindex(c.B73v5).values
    for col in ("k2p", "motif", "tsd", "confidence", "nest_status", "seq_len", "ltr5_len", "family"):
        c["B_" + col] = libB[col].reindex(c.B73v5).values
        c["T_" + col] = libM[col].reindex(c.TIL18).values
    c["superfamily"] = c.B73v5.str.split("#").str[1]
    ok = c[(c.state == "empty") & (c.B_k2p <= 1e-9) & (c.same_tsd == "yes") & (c.B_motif == "tg...ca") &
           (c.T_motif == "tg...ca") & (c.B_tsd.str.len() == 5) & (c.B_tsd == c.T_tsd) & (c.B_confidence == "high") &
           (c.T_confidence == "high") & (c.B_nest_status == ".") & (c.T_nest_status == ".")]
    el = pd.read_csv(f"{MAIN}/elements.B73v5.tsv", sep="\t", usecols=["chrom", "start", "end", "name", "class"])
    tr = pd.read_csv(f"{MAIN}/tracts.B73v5.bed", sep="\t")
    tr.columns = ["chrom", "s0", "e", "name", "score", "n", "mp", "sp", "q", "p"]
    hi = tr[tr.q <= 0.05]
    nd, intr = [], []
    by = {k: g for k, g in el.groupby("chrom")}
    for _, x in c.iterrows():
        g = by[x.chrom]
        nb = g[(g.end > x.start - 100_000) & (g.start < x.end + 100_000) & (g.name != x.B73v5)]
        nd.append(int((nb["class"] == "near_donor").sum()))
        h = hi[(hi.chrom == x.chrom) & (hi.s0 < x.start) & (hi.e > x.end)]
        intr.append(h.q.min() if len(h) else np.nan)
    c["near_donor_100kb"], c["tract_q"] = nd, intr
    fam = libB[libB.family == ex["family"]]
    me = c[c.B73v5 == EX["B"]].iloc[0]
    return dict(n=len(c), tested=int(c.state.notna().sum()), empty=int((c.state == "empty").sum()), cand=ok,
                n_sf=int((c.superfamily == me.superfamily).sum()), sf=me.superfamily,
                ltr_q=np.percentile(c.B_ltr5_len.astype(float), [25, 50, 75]),
                fam_n=len(fam), fam_q=np.percentile(fam.seq_len.astype(float), [25, 50, 75]),
                nd_me=int(me.near_donor_100kb), nd_q=np.percentile(c.near_donor_100kb, [25, 50, 75]),
                tract_q=float(me.tract_q), frac_in_tract=float(np.isfinite(c.tract_q).mean()),
                n_in_tract=int(np.isfinite(c.tract_q).sum()),
                tract=hi[(hi.chrom == me.chrom) & (hi.s0 < me.start) & (hi.e > me.end)].iloc[0])


def sim_caveats():
    """Annotation-completeness ratio under admixture alone (f = 0.18) and under 20% one-sided dropout (f = 0), with
    the spurious D of the dropout runs, from benchmark/sim/out/<run>/stats.tsv and sim/eval/<run>.json."""
    def comp(run):
        t = pd.read_csv(f"{ROOT}/benchmark/sim/out/{run}/stats.tsv", sep="\t", low_memory=False)
        return float(t.loc[t.test == "completeness_ratio", "ratio"].iloc[0])
    adm = [comp(f"f0.18_Ta{ta}_r{r}") for ta in (50, 500, 5000) for r in (1, 2)]
    dro = [f"fn0.2_f0_r{r}" for r in (1, 2, 3)]
    js = [json.loads(open(f"{SIM}/{r}.json").read()) for r in dro]
    return dict(adm=(min(adm), max(adm), len(adm)), dro=(min(map(comp, dro)), max(map(comp, dro)), len(dro)),
                dk=(min(abs(j["D_kmer"]) for j in js), max(abs(j["D_kmer"]) for j in js)),
                di=(min(abs(j["D_ins"]) for j in js), max(abs(j["D_ins"]) for j in js)))


def gene_flow_sims(fmin=0.18):
    """Young / old insertion D in the power-grid simulations with gene flow (f >= fmin, sister inference intact),
    signed toward the true recipient B."""
    rows = [json.loads(open(f).read()) for f in sorted(glob.glob(f"{SIM}/f*_Ta*_r*.json"))]
    x = pd.DataFrame(rows)
    x = x[x.sisters_ok.astype(bool) & (x.f >= fmin)]
    sg = np.where(x.recipient_called == "B", 1.0, -1.0)
    y, o = sg * x.Dins_young, sg * x.Dins_old
    return dict(n=len(x), fmin=fmin, fmax=float(x.f.max()), young=(float(y.min()), float(y.max())),
                old=(float(o.min()), float(o.max())))


def region_numbers(d, bres):
    aln = d["aln"]
    big = max(aln["TIL18"], key=lambda b: b[3] - b[2])
    id18 = 1 - len(big[4]) / (big[3] - big[2])
    ids01 = [1 - len(b[4]) / (b[3] - b[2]) for b in aln["TIL01"] if b[3] - b[2] >= 2000 and b[2] >= VIEW_B[0]]
    t01 = [b for b in aln["TIL01"] if b[3] > VIEW_B[0] and b[2] < VIEW_B[1]]
    lo01 = t01[0][0] + (VIEW_B[0] - t01[0][2]) * (t01[0][1] - t01[0][0]) / (t01[0][3] - t01[0][2])
    hi01 = t01[-1][0] + (VIEW_B[1] - t01[-1][2]) * (t01[-1][1] - t01[-1][0]) / (t01[-1][3] - t01[-1][2])
    return dict(id18=id18, mm18=len(big[4]), len18=big[3] - big[2], id01=(min(ids01), max(ids01)),
                win01=(int(lo01), int(hi01)), n_wedges=len(bres["wedges"]))


# ---------------------------------------------------------------------------------------------------------------------
# numbers, legends
# ---------------------------------------------------------------------------------------------------------------------
def fmt_d(x):
    return f"{x:+.2f}".replace("-", "−")


def build_text(d, scr, reg):
    st, ed, ag, ex, sims, comp = d["st"], d["ed"], d["ag"], d["ex"], d["sims"], d["comp"]
    rows = []

    def add(key, value, source):
        rows.append((key, value, source))
        return value

    S, E_ = f"{MAIN}/stats.tsv", EDTA
    g = lambda T, test: T[T.test == test].iloc[0]
    # genome-wide tests
    gw = {}
    for t in ("D_kmer", "D_ins", "D3_triples", "D_self_outgroup"):
        r, re_ = g(st, t), g(ed, t)
        gw[t] = (float(r.D), float(r.SE), float(r.Z))
        add(f"{t} D", f"{float(r.D):+.4f}", S)
        add(f"{t} SE", f"{float(r.SE):.4f}", S)
        add(f"{t} Z", f"{float(r.Z):.2f}", S)
        gw["edta_" + t] = (float(re_.D), float(re_.SE), float(re_.Z))
        add(f"EDTA {t} D", f"{float(re_.D):+.4f}", E_)
        add(f"EDTA {t} SE", f"{float(re_.SE):.4f}", E_)
        add(f"EDTA {t} Z", f"{float(re_.Z):.2f}", E_)
    rD = g(st, "D_ins")
    add("D_ins nA (B73+TIL18, absent TIL01)", f"{int(rD.nA)}", S)
    add("D_ins nB (TIL01+TIL18, absent B73)", f"{int(rD.nB)}", S)
    rS = g(st, "D_self_outgroup")
    add("D_self ABBA sites", f"{int(rS.nA)}", S)
    add("D_self BABA sites", f"{int(rS.nB)}", S)
    fnd = open(f"{MAIN}/findings.txt").read()
    ntr = re.search(r"([\d,]+) triples", fnd).group(1)
    add("D3 ortholog triples", ntr, f"{MAIN}/findings.txt")
    eD = g(ed, "D_ins")
    add("EDTA D_ins nA", f"{int(eD.nA)}", E_)
    add("EDTA D_ins nB", f"{int(eD.nB)}", E_)
    for k, (D_, se, src) in comp.items():
        add(f"comparator {k} D", f"{D_:+.4f}", src)
        add(f"comparator {k} SE", f"{se:.4f}", src)
        add(f"comparator {k} Z", f"{D_ / se:.2f}", src)
    glog = open(GSNP).read()
    ngenes = re.search(r"genes with all four: ([\d,]+)", glog).group(1)
    nsites = re.search(r"sites ([\d,]+);", glog).group(1)
    add("gene-space SNP genes", ngenes, GSNP)
    add("gene-space SNP sites", nsites, GSNP)
    # age strata
    lab_kyr = ["0 (identical LTRs)", "0–33", "33–83", "83–167", "167–333", "333–833", "833–1,667", "> 1,667"]
    for j, s_ in enumerate(STRATA):
        r = ag.loc[s_]
        add(f"D_ins_by_age {s_} D", f"{float(r.D):+.4f}", S)
        add(f"D_ins_by_age {s_} SE", f"{float(r.SE):.4f}", S)
        add(f"D_ins_by_age {s_} Z", f"{float(r.Z):.2f}", S)
        add(f"D_ins_by_age {s_} nA", f"{int(r.nA)}", S)
        add(f"D_ins_by_age {s_} nB", f"{int(r.nB)}", S)
        add(f"D_ins_by_age {s_} age range (kyr)", lab_kyr[j], "K2P / (2 x 3e-8)")
    eag = ed[ed.test == "D_ins_by_age"].set_index("stratum")
    for s_ in eag.index:
        add(f"EDTA D_ins_by_age {s_} D", f"{float(eag.loc[s_, 'D']):+.4f}", E_)
    # simulations
    add("null simulations, runs", f"{len(sims)}", f"{SIM}/null_s1*.json")
    add("null young D mean (signed toward B)", f"{sims.youngB.mean():+.4f}", f"{SIM}/null_s1*.json")
    add("null young D SD", f"{sims.youngB.std():.4f}", f"{SIM}/null_s1*.json")
    add("null old D mean (signed toward B)", f"{sims.oldB.mean():+.4f}", f"{SIM}/null_s1*.json")
    add("null old D SD", f"{sims.oldB.std():.4f}", f"{SIM}/null_s1*.json")
    add("null young insertions per run (median)", f"{sims.Dins_young_n.median():.0f}", f"{SIM}/null_s1*.json")
    # identity spectrum
    idn, cal = d["idn"], float(d["fl"]["calibration"])
    tt, mm_ = idn.n_target.astype(float).values, idn.n_mirror.astype(float).values
    lo_t, lo_m = tt[:5].sum(), mm_[:5].sum() / cal
    add("identity spectrum B73-TIL18 orthologs, total", f"{int(d['fl'].n_target)}", S)
    add("identity spectrum TIL01-TIL18 orthologs, total", f"{int(d['fl'].n_mirror)}", S)
    add("identity spectrum calibration (deep-half TIL01-TIL18 / B73-TIL18)", f"{cal:.4f}", S)
    add("identity spectrum B73-TIL18, divergence < 0.002", f"{lo_t:.0f}", S)
    add("identity spectrum TIL01-TIL18 scaled, divergence < 0.002", f"{lo_m:.0f}", S + " (n_mirror / calibration)")
    add("identity spectrum ratio < 0.002", f"{lo_t / lo_m:.2f}", S)
    med = float(re.search(r"ratio at d >= ([\d.]+)", fnd).group(1))
    add("identity spectrum median divergence (calibration split)", f"{med}", f"{MAIN}/findings.txt")
    cr = st[st.test == "completeness_ratio"].iloc[0]
    add("completeness ratio B73/TIL01 (TIL18 K2P > 0.0391)", f"{float(cr.ratio):.3f}", S)
    add("completeness ratio SE", f"{float(cr.SE):.3f}", S)
    add("near-identity threshold (divergence)", f"{d['near_thr']}", S + " (hmm rows)")
    # example
    nA0 = int(ag.loc["K2P 0", "nA"])
    add("K2P-0 insertions shared B73+TIL18, absent TIL01", f"{scr['n']}", "ortholog tables + TIL18 library")
    add("  of which in the absence-check table", f"{scr['tested']}", ABS)
    add("  of which empty site in TIL01", f"{scr['empty']}", ABS)
    add("  passing all structural checks", f"{len(scr['cand'])}", "this script (screen_examples)")
    add("  candidate elements", "; ".join(scr["cand"].B73v5), "this script (screen_examples)")
    add("example superfamily count among K2P-0 shared", f"{scr['n_sf']} ({scr['sf']})", "this script")
    add("LTR length of K2P-0 shared, quartiles (bp)", "/".join(f"{x:.0f}" for x in scr["ltr_q"]), "B73 library")
    add(f"family {ex['family']} copies in B73", f"{scr['fam_n']}", "B73 library")
    add(f"family {ex['family']} length quartiles (bp)", "/".join(f"{x:.0f}" for x in scr["fam_q"]), "B73 library")
    add("example near-donor neighbors within 100 kb", f"{scr['nd_me']}", f"{MAIN}/elements.B73v5.tsv")
    add("near-donor neighbors, quartiles over K2P-0 shared",
        "/".join(f"{x:.0f}" for x in scr["nd_q"]), f"{MAIN}/elements.B73v5.tsv")
    add("example recent tract q", f"{scr['tract_q']:.3g}", f"{MAIN}/tracts.B73v5.bed")
    t_ = scr["tract"]
    add("example recent tract", f"{t_.chrom}:{(t_.s0 + 1) / 1e6:.2f}-{t_.e / 1e6:.2f} Mb", f"{MAIN}/tracts.B73v5.bed")
    add("K2P-0 shared insertions inside FDR-passing recent tracts", f"{scr['n_in_tract']} ({scr['frac_in_tract']:.0%})",
        f"{MAIN}/tracts.B73v5.bed")
    add("example lengths B73 / TIL18 (bp)", f"{ex['lenB']} / {ex['lenM']}", "inputs/*.fa via samtools faidx")
    add("example LTR length (bp)", f"{ex['L']}", "run/B73v5 library; verified by alignment")
    add("example LTR-LTR differences (both copies)", "0", "edlib alignment of re-extracted copies")
    add("example TSD", ex["tsd"], "inputs/*.fa")
    add("example copy differences", f"{ex['n_sub']} substitutions, {ex['n_indel']} 1-bp indels", "edlib alignment")
    up95 = -np.log(0.05) / (2 * MU * ex["L"]) / 1e3
    add("example age, 95% upper bound from 0 differences in one LTR pair (kyr)", f"{up95:.0f}",
        "Poisson: -ln(0.05) / (2 mu L)")
    cpd = float(pd.read_csv(f"{MAIN}/orthologs.B73v5.TIL18.tsv.gz", sep="\t").set_index("B73v5").loc[EX["B"], "divergence"])
    add("example B73-TIL18 copy divergence", f"{cpd:.6f}", f"{MAIN}/orthologs.B73v5.TIL18.tsv.gz")
    add("example TIL01 empty-site TSD", f"TIL01_chr1:{ex['pos01'] + ex['F']}-{ex['pos01'] + ex['F'] + 4}", "inputs/TIL01.fa")
    add("region B73 view", f"B73v5_chr1:{VIEW_B[0]}-{VIEW_B[1]}", "this figure")
    add("region TIL18 view", f"TIL18_chr1:{VIEW_B[0] + OFF18}-{VIEW_B[1] + OFF18}", "collinear block")
    add("region TIL01 view (from alignment)", f"TIL01_chr1:{reg['win01'][0]}-{reg['win01'][1]}", "minimap2 asm10")
    add("region B73-TIL18 identity (largest block)", f"{reg['id18']:.4%} ({reg['mm18']} mismatches / {reg['len18']} bp)",
        "minimap2 asm10, this script")
    add("region B73-TIL01 identity, blocks >= 2 kb", f"{reg['id01'][0]:.2%}-{reg['id01'][1]:.2%}",
        "minimap2 asm10, this script")
    add("region insertions shared B73+TIL18 absent TIL01", f"{reg['n_wedges']}", "ortholog tables + alignment")
    sc = d["simcav"]
    gf = d["gfsim"]
    add(f"gene-flow simulations (f {gf['fmin']}-{gf['fmax']}, sisters inferred), runs", f"{gf['n']}",
        f"{SIM}/f*_Ta*_r*.json")
    add("gene-flow simulations, young D range (per run)", f"{gf['young'][0]:.2f}-{gf['young'][1]:.2f}",
        f"{SIM}/f*_Ta*_r*.json (Dins_young, signed toward B)")
    add("gene-flow simulations, old D range (per run)", f"{gf['old'][0]:.2f}-{gf['old'][1]:.2f}",
        f"{SIM}/f*_Ta*_r*.json (Dins_old, signed toward B)")
    simsrc = f"{ROOT}/benchmark/sim/out/<run>/stats.tsv (completeness_ratio) and sim/eval/<run>.json"
    add("sim completeness ratio, admixture alone (f0.18 runs)", f"{sc['adm'][0]:.3f}-{sc['adm'][1]:.3f} "
        f"({sc['adm'][2]} runs)", simsrc)
    add("sim completeness ratio, 20% one-sided dropout (fn0.2_f0 runs)", f"{sc['dro'][0]:.3f}-{sc['dro'][1]:.3f} "
        f"({sc['dro'][2]} runs)", simsrc)
    add("sim spurious |D_kmer| under dropout", f"{sc['dk'][0]:.3f}-{sc['dk'][1]:.3f}", simsrc)
    add("sim spurious |D_ins| under dropout", f"{sc['di'][0]:.3f}-{sc['di'][1]:.3f}", simsrc)
    add("max annotation bias in D_kmer / D_ins", "~0.05 / ~0.07",
        f"{ROOT}/benchmark/figures/SPEC.md caveats (dropout simulations scaled to the observed completeness ratio)")
    add("simulated genome size relative to B73", "~1/7 of the elements (200-Mb genomes, ~19,000 elements)",
        f"{ROOT}/benchmark/REPORT.md section 7.2")
    add("young shared insertions (K2P <= 0.005), real", f"{sum(int(ag.loc[s_, 'nA']) + int(ag.loc[s_, 'nB']) for s_ in STRATA[:3])}", S)
    add("identity spectrum scale factor for TIL01-TIL18 (1/calibration)", f"{1 / cal:.3f}", S)
    add("recent-shared-ancestry tracts at FDR <= 0.05", re.search(r"(\d+) at FDR <= 0.05", fnd.split("Recent shared")[1]).group(1),
        f"{MAIN}/findings.txt")
    add("maize-mexicana split (kya)", "30-60", f"published estimates quoted in {ROOT}/benchmark/REPORT.md section 2")
    add("maize domestication from parviglumis (kya)", "~9", "literature (Matsuoka et al. 2002, PNAS 99:6080)")
    add("mutation rate for ages", "3e-8 substitutions per site per year", f"{ROOT}/benchmark/figures/SPEC.md")
    for _, r in scr["cand"].iterrows():
        if r.B73v5 != EX["B"]:
            fam_n = int((ex["libB"].family == r.B_family).sum())
            add(f"passed-over candidate {r.B73v5}", f"{int(r.B_seq_len)} bp, family {r.B_family} ({fam_n} copies)",
                "B73 library")
    ages = sorted(round(a) for _, a in d["bres_ages"])
    add("region shared-insertion ages (kyr, TIL18 copy)", ", ".join(str(a) for a in ages), "TIL18 library K2P / 2 mu")
    return rows, gw, med


def legends(d, rows, gw, med, scr, reg):
    st, ag, ex, sims, comp = d["st"], d["ag"], d["ex"], d["sims"], d["comp"]
    v = {k: val for k, val, _ in rows}
    Dk, Di, D3, Ds = gw["D_kmer"], gw["D_ins"], gw["D3_triples"], gw["D_self_outgroup"]
    eDk, eDi, eD3, eDs = gw["edta_D_kmer"], gw["edta_D_ins"], gw["edta_D3_triples"], gw["edta_D_self_outgroup"]
    Dx = {s_: float(ag.loc[s_, "D"]) for s_ in STRATA}
    nA = {s_: int(ag.loc[s_, "nA"]) for s_ in STRATA}
    nB = {s_: int(ag.loc[s_, "nB"]) for s_ in STRATA}
    young_n = sum(nA[s_] + nB[s_] for s_ in STRATA[:3])
    tq = scr["tract"]
    up95 = float(v["example age, 95% upper bound from 0 differences in one LTR pair (kyr)"])
    wg, wn, gs = comp["wgk_all"], comp["wgk_noLTR"], comp["gene_snp"]
    ages = v["region shared-insertion ages (kyr, TIL18 copy)"]
    sc = d["simcav"]
    short = [
        "**Fig. 2 | The LTR clock separates gene flow from lineage sorting.** An insertion younger than the split of "
        "two lineages can be shared by them only through gene flow, and an element's two LTRs record its own age. "
        "Maize shares far more young insertions with *mexicana* than *parviglumis* does: introgression, read from "
        "transposons alone, without an outgroup or SNP panel.",
        "**A** Old insertions, polymorphic before the subspecies split, sort by chance into maize or *parviglumis*; "
        "an insertion that arose in *mexicana* after the split can reach maize only through gene flow. An element's "
        "two LTRs are identical when it inserts and then diverge, so their differences date it.",
        "**B** A stretch of maize chromosome 1 is nearly identical to *mexicana* and carries five insertions that "
        "*parviglumis* lacks, one of them with identical LTRs.",
        "**C** That young element sits at the same site in maize and *mexicana*, inside the same target-site "
        "duplication (one insertion event), while *parviglumis* carries the empty site.",
        "**D** Genome-wide, maize shares about three times as many young insertions with *mexicana* as "
        "*parviglumis* does; the excess fades among insertions older than the split, and genomes simulated without "
        "gene flow show none.",
        "**E** Maize and *mexicana* copies of the same element are near-identical about four times as often as "
        "*parviglumis* and *mexicana* copies, the mark of recent common ancestry.",
        "**F** Four tests that use only the transposon libraries detect the same excess, in agreement with "
        "whole-genome and gene-based tests that use an outgroup.",
    ]
    long_ = [
        "**Fig. 2 | The LTR clock separates gene flow from lineage sorting.** Maize B73 (Zm-B73-REFERENCE-NAM-5.0), "
        "*Zea mays* ssp. *parviglumis* TIL01 and ssp. *mexicana* TIL18 (PanAnd-1.0); intact LTR retrotransposons "
        "(LTR-RTs) annotated with LTRquest. Shared insertion: an element with orthologs in TIL18 and one sister and "
        "absent from the syntenic interval in the other sister, inferred from the LTR-RT libraries alone. Age: K2P "
        "divergence between the two LTRs of the TIL18 copy at 3 × 10$^{-8}$ substitutions per site per year "
        "(age = K2P/2μ). D = (a − b)/(a + b), a counting what B73 and TIL18 share and TIL01 lacks, b what TIL01 and "
        "TIL18 share and B73 lacks; SE from a 5-Mb block jackknife.",
        "**A** Schematic. Tubes: populations; lines: lineages carrying an insertion; split 30–60 kya and "
        "domestication of maize from *parviglumis* ~9 kya (published estimates). Insertions polymorphic before the "
        "split (gray) end up in maize and *mexicana* or in *parviglumis* and *mexicana* with equal chance, so lineage "
        "sorting adds no net excess. An insertion that arose in *mexicana* after the split (vermillion) reaches maize "
        "only by gene flow, drawn here in the direction reported by Yang et al. (2023); three genomes cannot resolve "
        "direction. The two LTRs are copied from one template, so they are identical at insertion and then diverge; "
        "at a site where the sisters differ, the other LTR carries the ancestral base (the outgroup of the LTR-site "
        "test in F).",
        f"**B** B73 chr1:{VIEW_B[0]:,}–{VIEW_B[1]:,} (v5), TIL18 chr1:{VIEW_B[0] + OFF18:,}–{VIEW_B[1] + OFF18:,} and "
        f"TIL01 chr1:{reg['win01'][0]:,}–{reg['win01'][1]:,} at one scale; every annotated intact LTR-RT drawn to "
        "size (bar: internal region; arrows: LTRs along the strand; outer element of a nest above the inner one). "
        f"Vermillion: insertions shared by B73 and TIL18 and absent from TIL01 ({reg['n_wedges']}); gray: present in "
        "all three. Ribbons: alignment to B73 (minimap2), shaded by identity per ~1 kb; wedges close onto the empty "
        f"sites in TIL01 (triangles). B73 is {reg['id18']:.2%} identical to TIL18 across the {reg['len18'] / 1e3:.0f}-kb "
        "aligned window but "
        f"{reg['id01'][0]:.1%}–{reg['id01'][1]:.1%} to TIL01: it carries a *mexicana*-like haplotype here, with old "
        f"insertions as well as the young one. Numbers: insertion ages ({ages} kyr).",
        f"**C** The boxed element (Gypsy/Retand, family {ex['family']}; B73 chr1:300,732,131–300,741,649, "
        f"{ex['lenB']:,} bp; TIL18 chr1:324,713,252–324,722,768, {ex['lenM']:,} bp), re-extracted from the "
        f"assemblies. Arcs: each copy's two LTRs, identical over all {ex['L']} bp (K2P = 0). Gray band: "
        f"{ex['n_sub']} substitutions (lines) and {ex['n_indel']} single-base indels (triangles) between the copies, "
        f"all internal. Junctions: the same 5-bp target-site duplication ({ex['tsd']}, boxed) at both ends of both "
        f"copies, canonical TG…CA ends; TIL01 (chr1:{ex['pos01'] + ex['F']:,}) has the empty site, its flanks joined "
        "across one duplication copy. Gray column: a flank site where B73 and TIL18 share G and TIL01 has A. One "
        f"element is a coarse clock: no difference in {ex['L']} bp only bounds its age below ~{up95:.0f} kyr (95%).",
        f"**D** Top: every shared insertion (dots; vertical position random), {nA_tot(ag):,} shared by B73 and TIL18 "
        f"(vermillion) and {nB_tot(ag):,} by TIL01 and TIL18 (blue), at the TIL18 copy's age (identical LTRs at left); "
        "numbers: insertions per stratum (dashed lines at K2P 0.002, 0.005, 0.01, 0.02, 0.05 and 0.1); outlined: "
        "the insertions of B. Bottom: D per stratum ± 2 SE at the stratum's median age (filled: LTRquest; open: "
        f"EDTA intact elements of the same genomes). D is {fmt_d(Dx[STRATA[0]])} for identical LTRs "
        f"({nA[STRATA[0]]} vs {nB[STRATA[0]]}) and {fmt_d(Dx[STRATA[1]])} to {fmt_d(Dx[STRATA[2]])} up to 83 kyr, "
        f"then falls to {fmt_d(Dx[STRATA[3]])}, {fmt_d(Dx[STRATA[4]])}, {fmt_d(Dx[STRATA[5]])}, "
        f"{fmt_d(Dx[STRATA[6]])} and {fmt_d(Dx[STRATA[7]])}. Gray: {len(sims)} simulations without gene flow "
        "(LTR-RT insertion, loss and sequence evolution on coalescent genealogies, *Zea* demography), dots = runs, "
        f"band = mean ± 2 SD; mean ± SD {fmt_d(sims.youngB.mean())} ± {sims.youngB.std():.2f} for young (K2P ≤ "
        f"0.005) and {fmt_d(sims.oldB.mean())} ± {sims.oldB.std():.2f} for old (> 0.02) insertions. Simulated "
        f"genomes hold ~1/7 of B73's elements (~{sims.Dins_young_n.median():.0f} young shared insertions per run vs "
        f"{young_n:,} here), so their spread is wider; with gene flow (f = {d['gfsim']['fmin']}–"
        f"{d['gfsim']['fmax']:.1f}, {d['gfsim']['n']} runs) young D was {d['gfsim']['young'][0]:.2f}–"
        f"{d['gfsim']['young'][1]:.2f} and old D {d['gfsim']['old'][0]:.2f}–{d['gfsim']['old'][1]:.2f}, the "
        "pattern seen here. Gray band: published split. Insertions younger than the split "
        "can be shared only through gene flow; older strata mix gene flow with lineage sorting. Some young TIL01–TIL18 "
        f"sharing exists ({nB[STRATA[0]]} at K2P 0): *parviglumis*–*mexicana* gene flow or K2P noise.",
        f"**E** All 1:1 orthologs, B73–TIL18 ({int(d['fl'].n_target):,}; vermillion) and TIL01–TIL18 "
        f"({int(d['fl'].n_mirror):,}; blue), by whole-element divergence in classes that double in width (identical "
        f"copies at left). TIL01–TIL18 counts are scaled by {1 / float(d['fl']['calibration']):.3f} to equal numbers "
        f"above the median divergence ({float(med) * 1e3:.1f} per kb). Below 2 differences per kb (~33 kyr) B73–TIL18 "
        f"orthologs outnumber TIL01–TIL18 {float(v['identity spectrum ratio < 0.002']):.1f}-fold "
        f"({int(float(v['identity spectrum B73-TIL18, divergence < 0.002'])):,} vs "
        f"{int(float(v['identity spectrum TIL01-TIL18 scaled, divergence < 0.002'])):,}; shaded); deeper classes match.",
        "**F** Genome-wide D ± 2 SE. Filled: four tests from the LTR-RT libraries alone: single-copy k-mers shared by "
        f"exactly two genomes ({fmt_d(Dk[0])}, Z = {Dk[2]:.1f}), insertions ({fmt_d(Di[0])}, Z = {Di[2]:.1f}), "
        f"ortholog-triple divergence ({fmt_d(D3[0])}, Z = {D3[2]:.1f}; {v['D3 ortholog triples']} triples) and "
        f"ABBA/BABA at LTR sites polarized by the other LTR ({fmt_d(Ds[0])}, Z = {Ds[2]:.1f}; "
        f"{int(float(v['D_self ABBA sites'])):,} vs {int(float(v['D_self BABA sites'])):,} sites). Open: the same on "
        f"EDTA intact elements (Z = {eDk[2]:.1f}, {eDi[2]:.1f}, {eD3[2]:.1f}, {eDs[2]:.1f}). Diamonds: the k-mer test "
        f"on whole assemblies ({fmt_d(wg[0])}, Z = {wg[0] / wg[1]:.1f}) and with LTR-RTs masked ({fmt_d(wn[0])}, Z = "
        f"{wn[0] / wn[1]:.1f}), and gene-space SNP ABBA/BABA with *Z. diploperennis* as outgroup ({fmt_d(gs[0])}, "
        f"Z = {gs[0] / gs[1]:.1f}; {int(v['gene-space SNP genes'].replace(',', '')):,} genes). The tests measure "
        "different things, so their sizes differ; none overlaps 0. The k-mer and insertion tests assume equal "
        "annotation completeness and branch lengths: TIL18's oldest quarter of insertions (K2P > 0.039) is present "
        f"{float(v['completeness ratio B73/TIL01 (TIL18 K2P > 0.0391)']):.3f} ± "
        f"{float(v['completeness ratio SE']):.3f} times as often in B73 as in TIL01, against "
        f"{sc['adm'][0]:.2f}–{sc['adm'][1]:.2f} from admixture alone (f = 0.18) and {sc['dro'][0]:.2f}–"
        f"{sc['dro'][1]:.2f} from a simulated 20% one-sided annotation dropout, which gave spurious D of "
        f"{sc['dk'][0]:.2f}–{sc['dk'][1]:.2f} (k-mers) and {sc['di'][0]:.2f}–{sc['di'][1]:.2f} (insertions); at most "
        "~0.05 and ~0.07 of these two D could be annotation bias. The triple and LTR-site tests (immune to dropout "
        "in simulations), the SNP test and whole-genome k-mers agree.",
        f"**Example and exceptions.** The element in B and C was chosen by rule among the {scr['n']} shared "
        f"insertions with identical LTRs: {scr['tested']} fall in a random subset checked against the TIL01 "
        f"assembly, {scr['empty']} of them with the empty site; identical LTRs in both copies, one duplication at "
        f"both ends, TG…CA ends and confident, non-nested annotation left {len(scr['cand'])}. Retand was preferred "
        f"to a 943-bp Ale (atypically short) and a member of a 10-copy Ale family: it is the commonest superfamily "
        f"among the {scr['n']} ({scr['n_sf']}), its family is B73's largest ({scr['fam_n']:,} copies, length "
        f"quartiles {scr['fam_q'][0]:,.0f}–{scr['fam_q'][2]:,.0f} bp) and its LTRs are typical (quartiles "
        f"{scr['ltr_q'][0]:.0f}–{scr['ltr_q'][2]:.0f} bp). Its neighborhood is typical: {scr['nd_me']} elements "
        f"near-identical to TIL18 within 100 kb (median {scr['nd_q'][1]:.0f}, quartiles {scr['nd_q'][0]:.0f}–"
        f"{scr['nd_q'][2]:.0f}). It lies in one of the 21 recent-shared-ancestry tracts that pass the target-decoy "
        f"FDR ({tq.chrom.replace('B73v5_', '')}:{(tq.s0 + 1) / 1e6:.2f}–{tq.e / 1e6:.2f} Mb, q = "
        f"{scr['tract_q']:.3f}), as do {scr['n_in_tract']} of the {scr['n']} ({scr['frac_in_tract']:.0%}). "
        f"Exceptions: the oldest stratum ({fmt_d(Dx[STRATA[7]])}) sits above the one before it "
        f"({fmt_d(Dx[STRATA[6]])}); the EDTA triple test is weak (Z = {eD3[2]:.1f}).",
        f"Analysis: asc-oulab:/data2/chris/maize_introgression/benchmark · Script: {OUT}/{STEM}.py · {DATE}",
    ]
    return short, long_


def nA_tot(ag):
    return int(ag.nA.astype(int).sum())


def nB_tot(ag):
    return int(ag.nB.astype(int).sum())


def md_runs(text):
    out, pos = [], 0
    for m in re.finditer(r"\*\*(.+?)\*\*|\*(.+?)\*", text):
        if m.start() > pos:
            out.append((text[pos:m.start()], "n"))
        out.append((m.group(1), "b") if m.group(1) is not None else (m.group(2), "i"))
        pos = m.end()
    if pos < len(text):
        out.append((text[pos:], "n"))
    return out


def legend_page(paras, fs=10.0):
    """A page as wide as the figure, height fitted to the text; ragged right, mixed italic/bold runs."""
    from matplotlib.font_manager import FontProperties
    props = {st: FontProperties(family="Liberation Sans", size=fs, style="italic" if st == "i" else "normal",
                                weight="bold" if st == "b" else "normal") for st in "nib"}
    MDPI = 2400
    tmp = plt.figure(figsize=(W / 25.4, 2), dpi=MDPI)
    rend = tmp.canvas.get_renderer()
    cache = {}

    def wmm(t, st):
        if (t, st) not in cache:
            w_, _, _ = rend.get_text_width_height_descent(t, props[st], ismath="$" in t)
            cache[(t, st)] = w_ * 25.4 / MDPI
        return cache[(t, st)]

    space = wmm("a a", "n") - wmm("aa", "n")
    margin, width = 3.0, W - 6.0
    lh, gap = fs * 1.32 * 25.4 / 72, fs * 0.55 * 25.4 / 72
    laid = []
    for para in paras:
        words, cur = [], []
        for t, st in md_runs(para):
            for tok in re.split(r"(\s+)", t):
                if not tok:
                    continue
                if tok.isspace():
                    if cur:
                        words.append(cur)
                        cur = []
                else:
                    cur.append((tok, st))
        if cur:
            words.append(cur)
        lines, line, x = [], [], 0.0
        for wd in words:
            ww = sum(wmm(t, st) for t, st in wd)
            if line and x + space + ww > width:
                lines.append(line)
                line, x = [], 0.0
            if line:
                x += space
            xx = x
            for t, st in wd:
                line.append((xx, t, st))
                xx += wmm(t, st)
            x += ww
        if line:
            lines.append(line)
        laid.append(lines)
    plt.close(tmp)
    hh = 2 * margin + sum(len(L_) for L_ in laid) * lh + (len(laid) - 1) * gap + 1.0
    fig = plt.figure(figsize=(W / 25.4, hh / 25.4))
    y = margin + lh * 0.8
    for lines in laid:
        for line in lines:
            for xx, t, st in line:
                fig.text((margin + xx) / W, 1 - y / hh, t, fontproperties=props[st], va="baseline", ha="left")
            y += lh
        y += gap
    return fig


def write_numbers(rows):
    with open(f"{OUT}/{STEM}_numbers.tsv", "w") as fo:
        fo.write("quantity\tvalue\tsource\n")
        for k, v_, s_ in rows:
            fo.write(f"{k}\t{v_}\t{s_}\n")


def main():
    global VERBOSE
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-v", "--verbose", action="store_true", help="report per-step progress and checks")
    ap.add_argument("--figure-only", action="store_true", help="write only the PNG (layout iterations)")
    a = ap.parse_args()
    VERBOSE = a.verbose
    setup_rc()
    log(f"{STEM}: loading tables and raw data")
    d = load()
    log(f"{STEM}: example checks passed: {', '.join(k for k, v in d['ex']['checks'].items() if v)}", v=True)
    fig, bres = draw_figure(d)
    d["bres_ages"] = list(bres["ages"].values())
    fig.savefig(f"{OUT}/{STEM}.png", dpi=300)
    if a.figure_only:
        log(f"{STEM}: wrote {OUT}/{STEM}.png")
        return
    scr = screen_examples(d)
    d["simcav"] = sim_caveats()
    d["gfsim"] = gene_flow_sims()
    reg = region_numbers(d, bres)
    rows, gw, med = build_text(d, scr, reg)
    short, long_ = legends(d, rows, gw, med, scr, reg)
    write_numbers(rows)
    with PdfPages(f"{OUT}/{STEM}.pdf", metadata={"Title": "Fig. 2 fig2_clock", "Author": ""}) as pdf:
        pdf.savefig(fig, dpi=600)
        for paras in (short, long_):
            lf = legend_page(paras)
            pdf.savefig(lf)
            plt.close(lf)
    plt.close(fig)
    log(f"{STEM}: wrote {STEM}.png, {STEM}.pdf (3 pages), {STEM}_numbers.tsv ({len(rows)} numbers) in {OUT}")


if __name__ == "__main__":
    main()
