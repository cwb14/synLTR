# Task 24 phase B review: scoring, decision, Step 9 (B1, B2, B3)

Reviewer: task reviewer, 2026-11-11. Reviewed from the files (ledger ruling R8). D = /data2/chris/maize_introgression/benchmark_pav/bakeoff.
Requirements read: task-24-brief.md Steps 5-9, task-24-rulings.md rules 13-16, task-24b-rulings.md (1-18), task-24b-report.md.
Under review: D/REPORT.md, D/figures/bakeoff_overview/ and SPEC.md, D/../dead_ends.md, D/03_score_sims.py, D/scores/discordance.py,
D/05_chr10_metrics.py, D/07_readout_compare.py, D/09_report_tables.py, D/inspections/{b1_insp.py, b1_thin_anchor.py}, D/scores/,
D/metrics/, and LTRpav commit 568f90d.

## Verdicts

- **Spec: ✅** Rules 13-15 and ruling 12 were applied as written, and the winner follows from them. The unmet items (below) are
  documented deviations, most caused by the controller's stop of the chr10 batch, and none can change the decision.
- **Quality: Changes needed**, in REPORT.md text and the figure only. Every decision number reproduces exactly from the raw
  files, and commit 568f90d is correct. One Important misstatement sits in the robustness table of section 0.

Counts: Critical 0, Important 1, Minor 11.

## How I checked (independent of the implementer's pooled tables and parsers)

Scripts and outputs in D/review24b/ (env ltrpav_bench; ltrpav from D/b3_snap/src, `ltrpav.__file__` checked; b3_snap's 35 .py
files are byte-identical to `git show 568f90d:src/...`).
- `recompute_sims.py`: re-scored all 168 final-engine run-directions (14 scored variants x 6 sims x 2 directions) from the raw
  calls, elements and truth.tsv with a minimal scorer written for the review. **0 mismatches** against every per-run
  `*.score.tsv` (tp/fp/fn per state and tier set, and each file's 4-dp crf). So the score files are current, not stale skips.
  Pooled from the per-run score files (not pooled.tsv) -> `sims_recomputed.tsv`.
- `recompute_cost.py`: its own run.log parser and chunk-marker busy time, .fai lengths and r per pair, per-stage and linear
  whole-genome (WG) estimates, ruling 12 and eight readings -> `cost_recomputed.tsv`.
- `check_claims.py`: section 2 side claims from the raw calls.
- `default_run/`: plain `ltrpav run` (no --anchor, 8 threads) from the 568f90d snapshot on sims R1_s1 and R2_s1.
- `repo568/`: `git archive 568f90d tests pyproject.toml` plus the snapshot's src, for pytest and ruff.

### Decision, recomputed

| candidate | P high (tp/fp) | E high (tp/fp) | crf all (num/den) | crf high | WG pair h, mean / worst (per stage) | WG GB worst, per stage / linear (from chr10_cost_final.tsv; method checked by hand on 2) |
|---|---|---|---|---|---|---|
| mm2 | 0.9989 (2754/3) | 0.9976 (1237/3) | 0.899194 (4460/4960) | 0.856855 | 0.3899 / 0.4414 | 58.3 / 362 |
| mm2_N50 | 0.9989 (2754/3) | 0.9976 (1237/3) | 0.899194 (4460/4960) | 0.856855 | 0.4592 / 0.5583 | 53 / 357 |
| flank-mm2_2k | 0.9989 (2736/3) | 0.9936 (1243/8) | 0.898387 (4456/4960) | 0.853629 | **0.1941** / 0.2671 | 32 / 212 |
| flank-mm2_10k | 0.9989 (2739/3) | 0.9976 (1249/3) | 0.897782 (4453/4960) | 0.855645 | 0.3500 / 0.3740 | 32 / 193 |
| flank-mm2_20k | 0.9989 (2739/3) | 0.9976 (1247/3) | 0.897379 (4451/4960) | 0.855242 | 0.4284 / 0.5000 | 30 / 234 |
| flank-mm2_5k | 0.9989 (2735/3) | 0.9976 (1245/3) | 0.895766 (4443/4960) | 0.853629 | 0.2187 / 0.2537 | 33 / 233 |
| flank-blast_10k | 0.9993 (2671/2) | 0.9959 (1211/5) | 0.884677 (gap 0.0145: out) | 0.832661 | 10.56 / 20.17 (FAIL) | |
| fastga = hybrid | 0.9991 (2315/2) | 0.9802 (1038/21) | 0.807460 (out) | 0.717540 | unmeasured | |
| flank-mm2_2k_lastz | 0.9993 (2799/2) | 0.9940 (1320/8) | 0.930040 (4613/4960) | 0.883669 | 0.452 (one-pair estimate) | |

- **Precision bar** (rule 14): every scored candidate passes; lowest pooled E is fastga_lastz 0.9711.
- **Band** (rule 15, exact fractions): best 0.899194, the six above, largest gap flank-mm2_5k 0.003427. The band is the same set
  at high tier, where 2k and 5k have identical crf (4234/4960), so ruling 13's choice of tier set is moot here.
- **Cost bar** (rule 13, per-stage estimate of ruling 3): all six pass. The worst pair is 0.25-0.56 h and memory per stage is
  <= 58.3 GB. mm2 and mm2_N50 fail only the linear memory bound (362 and 357 GB): "confirm in Task 25", as ruling 3 says.
- **Ruling 12:** cheapest flank-mm2_2k 0.19413 h. flank-mm2_5k 0.21870 h (x1.1266) is a cost tie and goes back to crf, where
  0.8984 > 0.8958. The next costs are flank-mm2_10k at x1.80 and mm2 at x2.01. **Winner: flank-mm2_2k, reproduced.**
- **Backend** (rule 15 with the winner): lastz 0.930040 against mappy 0.898387 (+0.0317, outside the band). On paired
  elements b = 1 and c = 158 (sign test p = 4e-46), and lastz is better in all 6 sims (+0.022 to +0.042). Both bars are met.
  flank-mm2_2k_wfa timed out (status.json: timeout, exit 124, 1,800 s), a failure under rule 8. **lastz, reproduced.**
- Ruling 3's per-stage estimator (anchoring x r + busy/threads x r) was fixed before any result. Only the aggregation over
  pairs and the 20% tolerance were post hoc.

All readings of "cheaper" (the costs are mine and match chr10_cost_final.tsv to 4 dp):

| reading | winner |
|---|---|
| ruling 12: per stage, mean, 20% tolerance | flank-mm2_2k ({2k, 5k} cost-tied -> crf) |
| per stage, worst pair, tolerance | flank-mm2_2k (5k 0.2537, 2k 0.2671 tied -> crf) |
| per stage, mean, no tolerance | flank-mm2_2k |
| per stage, worst pair, no tolerance | flank-mm2_5k |
| rule 11 linear, mean, tolerance | flank-mm2_20k (5k 0.4235, 20k 0.4810 tied -> crf) |
| rule 11 linear, mean, no tolerance | **flank-mm2_5k** |
| rule 11 linear, worst pair, tolerance | **mm2_N50** (20k 0.6189, N50 0.7105 = +14.8% tied -> crf 0.8992 > 0.8974) |
| rule 11 linear, worst pair, no tolerance | flank-mm2_20k |

### Cost and memory, checked by hand (item 2)

- **flank-mm2_2k from run.log.**
  - Anchoring, B73~T18: 08:03:53 to 08:04:04 (11 s, TIL18 index built) plus 08:04:55 to 08:05:08 (13 s, B73v5 index) = 24.0 s.
  - Anchoring, B73~T01: 17 + 7 s, plus the reused B73v5 index 7.0 s = 31.0 s.
  - Anchoring, T18~T01: 8 + 8.7 (reused TIL01 index) + 6 + 5.5 (reused TIL18 index) = 28.2 s.
  - Genotype wall: B73v5>TIL18 37.3 - 11 = 26.3 s; TIL01>TIL18 429.1 - 6 = 423.1 s.
  - All of these equal chr10_cost_final.tsv. Per stage, B73~T18 = (24 + 286.7/32) x 15.743 / 3600 = 0.1441 h.
- **time.txt against the logs:** time.txt wall equals the sum of the log's direction totals plus element loading and loci,
  within 5 s, for all six band runs (e.g., 2k 629.4 s against 624.0 s; mm2 393.8 s against 388.4 s).
- **Busy time against CPU:** busy time equals GNU-time CPU on the genotype-only runs (1.009 for flank-mm2_2k_lastz and
  mm2_lastz, 1.008 for mm2_wfa). For mappy, 132.7 s busy against 135.4 s CPU (metrics/genocpu). The noise pair 111.4 / 132.7
  s and its byte-identical calls are confirmed.
- **Memory rule:** max(max_rss_kb, peak_tree_pss_kb), e.g., 2k: max(1.36, 12.53 GB) x 15.743 = 197.3 GB (linear bound).
  Per stage, from mem.tsv samples >= 2 s into the stage:
  - 2k: B73v5 index 1.98 GB x 14.31 = 28.3 GB;
  - mm2: TIL01 index 3.51 GB x 16.61 = 58.3 GB (the 58-GB worst case).

  Both match the table.
- **Mechanism of the 2k-vs-5k cost gap:** the gap is real, not noise. 2k maps 20.7 Mb of flank against 5k's 41.6 Mb, and its
  flank mapping takes 5.5-15.4 s against 11.6-19.2 s.
- **Sensitivity:** busy/threads leaves out the pool tail. Adding each pair's unscaled tail (pool span beyond busy/threads;
  2k: 21, 9, 478 s; 5k: 5, 1, 116 s) gives means of 0.241 h for 2k and 0.230 h for 5k. That is still a cost tie, so crf
  decides and 2k still wins. On the worst pair, the defect's 478-s tail makes 5k cheaper (0.286 h against 0.400 h), the same
  flip as the worst-pair reading without tolerance.

### Step 9 (item 3)

- `git show --stat 568f90d`: only docs/DESIGN.md, src/ltrpav/constants.py and tests/test_smoke.py change. Its parent is
  1cb1b34, the engine of every final run: the sims rerun began at 07:50:11, after the 07:46:16 commit.
- **FLANK_CAP** is used only in anchor/flanks.py:
  - as the defaults of `flank_pieces`, `FlankMm2Route`, `FlankBlastRoute` and `HybridRoute`, bound at import;
  - every caller passes `self.cap` explicitly;
  - `get_route("flank-mm2")` returns `FlankMm2Route()` with cap 2000, and `cli.BACKEND` is "mappy".

  mm2, fastga and paf routes are unaffected.
- **Plain default run** from the snapshot on R1_s1 and R2_s1: the calls are **byte-identical** (decompressed md5) to
  runs/<sim>/flank-mm2_2k in both directions, and differ from 5k and mm2. The anchor cache keys in `*.npz.done.json` are equal.
- **Tests and lint:**
  - `pytest -W error` with the env's bin first on PATH: 733 collected, exit 0;
  - `ruff check`: clean.
- **Commit:** author and committer cwb14; no trailers or AI attribution; on plan1-engine with no upstream and no remote
  containing it (not pushed).
- **DESIGN:** 5.3 "without long join" is fixed and `boundary_offset` is gone (rule 16). The section 9 outcome matches REPORT.

## Spec compliance: unmet or deviated items (all documented)

1. **Ruling 14:** flank-mm2_2k_wfa ran on 1 of 6 sims. It timed out at 1,800 s; the other 5 were skipped (REPORT 7.5 and 10).
   This is justified by rule 8, since a timeout is a failure, and wfa also fails the cost bar on chr10 (mm2_wfa 21.4 h).
2. **Ruling 3 thread scaling (mm2_t64), and the chr10 rows and read-out comparison of fastga and hybrid (rulings 4-6):**
   - not measured; the controller stopped the chr10 batch at 11:13 (chr10/batch.exit: 143, "hybrid and mm2_t64 not run");
   - stated as "unmeasured, not failed" (REPORT 0, 4 and 10);
   - both routes are outside the band, so the decision cannot change.
3. **Ruling 6's 10 FastGA breakpoint dotplots** come from the stock run's raw blocks re-netted with the final net, not from a
   final-engine run. This is a stated substitute (REPORT 5a).
4. **Brief Step 5 ("time and RSS"):** 03_score_sims.py writes the sims wall time (summary.tsv) but no RSS. RSS is only in
   runs/runs.tsv. Trivial, because ruling 3 gives the sims' memory no weight.

Met:
- Step 5 per-state P/R for both tier sets, crf and unresolved; pooled sums of counts; per-sim values; confusion tables for
  every candidate.
- Step 6 metrics and extrapolation; Step 7 read-out comparison and 37 dotplots; Step 8 rules verbatim.
- Ruling 8: the real-data metrics are beside the decision (REPORT 7), and it says plainly what argues for mm2 and against 2 kb.
- Ruling 9 write-ups and figure; ruling 12's disclosure and readings; ruling 14's PARAMS.md declaration (mtime 10:27:24,
  before the first follow-up run started at 10:27:56).
- Ruling 15 (cap set to the winner's and interplay explained; lastz recorded, not ported); ruling 16's six caveats (REPORT 8,
  dead_ends.md); ruling 17; thread budget (B2 runs sequential, <= 32 threads beside the batch's 32).

## Findings

### Critical
None.

### Important

**I1. The linear row of the "cheaper" alternative readings is wrong, and it hides a reading that picks a whole-genome route.**
- **Where:**
  - REPORT.md:39 (section 0) says "rule 11's linear estimate | 20 kb".
  - The implementer's table (task-24b-report.md:99-100) has two linear rows. It applies the 20% tolerance to the mean and
    silently drops it for the worst pair.
- **What the eight readings give** (my table above):
  - linear, mean, no tolerance: **flank-mm2_5k**;
  - linear, worst pair, with tolerance: **mm2_N50**. Cheapest is 20k at 0.6189 h; N50 at 0.7105 h is +14.8%, so the two are
    cost-tied, and crf decides 0.8992 > 0.8974.
- **Effect:**
  - Section 0 reads as if every reading picks a flank route; one picks the whole-genome route.
  - The winner under the rules as written is unaffected, because ruling 3 fixed the per-stage estimator before any result.
  - It matters because ruling 12 asked for an honest statement of the alternative readings of a post-hoc definition.
- **Fix:**
  - Replace the row with the four linear sub-readings and their winners (20k, 5k, mm2_N50, 20k).
  - Keep the note that the linear form is inflated for 2 kb by the 423-s window-merge chunk.
  - Script the decision trace (band, then bars, then ruling 12, then readings), for example in 09_report_tables.py. Today no
    checked-in script computes it: 09's cost summary prints 2 decimals and "no decision here". That is how this slipped in.
  - The figure legend and DESIGN 9 cite only the per-stage readings, which are correct.

### Minor

**M1. The order-independence claim is overstated** (REPORT.md:44-46).
- "With lastz chosen first ... the same route wins" covers only the lastz routes that were run (mm2, fastga, flank-mm2_2k).
- flank-mm2_5k/10k/20k and mm2_N50 never ran with lastz.
- The 1.38x ratio is a one-pair (B73~T18), one-direction estimate, not ruling 12's three-pair mean.
- Qualify the claim: "among the measured lastz combinations".

**M2. The candidate count is wrong** (REPORT.md:438). "All 15 scored candidates pass": 14 were scored (9 routes, 4 phase-A
backends and flank-mm2_2k_lastz). The 15th, flank-mm2_2k_wfa, timed out unscored.

**M3. A stale count** (REPORT.md:305). "(101 rows over all routes)" is the B1 count. The final readout tables hold 135
high-tier contradictions, 130 without the yardstick. All of them are still route E against read-out present (E>P 81, E>T 48,
E>S 6), so the claim stands but the number is out of date.

**M4. FastGA's cause is stated three ways.**
- REPORT.md:417-418 (section 6) still says "Suspected cause: paralog chains netted first. Not inspected."
- That contradicts B3's section 5a (REPORT.md:386-397) and dead_ends.md:17, which give CHAIN_LOOKBACK as the cause.
- Also, REPORT.md:397 "mostly a chaining-lookback effect" and dead_ends.md:17 "Measured cause" overstate the test. It measured
  windows and anchored bp, not crf ("not genotyped or scored").
- None of this affects the decision: FastGA is outside the band under both engines.

**M5. A wrong generalization about per-sim precision** (REPORT.md:130). "Every mappy route keeps E high-tier precision >= 0.975
in every sim" is false for fastga and hybrid, which use the mappy backend and have a per-sim minimum of 0.918, as the next
line says. Write "every mm2 and flank-mm2 route".

**M6. A stale dead_ends entry** (dead_ends.md:46). hybrid "Pending. Its chr10 run had not finished at B2." The batch was
stopped before hybrid started (chr10/batch.exit). It should say "not run; chr10 cost unmeasured".

**M7. Figure 1C draws unmeasured costs as if measured** (bakeoff_overview.py:292-296 and 315-316).
- fastga, hybrid, fastga_lastz and fastga_wfa sit at arbitrary x inside a hatched band at 30-60 h.
- That band is on the numeric log axis, right of the gray beyond-the-bar zone.
- So the panel reads as "FastGA costs > 25 h and fails the bar", which was not measured on this engine (REPORT 4: unmeasured,
  not failed).
- Fix: move them to an off-axis column behind an axis break.

**M8. The figure's headline is stronger than the data** (bakeoff_overview.py:393).
- "...as reliably as aligning the whole genomes":
  - on the sims, flank 2 kb has 8 high-tier false E against mm2's 3 (E precision 0.9936 against 0.9976; Fisher p = 0.23);
  - on chr10 it has 18 high-tier read-out contradictions against 8, with 3 inspected wrong-copy errors.
- SPEC.md:67 lists "8 against 3" as a long-legend caveat, but the legend dropped it.
- Fix: write "as accurately" and restore the caveat.
- Otherwise the figure passes the skill's figure check, answered independently from the PNG and the legend pages:
  - A is in genome coordinates with every element drawn.
  - B is a verified real site: I re-fetched it. TSD CTTTC exact; ends TG...CA; 42/44 flank bp identical; TIL18 shows one
    TSD copy.
  - The control is a full partner. The bars and the noise bands are drawn, and the per-sim dots show that the tie band is
    noise-level.
  - Panel A's full agreement is typical. 11 of the 22 dense 150-kb tiles agree fully, though chromosome-wide state agreement
    is 83%; giving that number in the legend would help.

**M9. The 20% noise tolerance rests on one pair of measurements** (REPORT.md:211-212). It is 111.4 against 132.7 s, measured at
32 against 8 threads, so thread count is a confound beside load. Call it n = 1. The mean reading picks 2 kb with or without
the tolerance.

**M10. lastz's cost may not extrapolate linearly to whole genomes.**
- Its chr10 CPU is 65-75% kernel time: flank-mm2_2k_lastz has 505 s user and 925 s sys; mm2_lastz has 213 s user and 635 s
  sys.
- The likely cause is the per-window subprocess and temp files (backends.py:89 and 109).
- The 0.45-h estimate covers one pair and one direction. TIL18~TIL01, where mappy's busy time is 3.2x higher, was not run.
  Scaling it gives about 1.3 h, still under the bar.
- Confirm with the ported backend in Task 25.

**M11. Smaller gaps in coverage and documentation.**
- **Rule 5a loopholes:** their scale (REPORT.md:358-363 and 477-479) was measured on mm2 and flank-mm2_5k only
  (inspections/data/thin_*), not on the default flank-mm2_2k.
- **Shared FLANK_CAP:** flank-blast and hybrid now default to an unmeasured 2-kb cap, and there is no CLI override. This is
  disclosed.
- **DESIGN 5.1** (568f90d, around line 182) still argues for flanks "capped at ~10-20 kb (published 0.5-2 kb flanks would
  mostly sit inside other TEs in maize)" before the new 2-kb sentence. Mark that paragraph as the pre-bake-off prior.
- **wfa timeout:** the B2 report and memo blame load ~190. But mm2_wfa's sims took 200-311 s, and this run reached 504 of 512
  windows with 13 guarded windows, which points to the route's windows instead. This has no effect: a timeout is a failure.

## What would make it Approved
- Fix I1, the linear readings in REPORT section 0, and preferably script the decision trace.
- Fix M2 and M3, the counts.
- Fix M4 and M5, the section 6 cause and the per-sim wording.
- Fix M6, dead_ends.md.
- Fix M7 and M8 in the figure.

No reruns are needed. The route (flank-mm2, 2 kb), the backend (lastz) and commit 568f90d stand.

## Re-review (fix round 1, 2026-11-11)

Scope: the "Fix round 1" section of task-24b-report.md, and only the files it touched:
- D/REPORT.md, D/../dead_ends.md, D/memo_bakeoff.md;
- D/10_decision_trace.py and D/metrics/decision_trace.txt;
- D/inspections/data/thin_flank-mm2_2k_*;
- D/figures/ (bakeoff_overview.* and SPEC.md).

Same rules as before: read-only outside D/review24b/, ltrpav from D/b3_snap only, at most 8 threads.

**Result:** 11 ADDRESSED (I1, M1-M10), 1 PARTIAL (M11), 0 NOT ADDRESSED. 1 new Minor problem and 3 wording nits.
**Quality verdict now: Approved.** What remains is a deferred repo edit, a robustness gap in the script and wording.

### Decision trace: run by the reviewer, and it matches
- **How it was run:** a byte-identical copy of D/10_decision_trace.py, run in D/review24b/trace_run/ (symlinks to scores/, runs/,
  chr10/ and the two metrics inputs). Env: ltrpav_bench with PYTHONPATH=D/b3_snap/src; the script imports no ltrpav. It
  exited 0, and its trace is **identical** to the checked-in D/metrics/decision_trace.txt (diff empty).
- **Against my own recomputation** (review24b/sims_recomputed.tsv and cost_recomputed.tsv):
  - all decisions match: precision bar 14/14; the band of six; ruling 12 -> flank-mm2_2k (5k cost-tied at x1.126, crf
    decides); backend lastz (+0.031653); order check -> flank-mm2_2k_lastz;
  - all eight readings match, including linear worst pair + tolerance -> mm2_N50;
  - crf is identical to 6 decimals;
  - every per-stage and linear cost is within 2e-4 h. The residue comes from the 1-decimal seconds in
    chr10_cost_final.tsv: flank-mm2_20k worst pair is 0.4999 against my 0.5000.

### Findings

| finding | verdict | evidence |
|---|---|---|
| I1 linear readings | ADDRESSED | See note 1. |
| M1 order claim | ADDRESSED | REPORT.md:51-55: "among the measured lastz combinations", the costs called one-pair and one-direction estimates, and the routes never run with lastz named. 1.37x = 0.620/0.453 (trace section 7). |
| M2 candidate count | ADDRESSED | REPORT.md:27 and 470-471: 14 scored, plus flank-mm2_2k_wfa timed out unscored. |
| M3 stale count | ADDRESSED | REPORT.md:333-335: 135 rows, 130 without the yardstick, all route E against read-out present (recounted: E>P 81, E>T 48, E>S 6). Nit c below. |
| M4 FastGA cause | ADDRESSED | See note 2. |
| M5 per-sim wording | ADDRESSED | REPORT.md:144-148. Recomputed per-sim E high-tier minima: flank-mm2_2k 0.97475 (193/198, R1_s1); mm2, N50, 5k, 10k and 20k 0.99034-0.99048; flank-blast_10k 0.98990; flank-mm2_2k_lastz 0.97642; fastga and hybrid 0.91837. All as stated. |
| M6 dead_ends hybrid | ADDRESSED | dead_ends.md:47-48: "chr10: not run", with the batch stop cited. |
| M7 unmeasured costs | ADDRESSED | See note 3. |
| M8 headline | ADDRESSED | See note 4. Nit b below. |
| M9 noise n = 1 | ADDRESSED | REPORT.md:112-113 and 230-232: one pair of measurements, thread count confounded with load, and the mean reading picks 2 kb either way. |
| M10 lastz scaling | ADDRESSED | REPORT.md:274-280: 65-75% kernel time (925/1,430 and 635/848, matching time.txt), and the 1.33-h TIL18~TIL01 sensitivity (trace section 6). |
| M11 | PARTIAL | See note 5. |

Notes on the findings:
1. **I1, linear readings.**
   - REPORT.md:37-49 now lists all four linear sub-readings with the right winners (20k, 5k, mm2_N50, 20k), and says
     "one reading picks a whole-genome route".
   - The decision trace is scripted (REPORT.md:499-507 and 590) and matches. Line 34-35 adds that ruling 3's estimator
     predates the results.
2. **M4, FastGA cause.** The account is now consistent:
   - REPORT.md:427-429 says the lookback explains the windows and the anchored bp, and that its crf effect was not tested;
   - section 6 (lines 448-450), 8.5 (line 532) and dead_ends.md:17-18 match.
3. **M7, unmeasured costs.** I re-rendered the figure (review24b/fig/p2-*, panelC2.png).
   - The cost axis ends at about 28 h with an axis break. The gray beyond-the-bar zone stops at the break.
   - FastGA/hybrid, FastGA + LASTZ and FastGA + WFA stand in a separate white column, "cost not measured", with no x scale.
   - The hatched numeric band is gone. The long legend says position carries no cost there.
4. **M8, headline.**
   - The short legend now reads "On simulated maize genome pairs ... as accurately as aligning the whole genomes, at half
     the computing time". It adds the real-data caveat (wrong-copy calls in duplicated segments), and legend D says "a
     difference within chance".
   - The long legend restores 8 against 3 (p = 0.23; my Fisher p = 0.226), 18 against 8 chr10 contradictions (11+7
     against 5+3) with 3 inspected wrong-copy cases, and the other readings including whole-genome. "Half the computing
     time" is conservative in CPU terms: chr10 run CPU is 1,890 s against 6,988 s.
   - Panel A typicality: 15/15 here, "not the rule": 3 of 7 region-rule tiles, and 7,533 of 9,064 = 0.831 chromosome-wide,
     which I recounted. I reran bakeoff_overview_data.py in a scratch mirror; its 108 numbers and data.json are
     byte-identical to the shipped ones.
   - The panel B site is unchanged and was verified before.
5. **M11.**
   - Thin-run coverage: **addressed**. thin_flank-mm2_2k_{B73v5__TIL18,TIL18__B73v5}.tsv have 2,069 + 2,049 = 4,118
     high-tier own present calls, 2 + 2 thin and 5 + 4 TSD-only, and 0 reclassified calls differ (logs). This matches
     REPORT 5a:393, 8.3 and dead_ends.md.
   - Shared FLANK_CAP: **addressed**, documented at REPORT.md:491-493.
   - wfa cause: **addressed**. status.json: 504/512 windows, 13 guarded, CPU/wall = 9,685/1,800 = 5.38 cores.
   - DESIGN 5.1: **not addressed**, deferred because Task 24H holds the repo. It is recorded at REPORT.md:494-496 with
     replacement text in task-24b-report.md. That text needs one correction (nit d) before the controller applies it.

### New problems
- **Minor N1. The backend step of 10_decision_trace.py asserts some results instead of computing them.**
  - The result line prints "both bars met", "backend lastz" and "wfa timed out" as fixed text (10_decision_trace.py:228-229).
  - It never tests the precision bar for `<route>_lastz`, e_lz <= 2.5 h or the memory bar, as the route step does
    (lines 112-120).
  - `lz = f"{route}_lastz"` assumes that a follow-up exists for the winner.
  - The output is right today, but a rerun on changed inputs would not catch a failure. Compute pass/FAIL as in step 2.
- **Nits.**
  - (b) The figure's Exceptions say flank 2 kb "disagrees with AnchorWave's alignment ... at 18 high-tier calls", and later
    "15 high-tier disagreements inspected". These counts are present-against-absent contradictions; high-tier state
    disagreements number 1,606 (2 kb) against 1,189 (mm2). Write "contradicts".
  - (c) REPORT.md:333-334 puts the breakdown "P 81, T 48, S 6" after "130 without the yardstick", but it sums to 135.
    Without the yardstick it is 77/47/6.
  - (d) The proposed DESIGN 5.1 text says "matches the longer caps on accuracy at about half the cost". That holds against
    10 and 20 kb (x0.55, x0.45), not 5 kb (2 kb costs 0.89x of 5 kb). Write "at about half the cost of the 10- and 20-kb
    caps".
