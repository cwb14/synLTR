# Task 12: controller rulings
These bind as much as `task-12-brief.md`, and override it where the two conflict.

## Context the brief cannot know
- **Branch state.** `plan2-analyses` holds Tasks 1-11. The analysis commands are `ltrpav-stats`, `ltrpav-paint` and
  `ltrpav-plot`, all registered in the env `ltrpav`, which imports the repo's working tree. Tasks 10 and 11 ran them
  end to end on read-only views of main3. They match the Task 3-8 probes: D_pav +0.2905 +- 0.0392, Z 7.42; sister
  pair B73 + TIL01; donor TIL18.
- **What Task 9 established about the identity layer.**
  - On all TIL01-TIL18 pairs: isolation split s = 0.000742 +- 0.000094.
  - The mixture fit is fragile. Its s_mix moved from 0.00248 to 0.00082 with small changes in pair counts, and the
    gene-flow weight was 0 both times.
  - Cost: about 105 pairs/s at 16 threads, for about 50,800 pairs.
- **Known defect in the inversion caller (Task 5), queued for Plan 2's final wave.**
  - On TIL01's side, 49 sparse blocks of 5-19 loci span up to 278 Mb, many between non-syntenic sequences. They flag
    31,473 decoy loci.
  - No statistic reads the flags.
  - See ruling 7 for item 10.
- **The figure.** Task 11 is complete at 2c2e639, after three fix rounds.
  - The overview's legend verdicts are conditioned on their statistics.
  - Panel B's tract is typical on loci, length and mean posterior.
  - `ltrpav-plot` refuses a stats.tsv that is not current.
  - run_analyses.sh runs stats, then paint, then plot, so the figure is drawn from fresh parts.
  - The controller's own figure check on the main3 render passed all seven lines. Your check (ruling 10) is
    independent.

## Rulings
1. **Run in a view of main3, not in main3 itself.**
   - Create `/data2/chris/maize_introgression/benchmark_pav/main3_analyses/` as a view of main3, built as Tasks 10
     and 11 built theirs:
     - a real `work/` directory;
     - symlinks `loci.tsv -> ../main3/loci.tsv`, `manifest.json -> ../main3/manifest.json`, `pairs -> ../main3/pairs`
       and `work/elements -> ../../main3/work/elements` (absolute targets are fine);
     - `qc.tsv -> /data2/chris/maize_introgression/benchmark_pav/main3/qc_fixed/qc.tsv`. These are the DESIGN 10.1
       values QC.md judges. The rows the analyses read (annot_sensitivity, skipped_*) are identical in both qc.tsv
       files;
     - a copy of `main3/samples.tsv`.
   - Every file the brief puts in `main3/` goes in `main3_analyses/` instead: run_analyses.sh, analyses.log,
     analyses.done, compare_papers.py, prelim_papers.tsv and PRELIM.md.
   - Snapshot the sizes and mtimes of main3's entries (depth 3) and of `inputs/*.fai` before the launch. Compare
     after the last command and report equality.
   - Why: main3 is Plan 1's frozen run, and QC.md, qc_fixed and the memo describe it as it is.
   - Cost if wrong: the results sit one directory over.
2. **Launch** as brief Step 2, from `main3_analyses/`.
   - First run `pgrep -af "ltrpav|lastz"`, which should show no job, and check `uptime` and `free -g`.
   - Add `trap 'echo $? > analyses.exit' EXIT` to run_analyses.sh so that a failure leaves a status.
   - Verify the PID as the brief says.
   - While it runs, write compare_papers.py; run it after `analyses.done` appears. Wait with a Monitor until-loop,
     never a foreground sleep.
3. **Length weighting (items 4, 5, 6, 9).**
   - "Length-weighted" means weighted by each insertion's span (end - start + 1). That is the weight LTRmix's
     `eval_real.py` uses (`np.average(..., weights=g.len)`).
   - Apply it identically to both tools' per-locus rows: LTRpav's `posterior.B73.tsv` (start, end) and LTRmix's
     `elements.B73v5.tsv.gz`.
   - Each mean function takes an optional weight column for both tools.
4. **LTRmix's files are read-only.**
   - The results are in `/data2/chris/maize_introgression/LTRmix/benchmark/results/main3/`: elements.B73v5.tsv.gz,
     tracts.B73v5.bed, ancestry.B73v5.bed, stats.tsv and benchmark_real.tsv. The model script is
     `/data2/chris/maize_introgression/LTRmix/benchmark/scripts/eval_real.py`: read it, never run anything that writes
     into LTRmix.
   - After computing LTRmix's rows with the shared functions, check each one that benchmark_real.tsv also holds.
     Report each as equal, equal within rounding, or different with the reason.
5. **Item 13.**
   - `s_mix` gets verdict `reported`, with the note "unstable (Task 9: moved 0.00248 -> 0.00082 with small count
     changes; gene-flow weight 0)".
   - Never present s_mix as a gene-flow estimate.
6. **Truth and inputs are read-only:** `benchmark/truth/`, `inputs/`, `run/` and main3.
7. **Item 10, inversions.**
   - Report every block whose interval lies within 10 Mb of a published breakpoint. Give its loci, `n_discordant`,
     span on both genomes, and the distance from its breakpoint interval to each published end.
   - Flag a block as "sparse (known caller defect, queued for the final wave)" when its loci per Mb on either genome
     is below that genome's median for blocks. That is a description, not a rule the comparison uses.
   - The controller re-runs the analyses after the final wave and refreshes this item.
8. **Compute.**
   - The run uses 32 threads.
   - Every other probe uses at most 16 threads and runs under `timeout 15m` in the foreground; anything longer runs
     detached with its PID verified.
   - Export `NUMPY_MADVISE_HUGEPAGE=0` everywhere.
9. **Repo.**
   - Commit only DESIGN.md section 12 (3-5 lines), with subject "Record Plan 2 analyses outcome", on
     `plan2-analyses`.
   - No code change in Task 12. A defect you find goes in the report with evidence, and the controller rules on it.
   - Use the existing identity; set nothing; add no trailers or AI attribution. The user is the sole author. Never
     push.
10. **Figure check (PRELIM.md item 5).**
    - You did not make the figure, so answer the seven lines yourself from `main3_analyses/overview.png` and the
      legend pages (`pdftoppm -f 2 -l 3`).
    - Inspect full-resolution crops.
    - The seven lines are at the end of `/home/chris/.claude/skills/making-figures/SKILL.md` ("The figure check").
11. **Science.**
    - CLAUDE.md's "Biological Analyses" applies.
    - The headline sentence is labeled "hypothesis: one trio, no simulated null". Never present a null or a
      description as a finding.
    - Each MISS gets a dead_ends.md entry with an investigation note.
    - Where PRELIM.md says something is new against the literature, cite the paper. The two papers are the PDFs in
      `/data2/chris/maize_introgression/`.
12. **Memo.**
    - Append the Plan 2 section to `/data2/chris/maize_introgression/memo_ltrpav.md` in its existing format.
    - Include `claude --resume a7cbe20d-95be-480c-b88f-18a5132aaf2e`.
    - Include the view's construction commands, so the run can be rebuilt from the memo alone.

## Report
- Write the full report to `task-12-report.md`, in this directory.
- Return ONLY:
  - status;
  - commits;
  - the test line;
  - the verdict counts (PASS, MISS, reported);
  - the direct answer, in 3-5 lines;
  - one line per MISS;
  - the main3-unchanged check;
  - concerns.
