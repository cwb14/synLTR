# Plan 2 review: statistics, discovery rules, coverage, tests, decisions, Task 12

- **Plan:** `docs/plans/2026-11-11-plan2-analyses.md` (1489 lines). Line numbers below are the plan's unless marked.
- **Read against:**
  - `docs/DESIGN.md` (sections 1-3, 5.4, 6, 7, 10) and `docs/lit_review.md`;
  - the draft summary and brief;
  - LTRmix `ltrmix.py`, `benchmark/scripts/rate_free_split.py`, `eval_real.py` and `benchmark/results/main3/`;
  - the engine: `loci.py`, `classify.py`, `outputs/tables.py`, `elements.py`, `localign.py`, `seqio.py`, `cli.py`, `checkpoint.py`.
- **Probes:** scripts and a memo in `/data2/chris/maize_introgression/benchmark_pav/plan2_review/`.
  - msprime and scipy came from the `ltrmix` env, used read-only; `ltrpav_bench` has no scipy.
  - Nothing else was written.

**Counts:** Critical 3, Important 11, Minor 15.

**Overall.**
- Most ports are faithful. These checked out line by line:
  - the HMM (forward-backward, EM, L grid, start values, pseudocounts, the pi clip, the stop rule);
  - the tract rule, the +1 target-decoy q and the decoy p;
  - the jackknife formula, PI_MAX and BF_TRACT;
  - the f4-ratio's numerator and denominator, and the second-donor rule (equivalent on distances);
  - the rate-free likelihood (closed form re-derived) and u95.
- Most test expectations are right (recomputed list at the end).
- Three rules would bias or void results:
  - the discovery-ruled statistics read merged `loci.tsv` states, which let the sisters' own annotation back in (C1);
  - DFOIL-alt is decoded with the full-DFOIL sign table (C2);
  - the fallback discovery genome can sit inside the sisters' clade (C3).
- The direction count n(X->Y) also has a non-zero null whenever the two taxa differ in Ne (I11).

---

## Critical

### C1. Discovery-ruled statistics read `loci.tsv`'s merged states, so the sisters' annotation enters D_pav, its strata, the outgroup rule, the f4-ratio and painting

**Lines:**
- 43-44 (builder call 1); 92-95; 196-213 (`Catalog.state`, `cls`);
- 577-586 (`counted`, `d_pav`); 606 (`high_tier`: "tier `high` or `annot`"); 617-621 (f4);
- 785-789 and 801-802 (painting classes, decoy); 1077-1079 (identity pairs); 1162 (paint stage inputs);
- DESIGN 7.1 (l. 297-300): "The sisters' annotation never enters".

**What is wrong.** `Catalog.state` is each genome's state in `loci.tsv`. In `loci.py`, `_member_state` and `_state` build it like this:
- **A member genome** (its annotation holds the copy) is `P`, tier `annot`, whatever the discovering genome's own call says. A contradicting call only adds the flag `annot_conflict`.
- **A non-member genome** gets the highest-tier call among all member elements' calls into it.

Take a D-discovered RD locus whose copy R's annotation also holds. Then:
- R is resolved `P` even where D's own call into R is U;
- R's own calls into S and into the outgroup are extra chances to resolve S = E and O = E;
- the SD mirror gets the same help only through S's annotation.

So the more completely annotated sister has more of its patterns counted, and its member tier "annot" passes `high_tier`. Painting has the same leak: S's and D's annotations enter the RS and RD classes, and R's and D's enter the decoy's.

**Why it matters (probe `probe_depth_leak.py`).**
- Setup: a true null (n_RD = n_SD), 40,000 loci in 400 blocks, each call resolving with probability 0.8 (0.5 for a distant outgroup).
- At the completeness LTRmix measured for B73 against TIL01 (ratio 1.081 ± 0.018, main3 `stats.tsv` `completeness_ratio`):
  - merged-state D_pav = +0.017 to +0.021, Z = +3.2 to +3.3: a false positive at the plan's own bar;
  - counting with D's own calls gives D ≈ 0 (|Z| < 0.5).
- At the completeness ratios of the Zn trios (1.28-1.64, LTRmix REPORT l. 255): D = +0.09 to +0.11, Z ≈ +16.
- Real loci cluster in blocks, so real Z values are smaller, but the D offset is the same.
- The bias points to the better-annotated sister. In Task 12 that is B73, the expected recipient, so the leak would inflate exactly the answer being checked.

**Replacement text.**

Global Constraints, new bullet after l. 95:
> A statistic with a discovery rule reads every other genome's state from the discovering genome's own calls
> (`cat.pcls(disc, label)`), never from `loci.tsv`'s merged state. In `loci.tsv` a member genome is P/annot whatever
> the discoverer's call says, and a member's own calls give the other genomes extra chances to be resolved, so merged
> states let annotation depth into the count (DESIGN 7.1). Merged states remain for any-discovery descriptions: run
> summary, distances, sharing counts used to pick the sister pair, Dollo placement and inversions.

Task 1 `Catalog`, add:
```python
    proj: dict[str, np.ndarray]    # annotated A -> (n, G) uint8 STATE_CODE of A's member element's own call into each
                                   # genome (pairs/<A>__<B>.calls.tsv.gz joined on cat.eid[:, g(A)]); A's own column P;
                                   # 0 where A has no member at the locus (extra members ignored) or the pair has no call
    ptier: dict[str, np.ndarray]   # same shape: TIER_CODE of those calls
    def pcls(self, disc: str, label: str) -> np.ndarray   # (n,) int8 from proj[disc]: 1 P/S/T, 0 E, -1 D/O/G/U or none
```
`load_catalog`: "Stream each pair file once (an annotated A against every other genome). Fail fast on a header other than `CALL_COLUMNS`."

Task 4 `counted` (replace l. 580-582):
> Per row, g* = D if D is a member there; under fallback, the first eligible fallback genome (C3) that is a member,
> in sheet order. `cand` = g* exists, `pcls(g*, D) == 1`, and `pcls(g*, o) == 0` for every outgroup o
> (`outgroup="E"`; `"none"` drops this). `rows` = `cand` with `pcls(g*, R) >= 0` and `pcls(g*, S) >= 0`.

Further replacements:
- **`d_pav`:** "a = `pcls(g*, R) == 1` & `pcls(g*, S) == 0`; b = the mirror."
- **`high_tier`** (l. 606): "`ptier[g*]` of R and of S is `high`."
- **Resolution row:** read from `pcls(g*, ·)`.
- **f4** (l. 618): "on `counted` rows with `pcls(D, D2) >= 0`; num and den from D's calls."
- **Task 6 `classes`** (l. 787): "Y's, D's and the outgroups' states are X's own calls (`pcls(X, ·)`). The decoy classes S's members by `pcls(S, ·)`. The `"any"` variant keeps `loci.tsv` states and says so, because it is the variant Plan 3 tests under one-sided dropout."
- **Task 9 Pairs** (l. 1078): "Y's state (`P`) and site come from D's own call in `pairs/<D>__<Y>`: `b_seqid`, `b_start`, `b_end`, `b_strand`."
- **Task 10 stage inputs, paint** (l. 1162): "… the element TSVs and every pair file."
- **Builder call 1:** append "The catalog also reads each discoverer's own calls from the pair files; no format changes."
- **Toy (Task 1 Step 3):**
  - `ToyLocus` gains `calls: dict[tuple[str, str], str] = {}`, which overrides the state of A's call into B in `pairs/<A>__<B>`.
  - A member B is written `P` with tier `high`. "annot" is a `loci.tsv` tier, not a call tier.
- **New test (Task 4):**
```python
def test_counted_reads_discoverer_calls(tmp_path, toy_fastas):
    # all D members, O E. RD x4, every call resolved -> counted. RD x3 with R a member but D's call into R U
    # -> not counted (loci.tsv says R P/annot). RD x2 where D's call into S is U and R (a member) calls S E
    # -> not counted (loci.tsv says S E). SD x4 resolved -> counted. (n_RD, n_SD) == (4, 4);
    # high_tier counts D's call tiers only (a member's "annot" never passes)
```

### C2. DFOIL-alt is decoded with the full-DFOIL sign table, which does not hold once single-derived patterns are dropped

**Lines:** 62-66 (builder call 9); 899-907; 924-926; 940-942. Draft decision 40.

**What is wrong.**
- `DFOIL_ALT` is exactly Pease & Hahn's DFOIL sets minus the four single-derived patterns. I checked it against dfoil.py's count indices: DFO = (1010, 1110, 0101, 0001) vs (1001, 1101, 0110, 0010), and so on.
- `DFOIL_SIGNS` is the full-DFOIL table. Its 0 entries hold only because single-derived counts cancel.
  - Example, P1⇒P3: BABAA (1010, in DOL's right set) rises by P1's terminal branch above the event.
  - BAAAA (1000, also in DOL's right set) falls by the same amount, so full DOL = 0.
  - Without BAAAA, DOL-alt = minus that amount, as large as DFI-alt.
- dfoil.py makes the same mistake. `--mode dfoilalt` only sets the single-B weight (`beta1`) to 0, is then remapped to `'dfoil'`, and reuses `SIGNCODES['dfoil']`.

**Derivation.** Infinite sites, migration at t < T12 < T34 < Troot, with:
- a = T12 − t, b = Troot − T12;
- c = T34 − t, d = Troot − T34.

| scenario | full DFOIL | DFOIL-alt |
|---|---|---|
| P1⇒P3 | + + + 0 | + sgn(b−a) + − |
| P1⇒P4 | − − 0 + | − sgn(a−b) − + |
| P2⇒P3 | + + − 0 | sgn(b−a) + − + |
| P2⇒P4 | − − 0 − | sgn(a−b) − + − |
| P3⇒P1 | + 0 + + | + − + sgn(d−c) |
| P4⇒P1 | − 0 + + | − + sgn(d−c) + |
| P3⇒P2 | 0 + − − | − + − sgn(c−d) |
| P4⇒P2 | 0 − − − | + − sgn(c−d) − |
| P1+P2⇔P3 / ⇔P4 | + + 0 0 / − − 0 0 | same |

**Coalescent check (msprime with ILS, f = 0.15, 3000 × 100-kb blocks).**
- `probe_dfoil.py`, deep root:
  - full DFOIL recovers all 8 directional scenarios;
  - the plan's DFOIL-alt plus the standard table returns "none" for all 8;
  - the alt codes match the table above exactly (|Z| 5-105).
- `probe_dfoil_shallow.py` (T12 4000, T34 5000, Troot 6000, t 500): the alt codes collapse into two classes, as the table predicts:
  - +−+− for P1⇒P3, P3⇒P1, P2⇒P4 and P4⇒P2;
  - −+−+ for the other four.
- `probe_dfoil_unequal_ne.py` (Ne 400 vs 4000 between taxa): the alt null stays at |Z| ≤ 1.3 and the codes are unchanged.

**Replacement (Task 7).** Keep DFOIL-alt, because private insertions follow annotation depth and lineage TE bursts, and use its own table:
```python
DFOIL_ALT_SIGNS = {   # DFOIL-alt codes over DFO DIL DFI DOL: infinite-sites expectations without the single-derived
                      # patterns (checked by coalescent simulation). Each directional entry has one branch-length slot:
                      # deep root (Troot - T12 > T12 - t, Troot - T34 > T34 - t) gives the first code, a non-significant
                      # slot the second, the opposite sign one of the two ambiguous classes at the end.
    "+++-": "P1=>P3", "+0+-": "P1=>P3", "---+": "P1=>P4", "-0-+": "P1=>P4",
    "++-+": "P2=>P3", "0+-+": "P2=>P3", "--+-": "P2=>P4", "0-+-": "P2=>P4",
    "+-++": "P3=>P1", "+-+0": "P3=>P1", "-+++": "P4=>P1", "-+0+": "P4=>P1",
    "-+--": "P3=>P2", "-+-0": "P3=>P2", "+---": "P4=>P2", "+-0-": "P4=>P2",
    "++00": "P1+P2<=>P3", "--00": "P1+P2<=>P4",
    "+-+-": "P1<=>P3 or P2<=>P4 (direction unresolved)", "-+-+": "P1<=>P4 or P2<=>P3 (direction unresolved)",
}
```
- `signature()` returns the label of the code, else "none".
- Builder call 9 / decision 40: replace "with |Z| >= 3 for the sign code" by "with |Z| >= 3 and DFOIL-alt's own sign table (the full-DFOIL table does not apply once single-derived patterns are dropped; dfoil.py's dfoilalt mode reuses it)".

Tests (replace l. 940-942, add one):
```python
def test_dfoil_signature():
    assert signature({"DFO": 4, "DIL": 5, "DFI": 3.5, "DOL": -4}) == "P1=>P3"
    assert signature({"DFO": 4, "DIL": 5, "DFI": 3.5, "DOL": 0.2}) == "none"    # full-DFOIL P1=>P3 is no alt code
    assert signature({"DFO": 4, "DIL": -5, "DFI": 3.5, "DOL": -4}).startswith("P1<=>P3 or P2<=>P4")

def test_dfoil_alt_signatures_from_branch_lengths():
    # expected pattern counts on ((P1,P2),(P3,P4)),O with T12 = 2, T34 = 4, Troot = 8, t = 1, f = 0.1: each branch adds
    # its length to the pattern of the leaves below it, and the recipient's share f follows the donor's branch above t
    # (table in the review) -> for each of the ten scenarios, signature({k: 1000 * value}) is that scenario
```
`test_dfoil_alt_values` (l. 937-938) stays valid.

### C3. The fallback discovery genome (D unannotated) can sit inside the sisters' clade, which biases the null D_pav

**Lines:** 578-579; 647-649 (test). Draft decision 20. DESIGN 7.1 (l. 299-300): "any annotated genome other than R and S".

**What is wrong.**
- With D unannotated, loci discovered by any annotated genome X outside the trio are used.
- If X is closer to R than to S (a second maize when R is maize), then given X and D present, R carries the insertion more often than S under pure lineage sorting.

**Probe** (`probe_fallback.py`, msprime, no gene flow):

| X's position | n_RD | n_SD | D | Z |
|---|---|---|---|---|
| sister of R | 461 | 224 | +0.346 | +6.7 |
| sister of D | — | — | −0.015 | −0.4 |

**Replacement** (l. 578-579):
> `disc = (D,)` if D is annotated. Otherwise the annotated ingroup genomes X outside the trio that split with D from
> the sisters, by the four-point condition on PAV distances: d(R,S) + d(X,D) < min(d(R,X) + d(S,D), d(R,D) + d(S,X)).
> Terminal-branch effects of annotation depth cancel in each sum. None eligible → `None`: skipped, with a WARNING
> naming the genomes excluded and why.

Further changes:
- `counted` and `trios` gain `dist`.
- Test:
  > ingroup R, S, D (unannotated), X (annotated); dist with X grouping with D → `disc == ("X",)`; dist with X
  > grouping with R → `counted(...) is None` and the WARNING names X.
- This narrows DESIGN 7.1's wording, so record it as a build decision for the user to confirm.

---

## Important

### I1. `p_kksc` (the KKSC symmetry test) counts loci of any discovery, so annotation depth tilts it

**Lines:** 492-502, 519-523. Decisions 13, 15.

**What is wrong.**
- n_x+z can be discovered only by x or z, and n_y+z only by y or z.
- A more deeply annotated x inflates n_x+z, and the merged states add the C1 leak on top.
- The result is reported as the lineage-sorting symmetry test.

**Replacement** (l. 499):
> `p_kksc` = two-sided `binomtest(n_x+z, n_x+z + n_y+z)`, (x, y) the sister pair and z the third genome, counted on loci
> z discovers with z's own calls (`pcls(z, ·)`): x and y resolved, no outgroup present; `loci` =
> `disc=z;present=z;res=x,y;outgroup=not_present`. z unannotated: the C3 fallback, else `none`. It ignores block
> dependence (nested clusters, linkage), so its p is anti-conservative; the jackknifed D_pav is the test of record.

- The any-discovery counts stay, only to pick the sister pair; decision 13's warning stands.
- The test's R+D and S+D hand loci become D members.

### I2. The nested collapse keeps the outermost counted element whatever its pattern, so it drops independent informative children

**Lines:** 607-609, 653. Decision 24.

**What is wrong.**
- A host present in R, S and D is a counted (resolved) row but not informative.
- Keeping it as its cluster's marker discards RD or SD children inserted into it. Those children are independent insertions, so their fates are not the host's.
- The check is meant to merge elements that share a fate, such as an RD host whose children are E `host_empty` in S.

**Replacement** (l. 607-609):
> `nested_collapsed`: the informative counted rows (a | b), sorted by the discovery genome's (seq, start, −end); keep
> the first row per `cluster_keys` key.

Test, add: "a host present in R, S and D with 3 RD children → collapsed n_RD 1 (0 under the old rule)". The existing case stays.

### I3. Mechanisms label "O at the site" ancestral and D derived, against DESIGN 5.4

**Lines:** 980-990, 1009-1012, 1421-1422. Decision 41. DESIGN 5.4 (l. 228-229): "`D` and `O` say nothing about whether it did".

**What is wrong.**
- **O at the site** (|dl|, |dr| ≤ w with ≥ 80 bp of B-only sequence; also `small_ins`) fits an independent insertion at the same site (absence ancestral) or a replacement (absence derived).
- **D** (breakpoints not at the element's ends) fits several histories:
  - a deletion in B of the element (derived);
  - a deletion in B of an empty site (ancestral);
  - an A-only insertion of a larger unit holding the element (ancestral), for example an LTR-RT nested in a helitron, a TIR or a fragmented LTR-RT that the annotation lacks. Rule 4f explains overhangs only with annotated elements.
- With 28% of intact elements nested (DESIGN 4) and most maize TE sequence outside intact LTR-RTs, the last case is likely common. "D is derived" therefore inflates DESIGN 7.8's answer.

**Replacement (Task 8).**
- **`d_kind(dl, dr, tsd)`:** "`D_inside` if dl < −w or dr < −w: a gap end lies more than w inside the element, so B keeps up to MIN_SEG bp of it and B carried it. Else `D_beyond`. w as in `o_kind`."
- **Table `states`:** metrics `n_P n_S n_T n_E n_D_inside n_D_beyond n_O_site n_O_complex n_G n_U`.
- **Table `absence`:**
  - `n_absent` (E + D + O);
  - `frac_E`: ancestral, shown (an empty site; no precise excision);
  - `frac_D_inside`: derived, shown;
  - `frac_D_beyond`, `frac_O_site`, `frac_O_complex`: not determined (a deletion in B, an A-only insertion of an unannotated unit, an independent insertion at the site, or a replacement).
- **Findings:** "absences not shown ancestral = 1 − frac_E (upper bound on derived absences); shown derived = frac_D_inside (lower bound); both by age."
- **Task 12 item 12:** the five fractions by age, with those bounds.
- **Test:** `d_kind(-12, 0, "ACGTA") == "D_inside"`; `d_kind(300, 0, "ACGTA") == "D_beyond"`.

### I4. The Dollo test contradicts the Dollo rule

**Lines:** 998-1003, 1028-1030. Decision 44.

**What is wrong.**
- By the rule (present = cls == 1; missing never constrains), "R D with S P" has the clade {S}.
- R lies outside it, so the insertion goes on "S" and no deletion is placed on R. The test expects "deletion on R".
- An executor will bend the rule (count D as present) to pass the test, which turns D into proof that the element was there (see I3).
- "Missing" is also undefined for S, T and D events.

**Replacement.**
- Rule (l. 1002), add: "'Missing' is D/O/G/U for S and T events and O/G/U for D events. A D genome outside the clade is not placed: it is missing."
- Test:
  > tree ((R,S),D),O: R D, S P, genome D P, O E → insertion on "R+S+D", deletion on "R"; R D, S P, genome D E,
  > O E → insertion on "S", no deletion.

### I5. `test_sharing_and_sister` expects "not ambiguous" for counts the rule calls ambiguous

**Lines:** 519-523.

- With R+S 5 against R+D 2, `p_top` = `binomtest(5, 7)` = 0.453 ≥ P_WARN, so `ambiguous` is True.
- Replace the hand loci with:
  > R+S present, D E x12; R+D (D members), S E x2; S+D (D members), R E x1; R+S with O present x3; R+S with S U x1 →
  > counts {"R+S": 12, "R+D": 2, "S+D": 1}; p_top = binomtest(12, 14).pvalue = 0.0129, not ambiguous;
  > p_kksc = binomtest(2, 3).pvalue = 1.0.

### I6. Inverted runs break at a single out-of-order locus, and the p = 1/120 argument is misapplied

**Lines:** 61-62, 350, 699-712. Decision 38.

**What is wrong.**
- **Fragmentation.** A run ends at the first step that is not −dominant. One discordant locus inside an inversion (a nested inversion, a local rearrangement, a misplaced call) splits it, puts a false breakpoint interval inside it, and drops fragments under 5 loci. Inv4m (15 Mb, hundreds of loci) will come out in pieces, and Task 12 item 10 would measure the fragments.
- **The p-value.** 1/5! is the chance that one given 5-locus window is exactly reversed under a random local order. It is neither a genome-wide error rate (tens of thousands of windows) nor the null for collinear sequence.

**Replacement.**
- Add after l. 711:
  > merge consecutive inverted runs A and B (x order, same seqid pair) when B continues A's reversed order (dominant +1:
  > max y(B) < min y(A); −1: min y(B) > max y(A)) and fewer rows lie between them than min(|A|, |B|); those rows are
  > `n_discordant` (new `INV_COLUMNS` column); apply INV_MIN_LOCI to the merged block's rows.
- l. 350: `INV_MIN_LOCI = 5  # heuristic: shortest reversed run reported; named in findings.txt`.
- Drop the p-value sentence from builder call 8.
- Test, add: "one locus inside the S inversion moved 50 kb out of order → still one block, `n_discordant` 1".

### I7. The identity layer drops LTRmix's guard against a known downward bias of s and changes the site threshold, so Task 12 compares unlike numbers

**Lines:** 1083-1093, 1423-1426. Decisions 46, 48.

**What is wrong.**
- **The bias.** Post-split S–D gene flow pulls the isolation-model s down. LTRmix's own check found an isolation fit of 0.024% where the truth was 0.18% at 4% gene flow (REPORT l. 101-104). LTRmix ported a mixture fit (`fit_mix`) as the guard, and DESIGN 7.5 cites `rate_free_split.py` logic. The plan drops it.
- **The site threshold.** Pairs need ≥ 80 LTR sites here, ≥ 200 in LTRmix.
- **The Task 12 comparison.** "LTRmix's rate-free 0.05–0.07%" merges LTRmix's isolation fit (0.048%, bootstrap 0.034–0.063%) with its mixture fit (0.070%).

**Replacement (Task 9).**
- Port `fit_mix`: isolation, plus post-split gene flow with mean ≤ MG_MAX = 1e-3, plus an unshifted upper tail; the 18 starts of `rate_free_split.py`. Report it as row `s_mix` with its weights. MG_MAX goes to `constants.py` with LTRmix's reason.
- Add row `s_200`: the fit on pairs with ≥ 200 LTR sites.
- **Task 12 item 13:** `s_200` against 0.048% (isolation) and `s_mix` against 0.070% (mixture).

### I8. Task 12 compares LTRpav with LTRmix numbers produced under different procedures

**Lines:** 1384-1426. Decisions 33, 52.

**What is wrong.** LTRmix's numbers come from `eval_real.py`, which made different choices:
- element-length-weighted posteriors (windows, chromosomes, high-frequency means);
- 200 shifts for the high-frequency test;
- eight age bins;
- a `D_ins` that needs the sisters' own annotation (ABBA on R's elements, BABA on S's), so it is not blind to the 1.08 completeness ratio.

Item 3 compares LTRpav's K ≥ 0.01 bin with LTRmix's K > 0.05 bins (+0.08 to +0.13). LTRmix's own D over K > 0.01 is +0.153.

**Replacement (Step 4 constraints).**
- **Same code for both tools.** LTRmix's files go through the same window, AUROC, tract-recall, named-locus and high-frequency functions, with the same weights, 1000 shifts and seeds:
  - `elements.B73v5.tsv.gz` (class, `post_ancestry_TIL18`, span);
  - `tracts.B73v5.bed` (recent) and `ancestry.B73v5.bed` (ancestry).
- LTRmix's `benchmark_real.tsv` is a cross-check only.
- **Posterior means:** report LTRpav's both unweighted and length-weighted.
- **Item 2:** LTRmix `D_ins` beside LTRpav's primary and its `no_outgroup_filter` stratum (LTRmix uses no outgroup). Note LTRmix's dependence on the sisters' annotation.
- **Item 3:** LTRmix's `D_ins_by_age` counts re-binned to LTRpav's bins (from main3 `stats.tsv`):

  | bin | LTRmix D | counts |
  |---|---|---|
  | K = 0 | +0.506 | 122 vs 40 |
  | 0 < K ≤ 0.01 | +0.404 | 2,001 vs 850 |
  | K > 0.01 | +0.153 | 8,795 vs 6,467 |
  | gradient | dD +0.354 | — |

- Name LTRmix's HMM mode in every row: ancestry for posterior, windows and AUROC; both modes for tracts.

### I9. Direction declares no discovery rule (DESIGN 7.1), and DFOIL's pattern pairs are depth-sensitive

**Lines:** 913-927.

**What is wrong.** Pattern 1010 is discovered by P1 or P3; its mirror 1001 by P1 or P4. Unequal P3/P4 annotation depth therefore tilts DFO, the way C1 tilts D_pav.

**Replacement (rules block):**
> Each DFOIL-alt left/right pattern pair is counted on loci discovered by a genome present in both patterns, with that
> discoverer's own calls:
> - DFO: (1010|1001: P1), (1110|1101: P1, else P2), (0101|0110: P2);
> - DIL: (0110|0101: P2), (1110|1101: P1, else P2), (1001|1010: P1);
> - DFI: (1010|0110: P3), (1011|0111: P3, else P4), (0101|1001: P4);
> - DOL: (1001|0101: P4), (1011|0111: P3, else P4), (0110|1010: P3).
>
> n(X->Y), n(Y->X) and the 4-LIST counts declare `disc=any`, with a findings note that three present genomes nearly
> saturate discovery; Plan 3's one-sided dropout runs check it.

### I10. The toy interfaces cannot build three of the plan's tests, and one expected value is off

**Lines:** 298-303, 308-328, 651, 658-659.

**What is wrong.**
- `simulate_run` has one `p_missing` for every genome. `test_resolution_warning` (S 0.40 vs R 0.15) and `test_outgroup_mostly_missing` (O 0.8) need per-genome rates.
- The toy pair files mirror `loci.tsv` states, so C1 cannot be tested, and member columns would carry tier "annot".
- With the toy's 16% old loci (O present), `removed_frac` = 0.254 + 0.746 × 0.8 = 0.85, not "~0.8".

**Replacement.**
- `simulate_run(..., p_missing: float | dict[str, float] = 0.15, ...)`: a dict sets each listed genome's rate; the others stay at 0.15.
- `test_resolution_warning`: `p_missing={"S": 0.6}` → resolved fractions ≈ 0.94 (R) and 0.74 (S) among the candidates, so it warns. The plan's 0.40 gives a 0.106 gap, too close to RESOLVE_WARN.
- `test_outgroup_mostly_missing`: `p_missing={"O": 0.8}` → `removed_frac == approx(0.85, abs=0.03)`.
- `ToyLocus.calls` as in C1.

### I11. The direction count n(X->Y) has a non-zero null whenever the two taxa differ in Ne

**Lines:** 920-922, 927 (DESIGN 7.6's statistic).

**What is wrong.** With no gene flow, a smaller-Ne taxon fixes ancestral polymorphisms in its sample, so "present in all X and some Y" outnumbers the mirror. Probe `probe_ddir_null.py`, two genomes per taxon:

| Ne_X vs Ne_Y | D_dir, no gene flow |
|---|---|
| equal | −0.016 |
| 1000 vs 5000 | +0.932 |
| 300 vs 5000 | +1.000 |

- A small recipient also fixes transferred insertions, which reads as flow out of it. Age strata do not rescue this.
- Maize's bottleneck makes this the expected case for maize ↔ mexicana (DESIGN 10.4).
- DFOIL-alt's pairs compare genomes within one taxon, and its null held with a 10-fold Ne difference (C2 probe).

**Replacement.**
- Task 7 note and findings:
  > D_dir is not read as direction: unequal Ne alone drives it (no gene flow: +0.93 at Ne 1000 vs 5000), and drift in
  > a small recipient fixes transferred insertions. DFOIL-alt is the direction statistic.
- Task 12 Step 8 hand-off: "Plan 3's direction simulations include unequal Ne (the maize bottleneck) in the null and the gene-flow runs."

---

## Minor

- **M1. Tract length (l. 793-795, 830, 1411).** `mean_tract_bp` = L is the switch scale. The mean donor-like run under the model is L/(1 − pi), because the rate out of state 1 is (1 − pi)/L. Report both `L` and `mean_tract_bp = L/(1 − pi)`. Quote L beside LTRmix's 197 kb, which is its L.
- **M2. `youngest_k` (l. 816-818, 837-838; decision 37).** K = 0 is not age 0, and LTR-LTR gene conversion (40% of maize elements) makes K too young, so the bound can be too recent. Add `youngest_u95` = chi2.ppf(0.95, 2(d+1))/2/n with n = the locus `ltr_len` and d = round(K·n); use exact `self_counts` with `--identity`. State both caveats in findings.
- **M3. Outgroup-conflict wording (l. 67-68, 505-506).** Write "an upper bound on the combined rate of ingroup false E and outgroup false presence; deep lineage sorting and parallel insertions also give it".
- **M4. Jackknife (l. 406-408).**
  - Define "fewer than 3 blocks" as distinct blocks among the rows, counted before non-finite pseudovalues are dropped (LTRmix).
  - Note that this is the unweighted delete-one form, kept for comparability with LTRmix. Busing's weighted form is standard for unequal blocks and is a candidate for Plan 3's stability checks.
- **M5. Role tie-break (l. 593; decision 19).** LTRmix sends a nan D to pair[1], because `nan >= 0` is False. The plan's nan → pair[0] is fine, but it is not "LTRmix's rule".
- **M6. Resolved fractions (l. 95).** The constraint that every test reports resolved fractions has no counterpart for f4 (`resolved_D2`) or direction (every quartet genome). Add them.
- **M7. `shortest_callable` (l. 810-814; decision 32).**
  - The missing flanks equal no flanks, because the chain is stationary across missing loci.
  - Add an upper bound with 20 RS loci on each side.
  - The middle locus is index k // 2.
- **M8. Toy margin (l. 645).** My count-level replica of the toy gives Z ≈ 3.5 at seed 1. Over 200 seeds the median is 4.5 and P(Z ≤ 3) = 1.5%. Use `n_per_seq=3000` for the admixed assertion.
- **M9. Detached-job check (l. 1372-1373).** `pgrep -af run_analyses.sh` matches the `mamba run` leader and its bash child. Only the leader has SID = PID and PPID 1, so say which process to check.
- **M10. Chromosome ranking (l. 1398-1400).** Restrict item 5's ranking to seqids ending chr1..chr10, because `paint_seqid` also holds scaffolds.
- **M11. Figure story (l. 1264-1266).** Lineage sorting also clusters, at the linkage scale. Write "would give the same clustering in the sister's mirror and no age excess".
- **M12. Interface types.** Specify:
  - `inside(..., seqid, ...)`: names or fai indexes;
  - the two arrays `classes` returns;
  - `Counted.rows` and `cand` as boolean masks;
  - `block_ids` rows: mask or index.
- **M13. Preliminary labels (l. 1429, 1446-1450).** Write verdicts as "PASS (prelim)" and "MISS (prelim)", and label the closing headline "hypothesis: one trio, no simulated null".
- **M14. Environments (l. 229; Global Constraints l. 73).** `ltrpav_bench` also imports this tree and lacks scipy and matplotlib (checked). Install them there too, or state that analyses run only in `ltrpav`.
- **M15. Younger-than-split counts (l. 1089-1092).** Name their rows: the D_pav counted rows, all tiers, outgroup E. DESIGN 7.5's "counts of shared insertions younger than the split" exist only with `--identity`; say so in findings when it is off.

---

## The 52 drafting decisions

Disagree or amend:

| # | Decision | Verdict |
|---|---|---|
| 2 | catalog from `loci.tsv` alone | C1: also read each discoverer's calls |
| 6 | paint stage keys | C1: add the pair files |
| 13, 15 | sharing and KKSC on any discovery | I1 |
| 19 | role tie-break | M5: attribution only |
| 20 | fallback discovery genomes | C3 |
| 24 | nested collapse | I2 |
| 32 | shortest callable tract | M7 |
| 33 | unweighted posterior means | keep; I8 for the comparison |
| 37 | youngest K | M2 |
| 38 | inverted blocks | I6 |
| 39 | sister taxon | I9, I11 |
| 40 | DFOIL-alt sign table | C2 |
| 41 | ancestral vs derived absences | I3 |
| 44 | Dollo placement | rule fine; test I4 |
| 46, 48 | identity layer | I7 |
| 51 | toy runs | I10 |
| 52 | Task 12 conventions | I8 |

Agree with the rest: 1, 3-5, 7-12, 14, 16-18 (18 with the M3 wording), 21-23, 25-31, 34-36, 42, 43, 45, 47, 49, 50.
- Each is principled, display-only or a named heuristic.
- None tunes a threshold to ELAI, the papers or LTRmix.
- Decision 31 (informative-locus scale) is the better target-decoy scale.

The summary's conflict 7 lists four deliberate changes from LTRmix. It omits:
- unweighted posteriors;
- the 80-site minimum (LTRmix: 200);
- the nan role tie-break;
- the fit check (P(k=0) only; LTRmix checked the CDF at five thresholds).

## Spec coverage

- Every DESIGN 7.1-7.8 item and every section-6 analysis output has a task; the plan's table at l. 1472-1489 checks out.
- Additions beyond DESIGN are small and justified: decoy files, `identity.tsv`, the missingness table, `n_identical`.
- Gaps: M6 (resolved fractions for f4 and direction) and M15 (younger-than-split counts need `--identity`).

**DESIGN 7.1:**
- **Discovery rules:** D_pav, f4 and painting leak through merged states (C1); the fallback rule (C3); KKSC (I1); direction (I9). The any-discovery descriptions (distances, sharing, Dollo) declare `disc=any`, which is acceptable.
- **Missingness:** never treated as absence and never imputed in any rule. The mechanisms table's "absent" (E + D + O) is a descriptive count, but its reading as ancestral or derived is I3.

## Tests: expected values recomputed

Correct:
- jackknife leave-one-out;
- `block_size`, four cases;
- `counted`: cand 7, (4, 2), D = 1/3;
- `outgroup_conflict` 1/8;
- f4: num 2, den 4, f 0.5;
- tract rule (0,1), (3,4);
- target-decoy: q 1/25 and 2/30, p 0.5 and 1.0, lone target q = 1;
- DFOIL-alt arithmetic ±0.6;
- `o_kind`;
- `u95` = 0.0029957;
- `fit_split` (3 seeds: s within 1.2%, m within 0.5%);
- `age_bin`;
- the NJ additive example;
- `load_roundtrip`.

Wrong:
- `test_sharing_and_sister` (I5);
- `test_dollo_branches` (I4);
- `test_dfoil_signature` encodes the wrong table (C2);
- `test_outgroup_mostly_missing` should expect 0.85 (I10).

## Task 12: fairness and framing

**Correct as written:**
- the taxa: TIL18 = mexicana (donor), TIL01 = parviglumis (sister), B73 the recipient, Zd the genotype-only outgroup;
- "preliminary" framing throughout; the bars and the null are deferred to Plan 3;
- direction is skipped, correctly (one genome per taxon);
- the quoted LTRmix values (D_ins +0.1949, Z 7.2; +0.51 at K = 0; ELAI 0.1695; 25 kb median spacing; 7.6% vs 3.5%) match LTRmix's files.

**To fix:**
- **Fairness:** I8 (same code for both tools, matching bins and weights).
- **Bias toward the expected answer:** C1 would favor B73 as recipient.
- **Labels:** M13 (verdicts and the closing headline).

## Probes

All in `/data2/chris/maize_introgression/benchmark_pav/plan2_review/`; the commands are in `memo.md` there.

| Probe | Checks |
|---|---|
| `probe_tests.py` | test expectations and the split fit |
| `probe_dfoil.py`, `probe_dfoil_shallow.py`, `probe_dfoil_unequal_ne.py` | C2, I11 |
| `probe_depth_leak.py` | C1 |
| `probe_fallback.py` | C3 |
| `probe_toy_dpav.py` | M8 |
| `probe_ddir_null.py` | I11 |

---

## Re-review (scoped), 2026-11-11

**Scope.**
- The revised plan (1,773 lines) against the 29 findings above, the drafter's three deviations and three additions (`plan2-draft-summary.md`, decisions 53-60), and new inconsistencies from the edits.
- Especially the Interfaces blocks against the C1 `Catalog` change.
- Every changed test expectation recomputed. Untouched parts not re-reviewed.

**Probes** (same directory, commands at the end):
- `rr_toy.py`: count-level replica of the revised per-call toy model;
- `rr_callable_inv.py`: `shortest_callable` bounds and the literal merge rule;
- `rr_inv_fix.py`: the corrected merge rule;
- `rr_fitmix.py`: the new `fit_mix` test, LTRmix code verbatim.

**Verdict counts:** 28 ADDRESSED, 1 PARTIAL (I6), 0 NOT ADDRESSED.
**New problems:** 1 Important (N1, the merge rule behind I6), 4 Minor (N2-N5). No new Critical.

### Findings

| Finding | Verdict | Where (plan lines) |
|---|---|---|
| C1 merged states | ADDRESSED | Architecture 11-18; builder calls 54-56, 64-72; Global Constraints 119-124; `Catalog` 248-262; toy 331-338, 361-367, 389-397; `load_catalog` 428-429; Task 4 656, 686-703, 715-716, 722-723, 733-738; Task 6 935-942, 956-958; Task 9 1303-1305; paint inputs 1400; tests 304-309, 753-766, 1020-1022 |
| C2 DFOIL-alt table | ADDRESSED | 76-80, 1063-1089, 1130-1139 |
| C3 fallback four-point | ADDRESSED | 85-88, 435-438, 548-549, 593-594, 688-695, 780-782, 1752 |
| I1 `p_kksc` | ADDRESSED | 589-598, 615-625 |
| I2 nested collapse | ADDRESSED | 724-725, 788-790 |
| I3 ancestral/derived | ADDRESSED | 1171-1172, 1183-1194, 1218-1220, 1227-1235, 1530, 1694-1700 |
| I4 Dollo test | ADDRESSED | 1210-1212, 1241-1244 |
| I5 sister test | ADDRESSED | 615-621 |
| I6 inversions | **PARTIAL** | 74-75, 421 and 861 (heuristic named), 822-831 and 1691 (`n_discordant`) are in. The merge rule at 848-850 does not merge across a displaced locus, so its new test at 873-874 fails (N1) |
| I7 identity guard | ADDRESSED (deviation accepted) | 39, 1261, 1277-1279, 1289-1294, 1309-1319, 1349-1352, 1701-1705 |
| I8 fair comparison | ADDRESSED | 1636-1665, 1681-1683 |
| I9 direction discovery | ADDRESSED | 1081-1086, 1099-1111, 1141-1143 |
| I10 toy interfaces | ADDRESSED (deviation accepted) | 372-397, 784-786, 795-797 |
| I11 D_dir null | ADDRESSED | 81, 1115-1117, 1746-1749 |
| M1 | ADDRESSED | 952-953, 988, 1683 |
| M2 | ADDRESSED | 905, 974-975, 996-998, 1034 (see N5) |
| M3 | ADDRESSED | 83-84, 601-602 |
| M4 | ADDRESSED | 486-491 |
| M5 | ADDRESSED | 710 |
| M6 | ADDRESSED | 737-738, 1105, 1113 |
| M7 | ADDRESSED | 925-926, 966-970, 1041-1043 |
| M8 | ADDRESSED | 777 |
| M9 | ADDRESSED | 1619-1621 |
| M10 | ADDRESSED | 1668-1669 |
| M11 | ADDRESSED | 1509-1512 |
| M12 | ADDRESSED | 196-200, 465, 668-674, 834-835, 918-919 |
| M13 | ADDRESSED | 1605, 1708, 1725 |
| M14 | ADDRESSED (deviation accepted) | 101-103, 282, 1424, 1447-1448 (see N3) |
| M15 | ADDRESSED | 1320-1322, 1410-1412 |

**Changed test expectations, recomputed.**

| Test | Recomputed | Verdict |
|---|---|---|
| `test_load_roundtrip` new asserts (305-309) | — | right under the toy's call rules |
| `test_sharing_and_sister` | 12/2/1, p_top 0.0129, p_kksc 1.0 | right |
| `test_kksc_reads_the_third_genomes_calls` | n_R+D 2 | right |
| `test_counted_reads_discoverer_calls` | (4, 4) | right |
| `test_counted_rule_and_d` | cand 7, (4, 2), D = 1/3 | right |
| `test_resolution_warning` | 0.838 / 0.408 | right (expected 0.85 / 0.40) |
| `test_outgroup_mostly_missing` | 0.856 | right (expected 0.85 ± 0.03) |
| `test_null_and_admixed` | null \|Z\| < 3 in 200/200 seeds; admixed at n_per_seq 3000: median Z 5.0, P(Z ≤ 3) = 0.005 | right |
| `test_shortest_callable` | k_lo = 2, k_hi = 4 | right (bar ≤ 20) |
| `test_dfoil_alt_signatures_from_branch_lengths` | a = 1 < b = 6 and c = 3 < d = 4 give the deep-root codes; ancestral at t = 3 gives ++00 / --00, the nan DFI and DOL read as 0 | right |
| `test_null_with_unequal_annotation` | projection \|Z\| ≤ 0.15 at seeds 1-3; merged-state D off | see N2 |
| `test_fit_mix_guards_against_gene_flow` | passes | slow, see N4 |

**C1 Interfaces check.** No new inconsistency.
- `cluster_keys(cat, gstar, rows)` matches the nested-collapse rule.
- `block_ids(seq, mid, size)` is used consistently by Tasks 4, 7 and 9: proj_site, or merged coordinates for the any-discovery D_dir.
- `counted`, `trios`, `f4_ratio`, `second_donors`, `sister_pair` and `identity` all gain or take `dist`. `run_paint` recomputes `relations` for it.
- `Catalog.ltr_len` was added for `youngest_u95`.
- The Consumes lists name the new accessors.
- `TIER_CODE["annot"]` stays only for merged states; call tiers never carry it.

### Deviations and additions

| Item | Verdict | Why |
|---|---|---|
| Deviation 1: no separate `s_200` row | Accept | The fit itself now uses 200 sites (controller ruling); `s_200` would duplicate `s`. |
| Deviation 2: resolution expectations 0.85 / 0.40 | Accept | Correct under C1's per-call toy; my 0.94/0.74 were for the old merged-state toy. Replica: 0.838 / 0.408. |
| Deviation 3: M14 by lazy imports | Accept | It was the review's second option, and `env_bench.yml` lives in `bakeoff/`. See N3 for the run-time behavior it leaves open. |
| Addition 1: ancestral scenarios at t = 3 | Accept | My t = 1 for all ten was wrong for the ancestral pair: P12 exists only between T12 and Troot. At t = 3 the codes are ++00 / --00. |
| Addition 2: `fit_mix` asserts 0.01 < w_flow < 0.1 | Accept | At the test's 50,000 pairs: w_flow = 0.042 (true 0.04), s_mix 0.00210 against isolation 0.00115. The softmax rationale is right. Runtime: N4. |
| Addition 3: LTRmix's five CDF points | Accept | Matches `rate_free_split.py`: x = 0, 0.001, 0.002, 0.003, 0.005; `pred_cdf` with nsim 200, seed 0. |

### New problems

**N1 (Important). The I6 merge rule cannot merge across a displaced locus, so `test_one_discordant_locus_keeps_one_block` fails as specified.** Lines 847-850, test 873-874. The fault is in my own replacement text, which was applied verbatim.

- Runs partition the rows, so a displaced row always joins a neighboring run as its first or last row.
- B's maximum (or A's minimum) is then the displaced row, and "max y(B) < min y(A)" never holds.
- Literal implementation (`rr_callable_inv.py`), Task 5's inversion with one locus moved ±50 kb: 2 blocks (300 + 301 rows), not 1.

Replacement for l. 848-850:
```
    candidates = runs of >= 2 rows (a single row is collinear or isolated)
    merge consecutive candidates A and B (x order, left to right; a merged block is the next A): find the fewest rows
      u trimmed from A's end and v from B's start such that A's last remaining row and B's first remaining row are in
      reversed order (dominant +1: y(B) < y(A); -1: y(B) > y(A)), with u + v + (rows between A and B) < min(|A|, |B|);
      merge when found. The trimmed rows and the rows between are the block's n_discordant
    keep merged blocks with >= INV_MIN_LOCI rows of distinct mid_y outside n_discordant
```

Checked in `rr_inv_fix.py`:

| case | result |
|---|---|
| clean inversion | 1 block, n_discordant 0 |
| one locus moved +50 kb or −50 kb | 1 block, n_discordant 1 |
| two adjacent loci moved | 1 block, n_discordant 2 |
| two separate inversions on one seqid | 2 blocks |
| a 30-locus nested re-inversion | absorbed, n_discordant 29 |
| collinear, a wholly reversed seqid, 4 reversed loci | no block |

Add the test: "two separate inversions on one seqid → two blocks".

**N2 (Minor). `test_null_with_unequal_annotation`'s merged-state expectation is off and its bar is flaky.** Lines 765-766.
- The plan expects D "about +0.18" with the bar D > 0.1. The toy's expectation is +0.15.
- Analytic: RD resolution 0.804 against SD 0.586, so D = (1.373 − 1)/(1.373 + 1) = 0.157.
- Replica: mean +0.152, sd 0.033 over 100 seeds; D ≤ 0.1 in 7% of seeds.
- Write "expected about +0.15" and the bar "D > 0.05" (no seed of 100 at or below).

**N3 (Minor). `ltrpav run` in an env without scipy is unspecified.** Lines 101-103, 1447-1448.
- The lazy imports make `import ltrpav.cli` work. But `ltrpav run` now ends with the analyses, so in `ltrpav_bench` the stage's import raises ImportError.
- ImportError is not in `cli._HANDLED`, so the run ends in a traceback after the merge.
- Add: "the stage functions turn an ImportError of scipy or matplotlib into CliError('analyses need scipy and matplotlib: run ltrpav-stats and ltrpav-paint in the ltrpav env'): one error line, exit 1, the engine's outputs kept."
- Extend `test_cli_imports_without_scipy`: `ltrpav run` on `make_world` without scipy exits 1 with that line, and `loci.tsv` exists.

**N4 (Minor). The new `fit_mix` test takes about 5 minutes.** Lines 1349-1352.
- `rr_fitmix.py`: 288 s at 50,000 pairs (18 Nelder-Mead starts), on every CI Python version.
- At 10,000 pairs (62 s) it is fragile: w_flow = 0.0125, and the tail takes 26%.
- Keep 50,000 pairs. Mark the test `@pytest.mark.slow`, deselected in CI (`-m "not slow"` in its config) and run by the executor once in Task 9.

**N5 (Minor). `youngest_u95`'s exact counts belong to another copy.** Lines 974-975.
- Exact counts from `identity.tsv` are D's copy's LTR-LTR counts. `youngest_k` and the fallback u95 use X's (R's) copy.
- Both date the same insertion, so this is valid, but say so: "the donor copy's exact counts, the same insertion".
- These exist only where D is a member of the locus.

**Commands:**
```
export NUMPY_MADVISE_HUGEPAGE=0; cd /data2/chris/maize_introgression/benchmark_pav/plan2_review
/home/chris/bin/mambaforge/envs/ltrpav_bench/bin/python rr_toy.py            # toy expectations (C1, I10, M8, N2)
/home/chris/bin/mambaforge/envs/ltrpav_bench/bin/python rr_callable_inv.py   # M7 bounds; literal merge rule (N1)
/home/chris/bin/mambaforge/envs/ltrpav_bench/bin/python rr_inv_fix.py        # corrected merge rule (N1)
/home/chris/bin/mambaforge/envs/ltrmix/bin/python rr_fitmix.py               # fit_mix test and runtime (addition 2, N4)
```
