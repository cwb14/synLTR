#!/usr/bin/env python3
"""Two deletion records per annotated LTR-RT, for generic SV genotypers (Sniffles2 --genotype-vcf, kanpig).

  <id>|empty : the element plus one TSD copy deleted (pre-insertion allele)
  <id>|solo  : the internal region plus the right LTR deleted (solo LTR; with unequal LTRs the left one is kept)
--seq writes sequence-resolved REF/ALT (kanpig needs them; limit with --max-len), otherwise symbolic <DEL>.
Output is sorted by position. Usage: elements_to_sv_vcf.py -r ref.fa -a ltr.gff3 [--seq --max-len N] -o out.vcf
"""
import argparse
import os
import sys

import pysam

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from ltrkin.annot import read_gff3, infer_tsd  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-r", "--reference", required=True)
    ap.add_argument("-a", "--annotation", required=True)
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--seq", action="store_true", help="sequence-resolved REF/ALT instead of symbolic <DEL>")
    ap.add_argument("--max-len", type=int, default=0, help="skip deletions longer than this (0 = no limit)")
    a = ap.parse_args()
    fa = pysam.FastaFile(a.reference)
    els = read_gff3(a.annotation)
    recs = []
    for el in els:
        tsd = infer_tsd(fa, el)
        t = len(tsd) if tsd else 5
        for allele, d0, d1 in (("empty", el.start, el.end + t), ("solo", el.lltr[1], el.end)):
            if a.max_len and d1 - d0 > a.max_len:
                continue
            pos = d0                     # 1-based position of the base before the deletion
            if pos < 1:
                continue
            anchor = fa.fetch(el.chrom, pos - 1, pos).upper()
            info = f"SVTYPE=DEL;SVLEN={-(d1 - d0)};END={d1};ALLELE={allele};ELEMENT={el.id}"
            if a.seq:
                ref = fa.fetch(el.chrom, pos - 1, d1).upper()
                alt = anchor
            else:
                ref, alt = anchor, "<DEL>"
            recs.append((el.chrom, pos, f"{el.id}|{allele}", ref, alt, info))
    order = {c: i for i, c in enumerate(fa.references)}
    recs.sort(key=lambda r: (order[r[0]], r[1]))
    with open(a.out, "w") as fh:
        fh.write("##fileformat=VCFv4.2\n")
        for c in fa.references:
            fh.write(f"##contig=<ID={c},length={fa.get_reference_length(c)}>\n")
        fh.write('##ALT=<ID=DEL,Description="Deletion">\n')
        fh.write('##INFO=<ID=SVTYPE,Number=1,Type=String,Description="Type of structural variant">\n')
        fh.write('##INFO=<ID=SVLEN,Number=1,Type=Integer,Description="Length difference between ALT and REF">\n')
        fh.write('##INFO=<ID=END,Number=1,Type=Integer,Description="Last deleted base">\n')
        fh.write('##INFO=<ID=ALLELE,Number=1,Type=String,Description="empty or solo">\n')
        fh.write('##INFO=<ID=ELEMENT,Number=1,Type=String,Description="element ID">\n')
        fh.write('##FORMAT=<ID=GT,Number=1,Type=String,Description="Genotype">\n')
        fh.write("#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\n")
        for c, pos, vid, ref, alt, info in recs:
            fh.write(f"{c}\t{pos}\t{vid}\t{ref}\t{alt}\t.\tPASS\t{info}\n")
    print(f"{a.out}: {len(recs)} records from {len(els)} elements", file=sys.stderr)


if __name__ == "__main__":
    main()
