# Plan 3 final fix wave (one commit, before merge)

The whole-branch review of plan3-benchmark (12d3e6c..a44f532) found nothing that changes a result. It asks for a
few fixes before merge. The findings, with file:line, are in `task-final-review.md` (this directory); read it first.
- Repo: `/data2/chris/maize_introgression/LTRpav`, branch `plan3-benchmark`, BASE a44f532. Commit on this branch;
  never push, never create branches.

## Fix
1. **I1: make the simulator's assumptions visible to users.**
   - Extend `SIMPLIFICATIONS` in `src/ltrpav/sim/pop.py`, which is written into params.json, so it names every
     approximation the simulator makes. The review lists the missing ones:
     - backbone source K is read as K at the root, so every sample adds about 2·mu·T_root;
     - the whole-span existence rule;
     - indel-versus-removal ordering;
     - truth's G/O limits;
     - the tract-end limit.

     Check each against the module docstrings in `src/ltrpav/sim/` and state it in one plain line.
   - Add an epilog to `ltrpav-sim pop --help`: the default demography and rates and where they come from (the
     calibrated values, as DESIGN 12 states them); the Demog and Rates field names a user can override; and that the
     lineage pulse codes need sub_a/sub_c.
   - Test it: params.json lists every simplification, and `--help` shows the epilog.
2. **M1.** Mark `tests/test_cli_analysis.py:794`'s test `@needs_lastz`, as the file's other lastz tests are.
3. **M2.** DESIGN 12 item 1 must say that the grid ran on the first five windows (50 Mb), the pre-registered
   fallback chosen by the pilot gate, not ten 10-Mb windows.
4. **M3.** State the coordinate convention of `insertions.tsv`'s `pos` column where the file is documented (pop.py's
   docstring or help, and DESIGN 10.2 if it lists the columns): 0-based backbone anchor, or the donor-body offset for
   nested insertions. Name the convention as the user's CLAUDE.md requires (BED-like 0-based half-open versus 1-based).
5. **M4, partial: remove workflow traces outside src/ltrpav/analysis/.** Phrases such as "controller ruling", "the
   brief's", "per the brief", "Task N review", "review m3" and "ruling R4" describe how a change was made, not what
   the code does. Remove them from:
   - docstrings and comments in `src/ltrpav/sim/`;
   - the user-visible error message at `src/ltrpav/sim/popbuild.py:377`;
   - test files.

   Rewrite each to say what the code does or why, with no process history.
   - Never edit any file under `src/ltrpav/analysis/` or the engine: an edit there re-keys every finished
     real-genome view. Those strings wait for Plan 4.
   - Do not touch commit messages; a history rewrite is the user's call.

   List the remaining traces under `src/ltrpav/analysis/` in your report.

## Constraints
- Engine modules stay untouched (`checkpoint.STAGE_MODULES`, `src/ltrpav/constants.py`), and so does
  `src/ltrpav/analysis/`. Show that every STAGE_MODULES fingerprint still equals 12d3e6c's, and that `git diff
  a44f532 -- src/ltrpav/analysis src/ltrpav/constants.py src/ltrpav/checkpoint.py` is empty.
- Env ltrpav (`/home/chris/bin/mambaforge/envs/ltrpav/bin` first on PATH), `NUMPY_MADVISE_HUGEPAGE=0`. Never install
  packages; never run python with -I or -E.
- Focused tests while working. After committing, launch the full suite detached and do not wait:
  `setsid -f nohup bash -c 'cd /data2/chris/maize_introgression/LTRpav && export NUMPY_MADVISE_HUGEPAGE=0 PATH=/home/chris/bin/mambaforge/envs/ltrpav/bin:$PATH && python -m pytest -W error -m "not slow" -q -rfEs > SUITE_DIR/suite.log 2>&1; echo $? > SUITE_DIR/suite.exit' < /dev/null > /dev/null 2>&1`
- One commit, global git identity, no AI attribution. Suggested message: "Document the simulator's assumptions and
  defaults; mark a lastz test; DESIGN 12 grid size". The message must not describe the review process either.
- American English. At most 8 threads and 15 minutes per command; never kill a process.
