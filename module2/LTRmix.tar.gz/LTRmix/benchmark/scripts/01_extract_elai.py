#!/usr/bin/env python3
"""Extract per-SNP ELAI summaries and selected lines from Yang et al. 2023 elai.845.txt.gz (streaming).
Writes: per-SNP mean dosage across lines, fraction of lines with dosage >1.8 ('high-confidence homozygous mexicana',
the paper's own definition), n lines called, and dosage for the selected lines. -999 = missing."""
import argparse, gzip, numpy as np
ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument("elai"); ap.add_argument("out")
ap.add_argument("--lines", default="B73.amp,MO17.amp,CML228.amp,CML69.amp")
a = ap.parse_args()
want = a.lines.split(",")
with gzip.open(a.elai, "rt") as f, open(a.out, "w") as o:
    hdr = f.readline().rstrip("\n").split("\t")
    idx = [hdr.index(w) for w in want]
    o.write("\t".join(["chrom", "pos", "n_called", "mean_dosage", "frac_gt1.8"] + want) + "\n")
    for line in f:
        p = line.rstrip("\n").split("\t")
        v = np.array(p[2:], dtype=float)
        ok = v > -900
        n = int(ok.sum())
        m = float(v[ok].mean()) if n else float("nan")
        fr = float((v[ok] > 1.8).mean()) if n else float("nan")
        sel = [p[i] for i in idx]
        o.write(f"{p[0]}\t{p[1]}\t{n}\t{m:.4f}\t{fr:.4f}\t" + "\t".join(sel) + "\n")
