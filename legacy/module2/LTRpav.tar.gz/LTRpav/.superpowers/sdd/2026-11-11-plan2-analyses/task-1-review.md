# Task 1 review: foundations (12279a1..837ea50)

Reviewer checks (read-only on the checkout; scratch in `benchmark_pav/plan2_reviews/task1/`):
- **Tests:** `pytest -W error tests/test_catalog.py tests/test_checkpoint.py`: 38 passed in 4.5 s, no warnings. `ruff check --no-cache .`: clean.
- **Brief match:** the brief's five tests are AST-identical to the committed ones, and the constants block is verbatim.
- **Lock file:** rebuilt from a fresh `env export` with the 84c8088 filter. The package list is identical.
- **Real data:** `load_catalog` and independent join checks on a scratch copy of main3 (`probe/load_time.py`, `probe/join_check.py`).
- **Toy:** edge probes (`probe/toy_edges.py`) and a seed-1 spot check of `simulate_run` (`probe/sim_check.py`).

## Spec Compliance

- ✅ **Step 1.**
  - The branch is cut from `plan1-engine` (= 12279a1).
  - pyproject has `scipy>=1.11` and `matplotlib>=3.8`.
  - The lock was made by 84c8088's procedure: no `prefix:`, no pip section, no `ltrpav==`, and `scipy=1.18.1` is present. Its package list matches a fresh export of the env.
  - `ltrpav_bench` is untouched (its history file was last written 2026-11-10).
- ⚠️ **Step 1 deviation:** environment.yml has `matplotlib-base`, not `matplotlib`. The controller has accepted this, and pyproject's `matplotlib>=3.8` is right for pip.
- ✅ **Step 2.** The five brief tests are verbatim (AST-identical). There is one added test.
- ✅ **Step 3: the `catalog_toy` API matches the brief:**
  - `ToyLocus` fields and defaults, with `default_factory` per A4/D1;
  - `ToyRun.load`, `loc`, `dmat`, `read_tsv`, `GENOMES`, `TRACTS`;
  - the `write_run` and `simulate_run` signatures;
  - the draw semantics (pattern table, tract copy, true states, members, calls, merge);
  - the spacing check;
  - the `toy_fastas` session fixture.
- ⚠️ **Step 3: two toy problems.**
  - `b_strand` is unspecified by the brief, and the implementer's choice is not what the engine writes (I1).
  - The brief's own toy table differs from the engine on O sites, D/O tiers and D sites. It is implemented as specified (I2).
- ✅ **Step 5.**
  - The constants are verbatim, with the docstring.
  - `load_catalog` fails fast on `manifest.json` and `loci.tsv`.
  - It reads loci.tsv in two passes into preallocated arrays.
  - It streams each pair file once, and a missing file or a non-`CALL_COLUMNS` header fails with the file named.
  - `sheet_sha` comes from `file_checksum(sheet, work/checksums.json)`.
  - Lengths come from `Fasta(..., cache_dir=work/fai)`.
  - `top` comes from the element tables.
  - It makes no engine-fingerprint check.
- ✅ **Step 6.** The task's tests pass under `-W error`, and ruff is clean.
- ✅ **Step 7.** DESIGN section 12 has "Build decisions (plan 2)" with the twelve calls, condensed faithfully from the plan's list. Call 11 is verbatim.
- ✅ **Step 8.**
  - The commit message is exact.
  - The author and committer are cwb14.
  - There are no trailers and no AI attribution anywhere in the diff.
- ✅ **Global constraints.**
  - Analysis code and constants are only in `ltrpav.analysis` and `ltrpav.plot`, and no engine module is edited.
  - An analysis edit leaves every `STAGE_MODULES` key unchanged (test verified, see Strengths).
  - The discoverer's own calls are exposed (`proj`/`ptier`/`pseq`/`pstart`/`pend`/`pstrand`).
  - All input is streamed, and output is deterministic (seeded rng, gzip mtime 0).
  - Spelling is American.
- ⚠️ **`tests/test_checkpoint.py`** (outside the brief's file list) has a one-line `mkdir(exist_ok=True)`. It is justified: the copied package now holds `analysis/`, and the assertions keep their meaning. It is a test, not an engine module.

## Strengths

**The join is correct on real data. I reproduced it independently on main3 (322,538 loci, 9 pair files):**
- **Single-member loci:** on all 272,012 of them, the merged state, tier, site and strand equal the discoverer's own call exactly (1.000000 for all 9 discoverer→genome pairs).
- **Row accounting:** every pair file has exactly one row per element. The rows the loader skips equal each genome's extra members exactly (B73 783, TIL18 1,622, TIL01 1,539). No member is missing from its element table.
- **`top`:** its keys equal each genome's members. The nested counts (35,539 / 33,649 / 37,518) match the report.
- **Own column:** every member's own column is P/high, and every non-member row is "no call".

**Validation:**
- The fail-fast checks mirror loci.py's own pair parser:
  - unknown state, tier or `b_strand`;
  - a site without `1 <= start <= end`;
  - a seqid absent from the FASTA;
  - a duplicate eid;
  - a P/S/T call without a site.
- The loader adds checks of its own: lost member calls, a corrupt gzip, and an "annot" tier in a pair file.
- The messages name the file and line.

**Cost:** `load_catalog` takes 10.8 s and 448 MB peak RSS on main3, which reproduces the report's figures (149 MB of that is arrays). The reading follows the brief's streaming rules: two passes over loci.tsv, and pair files split only up to `b_strand`.

**The fingerprint test is sound.**
- It runs in a fresh subprocess.
- The editable install is a `.pth` path entry, so the PYTHONPATH copy wins. An import-hook editable install would make the test fail loudly, not pass silently.
- It covers every stage in `STAGE_MODULES`, and every engine `stage_key` call site uses one of those stages: elements, anchor, raw, blastdb, mm2_index, genotype_pair, genotype_chunk.
- `cli._check_pair_files` keys on `stage_fingerprint("genotype_pair")`, so the test covers it too.

**`simulate_run` behaves as the plan says.** My seed-1 spot check:
- With `p_missing={"S": 0.6}`, D's calls resolve R and S at 0.849 and 0.401.
- With `TRACTS` and `n_per_seq` 3000: D_pav is +0.288, `n_rd_tract` is 322, and the same seed's null gives -0.033.

**Code quality:**
- `Catalog` is `eq=False/repr=False`, so array fields never break `==` and never flood pytest output.
- `AnalysisError` subclasses `ValueError`.
- The `top` walk is memoized and cycle-safe.
- Repeated strings are interned.
- The docstrings are precise.
- The added test has mutation evidence.

## Issues

### Critical
None.

### Important

**I1. The toy's `b_strand` is not the engine's. It makes calls into an unknown-strand genome unorientable, and a test asserts this.**
- **Where:** `tests/catalog_toy.py:403`, `tests/test_catalog.py:92`.
- **What is wrong:**
  - **What the toy writes:** `b_strand` comes from A's and B's strands agreeing. It is "." whenever either strand is unknown, even when the call has a site.
  - **What the engine writes:**
    - `b_strand` is the window's orientation: `classify._b_site` always returns "+" or "-" when there is a site. All 944,028 sited calls in main3's 9 pair files are "+" or "-", and none is ".".
    - So in the engine a call's strand is unknown only when the caller's own element strand is ".". That is common: 14,498 of 127,636 elements in B73, 14,724 of 124,641 in TIL18, and 16,544 of 137,847 in TIL01.
    - It is never unknown because the target genome's strand is unknown.
  - **Consequences:**
    - The added test asserts `cat.pstrand["R"][1, s] == 0`. The engine would give -1 there (R "+", S mirrored at that locus).
    - Decision 2 sets Task 9 up to rely on this: its planned test puts the "." on S to trigger "orientation not inferred". That is a case real runs cannot produce, and the real case (the caller's strand ".") would go untested.
    - The toy writes a non-member's loci.tsv strand from its given strand, but loci.py takes it from the deciding call. For example, `strand={"R": "."}` gives loci.tsv S "+" but `pstrand["R"][:, S]` 0. The engine would write "." for both.
- **Why it matters:** every later task tests on this toy.
- **How to fix:**
  - Write `b_strand` as the window orientation, and never "." when there is a site:
    - "-" when exactly one of A and B is mirrored at the locus, or when both given strands are known and differ;
    - "+" otherwise.
  - Then `pstrand` is the caller's strand turned, as in loci.py: 0 only when the caller's strand is ".".
  - Preferably, take a non-member's loci.tsv strand from the deciding call.
  - Change `test_catalog.py:92` to `cat.pstrand["R"][1, s] == -1`, and keep `cat.pstrand["S"][1, r] == 0`.
  - Tell the Task 9 brief to put the "." on the discovering genome (D), which is the case BED-annotated genomes produce.

**I2. The brief's toy table writes states the engine never writes.**
- **Where:** `tests/catalog_toy.py:37`, 318-327, 383-385, 406-407.
- **What is wrong:** three of the four differences below come from the brief.
  - **(a) O has no site.**
    - Classify gives every O call the B gap as its site (`classify.py:199,202`, `b=(g.b0, g.b1)`), with `b_ins` its length. All 201,707 O states in main3's loci.tsv have a site, and 162,314 of them are over 1 kb.
    - The toy writes O with no site but `b_ins` 500.
    - loci.py's module docstring (line 42, "G, U and O have none") is stale, and is the likely source of the brief's table.
  - **(b) Tiers disagree between files.**
    - The toy's pair files give D and O calls tier "high", while loci.tsv gives the same, only call "medium".
    - loci.py's merged tier is the deciding call's tier, so the engine cannot write this.
    - In main3, O calls are only "low" or "medium", never "high".
  - **(c) D's site is the element span (150 bp).** The engine's D site is the junction: 229,705 of 230,078 D states in main3 (99.8%) span 2 bp or less.
  - **(d) No `inv` flag.**
    - The engine flags every call from a reversed window: all 6,328 `b_strand` "-" calls in B73→TIL18 carry `inv`. The flag reaches the loci.tsv state such a call decides.
    - Mirrored toy loci never carry it.
- **Why it matters:**
  - Every later task's tests run on this toy. Code that equates "has a site" with "resolved", or that reads O/D sites or D/O call tiers, would pass on the toy and behave differently on real runs. Examples: the `proj_site` and `pseq` consumers, Task 4's `high_tier` stratum, and Task 8's O/D evidence.
  - Fixing it now is cheap, because no rng draws change. Once Tasks 2-9 derive seeded expected values from the toy, a tier change would ripple through their expected counts.
- **How to fix:** this needs a controller ruling that amends the brief's table.
  - Give O a site and strand in both files, e.g. `pos .. pos + b_ins - 1` with the default `b_ins` 500.
  - Write each default call's pair-file tier as its loci.tsv tier: D and O "medium"; P, S, T and E "high".
  - Make D's site a 2-bp junction (`pos - 1 .. pos`).
  - Add `inv` to the flags of calls with `b_strand` "-", and to the loci.tsv state they decide.
  - Optionally fix loci.py's docstring line 42. loci.py is in no `STAGE_MODULES` set, so no engine key changes.

### Minor

**M1. `cluster_keys` silently misreads an index array.**
- **Where:** `src/ltrpav/analysis/catalog.py:196`.
- **What is wrong:** `rows` goes through `np.flatnonzero`, so `rows=[1, 2]` returns the keys of rows 0 and 1 (confirmed by probe).
- **Why it matters:** Task 4 sorts rows by position before it collapses clusters, which invites passing an order array.
- **How to fix:** require a bool mask of shape (n,) and raise otherwise. Validate `gstar` with `cat._gstar`.

**M2. The toy's `_check` does not bound mirrored sites.**
- **Where:** `tests/catalog_toy.py:281`, 324.
- **What is wrong:** a locus that starts inside `[a, b]` but ends past `b` mirrors to start `a + b - end`, which can be 0 or below. The probe gave S's site `chr1:-138-11`.
- **Why it matters:** `write_run` writes the site, so the error shows up later as the loader's `AnalysisError`, not as the toy's own `ValueError`.
- **How to fix:** check that the mirrored span lies within `[1, length]`, or require the whole element to lie inside `[a, b]`.

**M3. The loader writes into the run directory.**
- **Where:** `src/ltrpav/analysis/catalog.py:234`.
- **What is wrong:** `load_catalog` writes the sheet's checksum into the run's `work/checksums.json`.
- **Why it matters:** on a read-only run whose cache lacks the entry, `_write_json` raises a raw `PermissionError`, not an `AnalysisError`. That clashes with "analyses read runs as data".
- **How to fix:** hash the sheet without caching when the cache cannot be written, or turn the error into an `AnalysisError` that names the directory.

**M4. Memory scaling of the brief's dense arrays.**
- **Where:** `src/ltrpav/analysis/catalog.py:436`.
- **What is wrong:** `proj`, `ptier`, `pseq`, `pstart`, `pend` and `pstrand` are each (n, G) per annotated genome, so memory grows as n·G·A.
- **Why it matters:**
  - Fine at main3 scale and at DESIGN's v1 ceiling (about 10 genomes): about 2 GB of these arrays at 1M loci.
  - Tens of GB at the v2 pangenome scale, and DESIGN 3 asks that v1 not block v2.
- **How to fix:**
  - No change now. For v2, store each A's calls only on A's member rows.
  - Note for Task 10: load the catalog once per run, not once per stage. One load takes about 11 s on main3, and over a minute at 10 genomes by extrapolation.

**M5. Analysis keys can miss changes to the engine readers they use.**
- **Where:** `docs/DESIGN.md:650` (call 12).
- **What is wrong:** analysis keys hash `ltrpav.analysis` and the checksums of the outputs read. But `catalog.py:36-40` also depends on engine readers: `elements.read_elements`, `seqio.Fasta`, `classify.CALL_COLUMNS` and `checkpoint.file_checksum`.
- **Why it matters:** a parsing change in one of those readers leaves the bytes read, and so the keys, unchanged. Task 10's "done, skip" would then reuse stale results.
- **How to fix:** for Task 10, weigh adding those named modules (not their import closures) to the analysis fingerprint. Engine keys stay unchanged. This trades against ruling C3's "reruns only when the outputs read change".

## Assessment

**Task quality: Needs fixes.**
- The loader is correct, validated on main3, fast enough, and meets the brief. It can stand as is.
- The toy that every later task tests on writes states the engine never writes:
  - the `b_strand` model (I1, implementer's choice, asserted by the added test);
  - O sites, D/O tiers, D junctions and `inv` (I2, from the brief's table).
- Fix both before Task 2 bakes seeded expected values into its tests. I2 needs a controller ruling that amends the brief.

## Re-review (fix round 1: 837ea50..3cb7c3e)

Checks (read-only on the checkout; scratch in `benchmark_pav/plan2_reviews/task1/`):
- **Tests:**
  - `test_catalog.py`: 9 passed. `test_read_only_run` ran; it was not skipped.
  - `test_checkpoint.py` and `test_loci.py` pass under `-W error`.
  - ruff is clean.
  - The brief's five tests are still AST-identical.
- **Engine keys:** I computed the seven `STAGE_MODULES` keys in fresh processes from `git archive` exports of 12279a1, 837ea50 and 3cb7c3e. Each process checked that it imported its own export. All seven keys are identical across the three commits:

  | Stage | Key (first 8 hex) |
  |---|---|
  | anchor | be2d7ee2 |
  | blastdb | e00496be |
  | elements | cd82ffba |
  | genotype_chunk | 2f17bb6d |
  | genotype_pair | 6cec6527 |
  | mm2_index | a308187b |
  | raw | 7c4edfa2 |

- **Toy against main3** (`probe/toy_vs_engine.py`):
  - **Toy runs scanned (every pair file and loci.tsv):**
    - `simulate_run` seed 1, with S inverted on chr1:100,001-400,000;
    - seed 2 with `p_missing` 0.3, with R inverted on chr2:1-300,000;
    - a hand-written run with O, D, G, U, a mirrored S and a nested `host_empty` E.
  - **Compared against:** facts tabulated from all 9 main3 pair files.
- **Later tasks' configurations:** I ran the seven `simulate_run` configurations later tasks use (`probe/planned_configs.py`).
- **Loader on main3:** 11.0 s and 448 MB, unchanged.

### Verdicts

**I1. ADDRESSED.**
- **The fix:**
  - `b_strand` is now the window's orientation (`_Places.reversed`, `catalog_toy.py:361`, written at :451). It is "+" or "-" on every sited call.
  - "." is allowed only as a member's own strand (`_check`). So a call's strand is unknown only where the caller's own strand is ".".
  - A non-member's loci.tsv strand comes from `build_loci`.
- **Evidence:**
  - The toy runs have 0 sited calls without "+" or "-". main3 has 0 of 944,028.
  - The test now asserts `pstrand["R"][1, s] == -1` and `pstrand["S"][1, r] == 0`.
  - The plan's Task 9 test now puts the "." on D (plan line 1974).

**I2. ADDRESSED.**
- **(a) O sites.**
  - Every toy O call has a site, of length `b_ins`.
  - In main3 all 221,874 O calls have a site. Every non-inherited O (166,331) has length equal to `b_ins`; the other 55,543 are rule-0 `inherit` copies of a host's site.
- **(b) Tiers.**
  - loci.tsv now comes from `build_loci` over the written pair files.
  - In every toy row, the merged tier equals the top tier among the member calls.
  - Each single-member row equals its call exactly (13,995 states checked).
  - Every toy (state, tier) pair occurs in main3: P high, S high with `solo_tsd`, T/D/O medium, E high, G/U ".". (In main3, 5,772 of 5,772 S-high calls carry `solo_tsd`.)
- **(c) D sites.** Toy D sites are 2 bp. In main3, 249,847 of the 249,943 D calls with `b_ins` 0 are 2 bp.
- **(d) `inv`.**
  - On sited calls, `inv` is present exactly when `b_strand` is "-". The toy has 0 violations. In main3, all 77,642 "-" calls carry it and none of the 866,386 "+" calls do.
  - G calls in reversed windows carry it, as in main3 (54 such calls). U calls never do.
- **loci.py docstring.** The fix is accurate: it matches `loci.py:101`, where `_SITED` excludes O. It changes no engine key.

**M1. ADDRESSED.** `catalog.py:216` rejects a non-bool or wrong-shape `rows`, and `gstar`'s shape is checked. My round-0 probe (`rows=[1, 2]`) now raises, and the added test covers it.

**M2. ADDRESSED.** `catalog_toy.py:392` checks every site's bounds before any file is written. The round-0 case now raises "leaves the sequence".

**M3. ADDRESSED.** `catalog.py:272` hashes the sheet without the cache and logs one warning. `test_read_only_run` passes.

**M4. ADDRESSED (documented).** The catalog docstring has a "Scale" paragraph. Its figures check out: 322,538 × 4 × 3 × 23 B = 89 MB, and 10^6 × 10 × 10 × 23 B = 2.3 GB.

**M5. ADDRESSED, per the ruling.**
- `READER_MODULES` (`catalog.py:63`) is in place, DESIGN call 12 names it, and an AST test checks it equals catalog.py's engine imports.
- Forward note: the test reads only catalog.py's relative imports. Task 9's identity layer will import the engine aligner. When it lands, extend the scan to every module of `ltrpav.analysis` and `ltrpav.plot`, and to absolute imports.

### New issues from the fix (none Critical or Important)

**N1 (Minor). Toy U calls have wid "."**
- **Where:** `catalog_toy.py:443`, 452; docstring at :17.
- **What is wrong:**
  - The engine cannot write this for the toy's elements:
    - `make_windows` gives every top-level element a window, even an unresolved one (`window.py:105-108`).
    - genotype.py writes wid "." only for elements that no window reaches (`genotype.py:365-383`). Those are nested elements under a broken parent chain, and the toy never builds one.
  - In main3, 0 of 225,183 U calls have wid ".". The 2,822 `no_anchor` U calls all have a wid.
  - In the toy, every U call has wid ".": 4,977 and 10,065 of them in the two simulated runs.
  - Round 0 wrote a wid here; the fix removed it.
- **Why it matters:** no planned reader uses a U call's wid (Task 8 uses wid only for adjacent E/D, and reads U's reason). But it is the one place where the toy still breaks the letter of the ruling.
- **How to fix:** keep U as `no_anchor` with no `inv` (an unresolved window has strand 0), but write its wid. Correct the docstring at :17 and the comment at :443.

**N2 (Minor). D sites ignore a given `b_ins`.**
- **Where:** `catalog_toy.py:380`.
- **What is wrong:** a test-given D with `b_ins` > 0 still gets a 2-bp site. The engine's junction is `[g.b0 - 1, g.b1 + 1)`, which is `b_ins` + 2 bp (`classify.py:260-263`; 300 of 300 such calls in main3).
- **Why it matters:** no current or planned test gives D a `b_ins` > 0, but such a test would get a D site the engine cannot write.
- **How to fix:** `s, e = x.pos - 1, x.pos + b_ins`, with `b_ins` defaulting to 0.

**N3 (Minor, docstring). The stated reason for D's tier is wrong.**
- **Where:** `catalog_toy.py:8`.
- **What is wrong:** it says T, D and O "never have the evidence a high tier needs". That is right for T and O, but not for D: `classify.py:204` passes `evidence=refined`, and main3 has 109,263 D-high calls.
- **Why it matters:** writing D as medium is still engine-possible, so only the stated reason is wrong.
- **How to fix:** correct the reason text.

**Accepted by the controller, not re-reviewed:** rule 0 is not modeled, and `test_load_roundtrip` keeps nesting the engine cannot produce.

### Later-task compatibility
- **Configurations:** all seven `simulate_run` configurations quoted by Tasks 4, 5, 6 and 11 write and load. That includes the inversion `("S", "chr2", 300_001, 700_000)`, with and without `TRACTS`.
- **D's own-call values are unchanged:**
  - seed 1 with `p_missing` S 0.6: R 0.849, S 0.401;
  - the leak configuration: D's own calls at -0.031.
- **`calls=` overrides:** the plan's overrides (lines 345, 834, 1002-1003, 1436) still merge to their specs. In each case the other member's P call links the members.

### Re-review assessment

**Task quality: Approved.**
- I1, I2 and M1-M5 are addressed, and verified against main3. The engine stage keys are unchanged.
- N1-N3 are Minor.
- N1 is a one-line fix. The controller may want it before Task 2, since it is the one place the toy still writes what the engine cannot.
