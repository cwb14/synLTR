"""Tiny synthetic diploid with planted LTR-RTs, simulated long reads and minimap2 alignments (test fixture).

Ancestral random sequence A; each event inserts an element at A[p] with a 5-bp TSD (T = A[p:p+5]):
  full: A[:p] + T + element + T + A[p+5:]      solo: A[:p] + T + LTR + T + A[p+5:]      empty: A unchanged
  X: A[x0:x1] deleted on that haplotype (element and flanks missing: hemizygous on the other)
hap1 is the reference; truth genotypes are per element (alleles of hap1/hap2).
"""
import os
import random
import subprocess

COMP = str.maketrans("ACGTN", "TGCAN")


def rc(s):
    return s.translate(COMP)[::-1]


def rand_seq(rng, n):
    return "".join(rng.choice("ACGT") for _ in range(n))


def mutate(rng, s, rate):
    s = list(s)
    for i in range(len(s)):
        if rng.random() < rate:
            s[i] = rng.choice([b for b in "ACGT" if b != s[i]])
    return "".join(s)


def make_family(rng, ltr_len, int_len):
    ltr = "TG" + rand_seq(rng, ltr_len - 4) + "CA"
    return {"ltr": ltr, "int": rand_seq(rng, int_len)}


def make_copy(rng, fam, div):
    ltr = mutate(rng, fam["ltr"], div)
    return {"ltr": ltr, "int": mutate(rng, fam["int"], div)}


def element_seq(cp, inner=None, inner_state="F"):
    """Full element sequence; inner = (offset in internal, copy dict) inserted with its own TSD when inner_state F."""
    internal = cp["int"]
    info = None
    if inner is not None and inner_state == "F":
        q, icp = inner
        iseq = icp["ltr"] + icp["int"] + icp["ltr"]
        t = internal[q:q + 5]
        internal = internal[:q + 5] + iseq + t + internal[q + 5:]
        info = (len(cp["ltr"]) + q + 5, len(iseq), len(icp["ltr"]))
    return cp["ltr"] + internal + cp["ltr"], info


def build_hap(A, events, hap, ann=None, chrom="chr1"):
    """Haplotype sequence; if ann is a list, append LTR-RT annotation records (hap1 coordinates)."""
    out, cur, n = [], 0, 0
    for ev in sorted(events, key=lambda e: e["p"]):
        st = ev["state"][hap]
        p = ev["p"]
        if st == "X":
            x0, x1 = ev["xdel"]
            out.append(A[cur:x0]); n += x0 - cur; cur = x1
            continue
        out.append(A[cur:p + 5]); n += p + 5 - cur; cur = p + 5
        T = A[p:p + 5]
        if st == "F":
            seq, info = element_seq(ev["copy"], ev.get("inner"), ev.get("inner_state", {}).get(hap, "F"))
            if ann is not None:
                L, l = len(seq), len(ev["copy"]["ltr"])
                ann.append(dict(id=ev["id"], chrom=chrom, s=n, e=n + L, l5=(n, n + l), l3=(n + L - l, n + L),
                                fam=ev["fam"]))
                if info:
                    off, il, ll = info
                    ann.append(dict(id=ev["id"] + "_inner", chrom=chrom, s=n + off, e=n + off + il,
                                    l5=(n + off, n + off + ll), l3=(n + off + il - ll, n + off + il), fam=ev["inner_fam"]))
            out.append(seq + T); n += len(seq) + 5
        elif st == "Fx":                     # full element with an internal deletion (other internal length)
            seq, _ = element_seq(ev["copy"])
            l = len(ev["copy"]["ltr"])
            d0, d1 = ev["int_del"]
            seq = seq[:l + d0] + seq[l + d1:]
            out.append(seq + T); n += len(seq) + 5
        elif st == "S":
            out.append(ev["copy"]["ltr"] + T); n += len(ev["copy"]["ltr"]) + 5
        elif st == "E":
            pass
    out.append(A[cur:])
    return "".join(out)


def write_gff(path, ann):
    with open(path, "w") as fh:
        fh.write("##gff-version 3\n")
        for a in sorted(ann, key=lambda r: (r["chrom"], r["s"])):
            fh.write(f"{a['chrom']}\tsynth\tLTR_retrotransposon\t{a['s'] + 1}\t{a['e']}\t.\t+\t.\t"
                     f"ID={a['id']};family={a['fam']};clade=test\n")
            for tag, (x, y) in (("lLTR", a["l5"]), ("rLTR", a["l3"])):
                fh.write(f"{a['chrom']}\tsynth\tlong_terminal_repeat\t{x + 1}\t{y}\t.\t+\t.\t"
                         f"ID={a['id']}.{tag};Parent={a['id']}\n")


def simulate_reads(rng, seqs, depth, mean_len, err, fh, tag):
    """Reads uniformly from each sequence; lengths ~ lognormal; errors split equally into sub/ins/del."""
    import math
    n_tot = 0
    for name, s in seqs.items():
        n = int(depth * len(s) / mean_len)
        for k in range(n):
            ln = max(1500, min(len(s), int(rng.lognormvariate(math.log(mean_len) - 0.06, 0.35))))
            st = rng.randrange(0, len(s) - ln + 1)
            r = s[st:st + ln]
            if err > 0:
                o = []
                for b in r:
                    u = rng.random()
                    if u < err / 3:
                        o.append(rng.choice([c for c in "ACGT" if c != b]))
                    elif u < 2 * err / 3:
                        o.append(b + rng.choice("ACGT"))
                    elif u < err:
                        continue
                    else:
                        o.append(b)
                r = "".join(o)
            if rng.random() < 0.5:
                r = rc(r)
            fh.write(f"@{tag}_{name}_{k}\n{r}\n+\n{'I' * len(r)}\n")
            n_tot += 1
    return n_tot


def build(outdir, seed=1, depth_per_hap=15, mean_len=12000, err=0.005, het=0.0):
    """Write ref.fa, elements.gff3, truth.tsv, reads.fq, full.bam and primary.bam into outdir. Returns paths.
    het: substitution rate between the haplotypes (hap2 mutated after construction)."""
    rng = random.Random(seed)
    os.makedirs(outdir, exist_ok=True)
    famA, famB = make_family(rng, 400, 4000), make_family(rng, 600, 6000)
    A1, A2 = rand_seq(rng, 160000), rand_seq(rng, 60000)
    A3 = rand_seq(random.Random(seed + 7), 40000)      # separate stream: the other sequences are unchanged
    cp = lambda f: make_copy(rng, f, 0.002)
    ev1 = [
        dict(id="E1_het_empty", p=20000, copy=cp(famA), fam="famA", state={"h1": "F", "h2": "E"}),
        dict(id="E2_het_solo", p=45000, copy=cp(famA), fam="famA", state={"h1": "F", "h2": "S"}),
        dict(id="E3_hom", p=70000, copy=cp(famB), fam="famB", state={"h1": "F", "h2": "F"}),
        dict(id="E4_hemi", p=95000, copy=cp(famA), fam="famA", state={"h1": "F", "h2": "X"}, xdel=(87000, 103000)),
        dict(id="E5_nested_outer", p=125000, copy=cp(famB), fam="famB", state={"h1": "F", "h2": "F"},
             inner=(3000, cp(famA)), inner_fam="famA", inner_state={"h1": "F", "h2": "E"}),
    ]
    ev2 = [
        dict(id="E7_hom", p=15000, copy=cp(famB), fam="famB", state={"h1": "F", "h2": "F"}),
        dict(id="E8_decoy_hom", p=40000, copy=cp(famB), fam="famB", state={"h1": "F", "h2": "F"}),
    ]
    ev3 = [dict(id="E9_internal_del", p=18000, copy=make_copy(random.Random(seed + 8), famA, 0.002), fam="famA",
                state={"h1": "F", "h2": "Fx"}, int_del=(1000, 2500))]
    ann = []
    h1 = {"chr1": build_hap(A1, ev1, "h1", ann, "chr1"), "chr2": build_hap(A2, ev2, "h1", ann, "chr2"),
          "chr3": build_hap(A3, ev3, "h1", ann, "chr3")}
    h2 = {"chr1": build_hap(A1, ev1, "h2"), "chr2": build_hap(A2, ev2, "h2"), "chr3": build_hap(A3, ev3, "h2")}
    if het > 0:
        h2 = {c: mutate(random.Random(seed + 100), v, het) for c, v in h2.items()}
    truth = {"E1_het_empty": "F/E", "E2_het_solo": "F/S", "E3_hom": "F/F", "E4_hemi": "F/N",
             "E5_nested_outer": "F/F", "E5_nested_outer_inner": "F/E", "E7_hom": "F/F", "E8_decoy_hom": "F/F",
             "E9_internal_del": "F/F"}
    ref = os.path.join(outdir, "ref.fa")
    with open(ref, "w") as fh:
        for c, s in h1.items():
            fh.write(f">{c}\n" + "\n".join(s[i:i + 80] for i in range(0, len(s), 80)) + "\n")
    gff = os.path.join(outdir, "elements.gff3")
    write_gff(gff, ann)
    with open(os.path.join(outdir, "truth.tsv"), "w") as fh:
        fh.write("element_id\ttruth\n" + "".join(f"{k}\t{v}\n" for k, v in truth.items()))
    fq = os.path.join(outdir, "reads.fq")
    with open(fq, "w") as fh:
        simulate_reads(rng, h1, depth_per_hap, mean_len, err, fh, "h1")
        simulate_reads(rng, h2, depth_per_hap, mean_len, err, fh, "h2")
    full = os.path.join(outdir, "full.bam")
    prim = os.path.join(outdir, "primary.bam")
    subprocess.run(f"minimap2 -ax map-hifi -t 4 {ref} {fq} 2>/dev/null | samtools sort -o {full} - 2>/dev/null && "
                   f"samtools index {full} && samtools view -b -F 0x904 -o {prim} {full} && samtools index {prim}",
                   shell=True, check=True)
    return dict(ref=ref, gff=gff, full=full, primary=prim, truth=truth)
