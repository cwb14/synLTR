#!/usr/bin/env python3
"""Pick and verify the base-pair example for Fig. 3 (absence check): one B73 LTR-RT that the library-only method
calls 'absent' in TIL01 and that the raw TIL01 assembly confirms as an empty site.

Rule: among library-only 'absent' calls with raw-assembly state 'empty' (absence/B73v5.TIL01.tsv.gz), keep elements
with a 5-bp TSD, TG..CA motif, high confidence, not nested, length inside the inter-quartile range of its family;
rank by distance to the median K2P and median length of ALL absent calls; take the first candidate that passes the
structural checks on the raw B73 assembly (identical TSDs on both sides, TG..CA at both LTRs) and whose empty site is
found in the raw TIL01 assembly between the TIL01 orthologs of the nearest flanking B73 elements (edlib, both
flanks >= 95% identity, one TSD copy). Writes data/example_absence.json. Usage: python fig3_example.py"""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import glob
import gzip
import json
import os
import subprocess
import sys

import edlib
import numpy as np
import pandas as pd

R = "/data2/chris/maize_introgression"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
COMP = str.maketrans("ACGTNacgtn", "TGCANtgcan")


def faidx(fa, region):
    s = subprocess.run(["samtools", "faidx", fa, region], capture_output=True, text=True, check=True).stdout
    return "".join(s.split("\n")[1:]).upper()


def rc(s):
    return s.translate(COMP)[::-1]


def main():
    ab = pd.read_csv(f"{R}/benchmark/absence/B73v5.TIL01.tsv.gz", sep="\t")
    allabs = ab[ab.status_in_TIL01 == "absent"].copy()
    allabs["len"] = allabs.end - allabs.start + 1
    k2p_med, len_med = allabs.k2p.median(), allabs.len.median()
    cand = allabs[(allabs.genome_state == "empty")].copy()
    lt = pd.concat([pd.read_csv(f, sep="\t") for f in sorted(glob.glob(f"{R}/run/B73v5_LTRs_depth*_clean_ltr.tsv"))])
    lt = lt.rename(columns={"#seq_id": "seq_id"}).set_index("seq_id")
    lt = lt[pd.to_numeric(lt.seq_len, errors="coerce").notna()].copy()
    lt = lt[~lt.index.duplicated()]
    lt["len"] = pd.to_numeric(lt.seq_len)
    for c in ("ltr5_len", "ltr3_len"):
        lt[c] = pd.to_numeric(lt[c], errors="coerce")
    cand = cand[cand.B73v5.isin(lt.index)].copy()
    for c in ("tsd", "motif", "confidence", "nest_status", "family", "ltr5_len", "ltr3_len", "strand"):
        cand[c] = lt.loc[cand.B73v5, c].values
    fam_q = lt.groupby("family")["len"].quantile([0.25, 0.75]).unstack()
    cand = cand[(cand.motif == "tg...ca") & (cand.tsd.str.len() == 5) & (cand.confidence == "high")
                & (cand.nest_status == ".")]
    cand = cand[(cand.len >= fam_q.loc[cand.family, 0.25].values) & (cand.len <= fam_q.loc[cand.family, 0.75].values)]
    cand["score"] = np.abs(np.log((cand.k2p + 1e-3) / (k2p_med + 1e-3))) + np.abs(np.log(cand.len / len_med))
    cand = cand.sort_values("score")
    print(f"absent calls {len(allabs)}; median K2P {k2p_med:.4f}, median length {len_med:.0f}; "
          f"clean empty candidates {len(cand)}", file=sys.stderr)
    el = pd.read_csv(f"{R}/benchmark/results/main3/elements.B73v5.tsv", sep="\t",
                     usecols=["chrom", "start", "end", "name", "in_TIL01", "ortholog_TIL01"])
    checked = []
    for _, r in cand.head(40).iterrows():
        c, s, e = r.chrom, int(r.start), int(r.end)
        seq = faidx(f"{R}/inputs/B73v5.fa", f"{c}:{s - 300}-{e + 300}")
        L, Rr = seq[:300], seq[-300:]
        body = seq[300:-300]
        tsdL, tsdR = L[-5:], Rr[:5]
        ok_struct = (tsdL == tsdR == r.tsd.upper() and body[:2] == "TG" and body[-2:] == "CA"
                     and body[int(r.ltr5_len) - 2:int(r.ltr5_len)] == "CA"
                     and body[len(body) - int(r.ltr3_len):len(body) - int(r.ltr3_len) + 2] == "TG")
        if not ok_struct:
            checked.append((r.B73v5, "structure"))
            continue
        # TIL01 interval between orthologs of the nearest flanking B73 elements
        g = el[(el.chrom == c) & (el.in_TIL01 == "present")]
        up = g[g.end < s].tail(3)
        dn = g[g.start > e].head(3)
        if len(up) == 0 or len(dn) == 0:
            checked.append((r.B73v5, "no flanking orthologs"))
            continue
        och = [x.split(":")[0] for x in pd.concat([up, dn]).ortholog_TIL01]
        if len(set(och)) != 1:
            checked.append((r.B73v5, "flanking orthologs on different TIL01 chromosomes"))
            continue
        co = [list(map(int, x.split(":")[1].split("#")[0].split("-"))) for x in pd.concat([up, dn]).ortholog_TIL01]
        lo, hi = min(min(x) for x in co) - 5000, max(max(x) for x in co) + 5000
        if hi - lo > 600_000:
            checked.append((r.B73v5, f"TIL01 interval too long ({hi - lo})"))
            continue
        reg = faidx(f"{R}/inputs/TIL01.fa", f"{och[0]}:{max(1, lo)}-{hi}")
        empty = L[-150:] + Rr[5:155]          # left flank incl. TSD + right flank after the 2nd TSD
        best = None
        for strand, q in (("+", empty), ("-", rc(empty))):
            a = edlib.align(q, reg, mode="HW", task="path")
            if best is None or a["editDistance"] < best[1]["editDistance"]:
                best = (strand, a)
        strand, a = best
        if a["editDistance"] > 0.05 * len(empty):
            checked.append((r.B73v5, f"empty site not found (edit {a['editDistance']})"))
            continue
        ts, te = a["locations"][0]
        hit = reg[ts:te + 1]
        hit = hit if strand == "+" else rc(hit)
        al = edlib.align(empty, hit, mode="NW", task="path")
        nice = edlib.getNiceAlignment(al, empty, hit)
        # TSD copy count in TIL01: the TSD must appear once at the join
        til_left = nice["target_aligned"][:155].replace("-", "")
        res = dict(element=r.B73v5, chrom=c, start=s, end=e, length=int(r.len), k2p=float(r.k2p),
                   family=r.family, ltr5_len=int(r.ltr5_len), ltr3_len=int(r.ltr3_len), tsd=r.tsd.upper(),
                   strand_elem=r.strand, junction_left=float(r.junction_left), junction_right=float(r.junction_right),
                   empty_site_frac=float(r.empty_site), b73_left=L, b73_right=Rr, b73_body_start=body[:40],
                   b73_body_end=body[-40:], til01_chrom=och[0], til01_region=[int(max(1, lo)), int(hi)],
                   til01_hit_start=int(max(1, lo) + ts), til01_hit_end=int(max(1, lo) + te), til01_strand=strand,
                   til01_hit=hit, empty_allele=empty, edit_distance=int(a["editDistance"]),
                   aln_query=nice["query_aligned"], aln_target=nice["target_aligned"], aln_match=nice["matched_aligned"],
                   k2p_median_absent=float(k2p_med), len_median_absent=float(len_med),
                   rejected_before=checked)
        os.makedirs(OUT, exist_ok=True)
        with open(os.path.join(OUT, "example_absence.json"), "w") as fo:
            json.dump(res, fo, indent=1)
        print(json.dumps({k: v for k, v in res.items() if k not in ("b73_left", "b73_right", "til01_hit",
                                                                   "empty_allele", "aln_query", "aln_target",
                                                                   "aln_match")}, indent=1))
        print(nice["query_aligned"][120:185])
        print(nice["matched_aligned"][120:185])
        print(nice["target_aligned"][120:185])
        return
    print("no candidate passed", checked, file=sys.stderr)
    sys.exit(1)


if __name__ == "__main__":
    main()
