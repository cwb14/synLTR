#!/usr/bin/env python3
"""Rate-free test of 'shared insertion younger than the split' (benchmark).

Both clocks are read in substitutions per LTR site, so the mutation rate cancels:
  - the split: LTR divergence between sister and donor ortholog copies (S-D). Without gene flow every S-D pair
    coalesced before the split, so divergence = s + X with s = 2*mu*T_split and X >= 0 the ancestral coalescence.
    Fitted by maximum likelihood: k ~ Poisson(n (s + X)), X ~ Exponential(mean m) (isolation model; closed form
    via the regularized upper incomplete gamma). Gene flow between S and D adds young pairs and pulls s down, which
    makes the test below conservative.
  - the insertion: LTR-LTR differences d over n sites of the donor copy; one-sided 95% Poisson upper bound
    u95 = chi2.ppf(0.95, 2(d+1)) / 2 / n (same bound as young_shared.py, without the rate).
A donor insertion shared with exactly one sister and with u95 < s is younger than the split: shared only by gene
flow. Counts both sister patterns. Also reports the rate implied by s for published split times."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import argparse
import glob
import sys

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import gammaincc, gammaln
from scipy.stats import chi2

sys.path.insert(0, "/data2/chris/maize_introgression/LTRmix")
import ltrmix  # noqa: E402


def nll(par, k, n):
    s, m = np.exp(par)
    c = 1.0 + 1.0 / (n * m)
    q = gammaincc(k + 1, c * n * s)
    lp = s / m - np.log(m * n) - (k + 1) * np.log(c) + np.log(np.maximum(q, 1e-300))
    return -lp.sum()


def fit(k, n, start=(1e-3, 1e-2)):
    r = minimize(nll, np.log(start), args=(k, n), method="Nelder-Mead", options=dict(xatol=1e-6, fatol=1e-6,
                                                                                     maxiter=4000))
    return np.exp(r.x)


def _lp(k, n, s, m):
    c = 1.0 + 1.0 / (n * m)
    q = gammaincc(k + 1, c * n * s) if s > 0 else 1.0
    return s / m - np.log(m * n) - (k + 1) * np.log(c) + np.log(np.maximum(q, 1e-300))


MG_MAX = 1e-3  # gene-flow component: coalescence after the split, mean divergence <= 0.1%


def _mix_par(par):
    w = np.exp(np.r_[0.0, par[0], par[1]])
    w /= w.sum()                                   # isolation, gene flow, upper tail
    mg = MG_MAX / (1 + np.exp(-par[2]))
    s, m, mh = np.exp(par[3:])
    return w, mg, s, m, mh


def nll_mix(par, k, n):
    w, mg, s, m, mh = _mix_par(par)
    lp = np.stack([np.log(w[0]) + _lp(k, n, s, m), np.log(w[1]) + _lp(k, n, 0.0, mg),
                   np.log(w[2]) + _lp(k, n, 0.0, mh)])
    return -np.logaddexp.reduce(lp, axis=0).sum()


def fit_mix(k, n, s0, m0):
    """Isolation (shifted exponential) + post-split gene flow (unshifted, mean <= MG_MAX) + an unshifted upper-tail
    component (old paralogs, mis-assigned pairs). Several starts; returns weights, gene-flow mean, s, m, nll."""
    best = None
    for fg in (0.005, 0.02, 0.05):
        for sm in (1, 3, 6):
            for mh0 in (0.05, 0.15):
                x0 = [np.log(fg / 0.95), np.log(0.03 / 0.95), 0.0, np.log(max(s0, 1e-5) * sm), np.log(m0),
                      np.log(mh0)]
                r = minimize(nll_mix, x0, args=(k, n), method="Nelder-Mead",
                             options=dict(xatol=1e-7, fatol=1e-7, maxiter=20000))
                if best is None or r.fun < best.fun:
                    best = r
    w, mg, s, m, mh = _mix_par(best.x)
    return w, mg, s, m, mh, best.fun


def pred_cdf(x, n, s, m, nsim=200, rng=None):
    """Predicted fraction of pairs with observed divergence <= x (simulated from the fit at the observed n)."""
    rng = rng or np.random.default_rng(0)
    nn = np.tile(n, nsim)
    kk = rng.poisson(nn * (s + rng.exponential(m, len(nn))))
    return float(np.mean(kk / nn <= x))


def ltr_div(la, lb, names_a, names_b, threads):
    ia = pd.Series(np.arange(la.n), index=la.names)
    ib = pd.Series(np.arange(lb.n), index=lb.names)
    a = ia.reindex(names_a).to_numpy()
    b = ib.reindex(names_b).to_numpy()
    ok = ~(np.isnan(a) | np.isnan(b))
    c = ltrmix.align_pairs(la, lb, a[ok].astype(np.int64), b[ok].astype(np.int64), threads)
    return np.asarray(names_a)[ok], c[:, 3], c[:, 4]


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--res", default="benchmark/results/main3", help="ltrmix output directory")
    ap.add_argument("--donor", default="TIL18=run/TIL18_LTRs", metavar="LABEL=LIB")
    ap.add_argument("--sister", default="TIL01=run/TIL01_LTRs", metavar="LABEL=LIB",
                    help="the less-admixed sister (its pairs with the donor date the split)")
    ap.add_argument("--recipient", default="B73v5=run/B73v5_LTRs", metavar="LABEL=LIB")
    ap.add_argument("--min-sites", type=int, default=200, help="LTR sites per ortholog pair [200]")
    ap.add_argument("--boot", type=int, default=200, help="block-bootstrap replicates for s [200]")
    ap.add_argument("--split-yr", default="30000,60000", help="published split times for the implied rate")
    ap.add_argument("-t", "--threads", type=int, default=8)
    ap.add_argument("--out", default="benchmark/analysis/rate_free_split.tsv")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args()
    ltrmix.ARGS_THREADS[0] = a.threads
    (D, dsp), (S, ssp), (R, rsp) = (x.split("=", 1) for x in (a.donor, a.sister, a.recipient))
    ld, ls, lr = (ltrmix.load_library(l, p) for l, p in ((D, dsp), (S, ssp), (R, rsp)))
    od_s = pd.read_csv(f"{a.res}/orthologs.{D}.{S}.tsv.gz", sep="\t")
    od_r = pd.read_csv(f"{a.res}/orthologs.{D}.{R}.tsv.gz", sep="\t")
    rows = []
    fits = {}
    for lab, od, lo in ((f"{S}-{D}", od_s, ls), (f"{R}-{D}", od_r, lr)):
        p = od[od.iloc[:, 5] == "present"]
        nm, n, k = ltr_div(ld, lo, p.iloc[:, 0].to_numpy(), p.iloc[:, 6].to_numpy(), a.threads)
        keep = n >= a.min_sites
        nm, n, k = nm[keep], n[keep].astype(float), k[keep].astype(float)
        s, m = fit(k, n)
        fits[lab] = (nm, n, k, s, m)
        print(f"{lab}: {len(n):,} ortholog pairs with >= {a.min_sites} LTR sites; median LTR divergence "
              f"{np.median(k / n):.5f}; isolation-model fit s = {s:.5f}, mean ancestral excess m = {m:.5f}")
    # block bootstrap of s on the sister-donor pairs (5-Mb blocks of the donor)
    nm, n, k, s, m = fits[f"{S}-{D}"]
    pos = od_s.set_index(od_s.columns[0]).loc[nm]
    blk = (pos.iloc[:, 0].astype(str) + ":" + (((pos.iloc[:, 1] + pos.iloc[:, 2]) // 2) // 5_000_000).astype(str)).to_numpy()
    ub, inv = np.unique(blk, return_inverse=True)
    rng = np.random.default_rng(1)
    bs = []
    for _ in range(a.boot):
        pick = rng.integers(len(ub), size=len(ub))
        idx = np.concatenate([np.where(inv == j)[0] for j in pick])
        bs.append(fit(k[idx], n[idx], (s, m))[0])
    lo95, hi95 = np.quantile(bs, [0.025, 0.975])
    print(f"s (split, substitutions per LTR site) = {s:.5f}, 95% block bootstrap {lo95:.5f}-{hi95:.5f} "
          f"({len(ub)} blocks, {a.boot} replicates)")
    # fit check in the lower tail, where s is decided
    for x in (0.0, 0.001, 0.002, 0.003, 0.005):
        print(f"  pairs with divergence <= {x:.3f}: observed {np.mean(k / n <= x):.4f}, "
              f"fitted {pred_cdf(x, n, s, m):.4f}")
    # sensitivity: post-split gene flow between sister and donor pulls the isolation-model shift down
    w_, mg_, s_mix, m_, mh_, nl_mix = fit_mix(k, n, s, m)
    nl_iso = nll(np.log([s, m]), k, n)
    print(f"isolation + gene flow + upper tail: weights {w_[0]:.3f}/{w_[1]:.4f}/{w_[2]:.3f}, gene-flow mean "
          f"{mg_:.5f}, s = {s_mix:.5f}, m = {m_:.5f}, tail mean {mh_:.4f}; AIC {2 * nl_mix + 12:.1f} vs isolation "
          f"{2 * nl_iso + 4:.1f}")
    nr, n_r, k_r, _, _ = fits[f"{R}-{D}"]
    print(f"fraction of ortholog pairs below s: {R}-{D} {np.mean(k_r / n_r < s):.4f}, {S}-{D} {np.mean(k / n < s):.4f}")
    # insertions shared with one sister, dated by the donor copy's own LTRs
    t = pd.concat([pd.read_csv(f, sep="\t", usecols=["#seq_id", "n_sites", "n_ts", "n_tv"])
                   for f in sorted(glob.glob(dsp + "_depth*_clean_ltr.tsv"))])
    t = t.rename(columns={"#seq_id": "name"}).drop_duplicates("name").set_index("name")
    st = pd.DataFrame({"inR": od_r.set_index(od_r.columns[0]).iloc[:, 4],
                       "inS": od_s.set_index(od_s.columns[0]).iloc[:, 4]}).join(t, how="inner")
    d = (st.n_ts + st.n_tv).astype(float)
    st["u95"] = chi2.ppf(0.95, 2 * (d + 1)) / 2 / st.n_sites.clip(lower=1)
    pats = {f"{R}+{D}": (st.inR == "present") & (st.inS == "absent"),
            f"{S}+{D}": (st.inS == "present") & (st.inR == "absent")}
    print(f"identical LTRs: median {st.n_sites[d == 0].median():.0f} sites, u95 {3.0 / st.n_sites[d == 0].median():.5f}; "
          f"identical LTR sites needed for u95 < s: {3.0 / s:,.0f}")
    for lab, thr in (("s point", s), ("s lower 95%", lo95), ("s upper 95%", hi95), ("s gene-flow mixture", s_mix),
                     ("rate-based 30 kyr at 3e-8", 2 * 3e-8 * 30000)):
        A, B = int((pats[f"{R}+{D}"] & (st.u95 < thr)).sum()), int((pats[f"{S}+{D}"] & (st.u95 < thr)).sum())
        Dv = (A - B) / (A + B) if A + B else np.nan
        print(f"insertions younger than the split ({lab}, u95 < {thr:.5f}): {R}+{D} {A}, {S}+{D} {B}; D = {Dv:+.2f}")
        rows.append(dict(threshold=lab, s=thr, **{f"{R}+{D}": A, f"{S}+{D}": B}, D=Dv))
    for T in [float(x) for x in a.split_yr.split(",")]:
        print(f"implied rate if the split is {T / 1e3:.0f} kyr: {s / (2 * T):.2e} per site per year "
              f"(bootstrap {lo95 / (2 * T):.2e}-{hi95 / (2 * T):.2e})")
    out = pd.DataFrame(rows)
    out.attrs = {}
    os_ = _os.path.dirname(a.out)
    if os_:
        _os.makedirs(os_, exist_ok=True)
    out.to_csv(a.out, sep="\t", index=False)


if __name__ == "__main__":
    main()
