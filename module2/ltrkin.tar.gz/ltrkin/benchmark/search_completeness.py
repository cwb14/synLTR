#!/usr/bin/env python3
"""Is ltrkin's nearest fixed copy the true nearest? Exhaustive check on real data.

For a random sample of new copies (from <prefix>.sources.tsv), align the copy's own internal region (nested
elements excised, as ltrkin does) to the internal region of EVERY fixed copy of the same family (mappy asm5, cs),
compute the per-base divergence like minimap2's de (mismatches + indel events over aligned columns), and compare
the exhaustive minimum with ltrkin's assigned divergence.
Usage: search_completeness.py -r ref.fa -a ann.gff3 -p ltrkin_source_prefix [-n 100] [-o out.tsv]
"""
import argparse
import random

import mappy
import numpy as np
import pandas as pd
import pysam

from ltrkin.annot import read_gff3
from ltrkin.source import own_internal, nested_pair, _cs_ops
from ltrkin.constants import MIN_ALN, MIN_COV, MIN_COV_LONG


def de(hit):
    sub = ind = 0
    for op, v in _cs_ops(hit.cs):
        if op == "*":
            sub += 1
        elif op in "+-":
            ind += 1
    cols = hit.blen
    return (sub + ind) / cols if cols else np.nan


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-r", "--reference", required=True)
    ap.add_argument("-a", "--annotation", required=True)
    ap.add_argument("-p", "--prefix", required=True)
    ap.add_argument("-n", type=int, default=100)
    ap.add_argument("-o", "--out", default=None)
    a = ap.parse_args()
    fa = pysam.FastaFile(a.reference)
    els = {e.id: e for e in read_gff3(a.annotation)}
    cp = pd.read_csv(f"{a.prefix}.copies.tsv", sep="\t", dtype={"element_id": str}).set_index("element_id")
    src = pd.read_csv(f"{a.prefix}.sources.tsv", sep="\t", dtype={"new_id": str, "source_id": str})
    best = src.groupby("new_id").divergence.min()
    fixed = cp[cp.status == "fixed"]
    rng = random.Random(3)
    sample = rng.sample(sorted(best.index), min(a.n, len(best)))
    rows = []
    for n in sample:
        e = els[n]
        q = own_internal(fa, e)
        fam = cp.at[n, "family"]
        pool = fixed[fixed.family == fam].index if fam != "." else fixed.index
        dmin, tmin = np.inf, None
        for t in pool:
            te = els[t]
            if nested_pair(e, te):
                continue
            ts = own_internal(fa, te)
            h = next(iter(mappy.Aligner(seq=ts, preset="asm5", best_n=1).map(q, cs=True)), None)
            if h is None:
                continue
            al = min(h.q_en - h.q_st, h.r_en - h.r_st)
            if h.blen < MIN_ALN or al / min(len(q), len(ts)) < MIN_COV or al / max(len(q), len(ts)) < MIN_COV_LONG:
                continue
            d = de(h)
            if d < dmin:
                dmin, tmin = d, t
        # same metric for ltrkin's chosen source(s): differences (substitutions + indel events) in the mappy alignment
        lt_diffs = []
        for t in src[src.new_id == n].source_id:
            h = next(iter(mappy.Aligner(seq=own_internal(fa, els[t]), preset="asm5", best_n=1).map(q, cs=True)), None)
            if h is not None:
                lt_diffs.append(de(h) * h.blen)
        ex_h = next(iter(mappy.Aligner(seq=own_internal(fa, els[tmin]), preset="asm5", best_n=1).map(q, cs=True)), None) if tmin else None
        rows.append(dict(new_id=n, family=fam, n_fixed_in_family=len(pool), ltrkin_div=best[n], exhaustive_div=dmin,
                         ltrkin_diffs_same_metric=min(lt_diffs) if lt_diffs else np.nan,
                         exhaustive_diffs=de(ex_h) * ex_h.blen if ex_h else np.nan,
                         exhaustive_best=tmin, ltrkin_sources=",".join(src[src.new_id == n].source_id)))
    d = pd.DataFrame(rows)
    d["missed_closer"] = d.exhaustive_diffs <= d.ltrkin_diffs_same_metric - 1   # >= 1 fewer difference, same metric
    print(f"sampled {len(d)} new copies; exhaustive nearest strictly closer than ltrkin's: {int(d.missed_closer.sum())} "
          f"({d.missed_closer.mean():.3f}); exhaustive best among ltrkin's tied sources: "
          f"{np.mean([b in s.split(',') for b, s in zip(d.exhaustive_best, d.ltrkin_sources)]):.3f}")
    print(f"median |ltrkin - exhaustive| divergence (minimap2 de vs recomputed): {np.median(np.abs(d.ltrkin_div - d.exhaustive_div)):.5f}")
    x = d[d.missed_closer]
    if len(x):
        print(f"missed cases: fewer differences by median {np.median(x.ltrkin_diffs_same_metric - x.exhaustive_diffs):.1f} "
              f"(ltrkin {np.median(x.ltrkin_diffs_same_metric):.0f} vs exhaustive {np.median(x.exhaustive_diffs):.0f})")
    if a.out:
        d.to_csv(a.out, sep="\t", index=False)


if __name__ == "__main__":
    main()
