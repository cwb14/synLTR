# Task 24 phase A report: bake-off setup and launch

Status: see the last section. All files are under `/data2/chris/maize_introgression/benchmark_pav/bakeoff/` (D). No
repo file was changed.

## What I built (one line per file)

- `PARAMS.md`: parameter interrogation (minimap2/mappy, FastGA, BLAST, LASTZ, WFA, AnchorWave). Also the engine
  constants with a keep/flag verdict, the carry-forward answers, the declared variants, the wrapper patches and
  the measurement method. Written before any run; patch 9.5 (chunk size) was added after the first smoke run.
- `backends.py`: window backends `lastz` and `wfa`, registered with `register_backend`; AlnMaps built with
  `alnmap_from_hits`; per-window guard (empty AlnMap -> U, plus one `bakeoff-guard` log line).
- `backend_check.py` -> `backend_check.log`: toy check of P/E/D (plus all 21 toy cases, informational).
- `01_sim.sh`: the 6 sims (R1/R2/R3 x seeds 1, 2; Task 22 defaults), run in parallel; markers `sims/sims.done`
  and `sims/sims.exit`.
- `bakeoff.py`: the variant table, the measured run (`/usr/bin/time -v` + `timeout --kill-after=60s` + 2-s
  process-tree RSS/PSS sampling) -> `status.json` (wall, CPU, max RSS, tree peaks, guard/error line counts,
  bakeoff-flanks lines, calls files, timeout progress per pair), and the runs table.
- `run_variant.py`: in-process wrapper. It sets `cli.BACKEND`, the flank cap (`flanks.FLANK_CAP` plus the
  route's `cap` via a wrapped `cli.get_route`), `mm2.MAPPY_BEST_N` and `genotype.CHUNK_WINDOWS`. It logs one
  `bakeoff-flanks` line per `flank_pieces` call and writes `variant.json`.
- `02_run_sims.py`: sims batch (6 sims x 13 variants, 32 threads, `timeout 30m` each). Resumable: a run with
  `status.json` is skipped, an interrupted run is deleted and rerun whole. Writes `runs/runs.tsv`,
  `runs/batch.done` and `runs/batch.exit`.
- `chr10_inputs.py`: chr10 FASTAs (`samtools faidx`, seqids kept), LTRquest tables filtered with the loader's own
  seq_id regex, the element-set check, the sample sheets and `chr10/inputs.done`.
- `04_chr10.sh`: chr10 batch: inputs, read-out, `paf:` run, mm2, mm2_lastz/mm2_wfa (`--pair B73v5,TIL18` on
  copied mm2 anchors), 8 more routes, element-file `cmp`, then mm2 at 64 threads after the sims batch. Writes
  `chr10/runs.tsv`, `chr10/batch.done` and `chr10/batch.exit`.
- `06_anchorwave_readout.py`: streams the MAF block by block into a PAF (`cg:Z:` =/X) and gap-free segments,
  then per direction read_paf -> chain/net -> make_windows -> per-window AlnMap from the MAF segments ->
  `classify_window` -> `call_row` (mirrors `_Genotyper.rows`).
- `memo_bakeoff.md`: CLAUDE.md memo (env, inputs, commands, PIDs, markers, gotchas).

## PARAMS.md decisions in brief

- **minimap2/mappy:** asm20 for anchoring; windows take the preset from the pair's d (PRESET_CUTS, kept). mappy
  cannot set `-p`, `-U`, `-f`, `-z` or `-g` (probed: rejected keywords), so they stay at the preset values. Probe:
  minimap2 2.31's asm presets set **-N 50**; the engine forces `MAPPY_BEST_N = 5`. Its comment ("minimap2's
  default -N") is true only of the generic default. Carry-forward answer: 2%-divergent rivals pass `-p 0.8`
  (score ratio ~0.90), but `-N` caps secondaries **per query**. Flank pieces keep their best rival; mm2's 120-kb
  chunks keep only 5 secondaries per chunk. Rivals at 0.5-0.8 of a hit's score are never reported, although
  MARGIN_HIGH = 0.5 would count them. Both effects can only overstate the margin. Declared sensitivity variant
  **mm2_N50** (anchoring best_n 50; windows keep 5) enters the winner rule as its own candidate. Chunk overlap:
  +20% mapping work, kept. Strand-split windows: two map passes per window, measured in the logs.
- **FastGA:** all defaults kept (-f 10, -c 85, -s 1000, -l 100 = ANCHOR_MIN, -i 0.7). No soft masks: the FASTAs
  are all uppercase, checked on 2 Mb of each chr10.
- **BLAST:** megablast (word 28), DUST on, evalue 1e-20, max_target_seqs 50 (first N subjects found, not the
  best N; moot on a one-sequence sim/chr10 database, flagged for whole genomes with scaffolds), max_hsps 20.
- **LASTZ:** plain `lastz` (windows <= 500 kb). Scoring is the pair's preset scoring, not HOXD70: asm20
  `--match=1,4 --gap=6,2`. HOXD70 aligns 70-80% paralogous TE copies; under 1/4 scoring an alignment scores
  >= 0 only above 80% identity, Wicker's rule. Other settings: `--ydrop` = the cost of an 80-bp gap (166), so
  TE-sized indels split hits; `--gappedthresh=80` (MIN_SEG); `--step=1`; 12of19 seed with transitions;
  `--chain` on the plus strand only (the minus strand stays unchained so every inverted hit reaches `inv`);
  `--ambiguous=iupac`.
- **WFA:** pywfa gap-affine-2p, end-to-end over the whole window, BiWFA memory, exact (no heuristic). Penalties
  are the preset's scoring converted to match 0 (asm20: 10/12/5/52/3). Guard: `max_steps` = 2 x (o2 + 30 kb x e2)
  = 180,104 for asm20 (an O site at the design's largest element). Windows that reach it give U plus a guard line
  (about 40 s each). Probe timings: 10-kb indel 1.3 s, 30 kb 10.5 s, 100 kb 114 s.
- **AnchorWave:** `-IV`, `-t 8` (finished, read-only). **MAF used: `anchorwave.maf` (`-o`).** The manual calls it
  the end-to-end alignment of the whole chromosome, and its conversion examples read it. Checked: `-o` and `-f`
  hold the same alignment (151,357,043 / 143,611,282 bases, the same 6,898,036 inverted TIL18 bases). `-o` has 5
  blocks (3 forward, 2 inversions: B73 123.1-124.4 and 126.3-131.9 Mb) with disjoint, increasing intervals on
  both genomes, i.e. one-to-one and collinear. `-f` is the same alignment cut into 6,736 blocks at gene anchors.
- **Wrapper patches** (PARAMS.md 9): backend; flank cap (`FLANK_CAP` alone has **no effect**: the route classes
  bind `cap=FLANK_CAP` as a default at import, so the wrapper sets `route.cap` through `cli.get_route`); mm2
  best_n; **CHUNK_WINDOWS = 8** in every run. With the default 2,000, a chr10 direction gets only ~4 workers (a sim
  1), while a whole genome fills 32. The calls are identical whatever the chunking, so chr10 is measured at
  whole-genome parallelism.
- **Measurement:** GNU time's max RSS is the largest single process, so the harness also records summed tree
  RSS/PSS (mem.tsv, status.json). Each run sets `OMP_NUM_THREADS` to its thread count (this shell exports 8) and
  `TMPDIR` under D (the root filesystem is 96% full).

## Toy-check results (backend_check.log; seeds 7, 0, 4, 6, 9, 11, 14 = the engine's classifier test seeds)

Required P, E, D_left and D_both (3-kb flanks) plus P and E (500-bp window-sized flanks): **PASS**, 7/7 seeds for
lastz and for wfa. Informational, all 21 toy cases:

| backend | correct (whole) | misses |
|---|---|---|
| mappy | 21/21 cases x 7 seeds | none |
| lastz | 21/21 x 7 | none |
| wfa | 18/21 x 7 | O, U_flank, inv_site called T on every seed |

The wfa misses are a property of whole-window global alignment, not a backend bug. On toy O, WFA aligns B's
unrelated 2-kb insertion against the element as 161 short segments at 66% identity, so the element looks partly
aligned (1,812/4,800 bp), which gives T. A global alignment also has no inverted hits, so inv_site is impossible.
Expect wfa to lose O recall and T precision on the sims. Stress test on a 400-kb window with a 12-kb element and 8
TE-like repeats: all three backends gave the same 2 segments (mappy 0.1 s, lastz 0.7 s, wfa 10.5 s); LASTZ's
default traceback space was enough.

## Sim summaries (truth counts; ltrpav-sim log)

| sim | backbone | A bp / B bp | A in B: P S T E D O G | B in A: P S T E D O G |
|---|---|---|---|---|
| R1_s1 | chr10:2-8 Mb | 8.24 / 8.09 Mb | 246 25 16 132 85 23 13 | 253 32 20 134 58 22 10 |
| R1_s2 | chr10:2-8 Mb | 8.31 / 8.30 | 264 31 22 144 75 23 6 | 259 30 15 141 64 20 16 |
| R2_s1 | chr10:48-54 Mb (CentC) | 8.07 / 8.21 | 338 26 12 140 59 19 18 | 339 24 19 135 67 20 12 |
| R2_s2 | chr10:48-54 Mb | 8.06 / 8.28 | 310 31 21 137 69 20 14 | 312 31 20 130 84 20 16 |
| R3_s1 | chr10:140-146 Mb | 8.19 / 8.26 | 250 24 23 137 72 24 13 | 256 30 18 142 60 20 7 |
| R3_s2 | chr10:140-146 Mb | 8.40 / 8.17 | 267 29 20 141 69 20 10 | 261 29 17 142 52 21 13 |

Backbone elements: 323 (R1), 401 (R2), 317 (R3); about 2,000 donors each; about 50 s per sim.

## chr10 inputs (chr10/inputs_check.tsv)

| genome | chr10 bp | whole-genome load | of which chr10 | chr10 load (top-level) | identical |
|---|---|---|---|---|---|
| B73v5 | 152,435,371 | 127,636 | 9,064 | 9,064 (6,516) | yes, every field |
| TIL18 | 144,562,906 | 124,641 | 8,319 | 8,319 (6,040) | yes |
| TIL01 | 157,537,249 | 137,847 | 9,304 | 9,304 (6,685) | yes |

B73v5_chr10 and TIL18_chr10 equal AnchorWave's renamed FASTAs (sequence sha256).

## What is running (state at 05:45, 2026-11-11)

Thread budget: sims 32 + chr10 32 = 64. The 64-thread run waits until the sims batch has ended.

**1. Sims batch.**
- Command: `setsid -f nohup env NUMPY_MADVISE_HUGEPAGE=0 .../ltrpav_bench/bin/python D/02_run_sims.py >
  D/runs/batch.log 2>&1 < /dev/null`. 78 runs (6 sims x 13 variants), 32 threads, `timeout 30m` each.
- PID verification:
  ```
  pgrep -af: 3523920 /home/chris/bin/mambaforge/envs/ltrpav_bench/bin/python .../bakeoff/02_run_sims.py
  ps -o pid,ppid,sid,etime,cmd: 3523920  1  3523920  16:45  .../python .../bakeoff/02_run_sims.py
  ```
- Log: `D/runs/batch.log`. Table: `D/runs/runs.tsv`. Per run: `D/runs/<sim>/<variant>/` (status.json, run.log,
  time.txt, mem.tsv, variant.json, the ltrpav outputs).
- Done marker: `D/runs/batch.done`; exit status: `D/runs/batch.exit`.
- Expected: about 07:10 (later if R2's centromeric windows slow wfa). Estimate: R1_s1's 13 variants took ~17 min
  (the two wfa runs 5-6.5 min, the four FastGA-based runs ~75 s each, the rest 4-40 s), times 6 sims.
- Progress: 19/78 finished, all ok, 0 errors.

**2. chr10 batch.**
- Command: `setsid -f nohup bash D/04_chr10.sh > D/chr10/batch.log 2>&1 < /dev/null`. Its steps are in the
  script header.
- PID verification:
  ```
  pgrep -af: 662846 bash .../bakeoff/04_chr10.sh
  ps -o pid,ppid,sid,etime,cmd: 662846  1  662846  07:08  bash .../bakeoff/04_chr10.sh
  ```
- Log: `D/chr10/batch.log`. Table: `D/chr10/runs.tsv` (written at the end; `python bakeoff.py table --root
  chr10/runs --out chr10/runs.tsv` any time). Per run: `D/chr10/runs/<variant>/`.
- Done marker: `D/chr10/batch.done`; exit status: `D/chr10/batch.exit`.
- Now running: mm2_wfa (B73v5 -> TIL18; `timeout 45m`, started 05:41:31). At 05:45 it was at 121/709 chunks
  (~34 chunks/min) with 58 guarded windows, PSS 9.6 GB. Expected about 06:05; its timeout falls at 06:26 and would
  be recorded with progress.
- Then fastga, flank-mm2 at 2/5/10/20 kb, flank-blast_10k, hybrid and mm2_N50 (each `timeout 2h`). Estimate
  ~5-15 min each, from mm2's 5.9 min for the 3 genomes plus FastGA's fixed cost and BLAST, so about 07:15. Then
  the element-file `cmp`, a wait for `runs/batch.exit`, mm2 at 64 threads (~5 min) and the table.
- Expected done: about 07:20-07:40.

Check:
```
cd /data2/chris/maize_introgression/benchmark_pav/bakeoff
cat runs/batch.exit chr10/batch.exit; ls runs/batch.done chr10/batch.done
tail -3 runs/batch.log chr10/batch.log; pgrep -af 'bakeoff/(02_run_sims.py|04_chr10.sh)'
```
A failed or timed-out run has `status` failed/timeout in its status.json. A timeout's `progress` field gives
windows and chunks done/total per pair. A pair absent from it was still anchoring.

## What finished

- Toy check: PASS (above). 01_sim.sh: 6 sims, `sims/sims.done`.
- chr10 inputs: `chr10/inputs.done`, identical element sets.
- **Read-out** (`chr10/anchorwave_readout/`, 17.7 s, 0.5 GB; `readout.done`).
  - MAF streamed into `chr10/awpaf/B73v5__TIL18.paf` (5 records, =/X CIGARs, 6.8 MB) and `segments.npz` (168,440
    segments): 58,032,162 aligned columns at 0.975 identity. The other ~93 Mb of B73 and ~86 Mb of TIL18 sit in
    gap columns (non-shared sequence).
  - Every block's first and last 1,000 bases match the FASTAs on both genomes.
  - B73v5 -> TIL18: 3,771 windows (3,560 anchored); 9,064 calls: 2,217 P, 106 S, 622 T, 1,621 E, 1,914 D,
    2,132 O, 3 G, 449 U.
  - TIL18 -> B73v5 (the symmetric swap): 3,584 windows (3,311 anchored); 8,319 calls: 2,193 P, 94 S, 601 T,
    1,419 E, 1,519 D, 1,954 O, 7 G, 532 U.
  - Validation (scratch script, not a deliverable): over 120 windows per direction, half on strand -1 (inside
    the inversions), the MAF-segment AlnMaps and mappy's realignment place sampled A bases at the same B position
    (+-3 bp) in 97.9-99.96% of bases on both strands. Call agreement is 62-70%, mostly MAF O/D against mappy U;
    no P/E contradictions.
- **`paf:` run** (AnchorWave anchors, mappy windows; yardstick, not a candidate), `chr10/runs/awpaf`: 18.6 s.
  - B73v5 -> TIL18: 2,057 P, 86 S, 580 T, 1,392 E, 1,410 D, 1,362 O, 3 G, 2,174 U.
  - TIL18 -> B73v5: 2,045 P, 1,932 U.
- **chr10 mm2:** 352.8 s wall, 13.4 GB max single-process RSS, 19.0 GB peak tree PSS (80.5 GB summed RSS
  double-counts forked pages). Mapping 150 Mb onto a 145-Mb index took 72-88 s per unordered pair at 32 threads.
- **chr10 mm2_lastz** (B73v5 -> TIL18, mm2 anchors reused: "anchors done, skip"): 21.0 s.
- **Sims R1_s1**, all 13 variants ok, 0 error lines, 2 calls files each.
  - Wall: mm2 4.2 s, fastga 73.9, flank-mm2 3.5-4.5, flank-blast 38.3, hybrid 77.0, mm2_N50 4.2, mm2_lastz 7.0,
    mm2_wfa 313.6 (13 guarded windows), fastga_lastz 77.2, fastga_wfa 383.5 (21 guarded).
  - Patches verified: `bakeoff-flanks` max reach = cap at 2,000/5,000/10,000/20,000 bp. mm2_lastz and mm2_wfa have
    windows byte-identical to mm2 but 23 and 88 state differences (the backend took effect in the forked
    workers). mm2_N50 changes the anchors (616 vs 568 raw blocks).
- Smoke check: R1_s1/mm2's calls parse (header = CALL_COLUMNS, every element exactly once, valid states and
  tiers). No scoring was done.

## Concerns

1. **mm2 on real chr10 leaves 37-49% of calls U, mostly `breakpoint` windows.** B73v5 -> TIL18 has 5,671
   windows, of which 3,013 anchored, 2,054 breakpoint and 604 span_cap; that is 4,295 U of 9,064 calls (2,890
   breakpoint, 857 span_cap). AnchorWave's collinear anchors give 42 breakpoint windows for the same elements. The
   1:1 net seems to admit paralogous chains interleaved with the orthologous ones, so the nearest anchors of an
   element disagree. The 6-Mb sims may not reproduce this, so phase B should weigh real-data resolved_frac and
   inspect it. Engine behavior; not touched.
2. **FastGA's netted anchors are ~3x as divergent as mm2's on the sims** (R1_s1: d = 0.051-0.056 vs 0.018; 7.3
   vs 5.6 Mb of A anchored; 44,788 vs 568 raw blocks; true A-B divergence ~1.2%). Its `-i 0.7` alignments of
   paralogous TE copies reach the net. Watch FastGA's and hybrid's high-tier precision. FastGA also has a ~70-s
   fixed cost even on 8-Mb sims.
3. **wfa is a global aligner.** It misreads toy O, U_flank and inv_site as T (unrelated sequence aligned as short
   low-identity segments; no inverted hits). Expect lower O recall and T precision. Windows over its penalty cap
   become U (each costs ~40-60 s first; counted in status.json `guard_lines`). The chr10 wfa run may still hit its
   45-min timeout; that would be recorded with progress per ruling 10.
4. **`MAPPY_BEST_N = 5` and its comment.** minimap2 2.31's asm presets set -N 50, and the per-chunk cap hides
   rivals for the mm2 route's margin. mm2_N50 measures the effect. The comment ("minimap2's default -N") should
   name the generic default (repo change for review, not made).
5. **Engine chunking under-parallelizes chromosome-sized inputs.** With CHUNK_WINDOWS = 2,000 a chr10 direction
   gets ceil(windows/2,000) = 3-4 workers and a sim 1, while a whole genome fills 32. All bake-off runs use 8
   windows per chunk (declared, PARAMS.md 9.5; calls unchanged). Phase B should extrapolate per stage: anchoring
   scales with length, and genotyping is CPU time / 32 at whole-genome scale. The default leaves the last round
   part-idle, a small optimistic bias. A chunk size of about windows/threads would be a possible engine
   improvement.
6. **Use peak tree PSS for the 250-GB bar.** GNU time's max RSS is the largest single process, and summed tree RSS
   double-counts the forked workers' shared pages (chr10 mm2: 80.5 GB summed RSS vs 19.0 GB PSS).
7. **AnchorWave read-out composition.** 62% of B73 chr10 sits in gap columns, so the read-out calls many D (21%)
   and O (24%). The comparison with routes should separate P/E agreement from the missing states. The read-out
   imports private `ltrpav.genotype` helpers (`_index`, `_in_no_window`, `_no_window_line`, `_line`, `_sort_key`,
   `_window_line`, `_write_tsv`) to match the engine's files exactly; this ties it to HEAD bfeeb55.
8. **Process disclosure.** One smoke run (mm2 on R1_s1) ran before PARAMS.md 9.5 (chunk size) existed. It was
   deleted and rerun by the batch; no other run preceded PARAMS.md. The hybrid route's primary is FastGA, because
   FastGA is on PATH (`get_route`). The `paf:` run's row has variant "." and route `paf:.../chr10/awpaf` in
   chr10/runs.tsv.
9. **BLAST `-max_target_seqs 50`** is moot on one-sequence databases (sims, chr10) but could drop rivals on
   scaffold-rich whole genomes (PARAMS.md section 3).

Status: DONE_WITH_CONCERNS. Every phase A deliverable is built, run or launched. The concerns are findings and
caveats for phase B, not blockers.

## Fix round 1 (2026-11-11 07:13-07:40; task-24a-fix1.md, the coordinator's messages and addendum)

**Context.** I started once both batches had ended and no `run_variant.py`, `02_run_sims.py` or `04_chr10.sh`
process was live: `runs/batch.exit` = 0 (78/78 ok), and `chr10/batch.exit` holds the controller's stop note
(left untouched).
- No batch or run was launched, and no repo file was touched.
- No probe imported ltrpav (item 11). The probe asserts `ltrpav` never entered `sys.modules`, and dummy commands
  stand in for runs. Probes and logs:
  `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/fix1/`
  (`probe_fix1.py` -> `probe_fix1.log`, 25/25 PASS; `trace/` for the run order).
- No run was re-measured: item 8 says the whole bake-off reruns after Task 24F, and the coordinator said not to
  launch runs.
- Checks: `bash -n` passes on 01_sim.sh and 04_chr10.sh, and `py_compile` on all 7 Python scripts.

| Fix | Change | Probe result |
|---|---|---|
| I1 | `bakeoff.run_measured` and `measure` always start from an empty run dir. `check_rundir` resolves the path and refuses anything not strictly inside `runs/` or `chr10/runs/` (`RUN_ROOTS`). `--skip-done` skips a run with `status.json`; otherwise the dir is deleted. `--seed REL=FILE` re-adds files after the cleanup; 04 seeds the mm2 anchors of mm2_lastz and mm2_wfa this way (its manual `rm -rf`/`cp` is gone). 04 also clears `chr10/anchorwave_readout/` before rerunning the read-out. | PASS (6 checks): a dir without `status.json` is emptied (leftover and stale anchor gone, seed copied in); an outside dir, the root itself and a `..` escape are refused with nothing deleted; the CLI refuses with exit 2 before running anything; `--skip-done` leaves a finished run untouched. |
| M1 | `classify`: ok on exit 0; timeout on 124, or on 137 with wall >= limit; killed on any other signal death (exit > 128, a negative return code, or GNU time's "Command terminated by signal"); else failed. `status.json` also records `signal` and `harness_wall_s`. | PASS (6): `true` ok; `exit 3` failed; SIGKILL after 1 s with a 30-min limit killed (exit 137, signal 9); SIGTERM killed (143); `sleep 30` with a 2-s limit timeout (124); TERM ignored with kill-after 1 s timeout (137, wall 3.0 s >= 2 s). |
| M2 | Both drivers delete their own `batch.done` and `batch.exit` at start. They refuse (exit 1, with a message listing the processes) while a measured run writes under their own root or another copy of the driver lives (`bakeoff.py idle`, `live_runs`). Before the 64-thread run, 04 also waits until no measured run is live anywhere. | PASS (8): stale markers cleared (02 dry run; 04 with `BAKEOFF_CHR10` set to a scratch dir and `BAKEOFF_DRY_RUN=1`); both refuse while a dummy `run_variant.py --outdir <their root>/...` lives; a relative `--outdir` resolves against the run's own cwd; a run under the other root blocks neither; `idle` (no root) is busy while any run lives and idle afterwards. |
| M3 | `--sims` takes only the six sim names. The only `rmtree` left is the guarded `fresh_rundir`. | PASS (3): `../evil`, `/tmp/evil` and `R9_s9` are refused by argparse (exit 2). |
| M5 | PARAMS.md corrections. §4: `--ydrop` default under this scoring is Y = 40 (`lastz --match=1,4 --gap=6,2 --show=defaults`, re-checked; "606" was wrong). §10: sampling every 2 s. §9.5 rewritten: about 1.5-1.7x on the genotype stage under the 2,000-window default; the controller's adaptive-chunking ruling, so the shipped default is close to what was measured; the patch is removed. | LASTZ re-probe: Y=40 under both `--help=defaults` and `--show=defaults`. |
| M8 | The runs tables get a `role` column (candidate or yardstick). The AnchorWave-anchors run is named `awpaf_yardstick`: new runs pass `--yardstick awpaf_yardstick` (rundir `chr10/runs/awpaf_yardstick`), and the phase-A run (variant ".", route `paf:`) is shown under that name by the table code. Its directory was not touched or rerun. `chr10/runs.tsv` was regenerated. | PASS: the table probe gives awpaf_yardstick/yardstick and mm2/candidate. `chr10/runs.tsv` now lists mm2, mm2_lastz and mm2_wfa as candidates and awpaf_yardstick as yardstick (the stopped fastga has no status.json). |
| M9 | `Segments.hits` refuses a window whose A or B seqid is not the MAF's (per direction). The PAF/segments cache stamp adds the MAF's sha256 and the script's sha256. Also, the read-out now takes its windows from the engine's own `anchor_pair` with `PafRoute`, using samples from `read_samples` and the same `make_windows` call. It thus mirrors the `paf:` route exactly after Task 24F's net change, instead of calling `chain_blocks`/`net_blocks` itself. | No runtime probe is possible (the script imports ltrpav). Static check against the current working tree (read-only AST parse): all 25 imported `ltrpav` names resolve, and the signatures it calls match (`anchor_pair(ctx, route)`, the `PairContext` fields, `PafRoute(dirpath)`, `make_windows`, `read_samples(path)`, `classify_window`). The changed script checksum invalidates the old cache, so the rerun regenerates the PAF (about 10 s). |
| M4, M7 | Noted in `memo_bakeoff.md` ("phase A outcome"): the sims' `status.json` files carry no `progress` field, and R1_s1/flank-mm2_2k was measured by hand. | n/a (no re-measure) |
| M6 | Not fixed, per the controller's ruling. PARAMS §10 states that phase B judges memory on max(max_rss_kb, peak_tree_pss_kb) from the chr10 runs, and gives the sims' tree peaks no weight. | n/a |
| 10 | The chunk-size patch is removed from `run_variant.py` (option, import and record) and from `bakeoff.wrapper_cmd`, so the reruns measure the engine's adaptive default. `progress()` no longer assumes a chunk size: windows done are counted as the distinct wids in finished chunk files. | PASS: `run_variant.py --help` has no `--chunk-windows`; grep finds no chunk patch in the harness or drivers; the progress probe gives windows 10, windows_done 5, chunks_done 2. |
| 11 | Complied: dummy commands only. | ltrpav never imported (asserted). |
| Addendum | 04_chr10.sh order: read-out, awpaf_yardstick, mm2, mm2_lastz, mm2_N50, flank-mm2_2k/5k/10k/20k, flank-blast_10k, mm2_wfa, fastga, hybrid, then mm2 at 64 threads (after `runs/batch.exit` and the idle gate). Variants, timeouts and threads are unchanged. | Traced with a stub interpreter in a scratch chr10 dir, executing nothing. The 15 measured runs come in exactly this order: routes at 2h/32 threads, mm2_lastz and mm2_wfa as `genotype --pair B73v5,TIL18` at 45m/32 threads with both anchor seeds, t64 at 2h/64 threads, then the table. |

**Relaunch readiness** (after the controller moves `runs/`, `chr10/runs/` and `chr10/anchorwave_readout/` to
`*_stocknet`):
- 02 creates a fresh `runs/` and runs all 78.
- 04 reruns the read-out because `readout.done` is absent. The read-out regenerates the PAF (stale stamp), then
  awpaf_yardstick and every route run into fresh directories.
- Nothing hard-codes stock-net state. The relaunch commands are unchanged (memo). `python 02_run_sims.py
  --dry-run` and `BAKEOFF_DRY_RUN=1 bash 04_chr10.sh` preview a relaunch.

**Concerns (fix round 1).**
1. **The read-out's runtime path is untested until the rerun.** Item 11 forbids importing ltrpav, so its
   `anchor_pair` and `PafRoute` mirror, the seqid check and the new cache stamp were checked statically only. If
   it fails, step 2 logs a nonzero exit and the batch goes on, but the PAF must exist for awpaf_yardstick: the
   MAF -> PAF conversion runs first in the script.
2. **The M2 start-up check is scoped, which deviates from the literal ruling.** Refusing on *any* live
   `run_variant.py` would make whichever batch starts second refuse while the other runs, which breaks the
   intended 32 + 32 concurrency. The check covers the review's hazard: an orphaned run writing into the directory
   about to be cleaned. The 64-thread gate stays unscoped.
3. **The dry runs delete the real markers.** That includes `chr10/batch.exit` (the controller's stop note) and
   `runs/batch.{done,exit}`. Use them only after the stock-net directories are moved; this is in the memo.
4. **`runs/runs.tsv` (the stock-net sims table) was left without a `role` column**, since every row is a
   candidate. To add it, run `python bakeoff.py table --root runs_stocknet --out runs_stocknet/runs.tsv`. Also,
   `chr10/runs.tsv`'s rundir column points into `chr10/runs/`, which moves to `chr10/runs_stocknet/`.

Status after fix round 1: DONE_WITH_CONCERNS (concern 1 can only be cleared by the rerun).
