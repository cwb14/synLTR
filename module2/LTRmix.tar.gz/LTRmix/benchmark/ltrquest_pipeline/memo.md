# memo: maize_introgression LTRquest run
date: 2026-11-05
purpose: LTRquest multi-genome LTR-RT annotation, B73 + teosinte mexicana + parviglumis, shared family namespace
host: asc-oulab lab server, 256 threads (no SLURM)
status: COMPLETE, exit 0, 2026-11-06 17:09:58. Wall 11:52:27, peak RSS of largest process 96.5 GB, 40.9 CPUs average (logs/time.txt)
launched: 2026-11-06 05:17:31 at 95 busy threads, 478 GB MemAvailable, after 11.5 h wait; launcher confirmed 5042a1e was origin HEAD at launch (no HEAD_CHECK event)

## version
ltrquest: https://github.com/cwb14/LTRquest.git @ 5042a1e (origin HEAD on 2026-11-05), clone at code/LTRquest
env: ltrquest_5042a1e, from the repo's environment.yml + `pip install --no-deps .` (shared `ltrquest` env has identical code; PATH `ltrquest` is an old f6608d8 build, not used)
helpers: code/tools via LTRQUEST_TOOLS_DIR; cloned unpinned by the preflight, reused unchanged by the real run: Kmer2LTR 2c7e7f8 | TEsorter2 cc9b195 | TRF-mod 3e891db | FASTAN 843d0ed
preflight: PASSED 2026-11-05 18:04 (~19 min, 8 threads, 6 Mb of chr1 per genome, same flags). merged_all_ltr: B73v5 350 | TIL18 335 | TIL01 347. depth0/1/2 clean: B73v5 252/86/11 | TIL18 250/77/8 | TIL01 263/74/9. No genome FP-masked; no ltr-timeout caps fired. Rehearsal only, not results.
preflight gaps: stopped after 2 rounds on B73 (r2 = 66 < default --terminate_count 100), so round 3 was not rehearsed; FastLTR rescue was also not exercised (no caps fired on the slices). `depthN` tables are nesting depth, not round number (B73: r1 284 + r2 66 = 350 = merged_all_ltr; clean depth0+1+2 = 349).
real run, B73: r1 104,396 | r2 23,427 before FP filtering; ltr-timeout capped 40 chunks in r1 and 39 in r2 of 5,169, all re-searched by FastLTR.

## inputs (MaizeGDB, md5 verified; raw copies in inputs/raw/<assembly>/)
| label | assembly | taxon | Mb | contig N50 Mb | gaps | telomere ends |
|---|---|---|---|---|---|---|
| B73v5 | Zm-B73-REFERENCE-NAM-5.0 | maize | 2182 | 47.0 | 708 | 16/20 |
| TIL18 | Zx-TIL18-REFERENCE-PanAnd-1.0 | ssp. mexicana | 2494 | 148.0 | 51 | 15/20 |
| TIL01 | Zv-TIL01-REFERENCE-PanAnd-1.0 | ssp. parviglumis | 2617 | 63.9 | 85 | 15/20 |
proteins: Zm-B73-REFERENCE-NAM-5.0_Zm00001eb.1.protein.fa.gz (72,539 records, 39,756 genes; all isoforms, no canonical protein file offered; not the 2025 .nc.protein set)
runners-up: full table in logs/assembly_stats.tsv. TIL25 (N50 79.7), TIL11 (30.1), Ames21814 (62.3, MaizeGDB notes sequence differs from GenBank). PI566673 not downloaded (.fai implies ~30k sequences). NCBI/web search found no B73 T2T; B73-Ab10 is a different line.
selection rule: contig N50 first, then gaps and telomeres, then same assembly pipeline across teosintes.
checks: only ACGTN, no soft-masking, so no clash with IUPAC mask characters. Pfam RT/gag/integrase/RNaseH hits in 2 of 54,053 Pfam-annotated B73 proteins, so gene masking should not hit real TEs. TIL18 is 18% larger than TIL25 with fewer genes (35.7k vs 36.4k), so not retained haplotigs.
seqids: prefixed <label>_ (required: all use chr1..chr10); sequence otherwise untouched; count + length checked against .fai.

## commands
```bash
scripts/01_download.sh inputs/raw
python3 -I scripts/02_assembly_stats.py inputs/raw/*/*REFERENCE*-[0-9].[0-9].fa.gz > logs/assembly_stats.tsv
scripts/03_prepare_inputs.sh
setsid -f nohup scripts/04_preflight.sh > logs/preflight.out 2>&1 < /dev/null        # 6 Mb per genome, 8 threads, same flags
setsid -f nohup scripts/05_wait_and_launch.sh > logs/launcher.out 2>&1 < /dev/null   # waits for CPU + preflight, then runs below
setsid -f nohup scripts/06_heartbeat.sh > logs/heartbeat.out 2>&1 < /dev/null        # hourly logs/heartbeat.log
```
real job (cwd run/, launched by 05):
```bash
ltrquest --genome inputs/B73v5.fa inputs/TIL18.fa inputs/TIL01.fa --proteins inputs/B73v5.proteins.fa.gz \
  --threads 120 --max-rounds 3 --detect-args "ltr-timeout=300" --run-sdust --no-plots --reboundary
```
launch rule: busy threads < 100 of 256 averaged over one 60 s window (/proc/stat, iowait = idle), and state/preflight_ok.<commit> exists.
rule change 2026-11-06 00:47: first version required 3 consecutive windows; that blocked a real reading of 90 at 00:38 (rebounded to ~200 within 3 min), so it was reduced to 1 to match the request. Expect possible oversubscription if load rebounds after launch.

## gotchas
rerun or add a genome: activate ltrquest_5042a1e, export LTRQUEST_TOOLS_DIR=$PWD/code/tools, run the command from run/ with the same absolute genome paths; finished genomes are reused via *.detect.json. state/ was removed in cleanup, so 05 would hold until 04 is rerun.
--mutation-rate left at the default 3e-8 as in the requested command; it only affects k2p_time (K2P itself is in the tables).
B73 NAM-5.0 is PacBio CLR + Canu; TIL01/TIL18 are PanAnd. Cross-genome differences in young, near-identical LTR-RTs may partly reflect assembly technology.

## ltr-timeout asymmetry (caveat for comparing genomes)
round 1 chunks where --ltr-timeout 300 cut LTRharvest short: B73v5 39/5169 (0.75%) | TIL18 166/5340 (3.1%). LTR_FINDER capped far less (1 and 4), and FastLTR re-searched the capped chunks, so those regions still have two callers. TIL18 caps span all 10 chromosomes. Cause not checked; repeat arrays are a guess. TIL01 r1 118/5677 (2.1%).

## detection totals, before FP filtering and reboundary (not final calls)
| genome | r1 | r2 | r3 | total | LTRharvest capped r1/r2/r3 (chunks) |
|---|---|---|---|---|---|
| B73v5 | 104,396 | 23,427 | 2,618 | 130,441 | 39/39/6 |
| TIL18 | 103,118 | 23,026 | 3,002 | 129,146 | 166/153/32 |
| TIL01 | 113,992 | 25,357 | 3,151 | 142,500 | 118/100/12 |

## final results (after FP filtering and reboundary); logs/qc_summary.tsv
| genome | elements | per Mb | depth0 | nested (depth>=1) | Gypsy | Copia | unknown | high/medium/low confidence | median K2P | families |
|---|---|---|---|---|---|---|---|---|---|---|
| B73v5 | 127,636 | 58.5 | 95,049 | 32,587 | 68,619 | 44,573 | 14,343 | 85,276/25,483/16,877 | 0.0194 | 6,774 |
| TIL18 | 124,641 | 50.0 | 93,372 | 31,269 | 67,281 | 42,658 | 14,599 | 83,844/24,775/16,022 | 0.0184 | 6,612 |
| TIL01 | 137,847 | 52.7 | 103,219 | 34,628 | 75,090 | 46,293 | 16,359 | 93,279/26,920/17,648 | 0.0180 | 7,130 |
families: 13,987 in any genome | 1,868 in all 3 | private B73v5 2,882, TIL18 3,141, TIL01 3,303
FP check: 3,069/397,962 = 0.77% (threshold 10%), 53 FP families, no genome masked or re-run
reboundary: 123,128 candidates, 80,919 moved, 0 merged, 2358 s
structure: 0 bad coordinates, 0 seq_len mismatches, 0 duplicate loci, 0 malformed IDs across 390,124 elements

## independent check vs MaizeGDB TE annotations, chr1-10; logs/boundary_concordance.tsv, logs/unmatched_profile.tsv
published: Method=structural intact elements in inputs/annot_<label>/te.gff3.gz (B73: NAM TE.gff3; TIL: PanAnd _EDTA.gff3)
both ends within 10 bp: published recovered 98.7% in all 3 (exact to the base 97.2-97.3%); LTRquest calls matched 40.5-41.6%; null (coordinates shifted 50 kb) 0.000
| group (B73v5; TIL18 and TIL01 within ~0.02) | n | TG..CA | TSD | domains | high conf | low conf | depth0 | median K2P | median length |
|---|---|---|---|---|---|---|---|---|---|
| matched | 51,126 | 0.994 | 0.995 | 0.878 | 0.987 | 0.002 | 0.969 | 0.0078 | 9,343 |
| unmatched | 74,450 | 0.730 | 0.535 | 0.904 | 0.449 | 0.223 | 0.591 | 0.0307 | 13,636 |
interpretation: the check validates only the matched ~40%. Unmatched calls are not validated by it; hallmarks suggest many are older/nested real elements, but about 22% have neither hallmark. Filter on `confidence` if false positives matter.
not a finding: annotation run only, no biological claim tested.

## other files
env lock: logs/env_ltrquest_5042a1e.lock.yml | QC: scripts/07_qc_summary.py, 08_boundary_concordance.py, 09_unmatched_profile.py

## cleanup 2026-11-06 (run/ 126 -> 64 GB apparent)
deleted: 65.9 GB TEsorter scratch from run/*.work (*.bounded.fa.db, *.bounded.fa.aa, *.fxi, *.rexdb.cls.lib, *.rexdb.cls.pep, *.rexdb.dom.faa) | preflight_5042a1e/ | inputs/raw TIL11, TIL25, Ames21814 | inputs/raw_ipr (one-off Pfam check, MaizeGDB ..._Zm00001eb.1.interproscan.tsv.gz) | logs/stats, state/
do NOT delete run/*.work directories wholesale: the *.detect.json reuse check fails on a missing .work, and annotate/gff3 read *.cls.tsv, minimap2_pass2/pass2.{tsv,paf} and *.genic.gff from them. Adding a genome would then mean re-detecting these three (~12 h).
verified after: `ltrquest.record check` prints `reuse` (rc 0) for all 3 genomes with the recorded settings; scripts/07_qc_summary.py output byte-identical to before.
kept: env ltrquest_5042a1e (remove with `mamba env remove -n ltrquest_5042a1e`) | code/ | inputs/*.fa + chosen raw assemblies + inputs/annot_* | all result tables
restore a deleted candidate: https://download.maizegdb.org/<assembly>/<assembly>.fa.gz. Preflight numbers above are from the deleted directory.
