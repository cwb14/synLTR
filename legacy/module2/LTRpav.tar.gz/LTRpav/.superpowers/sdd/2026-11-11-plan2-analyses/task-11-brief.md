### Task 11: Overview figure

**Files:**
- Create: `src/ltrpav/plot/overview.py`, `tests/test_overview.py`
- Modify:
  - `src/ltrpav/analysis/cli.py`: `plot_main`, and the plot stage at the end of `run_analyses`. In `ltrpav run`, a
    figure error is a warning, never a lost result (LTRmix). A missing matplotlib is Task 10's CliError, not a warning;
  - `src/ltrpav/analysis/report.py`: `stage_inputs` gains the `plot` stage;
  - `pyproject.toml`: `ltrpav-plot = "ltrpav.analysis.cli:plot_main"`;
  - `docs/DESIGN.md` section 6: one paragraph on the panels and the selection rules.

**Interfaces:**
- Consumes:
  - the run files: `stats.tsv`, `findings.txt`, `posterior.*`, `tracts.*`, `decoy_*`, `inversions.tsv`, `mechanisms.tsv`,
    `loci.tsv`;
  - `load_catalog` (`Catalog.tsd` for the base-pair panel), `seqio.Fasta` (0-based half-open `fetch`),
    `report.stage_inputs`, `report.analysis_fingerprint("plot")`.
- Produces:

```python
NUMBERS_COLUMNS = ("key", "value", "source")   # source "<file>:<test>/<scope>/<stratum>/<statistic>" or "<file>:<column>"
MAX_ROWS = 24          # display limit, not a data threshold: sequences drawn in panel A (LTRmix)
MIN_FRAC = 0.02        # display limit: sequences shorter than 2% of the longest are not drawn (LTRmix)
def overview(outdir: Path, samples: list[Sample], sheet: Path, trio: tuple[str, str, str] | None = None) -> list[Path]
    # [overview.png, overview.pdf, overview_numbers.tsv]
def plot_main(argv: list[str] | None = None) -> int     # in analysis/cli.py: ltrpav-plot --samples --outdir [--trio R,S,D] [-v]
```

The plot stage is checkpointed like the others. Its key uses `analysis_fingerprint("plot")` (the analysis and plot
packages) and the checksums of the run files listed under Consumes. Its marker lists the three overview files.

- [ ] **Step 1: Load the `making-figures` skill** (Skill tool). Read its `SKILL.md`, `figure-spec-template.md` and every
  image in its `examples/` folder. This task is the figure's own phase: give it the whole figure budget (about an hour of
  work, three or more render-inspect rounds).

- [ ] **Step 2: Write the spec block** (every slot of the template) as the first part of `overview.py`'s docstring. The
  panels are suggestions; choose by the skill.
  - **Story** (method first, DESIGN 2): insertions the recipient shares with the donor, at sites where the sister shows an
    empty target site, cluster along the recipient's chromosomes beyond what the sister's mirror pattern shows, and are
    concentrated in young insertions. Lineage sorting would give the same clustering in the sister's mirror and no age
    excess.
  - **Lead trio:** `--trio`, else the trio with the largest D_pav Z. Every trio appears as small multiples when there
    are more than one.
  - **Suggested panels:**
    - A, lead: the recipient's chromosomes to scale (at most `MAX_ROWS` sequences of >= `MIN_FRAC` of the longest),
      with:
      - every informative locus a tick: RD accent on one side, RS blue on the other;
      - the posterior as a thin track;
      - tracts boxed with their q;
      - inverted blocks as background bands;
      - stretches without informative loci hatched.

      The sister's decoy painting is drawn as a full partner at the same bp scale, rows paired by dominant synteny.
      Sequences are keyed as (genome, fai index); names are labels only.
    - B: one typical tract ± a few hundred kb. Every locus is drawn as a box, with rows for R, S, D and the outgroup
      (present filled, empty site open, missing hatched) and the posterior above.
    - C: one RD locus at base-pair scale: R's element ends with its two TSD copies against S's empty site with one TSD
      copy, fetched as `Fasta.fetch(seqid, start - 1, end)` from the 1-based catalog coordinates.
    - D: D_pav by age bin, points with 95% intervals, the lineage-sorting line D = 0 drawn, n shown.
    - E: the three sharing counts with the lineage-sorting expectation drawn: equal minority counts.
    - F: fates of absences by age: E; D and O inside the element (shown); D and O inside but unshown; D beyond it; O at
      the site; complex O (Task 8's classes as built).
    - G: every trio's D_pav as small multiples.
  - **Example rules** (typical, never the most dramatic):
    - the tract is the q <= 0.05 tract (else any tract) nearest the medians of n_loci and length;
    - the locus is an RD locus in that tract with D tier `annot` or `high`, S's E carrying `tsd_match`, and R's TSD known
      (`Catalog.tsd`), nearest the median K of all RD loci;
    - before drawing, check from the FASTA that R's two TSD copies are identical and that S's single copy matches.
  - **Fallbacks**, each also a numbers row:
    - no trio: a composition panel per genome, and numbers row `no_trio` with value `fewer than three ingroup genomes`;
    - no tract: the posterior only, "no tract called";
    - no FASTA: panel C omitted, with a legend note.

- [ ] **Step 3: Sketch 2-3 layouts** (ASCII), choose one and say why. Report them in the task handback; they are not a
  file.

- [ ] **Step 4: Write the failing tests**

```python
def _analyzed(path, toy_fastas, **kw):
    run = simulate_run(path, seed=1, fasta_dir=toy_fastas, **kw)
    args = ["--samples", str(run.sheet), "--outdir", str(run.outdir)]
    assert stats_main(args) == 0 and paint_main(args) == 0
    return run

def _numbers(path):
    return {r["key"]: r for r in read_tsv(path)}

def test_overview_files(tmp_path, toy_fastas):
    run = _analyzed(tmp_path, toy_fastas, tracts=TRACTS, inversion=("S", "chr2", 300_001, 700_000))
    png, pdf, nums = overview(run.outdir, run.samples, run.sheet)
    assert min(PIL.Image.open(png).info["dpi"]) >= 299.5                      # Pillow reports 299.9994 for 300
    assert len(re.findall(rb"/Type\s*/Page[^s]", pdf.read_bytes())) == 3
    rows = read_tsv(nums)
    assert list(rows[0]) == list(NUMBERS_COLUMNS) and len(rows) >= 10
    assert all((run.outdir / r["source"].split(":")[0]).is_file() for r in rows)
    assert "D_pav" in _numbers(nums)

@pytest.mark.skipif(shutil.which("pdftotext") is None, reason="poppler missing")
def test_overview_legend_text(tmp_path, toy_fastas):
    run = _analyzed(tmp_path, toy_fastas, tracts=TRACTS)
    _, pdf, nums = overview(run.outdir, run.samples, run.sheet)
    text = subprocess.run(["pdftotext", "-f", "2", "-l", "3", str(pdf), "-"], capture_output=True, text=True,
                          check=True).stdout
    assert _numbers(nums)["D_pav"]["value"] in text and "Analysis:" in text

def test_overview_two_genomes(tmp_path, toy_fastas):       # Review Focus 5
    run = write_run(tmp_path, [loc(1000 * i, "R:P* S:E O:E") for i in range(1, 20)],
                    genomes=[GENOMES[0], GENOMES[1], GENOMES[3]], fasta_dir=toy_fastas)
    args = ["--samples", str(run.sheet), "--outdir", str(run.outdir)]
    assert stats_main(args) == 0 and paint_main(args) == 0
    png, pdf, nums = overview(run.outdir, run.samples, run.sheet)
    assert png.is_file() and _numbers(nums)["no_trio"]["value"] == "fewer than three ingroup genomes"

def test_overview_many_scaffolds(tmp_path, toy_fastas):    # Review Focus 4
    seqids = ("chr1",) + tuple(f"scaf{i:03d}" for i in range(300))
    loci = ([loc(1000 * i, "R:P* S:E D:P O:E") for i in range(1, 60)]
            + [loc(70_000 + 1000 * i, "R:P* S:P D:E O:E") for i in range(60)]
            + [loc(1001, "R:P* S:E D:P O:E", seqid=f"scaf{i:03d}") for i in range(300)])
    run = write_run(tmp_path, loci, seqids=seqids, seq_len=5_000, seq_lens={"chr1": 200_000}, fasta_dir=toy_fastas)
    args = ["--samples", str(run.sheet), "--outdir", str(run.outdir)]
    assert stats_main(args) == 0 and paint_main(args) == 0
    num = _numbers(overview(run.outdir, run.samples, run.sheet)[2])
    assert int(num["sequences_drawn"]["value"]) <= MAX_ROWS and int(num["sequences_not_drawn"]["value"]) >= 277

def test_overview_deterministic(tmp_path, toy_fastas):
    run = _analyzed(tmp_path, toy_fastas, tracts=TRACTS)
    first = overview(run.outdir, run.samples, run.sheet)[2].read_text()
    assert overview(run.outdir, run.samples, run.sheet)[2].read_text() == first

def test_plot_help_is_short(capsys):
    with pytest.raises(SystemExit):
        plot_main(["--help"])
    assert len(capsys.readouterr().out.splitlines()) < 40
```

- [ ] **Step 5: Run** `python -m pytest -W error tests/test_overview.py`. Expected: FAIL.

- [ ] **Step 6: Implement.**
  - **Style:**
    - matplotlib; Liberation Sans (system) or Arial, falling back to DejaVu Sans with a warning;
    - `pdf.fonttype 42`; 180 mm wide; no titles; bold panel letters on one grid;
    - colorblind-safe colors, with context in gray.
  - **Outputs:**
    - `PdfPages`: page 1 the figure, page 2 the short legend, page 3 the long legend. Legend text is built from
      `stats.tsv` in the code.
    - The long legend ends `Analysis: <host>:<outdir> · Script: ltrpav.plot.overview · <date>`.
    - The PNG is the figure only, saved at 300 dpi.
    - Every number quoted in a legend gets a row in `overview_numbers.tsv`, among them `D_pav`, `sequences_drawn`,
      `sequences_not_drawn` and the fallback rows.

- [ ] **Step 7: Run** `python -m pytest -W error -m "not slow" && ruff check .`. Expected: PASS.

- [ ] **Step 8: Render and iterate.**
  - Render on a toy run, then on the chr10 scratch copy from Task 10 Step 5.
  - Inspect full-resolution PNG crops and the legend pages (`pdftoppm -r 150`). Fix clipping, collisions and lines too
    thin to read.
  - Repeat at least three rounds.
  - Answer the skill's 7-line figure check in the handback. The final check on real data comes in Task 12, by a reviewer
    who did not make the figure.

- [ ] **Step 9: Commit.** `"Add the overview figure and ltrpav-plot"`
---

