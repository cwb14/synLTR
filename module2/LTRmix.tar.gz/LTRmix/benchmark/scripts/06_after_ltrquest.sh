#!/usr/bin/env bash
# Waits for the extra LTRquest run (PT, TIL25, TIL11), then: six-genome ltrmix, and the TIL11+TIL25 spike-in.
set -u
B=/data2/chris/maize_introgression/benchmark
X=$B/ltrquest_extra
until [ -e $X/job.exit ]; do sleep 120; done
rc=$(cat $X/job.exit)
echo "$(date '+%F %T') LTRQUEST_EXIT rc=$rc" >> $B/logs/after_ltrquest.log
[ "$rc" = "0" ] || exit 1
source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix
R=/data2/chris/maize_introgression/run
T=/data2/chris/maize_introgression/LTRmix/ltrmix.py
cd $B/results
/usr/bin/time -v -o six.time.txt python $T --genome B73v5=$R/B73v5_LTRs --genome TIL18=$R/TIL18_LTRs \
  --genome TIL01=$R/TIL01_LTRs --genome PT=$X/PT_LTRs --genome TIL25=$X/TIL25_LTRs --genome TIL11=$X/TIL11_LTRs \
  --outdir six -t 32 -v > six.log 2>&1
echo "$(date '+%F %T') SIX_EXIT $?" >> $B/logs/after_ltrquest.log
cd $B/spike
python $B/scripts/spike_in.py --base $X/TIL11_LTRs --source $X/TIL25_LTRs --out SPK --frac 0.10 --seed 1 -t 32 > spike_build.log 2>&1
python $T --genome SPK=SPK.fa,SPK.tsv --genome TIL01=$R/TIL01_LTRs --genome TIL18=$R/TIL18_LTRs --outdir out -t 32 -v > spike_ltrmix.log 2>&1
echo "$(date '+%F %T') SPIKE_EXIT $?" >> $B/logs/after_ltrquest.log
