#!/usr/bin/env python3
"""Benchmark check: does masking 'old-arrangement' inverted blocks change the recipient's per-chromosome ranking and
window agreement with ELAI? A block is old-arrangement when the median divergence of the recipient's orthologs in the
genome carrying the other arrangement exceeds the genome-wide median sister-donor ortholog divergence (the two
arrangements then coalesce before the taxa split, so the block's genealogy follows the arrangement)."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")
import argparse

import numpy as np
import pandas as pd
from scipy.stats import spearmanr


def win_r(e, el, W, mask):
    ee = e[~mask] if mask is not None else e
    ee = ee.assign(w=(ee.mid // W).astype(int), pw=ee.post * ee.len)
    p = ee.groupby(["chrom", "w"]).agg(pw=("pw", "sum"), L=("len", "sum"), n=("post", "size"))
    p["post"] = p.pw / p.L
    x = el.assign(w=(el.pos_v5 // W).astype(int)).groupby(["chrom", "w"]).anc.mean()
    j = p.join(x, how="inner").dropna()
    return spearmanr(j.post, j.anc)[0], len(j)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--res", default="results/main3")
    ap.add_argument("--recipient", default="B73v5")
    ap.add_argument("--sister", default="TIL01")
    ap.add_argument("--donor", default="TIL18")
    ap.add_argument("--elai", default="truth/elai_summary.v5.tsv")
    ap.add_argument("--out", default="analysis/inversion_mask.tsv")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args()
    R, S, D = a.recipient, a.sister, a.donor
    e = pd.read_csv(f"{a.res}/elements.{R}.tsv", sep="\t")
    e["mid"] = (e.start + e.end) // 2
    e["len"] = e.end - e.start + 1
    e["post"] = e[f"post_ancestry_{D}"]
    sd = pd.read_csv(f"{a.res}/orthologs.{S}.{D}.tsv.gz", sep="\t")
    thr = float(sd.divergence.median())
    inv = pd.read_csv(f"{a.res}/inversions.tsv", sep="\t")
    inv = inv[(inv.genome_a == R) & (inv.span_a_bp >= 1e6)]
    mask = np.zeros(len(e), bool)
    rows = []
    for _, r in inv.iterrows():
        sel = ((e.chrom == r.chrom_a) & (e.mid >= r.start_a) & (e.mid <= r.end_a)).to_numpy()
        md = float(e.loc[sel, f"div_{r.genome_b}"].median())
        old = md > thr
        rows.append((r.chrom_a, r.start_a, r.end_a, r.genome_b, md, old))
        if old:
            mask |= sel
    el = pd.read_csv(a.elai, sep="\t", usecols=["chrom_v5", "pos_v5", "B73.amp"], dtype={"chrom_v5": str})
    el = el[el["B73.amp"] > -900]
    el["chrom"] = R + "_chr" + el.chrom_v5.astype(str)
    el["anc"] = el["B73.amp"] / 2
    elm = np.zeros(len(el), bool)
    for c, s0, s1, g, md, old in rows:
        if old:
            elm |= ((el.chrom == c) & (el.pos_v5 >= s0) & (el.pos_v5 <= s1)).to_numpy()
    print(f"genome-wide median {S}-{D} ortholog divergence: {thr:.4f}")
    for c, s0, s1, g, md, old in rows:
        print(f"  {c}:{s0 / 1e6:.1f}-{s1 / 1e6:.1f} vs {g}: median divergence {md:.4f} -> "
              f"{'old arrangement (masked)' if old else 'kept'}")
    print(f"masked: {mask.sum():,} elements ({mask.mean():.1%}), {e.len[mask].sum() / 1e6:.0f} Mb of element sequence")
    chroms = [c for c in e.chrom.unique() if c in set(el.chrom)]
    out = []
    for lab, m, m_el in (("all", np.zeros(len(e), bool), np.zeros(len(el), bool)), ("masked", mask, elm)):
        pc = {}
        ec = {}
        for c in chroms:
            k = (e.chrom == c).to_numpy() & ~m
            pc[c] = float(np.average(e.post[k], weights=e.len[k]))
            ec[c] = float(el.anc[(el.chrom == c).to_numpy() & ~m_el].mean())
        rk = sorted(chroms, key=lambda c: pc[c])
        rho = spearmanr([pc[c] for c in chroms], [ec[c] for c in chroms])[0]
        r1, n1 = win_r(e, el[~m_el], 1_000_000, m)
        r10, n10 = win_r(e, el[~m_el], 10_000_000, m)
        low3 = ",".join(c.split("_")[-1] for c in rk[:3])
        print(f"{lab}: lowest three by posterior {low3}; per-chromosome rho vs ELAI {rho:.2f}; "
              f"window r {r1:.2f} (1 Mb, n={n1}), {r10:.2f} (10 Mb, n={n10}); "
              f"posterior mean {np.average(e.post[~m], weights=e.len[~m]):.3f}")
        for c in chroms:
            out.append(dict(set=lab, chrom=c, post=round(pc[c], 4), elai=round(ec[c], 4)))
        out.append(dict(set=lab, chrom="summary", post=np.nan, elai=np.nan, low3=low3, rho=round(rho, 3),
                        r_1mb=round(r1, 3), r_10mb=round(r10, 3)))
    pd.DataFrame(out).to_csv(a.out, sep="\t", index=False)


if __name__ == "__main__":
    main()
