# Task 3 report: seqio.py
Commit: 0dea228 Add FASTA random access with index fallback
Implemented: Fasta (lengths, fetch w/ clipping, close, context manager), revcomp (IUPAC, case kept), n_runs.
Index: sibling .fai/.gzi if present; pysam builds if dir writable; else cache_dir/<sha1[:12]>.<name>.fai/.gzi via pysam.faidx; ValueError if no cache_dir.
Plain gzip detected by magic + absence of BGZF 'BC' extra field + open failure -> ValueError "recompress with bgzip".
Tests (tests/test_seqio.py, 7): plain+bgzip, uppercase, clipping/KeyError, readonly->cache (+reuse), readonly w/o cache, plain gzip, n_runs/revcomp.
RED: pytest tests/test_seqio.py -> ModuleNotFoundError: No module named 'ltrpav.seqio' (expected, module absent).
GREEN: full suite `pytest -q` -> all pass (9 tests, pristine); `ruff check src tests` clean.
Notes: readonly-dir tests skip as root (euid 1007 here, so they ran). `ruff format --check` flags older files (not mine; left untouched). PYI034 noqa on __enter__ because typing.Self needs py3.11.
