#!/usr/bin/env python3
"""Score genotype calls at reference LTR-RTs against haplotype-resolved assembly truth (hap_truth.py).

Modes
  diploid  reads of the assembled individual on one haplotype (R): truth genotype = F/<state on the other haplotype>
  haploid  reads of the other haplotype only (O) on R: truth = <state on O>; scored on presence/absence (`pav`) and
           on a ploidy-1 genotype if given
Scored sets: 'core' = other-haplotype state F, E or S (site and flanks kept); 'all' adds Fx and Fn (present,
other length or flank -> F/F) and Nd, Nr (other haplotype lacks the site -> F/N). O, Nt and U are reported as call
distributions only.
Calls: ltrkin genotype TSVs (label=path), Sniffles2 / kanpig VCFs of elements_to_sv_vcf.py records (label=path).
Usage: eval_hap_truth.py --truth T.tsv --mode diploid --ltrkin v01=a.tsv dev=b.tsv --sniffles s=x.vcf -o prefix
"""
import argparse
import gzip
import sys

import numpy as np
import pandas as pd

TRUTH_GT = {"F": "F/F", "E": "F/E", "S": "F/S", "Fx": "F/F", "Fn": "F/F", "Nd": "F/N", "Nr": "F/N"}
CORE = ("F", "E", "S")           # clean states: the other haplotype keeps the site and its flanks


def op(p):
    return gzip.open(p, "rt") if p.endswith(".gz") else open(p)


def read_vcf_gt(path):
    """id -> (GT, GQ) for one-sample VCFs (Sniffles2, kanpig)."""
    out = {}
    with op(path) as fh:
        for ln in fh:
            if ln.startswith("#"):
                continue
            x = ln.rstrip("\n").split("\t")
            fmt = x[8].split(":")
            val = dict(zip(fmt, x[9].split(":")))
            gq = val.get("GQ", ".")
            out[x[2]] = (val.get("GT", "./.").replace("|", "/"), int(float(gq)) if gq not in (".", "") else 0)
    return out


def combine_sv(e, s):
    """Empty and solo DEL records of one element -> genotype over F/S/E (missing record = no call)."""
    if e is None and s is None:
        return "./.", 0
    ge, qe = e if e is not None else ("./.", 0)
    gs, qs = s if s is not None else ("./.", 0)
    if ge.startswith(".") and gs.startswith("."):
        return "./.", 0
    ae = 0 if ge.startswith(".") else ge.split("/").count("1")
    as_ = 0 if gs.startswith(".") else gs.split("/").count("1")
    q = min(x for x, g in ((qe, ge), (qs, gs)) if not g.startswith("."))
    if ae and as_:
        return "S/E", q
    if ae:
        return ("F/E" if ae == 1 else "E/E"), qe
    if as_:
        return ("F/S" if as_ == 1 else "S/S"), qs
    return "F/F", q


def norm_gt(g):
    if not isinstance(g, str) or g.startswith("."):
        return "./."
    order = {"F": 0, "S": 1, "E": 2, "N": 3}
    return "/".join(sorted(g.split("/"), key=lambda a: order.get(a, 9)))


def strata(t):
    t = t.copy()
    t["len_bin"] = pd.cut(t.length, [0, 5000, 10000, 17000, 1e9], labels=["<5kb", "5-10kb", "10-17kb", ">17kb"])
    k = pd.to_numeric(t.k2p, errors="coerce")
    t["age_bin"] = pd.cut(k, [-1, 0, 0.005, 0.02, 10], labels=["k2p=0", "<=0.005", "0.005-0.02", ">0.02"])
    t["nested"] = np.where(pd.to_numeric(t.depth, errors="coerce").fillna(0) > 0, "inner", "top")
    fi = pd.to_numeric(t.flank_identity, errors="coerce")
    t["hap_div"] = pd.cut(1 - fi, [-1, 0.001, 0.01, 1], labels=["<0.1%", "0.1-1%", ">1%"])
    chrom_rank = {c: i for i, c in enumerate(sorted(t.chrom.unique()))}
    t["split"] = np.where(t.chrom.map(chrom_rank) % 2 == 0, "dev(odd)", "test(even)")
    return t


def score_diploid(d):
    """Metrics for a frame with truth_gt, call, gq (scored set)."""
    n = len(d)
    ok = d.call == d.truth_gt
    hi = d.gq >= 20
    r = dict(n=n, concordance=ok.mean() if n else np.nan,
             call_rate_gq20=hi.mean() if n else np.nan,
             conc_gq20=ok[hi].mean() if hi.any() else np.nan)
    for tg in ("F/F", "F/E", "F/S", "F/N"):
        m = d.truth_gt == tg
        r[f"recall_{tg}"] = ok[m].mean() if m.any() else np.nan
        r[f"n_{tg}"] = int(m.sum())
    for a in "ES":
        has_t = d.truth_gt.str.contains(a)
        has_c = d.call.str.contains(a)
        tp = (has_t & has_c).sum()
        r[f"{a}_recall"] = tp / has_t.sum() if has_t.any() else np.nan
        r[f"{a}_precision"] = tp / has_c.sum() if has_c.any() else np.nan
        hc = has_c & hi
        r[f"{a}_precision_gq20"] = (has_t & hc).sum() / hc.sum() if hc.any() else np.nan
        r[f"{a}_recall_gq20"] = (has_t & hc).sum() / has_t.sum() if has_t.any() else np.nan
    return r


def score_haploid(d):
    n = len(d)
    truth = d.truth_state.map({"F": "present", "E": "absent", "S": "solo"})
    r = dict(n=n)
    if "pav" in d:
        ok = d.pav == truth
        dec = d.pav != "uncertain"
        r.update(pav_conc=ok.mean(), pav_decided=dec.mean(), pav_conc_decided=ok[dec].mean() if dec.any() else np.nan)
        for lab in ("present", "absent", "solo"):
            m = truth == lab
            c = d.pav == lab
            r[f"{lab}_recall"] = (m & c).sum() / m.sum() if m.any() else np.nan
            r[f"{lab}_precision"] = (m & c).sum() / c.sum() if c.any() else np.nan
    if "call" in d:
        g1 = d.call.str.split("/").str[0]
        ok = g1 == d.truth_state
        r.update(gt1_conc=ok.mean(), gt1_conc_gq20=ok[d.gq >= 20].mean() if (d.gq >= 20).any() else np.nan,
                 gt1_call_rate_gq20=(d.gq >= 20).mean())
    return r


def load_calls(args, truth_ids):
    calls = {}
    for spec in args.ltrkin or []:
        lab, p = spec.split("=", 1)
        g = pd.read_csv(p, sep="\t", dtype={"element_id": str})
        if args.sample:
            g = g[g["sample"] == args.sample]
        g = g.drop_duplicates("element_id").set_index("element_id")
        calls[lab] = pd.DataFrame(dict(call=g.genotype.map(norm_gt), gq=g.gq, pav=g.pav, flags=g["flags"],
                                       p_E=g.p_E, p_S=g.p_S, p_F=g.p_F))
    for kind in ("sniffles", "kanpig"):
        for spec in getattr(args, kind) or []:
            lab, p = spec.split("=", 1)
            v = read_vcf_gt(p)
            rows = {}
            for eid in truth_ids:
                e, s = v.get(f"{eid}|empty"), v.get(f"{eid}|solo")
                if e is None and s is None:
                    continue
                gt, gq = combine_sv(e, s)
                rows[eid] = (norm_gt(gt), gq)
            calls[lab] = pd.DataFrame.from_dict(rows, orient="index", columns=["call", "gq"])
    return calls


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--truth", required=True)
    ap.add_argument("--mode", choices=["diploid", "haploid"], default="diploid")
    ap.add_argument("--ltrkin", nargs="*", help="label=genotypes.tsv")
    ap.add_argument("--sniffles", nargs="*", help="label=vcf")
    ap.add_argument("--kanpig", nargs="*", help="label=vcf")
    ap.add_argument("--sample", help="sample name in ltrkin TSVs (default: all rows, first per element)")
    ap.add_argument("--subset", help="file of element IDs to restrict scoring to (e.g. kanpig size range)")
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    t = strata(pd.read_csv(a.truth, sep="\t", dtype={"element_id": str}))
    if a.subset:
        keep = set(open(a.subset).read().split())
        t = t[t.element_id.isin(keep)]
    calls = load_calls(a, set(t.element_id))
    rows, dist, joined = [], [], []
    strat_cols = ["all", "truth_source", "len_bin", "age_bin", "nested", "hap_div", "split", "clade"]
    for lab, c in calls.items():
        d = t.set_index("element_id").join(c, how="left")
        d["call"] = d["call"].fillna("./.")
        d["gq"] = d["gq"].fillna(0)
        d["truth_state"] = d.state
        d["truth_gt"] = d.state.map(TRUTH_GT)
        d["tool"] = lab
        d["all"] = "all"
        joined.append(d.reset_index())
        for scope, states in (("core", CORE), ("all", tuple(TRUTH_GT))):
            if a.mode == "haploid" and scope == "all":
                continue
            sc = d[d.state.isin(list(states))]
            for col in strat_cols:
                for k, g in sc.groupby(col, observed=True):
                    if col == "clade" and len(g) < 30:
                        continue
                    r = score_diploid(g) if a.mode == "diploid" else score_haploid(g)
                    rows.append(dict(tool=lab, scope=scope, stratum=col, level=str(k), **r))
        for st, g in d.groupby("state"):
            vc = g.call.value_counts()
            for call, n in vc.items():
                dist.append(dict(tool=lab, truth_state=st, call=call, n=int(n), frac=n / len(g),
                                 n_gq20=int(((g.call == call) & (g.gq >= 20)).sum())))
    res = pd.DataFrame(rows)
    res.to_csv(a.out + ".metrics.tsv", sep="\t", index=False, float_format="%.4f")
    pd.DataFrame(dist).to_csv(a.out + ".confusion.tsv", sep="\t", index=False, float_format="%.4f")
    pd.concat(joined).to_csv(a.out + ".calls.tsv.gz", sep="\t", index=False)
    show = res[(res.stratum == "all")].drop(columns=["stratum", "level"])
    show = show[[c for c in show.columns if not c.startswith("S_") and "_gq20" not in c or c == "conc_gq20"]]
    with pd.option_context("display.width", 250, "display.max_columns", 40, "display.float_format", "{:.3f}".format):
        print(show.to_string(index=False), file=sys.stderr)


if __name__ == "__main__":
    main()
