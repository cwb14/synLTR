#!/usr/bin/env python3
"""Concordance by stratum on confirmed truth for one condition. usage: strata_confirmed.py <S> <ref> <cond> [tools]"""
import sys
import numpy as np
import pandas as pd
S, ref, cond = sys.argv[1:4]
tools = sys.argv[4].split(",") if len(sys.argv) > 4 else ["v01", "p9", "sniffles", "kanpig"]
t = pd.read_csv(f"{S}/truth/{ref}_truth.tsv", sep="\t").set_index("element_id")
tg = {"F": "F/F", "Fx": "F/F", "Fn": "F/F", "E": "F/E", "S": "F/S", "Nd": "F/N", "Nr": "F/N"}
c = t[(t.truth_source == "confirmed") & t.state.isin(list(tg))].copy()
c["truth"] = c.state.map(tg)
c["len_bin"] = pd.cut(c.length, [0, 5000, 10000, 17000, 1e9], labels=["<5kb", "5-10kb", "10-17kb", ">17kb"])
k = pd.to_numeric(c.k2p, errors="coerce")
c["age"] = pd.cut(k, [-1, 0, 0.005, 0.02, 10], labels=["0", "<=0.005", "0.005-0.02", ">0.02"])
c["nested"] = np.where(pd.to_numeric(c.depth, errors="coerce").fillna(0) > 0, "inner", "top")
fi = pd.to_numeric(c.flank_identity, errors="coerce")
c["hapdiv"] = pd.cut(1 - fi, [-1, 0.001, 0.01, 1], labels=["<0.1%", "0.1-1%", ">1%"])
cc = pd.read_csv(f"{S}/eval/diploid/{ref}_{cond}.calls.tsv.gz", sep="\t", low_memory=False)
for tl in tools:
    c[tl] = cc[cc.tool == tl].set_index("element_id").call.reindex(c.index)
rows = []
for col in ["len_bin", "age", "nested", "hapdiv"]:
    for lev, g in c.groupby(col, observed=True):
        r = dict(stratum=col, level=lev, n=len(g))
        for tl in tools:
            r[tl] = round((g[tl] == g.truth).mean(), 3)
        rows.append(r)
print(pd.DataFrame(rows).to_string(index=False))
