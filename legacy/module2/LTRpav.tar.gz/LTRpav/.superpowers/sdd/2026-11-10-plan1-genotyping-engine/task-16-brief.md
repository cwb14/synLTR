### Task 16: Pair genotyping orchestration

**Files:** Create `src/ltrpav/genotype.py`, `tests/test_genotype.py`

**Interfaces:**
- Consumes: `anchor_pair`, `make_windows`, `align_window`, `preset_for_divergence`, `classify_window`, `call_row`,
  checkpoint functions.
- Produces: `genotype_pair(ctx: PairContext, route: Route, backend: str = "mappy") -> Path`. It writes
  `outdir/pairs/<A>__<B>.calls.tsv.gz` (CALL_COLUMNS, 1-based) and the windows in
  `workdir/windows/<A>__<B>.tsv.gz`. Chunks go to `workdir/calls/<A>__<B>/chunk_<n>.tsv.gz` with `.done.json`.

- [ ] **Step 1: Write the failing tests**

```python
def test_pair_end_to_end(tmp_path):
    # toy.build_pair(): every toy case laid out on one 'chr1' with 20-kb random spacers; GFF3 via write_gff3
    path = genotype_pair(ctx, get_route("mm2"), backend="mappy")
    got = read_calls(path)
    for eid, state in toy_pair.expect.items():
        assert got[eid] == state                       # exact, every case
def test_pair_lowercase_target(tmp_path):            # B FASTA lowercased: identical calls (Review Focus 2)
def test_pair_repetitive_flank_decoy(tmp_path):
    # the E case's 6-kb site region (L and R) is also pasted, with the element inside, 100 kb away in B
    # (a paralog, out of collinear order): the call follows the collinear ortholog -> E, not P

def test_pair_unrelated_genomes(tmp_path, caplog):   # B random: all U "no_anchor", warning logged (Review Focus 5)
def test_resume(tmp_path):
    # run; delete chunk_0 output + marker; rerun -> only chunk_0 recomputed (mtimes), final file byte-identical
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - Windows are grouped in A fai order and split into chunks of `CHUNK_WINDOWS`. Run
    `multiprocessing.get_context("fork").Pool(threads)` with an initializer that opens both `Fasta` objects in each
    worker and receives the elements and children maps.
  - Worker per window: fetch A and B (revcomp B when `strand == -1`), `align_window` with the preset from `d`, then
    `classify_window`.
  - Elements in no window get U `no_anchor`.
  - Concatenate the chunks in order, then mark the pair done.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add pair genotyping with chunked workers and resume"`.

---

