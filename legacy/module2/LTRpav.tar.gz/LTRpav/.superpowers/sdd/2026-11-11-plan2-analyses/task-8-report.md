# Task 8 report: Mechanisms and missingness (DESIGN 7.8)

**Status:** DONE_WITH_CONCERNS.

**Commit:** 7bb87fc "Add mechanisms: states by family and age, absence events, Dollo placement" (BASE 0332c9f). This
was first committed as 518ae1b, then amended with the self-review fixes below. Global identity, no trailers.

**Files:**
- `src/ltrpav/analysis/mechanisms.py` (new; no engine module edited);
- `tests/test_mechanisms.py` (new).

**Tests:**
- `tests/test_mechanisms.py` has 15 tests.
  - The brief's 7 tests and `_table` helper are verbatim (AST-identical to the brief).
  - 8 tests are added: inherited calls, pair tables with stats rows and findings, strata named "all", no K2P, Dollo
    losses and superfamilies, Dollo skips and tree checks, the `pair_calls` errors, and an element table that does
    not match its pair file.
- The full suite `-W error -m "not slow"`: 1015 passed, 1 deselected (120 s). ruff is clean.

## Interfaces (as in the brief)
- `MECH_COLUMNS`, `pair_calls`, `o_kind`, `d_kind`, `pair_mechanisms`, `dollo`, `mechanisms` and
  `write_mechanisms`, with the brief's signatures.
- `pair_mechanisms` reads A's element table itself. `mechanisms` reads each element table once per A and each pair
  file once, through the private worker `_pair`.
- Findings go to the section "Mechanisms".
- The Dollo findings summary comes from a private `_dollo`. The public `dollo` returns `(rows, StatRows)`.

## Judgment calls (recorded; each consistent with DESIGN 5.4/7.8 and the brief)
1. **Inherited D and O** (rule 0, flag `inherit`) have no junction of their own: the engine writes `dl` and `dr`
   as ".".
   - They count as D_beyond and O_complex: undetermined, never "shown derived" and never "at the site".
   - The host's gap covers the nested element and runs past both its ends.
   - The host's history is not the nested element's: a nested insertion can be A-specific.
   - On main3 B73>TIL18 these are 6,987 of 27,647 D calls and 5,545 of 22,123 O calls.
2. **States table: a named family lists its nonzero counts only. Every rollup lists every metric.**
   - Rollups are the strata with family `all`; (all, all, all) is always written.
   - Listing every metric for every family gave 1,370,160 rows (72 MB) on main3, 86.5% of them zeros (median
     family: 1 call per pair). It would reach hundreds of MB at DESIGN's 10-genome ceiling.
   - Listing nonzero counts only gives 185,424 rows (9.7 MB in all).
   - I checked the sparse output against the full one on main3: every non-family row is identical, and the
     family rows are exactly the full table's nonzero rows.
   - Readers must treat a missing family metric as 0. The module docstring says so.
3. **Strata only where calls exist.**
   - An element without K counts in age `all` only.
   - An unknown superfamily or family is ".".
   - Absence rows are written only for age bins holding a call. Without any K2P, the findings line says "skipped
     (no K2P ...)" and there is no table of nans (Review Focus 2).
   - When only some elements have K, the findings line says how many absences count in `all` only.
4. **Resolution rows** go through `stats.resolution` (Global Constraint).
   - Per pair: `resolved_<B>` in test `missingness`.
   - For Dollo: test `branches_resolution` (scope all), each genome's resolved fraction over all loci (merged).
   - On main3 the Dollo one warns: B73 0.60, TIL18 0.58, TIL01 0.63, Zd 0.25.
5. **Dollo guards.**
   - `dollo` raises ValueError in these cases:
     - no outgroup;
     - a tree that lacks a genome or repeats one;
     - a tree not rooted between the outgroups and the ingroup (two children at its top, one of them outgroups
       only). Every tree from `relations` passes this check, including one rooted on the first outgroup.
   - `mechanisms` writes "Dollo placement skipped: no outgroup ..." or "... no tree ..." and never calls `dollo`
     in those cases.
6. **A loss subclade may be the clade itself.** When every genome of the clade is S or missing, the insertion and
   the solo formation go on the same branch. This is one event, not one per leaf: the parsimonious reading of "maximal
   subclade".
   - Merged states make every member P, so no loss lands on a clade that holds a member.
   - On main3 no loss falls on before_root or on the ingroup branch.
7. **Fail fast on mismatched inputs.** Each of these raises an AnalysisError naming the file and line:
   - an eid in a pair file that is not in A's element table;
   - an element called twice;
   - an element without a call;
   - an unknown state;
   - a non-integer `dl` or `dr`;
   - a bad header, a line of the wrong width, or an unreadable or corrupt gzip.

   Other cases:
   - A U without a reason counts as `U_unknown`.
   - A pair with zero calls gets one findings line ("no call") instead of lines of nan.
8. **Stats rows:** layer `pav`.
   - `mechanisms`: stratum = age. n = calls in the stratum for `n_absent`, and n_absent for the fractions.
   - `absence_events`: n = that state's E or D calls.
   - `missingness`: n = the pair's calls.
   - `branches`: scope = branch, stratum = superfamily or all. n = loci placed in that stratum, and all loci for
     `incongruent`.
   - Notes give each fraction's reading: ancestral shown, derived shown, or not determined.
9. **Self-review bug, fixed before the final commit.** A family or superfamily literally named "all" was counted
   two or three times into the rollups and Dollo's totals (3x in a toy). The keys are now deduplicated, and a test
   covers it: it fails on 518ae1b and passes on 7bb87fc.

## main3 probe (read-only)
- **View:** `scratchpad/t8/view` (symlinks to loci.tsv, manifest.json, qc.tsv, pairs/ and work/elements, with
  its own work/).
  - Script: /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t8/probe_mech.py.
  - Outputs: `probe_mech2.out`, `mechanisms.tsv` (sparse) and `mechanisms_dense.tsv` (the first run), in the
    same directory.
  - main3 is untouched: no file is newer than the probe's stamp, and `work/checksums.json` still shows 15:33:46.
- **Cost:** load 11.6 s; relations 0.7 s; `mechanisms` 13.1 s (9 pairs, 1.17 M calls); write 0.8 s; peak RSS
  0.60 GB.
- **B73 -> TIL18**, fractions of the 76,418 absences (E 26,648 + D 27,647 + O 22,123; the brief's counts):

  | age | n_absent | E | D_inside | D_beyond | O_site | O_complex |
  |---|---|---|---|---|---|---|
  | K=0 | 4,028 | 0.460 | 0.0119 | 0.307 | 0.0077 | 0.214 |
  | 0<K<0.01 | 28,949 | 0.384 | 0.0105 | 0.347 | 0.0046 | 0.253 |
  | K>=0.01 | 43,441 | 0.315 | 0.0194 | 0.349 | 0.0045 | 0.312 |
  | all | 76,418 | 0.349 | 0.0157 | 0.346 | 0.0047 | 0.285 |

  - Bounds on derived absences: at most 0.651 (1 - frac_E), at least 0.0157 (frac_D_inside).
  - By age (upper / lower): K=0 0.540 / 0.012; 0<K<0.01 0.616 / 0.011; K>=0.01 0.685 / 0.019.
  - **Superseded by Fix round 1.** These D_inside fractions and lower bounds count every gap end inside the element
    as shown. The current values are in "Fix round 1" at the end.
- **Top U reasons**, as fractions of all 127,636 calls (U 0.146 in all):

  | reason | fraction |
  |---|---|
  | unanchored | 0.068 |
  | inv_site | 0.022 |
  | flank_unaligned | 0.014 |
  | breakpoint | 0.013 |
  | ambiguous | 0.009 |
  | span_cap | 0.007 |
  | no_right_anchor | 0.004 |
  | no_left_anchor | 0.004 |
  | no_anchor | 0.004 |

  G is 0.0002.
- **Events (B73>TIL18):**
  - E: 21,553 events = 17,413 single + 4,140 nested clusters (9,235 elements).
  - D: 20,647 events = 14,805 single + 5,842 multi-element deletions (12,842 elements).
- **Dollo** on (Zd,((B73,TIL01),TIL18)): 316,818 of 322,538 loci placed; 5,720 incongruent.

  | branch | insertions | solo | truncation | deletion |
  |---|---|---|---|---|
  | before_root | 17,715 | 0 | 0 | 0 |
  | Zd | 0 | 1,682 | 5,410 | 0 |
  | B73+TIL18+TIL01 | 37,173 | 0 | 0 | 0 |
  | B73+TIL01 | 20,281 | 885 | 2,334 | 343 |
  | B73 | 74,815 | 1,228 | 2,756 | 2,596 |
  | TIL01 | 86,387 | 1,212 | 2,598 | 3,785 |
  | TIL18 | 80,447 | 1,733 | 4,239 | 871 |

- **Independent checks**, with no ltrpav code:
  - An awk recount of the O/D split from the raw B73__TIL18 pair file matches exactly: D_inside 1,197; D_beyond
    19,463 + 6,987 inherited; O_site 361; O_complex 16,217 + 5,545 inherited.
  - The Dollo insertions per branch, the incongruent count and the deletions per branch were recomputed from
    pav_matrix.tsv by rules derived by hand for this tree. All match exactly.

## Concerns
1. **Fingerprint coverage (for Task 10).**
   - `mechanisms` reads `SLOP_TSD_MULT`, `TSD_DEFAULT` and `MIN_SEG` from `ltrpav.constants`, as the brief
     says. `ltrpav.constants` is not in `READER_MODULES`, which a test ties to catalog.py's imports.
   - `ltrpav.genotype` (`tsv_field`, already used by stats.py and paint.py) is not covered either.
   - So a later change to w would not rerun the stats stage. It would also make the split disagree with the
     classifier that made an older run.
   - Suggest that `analysis_fingerprint` add `ltrpav.constants` (and `ltrpav.genotype`).
   - The three constants and dl/dr semantics are unchanged since main3's engine 7d71073 (`git diff`), so main3 is
     read correctly.
2. **Lead: O with a gap end inside the element.**
   - 460 of 16,578 own O calls (B73>TIL18) have a gap end more than w inside the element: 146 inside only, 314
     inside and beyond. B kept part of the element, which is exactly the D_inside argument.
   - The brief counts them as O_complex (undetermined). frac_D_inside therefore stays a valid lower bound, but a
     loose one: it would rise from 0.0157 to about 0.0217.
   - Not implemented, because the brief fixes the metric set. Worth a ruling: an `O_inside` split or a combined
     "shown derived" metric.
   - O at the site is rare: 361 of 16,578 own O calls, and no small_ins O. Most O calls replace the element plus
     flank with kb-scale B-only sequence (b_ins: 5,484 >= 10 kb, 7,747 1-10 kb, 3,347 < 1 kb).
3. **Reading the bounds.**
   - Even for K=0 insertions (identical LTRs) 54% of absences are not E. Almost all of the gap between the bounds
     is D_beyond and O_complex, which DESIGN 5.4 leaves undetermined.
   - The bounds bracket the derived share; they do not measure it. The lower bound does not rise with age (0.012,
     0.011, 0.019), so "old absences are mostly deletions" is not tested here beyond that bound.
   - **Superseded by Fix round 1:** the lower bounds are now 0.0112, 0.0092 and 0.0155. The reading stands.
4. **Two adjacent clusters in one window count as one event.** The pair files have no gap ids (plan decision 43).
5. **Dollo on merged states.**
   - Members are always P, so losses never land on a clade that holds a member.
   - Zd's low resolution (0.25) places insertions under the root that may be older. The branches_resolution
     WARNING flags this.

Headline test: not applicable. This is an engineering task, and the main3 numbers are a sanity probe, not a finding.

## Follow-up: controller rulings on concerns 1-5
**Commit:** 71b8648 "Count O calls whose gap ends inside the element as derived" (on 7bb87fc).

**Tests:**
- `tests/test_mechanisms.py` has 16 tests. The brief's 7 are still AST-identical to the brief.
- `test_o_inside_is_derived` is new. It fails on 7bb87fc ('O_complex' == 'O_inside') and passes now.
- `test_inherited_calls_are_undetermined` and the findings check of `test_pair_tables_stats_and_findings` are
  updated.
- The full suite `-W error -m "not slow"`: 1016 passed, 1 deselected. ruff is clean.

**Ruling 2: the O_inside split.**
- `o_kind` returns "O_inside" when a gap end lies more than w inside the element (dl < -w or dr < -w), whatever
  the other end does. Otherwise it returns "O_site" (|dl|, |dr| <= w) or "O_complex".
- The brief's `o_kind` cases have no gap end inside the element, so they are unchanged.
- Inherited O (no junction of its own) stays O_complex.
- **Tables:**
  - states gains `n_O_inside`;
  - absence gains `frac_O_inside`, ordered E, D_inside, O_inside, D_beyond, O_site, O_complex: ancestral shown,
    derived shown, undetermined.
- **Notes:** frac_O_inside reads "derived, shown". frac_O_complex now says "a gap end more than two TSD lengths past
  the element's ends and none inside it".
- **Findings:** the lower bound now reads "shown derived = frac_D_inside + frac_O_inside = a + b = c (a lower
  bound: a gap end inside the element, so B carried it)". The by-age lower bounds use the sum. The line ends: "...
  do not say whether B carried the insertion (DESIGN 5.4), so the bounds bracket the derived share; they do not
  measure it."
- The module docstring is updated: the split, the tables and the bounds.

**Ruling 1: fingerprint.** No code change. The docstring now names the engine constants read: SLOP_TSD_MULT and
TSD_DEFAULT (for w), and MIN_SEG (quoted in a note). It says they must equal those of the engine that made the run,
and that the analysis stage key must cover `ltrpav.constants`.

**Rulings 3-5:** accepted as documented limitations. The "bracket, not measure" wording is in the findings line
(ruling 2).

### main3 probe, rerun (read-only view; main3 untouched)
- No file in main3 is newer than the new stamp, and `work/checksums.json` still shows 15:33:46.
- **Cost:** mechanisms 12.5 s; 187,465 table rows; 9.8 MB; peak RSS 0.61 GB.
- **Output:** /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t8/mechanisms.tsv
  (`probe_mech3.out` beside it).
- **B73 -> TIL18**, fractions of the absences; upper = 1 - frac_E, lower = frac_D_inside + frac_O_inside:

  | age | n_absent | E | D_inside | O_inside | D_beyond | O_site | O_complex | upper | lower |
  |---|---|---|---|---|---|---|---|---|---|
  | K=0 | 4,028 | 0.460 | 0.0119 | 0.0017 | 0.307 | 0.0077 | 0.212 | 0.540 | 0.0137 |
  | 0<K<0.01 | 28,949 | 0.384 | 0.0105 | 0.0017 | 0.347 | 0.0046 | 0.252 | 0.616 | 0.0122 |
  | K>=0.01 | 43,441 | 0.315 | 0.0194 | 0.0093 | 0.349 | 0.0045 | 0.303 | 0.685 | 0.0288 |
  | all | 76,418 | 0.349 | 0.0157 | 0.0060 | 0.346 | 0.0047 | 0.279 | 0.651 | 0.0217 |

  - The O counts are O_site 361, O_inside 460 and O_complex 21,302 (15,757 own + 5,545 inherited). The 460
    match the earlier awk breakdown (146 inside only + 314 inside and beyond).
  - **Superseded by Fix round 1** (review I1): D_inside, O_inside and the lower bounds in this table count every
    inside gap end as shown. The current table is in "Fix round 1".
- **Checks against the previous output:**
  - Every row other than those of n_O_complex, n_O_inside, frac_O_complex and frac_O_inside is identical.
  - In every stratum the new n_O_complex + n_O_inside equals the old n_O_complex.
  - The findings lines other than the per-pair absence lines are identical.

## Fix round 1
**Review:** task-8-review.md (Spec ✅; Needs fixes: 1 Important, 4 Minor).

**Commit:** 512e344 "Count an inside gap end as derived only when its remnant is shown" (on 71b8648).

**Tests:**
- `tests/test_mechanisms.py` has 25 tests. The brief's 7 are still AST-identical to the brief.
- New: 2 for I1, 1 for M1, 1 for M2, and 5 parametrized cases for M3.
- The full suite `-W error -m "not slow"`: 1025 passed, 1 deselected. ruff is clean.

**Mutants.** Each was applied in place to `mechanisms.py`, with the file restored after each run. All six are
killed:

| mutant | killed by |
|---|---|
| w = 2 x TSD_DEFAULT | `test_w_is_the_elements_own` |
| adjacency keyed by state only | `test_events_group_adjacent_calls_per_window_and_state` |
| adjacency keyed by wid only | the same test |
| child condition dropped | `test_inside_stretch_with_a_child_is_unshown`, `test_long_inside_stretch_is_unshown` |
| MIN_SEG condition dropped | `test_long_inside_stretch_is_unshown` |
| host links dropped | `test_absence_events` and the M2 test |

Script: /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t8/mutants.py.

**I1 (ruling): a gap end inside the element counts as shown derived only when its remnant is shown.**
- A gap end lies inside when dl < -w or dr < -w. The stretch it cuts off (the element's first -dl or last -dr
  bases) is a shown remnant when both hold:
  - it is shorter than MIN_SEG;
  - no base of it belongs to an annotated child (direct children by the `parent` links of work/elements/<A>.tsv,
    as the classifier's holes).
- One shown end is enough.
- A call with gap ends inside but no shown remnant goes to the new undetermined classes `D_inside_unshown` and
  `O_inside_unshown`, not to D_beyond or O_complex.
- **Implementation:**
  - `d_kind` and `o_kind` gain an optional `own=(left, right)` argument: the element's own bases at each end before
    its first child there. The default, no child, keeps the brief's calls and tests valid.
  - `_element_info` derives `own` from the element table, and `_metric` passes it per element.
- **Tables:**
  - states adds `n_D_inside_unshown` and `n_O_inside_unshown`;
  - absence adds `frac_D_inside_unshown` and `frac_O_inside_unshown`, ordered ancestral shown, derived shown,
    undetermined.
- **Bounds:** the lower bound stays frac_D_inside + frac_O_inside (shown only); the upper bound stays 1 - frac_E.
  The findings line lists the unshown fractions among the undetermined classes.
- **Notes** for both unshown fractions are new. frac_D_inside's note now says it "assumes exact annotated ends, as
  the E/D split does" (the review's residual caveat).
- **Child test:** I read "contains no annotated child" as "no base of the stretch belongs to a child". The
  reviewer's measurement allowed a child covering under half of the stretch. On main3 B73>TIL18 both give the same
  D_inside 961 and O_inside 24 (checked with the reviewer's `lower_variants.py`).
- O at the site stays undetermined.

**M1:** `test_w_is_the_elements_own` pins w per element.
- Unit cases: w 8 for a 4-bp TSD, w 12 for a 6-bp one, w 10 for None and for "".
- Through `mechanisms`, a pair file is rewritten with a 6-bp `tsd_a` and a "." `tsd_a`.
- The w = 2 x TSD_DEFAULT mutant fails.

**M2:** `test_events_group_adjacent_calls_per_window_and_state` pins the grouping.
- Two adjacent E pairs in different windows give separate events.
- An adjacent D in the first pair's window stays a D event.
- A host -> child -> grandchild chain of host_empty E calls is one event.
- Both adjacency mutants and the dropped-link mutant fail.

**M3:** `test_damaged_pair_file_fails_fast` covers all five paths:
- unknown state;
- non-integer dl;
- duplicate call;
- an element without a call;
- a truncated gzip.

Each raises an AnalysisError naming the pair file. None is skipped.

**M4: the bounds, re-quoted.** These supersede every earlier quote in this report; the earlier tables are marked.

### main3 probe after I1 (read-only view; main3 untouched)
- No file in main3 is newer than the new stamp, and `work/checksums.json` still shows 15:33:46.
- **Cost:** mechanisms 12.7 s; 188,876 table rows; 9.9 MB; peak RSS 0.62 GB.
- **Output:** /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t8/mechanisms.tsv
  (`probe_mech4.out` beside it).
- **B73 -> TIL18**, fractions of the absences. Upper = 1 - frac_E; lower = frac_D_inside + frac_O_inside (shown
  only).

  | age | n_absent | E | D_inside | O_inside | D_inside_unshown | O_inside_unshown | D_beyond | O_site | O_complex | upper | lower |
  |---|---|---|---|---|---|---|---|---|---|---|---|
  | K=0 | 4,028 | 0.4598 | 0.0107 | 0.0005 | 0.0012 | 0.0012 | 0.3066 | 0.0077 | 0.2123 | 0.540 | 0.0112 |
  | 0<K<0.01 | 28,949 | 0.3841 | 0.0091 | 0.0001 | 0.0015 | 0.0016 | 0.3475 | 0.0046 | 0.2516 | 0.616 | 0.0092 |
  | K>=0.01 | 43,441 | 0.3149 | 0.0151 | 0.0004 | 0.0044 | 0.0089 | 0.3489 | 0.0045 | 0.3030 | 0.685 | 0.0155 |
  | all | 76,418 | 0.3487 | 0.0126 | 0.0003 | 0.0031 | 0.0057 | 0.3461 | 0.0047 | 0.2788 | 0.651 | 0.0129 |

- **Counts:**
  - D_inside 961 and D_inside_unshown 236 add up to the earlier D_inside of 1,197.
  - O_inside 24 and O_inside_unshown 436 add up to the earlier O_inside of 460.
  - D_beyond 26,450, O_site 361 and O_complex 21,302 are unchanged.
- **Against the reviewer:** the lower bounds equal the reviewer's "no child, depth <= 79" variant at every age:
  0.0112, 0.0092, 0.0155 and 0.0129.
- **Reading:**
  - Derived absences are at least 0.0129 and at most 0.651 of the absences.
  - The lower bound by age is 0.0112, 0.0092 and 0.0155: it does not rise steadily with age.
  - The bounds bracket the derived share; they do not measure it.
