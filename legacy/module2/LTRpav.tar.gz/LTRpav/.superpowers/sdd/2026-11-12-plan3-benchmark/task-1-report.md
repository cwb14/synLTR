# Task 1 report: branch, msprime extra and the population model

Status: DONE_WITH_CONCERNS (env pin change: bcftools 1.25 -> 1.24; brief's seed 3 replaced by a seed scan)

## What was implemented

- Branch `plan3-benchmark` cut from `plan1-engine` at 12d3e6c (preconditions: plan1-engine = 12d3e6c,
  `pgrep -af 'ltrpav|run_variant|bakeoff|lastz|ltrmix'` empty, `git status` clean).
- `src/ltrpav/sim/popmodel.py` (msprime and tskit imported only inside functions; `numpy` at top):
  - `MSPRIME_HELP`, `PULSES` (code -> (donor, recipient) population).
  - `Demog`, `Rates`: frozen dataclasses with the brief's fields and defaults verbatim, checked in `__post_init__`
    (ValueError). Tuple fields given as lists (JSON) are coerced to tuples.
  - `sample_labels(d)`: A1..An, B1..Bn, C1..Cn, O1 with group = taxon.
  - `demography(d)`: populations A, B, C, O (active at time zero), BC, ROOT, and A1p/C1p when sub_a/sub_c are set;
    splits exactly as the brief; pulse `add_mass_migration(ta, source=recipient, dest=donor, proportion=f)` (only
    when f > 0); bottleneck `add_population_parameters_change(t_ab - gens, "A", ne)`; `sort_events()`.
  - `recombination_map(rates, length)`: RateMap, r outside and r_low on [low0 L, low1 L).
  - `ancestry(d, rates, length, seed)`: `sim_ancestry(SampleSet(n, pop, ploidy=1)..., ploidy=2,
    record_migrations=True)`; A1 from A1p and C1 from C1p when those exist.
  - `tracts(ts, d)`: migration records with time == ta, source == recipient, dest == donor; one pass over the trees
    with the active records; for each, `tree.samples(node)` over the overlap; per-sample merge to sorted, disjoint,
    non-adjacent int intervals; `{}` when f = 0 or no record.
  - `demog_from_json(path)`: one flat JSON object keyed by Demog and Rates field names (no name collides); missing
    keys keep defaults; unknown key -> ValueError naming it; non-object -> ValueError; field errors are re-raised
    as ValueError with the path.
- `src/ltrpav/sim/__init__.py`: exports `MSPRIME_HELP, Demog, Rates, demog_from_json, sample_labels` (popmodel
  imports no msprime at import time); docstring updated.
- `tests/poptoy.py`: `L = 200_000`, `small_demog(**changes)` = Demog with every Ne cut tenfold and t_o = 90,000
  (t_ab, t_bc stay the defaults, so tests can place pulses and lineage splits against them). One 7-genome
  ancestry on 200 kb takes ~0.02 s.
- `tests/test_popmodel.py`: the 12 tests of the brief, starting with `pytest.importorskip("msprime")`.
- `pyproject.toml`: `sim = ["msprime>=1.3"]`. `environment.yml`: `- msprime`; bcftools pin 1.25 -> 1.24 (see
  Concerns). CI: `pip install -e ".[dev,sim]"`. `environment.lock.yml` refreshed by the 84c8088 procedure.
- `docs/DESIGN.md` section 12: "### Build decisions (plan 3)": a lead paragraph "Simulator calibration is not
  method tuning: ..." and items 1-36, one per call of `plan3-draft-summary.md`, in its numbering.

## Environment

- PyPI wheels (`pip download msprime --only-binary=:all: --python-version X --platform manylinux2014_x86_64
  --no-deps`): 3.10 msprime-1.4.0 cp310; 3.12 msprime-1.4.5 cp312; 3.13 msprime-1.4.5 cp313. No GSL step in CI.
- `mamba install -n ltrpav -c conda-forge "msprime>=1.3"` (as the brief) solved to msprime 1.4.5 + gsl 2.8 and
  DOWNGRADED bcftools 1.25 -> 1.5 (bioconda build 3), which then failed to start (libcrypto.so.1.0.0 missing).
  Cause: every bcftools 1.25 build (h118bc1c_0/_1) needs gsl >=2.6,<2.7; every conda-forge msprime >= 1.3 build
  needs gsl >= 2.7 (1.4.3+ need 2.8). A dry run pinning bcftools=1.25 with msprime never solved (killed at 590 s).
- Repair (conservative within conda, keeps the lock procedure valid):
  `mamba install -y -n ltrpav --override-channels -c conda-forge -c bioconda "msprime>=1.3" "bcftools=1.24"
  "python=3.12"` -> bcftools 1.24 h487d631_1 (gsl 2.7), htslib 1.25 -> 1.24, gsl 2.6 -> 2.7, msprime 1.4.2
  py312h71fd7f1_0, tskit 1.0.4 (+ attrs, demes, jsonschema, jsonschema-specifications, liblzma-devel, newick,
  referencing, rpds-py, ruamel.yaml, ruamel.yaml.clib, xz, xz-gpl-tools, xz-tools). `bcftools --version`: 1.24,
  htslib 1.24. The env diff against the pre-install export is exactly these lines (lock diff identical).
- bcftools is not used by the engine at run time (only `TOOL_VERSION_ARGS` lists it; no stage key reads its
  version) and only `tests/test_outputs.py::test_bcftools_reads_vcf` runs it (passes with 1.24).
- Lock: `mamba env export -n ltrpav | sed -e '/^  - pip:$/,$d' -e '/^prefix:/d' > environment.lock.yml`, then the
  footer line; checks: `! grep -qE '^prefix:|ltrpav==' environment.lock.yml && grep -qE '^  - msprime='
  environment.lock.yml` -> LOCK_OK.

## TDD evidence

RED (`python -m pytest -W error -p no:cacheprovider tests/test_popmodel.py`, before popmodel.py existed):

```
tests/poptoy.py:9: in <module>
    from ltrpav.sim.popmodel import Demog
E   ModuleNotFoundError: No module named 'ltrpav.sim.popmodel'
ERROR tests/test_popmodel.py
1 error in 1.56s
```

First GREEN run: 11 passed, 1 failed: `test_tract_through_ancestor` (KeyError: 0, no tracts). Diagnosis: with
ne_a = 5, A1 and A2 coalesce long before ta, so a single ancestral lineage meets the f = 0.5 pulse: a coin flip.
Seeds 1-3 move nothing, seeds 4-8 move it (msprime 1.4.5 and 1.4.2 alike; default and toy demography alike), so
the brief's seed 3 can never pass. Fix (test only): take the first seed from 3 whose pulse moves a lineage (seed
4), asserting `tracts == {}` for the seeds skipped; the rest of the test is unchanged and it also asserts every
moved node is internal (time > 0), i.e. the tract really comes through the ancestor.

GREEN (`python -m pytest -W error -p no:cacheprovider tests/test_popmodel.py`): `12 passed in 3.04s`
(test_fraction_matches_f 1.6 s, test_import_without_msprime 0.8 s, the rest < 0.05 s each).
With `tests/test_sim.py tests/test_checkpoint.py`: `112 passed in 10.61s`. `ruff check .`: All checks passed!

Mutation check: adding `import msprime` at popmodel's top level makes `test_import_without_msprime` fail
(`1 failed`), restored after.

## Full suite

Detached, on the committed tree (tree hash checked unchanged between launch and commit):
`setsid -f nohup env PATH=/home/chris/bin/mambaforge/envs/ltrpav/bin:$PATH NUMPY_MADVISE_HUGEPAGE=0 bash -c
'python -m pytest -W error -m "not slow" -p no:cacheprovider > LOG 2>&1; echo "exit $?" >> LOG'`; leader bash
2156377 with PPID 1 and SID 2156377 (= PID); waited with a Monitor until-loop.

```
1171 passed, 2 deselected in 810.19s (0:13:30)
exit 0
```

`ruff check .`: All checks passed!

## Engine fingerprints

`git archive` snapshots of 12d3e6c and of HEAD 3bf2833 (`src/`), each imported alone (`python -I`, snapshot first on
sys.path, `ltrpav.__file__` printed inside the snapshot), `{s: checkpoint.stage_fingerprint(s) for s in
STAGE_MODULES}` compared by `diff`: identical (anchor/raw/blastdb ebbfd97f..., elements a78af75d...,
genotype_pair/genotype_chunk 52071c27..., mm2_index 28f6fc79...). `git diff --stat 12d3e6c HEAD -- src/ltrpav`
touches only `sim/__init__.py` and `sim/popmodel.py`.

## Self-review: choices where the brief left room (conservative; controller to rule)

1. `initially_active=True` on every extant population (A, B, C, O, A1p, C1p), not only B and O: with sub_a or
   sub_c, A or C is the ancestral side of a split, which msprime starts inactive, and sampling A2/C2 there would
   fail. BC and ROOT keep msprime's default (inactive until their split).
2. Extra fail-fast checks beyond the brief's list: Ne and split times finite and > 0; t_ab < t_bc < t_o;
   sub_a's split < t_ab and sub_c's < t_bc (msprime requires it); ta >= 0, and ta > 0 when f > 0; per_taxon an
   integer; a bottleneck as long as t_ab is allowed (change at time 0), longer fails. The lineage checks (sub_*
   present, ta below the lineage split) apply at f = 0 too ("the fail-fast stays strict"); the ta < t_ab check
   only when f > 0, as the brief says. Rates: finite and >= 0, replace_mean > 0, 0 <= low0 <= low1 <= 1,
   loss_split four numbers summing to 1 (+- 1e-6).
3. `recombination_map(rates, length)` is a public helper outside the Interfaces block (the brief's
   test_recombination_map needs a handle). Boundaries are `round(low * L)`, not `int()`, to avoid a
   float-truncation off-by-one (e.g. 0.7 * L just below an integer); empty intervals are dropped (low = (0, x) or
   (x, 1) or (x, x)).
4. `demog_from_json` reads a flat object (Demog and Rates fields side by side), not nested sections.
5. `test_fraction_matches_f` uses `poptoy.small_demog(f=0.18, ta=500)` (the brief names no demography); the
   expected A1 fraction is f either way; 20 x 2 Mb takes 1.6 s.
6. `test_import_without_msprime` checks the import half in a fresh interpreter (`sys.modules['msprime'] =
   sys.modules['tskit'] = None`, then `import ltrpav, ltrpav.sim, ltrpav.cli, ltrpav.sim.cli,
   ltrpav.analysis.cli`, the child asserting it imported this tree's `ltrpav`), because re-importing ltrpav
   in-process would leave duplicate module objects behind; the RuntimeError(MSPRIME_HELP) half (ancestry,
   demography, recombination_map) runs in-process under monkeypatch.
7. `tracts` raises ValueError if the tree sequence lacks the pulse's populations (not made from this Demog).
8. ruff 0.17's default rules do not include E402, so the imports after `importorskip` need no noqa (RUF100 flags
   one); a single `# noqa: TRY004 (bad input)` keeps demog_from_json's non-object error a ValueError, which the
   CLI reports as one error line (`_HANDLED`).
9. A 10-Mb probe with the default Demog (f 0.18, ta 5,000): ancestry 128 s on the loaded server, 114,053 trees,
   94,495 migration records; `tracts` 0.47 s; max RSS 0.15 GB.
10. msprime raises its own ValueError for seed 0 ("seeds must be greater than 0 and less than 2^32"); noted in
    the `ancestry` docstring; Task 5's CLI should map or reject seed 0.

## Concerns

- ENV PIN CHANGE: env `ltrpav` now has bcftools 1.24 / htslib 1.24 / gsl 2.7 (was 1.25 / 1.25 / 2.6), and msprime
  1.4.2, not 1.4.5, because no conda build pair satisfies bcftools 1.25 and msprime >= 1.3. Alternative if the
  controller prefers bcftools 1.25: msprime from PyPI into the env (wheels bundle GSL), but the 84c8088 lock
  procedure strips the pip section, so the lock would not record msprime and the brief's `^  - msprime=` check
  would fail. The brief's own install command transiently broke the env's bcftools (1.5, unusable) before the
  repair; nothing else ran in between.
- The brief's seed 3 in test_tract_through_ancestor cannot produce a tract (see TDD evidence); the test now takes
  the first seed from 3 that does.

## Files changed

- New: `src/ltrpav/sim/popmodel.py`, `tests/poptoy.py`, `tests/test_popmodel.py`.
- Modified: `pyproject.toml`, `environment.yml`, `environment.lock.yml`, `.github/workflows/ci.yml`,
  `src/ltrpav/sim/__init__.py`, `docs/DESIGN.md`.

## Commit

3bf2833 "Add the population model for ltrpav-sim pop (msprime extra)" on `plan3-benchmark` (author and committer
cwb14, the existing identity; no trailers; not pushed). docs/plans/ and .superpowers/ untouched by git.
