### Spec Compliance
- ✅ Spec compliant. All five items have their hunk: m2 (report.py _rerun_advice, _LEFT_OUT, stale_parts WARNING; tests), m3 (DESIGN 7.4), m4 (paint.py docstring), m5 (test_block_size_reaches_every_jackknife), m1 (DESIGN 7.3 and 10.4). Only src/analysis, docs and tests touched; no engine modules; no maize names.
- ⚠️ Not verifiable from diff: STAGE_MODULES fingerprint equality (report claims 7/7 equal; diff touches no engine file, consistent); full-suite result (running separately).

### Strengths
- _rerun_advice (report.py ~320) is generic over OPTIONS, reads the marker's recorded options with the same stage_options default rule the staleness check uses, so old markers read as defaults. Default text byte-identical (findings.txt line at test_cli_analysis.py:412 still passes unchanged).
- Marker-missing case is safe: _rerun_advice is called only for stages already in `stale`, which requires done_meta non-None (_stale returns None otherwise); stage_options also tolerates None.
- m2 test covers default, one option and two options, checks both the WARNING and both findings.txt lines (Run and Warnings), and was shown RED on old code.
- m5 spy test checks all three consumers with both the rule value and an override; mutation-checked per report (each mutant fails). Identity layer stubbed, so no LASTZ cost.
- paint.py rewrap: words unchanged in diff (verified by reading); lines <= 115.

### Issues
#### Critical
None.
#### Important
None.
#### Minor
1. report.py _rerun_advice: advice names only OPTIONS flags, not --trio or --identity. A stale stats part made with --identity (or --trio) gets "ltrpav-stats", which remakes it without the identity layer (and deletes identity.tsv, the m1 hazard). Outside the brief's scope (brief names emission/discovery); worth a lead note.
2. DESIGN.md 7.4 (the edited line "fit collapsed or the painting was skipped). Which painting variant ...") is now a ~145-character line in a ~115-wrapped doc; rewrap.
3. The stale_parts WARNING wording changed for default parts too ("until the paint stage reruns, with ltrpav-paint (or ltrpav run): why"); acceptable, only the new test pins it, test_overview.py:287 and test_cli_analysis.py:412 (findings.txt text) unchanged. Awkward phrasing "with ltrpav-paint (or ltrpav run)" but fine.
4. test_left_out_advice mutates marker JSON by hand (key + backend_version); fine, but the "edited" key alone would already make it stale.

### Assessment
**Task quality:** Approved
**Reasoning:** Every brief item is implemented and tested; default advice is unchanged, variant advice names the recorded options, and the stale-part path cannot hit a missing marker. Only cosmetic and out-of-scope notes remain.
