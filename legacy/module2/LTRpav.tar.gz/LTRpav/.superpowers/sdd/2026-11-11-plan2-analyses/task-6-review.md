# Task 6 review (14d76e9..de55445): painting HMM, tracts, target-decoy q-values, youngest insertion per tract

Scope: src/ltrpav/analysis/paint.py (799 lines, new), tests/test_paint.py (299 lines, new) and the two
constants added to analysis/constants.py. Outside the diff I read only what the named risks needed:
- LTRmix's ltrmix.py: `_fb_cat` (l. 936), `fit_hmm_cat` (l. 999), `tracts_from_post` (l. 1033), `Trio._hmm`
  (l. 1328-1393) and `HMM_L_GRID` (l. 62);
- catalog.py: `pcls`, `cls`, `proj` and the coordinate arrays;
- inversions.py: `inside` and `InvBlock`;
- stats.py: `u95`, `resolution` and `Findings`;
- catalog_toy.py's simulator;
- DESIGN 7.4/7.5, build decisions (plan 2) and the pre-flight rulings A21, D4, A24/D13 and D8.

The checkout stayed read-only:
- git status is clean, and no file under src/ or tests/ is newer than my first main3 snapshot;
- pytest ran with no cache provider, PYTHONDONTWRITEBYTECODE and NUMBA_CACHE_DIR in scratch;
- mutants ran on a `git archive` copy of de55445.

Probes and outputs are in /data2/chris/maize_introgression/benchmark_pav/plan2_reviews/task6/. LTRmix was
imported from a copy of ltrmix.py there (sha256 b2dc6310... identical to LTRmix/), so nothing was written into
LTRmix/. main3 is untouched: the path, mtime and size of all 4,997 entries are identical before and after my
runs. I did not rerun the full suite.

## Spec Compliance: ✅

| Brief item | Status | How checked |
|---|---|---|
| Interfaces: the three column tuples, `HmmFit`, `Tract`, `Painting`, and the nine functions | ✅ | Names, signatures and return shapes match. Four trailing `Painting` fields with defaults (accepted ruling). |
| `classes`: X's members; Y's, D's and the outgroups' states from X's own calls; order old, missing, RD/RS/both/neither; (fai index, start) order; the "any" variant declares `disc=any` | ✅ | test_classes pins the own-call rule (R's U over a merged E). On main3 I rederived idx and classes from the raw own-call state codes (`cat.proj`, not `pcls`/`classes`): identical for B73 (126,853 loci) and the TIL01 decoy (136,308). |
| `forward_backward`: port of `_fb_cat`, `@njit(cache=True)` | ✅ | Bit-identical to `_fb_cat` on 12 random inputs, in one process and across envs (ltrmix: numpy 2.4.6; ltrpav: 2.5.4). |
| `fit_hmm`: pi 0.1, L 1e5, the geomspace scan, +0.5 pseudocounts, pi = clip(mean post of emitting loci), HMM_TOL, HMM_ITERS | ✅ | Bit-identical to `fit_hmm_cat` on 6 random inputs when both use one grid. LTRmix's own grid, `exp(linspace(log))`, differs from geomspace in ULPs (38 of 41 values; rel. 2.9e-15). Fits then differ by at most 2e-15 in pi, L and e, and 2.3e-13 in loglik. |
| Initial emissions; `donor_state` | ✅ | paint.py:408-415. For two classes, e1[0] > e0[0] is LTRmix's two-sided rule, since each row sums to 1. |
| `mean_tract_bp` = L, `mean_donor_run_bp` = L/(1 - pi) (A24/D13) | ✅ | Rows and test_rows_and_files. |
| `call_tracts`: post > 0.5 and odds >= BF_TRACT x prior odds, one fai index | ✅ | Same runs, starts and lengths as `tracts_from_post` on 6 inputs and on main3 (770 target, 599 decoy). The end is the largest end among the run's loci (accepted ruling). |
| Decoy: S's loci under the same rule, S's own calls with X = S and Y = R; the fitted parameters unchanged; the same tract rule | ✅ | Code path and main3 below. |
| `target_decoy`: +1 correction, scale, smallest raw at or below the score, capped at 1; p; scale = n informative(R) / n informative(S); no decoy gives "none" with a WARNING | ✅ | Bit-identical to `Trio._hmm`'s lines (executed verbatim from the source) on 400 random cases with ties. main3's scale is 7,515 / 6,358 = 1.18198. test_no_decoy_without_sister_annotation. |
| `shortest_callable`: middle locus k // 2, no flanks and 20 RS flanks, k <= 200 | ✅ | Recomputed with LTRmix's `_fb_cat`: the brief's fit (2, 4); main3's fit (1, 1); a weaker fit (3, 7). |
| Per tract: youngest_k, youngest_u95 (Task 2's `u95`, D4; "." without self rows, A21), n_identical, inv_frac; posterior `inv`; the fit ignores the blocks | ✅ | On main3, recomputed from loci.tsv's B73_k and the written classes: 0 mismatches over 770 tracts. Painting with and without blocks gives identical posteriors and tracts. |
| Skips (R unannotated; no RD or RS locus) | ✅ | test_skips; code. |
| `write_paintings`: old files removed; one file per recipient and per sister; BED 0-based; name, score, strand; names from `cat.seqids` | ✅ | main3 files: 126,853 and 136,308 posterior rows. Every BED tract's loci carry its label. No two tracts overlap. |
| `paint_rows`: the 21 statistics in the brief's order, paint_resolution, paint_seqid, the Dating lines | ✅ | The parsed list equals the brief's. main3 gives 2,235 rows (2,212 paint_seqid) and no warning under `-W error`. |
| The brief's 12 tests (D8 included) | ✅ | AST: 12 of the brief's 13 functions are identical. test_forward_backward_matches_enumeration differs only in `c1, c0` -> `_, _` (RUF059). |
| Global: analysis-only code, `-W error`, ruff, no attribution, no species or chromosome names in src/, American English, sequences keyed on (genome, fai index) | ✅ | 18 passed under `-W error` (13.8 s); ruff clean. Commit de55445 is by cwb14 with the specified message and no trailers. |

⚠️ notes:
- Every rule is built right, but several are pinned by no test: 11 of my 20 mutants pass all 18 tests (M1,
  M2).
- A collapsed fit (pi at its floor) is presented with a "donor state" and a shortest callable tract
  computed from pseudocounts (M3).
- The accepted rulings are built as described: the q floor line, the max tract end, site starts as
  positions, no decoy without an informative locus, skipped paintings writing nothing, the trailing fields,
  and CALLABLE_FLANK/CALLABLE_MAX in constants.py.

## Independent verification

### Risk 1: port fidelity (port_fidelity.py, ltrmix_side.py)

**Forward-backward.** 12 random inputs: six chains of 1, 2, 7, 60, 400 and 3,000 loci, 5% zero gaps,
negative steps (nested midpoints, to exercise the clamp), about 60% missing data, random pi, L, e0 and e1.
`_fb_cat` and the port agree bit for bit in posterior, loglik, c1 and c0, in one process and across the two
envs.

**EM.** 6 random inputs:
- with the same grid: pi, L, e0, e1, the posterior and loglik are bit-identical;
- with LTRmix's own grid (as LTRmix runs, in its env): max differences 5.6e-17 in pi, 1.8e-15 in relative L,
  2.2e-16 in e, 1.4e-15 in the posterior and 2.3e-13 in loglik.

**Tracts.** On the fitted posteriors, tract counts, starts, ends and lengths match `tracts_from_post`.
mean_post and sum_post differ by up to 5.5e-14 and 6.6e-13, because the port sums by cumulative-sum
differences (M4).

**main3.** The port's fit equals LTRmix's `fit_hmm_cat` (its own grid) on my independently derived classes:
pi diff 0; L rel. 8.9e-16; loglik diff 1.4e-12; posterior max diff 8.9e-16.

### Risk 2: the target-decoy q

**Verbatim comparison.** I executed `Trio._hmm`'s q and p lines (ltrmix.py l. 1360-1374) from the source. The
400 cases had 0-39 targets and 0-39 decoys, scores rounded to create ties, target-decoy ties in 1 in 5, and
scales 0.37, 1, 1.18 and 2.5. q and p are bit-identical in all 400.

**+1 correction.** The brief's example gives q = 1/25 and 2/30. A lone target over two decoys gives 1.0.

**Scale.** Informative loci (build decision 7). On main3, q and p equal LTRmix's lines at scale 1.181975.

**Ties.** `>=` comes from `searchsorted(side="left")`, as in LTRmix. Scores come from cumulative-sum
differences, so an exact tie between a target and a decoy sum may not compare equal. main3 has no tie: 0
exact, 0 within 1e-9 (M4).

**Floor.** q >= 1/n_tracts and p >= 1/(1 + n_decoy), by construction. The findings line fires when either
floor is above 0.05 (M5 is about its wording).

### Risk 3: the decoy

**Code path.** `paint` calls `classes(cat, Y, X, D, discovery)` (paint.py:406): S's members and S's own calls
into R, D and the outgroups. The target's classes never enter. The decoy posterior is `forward_backward`
with fit.pi, fit.L, fit.e0 and fit.e1 unchanged. Only the fitted parameters cross over, and that is the
design.

**main3.** The decoy's loci and classes equal my rederivation from TIL01's raw own-call codes: 1,495 SD and
4,863 SR. The decoy posterior equals LTRmix's `_fb_cat` with the fitted parameters (max diff 7.8e-16).

**Tests.** test_classes pins the own-call rule, and the decoy shares `classes`. But a decoy classed from merged
states passes every test (M2).

### Risk 4: chromosome ends, missing emissions, inverted blocks (main3_indep.py)

**Chromosome ends.**
- B73 gives 553 chains, one per sequence with painted loci. Positions never decrease within a chain.
- Each chain painted alone equals the joint painting (max diff 0).
- One chain across all sequences would move the posterior by up to 0.687 (mean 0.0016).
  test_rows_and_files catches that break (mutant M01) through its decoy recomputation.

**Missing emissions.** The posterior at the 7,515 emitting loci is the same with or without the 119,338
missing-data loci: max diff 2.2e-16, loglik diff 4.6e-13. The chain is stationary across missing loci, as
the docstring says, because the transitions compose: T(d1) T(d2) = T(d1 + d2).

**Inverted blocks.**
- Painting with and without main3's inverted blocks gives identical target posteriors, decoy posteriors
  and tracts.
- 14,527 painted loci are flagged.
- 48 of them lie inside Task 5's dominant-direction-flip blocks (O4).

### Risk 5: can the null and positive-control test fail? (mutate_review.py, null_half_driver.py)

I ran 20 mutants, each on its own copy of the commit, against tests/test_paint.py.

| Mutant | null + positive control | Caught by |
|---|---|---|
| M03 decoy with sister and donor swapped | fails | also finds_tracts |
| M10 missing emission 0.5 under state 1 | fails | also enumeration, outputs, finds_tracts, tracts_without_k |
| M19 swap RD/RS emissions (the implementer's) | fails | also 5 more |
| M01 one chain across sequences / M13 decoy as one chain | passes | test_rows_and_files |
| M15 L fixed at 1e5 | passes | test_fit_hmm_two_blocks |
| M17 tract rule without BF_TRACT | passes | test_tract_rule |
| M18 decoy refitted | passes | test_rows_and_files |
| M20 inv flags against the wrong partner | passes | test_outputs |
| M02 decoy from merged states; M04 pi over all loci; M05 initial e0 from the target; M06 scale 1 passed to `target_decoy`; M07 decoy counted with `>`; M08 tracts across sequences; M09 donor_state always true; M11 youngest_k over every tract locus; M12 shortest_callable at the first RD locus; M14 scores = mean_post; M16 no EM update of the emissions | passes | **nothing** |

**What the null half adds.** At seed 1 the null fit collapses: pi is 1e-4, L is 5e7, there are 0 tracts in
target and decoy, and both means are about 5e-8. Its assertions therefore hold trivially, and the three
symmetric breaks above are caught by the positive-control half. Two target-only false signals fail the null
half at seed 1: M21 (the target's both/neither loci emit RD) and M22 (the target painted donor-like). So D8
holds: the test fails when painting is broken. The surviving rules are covered in M1 and M2.

### Risk 6: main3's excess recomputed (main3_indep.py)

**Independent side.**
- Classes come from the raw state codes in `cat.proj`, not through `pcls` or `classes`. Positions are site
  starts, and chains are fai indexes.
- Initial e0 is the decoy's counts + 1.
- The fit is LTRmix's `fit_hmm_cat` with its own grid, and the decoy is painted with `_fb_cat`.
- The only shared component is Task 1's `load_catalog`.

**Fit.** pi 0.359080; L 301,708.8; e1 (0.99932, 0.00068); e0 (0.00049, 0.99951); loglik -2628.6733.

**Excess.** The unweighted posterior mean is 0.369574 against 0.316506 in the decoy: **+0.053068**. The port
gives +0.053068 (|diff| 1.1e-16), so the report's +0.053 is confirmed.

**Tracts and q.** 770 tracts and 599 decoy tracts; q min 0.2 (5 tracts at 0.2, none <= 0.05); p min 1/600,
with 63 at p <= 0.05. All as reported.

For context, LTRmix-style length weighting gives +0.0538. At the emitting loci alone, the means are 0.359
against 0.235 (O1).

### Report claims
- **Toy calibration, reproduced exactly** (toy_calib.py, seeds 1-25):
  - null: no tract at q <= 0.05; excess >= 0.05 only at seed 22 (+0.0753); +0.0433 is the largest at seeds
    1-5;
  - admixed: coverage 0.959-0.999; excess +0.174 to +0.209; 3-4 tracts and 0-1 decoy tracts; e1[RD]
    0.990-0.997 and e0[RD] 0.230-0.316; L 159-197 kb.
- **main3, reproduced:** the class counts, the decoy counts and scale, the fit, the tracts, q and p. The
  Dating claims hold too: median youngest K 0.01665 over 770 tracts; 35 tracts with an identical-LTR RD
  insertion.
- **Not rerun:** the full suite (981 passed), and the LTRmix main3 comparison figures in concern 1. The
  controller has already ruled on concern 1.
- **The D8 mutation table:** my overlapping mutants agree (swap RD/RS, decoy refitted, the tract rule
  without odds). But "scale inverted: caught by test_rows_and_files" holds for the stored `p.scale` only. The
  scale actually passed to `target_decoy` is untested (M1).

## Strengths
- **A faithful port.** Forward-backward, EM, the tract rule and q/p are bit-identical to LTRmix on shared
  inputs. The only departures are the ones the rulings name, and the module docstring states each.
- **One classing function for target and decoy.** It guarantees that both use the same rule with roles
  swapped. The decoy reads S's own calls and never R's classes.
- **The headline reproduces from scratch.** main3's classes, fit, excess, tracts and dating match an
  independent derivation through LTRmix's own HMM.
- **Useful extra tests.** They cover chain restarts with the expected counts, the decoy recomputed with the
  fitted parameters, u95 from self rows with the D-copy fallback, skips with their rows, and the "any"
  variant's declaration.
- **Honest reporting.** Concern 1 comes with evidence and a principled option. main3 was checked untouched.
  The findings state the q/p floors and the dating caveats: K = 0 is not age 0, and gene conversion makes K
  too young.
- **Cheap.** main3 paints in about 10 s, including fit and decoy, at 0.53 GB.

## Issues

### Critical
None.

### Important
None.

### Minor
- **M1. The q path in `paint` is untested beyond the stored scale (named risk 2).** paint.py:427-429;
  tests/test_paint.py:249 (test_rows_and_files) and :184 (test_target_decoy_edges).
  - **What.** Each of these passes all 18 tests:
    - dropping the scale from the `target_decoy` call (M06);
    - scoring tracts by mean_post instead of sum_post (M14);
    - counting decoy scores > x instead of >= x (M07).

    test_rows_and_files checks `p.scale` and that `n_tracts_q05` counts `p.q`, never that `p.q` and `p.p` are
    `target_decoy` of the tracts' sum_post at `p.scale`. The toy's seed-1 decoy has no tract, so the scale
    cannot show there anyway.
  - **Why.** The informative-locus scale is a deliberate departure from LTRmix (build decision 7). It is 1.18
    on main3, so losing it would shift every q silently.
  - **Fix.**
    - Spy on the call: monkeypatch `ltrpav.analysis.paint.target_decoy` with a wrapper that records its
      arguments. Assert they are `[t.sum_post for t in p.tracts]`, `[t.sum_post for t in p.decoy_tracts]` and
      n_inf(R) / n_inf(S).
    - Add a tie case to test_target_decoy_edges: `target_decoy([4, 3, 2, 1], [3], 1.0)` gives
      p = [0.5, 1, 1, 1]; the `>` variant gives [0.5, 0.5, 1, 1].
- **M2. Other rules that no test pins (named risks 3 and 4, Review Focus 1).** The code is right in each case
  (verified above), but each mutant passes all 18 tests.
  - **The decoy classed from merged states (M02, paint.py:406).** In test_rows_and_files, assert that
    `p.decoy_idx` and `p.decoy_cls` equal `classes(cat, "S", "R", "D")`. Under the merged rule the decoy also
    takes S-present non-member loci, so idx alone already differs.
  - **Tracts joined across sequences (M08, paint.py:318).** Extend test_tract_rule with seq [0, 0, 1, 1] and
    every post 0.9: two tracts. test_paint_many_scaffolds alternates RD and RS scaffolds, so no called run
    meets a boundary.
  - **EM without the emission update (M16, :293-294) or with pi averaged over all loci (M04, :295).**
    test_fit_hmm_two_blocks' asserts hold for the initial emissions, and its input has no missing locus.
    - Freeze LTRmix's `fit_hmm_cat` on the same input with `emit[::3] = -1` and the geomspace grid: pi
      0.2002118471; L 44393.53725; e0 (0.0062588872, 0.9937411128); e1 (0.9748814355, 0.0251185645); loglik
      -9.952418349.
    - The port reproduces these bit for bit, and M04 gives pi 0.2002419226.
    - Assert with rel = 1e-6. This is the suite's only guard on the "ported unchanged" EM.
  - **youngest_k, n_RD and n_identical over every tract locus (M11, :456).** The brief's assertion in
    test_outputs cannot tell RD loci from the rest: in the toy, the copied RD loci and R's private loci both
    take K 0 or 0.004. Add a write_run tract holding a non-RD locus with a smaller K than its RD loci.
  - **shortest_callable at the run's first RD locus (M12, :365).** The brief's fit is symmetric, so it cannot
    tell. Add pi 0.2, L 2e5, e0 (0.3, 0.7), e1 (0.6, 0.4) at a 20-kb spacing: ((3, 60,000.0), (7, 140,000.0)),
    recomputed with LTRmix's `_fb_cat`. The first-locus variant gives 9 loci with flanks.
  - **Low value, optional.** No test has donor_state false (M09). Initial e0 from the target (M05) reaches
    the same EM fit, so it needs no test.
- **M3. A collapsed fit reads like a found donor state.** paint.py:415; findings at :745; rows at
  :603-604 (callable rows).
  - **What.** EM drives pi to its 1e-4 floor in 10 of 25 toy nulls, including seed 1, the null test's seed.
    Then:
    - state 1 holds no data: e1 = (0.49999, 0.50001), the +0.5 pseudocounts;
    - donor_state is 1 (0.5 > e0[RD] 0.275), and L sits at the grid's end (5e7);
    - the findings report "shortest callable tract 16 loci (about 53.2 kb) without flanks, 39 loci (about
      129.8 kb) between 20 RS loci" and "switch scale L ... 50,000.0 kb";
    - there is a line for pi at PI_MAX, but none for its floor.
  - **Why.** This is the expected outcome for a recipient without gene flow, the case a user reads most
    carefully. The headline is right (0 tracts, excess +0.000), but the secondary rows look like estimates of
    something that was not found.
  - **Fix.** Keep the brief's `donor_state` rule. When pi <= `_PI_MIN`, add a findings line beside the
    PI_MAX one: "the fit found no {D}-like fraction (pi at its floor): L, state 1's emissions and the shortest
    callable tract are not estimated". Optionally flag L at either end of HMM_L_GRID (a bound, not an
    estimate). LTRmix has neither line, so this adds presentation only.
- **M4. Tract scores from cumulative-sum differences.** paint.py:323-326.
  - **What.** `sum_post = csum[b + 1] - csum[a]` differs from LTRmix's `post[a:b + 1].sum()` by up to 7e-13.
    So a target and a decoy tract whose sums are mathematically equal may compare unequal in
    `#decoy >= x`. There is no such tie on main3.
  - **Fix.** `s = float(post[a:b + 1].sum())`. The cost is negligible, and q/p become bit-identical to LTRmix
    in every case.
- **M5. Findings wording.**
  - paint.py:758 writes "1 loci". main3's resolution line reads "shortest callable tract 1 loci (about
    84.4 kb)"; it should be "1 locus".
  - paint.py:731-737: the floor line ends "too few tracts for a target-decoy test" even when only p_decoy is
    floored. With 100 target tracts against 5 decoy tracts, for example, q reaches 0.02 while p >= 1/6. Name
    each reason: q floored means too few tracts; p floored means too few decoy tracts for a per-tract p-value.

## Observations for the controller (no action in Task 6)
- **O1. The excess is diluted by design.** 94.1% of B73's painted loci are missing data. Their posterior
  shrinks toward the shared fitted pi in both target and decoy. The unweighted excess (+0.053) is therefore
  less than half the excess at the emitting loci (0.359 against 0.235: +0.124). This follows the brief
  ("unweighted over loci"). Task 12 or Plan 3 may want both.
- **O2. D8 holds, but the null half rests on a degenerate fit at seed 1.** Its q assertion is vacuous (0
  tracts; below 20 tracts q >= 1/n_tracts > 0.05 anyway). With the correct code, the same null assertions
  fail at seed 22 (+0.075): 1 of 20 at seeds 6-25, inside D6's allowance.
- **O3. The max-end rule.** 256 of main3's 770 tracts end beyond their last locus. Painted bp is 470.46 Mb,
  against 468.65 Mb under LTRmix's last-locus rule. No two BED tracts overlap, in the target or the decoy.
- **O4. `inside` (Task 5) also flags dominant-direction-flip blocks**, which are the collinear remainder,
  as inverted. B73's pairs have 3 such blocks, holding 48 of the 14,527 flagged painted loci. This is Task 5's
  semantics; Task 6 calls `inside` as the brief says.

## Assessment
**Task quality: Approved.** 0 Critical, 0 Important, 5 Minor.

The port is faithful: forward-backward, EM, the tract rule and q/p are bit-identical to LTRmix on shared
inputs. Every brief item is built. main3's headline reproduces exactly from an independent derivation through
LTRmix's own HMM: excess +0.053068, 770/599 tracts, q min 0.2, and per-tract dating with 0 mismatches. The
decoy uses S's own calls with roles swapped and the fitted parameters unchanged. Chains restart at every
sequence, missing loci are exactly neutral, and inverted blocks only flag.

The Minor items are test hardening (M1, M2), presentation of the collapsed fit (M3), an exact-tie detail (M4)
and wording (M5). None changes a number on main3.
