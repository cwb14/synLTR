import pytest

from synth import build


@pytest.fixture(scope="session")
def data(tmp_path_factory):
    """Synthetic diploid with planted states (identical haplotypes apart from the events)."""
    return build(str(tmp_path_factory.mktemp("synth")))
