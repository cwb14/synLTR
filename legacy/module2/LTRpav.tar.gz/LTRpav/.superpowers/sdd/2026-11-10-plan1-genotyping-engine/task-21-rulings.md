# Task 21 — controller rulings (bind as much as the brief; override it where they conflict)

## CLI (src/ltrpav/cli.py)
1. `ltrpav run --samples S --outdir O [--threads 8] [--anchor mm2] [--vcf-ref LABEL] [-v]`; `ltrpav-anchor` and
   `ltrpav-genotype` take the same plus `[--pair A,B]`; `ltrpav-merge --samples S --outdir O [--vcf-ref] [-v]`.
   `--anchor` accepts the names in anchor.KNOWN_ROUTES and "paf:<dir>"; default constants.DEFAULT_ROUTE.
   `--vcf-ref` default = first sheet row. Exit code 0 on success, 1 on a handled error (one line "error: <message>"
   on stderr, no traceback unless -v), argparse errors keep argparse's code 2.
2. Pipeline for `run`: read_samples -> open every Fasta with cache_dir = outdir/work/fai -> load_annotation for each
   annotated genome with a per-genome `skipped` Counter -> write outdir/work/elements/<label>.tsv with a checkpoint
   keyed by the annotation and FASTA checksums (reload when done) -> ordered pairs (annotated A, any B != A) in sheet
   order: PairContext(threads=--threads) -> anchor_pair -> genotype_pair -> build_loci(samples, elements, call_paths,
   seq_order) -> outputs: loci.tsv, pav_matrix.tsv, qc.tsv, pav.vcf.gz (+ .tbi, pav.unplaced.tsv), <label>.pav.gff3/
   .bed per genome, manifest.json (written last; started/finished ISO times; checksums of every FASTA and annotation).
   `ltrpav-anchor` stops after anchor_pair; `ltrpav-genotype` after genotype_pair; `ltrpav-merge` runs only the merge
   and outputs from existing pair files (error if any expected pair file is missing).
3. Fail fast with a clear message: SampleSheetError, AnnotationError, a missing external binary for the chosen route
   (fastga needs FastGA; flank-blast needs blastn and makeblastdb; mm2 and flank-mm2 work with mappy alone), an
   unknown --vcf-ref or --pair label, `--pair` naming an unannotated A.
4. Logging: logger "ltrpav" at INFO (start, one milestone per stage/pair, "skip" lines, done, errors); DEBUG with -v.
   `ltrpav --help` < 40 lines.

## QC metrics (extend loci.py; the registry yields Iterable[QcRow], so per-scope metrics are one registry line each)
5. Per ordered pair, scope "A>B": frac_<state> for all 8 states; resolved_frac (P/S/T/E); high_frac (tier high);
   annot_agree and e_in_annot (definitions below).
   - "B site" of a call: P/S/T -> [b_start, b_end]; E -> its TSD copy [b_start, b_end]; D -> the 2-base junction;
     G/U/O -> none.
   - annot_agree: among A->B calls with a B site that overlaps (>= 1 bp) a B-annotated element which is NOT linked
     (same locus) to any ancestor of the A element, the fraction whose state is P, S or T.
   - e_in_annot: E calls whose B site lies inside such a B element, divided by all E calls (0 when none).
6. Per annotated unordered pair, scope "A~B": reciprocity = |links seen in both directions| / |links seen in either|,
   where a link (a, b) is "seen in A->B" when an A->B P/S/T call of a links it to b (the Task 19 linking rule), and
   "seen in B->A" likewise; nan when no links.
7. Per genome, scope = label: annot_sensitivity = among loci where some projection into this genome is P with tier
   high, the fraction where this genome has a member (nan when none); gap_rate = fraction of calls into this genome
   with state G; skipped_<reason> = the annotation loader's skip counts (from the per-genome Counters).
8. Global scope "all": n_loci, n_conflict, n_multi_member, n_annot_conflict (existing).
9. After merging, log a WARNING for any ordered pair with resolved_frac < 0.01 ("no orthologous alignment between A
   and B?").

## Tests (tests/test_cli.py), toy-sized (each < ~30 s; mark slower ones slow)
10. test_run_toy_three_genomes: A and B annotated (toy.build_pair-based), C genotype-only (a mutated copy of B);
    every output exists; manifest has version, argv and sha256 of each input; qc.tsv has reciprocity for A~B and
    annot_agree for A>B and B>A. test_run_shared_seqids: all three genomes use seqid "chr1" (Review Focus 1); loci
    and VCF correct. test_rerun_skips: a second identical run logs "skip" for elements, anchors and genotype, and
    every output except manifest.json is byte-identical. test_help_is_short. Plus: unknown --vcf-ref -> exit 1 with
    a clear message; `ltrpav-merge` with a missing pair file -> exit 1.
