#!/usr/bin/env bash
# Build run FASTAs: prefix every seqid with the assembly label (ltrquest requires IDs unique across
# genomes; all three use chr1..chr10), drop header descriptions, keep the sequence untouched.
# Each output is checked against the MaizeGDB .fai for sequence count and total length.
set -euo pipefail
. "$(dirname "$0")/run.env"
RAW=$PROJECT/inputs/raw; OUT=$PROJECT/inputs; mkdir -p "$OUT"
while read -r label asm; do
  fa=$OUT/$label.fa
  [[ -s $fa ]] && { echo "exists: $fa"; continue; }
  zcat "$RAW/$asm/$asm.fa.gz" | awk -v p="${label}_" '/^>/{split(substr($0,2),a,/[ \t]/); print ">" p a[1]; next} {print}' > "$fa.tmp"
  got=$(awk '/^>/{n++; next} {l+=length($0)} END{print n, l}' "$fa.tmp")
  want=$(awk '{n++; l+=$2} END{print n, l}' "$RAW/$asm/$asm.fa.gz.fai")
  [[ $got == "$want" ]] || { echo "ERROR: $label: got [$got], .fai says [$want]" >&2; exit 1; }
  mv "$fa.tmp" "$fa"; echo "OK $label seqs,bases=$got"
done <<'LIST'
B73v5 Zm-B73-REFERENCE-NAM-5.0
TIL18 Zx-TIL18-REFERENCE-PanAnd-1.0
TIL01 Zv-TIL01-REFERENCE-PanAnd-1.0
LIST
ln -sf "$RAW/Zm-B73-REFERENCE-NAM-5.0/Zm-B73-REFERENCE-NAM-5.0_Zm00001eb.1.protein.fa.gz" "$OUT/B73v5.proteins.fa.gz"
echo PREPARED
