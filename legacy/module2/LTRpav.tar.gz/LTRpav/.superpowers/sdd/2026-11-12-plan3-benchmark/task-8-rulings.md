# Task 8: controller rulings (snapshot 4f3973e, Task 7 approved)

These bind as much as task-8-brief.md, and override it where the two conflict.

## R1. Snapshot
`snap/4f3973e` (Task 7 approved head, `git archive 4f3973e src`). Write `snap/<sha>/SHA`. Every script in this task sources
`common/env.sh`, which asserts `ltrpav.__file__` lies inside the snapshot.

## R2. Thread budget with the real-genome queue
- **The queue.** Task 12's queue (PID 1563670, `benchmark_pav/plan3/real/`) is running 32 threads. The Global
  Constraints cap jobs together at 32 threads and 250 GB.
- **Stop it before heavy compute.** Before the first step that runs more than 4 threads or processes (Step 3's
  probes, Step 4's detached run, or the pilot), stop the queue:
  1. Run `kill -TERM -- -1563670`. This is a process-group kill; a TERM to the PID alone orphans the running step.
  2. Confirm that no process of the queue remains: `pgrep -af 'genotype_all|ltrpav-genotype|lastz|mem_sampler'`
     must show none from `plan3/real`.
  3. Record in your report the time and the pair files done, `ls real/six/geno/pairs/*.done.json`.
- **Leave the queue alone.** Do not relaunch it, edit its files, or touch `plan3/real/` in any other way. The
  controller relaunches it after the grid; it resumes from its checkpoints.
- **Cost if wrong:** the queue's in-flight pair restarts from its chunk checkpoints.

## R3. Contracts from Tasks 2-7 (their reports and reviews; ledger)
- **Clear `sim/` before rerunning.** `ltrpav-sim pop` refuses an outdir holding anything but its own `fai/` cache
  (Task 5 m4). So when `run_one.sh`'s `sim` step reruns because its marker is absent, it removes `sim/` first.
- **Always pass `--threads`.** It defaults to 1.
- **Output names.**
  - Backbone truth names are source spans, `<seqid>:<start>-<end>`; iids are `i<cc><nnnnnn>`.
  - `tracts.<label>.bed` exists only for the recipient taxon's samples, and is empty at f = 0.
- **`params.json`** holds `events.dropped`, including Task 2's thinning counters, `indel_in_no_genome` and the
  off-chromosome gaps, and `meta.simplifications`.
- **Cost of a run.** Each run loads B73's whole annotation (about 24 s) and hashes the 2.2-GB FASTA.

## R4. Step 10's realism check, additions
These are reported, never tuned:
- **Genome length and element density.** Report each against main3: the 20-Mb probe grew the backbone 92-99%, and
  A1 held 67 alive elements per Mb of its own genome, against 58 in B73's LTRquest annotation.
- **K distribution** of simulated elements shared by all ingroup genomes and the outgroup, against main3's elements
  shared by B73 and Zd. Backbone elements age by 2*mu*T_root (Task 3 ruling C1).
- **The named deficit,** recomputed for one pilot run: insertions missing in replacing sequence and simulated solo
  LTRs, sum(lam x a x B_R) (Task 2 ruling I2). At 5 Mb it was 460 against 1,458 kept primaries.

## R5. Step 11 gate
The formula is pre-registered and approved, so applying it needs no user decision.
- If it picks 30 bottleneck nulls, record that and the extra hours in `sim/memo.md`. The controller tells the user.
- A 50-Mb fallback is applied as the brief says.

## R6. Environments
- Never install, update or remove packages in env `ltrpav`.
- Env `ltrmix` is LTRmix's. Check that it imports `ltrmix` before Step 8. If it does not, report NEEDS_CONTEXT;
  do not install into it either.

## R7. From Task 7 (report)
- **Variant paintings.** A run directory holds one painting. A variant paint overwrites the painting files, the paint
  part and stats.tsv's paint rows. So each painting variant (`any`, `decoy`, `anydecoy`) runs in its own view, as
  the brief's view table does. Never run variants in sequence in one directory.
- **No `python -I` or `-E`.** They ignore PYTHONPATH, so the snapshot would not be imported. `env.sh`'s assertion
  catches this; keep it.
- **PATH.** `common/env.sh` puts env `ltrpav`'s bin on PATH, not only its python. Without lastz on PATH, an
  `--identity` stats part reads as stale.
- **`--block-size`** reruns only the stats stage. The same options skip a stage; a different option reruns it.

## R8. Two dispatches
Task 8 is eleven steps, and recent implementers were cut off mid-task. So it runs as two dispatches, each with its
own review.
- **Part A, Steps 1-8:**
  - snapshot, env.sh and view.sh;
  - backbone.tsv;
  - calibration;
  - direction predictions, launched detached;
  - make_grid.py and grid.tsv;
  - run_one.sh and run_grid.sh;
  - the converter and its test.

  Part A ends when `direction_predictions.tsv` is written. Its run is detached; wait with a Monitor until-loop.
- **Part B, Steps 9-11:** the pilot, the realism check and the budget gate.
- **Write the report early.** Each part writes its report section before any long wait, so a cut-off leaves a
  usable record.

## R9. Part B (Steps 9-11): first fixes, then the pilot
- **First, fix Part A's review minors** (task-8a-review.md):
  - **m1:** `common/env.sh` always puts env `ltrpav`'s bin first on PATH, and checks the `python` that the scripts
    call (`command -v python`), not `$LTRPAV_ENV/bin/python`.
  - **m2:** `run_one.sh` takes an exclusive `flock` on `<rundir>/.lock` and refuses, with one error line, when the
    lock is held.
  - **m4:** `--dry-run` runs the run-directory check too.

  Test each on a toy, in scratch.
- **Stop the queue.** It was relaunched as PID 2932602. Before the pilot, stop it as R2 says, with
  `kill -TERM -- -2932602`. Verify, and record the time and the number of pair files done.
- **Measure.** For each pilot step, sample the process tree's summed PSS, as `real/mem_sampler.sh` does: read it and
  copy the approach. Record it beside GNU time's peak RSS, which covers the largest single process only (m3). Record
  the load average at each step's start, because the reviewer measured about 216 s of simulation setup at load
  ~236.
- **Write the report first.** The pilot runs about an hour or more. Write the report's Part B section before
  waiting, and fill it in as steps finish.
