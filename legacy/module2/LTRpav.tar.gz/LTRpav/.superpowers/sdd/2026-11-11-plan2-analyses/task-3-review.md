# Task 3 review (6682dd3..09fa5a5): relationships

Scope: src/ltrpav/analysis/relations.py (648 lines, new), tests/test_relations.py (246 lines, new). Outside the
diff I read only what the named risks needed: catalog.py (`cls`, `pcls_by`, the own-call join), loci.py
`_member_state`, stats.py, and the plan text of Tasks 4, 8 and 12 that consumes these interfaces. The checkout
stayed read-only. Probes and a symlinked main3 view (its own `work/`) are in
/data2/chris/maize_introgression/benchmark_pav/plan2_reviews/task3/. main3/work/checksums.json still has its
15:33:46 mtime. I did not rerun the full suite.

## Spec Compliance: ✅

| Brief item | Status | How checked |
|---|---|---|
| Interfaces: Node, Counted, SisterCall and the 11 functions | ✅ | names, fields and signatures match the brief |
| `discover`: disc, gstar (z, else the first eligible member in sheet order), cand, rows, loci; None on an empty fallback | ✅ | relations.py:385-416. On main3, `rows` and `cand` equal my recomputation from the raw `proj["TIL18"]` arrays, and gstar is always TIL18 or -1. On a toy, gstar takes the X1/X2 order |
| `eligible_fallback`: four-point rule; "groups with x/y", "distance unresolved" | ✅ | relations.py:359-382; "groups with S" and the nan case checked |
| `four_point_ok` | ✅ | argument order and strict `<` as in the brief |
| Run summary: n loci, resolved_frac, annotated; qc.tsv quoted; a missing qc.tsv is one line | ✅ | header `scope metric value` matches `write_qc` |
| Distances: merged states, pairwise complete, outgroups included, rows `distance` with n | ✅ | |
| Shared derived: both present, no outgroup present, E (never missing) in another ingroup genome | ✅ | for three ingroup genomes it equals `trio_sharing` on main3 (3,097 / 5,392 / 1,828) |
| NJ (Q-matrix, ties to sheet order, negative lengths to 0), rooting, the `tree` row and its skips | ✅ | D5 matches a hand-derived tree exactly, and an independent NJ agrees on 500 matrices (below) |
| Sharing, sister pair, p_top, ambiguous plus a WARNING naming the pair | ✅ | binomials recomputed by hand (below) |
| p_kksc on `discover(..., "not_present")`, kksc_loci, the anti-conservative note | ✅ | main3: 2,763 vs 1,495, p 3.12e-85, reproduced independently |
| Outgroup conflicts: row, n, note | ✅ as the brief defines it | I1 disputes the definition, not the implementation |
| Brief's 11 tests | ✅ | diff of the brief's code block against the file shows only the two lint edits the report names; every assertion is verbatim |
| Global constraints: own calls for discovery-ruled statistics, four-point fallback, missing never absent, resolution through `stats.resolution`, analysis package only, -W error, ruff, American English, no attribution | ✅ | `pytest -W error tests/test_relations.py` 16 passed; ruff clean; no British spellings; commit author cwb14, message as specified |

⚠️ The four judgment calls the controller accepted are built as the report describes: `kksc_resolution` rows, a
nan p_top counted as ambiguous, an unrooted tree when there is no outgroup, and lint-only edits to the tests.
`outgroup_conflict` follows the brief's merged-state definition word for word; I1 is about that definition.

## Independent verification

- **NJ.**
  - D5 is additive, with tree ((a:2,b:3):3, c:4, (d:2,e:1):2) (solved by hand). `neighbor_joining` returns
    exactly these edges.
  - I wrote a separate textbook NJ (dict-based, Q recomputed each round, same tie rule) and compared it with
    the implementation:
    - 300 random noisy matrices (3-10 leaves) and 200 integer matrices full of ties: identical splits and
      branch lengths;
    - random additive trees: recovered exactly.
  - `root_on` kept every leaf-to-leaf path length and gave (outgroup, rest) in all 600 rootings. Re-rooting
    merges the old degree-2 root.
- **Binomials, by hand.**
  - p_top = binomtest(12, 14) = 2 x (91 + 14 + 1) / 2^14 = 0.01294.
  - binomtest(12, 15) = 2 x 576 / 2^15 = 0.0352.
  - p_kksc = binomtest(2, 3) = min(1, 2 x 4/8) = 1.0.
- **main3.**
  - Sister pair B73+TIL01, third genome TIL18, p_top 1.6e-138.
  - KKSC recomputed from `proj["TIL18"]` directly: 2,763 vs 1,495, p 3.12e-85, the same as the
    implementation.
  - There are 113,062 not_present candidates against 23,470 under the E rule, because Zd is unresolved in
    TIL18's own call at 89,592 of them.
- **Null calibration (plan review I1's failure mode).** simulate_run with members R 0.95 / S 0.5, p_missing 0.3
  and no tracts:
  - Own-call KKSC over 60 seeds:
    - mean (n_RD - n_SD)/(n_RD + n_SD) = -0.008 ± 0.006 (se);
    - positive in 29 of 60;
    - p < 0.05 in 5 of 60;
    - p deciles 0.08 / 0.47 / 0.94.
  - The merged-state count it replaced rejects in 11 of 12 seeds (D +0.03 to +0.17).
  - The sister pair is (R, S) and the donor D in every seed.
- **Toy edge cases (all pass).**
  - Two eligible fallback genomes:
    - gstar is X1 where both are members and X2 where only X2 is;
    - X1's U call into D drops that locus, as the first-member rule says;
    - Y is excluded as "groups with S".
  - A multi-member locus where D's own call into the member R is E (annot_conflict): KKSC reads the E.
  - U, D and O calls are never counted as absent in shared_derived, trio_sharing or the distances.
  - Four ingroup genomes with two outgroups:
    - all 4 trios are produced;
    - shared_derived A~B = 14 and C~E1 = 3, matching my hand counts.

## Strengths

- `discover` is small and literal. It picks gstar per row, reads every state from gstar's own calls, and takes
  the outgroup rule as a parameter. It refuses an outgroup or a repeated label in a trio, so the rule cannot
  contradict itself.
- Missing is never absent:
  - E is always `== 0` and resolved is always `>= 0`;
  - "not present" (`!= 1`) appears only where the brief asks for not_present.
- NJ and rooting are correct to rounding, ties and degree-2 roots included, and a bad matrix is refused.
- KKSC holds its null under unequal annotation depth. Its findings line calls the p-value anti-conservative.
- Findings and WARNINGs name the genomes, counts and reasons.
- The extra tests are useful: Newick formatting, star ties, negative lengths, re-rooting, fallback reasons and
  the skip paths.
- It is cheap: 0.6 s on 322,538 loci after loading.

## Issues

### Critical

None.

### Important

**I1. The outgroup-conflict "upper bound" counts the genome's own member loci, which are P by construction. The
value is diluted by annotation depth and falls below the per-call rate it is meant to bound.**
relations.py:623-643 (`_conflicts`; denominator at 631-637). The brief's "Outgroup conflicts" rule and plan
Task 12 item 11 define it this way.

- **What.**
  - The denominator is "some outgroup present and g resolved", on merged states.
  - loci.py `_member_state` makes a member genome P/annot whatever the calls say, so the numerator can never
    count g's member loci.
  - On main3 those loci are 65-66% of each denominator: B73 10,129 of 15,377; TIL18 10,041 of 15,334; TIL01
    10,148 of 15,513.
  - In the brief's own fixture (test_outgroup_conflict), 7 of the 8 loci in R's denominator are R's member
    loci (`R:P*`).
- **Why it matters.**
  - *Annotation depth biases it.* Take a per-call false-E rate ε, annotation sensitivity s and call resolution
    r at loci the outgroup carries. Then frac_E ≈ ε·r(1−s) / (s + r(1−s)). A genotype-only genome reports ε;
    one with s = 0.8 and r = 0.5 reports 0.11ε. The Global Constraint says annotation depth must not bias a
    statistic. In a run that mixes annotated and genotype-only genomes, this number would read annotation as
    call error.
  - *On main3 it is not an upper bound on the per-call rate.* Counted from discoverers' own calls (gstar = the
    first annotated member other than g; its call into Zd P/S/T and into g resolved), the E fractions are
    above the reported values:

    | Genome | Own calls | Reported |
    |---|---|---|
    | B73 | 321 / 11,990 = 0.027 | 0.021 |
    | TIL18 | 368 / 11,385 = 0.032 | 0.024 |
    | TIL01 | 376 / 11,957 = 0.031 | 0.024 |

    Merged states with g's member loci removed give 0.062-0.071. That figure is looser, because it conditions on
    g's annotation having missed the copy.
  - *It does not match the stated quantity.* DESIGN 7.2 and build decision 10 speak of ingroup E *calls*. Plan
    review C1's list of permitted merged-state uses (run summary, distances, sharing for the sister pick, Dollo,
    inversions) does not include this one.
  - *What still holds.* On main3 the three member shares are equal, so the three values remain comparable with
    each other. Task 12 item 11 reports them per genome as a headline number.
- **Fix.**
  - Count it from discoverers' own calls:
    - per row, gstar = the first annotated member other than g, in sheet order, as `discover` picks it;
    - keep rows where gstar's call into some outgroup is P/S/T and its call into g is resolved;
    - frac_E = the fraction E among them;
    - `loci` names the rule, e.g. `disc=any_but_<g>;res=<g>;outgroup=present`.
  - That is about ten lines with `pcls_by`. The brief's fixture would then give R 1/1 instead of 1/8, so the
    test changes too.
  - Alternative: merged states without g's member loci, declared in `loci`.
  - The implementer followed the brief, so this needs a controller ruling, and the same edit in Task 12 item 11
    ("merged states, decision 18").

### Minor

- **M1. Two kinds of row carry no `loci` declaration.** relations.py:136 (`annotated`) and 142
  (`skipped_<reason>`) leave `loci` as "." although the brief says every row carries one.
  - Neither row counts loci, so "." means "not applicable". This module writes "none" for that elsewhere (a
    skipped p_kksc); use one explicit token for both.
  - The `annot_sensitivity` row's `disc=any;present=<x>` is looser than qc.tsv's definition (loci with a
    high-tier P call into x from another genome's member). "qc.tsv", or `disc=any_but_<x>;present=<x>`, would
    be exact.
- **M2. With several outgroups, the tree is rooted on the first outgroup's branch alone** (relations.py:565).
  - The other outgroups then sit inside "rest" as the ingroup's sister. A toy with two sister outgroups gives
    `(O1:0,((((A:0,B:0):0.457,C:0.109):0.065,E1:0.109):0.109,O2:0):0);`.
  - That is the brief's rule, but Task 8's Dollo placement would then use a branch between O2 and the ingroup.
  - When the outgroups form a clade in the unrooted tree, root on the branch that splits them from the
    ingroup; otherwise keep the first outgroup and say so in the findings.
  - This is a plan-level change and can wait for Task 8.
- **M3. Test coverage gaps.** My probes confirm the behavior; only the tests are missing:
  - two eligible fallback genomes (the per-row first-member rule);
  - the "groups with <y>" reason (test_fallback_discovery_reasons, test line 197, covers only "groups with R");
  - several outgroups (the "some outgroup present" conflict rule, and the rooting);
  - a locus where z's own call contradicts a member's merged P (annot_conflict) in the KKSC count.
- **M4. A successful fallback hides its exclusions.** The findings name the discovering genome(s) but not the
  candidates that were left out, or why. `_Sharing.excluded` (relations.py:473, 494) is filled but read only on
  the skip path. One clause in the KKSC line (e.g. "Y excluded: groups with B73") would show the four-point
  rule at work.

## Assessment

**Task quality: Needs fixes.** There is one Important finding, I1. It comes from the brief's own definition of the
outgroup-conflict denominator, so it needs a controller ruling, a small change in `_conflicts`, and the matching
Task 12 text.

Everything that decides the roles is correct as verified above:
- `discover`: own calls, outgroup rules, multi-member rows, fallback order;
- the four-point eligibility;
- the sharing counts;
- the sister pair and its binomial test;
- the KKSC test;
- NJ and rooting.

There are no Critical findings. M1-M4 can wait for the final wave.

Probe scripts are in /data2/chris/maize_introgression/benchmark_pav/plan2_reviews/task3/:
- `nj_probe.py`
- `toy_probe.py`
- `main3_probe.py`
- `conflict_owncall_probe.py`
- `kksc_null_probe.py`
- `kksc_sign_probe.py`

`view/` in the same directory is the read-only main3 view.

## Re-review: fix round 1 (09fa5a5..74c9fd8)

Scope: the fix diff only (relations.py +157/−49, tests +107). I checked it against the implementer's "Fix round 1"
account and the controller's I1 ruling. Commit 74c9fd8:
- `pytest -W error tests/test_relations.py`: 22 passed;
- ruff clean;
- author cwb14, no attribution trailers, no British spellings.

I did not rerun the full suite. main3 was read only through the view (checksums.json mtime still 15:33:46).
Probes are in benchmark_pav/plan2_reviews/task3/: `root_split_probe.py`, `fix1_toy_probe.py`,
`compare_fix1.py` (loads 09fa5a5's relations.py from `oldmod/`), and `conflict_literal_probe.py`.

### Finding verdicts

| Finding | Verdict | Evidence |
|---|---|---|
| I1 outgroup-conflict denominator | ADDRESSED | See below |
| M1 rows without `loci` | ADDRESSED | `annotated` and `skipped_<reason>` now `none`; `annot_sensitivity` now `disc=any_but_<x>;present=<x>` with qc.tsv's exact definition in the note; `test_rows_declare_their_loci` asserts no "." remains; the module docstring documents `none` and `any_but_<g>` |
| M2 multi-outgroup rooting | ADDRESSED | See below |
| M3 test gaps | ADDRESSED | Four new tests, one per gap: `test_fallback_first_member_and_exclusions` (two eligible genomes, first-member rule, "groups with S"), `test_two_outgroups` (conflict where only O1 or only O2 is present; rooting), `test_kksc_reads_a_member_as_the_discoverer_calls_it` (annot_conflict), `test_kksc_line_names_the_fallback_exclusions` |
| M4 fallback exclusions unreported | ADDRESSED | The KKSC line adds "(D has no annotation; X split with it ... ; not eligible: Y: groups with S)" only when the fallback discovers; with an annotated z the line has no clause (probe) |

**I1 evidence.**
- *What `_conflicts` now does* (relations.py, `_conflicts`):
  - discoverers are the annotated ingroup genomes other than g;
  - gstar is the first of them that is a member, via `_first_member`, which `discover` now shares;
  - counted rows are those where gstar's own call puts some outgroup P/S/T and g resolved;
  - frac_E is the fraction of those rows where gstar calls g E.
- *main3 values from the new code* (the full `relations` run):

  | Genome | E / counted loci | frac_E |
  |---|---|---|
  | B73 | 321 / 11,990 | 0.0268 |
  | TIL18 | 368 / 11,385 | 0.0323 |
  | TIL01 | 376 / 11,957 | 0.0314 |

  These are exactly the figures I recommended.
- *The new test proves depth invariance.* `test_outgroup_conflict_ignores_annotation_depth` gives 1/8 of 8 for both
  shallow and deep annotation of R, where the old merged rule gives 1/8 and then 1/16.
- *Wording note for the controller.* The ruling says "g's own member loci are excluded". The code implements this
  as "g never discovers": loci that only g discovered are excluded, and loci another ingroup genome also
  discovered stay, read from that genome's call into g. That is the reading behind my recommended figures, and
  it is the annotation-free one:

  | Reading | B73 | TIL18 | TIL01 |
  |---|---|---|---|
  | As built | 0.027 | 0.032 | 0.031 |
  | E at g's member loci only | 2/6,769 | 3/6,125 | 0/6,606 |
  | Literal (drop every locus g's annotation holds) | 0.061 | 0.069 | 0.070 |

  - At g's member loci the other discoverers almost never call g E, so keeping those loci dilutes nothing.
  - Under the literal reading the counted set would depend on g's annotation: in the new test it moves from 1/8
    to 1/1 between shallow and deep annotation.
  - Please confirm that the as-built reading is what the ruling meant.
- *Outgroup-as-discoverer exclusion: correct and necessary.* An annotated outgroup's private insertions leave
  every ingroup genome truly E. Toy check (O annotated, five O-only loci): R's bound is 1/4 as built. With the
  outgroup allowed to discover it would be 6/9, every extra E being correct biology. Loci an ingroup genome
  discovers where O is also a member still count. A genome that is the only annotated ingroup genome gets
  `none` (n 0, nan) and its own findings clause, while the other genomes read its calls (toy: S 1/4,
  `disc=R`).

**M2 evidence.**
- *Clade case.* `_tree` roots on the branch that splits the outgroups' clade from the ingroup.
  - `_root_on_split` agreed with an independent split computation on 2,400 random subsets: 1,283 splits on
    unrooted NJ trees and on re-rooted trees with degree-2 roots, plus 1,117 non-splits.
  - Every split came out (side, rest) with path lengths and splits kept and no unary node left; every
    non-split returned None.
  - Three outgroups forming a clade give `((O1,(O2,O3)),((R,S),D))`, with no WARNING.
- *Single outgroup.* Behavior is unchanged: main3's tree row and line are identical.
- *Non-clade case.* The tree is rooted on the first outgroup and a WARNING is issued, as recommended. The
  three-outgroup toy with O3 inside the ingroup gives this, and the tree row note says "rooted on the first
  outgroup, O1".

### New breakage check

- **Old code against new code**, every row and findings line of `run_summary` + `relations`, on main3 and two
  simulated runs (seed 1 null; seed 2 with tracts). The only changes are the intended ones:
  - the `outgroup_conflict` rows (value, n, loci) and their findings line;
  - the `loci` and note of the catalog rows (`annotated`, `annot_sensitivity`, `skipped_<reason>`).

  Unchanged, and so not broken by the `_first_member` refactor: distances, tree, shared_derived, sharing,
  sister pair, p_top, p_kksc and kksc_resolution.
- **`root_on`** keeps its signature, output and tests. Only its error texts changed, and nothing else calls it
  yet.

### New issues

- **Critical / Important:** none.
- **Minor (optional), N1: the non-clade fallback can split outgroups that form a clade among themselves.**
  - Toy: O1 and O2 identical, O3 copying R. The tree comes out as
    `(O1:0,((((R:0,O3:0):0.042,S:0.042):0.167,D:0.028):0.472,O2:0):0)`, so O2 becomes the ingroup's sister,
    although {O1, O2} is a split of that tree.
  - Rooting on the largest outgroup-only split that contains the first outgroup would keep them together.
  - The WARNING already sends the user to the samples sheet, so this can wait for Task 8 or the final wave.
- **Carry-forward, plan text (the controller's edits, already listed by the implementer).** These lines now
  differ from the code, as ruled:
  - Task 3's "Outgroup conflicts" rule and `test_outgroup_conflict` values (1/8 of 8 is now R 1 of 1, S 0 of 7);
  - "Rooted on the first outgroup";
  - Task 12 item 11 ("merged states, decision 18"), which should now say own calls, ingroup discoverers other
    than g.

### Re-review assessment

I1 and M1-M4 are all ADDRESSED. The fix introduces no Critical or Important problem, and one optional Minor
(N1). **Task quality: Approved.**
