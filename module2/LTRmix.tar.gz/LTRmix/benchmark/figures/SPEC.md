# Figure specification — LTRmix: admixture from LTR-retrotransposons alone (2026-11-07)
Standard: the making-figures skill; this spec only adds to it.
Project specifics: no house library or palette. Use matplotlib (Liberation Sans/Arial, fonttype 42).
  Colors (fixed across all figures): mexicana (*Z. mays* ssp. *mexicana*, TIL18 / TIL25) = vermillion #D55E00;
  parviglumis (ssp. *parviglumis*, TIL01 / TIL11) = blue #0072B2; maize (B73, PT) = black/dark gray #333333;
  context/shared = light gray #BBBBBB; ELAI (published truth) = bluish green #009E73 (a thin line, never filled).
  Taxa italic; "B73", "TIL18" etc. roman. Age axes state the rate: "kyr at 3×10⁻⁸ substitutions per site per year".
Per figure: benchmark/figures/<stem>/ holding <stem>.py, <stem>.pdf (figure + 2 legend pages), <stem>.png (300 dpi),
  <stem>_numbers.tsv, memo.md.
Environment: `source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix` (numpy, pandas, matplotlib,
  samtools, minimap2, mafft, edlib). Read-only inputs below; write only inside benchmark/figures/<stem>/.

Shared data (all paths under /data2/chris/maize_introgression):
- ltrmix outputs, real trio B73v5 (maize) / TIL01 (parviglumis) / TIL18 (mexicana): benchmark/results/main3/
  stats.tsv (every statistic), findings.txt, elements.B73v5.tsv (per B73 element: status/ortholog/divergence in
  TIL18 and TIL01, evidence class, post_ancestry_TIL18, post_recent_TIL18), tracts.B73v5.bed (recent-shared-ancestry
  tracts, q, p_decoy), ancestry.B73v5.bed, decoy_tracts.TIL01.bed, blocks.tsv (collinear blocks per genome pair,
  sign), inversions.tsv, orthologs.<A>.<B>.tsv.gz (both directions), benchmark_real.tsv (every benchmark row),
  benchmark_chromosomes.tsv.
- Published truth (Yang et al. 2023 ELAI, B73, lifted to B73 v5): benchmark/truth/elai_summary.v5.tsv (columns
  chrom_v5, pos_v5, B73.amp = mexicana dosage 0-2; -999 missing; mean_dosage = panel mean; frac_gt1.8);
  benchmark/truth/loci.v5.tsv (ZmPRR37a, HPC1, ZmLPCAT1, cob-weight gene); benchmark/truth/hf.v5.bed.
- Raw LTR-RT data: run/<G>_LTRs_depth*_clean_ltr.{fa,tsv} (records: chrom:start-end#class; tsv has ltr5/3 bounds,
  k2p, tsd, strand); run/<G>_LTRs_all_depth_LTR_cleaned.gff3 (element, LTR and domain features).
  Assemblies: inputs/<G>.fa (+.fai; samtools faidx inputs/B73v5.fa B73v5_chr7:39000000-39010000).
- Comparators: benchmark/wgk/wgk_{all,noLTR}.<G>.tsv (whole-genome / LTR-masked single-copy k-mer tallies per 100-kb
  window), benchmark/gene_snp/gene_abba_baba.tsv (gene-space SNP ABBA/BABA with Z. diploperennis outgroup),
  benchmark/edta/out/ (same tool on EDTA intact annotations).
- Simulations: benchmark/sim/eval/*.json (one line per run), benchmark/sim/sim_summary.tsv and sim_summary.txt,
  benchmark/sim/runs/<name>/{B,P,M}.{fa,tsv}, truth_B.bed, params.json; benchmark/sim/out/<name>/ (tool outputs).
  Names: null_s1xx (f = 0, 30 independent), f<f>_Ta<T>_r<k> (power grid), fn<x>_f<f>_r<k> (one-sided annotation
  dropout in B), m2_* (four genomes, f-ratio).
- Absence check against raw assemblies: benchmark/absence/<A>.<B>.summary.tsv (+ per-element .tsv.gz).
- Main numbers are in benchmark/results/main3/benchmark_real.tsv and the tables named per figure; copy every legend
  number into <stem>_numbers.tsv with its source.

## Fig. 1 `fig1_painting` — LTR-RT libraries alone paint maize B73's mexicana ancestry and its inversions
Story: Orthologous LTR-retrotransposons shared near-identically between maize B73 and mexicana, and not with
  parviglumis, trace the mexicana ancestry of the maize genome chromosome by chromosome, matching population-genomic
  ancestry calls, and their collinearity recovers the large inversions Inv1n and Inv4m.
  Mechanism: gene flow from mexicana into maize after the subspecies split leaves maize haplotypes whose LTR-RT
  copies coalesce with mexicana copies more recently than lineage sorting allows. Generality: one trio here;
  hypothesis for other systems.
  Main numbers: per-chromosome B73 ancestry (ltrmix posterior) ranks chr5, chr8, chr9 lowest, as ELAI (Spearman
  0.64); window correlation with ELAI r = 0.28 (1 Mb) to 0.36 (10 Mb), circular-shift p = 0.001; element AUROC
  0.72-0.78; Inv4m inverted block in B73 v5 chr4:172.85-187.84 Mb vs published 172.88-188.13 Mb; Inv1n: TIL01
  inverted relative to both B73 and TIL18 over ~48 Mb (source: benchmark_real.tsv, benchmark_chromosomes.tsv,
  blocks.tsv).
Data:
  numbers: main3/benchmark_real.tsv, benchmark_chromosomes.tsv, stats.tsv
  raw data to draw from: main3/elements.B73v5.tsv (every B73 element, its class and orthologs), blocks.tsv and
  orthologs.*.tsv.gz (synteny ribbons between genomes), truth/elai_summary.v5.tsv (ELAI trace), run/*_clean_ltr.fa
  + .tsv and inputs/*.fa (base-pair alignment of one ortholog triple with its TSD and LTRs).
Panels (suggested; sketch 2-3 layouts and choose):
  A (lead): for each of the 10 chromosomes, three ideograms side by side at one bp scale: TIL01 | B73 | TIL18,
     joined by synteny ribbons built from orthologous LTR-RTs (gray; inverted blocks in a distinct outline,
     Inv1n on chr1 and Inv4m on chr4 labeled). On B73: every element with a near-identical TIL18 ortholog as a
     vermillion tick on the TIL18 side, every element with a near-identical TIL01 ortholog as a blue tick on the
     TIL01 side; beside B73 a thin ELAI dosage trace (green) and the ltrmix ancestry posterior (black).
  B: zoom to one typical ~3-Mb region of B73 (rule below): every element drawn to size as an oriented box with its
     LTRs; links to its TIL18 and TIL01 orthologs colored by divergence class (near-identical = vermillion / blue,
     older = gray); ELAI trace and posterior on the same x-axis.
  C: base-pair evidence for one ortholog triple from panel B: the TSD shared by B73, TIL18 and TIL01 (one insertion
     event), a stretch of LTR alignment where B73 = TIL18 ≠ TIL01, and the same sites in the element's other LTR as
     the outgroup (the self-outgroup polarization).
  D: per chromosome, B73's mexicana share from LTR-RTs vs ELAI ancestry (one point per chromosome, labeled; chr5,
     8, 9 highlighted), with the window correlation vs window size as an inset or adjacent panel (null = 0 drawn).
Example: region for B: among 3-Mb windows with ≥ 30 informative elements whose posterior AND ELAI are both within the
  middle 50% of windows with ELAI ancestry above the genome mean (typical of agreement, not the most dramatic); state
  the rule. Triple for C: an element in that region with orthologs in all three genomes, identical 5-bp TSD in all
  three, TG..CA ends, self-LTR K2P reproducing the annotation, family-typical length; verify by re-extracting the
  three copies from inputs/*.fa with samtools faidx and aligning (mafft) before drawing.
Caveats for the long legend: individual tracts are not resolved (no ancestry tract survives the target-decoy FDR);
  ELAI itself is diffuse (B73 dosage > 1.8 at 0.6% of SNPs); near-identity ticks also include lineage sorting and
  recent sharing with the specific TIL18 genome; ZmPRR37a is not resolved at ±50 kb (5 of 6 elements private).
Colors: as shared block.

## Fig. 2 `fig2_clock` — The LTR clock separates gene flow from lineage sorting
Story: Transposon insertions shared between two lineages after they split can only come from gene flow, so the
  age of shared LTR-RT insertions, read from each element's own two LTRs, separates introgression from incomplete
  lineage sorting without an outgroup or SNP panel.
  Mechanism: an insertion is a derived state; the two LTRs were identical at insertion, so their divergence dates
  it, and each LTR is an outgroup for the other. Generality: maize trio plus simulations (msprime genealogies);
  hypothesis for other species.
  Main numbers: D(insertions; B73, TIL01; TIL18) rises from +0.08 (K2P 0.05-0.1) to +0.43-0.51 (K2P ≤ 0.005);
  30 null simulations: young-insertion D = +0.02 ± 0.08; with gene flow young D 0.2-0.5 vs old 0.05-0.15.
  Genome-wide D: k-mers +0.111 (Z 6.5), insertions +0.189 (Z 7.2), ortholog triples D3 +0.043 (Z 4.4),
  self-outgroup ABBA/BABA +0.313 (Z 8.4); comparators: whole-genome k-mers +0.107 (Z 8.9), LTR-masked +0.101 (Z 9.4),
  gene-space SNPs with Z. diploperennis outgroup +0.168 (Z 9.2), EDTA annotation D_ins +0.269 (Z 7.4).
  Identity spectrum: B73-TIL18 orthologs with divergence < 0.002 outnumber TIL01-TIL18 3.9× (5,941 vs 1,532).
Data:
  numbers: main3/stats.tsv (D_ins_by_age, D_kmer, D_ins, D3_triples, D_self_outgroup, identity_spectrum),
  sim/eval/*.json (Dins_young, Dins_old per run; recipient_called for the sign), wgk/ and gene_snp/ (see logs and
  benchmark/REPORT.md numbers table), edta/out/stats.tsv.
  raw data to draw from: main3/orthologs.TIL18.B73v5.tsv.gz and orthologs.TIL18.TIL01.tsv.gz (every donor element,
  its K2P and status in each sister: draw the shared insertions themselves along the age axis);
  main3/elements.B73v5.tsv; one young shared insertion for the schematic's real example (TSD, identical LTRs).
Panels (suggested):
  A (lead): schematic of the logic (flat cartoon, set apart): species tree ((maize, parviglumis), mexicana) with the
     split; an insertion younger than the split shared by maize and mexicana must have crossed by gene flow; the two
     LTRs of one element as clock and outgroup; next to it one real young B73+TIL18 insertion absent from TIL01
     (TSD, identical LTRs, empty site in TIL01 if verifiable from the absence check table).
  B: every shared insertion along the insertion-age axis: B73+TIL18 (above) and TIL01+TIL18 (below) as rug/strip
     marks, with the per-stratum D as points ± 2 SE; the null band from the 30 null simulations drawn.
  C: identity spectrum: counts of B73-TIL18 and TIL01-TIL18 orthologs by divergence (both drawn, log x-axis in
     plain units), the near-identical excess shaded.
  D: genome-wide D ± 2 SE: the four LTR-only tests and the comparators on one axis, null 0 drawn.
Example: the young shared insertion in A: K2P = 0, identical TSD in B73 and TIL18, status 'empty' in TIL01 from
  benchmark/absence/B73v5.TIL01.tsv.gz if available, typical length; verify by alignment.
Caveats: D_kmer and D_ins assume comparable annotation completeness and equal branch lengths; the completeness
  check (TIL18's oldest quarter of insertions, K2P > 0.039, present in B73 vs TIL01) is 1.081 ± 0.018; in simulations
  admixture alone gives 1.015-1.04 at f ≈ 0.2 and a 20% one-sided dropout gives 1.23-1.29 with spurious D_kmer ≈ 0.25
  and D_ins ≈ 0.34, so at most ~0.05 of D_kmer and ~0.07 of D_ins could be annotation bias; D3 and D_self (immune to
  dropout in simulations), the gene-space SNP test and whole-genome k-mers (+0.107, matching library D_kmer +0.111)
  agree. Some young TIL01+TIL18 sharing
  exists (parviglumis-mexicana gene flow or K2P noise).
Colors: as shared block.

## Fig. 3 `fig3_benchmark` — Calibration, power and resolution of LTR-RT-only admixture inference
Story: In coalescent simulations and against raw assemblies and independent annotations, LTR-RT-only tests are
  calibrated under no gene flow, detect ≥ 10-18% admixture with one genome per taxon, recover ~85-93% of what whole-
  genome k-mers give, and fail predictably: one-sided annotation dropout biases presence-based tests, and short tracts
  are not resolved individually.
  Mechanism: n/a (method benchmark). Generality: simulated demography fitted to Zea; one real trio.
  Main numbers: 30 null runs: mean Z −0.26 to +0.14, SD 0.77-1.23, no |Z| > 3, no confident tracts; power 100% at
  f ≥ 0.18; element AUROC 0.80-0.87 (admixture 5,000 generations ago) to ~1.0 (50 generations); window r with ELAI:
  LTR-only 0.21/0.28/0.36 vs whole genome 0.25/0.33/0.43 (0.1/1/10 Mb); 20% dropout in one sister: D_kmer Z ≈ −21,
  D_ins Z ≈ −25 vs D3 −0.01, D_self −0.6; absence calls confirmed empty in the raw assembly 87.5-89.3% of decidable
  cases, present calls occupied 76.8-83.0%; with a second donor genome the f-ratio (identity version) gives 0.285/0.271
  for true 0.318/0.285, 0.148/0.143 for 0.182/0.166, 0.101/0.085 for 0.097/0.092, 0.020/0.022 for 0 (sim/eval/m2_*.json).
Data:
  numbers: sim/sim_summary.tsv, sim/eval/*.json, main3/benchmark_real.tsv, wgk/ and edta/ outputs, absence/*.summary.tsv
  raw data to draw from: the per-run JSONs (every run a point), per-element ELAI vs posterior from
  main3/elements.B73v5.tsv + truth/elai_summary.v5.tsv, sim/runs/<name>/truth_B.bed vs sim/out/<name>/tracts.B.bed for
  one typical simulated chromosome painted against its truth.
Panels (suggested):
  A (lead): one simulated chromosome (typical f = 0.18, Ta = 5000 run) drawn like Fig. 1A: true mexicana segments
     (truth_B.bed) above, every element's class tick and the ltrmix posterior below, called tracts as boxes; beside it
     the same view for a null run (control as a full partner).
  B: null calibration: every null run's Z for each test (points), N(0,1) band drawn.
  C: power and fraction: Z (or fraction detected) vs admixture fraction, by admixture time; the identity-spectrum
     lower bound and the f-ratio estimate (m2 runs) against the true fraction, 1:1 line drawn.
  D: resolution: element AUROC by admixture time (sims) with the real B73-vs-ELAI value; window r vs window size for
     LTR-only, whole-genome and LTR-masked k-mers.
  E: failure modes: Z vs one-sided dropout for presence-based vs triple-based tests (both sides drawn); absence calls
     against the raw assemblies.
Example: simulated chromosome for A: from the f = 0.18, Ta = 5000 runs, the chromosome whose true introgressed
  fraction is closest to the genome-wide true fraction; the null partner the same chromosome number of a null run.
Caveats: simulated genomes have ~1/7 of B73's elements (power on real data is higher); 6 power runs with realized
  fraction ≥ 0.40 recast the recipient as the donor's sister (still detected, |Z| 9-13); 40% dropout breaks the
  sister inference; ELAI is not exact truth.
Colors: as shared block; tests: D_kmer, D_ins, D3, D_self in four grays/one accent per test consistently.

## Tool figure `ltrmix_plot` — the overview written by every ltrmix run
Story: per run, the evidence for gene flow and where it lies in the recipient genome, readable without the
  tables. Generality: any trio of LTR-RT libraries.
Data: one ltrmix output directory (trio level): stats.tsv, elements.<R>.tsv, tracts.<R>.bed, ancestry.<R>.bed,
  decoy_tracts.<S>.bed, blocks.tsv; labels from findings.txt. Test it on benchmark/results/main3 and on one
  simulation output (benchmark/sim/out/f0.18_Ta5000_r1).
Deliverable: LTRmix/ltrmix_plot.py exposing `overview(outdir)` (writes overview.png and overview.pdf with a short
  legend page generated from the run's own numbers) and a CLI `python ltrmix_plot.py OUTDIR`; no hard-coded taxa,
  chromosome names or sizes; runs in < 1 min on maize-size outputs; matplotlib only.
Panels: A (lead): recipient chromosomes, every informative element as a tick by class (donor-side ticks vermillion,
  sister-side blue), ancestry posterior trace, recent tracts (q ≤ 0.05 filled, others outlined); B: insertion D by
  age with ± 2 SE and the null 0; C: identity spectrum recipient-donor vs sister-donor (both drawn); D: the four
  genome-wide tests ± 2 SE.
Caveats: must not overstate: decoy tract counts shown next to tract counts.

## Fig. 4 `fig4_six_genomes` — Six genomes: positive controls, a SNP-calibrated gradient of gene flow, and its two directions
Story: with two genomes per taxon, LTR-RT libraries reproduce the known positive controls (a highland maize landrace
  carries more mexicana ancestry than B73, the mexicana Inv4m inversion and the mexicana HPC1 haplotype), scale with
  an outgroup SNP test across trios, and show that maize and both mexicana accessions share recent ancestry that
  mexicana-to-maize admixture alone cannot explain: three-genome tests see gene flow, not its direction.
  Mechanism: as Fig. 2; recent shared ancestry leaves near-identical orthologous LTR-RTs. Generality: maize/teosinte,
  six genomes (B73, PT, TIL01, TIL11, TIL18, TIL25).
  Main numbers (sources: results/six/analysis/trio_summary.tsv, ltr_vs_snp.tsv, six_findings.txt; results/forced/*;
  results/six/blocks.tsv; results/six/orthologs.*.tsv.gz):
  - PT vs B73 (donor TIL18): D_kmer +0.068 (Z 3.3), D_ins +0.132 (Z 4.6); vs parviglumis TIL01: PT +0.164 (Z 10.1)
    vs B73 +0.111 (Z 6.5).
  - Inv4m: B73-PT inverted block chr4:173.21-187.84 Mb (25 anchors); B73-TIL18 172.85-187.84 (26); B73-TIL25
    172.85-187.89 (27); none vs TIL11; B73-TIL01 a different inversion 162.53-183.12 (223).
  - HPC1 (B73 v5 chr3:8.50 Mb; PT chr3 ~9.04-9.08 Mb): PT with TIL25 as donor, posterior up to 0.999 from 1-3
    TIL25-shared elements; B73 parviglumis-like (posterior <= 0.09).
  - LTR vs SNP over 7 trios: D_kmer r = 0.99 (slope 0.75), D_ins r = 1.00 (slope 1.34), D3 r = 0.86, D_self r = 0.71.
  - Near-identical orthologs (< 0.2%): TIL18 with B73 25%, PT 30%, TIL25 10%, TIL01 8%; TIL25 with B73 19%, PT 22%,
    TIL01 12%; B73-PT 57%; TIL01-TIL11 18%. Median ortholog divergence for all 15 pairs (compute from the ortholog
    tables: present pairs, column divergence).
  - Controls: TIL11 vs TIL01 with TIL18: D_kmer Z 1.9, D_ins 1.2, D3 3.2, D_self 4.1, SNP Z 3.0 (a real asymmetry);
    with TIL25: all |Z| <= 0.5. Forced TIL18 vs TIL25 with B73 / PT as donor: |Z| <= 1.8 (SNP Z 2.0).
Data:
  numbers: as above; results/six/<trio>/stats.tsv for any trio; gene_snp/gene_abba_baba.<P1>_<P2>_<P3>.tsv (per-gene
    ABBA/BABA counts) and gene_snp/gene_abba_baba.tsv (B73,TIL01;TIL18).
  raw data to draw from: results/six/blocks.tsv (collinear blocks, all 15 pairs; sign), orthologs.<A>.<B>.tsv.gz
    (every 1:1 ortholog with positions and divergence), results/six/<trio>/elements.<R>.tsv (classes, posteriors),
    libraries run/{B73v5,TIL18,TIL01}_LTRs_* and ltrquest_extra/{PT,TIL25,TIL11}_LTRs_* (FASTA/TSV/GFF3), assemblies
    inputs/<G>.fa (+.fai). Genes: benchmark/truth/loci.v5.tsv (HPC1, ZmLPCAT1, ZmPRR37a).
Panels (suggested; the figure agent sketches 2-3 layouts and chooses):
  A (lead): chr4 around Inv4m (~160-200 Mb) for all six genomes stacked at one bp scale, every 1:1 ortholog anchor
     of each genome with B73 drawn as a link, inverted blocks highlighted; PT, TIL18 and TIL25 inverted relative to B73,
     TIL11 collinear, TIL01 its own inversion; published Inv4m breakpoints marked.
  B: HPC1 neighborhood (B73 chr3 ~8.3-8.7 Mb and the syntenic PT stretch), every element of B73, PT, TIL25 and TIL01 to
     size, ortholog links colored by near-identity (PT-TIL25 vs B73-TIL01), posterior traces.
  C: LTR-RT D (k-mers and insertions) against SNP D for the seven trios, ± 2 SE both ways, 1:1 line and zero lines;
     labels name the trios.
  D: the six-genome near-identity matrix (share of 1:1 orthologs < 0.2% divergent), or a network of the 15 pairs,
     showing maize-mexicana pairs above mexicana-mexicana.
  E: every trio's D_kmer ± 2 SE (or Z) as points, grouped by question (maize vs parviglumis with mexicana donor; PT vs
     B73; teosinte-only controls), the zero line drawn.
Example: panel B: HPC1 as named (Barnes et al. 2022); structural check on the drawn TIL25-shared PT elements (TSD,
  TG..CA, LTR divergence). Panel A: Inv4m as named; draw all anchors, no selection.
Caveats for the long legend: one genome per accession; PT_MEXI5 is a Toronto Agreement release; HPC1 call rests on
  1-3 informative elements; the TIL11/TIL01 "negative control" is asymmetric by SNPs too; direction of gene flow is
  not identified (both mexicana accessions share recent ancestry with maize; maize-to-mexicana gene flow or maize
  ancestry in the inbred lines are both possible); the pre-registered direction trio could not be formed (data pair
  B73 + TIL18) and the forced trios are post hoc; the f-ratio is not estimable; the spike-in was uninformative
  (TIL25 is no closer to TIL18 than parviglumis is).
Colors: maize (B73, PT) dark gray/black; mexicana (TIL18, TIL25) vermillion; parviglumis (TIL01, TIL11) blue; links
  gray unless near-identical (accent by pair type).

## Fig. 5 `fig5_generality` — The same signal in two more admixture events: a wild *Zea* exchange and sweet orange
Story: insertions shared nearly unchanged with one relative and absent from the other mark gene flow outside the
  maize benchmark too, under a different annotator (EDTA) and in a eudicot with a 300-Mb genome; where admixture is a
  few generations old, the same elements paint Mb-long introgressed tracts that match the published ones.
  Mechanism: as Fig. 2 (insertions younger than a split can be shared only by gene flow; recent gene flow leaves long
  tracts of near-identical copies). Generality: three independent admixture events (maize–mexicana; huehuetenangensis
  and parviglumis–Luxuriantes; pummelo × mandarin in sweet orange), two annotators.
  Main numbers (sources: lineage2/eval/trios.tsv, tracts.tsv, truth_tracts.tsv; lineage2/out/<trio>/stats.tsv;
  genus/wgk/wgk_trio.tsv; genus/out/<trio>/stats.tsv; results/main3/stats.tsv):
  - sweet orange CsB (pummelo-derived haplotype, 12.6% mandarin by Wu et al. 2023): D_kmer +0.315 (Z 4.0), D_ins
    +0.469 (Z 4.8), D_self +0.549 (Z 5.3); element AUROC 0.995; posterior 0.98 inside true tracts vs 0.04 outside;
    all 4 true tracts >= 1.7 Mb called (69-100% covered), the 3 <= 1.1 Mb (0-5 elements) missed; called tracts 42.7 Mb,
    bp precision 0.84, recall 0.95; no tract at q <= 0.05 (15 tracts vs 4 decoys); identity spectrum 197 vs 1
    orthologs below 0.2%; D_ins 0.86-1.00 for K2P <= 0.02 vs 0.21-0.28 above 0.05.
  - CsA (mandarin-derived, 2.9% pummelo): genome-wide |Z| <= 1.2; recent model calls the 7.5-Mb chr2 tract (66%).
  - controls: sour orange haplotypes |Z| <= 2.0, tracts = decoys.
  - Zea: nicaraguensis (Zn) as donor, k-mer D, whole assemblies: Zh vs TIL18 +0.139 (Z 15.0), TIL01 vs TIL18 +0.109
    (Z 18.3), Zh vs TIL01 +0.036 (Z 3.6), control TIL25 vs TIL18 -0.010 (Z -1.7); library k-mer D +0.177 / +0.121 /
    +0.061 / +0.013 (Z 17.0 / 17.9 / 5.7 / 1.7).
Data:
  numbers: as above. Citrus per-element: lineage2/out/CsB_Cr_Cm/elements.CsB.tsv (class, orthologs, divergences,
    post_ancestry_Cr, post_recent_Cr), tracts.CsB.bed, ancestry.CsB.bed, decoy_tracts.Cm.bed, blocks.tsv (in
    lineage2/out/), orthologs.<A>.<B>.tsv.gz (lineage2/out/); truth: lineage2/truth/CsB.M.bed, CsA.P.bed,
    DVS_segments.tsv (all segments, M/P). Genus window tallies: genus/wgk/wgk_trio.<R>_<S>_<D>.tsv (single-copy
    k-mers per 100-kb window of the donor: with_R, with_S).
  raw data to draw from: citrus assemblies inputs/{CsA,CsB,Cr,Cm,CaM,CaP}.fa (+.fai; samtools faidx), LTR-RT
    libraries lineage2/ltrquest_a/{CsA,CsB,Cr}_LTRs_depth*_clean_ltr.{fa,tsv} and ltrquest_b/{Cm,CaM,CaP}_...; GFF3
    <G>_LTRs_all_depth_LTR_cleaned.gff3 in the same folders. Labels: CsA = Valencia sweet orange DVS_A (mandarin-
    derived haplotype), CsB = DVS_B (pummelo-derived), Cr = Sun Chu Sha Kat mandarin (hap1), Cm = Guanximiyou
    pummelo, CaM / CaP = sour orange mandarin / pummelo haplotypes. Zea: inputs/{Zh,Zn,TIL18,TIL01,TIL25}.fa;
    EDTA libraries genus/{Zh,Zn,TIL25}.edta.{fa,tsv}, edta/{TIL01,TIL18}.edta.{fa,tsv}.
Panels (suggested; the figure agent sketches 2-3 layouts and chooses):
  A (lead): the nine CsB chromosomes at one bp scale, every informative element a tick (near-identical to the
     mandarin copy / mandarin-only insertion in vermillion above; to the pummelo copy below in blue), the ancestry
     posterior as a thin trace, the called tracts, and the published mandarin tracts as a thin bluish-green bar
     (truth, never filled); under each, the sister pummelo (Cm) homolog at the same scale with its decoy tracts.
  B: zoom across one tract boundary (typical; e.g., the chr3 43.3-Mb boundary of the 7.2-Mb tract): every element to
     size, joined to its Cr and Cm orthologs, colored by which copy is near-identical.
  C: one element at base-pair scale: shared by CsB and the mandarin Cr (near-identical, same TSD at both ends) and
     absent from the pummelo Cm (empty site with one TSD copy), from the assemblies.
  D: D_ins by insertion age for CsB (both counts shown per stratum), with the two sour-orange control trios drawn as
     the null.
  E: the Zea event: per-chromosome k-mer D on whole assemblies (Zh vs TIL18, TIL01 vs TIL18, control TIL25 vs TIL18;
     donor Zn), one point per chromosome, joined across comparisons; zero line drawn.
  F: every admixture event and control as points: D_kmer ± 2 SE for maize B73 (Fig. 1-2 numbers), Zh, TIL01,
     citrus CsB, CsA, and the controls (two-mexicana, two sour-orange); n or Z beside each.
Example: panel C: among CsB elements inside true mandarin tracts whose class is donor_only or near_donor and whose
  Cm status is absent, the one closest to the medians of K2P and length of all such elements; checks before drawing:
  identical 5-bp TSD at both ends in CsB and Cr, TG..CA ends, the Cm empty site found by aligning both flanks
  (single TSD copy), LTR divergence consistent with the annotation. Panel B: the boundary whose flank posteriors are
  closest to the median of all tract boundaries; say why on the long legend page.
Caveats for the long legend: the citrus truth is SNP-based (Wu B. et al. 2023 Hortic Res, Suppl. Table 4) and the two
  published truth sets disagree on phasing in places (chr9 among them); calls at the starts of chr5 (0-2 Mb) and chr9
  (0-3 Mb) fall outside the truth and are unverified; no citrus tract reaches q <= 0.05 because 15 tracts and 4 decoys
  cannot certify any under the +1 target-decoy rule; CsA's 2.9% is below genome-wide power; for the Zea event only the
  k-mer tests are used (insertion tests need synteny with the donor, which nicaraguensis lacks for 42-65% (mexicana genomes) of its
  elements); Zn stands in for the Luxuriantes (no EDTA calls for Z. luxurians); one genome per taxon.
Colors: donor-like / mandarin-like = vermillion #D55E00; sister-like / pummelo-like = blue #0072B2; published truth
  = bluish green #009E73 (thin line or outline, never filled); context gray. Taxa italic.
