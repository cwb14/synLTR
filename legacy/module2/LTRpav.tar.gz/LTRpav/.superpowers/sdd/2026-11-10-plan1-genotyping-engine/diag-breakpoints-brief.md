# Diagnostic: why the mm2 route leaves ~45% of real chr10 elements unresolved

You are investigating, not fixing. Nothing in the repo changes; you write a report and scratch files.

## Context
- LTRpav (repo `/data2/chris/maize_introgression/LTRpav`, branch `plan1-engine`, HEAD bfeeb55) genotypes LTR-RT
  presence/absence between genome assemblies. For a pair A->B the engine runs:
  route (raw alignment blocks) -> `chain.chain_blocks` -> `chain.net_blocks` -> `window.make_windows` -> local
  alignment per window -> `classify`.
- `net_blocks` is a flat greedy net: best chain first, and each later chain claims the A and B positions still
  unclaimed if it keeps >= MIN_CHAIN_SCORE (1,000) matches. It has no synteny classes (no top/syn/inv/nonSyn as in
  UCSC netClass). Each kept block carries a margin over the best competing chain.
- `make_windows` (`src/ltrpav/window.py`) takes up to NCAND = 3 nearest blocks of >= ANCHOR_MIN (100) bp on each
  side of an element, within WINDOW_CAP (500 kb). The window is U "breakpoint" when no left/right pair is on the
  same B sequence and strand and in order. It is U "span_cap" when the only consistent pairs are more than
  WINDOW_CAP apart.
- DESIGN.md 5.1 (`docs/DESIGN.md`) defines an anchor as "a stretch of A aligned 1:1 to B in an orthologous
  (collinear, uniquely best) chain". The W route "keep[s] a 1:1 orthologous chain set (best chain per position on
  both genomes)".

## Observation to explain
From `task-24a-report.md` (same directory as this brief), concern 1. On chr10, B73v5 -> TIL18, the mm2 route
gives:
- 5,671 windows: 3,013 ok, 2,054 breakpoint, 604 span_cap;
- 4,295 U calls of 9,064 (2,890 in breakpoint windows, 857 in span_cap windows).

With AnchorWave's collinear chr10 alignment as anchors (the `paf:` route, `chr10/runs/awpaf`), the same pair has
42 breakpoint windows and 2,174 U calls.

**Hypothesis to test, not to assume.** The flat net admits short paralogous chains into the gaps of the
orthologous chains, where 50-60% of chr10 is unshared between these lines. An element's nearest anchors then
land on paralogs in different places in B.

## Data
All paths are under `D = /data2/chris/maize_introgression/benchmark_pav/bakeoff`. Read `D/memo_bakeoff.md` and
`D/PARAMS.md` first.

**chr10 mm2 run:** `D/chr10/runs/mm2/`, three genomes (B73v5, TIL18, TIL01), all six directions.
- `work/anchors/<A>__<B>.mm2.raw.npz`: raw blocks.
- `work/anchors/<A>__<B>.mm2.npz`: netted blocks.
- `work/windows/<A>__<B>.tsv.gz`: windows.
- `pairs/<A>__<B>.calls.tsv.gz`: calls.
- `work/elements/<G>.tsv`: elements (`ltrpav.elements.read_elements`).

**AnchorWave read-out and anchors:**
- `D/chr10/anchorwave_readout/`, which includes `segments.npz` (gap-free MAF segments) and the read-out calls;
- `D/chr10/awpaf/B73v5__TIL18.paf`;
- the `paf:` run `D/chr10/runs/awpaf/`, with the same work layout.

**Inputs:** FASTAs and annotations in `D/chr10/fasta`, `D/chr10/annot`; sample sheets `D/chr10/samples*.tsv`.

**Sims:** `D/sims/<sim>/` and runs `D/runs/<sim>/<variant>/`, same layout. The sims batch is still running, so
use only runs whose `status.json` exists.

## Questions
1. **Cross-tab.** For every B73v5 -> TIL18 element, tabulate the mm2 window status, the awpaf window status and
   the two calls. Do the same for TIL18 -> B73v5.
   - Report the breakpoint and span_cap fractions for all six chr10 mm2 directions.
   - Report the same fractions for the finished sim mm2 runs, to show whether the sims reproduce the problem.
2. **Breakpoint causes.** Take the elements that are breakpoint under mm2 but ok under awpaf. For each of mm2's
   candidate blocks (up to 3 + 3 per element), find:
   - its chain: A span, B span, number of blocks, score, and whether it is the region's top chain or a fill
     inside a better chain's gap;
   - its B placement relative to AnchorWave's collinear path. "On path" means its B interval lies between the
     AnchorWave-aligned B bases bracketing its A interval; otherwise it is off path.

   Classify each window's cause:
   - (i) off-path fills among the candidates;
   - (ii) mm2's top chains disagree with AnchorWave, a candidate real rearrangement;
   - (iii) other, described.

   Give counts, and look at least 10 examples as dotplots of A window vs B region with mm2 blocks and AnchorWave
   segments. Load the `making-figures` skill first and follow its quick-plot rules.
3. **span_cap.** The same question for span_cap windows. Are they large unshared regions where AnchorWave's
   window is also wide?
4. **Net composition.** How much of the mm2 net (A bp and blocks) comes from kept chains that are not collinear
   with the chain whose gap they fill (UCSC netClass sense)?
   - nonSyn: the B span lies outside the parent's corresponding B gap.
   - inv: same sequence, opposite strand.

   Report this for chr10 and for a sim. Also check whether the blocks behind breakpoints have low margins, i.e.
   whether the existing margin already marks them.
5. **Fix.** Propose one, and write the proposal into the report **before measuring anything**:
   - the rule, every parameter and the reason for its value;
   - the literature behind it: UCSC chainNet/netClass/netFilter `-syn` (Kent et al. 2003, PNAS), AnchorWave's
     collinearity, or anything else you find;
   - how it treats real inversions, real transpositions and unplaced or scaffold-rich assemblies;
   - its runtime cost.

   Prefer a rule with no new threshold. For example, a fill counts as collinear when its B span lies inside its
   parent's B gap on the same sequence; on the opposite strand it is an inversion.

   Then prototype the rule in a scratch script (a wrapper or monkeypatch, no repo change) and measure it once:
   - **chr10 B73v5 -> TIL18:** re-net the cached raw blocks and rebuild the windows. Report the status counts,
     then genotype, either with `ltrpav-genotype --pair` on a copied workdir or an equivalent wrapper.
     - Report call counts.
     - Report agreement with the AnchorWave read-out. Give P/E agreement separately from the missing states.
     - For windows ok under both the old and new net, report whether the B placement changed.
   - **Sims:** run the patched mm2 route on two sims (R1_s1 and R2_s1). Score them with `ltrpav-sim score`
     against `truth.tsv` and report before/after summary rows and the high-tier P/E precision. The "before"
     values are the batch's own mm2 runs.

   Do not sweep parameters. Do not choose between variants by agreement with AnchorWave or the sim truth: those
   are yardsticks, not training data. Report the outcome, whatever it is. If the measurement shows the rule
   is wrong for a reason you can name independently of those scores, say so and propose (do not measure) a
   correction.

## Constraints
- **Read-only:** the repo; everything under `D` except your own directory `D/diag_breakpoints/`, where every
  script, table, figure and scratch run goes; `/data2/chris/maize_introgression/run/` and `inputs/`.
- **Running jobs:** two bake-off batches are running detached, PIDs 3523920 (sims) and 662846 (chr10). Never
  signal them, never write into their outdirs, never delete anything outside your directory.
- **Compute:** at most 4 threads in total for your probes. Bound each probe with `timeout 15m`, run it in the
  foreground and detach nothing.
- **Environment:** `ltrpav_bench` (`mamba run -n ltrpav_bench ...` or its python). Export
  `NUMPY_MADVISE_HUGEPAGE=0` for every Python process; without it, numpy imported before ltrpav can stall for
  minutes in the kernel.
- No subagents. American English. Never load whole genomes into memory beyond what the engine itself does.

## Report
Write `diag-breakpoints-report.md` in the same directory as this brief:
- answers to questions 1-5 with tables;
- the proposal exactly as written before measuring, followed by the measurement;
- what the dotplots showed, one line each;
- what would make you doubt the conclusion.

Return ONLY:
- status;
- the cause in 2-3 sentences, with key counts;
- the proposed fix in 2-3 sentences, with its measured effect;
- concerns;
- the report path.
