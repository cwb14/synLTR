"""Validation on main3 (read-only view): realigned LTR-LTR divergence (self rows) against the annotation's K2P
of the same copies, on a seeded sample of the layer's loci. Usage: selfk_main3.py VIEW N_LOCI THREADS"""
import sys
from pathlib import Path
import numpy as np
from ltrpav.samples import read_samples
from ltrpav.analysis.catalog import load_catalog, STATE_CODE
from ltrpav.analysis.relations import pav_distances, discover
from ltrpav.analysis.trio import Trio
from ltrpav.analysis.paint import RD, classes
from ltrpav.analysis import identity as idm

view, n_sample, threads = Path(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
cat = load_catalog(view, read_samples(view / "samples.tsv"), view / "samples.tsv")
R, S, D = "B73", "TIL01", "TIL18"
gd = cat.g(D)
c = discover(cat, R, S, D, pav_distances(cat)[0], "E")
pmask = {y: cat.member[:, gd] & (cat.proj[D][:, cat.g(y)] == STATE_CODE["P"]) for y in (R, S)}
idx, cls = classes(cat, R, S, D)
reads = c.rows.copy(); reads[idx[cls == RD]] = True
for m in pmask.values():
    reads |= m
loci = np.flatnonzero(reads)
rng = np.random.default_rng(2)
loci = np.sort(rng.choice(loci, size=n_sample, replace=False))
copies = [g for g in cat.labels if g in (R, S, D)]
elements = {g: idm._elements(cat, g, loci) for g in copies}
jobs = [(idm._job(cat, int(i), copies, elements, pmask, D)[0], None) for i in loci]   # self alignments only
res = idm._align_all(cat, jobs, threads)
div, k2p = [], []
for i, (selfs, _), (rs, _) in zip(loci, jobs, res):
    for (g, *_), (sites, diffs) in zip(selfs, rs):
        kk = cat.k[i, cat.g(g)]
        if sites >= 80 and np.isfinite(kk):
            div.append(diffs / sites); k2p.append(kk)
div, k2p = np.array(div), np.array(k2p)
p = 1 - np.exp(-k2p)  # rough inverse for comparison only (K2P >= p): use the raw K too
print(f"{len(div)} copies with a self row and an annotation K2P")
print(f"Pearson r(div, K2P) = {np.corrcoef(div, k2p)[0, 1]:.4f}; Spearman r = "
      f"{np.corrcoef(np.argsort(np.argsort(div)), np.argsort(np.argsort(k2p)))[0, 1]:.4f}")
print(f"median div {np.median(div):.5f}, median K2P {np.median(k2p):.5f}; median |div - K2P| {np.median(np.abs(div - k2p)):.5f}")
print(f"div == 0: {int((div == 0).sum())}, K2P == 0: {int((k2p == 0).sum())}, both 0: {int(((div == 0) & (k2p == 0)).sum())}")
print(f"|div - K2P| > 0.01: {int((np.abs(div - k2p) > 0.01).sum())} ({np.mean(np.abs(div - k2p) > 0.01):.3f})")
