#!/usr/bin/env python3
"""Insertions provably younger than a split, shared across it: per-element upper bounds on insertion age.

For each donor (D) element shared with exactly one sister (present in one, absent from the other, from the donor's
ortholog tables), the donor copy's LTR-LTR differences d over n aligned sites give a one-sided 95% Poisson upper bound
on the insertion age: t95 = lambda95(d) / (2 mu n), lambda95 = chi2.ppf(0.95, 2(d+1)) / 2. An insertion with t95 below
the split time cannot be shared through lineage sorting, only through gene flow. Counts both sister patterns."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import argparse
import glob

import numpy as np
import pandas as pd
from scipy.stats import chi2


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--lib", required=True, help="donor LTRquest prefix (reads PREFIX_depth*_clean_ltr.tsv)")
    ap.add_argument("--orth-r", required=True, help="orthologs.D.R.tsv.gz (donor records, status in recipient)")
    ap.add_argument("--orth-s", required=True, help="orthologs.D.S.tsv.gz (donor records, status in sister)")
    ap.add_argument("--mu", type=float, default=3e-8, help="substitutions per site per year [3e-8]")
    ap.add_argument("--bounds", default="10000,20000,30000,45000,60000", help="age bounds in years")
    ap.add_argument("--out", required=True, help="output TSV")
    a = ap.parse_args()
    t = pd.concat([pd.read_csv(f, sep="\t", usecols=["#seq_id", "n_sites", "n_ts", "n_tv", "k2p"])
                   for f in sorted(glob.glob(a.lib + "_depth*_clean_ltr.tsv"))])
    t = t.rename(columns={"#seq_id": "name"}).drop_duplicates("name").set_index("name")
    r = pd.read_csv(a.orth_r, sep="\t")
    s = pd.read_csv(a.orth_s, sep="\t")
    R, S = r.columns[5].replace("status_in_", ""), s.columns[5].replace("status_in_", "")
    m = pd.DataFrame({"inR": r.set_index(r.columns[0]).iloc[:, 4], "inS": s.set_index(s.columns[0]).iloc[:, 4]})
    m = m.join(t, how="inner")
    d = (m.n_ts + m.n_tv).astype(float)
    lam = chi2.ppf(0.95, 2 * (d + 1)) / 2
    m["t95"] = lam / (2 * a.mu * m.n_sites.clip(lower=1))
    pats = {f"{R}+D": (m.inR == "present") & (m.inS == "absent"), f"{S}+D": (m.inS == "present") & (m.inR == "absent")}
    rows = []
    for b in [int(x) for x in a.bounds.split(",")]:
        row = dict(bound_yr=b)
        for k, sel in pats.items():
            row[k] = int((sel & (m.t95 < b)).sum())
        A, B = row[f"{R}+D"], row[f"{S}+D"]
        row["D"] = (A - B) / (A + B) if A + B else np.nan
        rows.append(row)
    out = pd.DataFrame(rows)
    out.to_csv(a.out, sep="\t", index=False)
    print(f"donor elements with both statuses known: {len(m):,}; all shared: "
          + ", ".join(f"{k} {int(v.sum()):,}" for k, v in pats.items()))
    print(out.to_string(index=False))
    zero = m[(d == 0)]
    print(f"identical LTRs: median aligned sites {zero.n_sites.median():.0f}; t95 for the median {3.0 / (2 * a.mu * zero.n_sites.median()) / 1e3:.0f} kyr")


if __name__ == "__main__":
    main()
