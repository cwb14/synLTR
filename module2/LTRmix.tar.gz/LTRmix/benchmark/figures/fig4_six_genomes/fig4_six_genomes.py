#!/usr/bin/env python3
"""Fig. 4 (fig4_six_genomes): six genomes -- positive controls (Inv4m, HPC1, highland maize PT), LTR-RT D against an
outgroup SNP D, maize-mexicana near-identity, and every trio.

Rebuilds everything from the six-genome ltrmix run (benchmark/results/six), the forced-role trios
(benchmark/results/forced), the gene-space SNP logs (benchmark/gene_snp), the LTR-RT library tables (run/,
benchmark/ltrquest_extra/) and the assemblies (inputs/, read with samtools faidx; the HPC1 gene placed in each genome with
minimap2; empty sites found by edlib flank alignment). Writes fig4_six_genomes.pdf (figure + short legend + long
legend), fig4_six_genomes.png (300 dpi, figure only) and fig4_six_genomes_numbers.tsv into this script's folder; caches
parsed inputs in ./work (delete work/*.pkl or pass --rebuild to re-read every input).

Run:  source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix; python fig4_six_genomes.py [-v] [--rebuild]
"""
import argparse
import glob
import itertools
import os
import re
import subprocess
import sys

os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on the shared server
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib import font_manager  # noqa: E402
from matplotlib.backends.backend_pdf import PdfPages  # noqa: E402
from matplotlib.collections import LineCollection, PolyCollection  # noqa: E402
from matplotlib.patches import Rectangle, Polygon  # noqa: E402
from matplotlib.textpath import TextToPath  # noqa: E402
import edlib  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(HERE, "work")
ROOT = "/data2/chris/maize_introgression"
BENCH = f"{ROOT}/benchmark"
SIX = f"{BENCH}/results/six"
FORCED = f"{BENCH}/results/forced"
GSNP = f"{BENCH}/gene_snp"
INPUTS = f"{ROOT}/inputs"
LIBDIR = {"B73v5": f"{ROOT}/run", "TIL01": f"{ROOT}/run", "TIL18": f"{ROOT}/run",
          "PT": f"{BENCH}/ltrquest_extra", "TIL25": f"{BENCH}/ltrquest_extra", "TIL11": f"{BENCH}/ltrquest_extra"}
STEM = "fig4_six_genomes"
DATE = "2026-11-07"
VERBOSE = False

# colors fixed across the benchmark figures (SPEC.md shared block)
MEX, PAR, MAIZE, CTX, ELAI = "#D55E00", "#0072B2", "#333333", "#BBBBBB", "#009E73"
MEX_L, PAR_L = "#EDB48A", "#8CBFDC"
OLD, OLD_INV, PALE = "#C4C4C4", "#8C8C8C", "#D9D9D9"
CLASS_COL = {"near_donor": MEX, "donor_only": MEX_L, "near_sister": PAR, "sister_only": PAR_L,
             "near_both": "#777777", "shared": "#999999", "private": PALE, "unresolved": "#FFFFFF"}
G6 = ["TIL01", "TIL11", "B73v5", "PT", "TIL25", "TIL18"]          # row order (parviglumis, maize, mexicana)
LAB = {"B73v5": "B73", "PT": "PT", "TIL01": "TIL01", "TIL11": "TIL11", "TIL18": "TIL18", "TIL25": "TIL25"}
TAXON = {"B73v5": "maize", "PT": "maize", "TIL01": "parviglumis", "TIL11": "parviglumis", "TIL18": "mexicana",
         "TIL25": "mexicana"}
TCOL = {"maize": MAIZE, "parviglumis": PAR, "mexicana": MEX}
GCOL = {g: TCOL[TAXON[g]] for g in G6}
MARK = {"B73v5": "o", "PT": "D", "TIL01": "o", "TIL11": "D", "TIL18": "o", "TIL25": "D"}
MSIZE = {"o": 13, "D": 10}
NEAR = 0.002                                                       # near-identical: < 0.2% divergence (A, E)
MM = 1 / 25.4
FIG_W, FIG_H = 180.0, 238.0
RATE = 3e-8

INV4M_LIT = (172_883_881, 188_131_462)      # published Inv4m, B73 v5 (as in Fig. 1)
A_WIN = (150_000_000, 205_000_000)          # panel A window on B73 chr4
HPC1_FLANK = 200_000                        # panel B: +-200 kb around each genome's HPC1 copy
HPC1_SEARCH = {"B73v5": ("B73v5_chr3", 8_200_000, 8_800_000), "PT": ("PT_chr3", 8_700_000, 9_400_000),
               "TIL25": ("TIL25_chr3", 7_700_000, 8_400_000), "TIL01": ("TIL01_chr3", 8_300_000, 9_100_000)}
B_ROWS = ["TIL01", "B73v5", "PT", "TIL25"]
B_TRIO = {"B73v5": "B73v5_TIL01_TIL25", "PT": "TIL01_PT_TIL25"}   # recipient, sister TIL01, donor TIL25

# panel F: every trio, grouped by question: (dir, recipient, sister, donor); "forced:" = results/forced
F_GROUPS = [
    ("maize vs |parviglumis|, |mexicana| donor", [
        ("B73v5_TIL18_TIL01", "B73v5", "TIL01", "TIL18"), ("TIL18_TIL01_PT", "PT", "TIL01", "TIL18"),
        ("B73v5_TIL18_TIL11", "B73v5", "TIL11", "TIL18"), ("TIL18_PT_TIL11", "PT", "TIL11", "TIL18"),
        ("B73v5_TIL01_TIL25", "B73v5", "TIL01", "TIL25"), ("TIL01_PT_TIL25", "PT", "TIL01", "TIL25"),
        ("B73v5_TIL25_TIL11", "B73v5", "TIL11", "TIL25"), ("PT_TIL25_TIL11", "PT", "TIL11", "TIL25")]),
    ("PT vs B73, |mexicana| donor", [
        ("B73v5_TIL18_PT", "PT", "B73v5", "TIL18"), ("B73v5_PT_TIL25", "PT", "B73v5", "TIL25")]),
    ("two |parviglumis|, |mexicana| donor", [
        ("TIL18_TIL01_TIL11", "TIL11", "TIL01", "TIL18"), ("TIL01_TIL25_TIL11", "TIL11", "TIL01", "TIL25")]),
    ("|mexicana| paired with another taxon", [
        ("B73v5_TIL18_TIL25", "B73v5", "TIL18", "TIL25"), ("TIL18_PT_TIL25", "PT", "TIL18", "TIL25"),
        ("TIL18_TIL01_TIL25", "TIL25", "TIL01", "TIL18"), ("TIL18_TIL25_TIL11", "TIL25", "TIL11", "TIL18")]),
    ("maize or |parviglumis| donor", [
        ("B73v5_PT_TIL11", "B73v5", "PT", "TIL11"), ("B73v5_TIL01_PT", "B73v5", "PT", "TIL01"),
        ("B73v5_TIL01_TIL11", "TIL11", "B73v5", "TIL01"), ("TIL01_PT_TIL11", "TIL11", "TIL01", "PT")]),
    ("roles forced (post hoc)", [
        ("forced:TIL18_TIL25__B73v5", "TIL18", "TIL25", "B73v5"), ("forced:TIL18_TIL25__PT", "TIL18", "TIL25", "PT"),
        ("forced:TIL01_TIL11__B73v5", "TIL11", "TIL01", "B73v5")]),
]


def log(msg, verbose_only=False):
    if verbose_only and not VERBOSE:
        return
    print(f"[{STEM}] {msg}", file=sys.stderr, flush=True)


# ---------------------------------------------------------------------------------------------------------------------
# style
# ---------------------------------------------------------------------------------------------------------------------
def setup_style():
    for f in ("LiberationSans-Regular", "LiberationSans-Bold", "LiberationSans-Italic", "LiberationSans-BoldItalic",
              "LiberationMono-Regular", "LiberationMono-Bold"):
        for d in ("/usr/share/fonts/truetype/liberation", "/usr/share/fonts/truetype/liberation2"):
            p = f"{d}/{f}.ttf"
            if os.path.exists(p):
                font_manager.fontManager.addfont(p)
                break
    plt.rcParams.update({
        "font.family": "Liberation Sans", "font.size": 6.5, "pdf.fonttype": 42, "ps.fonttype": 42,
        "axes.linewidth": 0.5, "axes.labelsize": 6.5, "xtick.labelsize": 6, "ytick.labelsize": 6,
        "xtick.major.width": 0.5, "ytick.major.width": 0.5, "xtick.major.size": 2, "ytick.major.size": 2,
        "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
        "mathtext.fontset": "custom", "mathtext.rm": "Liberation Sans", "mathtext.it": "Liberation Sans:italic",
        "mathtext.bf": "Liberation Sans:bold", "mathtext.cal": "Liberation Sans:italic",
        "mathtext.sf": "Liberation Sans"})


def it(s):
    """Italic via mathtext, spaces and hyphens kept."""
    return r"$\mathit{" + s.replace(" ", r"\ ").replace("-", r"\text{-}") + "}$"


def mixed(s):
    """'|word|' marks italic stretches."""
    parts = s.split("|")
    return "".join(it(p) if k % 2 else p for k, p in enumerate(parts) if p)


MONO = font_manager.FontProperties(family="Liberation Mono", size=5.6)
MONO_W = 0.6001 * 5.6 * 25.4 / 72  # mm per character
_T2P = TextToPath()


def text_w(s, size):
    """Rendered width (mm) of a label, mathtext italics measured as plain text."""
    plain = re.sub(r"\$\\mathit\{(.*?)\}\$", lambda m: m.group(1).replace(r"\ ", " ").replace(r"\text{-}", "-"), s)
    fp = font_manager.FontProperties(family="Liberation Sans", size=size)
    w, _, _ = _T2P.get_text_width_height_descent(plain, fp, ismath=False)
    return w / 72 * 25.4


# ---------------------------------------------------------------------------------------------------------------------
# data
# ---------------------------------------------------------------------------------------------------------------------
def cached(name, fn):
    os.makedirs(WORK, exist_ok=True)
    p = os.path.join(WORK, f"{name}.pkl")
    if os.path.exists(p):
        return pd.read_pickle(p)
    log(f"building {name}", True)
    x = fn()
    pd.to_pickle(x, p)
    return x


def parse_ids(s):
    x = s.str.extract(r"^[^_]+_(?P<c>[^:]+):(?P<s>\d+)-(?P<e>\d+)#")
    return x.c, pd.to_numeric(x.s), pd.to_numeric(x.e)


def ortho(a, b):
    """1:1 orthologous LTR-RTs of genome a in genome b (present pairs; the two directions hold the same pairs)."""
    def f():
        t = pd.read_csv(f"{SIX}/orthologs.{a}.{b}.tsv.gz", sep="\t")
        t = t[t.iloc[:, 5] == "present"].copy()
        t = t.rename(columns={a: "id_a", b: "id_b"})
        t["c_a"] = t.chrom.str.split("_", n=1).str[1]
        t["s_a"], t["e_a"] = t.start, t.end
        t["c_b"], t["s_b"], t["e_b"] = parse_ids(t.id_b)
        return t[["id_a", "c_a", "s_a", "e_a", "id_b", "c_b", "s_b", "e_b", "divergence", "k2p"]].reset_index(drop=True)
    return cached(f"ortho_{a}_{b}", f)


def pair_identity():
    """Share of 1:1 orthologs below 0.2% divergence and median divergence, all 15 pairs (from the ortholog tables;
    pairs without a divergence value, 0.2-0.4%, are left out)."""
    def f():
        rows = []
        for a, b in itertools.combinations(["B73v5", "PT", "TIL18", "TIL25", "TIL01", "TIL11"], 2):
            t = ortho(a, b)
            d = t.divergence.values
            ok = np.isfinite(d)
            rows.append(dict(a=a, b=b, n=len(t), n_div=int(ok.sum()), n_near=int((d[ok] < NEAR).sum()),
                             share=float((d[ok] < NEAR).mean()), median=float(np.median(d[ok]))))
        return pd.DataFrame(rows)
    return cached("pair_identity", f)


def pair_blocks(a, b):
    """Collinear blocks (blocks.tsv) of genomes a, b on chr4 with a's span first."""
    bl = pd.read_csv(f"{SIX}/blocks.tsv", sep="\t")
    x = bl[(bl.genome_a == a) & (bl.genome_b == b)].copy()
    y = bl[(bl.genome_a == b) & (bl.genome_b == a)].copy()
    y = y.rename(columns={"chrom_a": "chrom_b", "start_a": "start_b", "end_a": "end_b",
                          "chrom_b": "chrom_a", "start_b": "start_a", "end_b": "end_a"})
    z = pd.concat([x, y], ignore_index=True)
    return z[z.chrom_a.str.endswith("_chr4") & z.chrom_b.str.endswith("_chr4")]


def inv4m_data():
    """Panel A: per genome its chr4 window (B73 A_WIN mapped through 1:1 orthologs: median position of the anchors
    within 1 Mb of each edge), every anchor between neighboring rows, segments inverted relative to B73."""
    def f():
        win = {"B73v5": A_WIN}
        for g in G6:
            if g == "B73v5":
                continue
            t = ortho("B73v5", g)
            t = t[(t.c_a == "chr4") & (t.c_b == "chr4")]
            ends = [float(np.median(t[(t.s_a > b - 1e6) & (t.s_a < b + 1e6)].s_b)) for b in A_WIN]
            win[g] = (min(ends), max(ends))
        anchors = []
        for a, b in zip(G6[:-1], G6[1:]):
            t = ortho(a, b)
            t = t[(t.c_a == "chr4") & (t.c_b == "chr4")]
            t = t[(t.s_a >= win[a][0]) & (t.e_a <= win[a][1]) & (t.s_b >= win[b][0]) & (t.e_b <= win[b][1])].copy()
            pb = pair_blocks(a, b)
            dom = 1 if pb[pb.sign == 1].n_anchor.sum() >= pb[pb.sign == -1].n_anchor.sum() else -1
            inv = np.zeros(len(t), bool)
            for r in pb[pb.sign != dom].itertuples():
                inv |= ((t.s_a >= r.start_a) & (t.e_a <= r.end_a) & (t.s_b >= r.start_b) & (t.e_b <= r.end_b)).values
            t["inverted"] = inv
            t["a"], t["b"] = a, b
            anchors.append(t)
        anchors = pd.concat(anchors, ignore_index=True)
        invseg = []
        for g in G6:
            if g == "B73v5":
                continue
            pb = pair_blocks("B73v5", g)
            dom = 1 if pb[pb.sign == 1].n_anchor.sum() >= pb[pb.sign == -1].n_anchor.sum() else -1
            for r in pb[pb.sign != dom].itertuples():
                if r.end_a >= A_WIN[0] and r.start_a <= A_WIN[1] and r.n_anchor >= 20:
                    invseg.append(dict(g=g, start=r.start_b, end=r.end_b, b73_start=r.start_a, b73_end=r.end_a,
                                       n_anchor=r.n_anchor))
        return dict(win=win, anchors=anchors, invseg=pd.DataFrame(invseg))
    return cached("inv4m", f)


def inv4m_stats(A):
    """Anchors inside vs outside the Inv4m span (each genome's B73-relative inverted segment; published span in B73)."""
    span = {"B73v5": INV4M_LIT}
    for r in A["invseg"].itertuples():
        if r.g in ("PT", "TIL25", "TIL18"):
            span[r.g] = (r.start, r.end)
    rows = []
    for (a, b), t in A["anchors"].groupby(["a", "b"], sort=False):
        g, col = (a, "s_a") if a in span else ((b, "s_b") if b in span else (None, None))
        ins = np.zeros(len(t), bool) if g is None else ((t[col] >= span[g][0]) & (t[col] <= span[g][1])).values
        for lab, m in (("inside", ins), ("outside", ~ins)):
            d = t.divergence.values[m]
            d = d[np.isfinite(d)]
            rows.append(dict(a=a, b=b, where=lab, n=int(m.sum()), median=float(np.median(d)) if len(d) else np.nan,
                             near=float((d < NEAR).mean()) if len(d) else np.nan, n_inv=int(t.inverted.values[m].sum())))
    return pd.DataFrame(rows)


def faidx(g, c, s, e):
    reg = f"{c}:{s}-{e}" if c.startswith(g + "_") else f"{g}_{c}:{s}-{e}"
    out = subprocess.run(["samtools", "faidx", f"{INPUTS}/{g}.fa", reg], capture_output=True, text=True,
                         check=True).stdout
    return "".join(out.split("\n")[1:]).upper()


def rc(s):
    return s[::-1].translate(str.maketrans("ACGTN", "TGCAN"))


def hpc1_genes():
    """HPC1 (B73 v5 chr3:8,497,916-8,499,434; truth/loci.v5.tsv) placed in PT, TIL25, TIL01 by minimap2 (asm20, one
    hit, + strand, > 97% identity asserted); differences between copies = NM of pairwise minimap2 alignments."""
    def f():
        loci = pd.read_csv(f"{BENCH}/truth/loci.v5.tsv", sep="\t").set_index("name")
        L = loci.loc["HPC1"]
        os.makedirs(WORK, exist_ok=True)
        gfa = os.path.join(WORK, "hpc1_B73v5.fa")
        with open(gfa, "w") as fo:
            fo.write(f">HPC1_B73v5\n{faidx('B73v5', f'chr{L.chrom}', int(L.start), int(L.end))}\n")
        pos = {}
        for g, (c, s, e) in HPC1_SEARCH.items():
            rfa = os.path.join(WORK, f"hpc1_search_{g}.fa")
            with open(rfa, "w") as fo:
                fo.write(f">{c}\n{faidx(g, c, s, e)}\n")
            out = subprocess.run(["minimap2", "-c", "-x", "asm20", "-t", "2", rfa, gfa], capture_output=True,
                                 text=True, check=True).stdout.strip().split("\n")
            hits = [x.split("\t") for x in out if x]
            assert len(hits) == 1, (g, hits)
            h = hits[0]
            assert h[4] == "+" and int(h[9]) / int(h[10]) > 0.97, h
            pos[g] = (c, s + int(h[7]), s + int(h[8]) - 1, int(h[9]), int(h[10]))
        seqs = {}
        for g, (c, s, e, _, _) in pos.items():
            p = os.path.join(WORK, f"hpc1_copy_{g}.fa")
            with open(p, "w") as fo:
                fo.write(f">{g}\n{faidx(g, c, s, e)}\n")
            seqs[g] = p
        diffs = {}
        for a, b in itertools.combinations(pos, 2):
            out = subprocess.run(["minimap2", "-c", "-x", "asm20", "-t", "1", seqs[b], seqs[a]], capture_output=True,
                                 text=True, check=True).stdout.strip().split("\n")[0].split("\t")
            nm = int([x for x in out if x.startswith("NM:i:")][0][5:])
            diffs[(a, b)] = diffs[(b, a)] = (nm, int(out[10]))
        return dict(pos=pos, diffs=diffs, b73=(int(L.start), int(L.end)))
    return cached("hpc1_genes", f)


def load_lib(g):
    """Every element of one LTR-RT library (all nesting depths): position, strand, LTR bounds, K2P, TSD, motif."""
    def f():
        rows = []
        for p in sorted(glob.glob(f"{LIBDIR[g]}/{g}_LTRs_depth*_clean_ltr.tsv")):
            rows.append(pd.read_csv(p, sep="\t", usecols=["#seq_id", "seq_len", "ltr5_start", "ltr5_end", "ltr3_start",
                                                          "ltr3_end", "k2p", "motif", "tsd", "strand", "family"],
                                    dtype={"tsd": str, "strand": str}))
        t = pd.concat(rows, ignore_index=True).rename(columns={"#seq_id": "name"})
        m = t.name.str.extract(r"^[^_]+_(?P<c>[^:]+):(?P<s>\d+)-(?P<e>\d+)#(?P<cls>.*)$")
        t["c"], t["start"], t["end"], t["te"] = m.c, m.s.astype(int), m.e.astype(int), m.cls
        return t
    return cached(f"lib_{g}", f)


def hpc1_data():
    """Panel B: every element of the four genomes within +-200 kb of their HPC1 copy, classes, posteriors, links."""
    H = hpc1_genes()

    def f():
        els, win = {}, {}
        for g in B_ROWS:
            c, s, e, _, _ = H["pos"][g]
            lo, hi = s - HPC1_FLANK, e + HPC1_FLANK
            win[g] = (c, lo, hi, s)
            lib = load_lib(g)
            x = lib[(lib.c == c.split("_", 1)[1]) & (lib.end >= lo) & (lib.start <= hi)].copy()
            x["rel_s"], x["rel_e"] = x.start - s, x.end - s
            if g in B_TRIO:
                el = pd.read_csv(f"{SIX}/{B_TRIO[g]}/elements.{g}.tsv", sep="\t")
                el = el[(el.chrom == c) & (el.end >= lo) & (el.start <= hi)]
                x = x.merge(el[["name", "class", "post_ancestry_TIL25", "div_TIL25", "div_TIL01"]], on="name",
                            how="left")
            els[g] = x.sort_values("start").reset_index(drop=True)
        links = []
        for a, b in zip(B_ROWS[:-1], B_ROWS[1:]):
            aa, bb = (a, b) if os.path.exists(f"{SIX}/orthologs.{a}.{b}.tsv.gz") else (b, a)
            t = ortho(aa, bb)
            ca, la, ha, _ = win[aa]
            cb, lb, hb, _ = win[bb]
            t = t[(t.c_a == ca.split("_", 1)[1]) & (t.s_a <= ha) & (t.e_a >= la) & (t.c_b == cb.split("_", 1)[1]) &
                  (t.s_b <= hb) & (t.e_b >= lb)].copy()
            t["ga"], t["gb"] = aa, bb
            links.append(t)
        return dict(els=els, win=win, links=pd.concat(links, ignore_index=True))
    return cached("hpc1", f)


def example_data():
    """Panel C rule: among PT elements within +-200 kb of HPC1 that are shared with TIL25 and absent from TIL01
    (classes donor_only / near_donor), those whose empty site is found in both B73 and TIL01 by aligning the 100-bp
    flanks (edlib, <= 10 edits each, same strand; empty site = left and right flank overlapping by exactly the 5-bp
    TSD). Exactly one passes; its flank hits are asserted unique within 2 Mb (<= 20 edits)."""
    D = hpc1_data()

    def f():
        pt = D["els"]["PT"]
        cand = pt[pt["class"].isin(["donor_only", "near_donor"])]
        res = []
        for r in cand.itertuples():
            Lq = faidx("PT", "chr3", r.start - 100, r.start - 1)
            Rq = faidx("PT", "chr3", r.end + 1, r.end + 100)
            row = dict(name=r.name, start=r.start, end=r.end)
            for g in ("B73v5", "TIL01", "TIL25"):
                c, lo, hi, _ = D["win"][g]
                o0 = lo - 100_000
                reg = faidx(g, c, o0, hi + 100_000)
                hit = []
                for q in (Lq, Rq):
                    best = None
                    for strand, qq in (("+", q), ("-", rc(q))):
                        al = edlib.align(qq, reg, mode="HW", task="locations")
                        if best is None or al["editDistance"] < best[0]:
                            best = (al["editDistance"], strand, o0 + al["locations"][0][0], o0 + al["locations"][0][1])
                    hit.append(best)
                (eL, sL, aL, bL), (eR, sR, aR, bR) = hit
                ok = eL <= 10 and eR <= 10 and sL == sR == "+"
                row[f"{g}_edits"] = (eL, eR)
                row[f"{g}_gap"] = (aR - bL - 1) if ok else None
                row[f"{g}_site"] = (aL, bL, aR, bR) if ok else None
            res.append(row)
        res = pd.DataFrame(res)
        res["empty_B73"] = res.B73v5_gap.apply(lambda v: v is not None and v == -5)
        res["empty_TIL01"] = res.TIL01_gap.apply(lambda v: v is not None and v == -5)
        res["in_B73"] = res.B73v5_gap.apply(lambda v: v is not None and v > 1000)
        sel = res[res.empty_B73 & res.empty_TIL01]
        assert len(sel) == 1, sel
        ex = sel.iloc[0]
        # uniqueness of the flank hits within 2 Mb
        Lq = faidx("PT", "chr3", ex.start - 100, ex.start - 1)
        Rq = faidx("PT", "chr3", ex.end + 1, ex.end + 100)
        for g in ("B73v5", "TIL01"):
            site = ex[f"{g}_site"]
            reg = faidx(g, D["win"][g][0], site[0] - 1_000_000, site[0] + 1_000_000)
            for q in (Lq, Rq):
                n = 0
                for qq in (q, rc(q)):
                    al = edlib.align(qq, reg, mode="HW", task="locations", k=20)
                    if al["editDistance"] >= 0:
                        locs = sorted(set(a for a, _ in al["locations"]))
                        n += 1 + sum(1 for i in range(1, len(locs)) if locs[i] - locs[i - 1] > 50)
                assert n == 1, (g, n)
        lib = load_lib("PT")
        e = lib[lib.name == ex["name"]].iloc[0]
        o = ortho("PT", "TIL25")
        tid = o[o.id_a == ex["name"]].iloc[0]
        l25 = load_lib("TIL25")
        e25 = l25[l25.name == tid.id_b].iloc[0]
        FL = 19                                     # displayed flank (bp) outside the TSD
        seq = {"PT": (faidx("PT", "chr3", e.start - FL - 5, e.start + 11), faidx("PT", "chr3", e.end - 11,
                                                                                e.end + 5 + FL)),
               "TIL25": (faidx("TIL25", "chr3", e25.start - FL - 5, e25.start + 11),
                         faidx("TIL25", "chr3", e25.end - 11, e25.end + 5 + FL))}
        for g in ("B73v5", "TIL01"):
            aL, bL, aR, bR = ex[f"{g}_site"]          # left flank ends at bL (TSD = bL-4..bL)
            seq[g] = (faidx(g, D["win"][g][0], bL - 4 - FL, bL), faidx(g, D["win"][g][0], bL + 1, bL + FL))
        nest = lib[(lib.c == e.c) & (lib.start > e.start) & (lib.end < e.end)]
        Lpt, Rpt = faidx("PT", "chr3", e.start - 100, e.start - 1), faidx("PT", "chr3", e.end + 1, e.end + 100)
        L25 = faidx("TIL25", "chr3", e25.start - 100, e25.start - 1)
        R25 = faidx("TIL25", "chr3", e25.end + 1, e25.end + 100)
        fl = {"TIL25": (edlib.align(Lpt, L25)["editDistance"], edlib.align(Rpt, R25)["editDistance"])}
        for g in ("B73v5", "TIL01"):
            fl[g] = tuple(ex[f"{g}_edits"])
        tsd_ok = (Lpt[-5:] == Rpt[:5] == e.tsd) and (L25[-5:] == R25[:5] == e.tsd)
        assert tsd_ok and e.motif == e25.motif == "tg...ca", (Lpt[-5:], Rpt[:5], L25[-5:], R25[:5], e.tsd)
        # family length context: Retand (same family) elements of PT without nested insertions
        fam = lib[(lib.family == e.family)]
        return dict(table=res, ex=ex, pt=e, til25=e25, div=float(tid.divergence), seq=seq, nest=nest, flank=fl,
                    FL=FL, fam_median_len=float(fam.seq_len.median()), fam_n=len(fam))
    return cached("example", f)


def trio_stats(trio):
    d = f"{FORCED}/{trio.split(':', 1)[1]}" if trio.startswith("forced:") else f"{SIX}/{trio}"
    st = pd.read_csv(f"{d}/stats.tsv", sep="\t")
    out = {}
    for t, s in (("D_kmer", "all"), ("D_ins", "all"), ("D3_triples", "all"), ("D_self_outgroup", "LTR sites")):
        x = st[(st.test == t) & (st.stratum == s)]
        if len(x):
            out[t] = (float(x.iloc[0]["D"]), float(x.iloc[0]["SE"]), float(x.iloc[0]["Z"]))
    return out


def trio_src(trio):
    return (f"results/forced/{trio.split(':', 1)[1]}/stats.tsv" if trio.startswith("forced:")
            else f"results/six/{trio}/stats.tsv")


def snp_logs():
    """Gene-space SNP D as printed in gene_snp/more_*.log (one line per trio)."""
    rows = []
    for p in sorted(glob.glob(f"{GSNP}/more_*.log")):
        for line in open(p):
            m = re.search(r"D\((\S+),(\S+);(\S+);Zd\) genes with all four: (\d+); sites ([\d,]+); ABBA ([\d.,]+) "
                          r"BABA ([\d.,]+); D = ([+-][\d.]+) \+- ([\d.]+) \(Z = ([-\d.]+)\)", line)
            if m:
                rows.append(dict(P1=m[1], P2=m[2], P3=m[3], genes=int(m[4]), D=float(m[8]), SE=float(m[9]),
                                 Z=float(m[10]), log=os.path.basename(p)))
    return pd.DataFrame(rows)


def ltr_vs_snp():
    t = pd.read_csv(f"{SIX}/analysis/ltr_vs_snp.tsv", sep="\t")
    rows = []
    for r in t.itertuples():
        d = r.ltr_dir.split("/")[-1]
        trio = f"forced:{d}" if "forced" in r.ltr_dir else d
        st = trio_stats(trio)
        rows.append(dict(P1=r.P1, P2=r.P2, P3=r.P3, snp=r.snp_D, snp_se=r.snp_SE, snp_z=r.snp_Z, genes=r.genes,
                         km=st["D_kmer"][0], km_se=st["D_kmer"][1], ins=st["D_ins"][0], ins_se=st["D_ins"][1],
                         d3=r.D3_triples, dself=r.D_self_outgroup, trio=trio))
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------------------------------------------------
# figure helpers
# ---------------------------------------------------------------------------------------------------------------------
class Page:
    """One figure page; overlay axes use figure millimeters as data units (y down)."""

    def __init__(self, w_mm, h_mm):
        self.w, self.h = w_mm, h_mm
        self.fig = plt.figure(figsize=(w_mm * MM, h_mm * MM))
        self.o = self.overlay(z=-5)

    def ax(self, x, y, w, h, **kw):
        return self.fig.add_axes([x / self.w, 1 - (y + h) / self.h, w / self.w, h / self.h], **kw)

    def overlay(self, z=5):
        a = self.fig.add_axes([0, 0, 1, 1], zorder=z)
        a.set_xlim(0, self.w)
        a.set_ylim(self.h, 0)
        a.axis("off")
        a.patch.set_alpha(0)
        return a

    def letter(self, x, y, s):
        self.o.text(x, y, s, fontsize=9, fontweight="bold", va="top", ha="left")


def stack_rows(starts, ends, gap):
    """Greedy IGV 'expanded' rows: an element goes to the first row whose last end + gap < its start."""
    order = np.argsort(starts, kind="stable")
    row_end, rows = [], np.zeros(len(starts), int)
    for i in order:
        for r, e in enumerate(row_end):
            if starts[i] > e + gap:
                rows[i], row_end[r] = r, ends[i]
                break
        else:
            rows[i] = len(row_end)
            row_end.append(ends[i])
    return rows


def genome_label(ax, x, y, g, sub=None, fs=6.5, ha="right"):
    """'B73  maize' (accession roman, taxon italic, both in the taxon color); optional gray second line."""
    t = TAXON[g]
    ax.text(x, y if sub is None else y - 1.05, f"{LAB[g]}  " + ("maize" if t == "maize" else it(t)), ha=ha,
            va="center", fontsize=fs, color=GCOL[g])
    if sub is not None:
        ax.text(x, y + 1.35, sub, ha=ha, va="center", fontsize=5.2, color="#666666")


def style_ax(a):
    a.tick_params(length=2, width=0.5, pad=1.5)
    for s in ("left", "bottom"):
        a.spines[s].set_linewidth(0.5)


def draw_key(ax, x0, y0, items, xmax, fs=5.8, dy=2.5):
    """One-line-per-row key that wraps at xmax; items are (kind, color, label)."""
    x, y = x0, y0
    for kind, col, lab in items:
        w = 3.4 + 0.9 + text_w(lab, fs) + 2.6
        if x + w > xmax and x > x0:
            x, y = x0, y + dy
        if kind == "line":
            ax.plot([x, x + 3.4], [y, y], color=col, lw=1.0, solid_capstyle="butt")
        elif kind == "box":
            ax.add_patch(Rectangle((x + 0.2, y - 0.65), 3.0, 1.3, fc=col, ec="none"))
        elif kind == "outline":
            ax.add_patch(Rectangle((x + 0.2, y - 0.75), 3.0, 1.5, fill=False, ec=col, lw=0.8))
        elif kind == "bracket":
            ax.plot([x + 0.2, x + 0.2, x + 3.2, x + 3.2], [y + 0.55, y - 0.15, y - 0.15, y + 0.55], color=col, lw=0.8)
        elif kind == "ribbon":
            ax.add_patch(Polygon([(x + 0.2, y - 0.7), (x + 1.8, y - 0.7), (x + 3.2, y + 0.7), (x + 1.6, y + 0.7)],
                                 closed=True, fc=col, ec="none", alpha=0.6))
        elif kind == "tri":
            ax.add_patch(Polygon([(x + 1.1, y - 0.55), (x + 2.3, y - 0.55), (x + 1.7, y + 0.5)], closed=True, fc=col,
                                 ec="none"))
        elif kind == "gene":
            ax.add_patch(Rectangle((x + 1.1, y - 0.8), 1.2, 1.6, fill=False, ec=col, lw=0.8))
        ax.text(x + 4.3, y, lab, ha="left", va="center", fontsize=fs)
        x += w
    return y


# ---------------------------------------------------------------------------------------------------------------------
# panel A: Inv4m, six genomes, every anchor
# ---------------------------------------------------------------------------------------------------------------------
A_X0, A_X1 = 26.0, 178.0      # drawing span (mm)
A_TOP = 10.5                  # first bar (mm)
A_BAR, A_GAP = 1.7, 6.9       # bar height and link band (mm)
LABEL_X = 23.0                # right edge of the row-label column (mm)


def link_color(a, b):
    ta, tb = TAXON[a], TAXON[b]
    if "mexicana" in (ta, tb):
        return MEX
    if "parviglumis" in (ta, tb):
        return PAR
    return MAIZE


def panel_A(P, V):
    ax = P.overlay(z=2)
    A = inv4m_data()
    win, anc, invseg = A["win"], A["anchors"], A["invseg"]
    span_bp = max(w[1] - w[0] for w in win.values())
    sc = (A_X1 - A_X0) / span_bp                      # mm per bp, one scale for all rows
    xc = (A_X0 + A_X1) / 2
    X = {g: (lambda pos, g=g: xc + (pos - (win[g][0] + win[g][1]) / 2) * sc) for g in G6}
    Y = {g: A_TOP + k * (A_BAR + A_GAP) for k, g in enumerate(G6)}
    for layer in ("old", "old_inv", "near"):
        for (a, b), t in anc.groupby(["a", "b"], sort=False):
            d = t.divergence.values
            near = d < NEAR
            m = {"old": ~near & ~t.inverted.values, "old_inv": ~near & t.inverted.values, "near": near}[layer]
            if not m.any():
                continue
            xa = X[a]((t.s_a.values[m] + t.e_a.values[m]) / 2)
            xb = X[b]((t.s_b.values[m] + t.e_b.values[m]) / 2)
            ya, yb = Y[a] + A_BAR, Y[b]
            segs = [((p, ya), (q, yb)) for p, q in zip(xa, xb)]
            col, lw, al, z = {"old": (OLD, 0.25, 0.8, 1), "old_inv": (OLD_INV, 0.35, 0.9, 1.5),
                              "near": (link_color(a, b), 0.28, 0.55, 2)}[layer]
            ax.add_collection(LineCollection(segs, colors=col, linewidths=lw, alpha=al, zorder=z))
    for g in G6:
        x0, x1 = X[g](win[g][0]), X[g](win[g][1])
        ax.add_patch(Rectangle((x0, Y[g]), x1 - x0, A_BAR, fc="#F2F2F2", ec="#777777", lw=0.4, zorder=3))
        genome_label(ax, LABEL_X, Y[g] + A_BAR / 2, g, sub=f"chr4: {win[g][0] / 1e6:.1f}–{win[g][1] / 1e6:.1f} Mb")
    for r in invseg.itertuples():
        x0, x1 = X[r.g](r.start), X[r.g](r.end)
        ax.add_patch(Rectangle((x0, Y[r.g] - 0.35), x1 - x0, A_BAR + 0.7, fill=False, ec="k", lw=0.8, zorder=4))
    x0, x1 = X["B73v5"](INV4M_LIT[0]), X["B73v5"](INV4M_LIT[1])
    yb = Y["B73v5"] + A_BAR + 0.75
    ax.plot([x0, x0, x1, x1], [yb + 0.7, yb, yb, yb + 0.7], color=ELAI, lw=0.8, zorder=5, solid_capstyle="butt")
    ybar = Y[G6[-1]] + A_BAR + 2.6
    ax.plot([A_X1 - 10e6 * sc, A_X1], [ybar, ybar], color="k", lw=0.8, solid_capstyle="butt")
    ax.text(A_X1 - 5e6 * sc, ybar + 0.5, "10 Mb", ha="center", va="top", fontsize=5.6)
    items = [("line", MAIZE, "near-identical pair (< 0.2%): maize–maize"), ("line", MEX, "with " + it("mexicana")),
             ("line", PAR, "with " + it("parviglumis")), ("line", OLD, "older pair"),
             ("line", OLD_INV, "older, in an inverted block"), ("outline", "k", "inverted relative to B73"),
             ("bracket", ELAI, "Inv4m (published)")]
    draw_key(ax, 7.0, 3.4, items, xmax=FIG_W, dy=2.4)
    return ybar + 2.0


# ---------------------------------------------------------------------------------------------------------------------
# panel B: HPC1, four genomes, every element
# ---------------------------------------------------------------------------------------------------------------------
B_X0, B_X1 = 26.0, 172.5
B_SUB, B_SUBGAP = 1.25, 0.35   # element sub-row height and gap (mm)


def element_glyph(ax, x0, x1, y, h, strand, l5, l3, col, ltrcol, z=4.0):
    """Element body (thin bar) with its two LTRs (full height, pointed toward the 3' end)."""
    yc = y + h / 2
    ax.add_patch(Rectangle((x0, yc - h * 0.22), x1 - x0, h * 0.44, fc=col, ec="none", lw=0, zorder=z))
    tip = min(0.35, (x1 - x0) * 0.08)
    for a, b in ((x0, x0 + l5), (x1 - l3, x1)):
        if b - a <= 0:
            continue
        if strand == "+":
            pts = [(a, y), (max(a, b - tip), y), (b, yc), (max(a, b - tip), y + h), (a, y + h)]
        elif strand == "-":
            pts = [(b, y), (min(b, a + tip), y), (a, yc), (min(b, a + tip), y + h), (b, y + h)]
        else:
            pts = [(a, y), (b, y), (b, y + h), (a, y + h)]
        ax.add_patch(Polygon(pts, closed=True, fc=ltrcol, ec="none", lw=0, zorder=z + 0.1))


def darker(col, f=0.72):
    return tuple(np.array(matplotlib.colors.to_rgb(col)) * f)


def panel_B(P, yB, V):
    ax = P.overlay(z=2)
    H = hpc1_genes()
    D = hpc1_data()
    EX = example_data()
    els, links = D["els"], D["links"]
    glen = H["pos"]["B73v5"][2] - H["pos"]["B73v5"][1] + 1
    lo, hi = -HPC1_FLANK, HPC1_FLANK + glen
    sc = (B_X1 - B_X0) / (hi - lo)
    X = lambda rel: B_X0 + (rel - lo) * sc  # noqa: E731
    items = [("box", MEX, "near-identical to the TIL25 copy"), ("box", MEX_L, "shared with TIL25, not TIL01"),
             ("box", PAR, "near-identical to the TIL01 copy"), ("box", PAR_L, "shared with TIL01, not TIL25"),
             ("box", PALE, "other"), ("ribbon", "#BDBDBD", "1:1 ortholog (B73–PT gray)"),
             ("gene", ELAI, "HPC1 copy (n = differences between neighbors)"),
             ("tri", MEX, "empty site of the insertion in C")]
    yk = draw_key(ax, 7.0, yB + 2.4, items, xmax=FIG_W - 2)
    rows, nsub = {}, {}
    for g in B_ROWS:
        e = els[g]
        rows[g] = stack_rows(e.rel_s.values, e.rel_e.values, gap=800)
        nsub[g] = rows[g].max() + 1 if len(e) else 1
    band = {"TIL01": 5.0, "B73v5": 6.4, "PT": 5.0}
    ytop, y = {}, yk + 5.2
    for g in B_ROWS:
        ytop[g] = y
        y += nsub[g] * (B_SUB + B_SUBGAP) + band.get(g, 0)
    yend = y
    ecol = {g: [CLASS_COL.get(c, PALE) if isinstance(c, str) else PALE for c in els[g]["class"]]
            for g in ("B73v5", "PT")}
    cls = {g: els[g].set_index("name")["class"] for g in ("B73v5", "PT")}
    link_col = {}
    for r in links.itertuples():
        if {r.ga, r.gb} == {"B73v5", "TIL01"}:
            c = cls["B73v5"][r.id_a if r.ga == "B73v5" else r.id_b]
        elif {r.ga, r.gb} == {"PT", "TIL25"}:
            c = cls["PT"][r.id_a if r.ga == "PT" else r.id_b]
        else:
            c = None
        link_col[(r.id_a, r.id_b)] = CLASS_COL.get(c, "#BDBDBD") if c else "#BDBDBD"
    partner_col = {"TIL01": {}, "TIL25": {}}
    for (ia, ib), col in link_col.items():
        for nm in (ia, ib):
            g = nm.split("_")[0]
            if g in partner_col:
                partner_col[g][nm] = col
    for g in ("TIL01", "TIL25"):
        ecol[g] = [partner_col[g].get(n, PALE) for n in els[g].name]
    pos = {}
    for g in B_ROWS:
        e = els[g]
        ax.plot([B_X0, B_X1], [ytop[g] + B_SUB / 2] * 2, color="#9A9A9A", lw=0.35, zorder=1)
        for k, r in enumerate(e.itertuples()):
            y0 = ytop[g] + rows[g][k] * (B_SUB + B_SUBGAP)
            x0, x1 = X(max(r.rel_s, lo)), X(min(r.rel_e, hi))
            l5 = (r.ltr5_end - r.ltr5_start + 1) * sc if r.rel_s >= lo else 0
            l3 = (r.ltr3_end - r.ltr3_start + 1) * sc if r.rel_e <= hi else 0
            col = ecol[g][k]
            element_glyph(ax, x0, x1, y0, B_SUB, r.strand, l5, l3, col, darker(col) if col != PALE else "#B3B3B3",
                          z=4 + rows[g][k] * 0.01)
            pos[r.name] = (x0, x1, y0, y0 + B_SUB)
            if g == "PT" and r.name == EX["ex"]["name"]:
                ax.add_patch(Rectangle((x0 - 0.3, y0 - 0.35), x1 - x0 + 0.6, B_SUB + 0.7, fill=False, ec="k",
                                       lw=0.6, zorder=7))
                ax.text(x1 + 0.8, y0 + B_SUB / 2 + 0.1, "C", fontsize=7, fontweight="bold", va="center",
                        ha="left", zorder=8)
        c, wlo, whi, s = D["win"][g]
        genome_label(ax, LABEL_X, ytop[g] + (nsub[g] * (B_SUB + B_SUBGAP)) / 2 - 0.15, g,
                     sub=f"{c.split('_')[1]}: {(s + lo) / 1e6:.2f}–{(s + hi) / 1e6:.2f} Mb")
    polys, cols = [], []
    for r in links.itertuples():
        if r.id_a not in pos or r.id_b not in pos:
            continue
        a, b = (r.id_a, r.id_b) if B_ROWS.index(r.ga) < B_ROWS.index(r.gb) else (r.id_b, r.id_a)
        ga, gb = a.split("_")[0], b.split("_")[0]
        xa0, xa1, _, _ = pos[a]
        xb0, xb1, _, _ = pos[b]
        ya = ytop[ga] + nsub[ga] * (B_SUB + B_SUBGAP) - B_SUBGAP + 0.1
        yb = ytop[gb] - 0.1
        polys.append([(xa0, ya), (xa1, ya), (xb1, yb), (xb0, yb)])
        cols.append(link_col[(r.id_a, r.id_b)])
    ax.add_collection(PolyCollection(polys, facecolors=cols, edgecolors="none", alpha=0.5, zorder=2))
    xg0, xg1 = X(0), X(glen)
    for g in B_ROWS:
        ax.add_patch(Rectangle((xg0 - 0.2, ytop[g] - 0.5), xg1 - xg0 + 0.4, B_SUB + 1.0, fill=False, ec=ELAI, lw=0.8,
                               zorder=7))
    ax.text((xg0 + xg1) / 2, ytop["TIL01"] - 0.9, "HPC1", ha="center", va="bottom", fontsize=6, color=ELAI)
    for a, b in zip(B_ROWS[:-1], B_ROWS[1:]):
        nm, ln = H["diffs"][(a, b)]
        ya = ytop[a] + B_SUB + 0.5
        yb = ytop[b] - 0.5
        ax.plot([(xg0 + xg1) / 2] * 2, [ya, yb], color=ELAI, lw=0.6, zorder=6)
        ax.text((xg0 + xg1) / 2 - 0.6, (ya + yb) / 2, f"{nm}", ha="right", va="center", fontsize=5.6, color=ELAI,
                zorder=8, bbox=dict(fc="white", ec="none", pad=0.1, alpha=0.9))
    # empty sites of the panel C insertion, joined to the PT copy
    xs = {}
    for g in ("B73v5", "TIL01"):
        aL, bL, aR, bR = EX["ex"][f"{g}_site"]
        xs[g] = X(bL - 2 - D["win"][g][3])
        yy = ytop[g] - 0.1
        ax.add_patch(Polygon([(xs[g] - 0.6, yy - 1.05), (xs[g] + 0.6, yy - 1.05), (xs[g], yy)], closed=True, fc=MEX,
                             ec="none", zorder=8))
    x0, x1, y0, _ = pos[EX["ex"]["name"]]
    yB73 = ytop["B73v5"] + nsub["B73v5"] * (B_SUB + B_SUBGAP)
    ax.plot([xs["B73v5"], x0 + 0.3], [yB73 - 0.2, y0 - 0.4], color=MEX, lw=0.5, ls=(0, (2, 1.2)), zorder=6)
    # posterior track (same relative axis)
    yt0 = yend + 0.6
    th = 6.5
    tax = P.ax(B_X0, yt0, B_X1 - B_X0, th)
    for g, col in (("PT", "k"), ("B73v5", "#8A8A8A")):
        e = els[g].dropna(subset=["post_ancestry_TIL25"])
        mid = ((e.rel_s + e.rel_e) / 2).values
        o = np.argsort(mid)
        tax.plot(mid[o], e.post_ancestry_TIL25.values[o], color=col, lw=0.8, zorder=3)
        tax.text(hi + (hi - lo) * 0.006, e.post_ancestry_TIL25.values[o][-1], LAB[g], color=col, fontsize=5.8,
                 va="center", ha="left")
    tax.axvspan(0, glen, color=ELAI, alpha=0.3, lw=0, zorder=1)
    tax.set_xlim(lo, hi)
    tax.set_ylim(-0.06, 1.1)
    tax.set_yticks([0, 1])
    tax.set_yticklabels(["0", "1"], fontsize=5.6)
    style_ax(tax)
    ticks = np.arange(-200_000, 200_001, 50_000)
    tax.set_xticks(ticks)
    tax.set_xticklabels([("+" if t > 0 else "") + f"{t / 1000:.0f}".replace("-", "−") for t in ticks], fontsize=5.6)
    tax.set_xlabel("position relative to each genome's HPC1 copy (kb)", fontsize=6.2, labelpad=1.5)
    P.o.text(LABEL_X, yt0 + th / 2, "TIL25-like\nposterior", ha="right", va="center", fontsize=6.2, linespacing=1.0)
    return yt0 + th + 6.5


# ---------------------------------------------------------------------------------------------------------------------
# panel C: base-pair evidence
# ---------------------------------------------------------------------------------------------------------------------
def panel_C(P, yC, V):
    ax = P.overlay(z=3)
    EX = example_data()
    e, e25, FL = EX["pt"], EX["til25"], EX["FL"]
    seq = EX["seq"]
    gx0, gw = 44.0, 96.0
    gsc = gw / (e.end - e.start + 1)
    gy = {"PT": yC + 2.6, "TIL25": yC + 6.0}
    for g, r in (("PT", e), ("TIL25", e25)):
        L = r.end - r.start + 1
        y0 = gy[g]
        ax.plot([gx0 - 3, gx0], [y0 + 0.6] * 2, color="#777777", lw=0.4)
        ax.plot([gx0 + L * gsc, gx0 + L * gsc + 3], [y0 + 0.6] * 2, color="#777777", lw=0.4)
        element_glyph(ax, gx0, gx0 + L * gsc, y0, 1.2, r.strand, (r.ltr5_end - r.ltr5_start + 1) * gsc,
                      (r.ltr3_end - r.ltr3_start + 1) * gsc, MEX_L, MEX, z=4)
        genome_label(ax, gx0 - 4, y0 + 0.6, g, fs=6.2)
    for r in EX["nest"].itertuples():
        x0, x1 = gx0 + (r.start - e.start) * gsc, gx0 + (r.end - e.start) * gsc
        element_glyph(ax, x0, x1, gy["PT"] - 1.75, 1.2, r.strand, (r.ltr5_end - r.ltr5_start + 1) * gsc,
                      (r.ltr3_end - r.ltr3_start + 1) * gsc, PALE, "#9A9A9A", z=5)
        ax.text(x1 + 1.0, gy["PT"] - 1.15, f"nested {r.te.split('/')[-1]} (PT only)", fontsize=5.6, va="center",
                ha="left", color="#555555")
    kb = 2000 * gsc
    xk = gx0 + gw + 6
    ax.plot([xk, xk + kb], [gy["TIL25"] + 0.6] * 2, color="k", lw=0.7, solid_capstyle="butt")
    ax.text(xk + kb + 1.0, gy["TIL25"] + 0.6, "2 kb", ha="left", va="center", fontsize=5.6)
    cw = MONO_W
    ys = yC + 14.6
    dy = 2.55
    xL = 35.0
    nL = FL + 5 + 12
    xmid0 = xL + nL * cw
    xR = xmid0 + 27.0
    refL, refR = seq["PT"]
    for k, g in enumerate(["PT", "TIL25", "B73v5", "TIL01"]):
        y = ys + k * dy
        genome_label(ax, xL - 1.4, y, g, fs=6.2)
        left, right = seq[g]
        empty = g in ("B73v5", "TIL01")
        for i, ch in enumerate(left[:FL + 5]):           # flank + TSD (same columns in every row)
            x = xL + i * cw
            if ch != refL[i]:
                ax.add_patch(Rectangle((x, y - 1.05), cw, 2.1, fc="#CFCFCF", ec="none", zorder=2))
            ax.text(x + cw / 2, y, ch, fontproperties=MONO, ha="center", va="center", zorder=3)
        ax.add_patch(Rectangle((xL + FL * cw, y - 1.05), 5 * cw, 2.1, fill=False, ec="k", lw=0.6, zorder=4))
        if not empty:
            x0 = xL + (FL + 5) * cw
            ax.add_patch(Rectangle((x0, y - 1.05), 12 * cw, 2.1, fc=MEX, ec="none", zorder=2))
            for i, ch in enumerate(left[FL + 5:FL + 17]):
                ax.text(x0 + (i + 0.5) * cw, y, ch, fontproperties=MONO, ha="center", va="center", color="white",
                        zorder=3)
            ln = (e.end - e.start + 1) if g == "PT" else (e25.end - e25.start + 1)
            ax.text((xmid0 + xR) / 2, y, f"… {ln:,} bp …", ha="center", va="center", fontsize=6)
            ax.add_patch(Rectangle((xR, y - 1.05), 12 * cw, 2.1, fc=MEX, ec="none", zorder=2))
            for i, ch in enumerate(right):
                fc = "white" if i < 12 else "k"
                ax.text(xR + (i + 0.5) * cw, y, ch, fontproperties=MONO, ha="center", va="center", color=fc,
                        zorder=3)
            ax.add_patch(Rectangle((xR + 12 * cw, y - 1.05), 5 * cw, 2.1, fill=False, ec="k", lw=0.6, zorder=4))
        else:
            ax.plot([xL + (FL + 5) * cw + 0.6, xmid0 + 2.0], [y, y], color="#9A9A9A", lw=0.5, ls=(0, (2, 1.5)))
            ax.text((xmid0 + xR) / 2, y, "empty site", ha="center", va="center", fontsize=6, color=GCOL[g])
            ax.plot([xR - 2.0, xR + 17 * cw - 0.6], [y, y], color="#9A9A9A", lw=0.5, ls=(0, (2, 1.5)))
            for i, ch in enumerate(right):
                x = xR + (17 + i) * cw
                if ch != refR[17 + i]:
                    ax.add_patch(Rectangle((x, y - 1.05), cw, 2.1, fc="#CFCFCF", ec="none", zorder=2))
                ax.text(x + cw / 2, y, ch, fontproperties=MONO, ha="center", va="center", zorder=3)
    yh = ys - 1.75
    for x, s, c in ((xL + FL * cw / 2, "flank", "#666666"), (xL + (FL + 2.5) * cw, "TSD", "k"),
                    (xL + (FL + 11) * cw, "LTR", MEX), (xR + 6 * cw, "LTR", MEX), (xR + 14.5 * cw, "TSD", "k"),
                    (xR + (17 + FL / 2) * cw, "flank", "#666666")):
        ax.text(x, yh, s, ha="center", va="bottom", fontsize=5.8, color=c)
    for xa, ya, xb in ((gx0, gy["TIL25"] + 1.3, xL + (FL + 5) * cw),
                       (gx0 + (e25.end - e25.start + 1) * gsc, gy["TIL25"] + 1.3, xR + 12 * cw)):
        ax.plot([xa, xb], [ya, yh - 2.5], color="#AAAAAA", lw=0.4)
    return ys + 3 * dy + 1.5


# ---------------------------------------------------------------------------------------------------------------------
# panel D: LTR-RT D vs SNP D
# ---------------------------------------------------------------------------------------------------------------------
def panel_D(P, x, y, w, h, V):
    a = P.ax(x, y, w, h)
    style_ax(a)
    R = ltr_vs_snp()
    a.axhline(0, color="k", lw=0.5, zorder=1)
    a.axvline(0, color="k", lw=0.5, zorder=1)
    a.plot([-0.05, 0.4], [-0.05, 0.4], color="#888888", lw=0.6, ls=(0, (3, 2)), zorder=1)
    a.text(0.268, 0.252, "1:1", fontsize=5.6, color="#888888", ha="left", va="center")
    for r in R.itertuples():
        a.plot([r.snp, r.snp], [r.km, r.ins], color="#AAAAAA", lw=0.4, zorder=1)
    for col, fc in (("km", "k"), ("ins", "white")):
        a.errorbar(R.snp, R[col], xerr=2 * R.snp_se, yerr=2 * R[col + "_se"], fmt="none", ecolor="#666666",
                   elinewidth=0.45, capsize=0, zorder=2)
        sl, ic = np.polyfit(R.snp, R[col], 1)
        xx = np.array([R.snp.min(), R.snp.max()])
        a.plot(xx, ic + sl * xx, color="k", lw=0.55, ls="-" if col == "km" else (0, (1.2, 1.2)), zorder=3)
        a.scatter(R.snp, R[col], s=13, marker="o", facecolor=fc, edgecolor="k", linewidth=0.6, zorder=4)
    lab = {(r.P1, r.P2, r.P3): f"{LAB[r.P1]}, {LAB[r.P2]}; {LAB[r.P3]}" for r in R.itertuples()}
    P_ = {(r.P1, r.P2, r.P3): r for r in R.itertuples()}
    place = [(("PT", "TIL01", "TIL18"), "ins", 0.226, 0.312, "right"),
             (("B73v5", "TIL01", "TIL18"), "km", 0.180, 0.093, "left"),
             (("PT", "B73v5", "TIL18"), "ins", 0.098, 0.160, "right"),
             (("TIL25", "TIL01", "TIL18"), "km", 0.132, 0.046, "left")]
    for key, which, tx, ty, ha in place:
        r = P_[key]
        py = r.km if which == "km" else r.ins
        a.plot([r.snp, tx + (0.003 if ha == "left" else -0.003)], [py, ty], color="#888888", lw=0.35, zorder=5)
        a.text(tx + (0.005 if ha == "left" else -0.005), ty, lab[key], fontsize=5.4, ha=ha, va="center",
               color="#333333", zorder=6)
    cl = [("TIL11", "TIL01", "TIL18"), ("B73v5", "TIL01", "TIL25"), ("TIL18", "TIL25", "B73v5")]
    cx = np.mean([P_[k].snp for k in cl])
    a.plot([cx + 0.004, 0.083], [0.012, -0.020], color="#888888", lw=0.35, zorder=5)
    a.text(0.086, -0.020, "\n".join(lab[k] for k in cl), fontsize=5.4, ha="left", va="center", color="#333333",
           linespacing=1.0, zorder=6)
    a.scatter([0.012], [0.345], s=13, facecolor="k", edgecolor="k", lw=0.6)
    a.text(0.024, 0.345, "single-copy k-mers", fontsize=5.7, va="center")
    a.scatter([0.012], [0.318], s=13, facecolor="white", edgecolor="k", lw=0.6)
    a.text(0.024, 0.318, "insertions", fontsize=5.7, va="center")
    a.set_xlim(-0.012, 0.29)
    a.set_ylim(-0.055, 0.36)
    a.set_xticks([0, 0.1, 0.2])
    a.set_yticks([0, 0.1, 0.2, 0.3])
    a.set_xlabel("D, gene-space SNPs (± 2 SE)", fontsize=6.3, labelpad=2)
    a.set_ylabel("D, LTR-RT libraries only (± 2 SE)", fontsize=6.3, labelpad=2)
    return R


# ---------------------------------------------------------------------------------------------------------------------
# panel E: near-identity, each genome's five partners
# ---------------------------------------------------------------------------------------------------------------------
def panel_E(P, x, y, w, h, V):
    a = P.ax(x, y, w, h)
    style_ax(a)
    pid = pair_identity()
    share = {}
    for r in pid.itertuples():
        share[(r.a, r.b)] = share[(r.b, r.a)] = r.share * 100
    order = G6[::-1]                                        # y = 0 at the bottom: TIL18 ... TIL01 at the top
    for k, g in enumerate(order):
        vals = [(o, share[(g, o)]) for o in G6 if o != g]
        a.plot([min(v for _, v in vals), max(v for _, v in vals)], [k, k], color="#DDDDDD", lw=0.6, zorder=1)
        same = [o for o in G6 if o != g and TAXON[o] == TAXON[g]][0]      # reference: the same-subspecies pair
        a.plot([share[(g, same)]] * 2, [k - 0.42, k + 0.42], color=GCOL[g], lw=0.6, ls=(0, (1.5, 1)), zorder=2)
        for o, v in vals:
            dy = 0.15 if MARK[o] == "o" else -0.15
            a.scatter([v], [k + dy], s=MSIZE[MARK[o]], marker=MARK[o], facecolor=GCOL[o], edgecolor="white",
                      lw=0.3, zorder=3)
        a.text(-0.05, k, LAB[g], transform=a.get_yaxis_transform(), ha="right", va="center", fontsize=6.2,
               color=GCOL[g])
    a.set_yticks([])
    a.set_ylim(-0.6, len(order) - 0.45)
    a.set_xlim(0, 62)
    a.set_xticks([0, 20, 40, 60])
    a.set_xlabel("1:1 orthologs < 0.2% divergent (%)", fontsize=6.3, labelpad=2)
    a.spines["left"].set_visible(False)
    # key above the axes: one column per taxon
    ky = y - 8.4
    P.o.text(x - 9.0, ky + 1.3, "partner:", ha="left", va="center", fontsize=5.8, color="#555555")
    for j, (g1, g2) in enumerate((("B73v5", "PT"), ("TIL01", "TIL11"), ("TIL18", "TIL25"))):
        xx = x + 2.0 + j * 12.0
        for i, g in enumerate((g1, g2)):
            yy = ky + i * 2.5
            P.o.scatter([xx], [yy], s=MSIZE[MARK[g]], marker=MARK[g], facecolor=GCOL[g], edgecolor="white", lw=0.3)
            P.o.text(xx + 1.4, yy, LAB[g], ha="left", va="center", fontsize=5.8, color=GCOL[g])
    xx = x + 2.0
    P.o.plot([xx, xx], [ky + 4.1, ky + 6.0], color="#555555", lw=0.6, ls=(0, (1.5, 1)))
    P.o.text(xx + 1.4, ky + 5.05, "same-subspecies pair", ha="left", va="center", fontsize=5.8, color="#555555")
    return pid


# ---------------------------------------------------------------------------------------------------------------------
# panel F: every trio
# ---------------------------------------------------------------------------------------------------------------------
def panel_F(P, x, y, w, h, V):
    a = P.ax(x, y, w, h)
    style_ax(a)
    rows, heads, yk = [], [], 0.0
    for head, trios in F_GROUPS:
        heads.append((yk, head))
        yk += 1
        for trio, R, S, Dn in trios:
            Dk, se, Z = trio_stats(trio)["D_kmer"]
            rows.append(dict(y=yk, trio=trio, R=R, S=S, D=Dn, Dk=Dk, se=se, Z=Z, head=head))
            yk += 1
        yk += 0.4
    T = pd.DataFrame(rows)
    a.axvline(0, color="k", lw=0.5, zorder=1)
    g1 = T[T["head"] == F_GROUPS[0][0]].reset_index(drop=True)
    for i in range(0, len(g1), 2):
        r1, r2 = g1.iloc[i], g1.iloc[i + 1]
        a.plot([r1.Dk, r2.Dk], [r1.y, r2.y], color="#9A9A9A", lw=0.5, zorder=1.5)
    for r in T.itertuples():
        col = GCOL[r.R]
        a.plot([r.Dk - 2 * r.se, r.Dk + 2 * r.se], [r.y, r.y], color=col, lw=0.7, zorder=2, solid_capstyle="butt")
        a.scatter([r.Dk], [r.y], s=MSIZE[MARK[r.R]], marker=MARK[r.R], facecolor=col, edgecolor="white", lw=0.3,
                  zorder=3)
        a.text(-0.03, r.y, f"{LAB[r.R]}, {LAB[r.S]}; {LAB[r.D]}", transform=a.get_yaxis_transform(), ha="right",
               va="center", fontsize=5.5)
        a.text(1.03, r.y, f"{r.Z:.1f}", transform=a.get_yaxis_transform(), ha="left", va="center", fontsize=5.3,
               color="#555555")
    for yy, head in heads:
        a.text(-0.03, yy + 0.05, mixed(head), transform=a.get_yaxis_transform(), ha="right", va="center",
               fontsize=5.6, color="#666666")
    a.text(1.03, -0.75, "Z", transform=a.get_yaxis_transform(), ha="left", va="center", fontsize=5.6,
           color="#555555")
    a.set_ylim(yk - 0.2, -1.2)
    a.set_yticks([])
    a.spines["left"].set_visible(False)
    a.set_xlim(-0.06, 0.24)
    a.set_xticks([0, 0.1, 0.2])
    a.set_xlabel(r"$D_{\mathrm{kmer}}$" + " (± 2 SE)", fontsize=6.3, labelpad=2)
    return T


# ---------------------------------------------------------------------------------------------------------------------
# legend pages (layout as in Fig. 1)
# ---------------------------------------------------------------------------------------------------------------------
def _width_pt(s, style, size):
    if "s" in style:
        size = size * 0.7
    fp = font_manager.FontProperties(family="Liberation Sans", size=size,
                                     style="italic" if "i" in style else "normal",
                                     weight="bold" if "b" in style else "normal")
    w, h, d = _T2P.get_text_width_height_descent(s, fp, ismath=False)
    return w


def _tokens(par):
    """Split '*italic*', '**bold**' and '^{sup}' markup into (word, style, space_before) tokens."""
    out, style, buf, i = [], "", "", 0
    while i < len(par):
        if par.startswith("^{", i):
            if buf:
                out.append((buf, style))
                buf = ""
            j = par.index("}", i)
            out.append((par[i + 2:j], style + "s"))
            i = j + 1
        elif par.startswith("**", i):
            if buf:
                out.append((buf, style))
                buf = ""
            style = style.replace("b", "") if "b" in style else style + "b"
            i += 2
        elif par[i] == "*":
            if buf:
                out.append((buf, style))
                buf = ""
            style = style.replace("i", "") if "i" in style else style + "i"
            i += 1
        else:
            buf += par[i]
            i += 1
    if buf:
        out.append((buf, style))
    words = []
    for txt, st in out:
        parts = txt.split(" ")
        for k, p in enumerate(parts):
            if p == "":
                if words:
                    words[-1] = (words[-1][0], words[-1][1], words[-1][2], True)
                continue
            words.append((p, st, k > 0 or txt.startswith(" "), False))
    return [(p, st, k > 0 and (glue or words[k - 1][3])) for k, (p, st, glue, _) in enumerate(words)]


def layout_text(paragraphs, width_mm, size=10):
    width_pt = width_mm / 25.4 * 72
    sp = _width_pt(" ", "", size)
    lines = []
    for par in paragraphs:
        cur, x = [], 0.0
        for text, st, space_before in _tokens(par):
            w = _width_pt(text, st, size)
            add = sp if (space_before and cur) else 0.0
            if cur and x + add + w > width_pt:
                lines.append((cur, False))
                cur, x, add = [], 0.0, 0.0
            cur.append((x + add, text, st))
            x += add + w
        lines.append((cur, True))
    return lines


def legend_page(pdf, paragraphs, width_mm=FIG_W, size=10, margin=10):
    lead_mm = size * 1.25 / 72 * 25.4
    lines = layout_text(paragraphs, width_mm - 2 * margin, size)
    n_par = sum(1 for _, end in lines if end)
    h = 2 * margin + len(lines) * lead_mm + n_par * lead_mm * 0.45
    fig = plt.figure(figsize=(width_mm * MM, h * MM))
    y = margin
    for toks, end in lines:
        for x_pt, text, st in toks:
            sup = "s" in st
            fig.text((margin + x_pt / 72 * 25.4) / width_mm,
                     1 - (y + lead_mm * 0.8 - (size * 0.36 / 72 * 25.4 if sup else 0)) / h, text,
                     fontsize=size * (0.7 if sup else 1), family="Liberation Sans",
                     style="italic" if "i" in st else "normal", weight="bold" if "b" in st else "normal",
                     va="baseline", ha="left")
        y += lead_mm
        if end:
            y += lead_mm * 0.45
    pdf.savefig(fig)
    plt.close(fig)
    return h


# ---------------------------------------------------------------------------------------------------------------------
# numbers and legends
# ---------------------------------------------------------------------------------------------------------------------
class Numbers:
    """Every legend number with its source; v(key, value, source) registers and returns the formatted value."""

    def __init__(self):
        self.rows = {}

    def v(self, key, value, source, note=""):
        self.rows[key] = (value, source, note)
        return value

    def write(self, path):
        with open(path, "w") as fo:
            fo.write("key\tvalue\tsource\tnote\n")
            for k, (val, src, note) in self.rows.items():
                fo.write(f"{k}\t{val}\t{src}\t{note}\n")


def pct(x, d=1):
    return f"{100 * x:.{d}f}%"


def legends(N):
    A = inv4m_data()
    IS = inv4m_stats(A).set_index(["a", "b", "where"])
    H = hpc1_genes()
    D = hpc1_data()
    EX = example_data()
    pid = pair_identity()
    R = ltr_vs_snp()
    ts = pd.read_csv(f"{SIX}/analysis/trio_summary.tsv", sep="\t").set_index("trio")
    six_f = open(f"{SIX}/analysis/six_findings.txt").read()
    b3 = pd.read_csv(f"{BENCH}/results/main3/benchmark_real.tsv", sep="\t")
    SA = "computed by fig4_six_genomes.py from results/six/orthologs.<A>.<B>.tsv.gz + blocks.tsv"
    SB = "computed by fig4_six_genomes.py (minimap2 / libraries / elements tables)"
    v = N.v
    for k, val, src in (("param_near_identical", "< 0.2%", "SPEC (near-identical orthologs)"),
                        ("param_rate", "3 × 10^-8 substitutions per site per year", "SPEC shared block"),
                        ("param_HPC1_window", "± 200 kb", "as six_findings.txt (+-200 kb)"),
                        ("param_posterior_window", "50 kb", "fig4 legend (PT posterior near the gene)"),
                        ("param_flank_bp", "100 bp", "fig4 example rule (flank alignment)"),
                        ("param_unique_window", "2 Mb", "fig4 example check (flank hits unique, <= 20 edits)"),
                        ("param_jackknife_block", "5 Mb", "ltrmix findings.txt (blocks of 5 Mb)")):
        v(k, val, src)

    # ---- panel A
    inv = A["invseg"].set_index("g")
    blk = {}
    for g in ("PT", "TIL18", "TIL25", "TIL01"):
        r = inv.loc[g]
        blk[g] = v(f"A_inverted_block_B73_{g}", f"{r.b73_start / 1e6:.2f}–{r.b73_end / 1e6:.2f} Mb "
                   f"({r.n_anchor} anchors)", "results/six/blocks.tsv (= six_findings.txt)")
    m = re.search(r"Inv4m region, B73v5 vs TIL11: inverted blocks in B73 coordinates: (\S+)", six_f)
    v("A_inverted_block_B73_TIL11", m[1], "results/six/analysis/six_findings.txt")

    def st(a, b, w):
        r = IS.loc[(a, b, w)]
        return r
    bp_in, bp_out = st("B73v5", "PT", "inside"), st("B73v5", "PT", "outside")
    pt_in, pt_out = st("PT", "TIL25", "inside"), st("PT", "TIL25", "outside")
    tt_in, tt_out = st("TIL25", "TIL18", "inside"), st("TIL25", "TIL18", "outside")
    ib_in = st("TIL11", "B73v5", "inside")
    nA = len(A["anchors"])
    v("A_n_anchors_drawn", f"{nA:,}", SA)
    vals = {}
    for nm, r in (("B73-PT_in", bp_in), ("B73-PT_out", bp_out), ("PT-TIL25_in", pt_in), ("PT-TIL25_out", pt_out),
                  ("TIL25-TIL18_in", tt_in), ("TIL25-TIL18_out", tt_out), ("TIL11-B73_in", ib_in)):
        vals[nm] = (v(f"A_{nm}_n", f"{int(r.n):,}", SA), v(f"A_{nm}_median_div", pct(r["median"], 2), SA),
                    v(f"A_{nm}_near_share", pct(r.near, 0), SA))
    win = A["win"]

    # ---- panel B
    pos = H["pos"]
    dif = H["diffs"]
    dd = {k: v(f"B_HPC1_diff_{k[0]}_{k[1]}", f"{dif[k][0]}", SB, f"aligned length {dif[k][1]}")
          for k in (("B73v5", "TIL01"), ("B73v5", "PT"), ("PT", "TIL25"), ("B73v5", "TIL25"), ("PT", "TIL01"),
                    ("TIL01", "TIL25"))}
    alen = v("B_HPC1_aligned_bp", f"{dif[('PT', 'TIL25')][1]:,}", SB)
    hpos = {g: v(f"B_HPC1_pos_{g}", f"{pos[g][0].split('_')[1]}:{pos[g][1]:,}–{pos[g][2]:,}", SB,
                 f"identity {pos[g][3]}/{pos[g][4]}") for g in B_ROWS}
    ept, eb = D["els"]["PT"], D["els"]["B73v5"]
    cpt, cb = ept["class"].value_counts(), eb["class"].value_counts()
    n_pt = v("B_PT_elements", f"{len(ept)}", SB)
    n_pt_d = v("B_PT_TIL25_shared", f"{int(cpt.get('donor_only', 0) + cpt.get('near_donor', 0))}",
               f"results/six/{B_TRIO['PT']}/elements.PT.tsv")
    n_pt_s = v("B_PT_TIL01_shared", f"{int(cpt.get('sister_only', 0) + cpt.get('near_sister', 0))}",
               f"results/six/{B_TRIO['PT']}/elements.PT.tsv")
    n_b = v("B_B73_elements", f"{len(eb)}", SB)
    n_b_s = v("B_B73_TIL01_shared", f"{int(cb.get('sister_only', 0) + cb.get('near_sister', 0))}",
              f"results/six/{B_TRIO['B73v5']}/elements.B73v5.tsv")
    n_b_sn = v("B_B73_TIL01_near", f"{int(cb.get('near_sister', 0))}",
               f"results/six/{B_TRIO['B73v5']}/elements.B73v5.tsv")
    n_b_d = v("B_B73_TIL25_shared", f"{int(cb.get('donor_only', 0) + cb.get('near_donor', 0))}",
              f"results/six/{B_TRIO['B73v5']}/elements.B73v5.tsv")
    thr = pd.read_csv(f"{SIX}/{B_TRIO['PT']}/stats.tsv", sep="\t")
    thr = float(thr[thr.test == "hmm_ancestry"].near_threshold.iloc[0])
    thr_s = v("B_near_threshold", pct(thr, 3), f"results/six/{B_TRIO['PT']}/stats.tsv (hmm_ancestry near_threshold)")
    pp = ept.dropna(subset=["post_ancestry_TIL25"])
    pp_in = pp[(pp.rel_e >= -50_000) & (pp.rel_s <= 50_000)]
    pt_post_min = v("B_PT_posterior_min_50kb", f"{pp_in.post_ancestry_TIL25.min():.2f}",
                    f"results/six/{B_TRIO['PT']}/elements.PT.tsv", "PT elements within 50 kb of HPC1")
    pt_post_max = v("B_PT_posterior_max", f"{pp.post_ancestry_TIL25.max():.3f}",
                    f"results/six/{B_TRIO['PT']}/elements.PT.tsv")
    bb = eb.dropna(subset=["post_ancestry_TIL25"])
    b_left = bb[(bb.rel_e < 0) & (bb.rel_s > -150_000)]
    b_right = bb[(bb.rel_s > 0) & (bb.rel_s < 200_000)]
    b_left_s = v("B_B73_posterior_left", f"{b_left.post_ancestry_TIL25.min():.2f}–"
                 f"{b_left.post_ancestry_TIL25.max():.3f}", f"results/six/{B_TRIO['B73v5']}/elements.B73v5.tsv",
                 "B73 elements 0-150 kb left of HPC1")
    b_right_s = v("B_B73_posterior_right_max", f"{b_right.post_ancestry_TIL25.max():.2f}",
                  f"results/six/{B_TRIO['B73v5']}/elements.B73v5.tsv", "B73 elements 0-200 kb right of HPC1")
    row = b3[b3["item"].astype(str).str.startswith("HPC1 +-200 kb")].iloc[0]
    b73_tiL18 = v("B_B73_posterior_TIL18_donor_max", re.search(r"max post ancestry ([\d.]+)", row["value"])[1],
                  "results/main3/benchmark_real.tsv (HPC1 +-200 kb)")
    m = re.search(r"PT at HPC1 \+-200 kb \(via (\d+) B73 anchors; PT chr3:(\d+)-(\d+)\) with TIL25 as donor: (\d+) PT "
                  r"elements, classes \{'private': (\d+), 'donor_only': (\d+)\}", six_f)
    old_win = v("B_report_PT_window", f"chr3:{int(m[2]) / 1e6:.2f}–{int(m[3]) / 1e6:.2f} Mb",
                "results/six/analysis/six_findings.txt")
    old_n = v("B_report_PT_TIL25_shared", f"{m[6]}", "results/six/analysis/six_findings.txt")

    # ---- panel C
    ex, e, e25 = EX["ex"], EX["pt"], EX["til25"]
    tab = EX["table"]
    c_n = v("C_candidates", f"{len(tab)}", SB, "TIL25-shared PT elements within +-200 kb of HPC1")
    c_inb = v("C_candidates_in_B73", f"{int(tab.in_B73.sum())}", SB, "flanks found in B73 with the element between")
    c_eb = v("C_candidates_empty_B73_only", f"{int((tab.empty_B73 & ~tab.empty_TIL01).sum())}", SB)
    c_none = v("C_candidates_flanks_absent", f"{int((~tab.in_B73 & ~tab.empty_B73 & ~tab.empty_TIL01).sum())}", SB)
    c_name = v("C_PT_copy", f"chr3:{e.start:,}–{e.end:,}", "PT library (ltrquest_extra/PT_LTRs_depth*_clean_ltr.tsv)")
    c_len = v("C_PT_len", f"{e.end - e.start + 1:,}", "PT library")
    nest = EX["nest"].iloc[0]
    c_nlen = v("C_nested_len", f"{nest.end - nest.start + 1:,}", "PT library", nest["name"])
    c_25 = v("C_TIL25_copy", f"chr3:{e25.start:,}–{e25.end:,}", "TIL25 library")
    c_25len = v("C_TIL25_len", f"{e25.end - e25.start + 1:,}", "TIL25 library")
    c_tsd = v("C_TSD", e.tsd, "libraries + samtools faidx (checked in script)")
    c_k2p = v("C_K2P_PT", f"{e.k2p:.4f}", "PT library")
    c_k2p25 = v("C_K2P_TIL25", f"{e25.k2p:.4f}", "TIL25 library")
    c_age = v("C_age_kyr", f"{e.k2p / (2 * RATE) / 1e3:,.0f}", "K2P / (2 x 3e-8)")
    c_div = v("C_div_PT_TIL25", pct(EX["div"], 2), "results/six/orthologs.PT.TIL25.tsv.gz")
    c_ltr = v("C_LTR_len_PT", f"{e.ltr5_end - e.ltr5_start + 1:,} and {e.ltr3_end - e.ltr3_start + 1:,}", "PT library")
    c_fam = v("C_family_median_len", f"{EX['fam_median_len'] / 1e3:.1f} kb", "PT library",
              f"median length of {EX['fam_n']:,} PT elements of family {e.family}")
    fl = EX["flank"]
    c_fl25 = v("C_flank_diff_TIL25", f"{fl['TIL25'][0]} + {fl['TIL25'][1]}", SB, "100-bp flanks, PT vs TIL25")
    c_flb = v("C_flank_diff_B73", f"{fl['B73v5'][0]} + {fl['B73v5'][1]}", SB, "100-bp flanks, PT vs B73")
    c_flt = v("C_flank_diff_TIL01", f"{fl['TIL01'][0]} + {fl['TIL01'][1]}", SB, "100-bp flanks, PT vs TIL01")
    sb = ex["B73v5_site"]
    stl = ex["TIL01_site"]
    c_sb = v("C_empty_site_B73", f"chr3:{sb[1] - 4:,}–{sb[1]:,}", SB, "single TSD copy")
    c_st = v("C_empty_site_TIL01", f"chr3:{stl[1] - 4:,}–{stl[1]:,}", SB, "single TSD copy")
    c_rel = v("C_dist_from_HPC1_kb", f"{(e.start - pos['PT'][2]) / 1e3:.0f}", SB)

    # ---- panel D
    r_ = {}
    for c in ("km", "ins", "d3", "dself"):
        rr = np.corrcoef(R.snp, R[c])[0, 1]
        sl = np.polyfit(R.snp, R[c], 1)[0]
        r_[c] = (v(f"D_r_{c}", f"{rr:.2f}", "computed from results/six/analysis/ltr_vs_snp.tsv (Pearson, 7 trios)"),
                 v(f"D_slope_{c}", f"{sl:.2f}", "computed from results/six/analysis/ltr_vs_snp.tsv (least squares)"))
    snp = {}
    for rr in R.itertuples():
        k = f"{LAB[rr.P1]}, {LAB[rr.P2]}; {LAB[rr.P3]}"
        snp[k] = (v(f"D_snpD[{k}]", f"{rr.snp:+.3f}", "results/six/analysis/ltr_vs_snp.tsv (= gene_snp/more_*.log)",
                    f"SE {rr.snp_se}"),
                  v(f"D_snpZ[{k}]", f"{rr.snp_z:.1f}", "results/six/analysis/ltr_vs_snp.tsv (= gene_snp/more_*.log)"))
        v(f"D_kmer[{k}]", f"{rr.km:+.3f} (SE {rr.km_se:.3f})", trio_src(rr.trio))
        v(f"D_ins[{k}]", f"{rr.ins:+.3f} (SE {rr.ins_se:.3f})", trio_src(rr.trio))
    genes = v("D_genes_range", f"{R.genes.min():,}–{R.genes.max():,}", "results/six/analysis/ltr_vs_snp.tsv")

    # ---- panel E
    P_ = {(r.a, r.b): r for r in pid.itertuples()}
    P_.update({(r.b, r.a): r for r in pid.itertuples()})
    SE_ = "computed from results/six/orthologs.<A>.<B>.tsv.gz (present pairs with a divergence value)"
    sh = {}
    for (a, b), r in P_.items():
        if a < b:
            sh[(a, b)] = sh[(b, a)] = v(f"E_share[{LAB[a]}-{LAB[b]}]", pct(r.share), SE_,
                                        f"{r.n_near:,} of {r.n_div:,}; median divergence {pct(r.median, 2)}")
            v(f"E_median[{LAB[a]}-{LAB[b]}]", pct(r.median, 2), SE_)
    med = lambda a, b: pct(P_[(a, b)].median, 2)  # noqa: E731
    mx_par = [P_[(m_, p)].share for m_ in ("TIL18", "TIL25") for p in ("TIL01", "TIL11")]
    mz_par = [P_[(m_, p)].share for m_ in ("B73v5", "PT") for p in ("TIL01", "TIL11")]
    mz_mx = [P_[(m_, p)].share for m_ in ("B73v5", "PT") for p in ("TIL18", "TIL25")]
    rng = lambda xs: f"{100 * min(xs):.1f}–{100 * max(xs):.1f}%"  # noqa: E731
    e_mxpar = v("E_range_mexicana_parviglumis", rng(mx_par), SE_)
    e_mzpar = v("E_range_maize_parviglumis", rng(mz_par), SE_)
    e_mzmx = v("E_range_maize_mexicana", rng(mz_mx), SE_)
    rat = [P_[(m_, z)].share / P_[("TIL18", "TIL25")].share for m_ in ("TIL18", "TIL25") for z in ("B73v5", "PT")]
    e_ratio = v("E_ratio_maize_vs_other_mexicana", f"{min(rat):.1f} to {max(rat):.1f}", SE_,
                "share(mexicana, maize) / share(TIL18, TIL25)")
    med_mx = lambda: med("TIL18", "TIL25")  # noqa: E731
    mpar_med = [P_[(m_, p)].median for m_ in ("TIL18", "TIL25") for p in ("TIL01", "TIL11")]
    mmz_med = [P_[(m_, p)].median for m_ in ("TIL18", "TIL25") for p in ("B73v5", "PT")]
    e_mpar_med = v("E_median_range_mexicana_parviglumis", f"{100 * min(mpar_med):.2f}–{100 * max(mpar_med):.2f}%", SE_)
    e_mmz_med = v("E_median_range_mexicana_maize", f"{100 * min(mmz_med):.2f}–{100 * max(mmz_med):.2f}%", SE_)

    # ---- panel F
    F = {}
    for head, trios in F_GROUPS:
        for trio, Rg, S, Dn in trios:
            stt = trio_stats(trio)
            k = f"{LAB[Rg]}, {LAB[S]}; {LAB[Dn]}"
            for t in ("D_kmer", "D_ins", "D3_triples", "D_self_outgroup"):
                if t in stt:
                    d, se, z = stt[t]
                    F[(k, t)] = (v(f"F_{t}[{k}]", f"{d:+.3f}", trio_src(trio), f"SE {se:.3f}"),
                                 v(f"F_{t}_Z[{k}]", f"{z:.1f}", trio_src(trio)))
    zr = lambda keys, t="D_kmer": (f"{min(float(F[(k, t)][1]) for k in keys):.1f}–"  # noqa: E731
                                   f"{max(float(F[(k, t)][1]) for k in keys):.1f}")
    g18 = ["B73, TIL01; TIL18", "PT, TIL01; TIL18", "B73, TIL11; TIL18", "PT, TIL11; TIL18"]
    g25 = ["B73, TIL01; TIL25", "PT, TIL01; TIL25", "B73, TIL11; TIL25", "PT, TIL11; TIL25"]
    z18 = v("F_Z_range_TIL18_donor", zr(g18), "results/six/<trio>/stats.tsv")
    z25 = v("F_Z_range_TIL25_donor", zr(g25), "results/six/<trio>/stats.tsv")
    forced_ins = [F[(k, t)][1] for k in ("TIL18, TIL25; B73", "TIL18, TIL25; PT")
                  for t in ("D_kmer", "D_ins", "D3_triples", "D_self_outgroup")]
    fmax = v("F_forced_mexicana_max_absZ", f"{max(abs(float(z)) for z in forced_ins):.1f}",
             "results/forced/TIL18_TIL25__{B73v5,PT}/stats.tsv")
    rtr = {t: v(f"F_recent_tracts_q05[{t}]", f"{int(ts.loc[t, 'recent_tracts_q05'])}", "results/six/analysis/"
                "trio_summary.tsv") for t in ("B73v5_TIL18_TIL01", "TIL18_TIL01_PT")}
    nf = v("F_n_trios", f"{sum(len(t) for _, t in F_GROUPS) - 3}", "results/six/ (data-defined trios)")

    def fv(k, t="D_kmer"):
        return f"{F[(k, t)][0]} (Z {F[(k, t)][1]})"

    def fz(k, t):
        return F[(k, t)][1]

    script = os.path.join(HERE, STEM + ".py")
    short = [
        "**Recently shared haplotypes leave near-identical copies of the same transposon insertions, so transposon "
        "libraries alone recover known introgressions and rank gene flow as an outgroup SNP test does.** "
        "Three-genome tests detect gene flow between maize and *mexicana*, not its direction.",
        "**A** Around the Inv4m inversion, the highland maize Palomero Toluqueño (PT) and both *mexicana* "
        "accessions share one arrangement, inverted relative to B73, and inside it they share near-identical "
        "transposon copies, whereas PT and B73 share almost none: PT carries the *mexicana* inversion haplotype.",
        "**B** At the flowering-time gene *HPC1*, PT shares transposon insertions with *mexicana* TIL25 on both sides "
        "of the gene, while B73 switches at the gene to insertions shared with *parviglumis* TIL01; the gene "
        "copies themselves pair the same way.",
        "**C** One of these insertions at base-pair resolution: PT and TIL25 carry the same insertion, with the same "
        "target-site duplication and identical flanks; B73 and TIL01 carry the empty site, with one copy of the "
        "duplication.",
        "**D** Across seven genome trios, the excess sharing read from transposon libraries alone rises in step with "
        "the excess read from gene-space SNPs with an outgroup.",
        "**E** Each *mexicana* accession shares more near-identical transposon copies with maize than with the other "
        "*mexicana*, which gene flow from *mexicana* into maize alone would not be expected to produce; maize is "
        "similarly close to each *parviglumis*.",
        "**F** Every trio: maize shares more with *mexicana* than *parviglumis* does in all eight comparisons, "
        "clearly so with TIL18 as donor, and PT more than B73; the two *parviglumis* differ slightly; forced into one "
        "trio, the two *mexicana* share equally with maize.",
    ]
    long_ = [
        "**Terms.** Six genomes, one assembly each: maize B73 and the highland landrace Palomero Toluqueño (PT); "
        "*Z. mays* ssp. *parviglumis* TIL01 and TIL11; ssp. *mexicana* TIL18 and TIL25; each annotated for "
        "LTR-retrotransposons (LTR-RTs) alone. Ortholog: the same insertion in two genomes (1:1, from the libraries "
        "alone); divergence: the difference between its two copies; near-identical: below 0.2% "
        "(A, E). Trio \"R, S; D\": does R share more with the donor D than its sister S does? D = excess sharing "
        "(0 = none), ± 2 SE by block jackknife. Ages at 3 × 10^{−8} substitutions per site per year.",
        f"**A** Chromosome 4, B73 {v('A_window_B73', f'{A_WIN[0] / 1e6:.0f}–{A_WIN[1] / 1e6:.0f} Mb', 'panel A window (B73 v5), as SPEC (~160-200 Mb) widened to show the flanks')} and the orthologous stretch of each "
        f"genome, one bp scale; each of the {v('A_n_anchors_drawn', f'{nA:,}', SA)} lines joins a 1:1 ortholog pair "
        "of neighboring rows, colored if near-identical. Black boxes: blocks inverted relative to B73 (B73 "
        f"coordinates): PT {blk['PT']}, TIL25 {blk['TIL25']}, TIL18 {blk['TIL18']} (green: published Inv4m, "
        f"{v('A_Inv4m_published', '172.88–188.13 Mb', 'Fig. 1 / SPEC (B73 v5 chr4:172,883,881-188,131,462)')}); "
        f"TIL11 none; TIL01 a different inversion, {blk['TIL01']}. Inside Inv4m, PT–TIL25 orthologs have median divergence "
        f"{vals['PT-TIL25_in'][1]} (n = {vals['PT-TIL25_in'][0]}; {vals['PT-TIL25_in'][2]} near-identical; "
        f"outside {vals['PT-TIL25_out'][1]}), TIL25–TIL18 {vals['TIL25-TIL18_in'][1]} (n = "
        f"{vals['TIL25-TIL18_in'][0]}; outside {vals['TIL25-TIL18_out'][1]}), but B73–PT {vals['B73-PT_in'][1]} "
        f"(n = {vals['B73-PT_in'][0]}; outside {vals['B73-PT_out'][1]}, n = {vals['B73-PT_out'][0]}). PT and both "
        "*mexicana* share a young inverted haplotype, long separated from B73's arrangement.",
        f"**B** *HPC1* (Barnes et al. 2022) placed in each genome by aligning B73's copy (PT {hpos['PT']}); rows "
        "centered on the gene, ± 200 kb. Every element drawn to size (LTRs pointed 3′, nested ones stacked); B73 "
        "and PT elements are "
        "colored by class with TIL25 as donor and TIL01 as sister (near-identical: below "
        f"{thr_s}, the trios' threshold); ribbons join 1:1 orthologs; TIL01 and TIL25 elements take their partner's "
        f"color. PT: {n_pt_d} of {n_pt} elements shared with TIL25 and absent from TIL01, {n_pt_s} with TIL01 only. "
        f"B73: {n_b_s} of {n_b} with TIL01 only ({n_b_sn} near-identical), {n_b_d} with TIL25 (left of the gene, "
        f"also in PT). Posterior: PT ≥ {pt_post_min} within 50 kb; B73 {b_left_s} on the left, ≤ {b_right_s} "
        f"rightward (≤ {b73_tiL18} over ± 200 kb with TIL18 as donor). Gene copies differ at "
        f"{dd[('PT', 'TIL25')]} of {alen} positions between PT and TIL25, {dd[('B73v5', 'TIL01')]} between B73 and "
        f"TIL01, {dd[('B73v5', 'PT')]} between B73 and PT.",
        f"**C** Rule: of the {c_n} TIL25-shared PT elements in B, the one with an empty site in both B73 and TIL01 "
        f"by 100-bp flank alignment ({c_inb} others are also in B73, {c_eb} is empty in B73 only, {c_none} have "
        f"flanks in neither). PT copy {c_name} (Gypsy/Retand, {c_len} bp with a nested {c_nlen}-bp Copia/SIRE only "
        f"in PT; {c_rel} kb right of *HPC1*); TIL25 copy {c_25} ({c_25len} bp; family median {c_fam}): TSD "
        f"{c_tsd} at both ends, TG…CA ends, LTRs {c_ltr} bp, LTR divergence {c_k2p} and "
        f"{c_k2p25} (about {c_age} kyr), copies {c_div} apart. Flanks differ at {c_fl25} "
        f"positions between PT and TIL25, at {c_flb} between PT and B73 or TIL01 (gray). Empty sites (B73 {c_sb}, "
        f"TIL01 {c_st}) hold one TSD copy; flank hits are unique within 2 Mb.",
        f"**D** The seven trios with a gene-space SNP test (ABBA–BABA in {genes} genes, *Z. diploperennis* "
        "outgroup); lines join one trio's k-mer and insertion values; least-squares fits drawn. Pearson r = "
        f"{r_['km'][0]} (slope {r_['km'][1]}) for single-copy k-mers, {r_['ins'][0]} ({r_['ins'][1]}) for "
        f"insertions; ortholog-triple divergence r = {r_['d3'][0]}, self-outgroup ABBA–BABA {r_['dself'][0]}. SNP D "
        f"ranges from {snp['TIL18, TIL25; B73'][0]} (TIL18, TIL25; B73; Z {snp['TIL18, TIL25; B73'][1]}) to "
        f"{snp['PT, TIL01; TIL18'][0]} (PT, TIL01; TIL18; Z {snp['PT, TIL01; TIL18'][1]}). Trios share genomes, so "
        "the points are not independent; the weak trios are ranked as the SNPs rank them.",
        "**E** Each row is one genome; its five points are its partners, at the share of their 1:1 orthologous "
        f"LTR-RTs below 0.2% divergence; dashed tick: the same-subspecies pair. TIL18: PT {sh[('TIL18', 'PT')]}, B73 "
        f"{sh[('TIL18', 'B73v5')]}, TIL25 {sh[('TIL18', 'TIL25')]}, *parviglumis* {sh[('TIL18', 'TIL01')]}–"
        f"{sh[('TIL18', 'TIL11')]}; TIL25: PT {sh[('TIL25', 'PT')]}, B73 {sh[('TIL25', 'B73v5')]}, *parviglumis* "
        f"{sh[('TIL25', 'TIL01')]}–{sh[('TIL25', 'TIL11')]}. Median divergence: *mexicana*–*mexicana* "
        f"{med('TIL18', 'TIL25')}, *mexicana*–*parviglumis* {e_mpar_med}, *mexicana*–maize {e_mmz_med}. Had maize "
        "only received *mexicana* DNA, its *mexicana*-derived copies should be no closer to either accession than "
        f"the two are to each other; both are {e_ratio} times closer to maize, as gene flow from maize into "
        "*mexicana* (documented in sympatric populations) or maize ancestry gained during propagation would make "
        f"them. Maize is also closer to each *parviglumis* ({e_mzpar}) than the two *parviglumis* are to each "
        f"other ({sh[('TIL01', 'TIL11')]}): the pattern is not specific to *mexicana*.",
        f"**F** All {nf} trios with roles from the data (sisters: the pair sharing most single-copy k-mers; the "
        "sister sharing more with the third genome is listed first, so D ≥ 0) and three post hoc trios with roles "
        "forced; Z at right. Gray lines join B73 and PT tested against the same sister and donor: PT leads in all "
        f"four. Maize vs *parviglumis*: Z {z18} with TIL18 as donor, {z25} with TIL25. PT vs B73: "
        f"{fv('PT, B73; TIL18')} with TIL18, {fv('PT, B73; TIL25')} with TIL25; confident recent-sharing tracts with "
        f"TIL18 against TIL01: PT {rtr['TIL18_TIL01_PT']}, B73 {rtr['B73v5_TIL18_TIL01']}. Two *parviglumis* with "
        f"TIL18: {F[('TIL11, TIL01; TIL18', 'D_kmer')][0]} (Z {fz('TIL11, TIL01; TIL18', 'D_kmer')}; insertions Z "
        f"{fz('TIL11, TIL01; TIL18', 'D_ins')}, triples {fz('TIL11, TIL01; TIL18', 'D3_triples')}, self-outgroup "
        f"{fz('TIL11, TIL01; TIL18', 'D_self_outgroup')}; SNPs {snp['TIL11, TIL01; TIL18'][0]}, Z "
        f"{snp['TIL11, TIL01; TIL18'][1]}), a real asymmetry; "
        f"with TIL25, Z {fz('TIL11, TIL01; TIL25', 'D_kmer')}. No trio pairs the two *mexicana*. Forced TIL18 vs "
        f"TIL25 with B73 or PT as donor: |Z| ≤ {fmax} in all four tests (SNPs {snp['TIL18, TIL25; B73'][0]}, Z "
        f"{snp['TIL18, TIL25; B73'][1]}).",
        "**Limits.** One genome per accession; PT_MEXI5 is a Toronto Agreement release. Inv4m and *HPC1* were "
        "chosen by name; the *HPC1* call rests on eight elements and one trio's posterior. The direction of gene "
        "flow is not identified; the pre-registered direction trio could not be formed (B73 and TIL18 pair) and the "
        "forced trios are post hoc. The f-ratio is not estimable; the spike-in was uninformative (TIL25 is no "
        "closer to TIL18 than *parviglumis* is).",
        f"Analysis: asc-oulab:/data2/chris/maize_introgression/benchmark · Script: {script} · {DATE}",
    ]
    return short, long_


# ---------------------------------------------------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------------------------------------------------
def main():
    global VERBOSE
    ap = argparse.ArgumentParser(description="Build Fig. 4 (fig4_six_genomes): PDF (figure + 2 legend pages), PNG "
                                             "(figure, 300 dpi) and the legend-numbers table.")
    ap.add_argument("-v", "--verbose", action="store_true", help="per-step progress and sanity checks")
    ap.add_argument("--rebuild", action="store_true", help="ignore the ./work cache and re-read every input")
    args = ap.parse_args()
    VERBOSE = args.verbose
    if args.rebuild:
        for p in glob.glob(os.path.join(WORK, "*.pkl")):
            os.remove(p)
    setup_style()
    log("start")
    N = Numbers()
    P = Page(FIG_W, FIG_H)
    P.letter(1.0, 1.0, "A")
    yA_end = panel_A(P, N)
    yB = yA_end + 1.0
    P.letter(1.0, yB, "B")
    yB_end = panel_B(P, yB, N)
    yC = yB_end + 1.5
    P.letter(1.0, yC, "C")
    yC_end = panel_C(P, yC, N)
    yD = yC_end + 3.5
    P.letter(1.0, yD, "D")
    P.letter(62.0, yD, "E")
    P.letter(112.0, yD, "F")
    hD = FIG_H - yD - 16.0
    panel_D(P, 13.0, yD + 3.5, 42.0, hD, N)
    panel_E(P, 77.0, yD + 9.5, 31.0, hD - 6.0, N)
    panel_F(P, 147.0, yD + 3.5, 22.5, hD, N)
    log(f"layout: A ends {yA_end:.1f}, B {yB:.1f}-{yB_end:.1f}, C {yC:.1f}-{yC_end:.1f}, D/E/F from {yD:.1f} mm", True)
    short, long_ = legends(N)
    P.fig.savefig(os.path.join(HERE, f"{STEM}.png"), dpi=300)
    with PdfPages(os.path.join(HERE, f"{STEM}.pdf")) as pdf:
        pdf.savefig(P.fig)
        h1 = legend_page(pdf, short)
        h2 = legend_page(pdf, long_)
    log(f"legend pages {h1:.0f} and {h2:.0f} mm tall", True)
    N.write(os.path.join(HERE, f"{STEM}_numbers.tsv"))
    log("done")


if __name__ == "__main__":
    main()
