"""manifest.json: what was run, on what, with which tools, for reproducibility."""
from __future__ import annotations

import json
import platform
import socket
from collections.abc import Mapping
from datetime import datetime
from importlib import metadata
from pathlib import Path

from .. import __version__
from ..checkpoint import STAGE_MODULES, TOOL_VERSION_ARGS, stage_fingerprint, tool_version
from ..samples import Sample

_PYTHON_DEPS = ("numpy", "numba", "pysam", "mappy", "scipy", "matplotlib")
_OPTIONAL_DEPS = ("msprime",)  # recorded only when installed (the simulator's extra)


def _py_version(name: str) -> str | None:
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        return None


def write_manifest(path: Path, argv: list[str], params: dict, samples: list[Sample],
                   checksums: dict[str, dict[str, str]], started: datetime, finished: datetime,
                   skipped: dict[str, Mapping[str, int]] | None = None) -> None:
    """Write the manifest. checksums: genome label -> {input name: checksum}; skipped: genome label -> its
    annotation loader's skip counts by reason (malformed records included; {} for a genome without one).
    Dependencies: Python, its packages (msprime only when installed) and every external tool the engine can
    run (checkpoint.tool_version; None when absent); code: each cached stage's code fingerprint
    (checkpoint.STAGE_MODULES), which its keys hold."""
    optional = {n: v for n in _OPTIONAL_DEPS if (v := _py_version(n)) is not None}
    deps = {"python": platform.python_version(), **{n: _py_version(n) for n in _PYTHON_DEPS}, **optional,
            **{exe: tool_version(exe) for exe in TOOL_VERSION_ARGS}}
    skipped = skipped or {}
    doc = {
        "tool": "ltrpav", "version": __version__, "code": {s: stage_fingerprint(s) for s in STAGE_MODULES},
        "command": list(argv),
        "params": params,
        "samples": [{"label": s.label, "fasta": str(s.fasta), "annotation": s.annotation, "group": s.group,
                     "role": s.role, "checksums": checksums.get(s.label, {}),
                     "skipped": {k: int(v) for k, v in sorted(skipped.get(s.label, {}).items()) if v}}
                    for s in samples],
        "dependencies": deps, "started": started.isoformat(), "finished": finished.isoformat(),
        "host": socket.gethostname(),
    }
    Path(path).write_text(json.dumps(doc, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
