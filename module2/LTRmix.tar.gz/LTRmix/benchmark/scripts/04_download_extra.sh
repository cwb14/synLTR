#!/usr/bin/env bash
# Download extra benchmark assemblies from MaizeGDB (resumable), check md5, write prefixed run FASTAs.
# PT = Palomero Toluqueno PT_MEXI5 (Barnes et al. parent; Toronto Agreement release), TIL25 = 2nd mexicana,
# TIL11 = 2nd parviglumis, Zd-Gigi = Z. diploperennis outgroup (benchmark comparators only).
set -u
PROJECT=/data2/chris/maize_introgression
RAW=$PROJECT/inputs/raw; OUT=$PROJECT/inputs
BASE=https://download.maizegdb.org
UA='Mozilla/5.0 (X11; Linux x86_64)'
get() { local a=$1 f=$2; mkdir -p "$RAW/$a"
  curl -sS -f -L -A "$UA" --retry 8 --retry-delay 20 --retry-all-errors -C - -o "$RAW/$a/$f" "$BASE/$a/$f" \
    && echo "OK $a/$f $(stat -c %s "$RAW/$a/$f")" || { echo "FAIL $a/$f"; return 1; }; }
LIST="PT:Zm-PT-REFERENCE-HiLo-1.0 TIL25:Zx-TIL25-REFERENCE-PanAnd-1.0 TIL11:Zv-TIL11-REFERENCE-PanAnd-1.0 Zd:Zd-Gigi-REFERENCE-PanAnd-1.0"
pids=()
for x in $LIST; do a=${x#*:}; ( get "$a" "$a.md5"; get "$a" "$a.fa.gz.fai"; get "$a" "$a.fa.gz" ) & pids+=($!); done
wait "${pids[@]}"
for x in $LIST; do
  label=${x%%:*}; a=${x#*:}; d=$RAW/$a
  want=$(grep -F "$a.fa.gz" "$d/$a.md5" | grep -vE "$a\.fa\.gz\.[a-z]" | awk '{print $1}' | head -1)
  have=$(md5sum "$d/$a.fa.gz" | cut -d' ' -f1)
  [ "$want" = "$have" ] && echo "MD5_OK $a" || { echo "MD5_BAD $a want=$want have=$have"; continue; }
  fa=$OUT/$label.fa
  [[ -s $fa ]] && { echo "exists: $fa"; continue; }
  zcat "$d/$a.fa.gz" | awk -v p="${label}_" '/^>/{split(substr($0,2),q,/[ \t]/); print ">" p q[1]; next} {print}' > "$fa.tmp"
  got=$(awk '/^>/{n++; next} {l+=length($0)} END{print n, l}' "$fa.tmp")
  wantn=$(awk '{n++; l+=$2} END{print n, l}' "$d/$a.fa.gz.fai")
  [[ $got == "$wantn" ]] || { echo "ERROR: $label: got [$got], .fai says [$wantn]"; continue; }
  mv "$fa.tmp" "$fa"; echo "PREPARED $label seqs,bases=$got"
done
echo DOWNLOAD_EXTRA_DONE
