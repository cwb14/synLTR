# Task 11 report: Windows
Implemented src/ltrpav/window.py (Window, make_windows with a_lengths, _try_merge) per controller rulings; per-chrom searchsorted, <=3 candidates/side, WINDOW_CAP search bound.
Tests: tests/test_window.py, 14 tests (brief's 8 + spanning block, next-nearest rescue, short block, clipping, nested/ordering, merge-refusal unit test). Full suite + ruff pass.
TDD note: implementation was written before the first test run (no separate RED run); first run failed on 2 bad test fixtures, fixed.
Choices: U window A interval = the element [s0,t0); merge compares only against the last ok window on the chromosome; anchor_right of merged = newest element's.
Commit: "Add anchor-to-window construction".

## Fix report
Change: _try_merge takes anchor_left from the window with smallest a_start and anchor_right from the one with largest a_end (not newest added).
Test: test_merge_anchors_from_outermost_windows (inside, right-extending, left-extending). Command: pytest -q (full suite) + ruff: all pass.
