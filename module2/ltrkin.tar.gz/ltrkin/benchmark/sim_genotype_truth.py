#!/usr/bin/env python3
"""Planted-truth diploid on real sequence, for benchmarking `ltrkin genotype` (see docs/benchmark_genotype_sim.md).

hap1 = the reference region unchanged. hap2 = hap1 with one planted state at each selected element:
  F full         unchanged                                              truth F/F
  E empty site   element + one TSD copy removed                         truth F/E
  S solo LTR     internal region + right LTR removed (the left LTR and   truth F/S
                 both TSD copies stay, as after LTR-LTR recombination)
  H hemizygous   element + 3-15 kb of each flank removed                truth F/N
  O other        a 500-2,000 bp chunk of the internal region removed    truth F/N or F/F
TSD = identical 4-6-mers on both sides of the element (longest k); without one, E removes the element only.
Eligible elements: `depth=0`, neither containing nor inside another element, no partial overlap with another element,
>= --edge bp from the region ends. States are drawn for every eligible element (one fixed random stream per element),
then events are kept left to right when their footprint (element +- TSD; for H, the whole deletion) starts
>= --min-gap after the previous kept footprint. Eligible elements dropped by the spacing rule, nested and overlapping
elements stay unchanged (context, not scored).

Outputs in --outdir: hap1.fa, hap2.fa (sequence names hap1, hap2), region.gff3 (every annotation line of the region's
elements, reference coordinates), truth.tsv (one row per element), events.tsv (hap2 deletions), planted_sv.vcf (two DEL
records per planted element for Sniffles2 --genotype-vcf: empty = element + TSD, solo = internal + right LTR),
check.txt (hand-check examples) and, with --check, check_junctions.tsv (hap2 junction windows aligned back to hap1).
"""
import argparse
import os
import random
import sys
from urllib.parse import unquote

import pysam

STATES = (("F", 0.50), ("E", 0.25), ("S", 0.10), ("H", 0.10), ("O", 0.05))
TRUTH = {"F": "F/F", "E": "F/E", "S": "F/S", "H": "F/N", "O": "F/N|F/F"}
LEN_BINS = ((0, 5000, "<5kb"), (5000, 10000, "5-10kb"), (10000, 17000, "10-17kb"), (17000, 10 ** 9, ">17kb"))
YOUNG_K2P = 0.005


def log(msg):
    print(f"[sim_genotype_truth] {msg}", file=sys.stderr, flush=True)


def parse_region(s):
    chrom, rng = s.rsplit(":", 1)
    a, b = rng.replace(",", "").split("-")
    return chrom, int(a) - 1, int(b)          # 0-based half-open


def gff_attrs(col9):
    d = {}
    for kv in col9.strip().strip(";").split(";"):
        if "=" in kv:
            k, v = kv.split("=", 1)
            d[k.strip()] = unquote(v.strip())
    return d


def read_elements(gff, chrom, r0, r1):
    """LTR-RT features fully inside [r0, r1) with exactly two LTR children. Returns (elements, n_skipped)."""
    feats = []
    for ln in pysam.TabixFile(gff).fetch(chrom, r0, r1):
        x = ln.rstrip("\n").split("\t")
        feats.append((x[2], int(x[3]) - 1, int(x[4]), x[6], gff_attrs(x[8]), ln))
    els = {}
    for t, s, e, strand, a, ln in feats:
        if t.lower().endswith("ltr_retrotransposon") and s >= r0 and e <= r1:
            els[a["ID"]] = dict(id=a["ID"], start=s, end=e, strand=strand, attrs=a, ltrs=[], lines=[ln])
    for t, s, e, strand, a, ln in feats:
        for p in a.get("Parent", "").split(","):
            if p in els:
                els[p]["lines"].append(ln)
                if t == "long_terminal_repeat":
                    els[p]["ltrs"].append((s, e))
    out, skipped = [], 0
    for el in els.values():
        if len(el["ltrs"]) != 2:
            skipped += 1
            continue
        el["lltr"], el["rltr"] = sorted(el["ltrs"])
        if el["lltr"][0] != el["start"] or el["rltr"][1] != el["end"]:
            raise SystemExit(f"element {el['id']}: LTRs do not bound the element; check the annotation convention")
        out.append(el)
    out.sort(key=lambda e: (e["start"], -e["end"]))
    return out, skipped


def relations(els):
    """Containment and partial overlap counts, nearest other element (edge to edge) and TE share of 2-kb flanks."""
    for e in els:
        e.update(n_outer=0, n_inner=0, n_partial=0)
    for i, a in enumerate(els):
        for b in els[i + 1:]:
            if b["start"] >= a["end"]:
                break
            if a["start"] <= b["start"] and b["end"] <= a["end"]:
                a["n_inner"] += 1
                b["n_outer"] += 1
            elif b["start"] <= a["start"] and a["end"] <= b["end"]:
                b["n_inner"] += 1
                a["n_outer"] += 1
            else:
                a["n_partial"] += 1
                b["n_partial"] += 1
    for i, a in enumerate(els):
        best, cov = 10 ** 9, 0
        lo_f, hi_f = (a["start"] - 2000, a["start"]), (a["end"], a["end"] + 2000)
        segs = []
        for j in range(max(0, i - 200), min(len(els), i + 200)):
            if j == i:
                continue
            b = els[j]
            gap = max(b["start"] - a["end"], a["start"] - b["end"], 0)
            best = min(best, gap)
            for f0, f1 in (lo_f, hi_f):
                x0, x1 = max(f0, b["start"]), min(f1, b["end"])
                if x1 > x0:
                    segs.append((x0, x1))
        segs.sort()
        cur0 = cur1 = None
        for x0, x1 in segs:                         # union length
            if cur1 is None or x0 > cur1:
                if cur1 is not None:
                    cov += cur1 - cur0
                cur0, cur1 = x0, x1
            else:
                cur1 = max(cur1, x1)
        if cur1 is not None:
            cov += cur1 - cur0
        a["nn_dist"] = best
        a["flank_te_frac"] = cov / 4000


def infer_tsd(seq, s, e, kmax=6, kmin=4):
    """Longest k in kmax..kmin with identical k-mers right before s and right after e (seq coordinates)."""
    for k in range(kmax, kmin - 1, -1):
        if s - k < 0 or e + k > len(seq):
            continue
        a, b = seq[s - k:s], seq[e:e + k]
        if a == b and "N" not in a:
            return a
    return ""


def pick_state(u, allowed):
    tot = sum(w for st, w in STATES if st in allowed)
    acc = 0.0
    for st, w in STATES:
        if st not in allowed:
            continue
        acc += w / tot
        if u < acc:
            return st
    return [st for st, _ in STATES if st in allowed][-1]


def len_bin(L):
    return next(lab for lo, hi, lab in LEN_BINS if lo <= L < hi)


def wrap(s, n=80):
    return "\n".join(s[i:i + n] for i in range(0, len(s), n))


def build(args):
    chrom, r0, r1 = parse_region(args.region)
    fa = pysam.FastaFile(args.fasta)
    seq = fa.fetch(chrom, r0, r1).upper()
    if len(seq) != r1 - r0:
        raise SystemExit(f"region {args.region} runs past the end of {chrom}")
    els, skipped = read_elements(args.gff, chrom, r0, r1)
    relations(els)
    log(f"{len(els)} elements fully inside {args.region} ({skipped} without two LTRs skipped)")
    for el in els:                                  # region-relative geometry
        el["s"], el["e"] = el["start"] - r0, el["end"] - r0
        el["a"], el["b"] = el["lltr"][1] - r0, el["rltr"][0] - r0
        el["int_len"] = el["b"] - el["a"]
        el["tsd"] = infer_tsd(seq, el["s"], el["e"])
        el["nested"] = el["attrs"].get("depth", "0") != "0" or el["n_outer"] > 0 or el["n_inner"] > 0
        edge = el["s"] < args.edge or el["e"] > len(seq) - args.edge
        el["eligible"] = not el["nested"] and el["n_partial"] == 0 and not edge
        el["why"] = ("nested" if el["nested"] else "overlap" if el["n_partial"] else "edge" if edge else "")
    rng = random.Random(args.seed)
    elig = [el for el in els if el["eligible"]]
    for el in elig:                                 # same number of draws per element: streams stay aligned
        u, u2, f1, f2, cu, cv = (rng.random(), rng.random(), rng.randint(3000, 15000), rng.randint(3000, 15000),
                                 rng.random(), rng.random())
        st = pick_state(u, "FESHO")
        if st == "O" and el["int_len"] < 1000:      # too short for a 500-2,000 bp internal chunk
            st = pick_state(u2, "FESH")
        el["state"] = st
        t = len(el["tsd"])
        if st == "H":
            el["fp"] = (el["s"] - f1, el["e"] + f2)
            el["del"] = (el["s"] - f1, el["e"] + f2)
            el["f1"], el["f2"] = f1, f2
        else:
            el["fp"] = (el["s"] - t, el["e"] + t)
            if st == "E":
                el["del"] = (el["s"], el["e"] + t)
            elif st == "S":
                el["del"] = (el["a"], el["e"])
            elif st == "O":
                cmax = min(2000, el["int_len"] - 200)
                c = 500 + int(cu * (cmax - 500 + 1))
                off = 100 + int(cv * (el["int_len"] - 200 - c + 1))
                el["del"] = (el["a"] + off, el["a"] + off + c)
            else:
                el["del"] = None
    planted, last = [], -10 ** 12
    for el in sorted(elig, key=lambda e: e["fp"][0]):
        if el["fp"][0] - last >= args.min_gap:
            planted.append(el)
            last = el["fp"][1]
            el["planted"] = True
    pset = {el["id"] for el in planted}
    for el in els:
        el.setdefault("planted", False)
        if el["eligible"] and el["id"] not in pset:
            el["why"] = "spacing"
    dels = sorted((el["del"][0], el["del"][1], el["id"], el["state"]) for el in planted if el["del"])
    for (a0, a1, *_), (b0, b1, *_) in zip(dels, dels[1:]):
        if b0 < a1:
            raise SystemExit("internal error: overlapping planted deletions")
    # hap2 = hap1 with the deletions; junction position on hap2 (0-based: first base after the junction)
    parts, cur, removed, junction = [], 0, 0, {}
    for d0, d1, eid, st in dels:
        parts.append(seq[cur:d0])
        junction[eid] = d0 - removed
        removed += d1 - d0
        cur = d1
    parts.append(seq[cur:])
    hap2 = "".join(parts)
    assert len(hap2) == len(seq) - removed
    # context elements touched by a planted deletion (their own state on hap2 changes; never scored)
    for el in els:
        el["hap2"] = "F"
        if el["planted"]:
            continue
        for d0, d1, eid, st in dels:
            if d1 <= el["s"] - 1000 or d0 >= el["e"] + 1000:
                continue
            if d0 <= el["s"] and el["e"] <= d1:
                el["hap2"] = "N"
            elif d1 <= el["s"] or d0 >= el["e"]:
                el["hap2"] = el["hap2"] if el["hap2"] != "F" else "F_near_event"
            else:
                el["hap2"] = "broken"
    os.makedirs(args.outdir, exist_ok=True)
    with open(os.path.join(args.outdir, "hap1.fa"), "w") as fh:
        fh.write(">hap1\n" + wrap(seq) + "\n")
    with open(os.path.join(args.outdir, "hap2.fa"), "w") as fh:
        fh.write(">hap2\n" + wrap(hap2) + "\n")
    with open(os.path.join(args.outdir, "region.gff3"), "w") as fh:
        fh.write(f"##gff-version 3\n##sequence-region\t{chrom}\t1\t{fa.get_reference_length(chrom)}\n")
        for el in els:
            for ln in el["lines"]:
                fh.write(ln.rstrip("\n") + "\n")
    cols = ["element_id", "chrom", "start", "end", "strand", "length", "ltr5_len", "ltr3_len", "int_len", "family",
            "clade", "K2P_d", "depth_attr", "nest_status", "n_outer", "n_inner", "n_partial", "nn_dist",
            "flank_te_frac", "len_bin", "age_bin", "category", "tsd", "tsd_len", "state", "truth", "hap2_state",
            "del_start", "del_end", "del_len", "flank5_del", "flank3_del", "hap2_junction"]
    with open(os.path.join(args.outdir, "truth.tsv"), "w") as fh:
        fh.write("\t".join(cols) + "\n")
        for el in els:
            a = el["attrs"]
            k2p = a.get("K2P_d", "NA")
            try:
                age = "young" if float(k2p) <= YOUNG_K2P else "old"
            except ValueError:
                age = "NA"
            cat = "planted" if el["planted"] else ("context_" + el["why"])
            st = el["state"] if el["planted"] else "."
            d = el.get("del") if el["planted"] else None
            row = [el["id"], chrom, el["start"] + 1, el["end"], el["strand"], el["end"] - el["start"],
                   el["lltr"][1] - el["lltr"][0], el["rltr"][1] - el["rltr"][0], el["int_len"], a.get("family", "."),
                   a.get("clade", "."), k2p, a.get("depth", "."), a.get("nest_status", "."), el["n_outer"],
                   el["n_inner"], el["n_partial"], el["nn_dist"], f"{el['flank_te_frac']:.3f}",
                   len_bin(el["end"] - el["start"]), age, cat, el["tsd"] or ".", len(el["tsd"]), st,
                   TRUTH[st] if el["planted"] else ("F/F" if el["hap2"] == "F" else "."), el["hap2"],
                   d[0] + r0 + 1 if d else ".", d[1] + r0 if d else ".", d[1] - d[0] if d else ".",
                   el.get("f1", ".") if st == "H" else ".", el.get("f2", ".") if st == "H" else ".",
                   junction.get(el["id"], -1) + 1 if d else "."]
            fh.write("\t".join(map(str, row)) + "\n")
    with open(os.path.join(args.outdir, "events.tsv"), "w") as fh:
        fh.write("element_id\tstate\tchrom\tdel_start\tdel_end\tdel_len\thap1_start\thap1_end\thap2_junction\n")
        for d0, d1, eid, st in dels:
            fh.write(f"{eid}\t{st}\t{chrom}\t{d0 + r0 + 1}\t{d1 + r0}\t{d1 - d0}\t{d0}\t{d1}\t{junction[eid]}\n")
    write_vcf(os.path.join(args.outdir, "planted_sv.vcf"), planted, fa, chrom, r0)
    counts = {}
    for el in planted:
        counts[el["state"]] = counts.get(el["state"], 0) + 1
    cat_counts = {}
    for el in els:
        k = "planted" if el["planted"] else "context_" + el["why"]
        cat_counts[k] = cat_counts.get(k, 0) + 1
    log(f"categories: {cat_counts}")
    log(f"planted {len(planted)}: " + ", ".join(f"{k} {counts.get(k, 0)}" for k, _ in STATES)
        + f"; hap1 {len(seq)} bp, hap2 {len(hap2)} bp ({removed} bp deleted)")
    hand_check(os.path.join(args.outdir, "check.txt"), planted, seq, hap2, junction, r0, chrom)
    return seq, hap2, planted, junction, r0


def write_vcf(path, planted, fa, chrom, r0):
    """Two DEL records per planted element: empty site (element + TSD) and solo LTR (internal + right LTR)."""
    recs = []
    for el in planted:
        t = len(el["tsd"])
        s, e, a = el["start"], el["end"], el["lltr"][1]          # reference (absolute) 0-based coordinates
        for allele, d0, d1 in (("empty", s, e + t), ("solo", a, e)):
            pos = d0                                             # 1-based base before the deletion = 0-based d0 - 1
            ref = fa.fetch(chrom, pos - 1, pos).upper()
            recs.append((pos, f"{el['id']}|{allele}", ref,
                         f"SVTYPE=DEL;SVLEN={-(d1 - d0)};END={d1};ALLELE={allele};ELEMENT={el['id']}"))
    recs.sort()
    with open(path, "w") as fh:
        fh.write("##fileformat=VCFv4.2\n")
        fh.write(f"##contig=<ID={chrom},length={fa.get_reference_length(chrom)}>\n")
        fh.write('##ALT=<ID=DEL,Description="Deletion">\n')
        fh.write('##INFO=<ID=SVTYPE,Number=1,Type=String,Description="Type of structural variant">\n')
        fh.write('##INFO=<ID=SVLEN,Number=1,Type=Integer,Description="Length difference between ALT and REF">\n')
        fh.write('##INFO=<ID=END,Number=1,Type=Integer,Description="Last deleted base">\n')
        fh.write('##INFO=<ID=ALLELE,Number=1,Type=String,Description="empty (element + TSD) or solo (internal + right LTR)">\n')
        fh.write('##INFO=<ID=ELEMENT,Number=1,Type=String,Description="Element ID">\n')
        fh.write('##FORMAT=<ID=GT,Number=1,Type=String,Description="Genotype">\n')
        # a sample column, so that Sniffles2 (which keeps this header line) writes a well-formed VCF
        fh.write("#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tSAMPLE\n")
        for pos, vid, ref, info in recs:
            fh.write(f"{chrom}\t{pos}\t{vid}\t{ref}\t<DEL>\t.\tPASS\t{info}\tGT\t./.\n")


def hand_check(path, planted, seq, hap2, junction, r0, chrom, per_state=2, w=12):
    """Print example sites: geometry, TSDs, and the hap2 sequence at the junction next to the expected sequence."""
    lines = []
    seen = {}
    for el in planted:
        st = el["state"]
        if seen.get(st, 0) >= per_state:
            continue
        seen[st] = seen.get(st, 0) + 1
        s, e, a, b, t = el["s"], el["e"], el["a"], el["b"], el["tsd"]
        lines.append(f"== {el['id']} state {st} truth {TRUTH[st]}  {chrom}:{el['start'] + 1}-{el['end']} "
                     f"({el['strand']}) length {e - s}, LTRs {a - s} / {e - b}, internal {b - a}, "
                     f"K2P {el['attrs'].get('K2P_d')}, annotated tsd {el['attrs'].get('tsd', '-')} "
                     f"offset {el['attrs'].get('tsd_offset', '-')}")
        lines.append(f"   left TSD {seq[s - 6:s]} | element starts {seq[s:s + 6]} ... element ends {seq[e - 6:e]} | "
                     f"right {seq[e:e + 6]}; inferred TSD '{t}'")
        if el["del"]:
            d0, d1 = el["del"]
            j = junction[el["id"]]
            got = hap2[j - w:j + w]
            exp = seq[d0 - w:d0] + seq[d1:d1 + w]
            lines.append(f"   deletion {chrom}:{d0 + r0 + 1}-{d1 + r0} ({d1 - d0} bp); hap2 junction at {j + 1}")
            lines.append(f"   hap2 {got[:w]}|{got[w:]}  expected {exp[:w]}|{exp[w:]}  {'OK' if got == exp else 'MISMATCH'}")
            if st == "E":
                lines.append(f"   E: one TSD copy left: hap2 {hap2[j - len(t) - 3:j + 3]} = flank+TSD {seq[s - len(t) - 3:s]}"
                             f" + right flank {seq[e + len(t):e + len(t) + 3]}; deleted = element {e - s} + TSD "
                             f"{len(t)} = {d1 - d0}: {'OK' if d1 - d0 == e - s + len(t) else 'BAD'}")
            if st == "S":
                lines.append(f"   S: solo = left LTR ({a - s} bp) between TSDs: hap2 {hap2[j - 4:j]}|{hap2[j:j + 4 + len(t)]}"
                             f"; deleted = internal {b - a} + right LTR {e - b} = {d1 - d0}: "
                             f"{'OK' if d1 - d0 == e - a else 'BAD'}")
        lines.append("")
    with open(path, "w") as fh:
        fh.write("\n".join(lines))


def check_junctions(path, seq, hap2, planted, junction, r0, flank=60000):
    """Align a hap2 window around every junction back to hap1 (minimap2 asm5, local hap1 sequence: the event +- 60 kb,
    so distant repeat copies cannot attract the window) and compare the implied deletion with the planted one: an
    independent check of the coordinates. The window reaches 2 kb past the left LTR, so a solo LTR cannot align
    contiguously to the right LTR."""
    import mappy
    ok = 0
    rows = []
    for el in planted:
        if not el["del"]:
            continue
        d0, d1 = el["del"]
        W = max(3000, el["a"] - el["s"] + 2000)
        j = junction[el["id"]]
        q = hap2[max(0, j - W):j + W]
        x0 = max(0, d0 - flank)
        al = mappy.Aligner(seq=seq[x0:d1 + flank], preset="asm5")
        hits = sorted((h for h in al.map(q) if h.strand == 1 and h.is_primary), key=lambda h: h.q_st)  # no secondaries
        imp = None
        if len(hits) == 1 and hits[0].q_st == 0 and hits[0].q_en == len(q):   # one alignment with a long deletion
            h, r = hits[0], hits[0].r_st
            for ln, op in h.cigar:
                if op == 2 and ln >= 50:
                    imp = (x0 + r, x0 + r + ln)
                    break
                if op in (0, 2, 7, 8):
                    r += ln
        elif len(hits) >= 2:
            # split alignment: query L.q_en <-> ref L.r_en; deletion length = ref gap - query gap
            L = min(hits, key=lambda h: h.q_st)
            R = max(hits, key=lambda h: h.q_en)
            ov = L.q_en - R.q_st
            imp = (x0 + L.r_en, x0 + R.r_st + ov)
        t = len(el["tsd"])
        same_len = imp is not None and (imp[1] - imp[0]) == (d1 - d0)
        status = ("OK" if same_len and abs(imp[0] - d0) <= t + 30 else "SHIFTED" if same_len else "CHECK")
        ok += status == "OK"
        rows.append((el["id"], el["state"], d0 + r0 + 1, d1 + r0, d1 - d0,
                     imp[0] + r0 + 1 if imp else ".", imp[1] + r0 if imp else ".",
                     (imp[1] - imp[0]) if imp else ".", len(hits), status))
    with open(path, "w") as fh:
        fh.write("element_id\tstate\tdel_start\tdel_end\tdel_len\timplied_start\timplied_end\timplied_len\tn_hits\t"
                 "status\n")
        for r in rows:
            fh.write("\t".join(map(str, r)) + "\n")
    n = {k: sum(r[-1] == k for r in rows) for k in ("OK", "SHIFTED", "CHECK")}
    log(f"junction check of {len(rows)} planted deletions: {n['OK']} exact (length; position within TSD + 30 bp), "
        f"{n['SHIFTED']} same length at a shifted position (repeat-equivalent), {n['CHECK']} not recovered")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-f", "--fasta", required=True, help="reference FASTA (indexed)")
    ap.add_argument("-g", "--gff", required=True, help="LTRquest GFF3, bgzipped and tabix-indexed")
    ap.add_argument("-r", "--region", required=True, help="region chrom:start-end (1-based, inclusive)")
    ap.add_argument("-o", "--outdir", required=True, help="output directory")
    ap.add_argument("--seed", type=int, default=1, help="random seed [1]")
    ap.add_argument("--min-gap", type=int, default=25000, help="minimum bp between planted footprints [25000]")
    ap.add_argument("--edge", type=int, default=50000, help="no planted site within this many bp of the region ends "
                    "[50000]")
    ap.add_argument("--check", action="store_true", help="align hap2 junction windows back to hap1 (needs mappy)")
    args = ap.parse_args()
    seq, hap2, planted, junction, r0 = build(args)
    if args.check:
        check_junctions(os.path.join(args.outdir, "check_junctions.tsv"), seq, hap2, planted, junction, r0)


if __name__ == "__main__":
    main()
