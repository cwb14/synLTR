# LTRpav Plan 3: Simulation Grid and Real Benchmark Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Calibrate and measure LTRpav's admixture analyses on simulated populations with known truth (DESIGN 10.2, with
LTRmix run on the same genomes), then run the real benchmark (DESIGN 10.3 rerun at the end, 10.4: six genomes, the *Zea*
genus event, sweet orange, EDTA portability, stability), each with result tables, bars judged PASS or MISS, memos and
dead-end entries.

**Architecture:**
- **Simulator.** A population simulator (`ltrpav-sim pop`) extends Plan 1's pair simulator. It draws msprime genealogies
  with a pulse of admixture on a real B73 backbone: ten 10-Mb windows, each an independent simulated chromosome. On each
  genealogy it places:
  - LTR-RT insertions copied from real families, with identical LTRs at insertion and nesting;
  - losses: solo-LTR, flank deletion, partial deletion, and replacement by other sequence;
  - SNPs and small indels.

  A one-pass builder writes each sample's genome.
- **Truth.** It reuses Plan 1's state rules, with "inherited by Y" in place of "inserted before the split".
- **Calibration.** Parameters the data can measure are set from main3 before the pilot, never from the method's
  outcome: the outgroup split, the loss-mechanism mix and the replacement length.
- **Analysis-package additions,** so the carry-overs can be tested from the command line. The engine is untouched.
  - `ltrpav-paint --discovery any`;
  - `ltrpav-paint --emission decoy`, a decoy-anchored emission model;
  - `ltrpav-stats --block-size`.
- **Benchmark code** lives outside the repo, in `benchmark_pav/plan3/`.
  - A grid driver runs genotype, merge, stats and paint on every simulated run, in eight analysis views.
  - The same driver runs LTRmix on libraries cut from the same annotations.
  - Both tools are scored against the truth by rules dated before any scoring.
  - Real runs are genotyped by one detached queue and analysed through views, as Plan 2's `main3_analyses` was.

**Tech Stack:**
- Python >= 3.10 (env `ltrpav`, 3.12), numpy, scipy, pysam.
- msprime >= 1.3 with tskit, the new optional extra `sim`.
- LASTZ 1.04.60, minimap2 2.31.
- LTRmix runs in its own env `ltrmix` (msprime 1.4.4, pandas).
- LTRquest runs from the pinned env `ltrquest_<GitHub HEAD commit>`.
- pytest, ruff, hatchling.

**Spec:** `/data2/chris/maize_introgression/LTRpav/docs/DESIGN.md`. Plan 3 implements sections 10.2-10.4 and 11, steps
4-5. Sections 1-8, 12 and 14 also bind.

The controller's files are in `.superpowers/sdd/2026-11-12-plan3-benchmark/`:
- the brief, `plan3-drafter-brief.md`;
- the science review, `plan3-review.md`, with its fixes in `plan3-applied.md`;
- the pre-flight scan, `preflight-scan.md`, with its fixes in `preflight-applied.md`;
- the calls made where DESIGN is silent, `plan3-draft-summary.md`.

**Plan series:**
1. Engine, pair simulator, bake-off, QC.
2. Analyses and the overview figure.
3. This plan: population simulator, simulation grid, real benchmark.
4. Head-to-head `REPORT.md` (10.5), final figures, packaging.

**Prior results this plan builds on:**
- **Plan 2's preliminary result,** `benchmark_pav/main3_analyses/PRELIM.md`:
  - D_pav +0.29 (Z 7.4) against LTRmix's D_ins +0.19;
  - one informative insertion per 84 kb (median);
  - no tract at q <= 0.05;
  - fitted emissions near 0 and 1;
  - split s 0.074% against LTRmix's 0.048%.
- **LTRmix's simulator,** `$P/benchmark/scripts/sim_ltr_admix.py`. Its demography and TE rates are this plan's
  defaults; its scorer, `eval_sim.py`, is the template for scoring LTRmix here.

## Drafting probes and what they fix

All probes use perfect genotypes and were run in env `ltrmix`. The drafter's and the review's probes and outputs were
copied at drafting into `$P/benchmark_pav/plan3/sim/probes/`, with `SHA256SUMS`: `drafting_probes_v2.txt`,
`probe_direction.py`, `probe_outgroup_ext.py`, `probe_outgroup.py`, `probe_msprime.py` and `review_probe_dfoil.py`.
The originals were in the session scratch, `plan3draft/` and `plan3review/`.

- **Direction (review C1).** The probe reports DFOIL-alt codes on the quartet A1, A2, C1, C2 (B1, B2 and O absent), with
  the pattern pairs and sign table of `ltrpav.analysis.direction`.
  - **The default demography.** Every one of these reads `0000`, which is "none":
    - no pulse;
    - population pulses C>A and A>C at f 0.18, Ta 5,000;
    - C>A at f 0.5, Ta 500;
    - a PT-like pulse from population C into A1's lineage only (A1's population split 6,000 generations ago).
  - **Lineage-to-lineage pulses** inside the default demography (subpopulations with Ne 10,000 or 1,000) read `+-+-`
    in both directions: "unresolved".
  - **The small-Ne design orients both ways.** In it every population has Ne 1,000, A1's lineage splits from A at
    2,000 generations and C1's from C at 30,000, and the pulse is f 0.5 at 500 generations:
    - C1>A1 reads `+-+0`, P3=>P1;
    - A1>C1 reads `+++-`, P1=>P3;
    - its null reads `0000`.

    At f 0.18, C1>A1 still orients, while A1>C1 reads `++00` (ancestral, unresolved). With A1's split at 5,000, A1>C1
    reads `+-+-`. The directional slot needs the split well inside the A–B split, because the sister-taxon filter cuts
    off older branches.
  - **Consequence.** Under maize-like Ne, DFOIL-alt is predicted not to orient any pulse simulated here. The small-Ne
    design is kept as the positive control of the implementation.
- **Outgroup (review I2).** The probe measures the outgroup conflict: ingroup absent where O carries the insertion, with
  58 backbone elements per Mb in the denominator. main3's measured upper bound is 0.027, 0.032 and 0.031. The rule in
  Task 8 is "smallest candidate split with conflict at most 0.032 in all three", which picks 900,000.

  | t_o (generations) | conflict A1 / B1 / C1 | insertions carried by A1 per Mb (before losses) |
  |---|---|---|
  | 120,000 | 0.229 / 0.204 / 0.202 | 67 |
  | 600,000 | 0.063 / 0.069 / 0.053 | 118 |
  | 900,000 | 0.017 / 0.025 / 0.017 | 146 |
  | 1,200,000 | 0.007 / 0.007 / 0.009 | 180 |

- **Loss mix (review I2).** It is measured from main3's own calls.
  - Set: top-level B73 elements that Zd carries (P/S/T in `B73__Zd`), which are inherited by TIL18 and TIL01. 9,219
    elements.
  - Their derived states pool to S 646, T 2,685, D 861 and O 1,063 (TIL18: 334, 1,405, 468, 583; TIL01: 312, 1,280,
    393, 480): S 0.123, D 0.164, T 0.511, O 0.202. E (2%) and U (7%) are excluded.
  - Mean B-only sequence of those O calls (`b_ins`): 12,915 and 14,295 bp per genome; 13,538 bp pooled over the 1,063
    calls.

## Inputs and provenance

All paths are absolute under `P=/data2/chris/maize_introgression`, and every one is read-only. The canonical LTRmix
comparator tree is `$P/benchmark/`: it holds every LTRmix output; `LTRmix/benchmark/` is a copy.

| Input | Path | Provenance | Use |
|---|---|---|---|
| B73 assembly | `$P/inputs/B73v5.fa` (+.fai; 2,182,075,994 bp) | Zm-B73-REFERENCE-NAM-5.0, MaizeGDB (`inputs/raw/Zm-B73-REFERENCE-NAM-5.0/`, md5) | real runs; simulation backbone |
| B73 LTRquest | `$P/run/B73v5_LTRs` (127,636 elements) | LTRquest 5042a1e (`run/ltrquest.log`) | annotation; backbone elements and donors |
| B73 proteins | `$P/inputs/B73v5.proteins.fa.gz` | Zm00001eb.1 | LTRquest gene masking on simulated genomes |
| TIL18, TIL01, Zd, TIL25, TIL11, Zh, Zn | `$P/inputs/{TIL18,TIL01,Zd,TIL25,TIL11,Zh,Zn}.fa` | PanAnd-1.0, MaizeGDB (`inputs/raw/*`, md5); seqids prefixed `<label>_` | real runs |
| PT | `$P/inputs/PT.fa` | Zm-PT-REFERENCE-HiLo-1.0 (Toronto Agreement: benchmark only, DESIGN 3) | six genomes |
| LTRquest TIL18, TIL01 | `$P/run/{TIL18,TIL01}_LTRs` | LTRquest 5042a1e | six, stability |
| LTRquest PT, TIL25, TIL11 | `$P/benchmark/ltrquest_extra/{PT,TIL25,TIL11}_LTRs` (`*.work` kept) | LTRquest 5042a1e, same flags | six |
| EDTA B73, TIL18, TIL01 | `$P/inputs/annot_{B73v5,TIL18,TIL01}/te.gff3.gz`; cross-check `$P/benchmark_pav/main3/qc_fixed/edta/*.structural.gff3` | MaizeGDB/PanAnd EDTA; `Method=structural` LTR-RTs | portability, genus |
| EDTA TIL25, Zh, Zn | `$P/inputs/raw/{Zx-TIL25,Zh-RIMHU001,Zn-PI615697}-REFERENCE-PanAnd-1.0/*_EDTA.gff3.gz` | PanAnd EDTA (Zn seqids `1`..`10`, FASTA `Zn_chr1`..) | genus |
| Citrus assemblies | `$P/inputs/{CsA,CsB,Cr,Cm,CaM,CaP}.fa` | NCBI GCA_022201045.1, _022201065.1, _059628685.1, _047301065.1, _046470815.1, _046470805.1 (`benchmark/lineage2/02_annotate_and_run.sh`) | sweet orange |
| Citrus LTRquest | `$P/benchmark/lineage2/ltrquest_a/{CsA,CsB,Cr}_LTRs`, `ltrquest_b/{Cm,CaM,CaP}_LTRs` | LTRquest 5042a1e | sweet orange |
| Citrus truth | `$P/benchmark/lineage2/truth/{CsA.P.bed,CsB.M.bed}` | Wu et al. 2023 Hortic Res Suppl. Table 4 (`03_truth.py`) | sweet orange |
| Maize truth | `$P/benchmark/truth/{elai_summary.v5.tsv,hf.v5.bed,loci.v5.tsv}` | Yang et al. 2023 ELAI (figshare 21579528), lifted v4 to v5 | 10.3 rerun, portability, stability |
| main3 calibration data | `$P/benchmark_pav/main3/pairs/B73__{Zd,TIL18,TIL01}.calls.tsv.gz`, `main3_analyses/stats.tsv` | engine 7d71073 | Task 8 calibration |
| LTRmix comparators | `$P/benchmark/results/{main3,six}`, `$P/benchmark/{genus/out,lineage2/out,edta/out,gene_snp}`, `$P/benchmark/scripts/{rate_free_split,eval_sim,sim_ltr_admix,edta_to_lib}.py` | LTRmix v2 runs | beside LTRpav; scorer templates |

Annotated and genotype-only genomes:
- **Six genomes:** B73, PT, TIL18, TIL25, TIL01 and TIL11 are annotated (LTRquest). Zd is genotype-only, the outgroup.
- **Genus:** TIL01, TIL18, TIL25, Zh and Zn are annotated (EDTA). Zd is genotype-only and an ingroup genome, the
  decision-11 case of Task 14. There is no outgroup.
- **Citrus:** all six genomes are annotated (LTRquest). There is no outgroup.
- **Portability:** B73, TIL18 and TIL01 are annotated (EDTA). Zd is the outgroup.
- **Stability:** B73, TIL18 and TIL01 are annotated (LTRquest). Zd is the outgroup.
- **Simulations:** A*, B* and C* are annotated from the truth, or by LTRquest in three runs. O1 is the genotype-only
  outgroup. View `nodonor` treats C1 as unannotated.

Every real genome already has an LTRquest annotation. LTRquest runs only on three simulated runs (Task 10), from the
pinned env `ltrquest_<HEAD>`. On 2026-11-12 the GitHub HEAD was 5042a1e, and env `ltrquest_5042a1e` exists.

## Compute budget

**Measured rates:**

| Item | Measured | Source |
|---|---|---|
| msprime, 7 haploid genomes, LTRmix demography + outgroup | 9.6 s at 5 Mb, 157 s at 20 Mb (Hudson, ~length²), 0.6 GB; 35 s at 10 Mb | drafter, reviewer |
| Insertions per genome at lam 1.2e-10 (no losses) | 146/Mb at t_o 900k (67/Mb at 120k) | `probe_outgroup_ext.py` |
| Genotyping a simulated 27.7-Mb pair (1,916 elements/genome) | 25.8 s, both directions, at 16 threads (~140 calls/s), 0.38 GB | `geno20` |
| Plan 1 `ltrpav-sim pair`, 20 Mb | 7.8 min (whole-array edits: not reusable at 100 Mb) | `simpair20` |
| main3 genotyping | 9 directed pairs in 2 h 11 min at 32 threads (14.6 min/pair), peak 19.6 GiB | brief, memo |
| Analyses on main3 | stats 26 s; identity ~105 pairs/s at 16 threads; paint 22 s | brief |
| LTRmix on 3 x 200-Mb simulated libraries | 1.2 min at 4 threads | LTRmix sim logs |
| LTRquest, 3 citrus genomes (~0.9 Gb) | 1 h 36-38 min at 32 threads, 12 GB | `lineage2/ltrquest_*/ltrquest.time` |

**Estimates.** 32 threads in total; the simulation grid runs two 16-thread runs at a time.

| Job | Estimate |
|---|---|
| One 7-genome run (100-Mb backbone, t_o 900k; ~80 surviving simulated insertions per Mb, so ~177-Mb genomes and ~13,900 elements each) | ~68 min at 16 threads (~34 min effective): msprime ~2 min over 10 workers; builder, truth and writing ~6 min (pilot-measured); genotype 36 directed pairs at ~90 s, 54 min; merge, 8 views, LTRmix and scoring ~6 min |
| One trio run (9 directed pairs) | ~26 min at 16 threads (~13 min effective) |
| Grid rows | 7-genome: 88 + bottleneck nulls (30 or 10); trio: 26; LTRquest: 3 |
| Grid with 30 bottleneck nulls | 118 x 34 min + 26 x 13 min + 3 x 1.4 h = ~77 h |
| Grid with 10 bottleneck nulls | 98 x 34 min + 26 x 13 min + 3 x 1.4 h = ~65 h |
| Six genomes: 36 directed maize pairs | ~9 h |
| Genus: 25 directed pairs (EDTA, 48-61k elements/genome; Zn 3.7 Gb) | ~3 h |
| Citrus: 30 directed pairs (~7,500 elements/genome) | ~0.5 h |
| Portability: 9 directed pairs (EDTA) | ~1 h |
| Stability: `--anchor mm2` (~4.5 h: 0.39/0.19 x 14.6 min x 9) and the 5-kb cap (~2.5 h) | ~7 h |
| Real analyses, identity layer, scoring | ~1.5 h |
| **Real benchmark** | **~22 h** |
| **Total, as projected (10 bottleneck nulls)** | **~87 h (3.6 days)** |
| Total with 30 bottleneck nulls | ~99 h: just over the gate, so the gate is expected to choose 10 |

**Why not the whole genome.** DESIGN 10.2's full grid on whole maize genomes would take months.

**The reduction.** Each simulated genome is a 100-Mb backbone: ten 10-Mb windows, one per B73 chromosome, each its own
chromosome.
- Hudson's cost is about length², and independent 10-Mb chromosomes keep it linear.
- At 100 Mb the full grid fits inside the gate, with every f, every Ta, every dropout level and 30 nulls.

**The pilot gate (Task 8, pre-registered).** Projected hours =

```
(N7 x h7 + 26 x h_trio) / 2 + 3 x h_LTRquest + 22
```

- `N7` = 88 + the bottleneck nulls (30, else 10). The 88 are: 30 null, 36 power, 8 reverse, 3 PT-like, 3 bottleneck
  gene-flow and 8 positive-control runs.
- `h7` is the pilot's measured 7-genome run, at 16 threads.
- `h_trio` is the pilot's fixed steps plus 9/36 of its genotyping.
- `h_LTRquest` is 1.4 h.

The decision:
1. If the projection with 30 bottleneck nulls is at most 96 h, use 30.
2. Else, if it is at most 96 h with 10, use 10.
3. Else, drop the backbone to the first five windows (50 Mb) for every run, and choose 30 or 10 bottleneck nulls by the
   same rule. No other null, f, Ta or dropout level is ever cut.

## Global Constraints

- **Branch:** `plan3-benchmark`, cut from `plan1-engine` at 12d3e6c. Plan 2 is merged there, and `plan2-analyses` is
  deleted.
  - Commits are local; never push.
  - `docs/plans/` is gitignored: never commit it.
- **Authorship.** The user is the sole author.
  - pyproject's `authors` stays as it is.
  - No AI attribution in any file, commit message or trailer.
  - Commit with the global git identity; never set author or committer.
- **Engine modules stay untouched**: `checkpoint.STAGE_MODULES` and the engine's `src/ltrpav/constants.py`.
  `src/ltrpav/analysis/constants.py` is analysis code.
  - Package code goes only in `src/ltrpav/sim/` and `src/ltrpav/analysis/`, with pytest tests on small synthetic
    fixtures.
  - After the last package commit, show that every `STAGE_MODULES` fingerprint equals the one at the branch base.
- **Defect protocol (R9).**
  - A benchmark that finds an engine defect stops and logs it in `benchmark_pav/dead_ends.md`.
  - A separate engine-fix task follows: test first, with its own review.
  - The controller then decides which genotyping to rerun, since an engine change invalidates every pair file. The user
    is told the cost.
  - No benchmark task edits an engine module.
- **No maize-specific names in `src/`.** Nothing there names *Zea*, maize, chromosome names or genome sizes. The
  simulator's taxa are `A`, `B`, `C` and `O`.
  - Maize- and citrus-specific scoring and calibration live only in `benchmark_pav/plan3/`.
  - Calibrated defaults in `src/` give their reason as "measured in the benchmark (DESIGN 12, Plan 3 calibration)".
- **Dependencies.** The only new one is `msprime>=1.3`, as the optional extra `sim`.
  - It is added to `environment.yml` and the CI install line.
  - Importing `ltrpav`, `ltrpav.sim` or `ltrpav.cli` must work without msprime.
  - The lock file is refreshed by commit 84c8088's portable procedure (Plan 2 Task 1 Step 1), never by a raw
    `mamba env export`.
- **Suite:** `python -m pytest -W error -m "not slow"` and `ruff check .`, in env `ltrpav` with
  `NUMPY_MADVISE_HUGEPAGE=0`.
  - A slow test runs once, in the task that adds it.
  - Every test module that imports msprime or tskit starts with `pytest.importorskip`.
- **Long jobs run from frozen code (Task 8).**
  - Every detached job sets `PYTHONPATH=$P/benchmark_pav/plan3/snap/<sha>/src` and asserts that `ltrpav.__file__` lies
    inside that snapshot.
  - Env `ltrpav`'s editable install is a path `.pth`, so PYTHONPATH wins.
  - Envs `ltrpav`, `ltrmix` and `ltrquest_<commit>` are not changed while a detached job runs.
  - The real analyses use a second snapshot only if Task 11 changes analysis code (a default, or the direction
    note). Its engine fingerprints must
    equal the first's.
- **Compute:**
  - Jobs together use at most 32 threads and 250 GB.
  - Probes use at most 16 threads and 15 minutes each.
- **Detached jobs.** Anything over 15 minutes runs as `setsid -f nohup <cmd> > <log> 2>&1 < /dev/null`.
  - Find the PID with `pgrep -af`, then `ps -o pid,ppid,sid,cmd -p <pid>`. SID must equal PID, and the PPID must be 1
    or a systemd user manager.
  - Each job writes a done marker and an exit-code file.
  - Wait on it with a Monitor until-loop, never a foreground sleep.
- **Read-only:** `inputs/`, `run/`, `benchmark/`, `LTRmix/`, `benchmark_pav/main3/`, `benchmark_pav/main3_analyses/`,
  `benchmark_pav/bakeoff/`.
  - LTRmix and its scripts run from env `ltrmix` with `PYTHONDONTWRITEBYTECODE=1`, writing only under
    `benchmark_pav/plan3/`.
  - Snapshot `inputs/*.fai` (size, mtime, sha256) before and after each real job.
- **Science (DESIGN 10, CLAUDE.md).**
  - The bars are DESIGN's. Truth is used only to score.
  - A miss is reported and investigated in `benchmark_pav/dead_ends.md`, never tuned away.
  - Every threshold comes from principle, with a one-line reason, and every heuristic is named.
  - `sim/RULES.md` is written and dated before any run is scored, the pilot included. It holds:
    - the bars' readings;
    - the calibration criteria;
    - the adoption rules for the two painting variants;
    - the direction predictions and rule.
- **Simulator calibration is not method tuning.** The simulator's own parameters may be set from measured properties
  of the real data, written down before the pilot: the outgroup split, the loss-mechanism mix and the replacement
  length. The method's thresholds and bars never are. DESIGN 12 records this as a call (Task 1).
- **Figures.** No figure is a deliverable of Plan 3; Plan 4 draws them. Before drawing anything beyond a quick working
  plot, load the `making-figures` skill (Skill tool) and follow it.
  - The overview has two known limits if Task 13 or 16 draws one with 20 trios: the page runs to about 264 mm, and
    large scaffolds can be called chromosomes.
  - Both go to Plan 4 as figure limits (Task 16's leads).
- **Memos.** Each benchmark directory gets a terse `memo.md` in CLAUDE.md format, with the `claude --resume` name. Task
  16 appends a Plan 3 section to `$P/memo_ltrpav.md`.
- **Language.** American English in code, docs and messages.

## Review Focus

1. **Backbone regions that overlap, are too short, hold N runs, or cut an element** in `ltrpav-sim pop`.
   - Overlapping regions, or one shorter than 2 x `WINDOW_PAD` plus the longest donor, fail with one error line.
   - Disjoint regions on one sequence are fine.
   - No insertion targets an N.
   - An element crossing a region's edge is not a backbone element (Plan 1's rule).
   - Tests: Task 5 `test_pop_regions_overlap_fails`, `test_pop_region_too_short`, `test_pop_two_regions_one_sequence`,
     `test_pop_edge_element_excluded`; Task 2 `test_no_insertion_target_on_n`.
2. **Backbone bases outside ACGTN** (soft-masked lowercase, IUPAC codes in other users' FASTAs).
   - The sequence is upper-cased on load.
   - No SNP lands on a non-ACGT base.
   - No TSD is read across one.
   - Test: Task 2 `test_backbone_case_and_iupac`.
3. **msprime missing.** `ltrpav-sim pop` exits 1 with one line naming `pip install 'ltrpav[sim]'`. `ltrpav-sim pair`,
   `ltrpav` and the analysis commands still work.
   - Test: Task 1 `test_import_without_msprime`.
4. **A dropout that empties an annotation, or one that names the outgroup or an unknown label.** Each of these fails
   before simulating: `--dropout-genome A1=1`, `O1=0.2` and `Z9=0.2`.
   - Test: Task 5 `test_pop_dropout_guards`.
5. **Analysis markers written before the new options**, by Plan 2's code. They read as the defaults through `.get`; they
   never raise a KeyError.
   - Test: Task 7 `test_old_marker_reads_defaults`.

---

## File Structure

```
src/ltrpav/sim/
  popmodel.py     Demog (incl. lineage subpopulations), Rates; msprime demography (LTRmix default + outgroup, optional
                  bottleneck), ancestry per chromosome, truth tracts from migration records; demog_from_json (Task 1)
  popevents.py    events on one chromosome's genealogy: insertions (+ nested), losses incl. replacement, SNPs, small
                  indels (Task 2)
  popbuild.py     one-pass builder per sample: sequence, element copies, coordinate records; assembly gaps (Task 3)
  poptruth.py     per ordered pair truth (TRUTH_COLUMNS), insertion table, tracts in sample coordinates; annotation with
                  dropout, jitter, K2P (Task 4)
  donors.py       pick_donors, backbone_elements, shift_element (moved from sim/cli.py) (Task 5)
  pop.py          PopParams, PopResult, simulate_pop (process pool over chromosomes), write_pop (Task 5)
  cli.py          (modify) `ltrpav-sim pop` (Task 5)
src/ltrpav/analysis/
  paint.py        (modify) emission "decoy"; e0/e1 rows (Task 6)
  constants.py    (modify) PAINT_DISCOVERY, PAINT_EMISSION, EMISSIONS (Task 6)
  stats.py, report.py, cli.py  (modify) --discovery, --emission, --block-size; stage keys (Task 7)
tests/  poptoy.py test_popmodel.py test_popevents.py test_popbuild.py test_poptruth.py test_pop_cli.py;
        test_paint.py, test_cli_analysis.py (modify)
benchmark_pav/plan3/                         (outside the repo)
  snap/<sha>/                                git archive of the reviewed head (Task 8)
  common/  env.sh view.sh evalib.py test_evalib.py compare_papers.py (copy, Task 13)
  sim/     backbone.tsv calibrate.sh calibration.tsv demography.json probe_direction.py direction_predictions.tsv
           make_grid.py grid.tsv pilot.tsv run_one.sh run_grid.sh gff3_to_ltrmix.py test_gff3_to_ltrmix.py
           eval_run.py eval_ltrmix.py summarize.py RULES.md runs/<name>/ lq/<name>/ tables/ SIM_RESULTS.md memo.md
  real/    edta_prep.py test_edta_prep.py cap_variant.py genotype_all.sh
           six/ genus/ citrus/ edta/ stability/{mm2,cap5k,block}/ papers/  (samples.tsv, geno/, views/, RESULTS.md each)
           memo.md
benchmark_pav/dead_ends.md  (append)
```

A simulated run directory, `runs/<name>/`, holds:
- `sim/`: the `ltrpav-sim pop` outputs;
- `geno/`: `ltrpav-genotype` and `ltrpav-merge`;
- `views/{main,roles,any,decoy,anydecoy,nodonor}/`;
- `ltrmix/`;
- `eval/`;
- `run.done` and `run.exit`.

An LTRquest run, `lq/<name>/`, has the same layout. Its `sim/` holds links to the source run's FASTAs and `truth/`, plus
its own `samples.tsv`.

**Shared conventions:**
- **Sample labels,** in sheet order: `A1, A2, B1, B2, C1, C2, O1`. With one genome per taxon: `A1, B1, C1, O1`.
- **Groups:** `A`, `B`, `C` and `O`. `O1` has role `outgroup`.
- **Mapping to LTRmix's simulator:**
  - A = maize (Ne 30,000), derived from B at 9,000 generations;
  - B = parviglumis (100,000);
  - C = mexicana (70,000), split from B at 60,000.
- **Pulse codes:**
  - `C>A` (population C into population A; the default);
  - `A>C`;
  - `C>A1` (into A1's own lineage population `A1p`; PT-like);
  - `C1>A1` and `A1>C1` (lineage to lineage, between `C1p` and `A1p`).
- **The pre-declared trio** of every simulated run is `--trio A1,B1,C1`: R = A1, S = B1, D = C1.
- **Seqids:** `<label>_c01` .. `<label>_c10`.
- **Coordinates:** internal 0-based half-open; truth TSVs 1-based inclusive, as `ltrpav`'s files are; BED 0-based.

---

### Task 1: Branch, msprime extra and the population model

**Files:**
- Create: `src/ltrpav/sim/popmodel.py`, `tests/test_popmodel.py`, `tests/poptoy.py`.
- Modify:
  - `pyproject.toml`, `environment.yml`, `environment.lock.yml`, `.github/workflows/ci.yml`;
  - `src/ltrpav/sim/__init__.py`, so that msprime is not imported at import time;
  - `docs/DESIGN.md` section 12: a "Build decisions (plan 3)" block, one line per call in `plan3-draft-summary.md`,
    including "simulator calibration is not method tuning".

**Interfaces:**
- Produces, in `popmodel.py` (msprime and tskit are imported inside functions):

```python
MSPRIME_HELP = "msprime is required for `ltrpav-sim pop`: pip install 'ltrpav[sim]'"
@dataclass(frozen=True)
class Demog:            # LTRmix sim_ltr_admix.py (diploid Ne; generations) + an outgroup + optional lineage populations
    ne_a: float = 30_000; ne_b: float = 100_000; ne_c: float = 70_000; ne_bc: float = 150_000
    ne_o: float = 150_000; ne_root: float = 150_000
    t_ab: float = 9_000; t_bc: float = 60_000; t_o: float = 900_000   # t_o: measured in the benchmark (DESIGN 12)
    f: float = 0.0; ta: float = 5_000.0
    pulse: str = "C>A"                       # "C>A" | "A>C" | "C>A1" | "C1>A1" | "A1>C1"
    sub_a: tuple[float, float] | None = None  # (split generations, Ne) of A1's own lineage population "A1p"
    sub_c: tuple[float, float] | None = None  # (split generations, Ne) of "C1p"
    bottleneck: tuple[float, float] | None = None   # (Ne, generations) of A right after t_ab
    per_taxon: int = 2
@dataclass(frozen=True)
class Rates:            # per bp (or per element) per generation
    mu: float = 3e-8; r: float = 1e-8; r_low: float = 1e-9; low: tuple[float, float] = (0.3, 0.7)
    lam: float = 1.2e-10; delta: float = 1 / 900_000; indel: float = 3e-9; copy_noise: float = 0.005
    loss_split: tuple[float, float, float, float] = (0.123, 0.164, 0.511, 0.202)  # solo, del_flank, del_partial,
                                                       # replace; drafting measurement (DESIGN 12)
    replace_mean: float = 13_538                       # mean replacement length, bp; drafting measurement (DESIGN 12)
def sample_labels(d: Demog) -> list[tuple[str, str]]        # (label, group): A1..An, B1.., C1.., O1 (group "O")
def demography(d: Demog) -> "msprime.Demography"
def ancestry(d: Demog, rates: Rates, length: int, seed: int) -> "tskit.TreeSequence"
def tracts(ts, d: Demog) -> dict[int, list[tuple[int, int]]]  # sample index -> merged introgressed [l, r) on this
                                                             # chromosome (one call per chromosome)
def demog_from_json(path: Path) -> tuple[Demog, Rates]       # fields named as above; unknown field -> ValueError
```

- Rules:
  - **Populations.** A, B, C and O are extant. B and O get `initially_active=True` (LTRmix's gotcha). Lineage
    populations are extant and derived.
  - **Splits.** In msprime terms:
    - `population_split(t_ab, ["A"], "B")`;
    - `(t_bc, ["B", "C"], "BC")`;
    - `(t_o, ["BC", "O"], "ROOT")`;
    - `sub_a` adds `(split, ["A1p"], "A")`, and `sub_c` adds `(split, ["C1p"], "C")`.

    A1 is sampled from `A1p` when `sub_a` is set, and C1 from `C1p` when `sub_c` is set.
  - **Pulse.** `add_mass_migration(ta, source=<recipient>, dest=<donor>, proportion=f)`. The populations are backward in
    time; `C>A1` uses `A1p` as the recipient.
  - **Bottleneck.** `add_population_parameters_change(t_ab - gens, population="A", initial_size=ne)`.
  - **Recombination.** A `RateMap` with `r` outside and `r_low` on `[low[0]*L, low[1]*L)`. This is LTRmix's
    per-chromosome rule, applied to each 10-Mb window: a heuristic that keeps LTRmix's 40% low-recombination share.
  - **Ancestry.** `sim_ancestry(samples=[SampleSet(n, pop, ploidy=1)...], ploidy=2, record_migrations=True)`.
  - **Tracts of sample s:** the union of the pulse's migration records (time `ta`, recipient to donor) over the intervals
    where the record's node is s or an ancestor of s (`tree.samples(node)`).
  - **Fail fast,** with ValueError, on any of:
    - `f` outside [0, 1];
    - `ta >= t_ab` when `f > 0`;
    - a lineage pulse without its `sub_*`, or `ta` not below the lineage split;
    - an unknown pulse code;
    - `per_taxon < 1`;
    - a bottleneck longer than `t_ab`.

- [ ] **Step 1: Branch and environment.**
  - Preconditions:
    - `plan1-engine` is at 12d3e6c, with Plan 2 merged (or at a later reviewed head);
    - `pgrep -af 'ltrpav|lastz|ltrmix'` prints nothing;
    - `git status` is clean.
  - `git checkout -b plan3-benchmark plan1-engine`.
  - `mamba install -n ltrpav -c conda-forge "msprime>=1.3"`.
  - pyproject: `[project.optional-dependencies] sim = ["msprime>=1.3"]`.
  - `environment.yml`: `- msprime`.
  - CI: `pip install -e ".[dev,sim]"`.
  - Confirm that PyPI has msprime wheels for Python 3.10, 3.12 and 3.13 (`pip download msprime --only-binary=:all:
    --python-version 3.13`). If 3.13 has none, the CI step installs GSL first; say so in the commit.
  - Refresh the lock (84c8088 procedure), then check:
    - `grep -qE '^  - msprime=' environment.lock.yml` succeeds;
    - the file holds neither `prefix:` nor `ltrpav==`.
  - Record the build decisions in DESIGN 12.
- [ ] **Step 2: Write the failing tests** (`tests/test_popmodel.py`, starting with `pytest.importorskip("msprime")`).
  `poptoy.small_demog()` runs in under a second on 200 kb.

```python
def test_sample_times_zero():            # every sample node time 0; labels A1 A2 B1 B2 C1 C2 O1
def test_no_pulse_no_tracts():           # f=0 -> tracts == {} for every pulse code (sub_a/sub_c supplied for the
                                         # lineage codes; the fail-fast stays strict)
def test_full_pulse_covers_recipient():  # f=1, ta=100, "C>A": A1, A2 tracts cover [0, L); B, C, O none
def test_reverse_direction():            # f=1, ta=100, "A>C": C samples covered, A none
def test_lineage_pulse():                # sub_a=(2000,1000), sub_c=(30000,1000), "C1>A1", f=1, ta=500: A1 covered, A2 none
def test_tract_through_ancestor():       # ne_a=5, ta=1000, f=0.5, seed 3: tracts(A1) == tracts(A2) != []
def test_fraction_matches_f():           # L=2 Mb, f=0.18, ta=500, seeds 1-20: mean A1 fraction within 0.18 +- 3 SE
def test_bottleneck_sizes():             # demography(bottleneck=(5000, 2000)).debug(): A 30000 at t=1000, 5000 at t=8000
def test_recombination_map():            # rate 1e-9 at 0.5 L, 1e-8 at 0.1 L
def test_demog_from_json(tmp_path):      # round trip of every field; an unknown key -> ValueError
def test_bad_demog_fails():              # ta=9000 with f>0; pulse "A-C"; f=1.5; "C1>A1" without sub_c -> ValueError
def test_import_without_msprime(monkeypatch):  # sys.modules["msprime"]=None: import ltrpav.sim, ltrpav.cli work;
                                                # ancestry(...) raises RuntimeError(MSPRIME_HELP)
```

- [ ] **Step 3: Run** `python -m pytest -W error tests/test_popmodel.py`. Expected: FAIL (module missing).
- [ ] **Step 4: Implement** `popmodel.py` as the Interfaces block states.
- [ ] **Step 5: Run** the file, then the suite and ruff.
- [ ] **Step 6: Commit:** `"Add the population model for ltrpav-sim pop (msprime extra)"`.

---

### Task 2: Events on the genealogy

**Files:**
- Create: `src/ltrpav/sim/popevents.py`, `tests/test_popevents.py`.
- Modify: `tests/poptoy.py`.
  - `toy_ts`: a hand-built tskit tree sequence from a nested-tuple topology with node times.
  - `toy_backbone`: random bases with planted SimElements.

**Interfaces:**
- Consumes:
  - `Rates` (Task 1);
  - `SimElement` (`sim/genome.py`, the backbone's elements, origin "backbone");
  - `Donor` (`sim/pair.py`);
  - `TSD_DEFAULT`, `SLOP_TSD_MULT` and `MIN_SEG` (engine constants, read only);
  - `pair.FLANK_DEL`, `PARTIAL` and `PARTIAL_MIN`.
- Produces:

```python
@dataclass(frozen=True)
class Ins:          # one LTR-RT insertion event
    iid: str        # "i<chrom:02d><n:06d>"
    host: str | None  # None: before backbone base `pos`; else the iid of the simulated insertion it landed in
    pos: int        # backbone position, or offset in the host's donor body
    node: int; time: float; donor: int; strand: str
    depth: int      # 0 primary, 1-2 nested in a simulated insertion
    carriers: frozenset[int]   # sample indices below the event, before any loss
@dataclass(frozen=True)
class Loss:         # one structural loss of an element on a lineage
    element: str    # iid or backbone eid
    node: int; time: float
    kind: str       # "solo" | "del_flank" | "del_partial" | "replace"
    a: int; b: int  # solo: crossover offset, 0; del_flank: bp beyond left end, beyond right end; del_partial: start
                    # offset in the internal region, length; replace: length of the replacing sequence, 0
    carriers: frozenset[int]
@dataclass
class ChromEvents:
    ins: list[Ins]; losses: list[Loss]
    snp_pos: np.ndarray; snp_base: np.ndarray        # (m,), (m, n_samples) uint8 base codes per sample
    indel_pos: np.ndarray; indel_len: np.ndarray; indel_ins: np.ndarray; indel_carriers: list[frozenset[int]]
    dropped: Counter                                  # ins_n, ins_end, snp_n, nested_after_loss
def draw_events(ts, backbone: bytes, elements: list[SimElement], donors: list[Donor], rates: Rates,
                rng: np.random.Generator) -> ChromEvents
```

- Rules, in this order. `W = SLOP_TSD_MULT * TSD_DEFAULT`. The backbone is upper-cased on load. A non-ACGT base (N or an
  IUPAC code) is never a SNP site, and never inside an insertion's 5 target bases.
  1. **Primary insertions.**
     - `sim_mutations(ts, rate=lam, model=BinaryMutationModel(), discrete_genome=False)`; `pos = floor(position)`.
     - An insertion within `W + TSD_DEFAULT` of a chromosome end is dropped (counted `ins_end`), as is one whose 5
       target bases hold a non-ACGT base (`ins_n`).
     - Donor uniform; strand + or - with probability 1/2.
     - Carriers: the samples below the mutation's node.
     - Positions inside backbone elements are nested in them by position, with host None.
  2. **Losses.** Backbone elements are read on the tree at their start; insertions on the tree at their position, and
     nested ones on their host's.
     - Along every branch below the element's origin (for a backbone element, every branch), draw a Poisson process at
       `delta`, with mechanism probabilities `loss_split`.
     - `solo`, `del_flank` and `replace` end the element on that lineage: no further event is drawn below them.
       `del_partial` does not end it, and needs `PARTIAL_MIN` of internal region.
     - Parameters follow Plan 1's pair simulator:
       - solo: crossover uniform in `1..min(LTR)-1`;
       - del_flank: 50-2,000 bp beyond the left end, the right end, or both (1/3 each);
       - del_partial: 20-60% of the internal region.
     - `replace` length: exponential with mean `replace_mean`, at least `MIN_SEG + 1`. The shape is a named heuristic;
       the mean is measured.
  3. **Nested insertions in simulated insertions,** depth at most 2. For each insertion X, after its losses are drawn:
     - Draw a Poisson count with mean `lam * len(X) * B_X`, where `B_X` is the branch length of X's subtree below its
       event, without the parts below a solo, del_flank or replace of X.
     - Each nested insertion takes a point uniform by length on that subtree and an offset uniform in X's donor body.
       Its carriers are the samples below the point.
     - Then draw the nested insertion's own losses. Depth 2 repeats once.
  4. **SNPs.**
     - `sim_mutations(ts, rate=mu, model=JC69(), discrete_genome=True)`.
     - At each site, relabel the alleles by the permutation of ACGT that sends msprime's ancestral state to the
       backbone base and keeps the order of the other three. JC69 is symmetric, so the law is unchanged.
     - Non-ACGT sites are dropped (`snp_n`). `snp_base` is each sample's base, from `ts.variants()`.
  5. **Small indels.**
     - `sim_mutations(ts, rate=indel, BinaryMutationModel(), discrete_genome=True)`.
     - Each event is an insertion of random bases or a deletion, with probability 1/2 each.
     - Lengths are geometric with mean 3 (`_INDEL_P` in `sim/genome.py`).
     - Carriers are the samples below.

  Inserted bodies take substitutions only (Task 3); small indels touch backbone sequence only.

  Two more rules:
  - **Separate mutation calls.** Each `sim_mutations` call takes the mutation-free tree sequence, never another call's
    output; msprime rejects JC69 and binary alleles on one site.
  - **`dropped["nested_after_loss"]`** counts the nested insertions whose offset falls in host sequence that an earlier
    del_partial of the host already removed on that lineage. They are discarded.

- [ ] **Step 1: Write the failing tests** (toy backbones of 200-500 kb, `toy_ts` for exact genealogies).

```python
def test_carriers_match_genotypes():   # primary insertions: carriers == samples with genotype 1 in the msprime ts
def test_no_insertion_target_on_n():   # 50-kb N block: no target overlaps it; dropped["ins_n"] > 0
def test_backbone_case_and_iupac():    # lowercase backbone -> same events as uppercase; an R/Y block: no SNP there, no
                                       # target across it
def test_snp_ancestral_is_backbone():  # every SNP site: a sample on no mutated lineage reads the backbone base
def test_loss_split():                 # delta=1e-4 toy, every element with >= PARTIAL_MIN internal region: drawn kinds
                                       # within 3 SE of loss_split
def test_loss_ends_lineage():          # no Loss below an earlier solo/del_flank/replace of the same element
def test_replace_length():             # all replace lengths >= MIN_SEG + 1; mean within 3 SE of replace_mean
def test_nested_carriers_and_offsets():  # nested.carriers <= host.carriers; never below an ending loss of the host;
                                          # 0 <= pos < len(donor body)
def test_insertion_count_poisson():    # toy_ts with total branch length T on 1 Mb: n primary in lam*L*T +- 3 sqrt
def test_seed_determinism():           # same rng seed -> identical ChromEvents
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement** `draw_events` as the rules state.
- [ ] **Step 4: Run.** Expected: PASS; then the suite.
- [ ] **Step 5: Commit:** `"Draw insertions, losses, SNPs and indels on simulated genealogies"`.

---

### Task 3: One-pass genome builder and assembly gaps

**Files:**
- Create: `src/ltrpav/sim/popbuild.py`, `tests/test_popbuild.py`.

**Interfaces:**
- Consumes:
  - `ChromEvents`, `Ins`, `Loss` (Task 2);
  - `Rates`, `SimElement`, `Donor`; `SLOP_TSD_MULT`, `TSD_DEFAULT` (engine constants, read only);
  - `pair.GAP_LEN`, `GAP_NEAR`;
  - `genome.revcomp_bytes`, `substitute`.
- Produces:

```python
@dataclass
class Copy:              # one element (backbone eid or iid) as it stands in one built genome
    eid: str; chrom: int; inherited: bool  # sample below the element's origin (backbone: always)
    fate: str            # "intact" | "solo" | "partial" | "deleted" | "replaced" | "absent" | "site_lost"
    start: int; end: int  # image in the genome (0-based half-open, chromosome coordinates), -1 if none
    ltr_left: tuple[int, int]; ltr_right: tuple[int, int]
    own: int; own_kept: int; ltr_own: tuple[int, int]; ltr_kept: tuple[int, int]
    site: int            # chromosome coordinate of the target site when not inherited and its empty-site window is
                         # intact (rule below), else -1
    target: tuple[int, str | None, int]   # (chrom, host, pos) of an insertion's target; backbone (chrom, None, -1)
    host: str | None; tsd: str; k2p: float | None; events: list[str]
@dataclass
class PopGenome:
    label: str; group: str; seqids: list[str]; seqs: list[bytes]
    copies: dict[str, Copy]; gaps: list[tuple[int, int, int]]      # (chrom, start, end)
    lift: list["Lift"]                             # per chromosome
Lift = tuple[np.ndarray, np.ndarray]   # start of every kept backbone piece, in backbone and in genome coordinates
                                       # (int64, ascending)
def build_chrom(chrom: int, backbone: bytes, elements: list[SimElement], ts, ev: ChromEvents, donors: list[Donor],
                rates: Rates, rng: np.random.Generator) -> list[tuple[bytes, dict[str, Copy], Lift]]   # per sample
def lift_pos(lift: Lift, pos: int) -> int     # genome coordinate of backbone position pos; a deleted position maps
                                              # to the next kept base
def add_gaps(genomes: list[PopGenome], per_mb: float, rngs: list[np.random.Generator]) -> None   # one stream/genome
```

- **Event order.** For each sample, the events it carries (insertions, losses, indels) are applied in time order, oldest
  first, in backbone or host coordinates.
  - A deletion removes everything present in its interval at that time, nested elements included.
  - An insertion whose target was deleted earlier on the sample's lineage does not happen there: fate `"site_lost"`.
- **One pass.** The sample's sequence is emitted as pieces in coordinate order and joined once. Pieces are backbone
  slices with the sample's SNP bases, indel insertions and payloads.
  - Element and site coordinates are cumulative piece lengths.
  - The lift map records each kept backbone piece's start in both coordinates (`PopGenome.lift`, `lift_pos`). Task 4's
    `tract_bed` reads it.
  - No per-event array copy is made; that was Plan 1's 7.8-minute cost.
- **The empty-site window** sets `Copy.site`, and Task 4 reads it.
  - It is the w = `SLOP_TSD_MULT * TSD_DEFAULT` bases on each side of the target, plus the TSD.
  - Only losses or deletions that remove window bases break it.
  - SNPs, small indels and insertions at other sites inside the window never break it. This is Plan 1's truth:
    point mutations and Y-specific insertions at other sites are transparent.
- **Payloads.**
  - Each insertion's body is its donor body with fresh `copy_noise` substitutions (LTRmix's 0.5%, one draw per
    insertion). Its left LTR is then copied over its right LTR, so the LTRs are identical at insertion.
  - The body is oriented by strand.
  - The TSD is the sample's 5 target bases at the insertion time: the left copy stays in place, and the right copy
    follows the element as part of the payload.
  - Payload substitutions: each base changes at `mu` per generation along the path from the event point to the sample
    (`genome.substitute`). Branches are shared, so orthologous copies share mutations (LTRmix's recursion).
  - Nested payloads are spliced in at their offsets after their own mutation.
- **Losses.**
  - `solo` keeps the left LTR's first `a` bases and the rest of the right LTR, with both TSD copies. Everything between
    is deleted, nested insertions included.
  - `del_flank` removes the element plus `a` and `b` flank bases in its host.
  - `del_partial` removes `b` internal bases from offset `a`.
  - `replace` deletes the element (and anything nested) and puts `a` random bases in its place, with no TSD change.
    Its fate is `replaced`.
- **Counts and divergence.**
  - `own` counts the element's bases outside anything nested in it; `*_kept` counts those still present.
  - `k2p` is the Kimura 2-parameter distance between the copy's two LTRs.
    - Simulated insertions: compared position by position (equal length, substitution only).
    - Backbone elements: p is the source annotation's p-distance, from its K, plus the sample's derived SNPs in either
      LTR per mean LTR length. It is converted back to K2P with transitions and transversions in the source's ratio
      (JC if unknown).
- **Gaps (`add_gaps`).** `per_mb` 100-bp N runs per Mb per genome. A third start or end within `GAP_NEAR` of an element
  end or an absent element's site; the rest are uniform. They are recorded in `gaps`.
  - Plan 1's density of 2.5 per Mb is conservative against real `G`, 0.02-0.08% of main3's calls.

- [ ] **Step 1: Write the failing tests** (`toy_ts` trees, 200-kb backbones, explicit `ChromEvents`).

```python
def test_tsd_both_sides():          # mu=0: carrier holds TSD, body, TSD at copy coords; non-carrier one TSD at `site`
def test_identical_ltrs_and_k2p():  # mu=0 -> k2p 0 (copy noise leaves LTRs identical); mu=1e-6, age 1e4, 2 leaves:
                                    # mean k2p within 3 SE of 2*mu*age
def test_copy_noise():              # copy_noise 0.005, mu=0: body differs from donor at 0.005 +- 3 SE; LTRs identical
def test_solo_structure():          # one LTR-length segment between the two TSD copies; fate "solo"
def test_flank_deletion():          # del_flank a=300 b=0: element and 300 left bases gone; fate "deleted"
def test_partial_deletion():        # own_kept == own - b; fate "partial"
def test_replace():                 # element gone, `a` new bases between the intact flanks; fate "replaced"
def test_deletion_takes_nested():   # host deleted after a nested insertion: nested fate "deleted" in that lineage
def test_site_lost():               # insertion below an older del_flank covering its target: fate "site_lost"
def test_snp_bases_applied():       # derived sites hold the derived base in carriers only
def test_copy_coordinates_hold_payload():  # seq[start:end] == the copy's payload for every intact copy
def test_lift_pos():                 # positions before and after an insertion, and inside a deletion, map as stated
def test_site_window_ignores_other_insertion():  # another insertion 4 bp from the target in Y: site stays >= 0
def test_backbone_k2p_adds_snps():  # backbone element with source K 0.02 and 3 derived SNPs in one 300-bp LTR:
                                    # k2p > 0.02
def test_gap_rate_and_near_share(): # 1-Mb toy, per_mb=50: 50 gaps; near share within 3 SE of 1/3
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement** `build_chrom` and `add_gaps`.
- [ ] **Step 4: Run.** Expected: PASS; then the suite.
- [ ] **Step 5: Commit:** `"Build simulated genomes in one pass with per-element copy records"`.

---

### Task 4: Truth, annotations and tracts in sample coordinates

**Files:**
- Create: `src/ltrpav/sim/poptruth.py`, `tests/test_poptruth.py`.
- Modify: `src/ltrpav/sim/pair.py`. Two helpers are factored out of `_annotation`, which then uses them.

**Interfaces:**
- Consumes:
  - `PopGenome`, `Copy`, `lift_pos` (Task 3);
  - `truth.TRUTH_COLUMNS`;
  - `COV_PRESENT`, `MIN_SEG`, `REFINE_PAD`, `TSD_DEFAULT`, `SLOP_TSD_MULT`;
  - `elements.Element`, `make_eid`, `annotation.gff3.write_gff3`;
  - `pair.jitter_bounds` and `pair.read_tsd`, factored out of `pair._annotation` here (Annotation, below).
- Produces:

```python
def alive(c: Copy) -> bool          # fate "intact" or "partial", and each LTR keeps >= COV_PRESENT of its own bases
                                    # (Plan 1: not deleted, not a solo-LTR)
def pair_truth(x: PopGenome, y: PopGenome) -> list[dict]   # TRUTH_COLUMNS, one row per alive element of x
def annotate(g: PopGenome, dropout: float, jitter: float, rng: np.random.Generator) -> list[Element]
def tract_bed(g: PopGenome, chrom_tracts: dict[int, list[tuple[int, int]]]) -> list[tuple[str, int, int]]
                                    # chrom_tracts: chromosome index -> this sample's backbone tracts (Task 1 `tracts`,
                                    # taken at the sample's index for each chromosome)
def insertion_rows(genomes: list[PopGenome], ins: dict[int, list["Ins"]]) -> list[dict]   # key: chromosome index
```

- **Truth rules.** These are Plan 1's (`sim/truth.py` docstring), with "inherited by Y" (Y lies below e's origin) in
  place of "present before the split". `w = SLOP_TSD_MULT * TSD_DEFAULT`. For an alive element e of X, read in Y:
  - **`G`:** Y has an N within `REFINE_PAD` of e's site or image in Y.
  - **e not inherited by Y, with a simulated host Y did not inherit:** the outermost such host's truth, plus
    `host_empty` when that truth is E.
  - **e not inherited by Y, otherwise:**
    - `O` when Y carries another insertion whose target overlaps e's target (same chrom and host, positions within
      `TSD_DEFAULT`);
    - `E` when Y's copy has `site >= 0`;
    - `D` otherwise, `site_lost` included.
  - **e inherited by Y:**
    - `S` on fate solo;
    - `O` on fate replaced (unrelated sequence of at least `MIN_SEG` at the intact site, DESIGN 5.4);
    - `P` when `own_kept >= COV_PRESENT * own` and each LTR keeps `COV_PRESENT`;
    - `T` when `own_kept >= MIN_SEG`;
    - `D` otherwise.
  - **The empty-site window** is Task 3's: the w shared bases on each side plus the TSD (`Copy.site`). Plan 1's rule
    holds:
    - only a target overlap gives O;
    - only losses or deletions of window bases give D;
    - **SNPs, small indels and insertions at other sites inside the window never break it.** Plan 1's truth says "a
      1-bp indel beside an empty site leaves it E", and treats Y-specific insertions at other sites as transparent.
  - **Columns.**
    - `origin` is `backbone` or `sim`; `events_x` and `events_y` are the copies' events.
    - `name` is the eid, so `ltrpav-sim score` joins unchanged.
    - Inversions are not simulated, so the painting's inverted-block flags go untested on the sims.
- **Annotation.** Plan 1's `_annotation` rules, applied to alive copies through two helpers factored out of
  `pair._annotation`:
  - `pair.jitter_bounds(start, end, ltr_left, ltr_right, length, jit, ds, dt) -> (start, end, ltr_left_start,
    ltr_right_end)`;
  - `pair.read_tsd(seq, start, end) -> str | None`.

  `_annotation` then uses them. The caller keeps the RNG draws, so `ltrpav-sim pair` stays byte-identical on its tests.
  The rules:
  - each dropped with probability `dropout`;
  - with probability `jitter`, start and end moved by U{-3..3};
  - the TSD read beside the reported ends.

  K2P comes from `Copy.k2p`. Family and superfamily come from the donor or the source. Name is the eid.
- **`tract_bed`** lifts each backbone tract's ends with `lift_pos` (Task 3's `PopGenome.lift`). A payload inserted
  inside a tract belongs to it.

- [ ] **Step 1: Write the failing tests** (engineered histories on `toy_ts`, one test per truth rule).

```python
def test_truth_P_inherited_intact():  def test_truth_E_never_inserted():   def test_truth_S_solo_in_y():
def test_truth_T_partial():           def test_truth_D_deleted_in_y():     def test_truth_D_site_deleted():
def test_truth_O_replaced():          def test_truth_O_same_target():
def test_truth_host_empty():          # nested in a simulated host Y never got: E + host_empty
def test_truth_G_gap_near_site():
def test_truth_E_with_snp_and_indel_beside_site():   # a SNP in the TSD and a 2-bp indel 5 bp from the site: still E
def test_truth_E_with_other_insertion_in_window():   # Y-only insertion 4 bp from e's target: still E
def test_pair_annotation_unchanged():   # tests/test_sim.py's annotation outputs byte-identical with the helpers
def test_annotation_dropout_bounds(): # 2,000 copies, dropout 0.1: annotated within 0.9n +- 3 sd
def test_annotation_loads(tmp_path):  # write_gff3 -> load_annotation: count, TSD, K2P_d, Name == eid
def test_tracts_lifted():             # every copy whose backbone point lies in a tract lies in the lifted tract
def test_score_joins(tmp_path):       # truth TSV + calls equal to truth -> ltrpav-sim score: P and E precision 1.0
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement** the Interfaces.
- [ ] **Step 4: Run.** Expected: PASS; then the suite.
- [ ] **Step 5: Commit:** `"Add population truth, annotations and lifted tracts"`.

---

### Task 5: `ltrpav-sim pop`: orchestration, outputs, command line

**Files:**
- Create: `src/ltrpav/sim/donors.py`, `src/ltrpav/sim/pop.py`, `tests/test_pop_cli.py`.
- Modify:
  - `src/ltrpav/sim/cli.py` (the `pop` subcommand; `pair` imports from `donors.py`);
  - `src/ltrpav/sim/__init__.py`;
  - `docs/DESIGN.md` 10.2: one paragraph on the built simulator.

**Interfaces:**
- Produces:

```python
# donors.py (moved from cli.py; `ltrpav-sim pair` byte-identical on its tests)
def pick_donors(elements: list[Element], fa: Fasta, seed: int) -> list[Donor]          # MAX_DONORS = 2000
def shift_element(e: Element, off: int) -> Element                    # was cli._shift; moved here, pair's CLI imports it
def backbone_elements(elements: list[Element], seqid: str, start: int, end: int) -> list[SimElement]
# pop.py
@dataclass(frozen=True)
class PopParams:
    demog: Demog; rates: Rates
    dropout: float = 0.1; jitter: float = 0.05     # Plan 1 PairParams defaults
    dropout_genome: tuple[tuple[str, float], ...] = (); gap_per_mb: float = 2.5
@dataclass
class PopResult:
    params: PopParams; seed: int; regions: list[tuple[str, int, int]]
    genomes: list[PopGenome]                       # sheet order
    tracts: dict[str, list[tuple[str, int, int]]]  # label -> lifted tracts (recipient-taxon samples)
    truth: dict[tuple[str, str], list[dict]]       # (X, Y) -> rows
    annotations: dict[str, list[Element]]          # ingroup labels
    insertions: list[dict]; meta: dict             # versions, tree counts, events requested/realized/dropped
def simulate_pop(regions: list[tuple[str, int, int]], fasta: Path, annotation: str, params: PopParams, seed: int,
                 threads: int) -> PopResult        # one process per chromosome (pool of `threads`)
def write_pop(outdir: Path, result: PopResult) -> None
```

- **Assembly.** `simulate_pop` runs `ancestry`, `draw_events` and `build_chrom` per chromosome. It joins each sample's
  chromosomes into one `PopGenome`, then calls `add_gaps`, `pair_truth`, `annotate` and `tract_bed`.
- **Seeds.** Chromosomes are numbered from 1 (seqids `c01`-`c10`). The streams are stated in `pop.py`'s docstring:
  - donors: `[seed, 0]` (Plan 1's, unchanged);
  - chromosome c: `[seed, c]`, from which msprime's `random_seed`s are drawn;
  - gaps of genome g (its sheet index): `[seed, 100, g]`;
  - annotation of genome g: `[seed, 200, g]`.

  Results do not depend on `threads`.
- **Outputs** in `outdir`:
  - `<label>.fa`;
  - `<label>.gff3` for A*, B* and C*;
  - `samples.tsv`, with columns `label fasta annotation group role` and paths relative to the sheet; O1 has annotation
    `.` and role `outgroup`;
  - `truth/<X>__<Y>.tsv` for every annotated X and every other Y;
  - `truth/insertions.tsv`: iid, chrom, host, pos, time, node, depth, family, carriers, survivors, fate per sample;
  - `truth/tracts.<label>.bed`;
  - `truth/fractions.tsv`;
  - `params.json`: seed, PopParams, regions, FASTA and annotation (path, sha256), msprime and tskit versions, trees per
    chromosome, events requested, realized and dropped, truth state counts.
- **CLI:**

```
ltrpav-sim pop --fasta FA --region SEQ:START-END [--region ...] --annotation ANNOT --outdir DIR
               [--demography FILE.json] [--seed N] [--f F] [--ta GEN] [--pulse CODE] [--per-taxon N]
               [--bottleneck NE,GEN] [--dropout X] [--dropout-genome LABEL=X ...] [--jitter X] [--threads N] [-v]
```

  - `--demography` sets any `Demog` or `Rates` field (`demog_from_json`). The flags given on the command line override
    it.
  - Exit codes follow Plan 1: 1 with one `error:` line, 2 for usage.
  - The command fails fast on:
    - overlapping regions;
    - a region shorter than 2 x `WINDOW_PAD` plus the longest donor;
    - `--dropout-genome` naming the outgroup or an unknown label, or a value of 1 or more;
    - a missing msprime (`MSPRIME_HELP`).

- [ ] **Step 1: Move** `_donors` and `_shift` into `donors.py` (`pick_donors`, `shift_element`) and add
  `backbone_elements`. Run `tests/test_sim.py`. Expected: PASS, unchanged.
- [ ] **Step 2: Write the failing tests.** The toy FASTA is 3 x 300 kb and the toy GFF3 has 40 elements; the module
  starts with `pytest.importorskip("msprime")`.

```python
def test_pop_writes_outputs(tmp_path):   # all files; read_samples loads samples.tsv; groups A,B,C,O; O1 outgroup
def test_pop_deterministic(tmp_path):    # same seed twice; threads 1 vs 2: byte-identical FASTA, GFF3, truth
def test_pop_demography_json(tmp_path):  # JSON t_o=300000 recorded in params.json; --f overrides the JSON's f
def test_pop_regions_overlap_fails(tmp_path):    # exit 1, one "error:" line
def test_pop_two_regions_one_sequence(tmp_path): # disjoint windows on one seqid: chromosomes c01, c02
def test_pop_edge_element_excluded(tmp_path):    # element crossing a region end is not a backbone element
def test_pop_dropout_guards(tmp_path):   # A1=1 -> exit 2 (argparse value check); O1=0.2, Z9=0.2 -> exit 1 (labels
                                         # checked after parsing); one error line each
def test_pop_region_too_short(tmp_path): # shorter than 2 x WINDOW_PAD plus the longest donor -> exit 1, one line
@pytest.mark.slow
def test_pop_end_to_end(tmp_path):       # pop (per-taxon 1) -> ltrpav-genotype -> ltrpav-merge -> ltrpav-stats
                                         # --trio A1,B1,C1: exit 0, D_pav rows; ltrpav-sim score on pairs/C1__A1 against
                                         # truth/C1__A1.tsv gives P and E rows
```

- [ ] **Step 3: Run.** Expected: FAIL.
- [ ] **Step 4: Implement** `pop.py` and the subcommand.
- [ ] **Step 5: Run** the file, then the slow test once (`python -m pytest -W error tests/test_pop_cli.py`), then the
  suite and ruff.
- [ ] **Step 6: Engine-key check** (every `STAGE_MODULES` fingerprint equals the branch base's). Commit:
  `"Add ltrpav-sim pop: population simulation on a real backbone"`.

---

### Task 6: Decoy-anchored emission model for the painting

**Files:**
- Modify: `src/ltrpav/analysis/paint.py`, `src/ltrpav/analysis/constants.py`, `tests/test_paint.py`.

**Interfaces:**
- Consumes: `classes`, `fit_hmm`, `paint` and `HmmFit` (paint.py); `tests/catalog_toy` (`ToyRun`, `loc`).
- Produces:
  - in `constants.py`:
    - `PAINT_DISCOVERY = "recipient"`, DESIGN 7.1's default;
    - `PAINT_EMISSION = "em"`, the default until Task 11 rules;
    - `EMISSIONS = ("em", "decoy")`. `paint.DISCOVERY` stays the one source of the discovery choices, and the CLI reads
      it;
  - `fit_hmm(pos, emit, starts, e0, e1, fix_e0: bool = False) -> HmmFit`. With `fix_e0`, EM never updates e0.
  - `paint(cat, trio, blocks, discovery=PAINT_DISCOVERY, emission=PAINT_EMISSION, self_counts=None)`.
  - New paint rows per trio:
    - `StatRow("pav", "paint", scope, "all", "emission", <"em"|"decoy">)`;
    - numeric rows `e0_RD`, `e0_RS`, `e1_RD`, `e1_RS`: the fitted emissions, beside `donor_state`; NA for a skipped or
      collapsed painting.
- **The model.**
  - With `emission="decoy"`, e0 is fixed at the decoy's informative class frequencies, using the EM update's
    pseudocounts: `e0 = ((n_D + 0.5) / (n + 1), (n_X + 0.5) / (n + 1))`.
    - n_D and n_X are the decoy's donor-like and recipient-like loci (`classes(cat, Y, X, D, discovery)`), and n their
      sum.
    - Reason: under the target-decoy design the sister carries no D introgression, so its class mix is the empirical
      sister-like background.
  - e1 starts at `e0 * (5, 0.2)` normalized. EM updates e1, pi and L.
  - The donor-like state needs `e1[RD] > e0[RD]`.
  - Without a decoy, the model falls back to `em`, with one WARNING naming why. That covers a sister unannotated under
    recipient discovery, and a decoy with no informative locus.
  - The q-values are unchanged in definition. Whether the decoy's double use keeps them honest is measured in Task 11
    (realized FDR).

- [ ] **Step 1: Write the failing tests.** Build degenerate input directly; do not rely on a seed. A failing seeded test
  is investigated by Plan 2's rule: seeds 6-25, at most 1 of 20.

```python
def test_decoy_e0_fixed():              # emission="decoy": fit.e0 == ((n_D+0.5)/(n+1), (n_X+0.5)/(n+1))
def test_em_degenerates_decoy_does_not():  # ToyRun with sparse loci in perfectly class-segregated runs (10 RD runs of
                                            # 3 loci, 10 RS runs of 3, 200 kb apart): default fit e1[RD] > 0.99 and
                                            # e0[RS] > 0.99; decoy fit on the same input: its posteriors are not
                                            # 0/1 copies of the classes (some locus has 0.05 < post < 0.95)
def test_emission_rows():               # every painted trio has emission, e0_RD, e0_RS, e1_RD, e1_RS rows; e* sum to 1
def test_decoy_null_no_tract():         # simulate_run seed 5, no planted tract: no target tract at q <= 0.05
def test_decoy_planted_tract():         # seed 5, one planted 2-Mb RD-rich tract: mean posterior over its loci > 0.5
def test_decoy_without_decoy_falls_back():  # sister unannotated: emission row "em", one WARNING naming the reason
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement** the model as specified.
- [ ] **Step 4: Run.** Expected: PASS; then the suite. On a scratch copy of the main3_analyses view, the default
  painting's rows must be byte-identical before and after. The new emission and e* rows and the stage sentinel rows are
  excluded from the comparison: sentinels hold the stage key, which the analysis fingerprint changes.
- [ ] **Step 5: Commit:** `"Add a decoy-anchored emission model to the painting (option, off by default)"`.

---

### Task 7: Command-line options and stage keys: `--discovery`, `--emission`, `--block-size`

**Files:**
- Modify:
  - `src/ltrpav/analysis/cli.py`, `report.py`, `stats.py`;
  - `tests/test_cli_analysis.py`;
  - `docs/DESIGN.md` 7.1, 7.3, 7.4, 8 and 10.4: the options and their roles.

**Interfaces:**
- Consumes: `paint(..., discovery, emission)` (Task 6); `stats.block_size`.
- Produces:
  - `ltrpav-paint --discovery {recipient,any}` (default `PAINT_DISCOVERY`).
  - `ltrpav-paint --emission {em,decoy}` (default `PAINT_EMISSION`).
  - `ltrpav-stats --block-size BP`: an integer >= `BLOCK_MIN`. Without it, DESIGN 7.3's rule applies.
  - `stats.block_size(cat, override: int | None = None) -> int`, and one row:
    `StatRow("pav", "jackknife", "all", "all", "block_bp", size, loci="none", note="rule" | "--block-size")`.
  - Stage keys and markers include `discovery`, `emission` and `block_size`. The stale-part check reads them from
    markers with `.get(name, default)`.
  - `ltrpav run` keeps the defaults and gains no option.

- [ ] **Step 1: Write the failing tests.**

```python
def test_paint_discovery_any_cli(tmp_path):  # rows' loci declare disc=any; posterior and tracts files written
def test_paint_emission_rerun(tmp_path):      # default paint, then --emission decoy: paint stage recomputed; the same
                                              # again: skipped; emission row "decoy"
def test_old_marker_reads_defaults(tmp_path): # a paint marker without the new keys: no KeyError; read as the defaults
def test_block_size_option(tmp_path):         # toy where 1-Mb blocks give >= 3 blocks; --block-size 1000000: block_bp
                                              # row 1000000, D_pav se finite and different from the
                                              # default; --block-size 5 -> exit 2
def test_plot_accepts_default_options(tmp_path):  # stats + paint (defaults) + plot: draws (Plan 2 sentinel rules hold)
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement** the options, keys and rows. Keep the plot stage's sentinel checks (Plan 2 final wave I2).
- [ ] **Step 4: Run** the suite, ruff and the engine-key check.
- [ ] **Step 5: Commit:** `"Expose the painting variants and the jackknife block size on the command line"`. This head is
  what Task 8 snapshots.

---

### Task 8: Simulation harness: snapshot, calibration, direction predictions, grid, pilot

**Files** (in `benchmark_pav/plan3/`):
- `snap/<sha>/`;
- `common/{env.sh,view.sh}`;
- `sim/`: `backbone.tsv`, `calibrate.sh`, `calibration.tsv`, `demography.json`, `probe_direction.py`,
  `direction_predictions.tsv`, `make_grid.py`, `grid.tsv`, `pilot.tsv`, `run_one.sh`, `run_grid.sh`, `gff3_to_ltrmix.py`,
  `test_gff3_to_ltrmix.py`, `pilot/`, `memo.md`;
- `sim/probes/` (already there: the drafting and review probes, copied 2026-11-12).

**Interfaces:**
- Consumes:
  - `ltrpav-sim pop` (Task 5);
  - `ltrpav-genotype`, `ltrpav-merge`;
  - `ltrpav-stats` and `ltrpav-paint` with Task 7's options;
  - LTRmix: `python $P/LTRmix/ltrmix.py --genome L=FA,TSV ... --outdir DIR -t 8 --no-figure`, in env `ltrmix`.
- Produces:
  - `view.sh RUN VIEW SHEET [PAIRS_FILTER]`. It makes VIEW with:
    - symlinks to RUN's `loci.tsv`, `manifest.json`, `pairs`, `qc.tsv` and `work/elements`;
    - SHEET written as `samples.tsv`, with its `fasta` and `annotation` columns made absolute (resolved against SHEET's
      directory). `read_samples` resolves relative paths against the sheet's own directory, so a plain copy would break
      every simulated view. Task 5's portable relative sheet stays as it is.

    With `PAIRS_FILTER` (a query label to leave out):
    - `pairs/` becomes a directory of links to every pair file whose query is not that label;
    - each linked file's `.calls.tsv.gz.done.json` marker is linked beside it, because `ltrpav-merge` reads the markers;
    - that label's annotation is set to `.` in the written sheet;
    - `loci.tsv`, `manifest.json` and `qc.tsv` are not linked, and the view runs `ltrpav-merge` itself.

    `view.sh` refuses an existing directory that is not a view.
  - `run_one.sh NAME [--from STEP] [--until STEP] [--rundir DIR]`. It reads NAME's grid row and runs the steps `sim`,
    `geno`, `views`, `ltrmix` and `eval` in DIR (default `runs/NAME`). A step is skipped when its marker exists.
  - `run_grid.sh TSV [--until STEP]` (Step 7).
  - `gff3_to_ltrmix.py GFF3 FASTA OUTPREFIX`. It writes an LTRmix generic library with `edta_to_lib.py`'s conventions.
    It fetches each element's span through the FASTA's `.fai` (pysam) and never reads the whole FASTA:
    - header `seqid:start-end#LTR/<superfamily or unknown>`;
    - minus-strand elements reverse-complemented;
    - table `seq_id k2p tsd strand ltr5_len ltr3_len`, where ltr5 is the genome-left LTR.

- [ ] **Step 1: Snapshot.**
  - `git archive <Task 7 head> src | tar -x -C snap/<sha>`, and write `snap/<sha>/SHA`.
  - `common/env.sh`:
    - exports `PYTHONPATH=snap/<sha>/src`, `NUMPY_MADVISE_HUGEPAGE=0` and `PYTHONDONTWRITEBYTECODE=1`;
    - asserts `ltrpav.__file__` is in the snapshot.

    Every script sources it.
- [ ] **Step 2: Backbone.** `backbone.tsv` lists the ten windows below.
  - They were drawn once at drafting with `numpy.random.default_rng(20261112)`: one 10-Mb start per B73 chromosome,
    uniform in [0, length - 10 Mb], redrawn above 1% N (none needed).
  - The element counts are the fully-inside elements of `run/B73v5_LTRs`.

  | region | elements | note |
  |---|---|---|
  | `B73v5_chr1:293751269-303751268` | 582 | 0.53% N |
  | `B73v5_chr2:204375545-214375544` | 555 | |
  | `B73v5_chr3:97859161-107859160` | 597 | pericentromeric |
  | `B73v5_chr4:23967460-33967459` | 594 | |
  | `B73v5_chr5:214711285-224711284` | 515 | |
  | `B73v5_chr6:58924490-68924489` | 658 | |
  | `B73v5_chr7:94584939-104584938` | 609 | pericentromeric |
  | `B73v5_chr8:18636237-28636236` | 586 | |
  | `B73v5_chr9:18667517-28667516` | 584 | |
  | `B73v5_chr10:12972514-22972513` | 612 | |

- [ ] **Step 3: Calibrate the simulator, before the pilot.** Simulator calibration, not method tuning (Global
  Constraints). `calibrate.sh` writes `calibration.tsv` (value, command, source) and `demography.json`:
  1. **Loss mix.** Take B73's top-level elements (`level` 0) that `B73__Zd` calls P, S or T. Join them by `eid` to
     `B73__TIL18` and `B73__TIL01`, and count the states S, T, D and O. Pool the two, normalize the four, and write
     `loss_split` in the order solo, del_flank, del_partial, replace = S, D, T, O.
     - Drafting values: 0.123, 0.164, 0.511, 0.202 (pooled S 646, D 861, T 2,685, O 1,063).
     - Reason: these elements are inherited by both sisters, so every S/T/D/O is a derived loss as the classifier reads
       it. E (2%) and U (7%) are not losses.
  2. **Replacement length.** `replace_mean` is the mean `b_ins` of those O calls, pooled over calls. Drafting value:
     13,538 bp.
  3. **Outgroup split.** For each candidate `t_o` in {120,000; 300,000; 600,000; 900,000; 1,200,000}, run
     `sim/probes/probe_outgroup.py`'s computation:
     - perfect genotypes, `popmodel.demography`, one 10-Mb chromosome, seed 11;
     - backbone 58 elements/Mb in the denominator.

     Take the smallest candidate whose outgroup conflict is at most 0.032 in A1, B1 and C1. 0.032 is main3's largest
     measured `outgroup_conflict frac_E`, an upper bound that includes errors. Drafting result: 900,000.
  4. Every other field stays the LTRmix default. `demography.json` holds calibrate.sh's exact values and governs every
     run: each grid row passes it with `--demography`. The `src` defaults (Task 1) are the drafting values. DESIGN 12
     records both (Task 16).
- [ ] **Step 4: Direction predictions, before any scoring.**
  - `sim/probe_direction.py` starts from `sim/probes/probe_direction.py` and runs in env `ltrpav` (msprime since Task 1).
    It reads
    `demography.json`, and imports the pattern pairs and `DFOIL_ALT_SIGNS` from `ltrpav.analysis.direction` rather than
    copying them.
  - Run it for every direction scenario of the grid (kinds `null`, `power`, `reverse`, `ptlike`, `bneck`, `posctl`),
    with perfect genotypes and 4 x 10 Mb (posctl 30 x 10 Mb). It writes `direction_predictions.tsv`: scenario, code,
    label.
  - About 29 scenarios take more than 15 minutes, so the run is detached (Global Constraints): at most 16 processes,
    with a done marker.
  - Expected codes, from the drafting probe:
    - `0000` ("none") for every population or PT-like pulse;
    - posctl `C1>A1` `+-+0` (P3=>P1), posctl `A1>C1` `+++-` (P1=>P3), posctl null `0000`.
  - If no posctl design orients, `RULES.md` says so, and direction power is reported as not estimable under this
    demography. That is not a miss.
- [ ] **Step 5: Grid.** `make_grid.py --bneck-nulls N` writes `grid.tsv` with the columns
  `name design per_taxon f ta pulse sub ne bottleneck dropout_A1 seed kind`. `ne` is 1000 for posctl (every
  population's Ne) and empty otherwise.
  - Every row uses `demography.json`. Base annotation: dropout 0.1, jitter 0.05.
  - Total: 88 + the bottleneck nulls on 7 genomes, and 26 trio rows.

  | kind | rows | design | values | seeds |
  |---|---|---|---|---|
  | null | `null_s101`..`null_s130` | 7g | f 0 | 101-130 |
  | power | `f{f}_Ta{ta}_r{1,2}` | 7g | f 0.02 0.05 0.10 0.18 0.25 0.50 x ta 50 500 5000, `C>A` | 1001-1036 |
  | reverse | `rev_f{f}_Ta{ta}_r{1,2}` | 7g | f 0.10 0.25 x ta 500 5000, `A>C` | 3001-3008 |
  | ptlike | `pt_r{1,2,3}` | 7g | `C>A1`, sub_a (6000, ne_a), f 0.18, ta 5000 | 5001-5003 |
  | bneck | `bn_null_s{1..30 or 1..10}`, `bn_f0.18_Ta5000_r{1,2,3}` | 7g | bottleneck 5000,2000; f 0 or 0.18 `C>A` | 4001-4033 |
  | posctl | `pc_C1A1_r{1,2,3}`, `pc_A1C1_r{1,2,3}`, `pc_null_r{1,2}` | 7g | every Ne 1,000; sub_a (2000, 1000), sub_c (30000, 1000); f 0.5, ta 500 | 6001-6008 |
  | dropout | `fn{0.2,0.4}_null_s{1..10}`, `fn{0.2,0.4}_f0.18_r{1,2,3}` | trio (per_taxon 1) | dropout_A1 0.2 or 0.4; ta 5000 | 2001-2026 |

  The number of bottleneck nulls (30 or 10) is set by the Step 11 gate, which regenerates `grid.tsv`.
- [ ] **Step 6: `run_one.sh`.**
  - Settings: `set -euo pipefail`; each step under `/usr/bin/time -v -o <step>.time`; `run.exit` on exit; `run.done`
    after `eval`.
  - **`sim`:**

    ```
    ltrpav-sim pop --fasta $P/inputs/B73v5.fa <--region x 10> --annotation $P/run/B73v5_LTRs --outdir sim
      --demography sim/row.json --seed S --f F --ta T --pulse P --per-taxon N [--bottleneck 5000,2000]
      [--dropout-genome A1=X] --threads 16
    ```

    `sim/row.json` is `demography.json` with the row's own fields merged over it: `sub` (sub_a, sub_c) and `ne` (every
    population's Ne). `row.json` records them.

  - **`geno`:** `ltrpav-genotype --samples sim/samples.tsv --outdir geno --threads 16`, then
    `ltrpav-merge --samples sim/samples.tsv --outdir geno`.
  - **`views`:**

    | view | commands |
    |---|---|
    | `main` | `ltrpav-stats --trio A1,B1,C1` (plus `--identity --threads 16` for kind null), then `ltrpav-paint --trio A1,B1,C1`: calibration and power |
    | `roles` | `ltrpav-stats` then `ltrpav-paint` (every trio, roles from the data): the head-to-head painting and the direction rows |
    | `any` | stats `--trio A1,B1,C1`, then paint `--trio A1,B1,C1 --discovery any` |
    | `decoy` | stats `--trio A1,B1,C1`, then paint `--trio A1,B1,C1 --emission decoy` |
    | `anydecoy` | stats `--trio A1,B1,C1`, then paint `--trio A1,B1,C1 --discovery any --emission decoy` |
    | `nodonor` | null and power rows only; `view.sh RUN nodonor sim/samples.tsv C1` (C1's annotation `.`, its own pair files and markers left out); `ltrpav-merge`, then `ltrpav-stats --trio A1,B1,C1`. Decision 11's default fallback on simulated truth; the rule is not changed |

  - **`ltrmix`:** convert A1, B1, C1 and C2's GFF3 (A1, B1, C1 in the trio design). With three libraries LTRmix writes the
    trio's files in `ltrmix/` itself, and with four in `ltrmix/A1_B1_C1/` (ltrmix.py L1615). Then in env `ltrmix` run
    `ltrmix.py --genome A1=lib/A1.fa,lib/A1.tsv ... --outdir ltrmix -t 8 --no-figure`.
    - For kind null, also run `$P/benchmark/scripts/rate_free_split.py --res ltrmix --donor C1=lib/C1.fa,lib/C1.tsv
      --sister B1=lib/B1.fa,lib/B1.tsv --recipient A1=lib/A1.fa,lib/A1.tsv -t 8 --out ltrmix/rate_free_split.tsv`,
      with stdout to `rate_free_split.txt`.
    - Its s line prints before the LTRquest-only section. With generic libraries the script then exits non-zero: record
      the exit and keep the line.
  - **`eval`:** Task 9's `eval_run.py runs/NAME` (env `ltrpav`) and `eval_ltrmix.py runs/NAME` (env `ltrmix`).
- [ ] **Step 7: `run_grid.sh TSV [--until STEP]`.**
  - Runs `xargs -P 2 -L 1 ./run_one.sh` over the names, passing `--until` on: two runs of 16 threads.
  - Writes `<TSV>.done` when every row's `run.exit` is 0 and the marker of its last requested step exists (`run.done`
    without `--until`).
  - Failures are listed in `<TSV>.failed` with their exit codes.
- [ ] **Step 8: Library converter test.** `test_gff3_to_ltrmix.py` builds a toy GFF3 and FASTA with one + and one -
  element.
  - Assert the exact headers, sequences and table row.
  - In env `ltrmix`, `ltrmix.load_library` reads the toy library (count 2).
- [ ] **Step 9: Pilot.**
  - `pilot.tsv` is two grid rows, `null_s101` and `f0.18_Ta5000_r1`. They are grid rows, and the grid later skips them
    by marker.
  - Run `setsid -f nohup ./run_grid.sh pilot.tsv --until ltrmix > pilot/pilot.log 2>&1 < /dev/null`. Scoring waits
    for `RULES.md` (Task 9).
  - Verify the PID, then wait on `pilot.tsv.done` or `pilot.tsv.failed`.
  - Record each step's wall time and peak RSS.
  - Check `nodonor`. If the catalog refuses the view, record the error and fix `view.sh` within the view's own files;
    the rule is untouched.
  - Compare the realized counts with the estimates: genome length ~177 Mb, ~13,900 elements per genome, 36 pair files.
- [ ] **Step 10: Realism check against the calibration.** Report the pilot's measured values against main3's:
  - per-pair state fractions and resolved fraction (`qc.tsv`);
  - outgroup conflict (`outgroup_conflict frac_E`);
  - D_pav counted and informative loci per Mb;
  - painting `n_informative` and `spacing_median`.

  Reported, not tuned. Write the numbers into `sim/memo.md`.
- [ ] **Step 11: Budget gate.** Apply the pre-registered formula (Compute budget) with the pilot's `h7` and the trio
  estimate.
  - Set the bottleneck null count to 30 or 10, or apply the 50-Mb fallback.
  - Regenerate `grid.tsv` with `make_grid.py --bneck-nulls N`.
  - Under the 50-Mb fallback, move the two pilot runs' directories aside (`runs/<name>.100Mb`), so that the grid reruns
    them on 50 Mb like every other row.
  - If the gate picks 30 bottleneck nulls, tell the user: about 12 h more than the expected 10.
  - Record the decision and its numbers in `sim/memo.md`.

---

### Task 9: Scoring, `RULES.md`, and the pilot's scores

**Files** (in `benchmark_pav/plan3/`): `common/evalib.py`, `common/test_evalib.py`, `sim/eval_run.py`,
`sim/eval_ltrmix.py`, `sim/summarize.py`, `sim/RULES.md`.

**Interfaces:**
- **Environments.**
  - `evalib.py` is numpy only.
  - `eval_run.py` and `summarize.py` run in env `ltrpav` (snapshot; numpy, scipy).
  - `eval_ltrmix.py` runs in env `ltrmix` (pandas).
- **Consumes:**
  - stats.tsv rows by name:
    - `D_pav` (D, n_RD, n_SD; strata incl. `no_outgroup_filter`), `D_pav_gradient` (dD), `f4_ratio` (f), `roles`
      (source), `resolution`;
    - `paint` (n_tracts_q05, posterior_mean, decoy_posterior_mean, excess, n_informative, spacing_median, emission,
      e0_RD, e0_RS, e1_RD, e1_RS);
    - `dfoil` (DFO, DIL, DFI, DOL, signature), `direction` (D_dir, n_XY, n_YX);
    - `identity_split` (s), `outgroup_conflict` (frac_E), `jackknife` (block_bp);
    - sentinel rows (layer `run`, test `part`, a text value) are skipped.
  - The painting files: `posterior.<R>.tsv` (`seqid start end class post`), `tracts.<R>.bed` (`start0 end q`) and
    `decoy_tracts.<S>.bed`.
  - `qc.tsv`, `truth/`, `ltrpav-sim score`.
  - LTRmix's trio files sit in `ltrmix/` itself when LTRmix got three libraries (trio design, LTRquest runs), and in
    `ltrmix/A1_B1_C1/` with four (ltrmix.py L1615). The files:
    - `stats.tsv`;
    - `elements.<R>.tsv` (`post_ancestry_<D>`, `post_recent_<D>`; plain text);
    - `tracts.<R>.bed` and `ancestry.<R>.bed`, for the recipient LTRmix chose;
    - the root-level `orthologs.<X>.<Y>.tsv.gz`.
  - `ltrpav.analysis.stats.jackknife` and `block_ids` (public).
- **Produces** (`evalib.py`):

```python
def auroc(score: np.ndarray, label: np.ndarray) -> float                  # Mann-Whitney, nan if one class empty
def bp_overlap(a: list[tuple[int, int]], b: list[tuple[int, int]]) -> int  # merged intervals, one sequence
def recall_by_length(truth, called, bins=(0, 5e4, 2e5, 1e6, inf)) -> dict  # found when called tracts cover >= 50%
def precision_by_length(truth, called, bins=(0, 5e4, 2e5, 1e6, inf)) -> dict  # bp precision of called tracts by their
                                                                              # own length bin
def tract_fdr(called, truth) -> tuple[int, int]                         # (called tracts overlapping no true tract, all)
def dfoil_direction(signature: str, p12: str, p34: str) -> str          # "P3=>P1"-type labels -> "<taxon>><taxon>";
                                                                         # "unresolved" (ancestral, "or" labels); "none"
def truth_d(rows_dr, rows_ds, rows_do, coords, block: int, outgroup: bool) -> dict   # D, se, z, n_RD, n_SD
def resign(z: float, called_recipient: str, true_recipient: str) -> float
def match_by_coords(called: list[Element], true_rows: list[dict], slop: int) -> dict  # LTRquest element -> true eid
                                                                                       # (both ends within slop)
```

**`eval_run.py RUN`** writes `eval/eval.json`, which holds the sha256 of each eval script. It contains:
- **Design:** kind, f, ta, pulse, and the true fractions.
- **Calibration and power,** from view `main`:
  - D_pav D, se, z and n for every stratum (`no_outgroup_filter` included), and dD with its z;
  - f4 against A1's true fraction;
  - n counted and n informative.
- **Roles,** from view `roles`: whether the inferred sister pair, donor and recipient match the truth.
- **Truth D,** on true states with the tool's block rule `min(5 Mb, max(smallest // 100, 10 kb))`:
  - donor-discovered (C1's annotated elements present, R and S resolved, O1 E), with and without the outgroup filter;
  - sister-discovered (LTRmix's D_ins loci): A1's elements present in C1 with B1 E, against B1's elements present in C1
    with A1 E.
- **Head-to-head painting,** from view `roles` (kinds with pulse `C>A`):
  - the recipient LTRpav inferred for {A1, B1, C1};
  - if it is A1: element AUROC of `post` against "inside a true A1 tract", bp precision and recall (all, and at
    q <= 0.05), recall and precision by length, recall also by true length in informative loci (length / the run's
    mean spacing), the realized tract FDR at q <= 0.05, and the excess against the true fraction;
  - if it is not A1: `wrong_recipient = 1`, recall 0, AUROC NA.
- **Model comparison,** from views `main`, `any`, `decoy` and `anydecoy`:
  - the same painting scores with the recipient fixed at A1;
  - e0 and e1, and `degenerate` (e1_RD > 0.99 and e0_RS > 0.99);
  - in nulls, n target tracts at q <= 0.05 and the excess.
- **Direction,** from view `roles`, taxa (A, C):
  - the signature mapped by `dfoil_direction`, against `direction_predictions.tsv` and the truth;
  - D_dir.
- **Decision 11,** from view `nodonor`: D_pav, se, z and n, and the discovery genomes named in findings.txt.
- **Genotypes,** on every directed pair:
  - eval_run joins calls to truth per element (call eid to Name to truth row, as `score.py` does). It checks that its
    pooled totals equal `ltrpav-sim score`'s;
  - pooled per state, all and high tier; split by target class (into O1, or ingroup) and by backbone window;
  - **LTRquest annotations**, where the sheet's annotation is not the simulator's GFF3:
    - elements map to true eids by `match_by_coords` (slop `SLOP_TSD_MULT * TSD_DEFAULT`, 10 bp);
    - matched elements get the same per-state counts, and unmatched ones are counted;
    - `ltrpav-sim score` is not called, since it needs eid Names.
- **Identity** (kind null): s against the true `2 * mu * t_bc` = 0.0036.
- **Realism:** per-pair state fractions and resolved fraction (`qc.tsv`), outgroup conflict, D_pav counted and
  informative loci per Mb, painting n_informative and spacing_median, and elements per Mb. Each sits beside main3's
  values:
  - D_pav 2,041 loci, 0.97/Mb;
  - painting 7,515, spacing 84 kb;
  - conflict 0.027-0.032;
  - B73->TIL18 P 21%, E 21%, D 22%, O 17%, U 15%, S 0.9%, resolved 46%.

**`eval_ltrmix.py RUN`** (env `ltrmix`) ports `eval_sim.py`'s logic onto A1's coordinates:
- D_kmer, D_ins, D3 and D_self, each with Z re-signed toward A1 (`sim_summary.py`);
- D_ins young and old;
- f-ratio with C2;
- the recipient LTRmix chose. If it is not A1, `wrong_recipient = 1`, recall 0 and AUROC NA, as for LTRpav. A missing
  `elements.A1.tsv` is recorded, never an error.
- element AUROC (ancestry and recent);
- tract bp precision and recall, recall by length, and tract FDR at q <= 0.05;
- presence/absence accuracy: `orthologs.<X>.<Y>.tsv.gz` status against `truth/` (DESIGN 10.5);
- `rate_free_split`'s s.

**`summarize.py`** (env `ltrpav`) writes `sim/tables/{null,calibration,power,tracts,direction,dropout,variants,
genotype,ltrmix,gaps,realism,decision11}.tsv` and every bar of `RULES.md`. Power is reported per (f, ta) as:
- mean and SD of Z;
- the fraction of runs with Z > 3;
- a probit fit of P(Z > 3) on f per ta, with the f at 80% power and its profile interval;
- the Z projected by locus count: `Z_sim * sqrt(2041 / n_sim)`, labeled as a projection.

LTRpav's `no_outgroup_filter` stratum stands beside LTRmix's D tests, since LTRmix has no outgroup.

**`RULES.md`** is written verbatim from this list, and dated, before any run is scored:
1. **Null bar (DESIGN 10.2).** D_pav, pre-declared trio, stratum `all`: |Z| > 3 in at most 1 of the 30 nulls (5% of 30
   is 1.5). Report the Clopper-Pearson 95% interval.

   The same count is reported for:
   - truth D;
   - LTRmix's four D;
   - `nodonor`;
   - the bottleneck nulls.
2. **Calibration reading.** A null Z is calibrated when both hold:
   - the 95% chi-square interval of its SD over the 30 nulls includes 1;
   - its mean lies within 2 SE of 0.

   Applied to D_pav, dD, truth D and LTRmix's four D. SD(D) over the nulls is also reported against the mean jackknife
   SE. The bar stays rule 1.
3. **Genotype bar** (DESIGN 10.1 on the population sims). High-tier precision >= 0.95 for P and for E, pooled over all
   directed pairs of all runs. Reported also per target class and per backbone window.
4. **Painting null.** A model holds the null when both hold:
   - at most 1 of the 30 nulls has a target tract at q <= 0.05;
   - the mean excess over the decoy in the nulls is within 2 SE of 0.

   For `any` and `anydecoy`, the 20 one-sided dropout nulls must also pass on their own: at most 1 of 20 with a
   q <= 0.05 tract, and their excess within 2 SE of 0.
5. **Variant adoption** (`any`, `decoy`). A variant becomes the default only when all four hold:
   - it holds the null (rule 4);
   - its pooled tract-level realized FDR at q <= 0.05, over the `C>A` power runs, is at most 0.05, with a
     Clopper-Pearson upper bound of at most 0.10;
   - over the `C>A` power runs (plus the f 0.18 dropout runs for `any`), its bp recall at q <= 0.05 is higher than the
     default's, by a paired sign test at p < 0.05;
   - its bp precision at q <= 0.05 is not lower by the same test.

   Runs where either model's value is NA (no q <= 0.05 tract) are dropped from that sign test, and the NA counts are
   reported.
   - `decoy` is also adopted when the default fails rule 4 and `decoy` passes rules 4 and 5's FDR bar.
   - Both are adopted together only if `anydecoy` passes rules 4 and 5. Otherwise only the one with the larger median
     recall gain is adopted.
   - Ties keep the default.
6. **Degeneracy.** A fit is degenerate when e1_RD > 0.99 and e0_RS > 0.99.
   - Reason: emissions within 1% of 0 and 1 make the posterior a copy of each locus's class. That is main3's state
     (e1_RD 0.9993, e0_RS 0.9995).
   - Degenerate fits are reported per kind and model.
   - If fewer than 10% of the default's fits in the `C>A` power runs are degenerate, the decoy decision is labeled "not
     tested in main3's regime" and listed as a Plan 4 lead, whatever rule 5 says. The 10% line is a named heuristic for
     "the regime is rare in the simulations".
7. **Direction.** The predicted codes are `direction_predictions.tsv`.
   - The test's implementation is confirmed when every posctl run reads its predicted direction (C1>A1 as C>A, A1>C1 as
     A>C) and the posctl nulls read "none".
   - Its false calls are counted in the 30 nulls and in the bottleneck nulls.
   - Under the maize-like demography, every gene-flow scenario is predicted "none". A directional call there is counted
     as a false call when it names the wrong direction, and reported when it names the right one.
   - Direction power for the real data's scenario (PT-like) is what the `ptlike` runs read. If the prediction there is
     "none", Task 13 states that DFOIL-alt is not expected to orient it.
   - D_dir is reported against its simulated null distribution under the same Ne, default and bottleneck, as an
     exploratory readout.
   - **Consequence** (DESIGN 7.6: "kept only if simulations with known direction recover it"):
     - if posctl confirms, DFOIL-alt stays an exploratory output, reported with its measured power and false-call rate;
     - if not, Task 11 changes the direction rows' note to "not validated by simulation (Plan 3)", and removing the
       test is a Plan 4 decision.
8. **Plan 2's D gap.** The two truth D are expected to differ only through which copies count:
   - any present state against annotated intact copies;
   - dropout.

   The informative comparison is D_pav against donor-discovered truth D, D_ins against sister-discovered truth D, and
   whether D_ins/D_pav reproduces the real 0.66 on the same runs.

- [ ] **Step 1: Write `test_evalib.py`** (synthetic inputs):

```python
def test_auroc_perfect_and_tied():    # [0.9,0.8,0.1] vs [1,1,0] -> 1.0; all-equal scores -> 0.5
def test_bp_overlap_merges():         # [(0,10),(5,20)] vs [(15,30)] -> 5
def test_recall_and_precision_by_length():  # one 60-kb tract half covered -> found in 50-200 kb; precision 0.5 there
def test_tract_fdr():                 # 3 called, 1 overlapping nothing -> (1, 3)
def test_dfoil_direction():           # ("P3=>P1","A","C") -> "C>A"; "P1+P2<=>P3" -> "unresolved"; "none" -> "none"
def test_truth_d_counts():            # 6 RD, 2 SD in 4 blocks -> D 0.5, n 8; outgroup-present loci dropped
def test_resign():                    # called B1, true A1 -> -z
def test_match_by_coords():           # ends within 10 bp match; 11 bp off does not; unmatched counted
```

- [ ] **Step 2: Run** `python -m pytest -q common/test_evalib.py`. It fails, then passes once implemented.
- [ ] **Step 3: Write and date `RULES.md`** (verbatim list above), and add it to `sim/memo.md`.
- [ ] **Step 4: Score the pilot.** Run `run_one.sh` from `eval` for both pilot rows, then `summarize.py`. Every field is
  filled, or NA with a reason. The pilot changes no rule.

---

### Task 10: Launch the grid and the LTRquest-annotated runs

**Files** (in `benchmark_pav/plan3/sim/`): `grid.log`, `grid.tsv.done`, `grid.tsv.failed`, `lq/<name>/`, `lq/run_lq.sh`,
and `memo.md` (append).

- [ ] **Step 1: Preconditions.**
  - `pgrep -af 'ltrpav|lastz|ltrmix|ltrquest'` is empty.
  - Record `uptime` and `free -g`.
  - Disk: about 2.3 GB per run, ~330 GB in all on /data2.
  - No environment changes until the grid finishes (Global Constraints).
- [ ] **Step 2: Launch.**
  - `cd sim && setsid -f nohup ./run_grid.sh grid.tsv > grid.log 2>&1 < /dev/null`.
  - Verify the PID: `pgrep -af run_grid.sh`, then `ps -o pid,ppid,sid,cmd -p <pid>`.
  - Wait with a Monitor until-loop on `grid.tsv.done` or `grid.tsv.failed`.
- [ ] **Step 3: Failures.** Rerun each failed row once; markers resume it. A second failure goes to `dead_ends.md` with
  its log. If it is an engine fault, follow the defect protocol.
- [ ] **Step 4: LTRquest runs.** They start after `grid.tsv.done`, because of the thread budget.
  - `git ls-remote https://github.com/cwb14/LTRquest.git HEAD`. If the HEAD is not 5042a1e, install that commit into a
    new env `ltrquest_<commit>`. Record the commit in the memo.
  - `run_lq.sh` runs inside the pinned env: `source $HOME/bin/etc/profile.d/conda.sh; conda activate
    ltrquest_<commit>`. It checks that `command -v ltrquest` lies in that env and never calls the PATH `ltrquest`.
  - For each of `null_s101`, `null_s102` and `f0.18_Ta5000_r1`, in `lq/<name>/`, it runs detached, one at a time at 32
    threads:

    ```
    LTRQUEST_TOOLS_DIR=$P/code/tools OMP_NUM_THREADS=8 ltrquest --genome sim/A1.fa sim/B1.fa sim/C1.fa \
      --proteins $P/inputs/B73v5.proteins.fa.gz --threads 32 --max-rounds 3 --detect-args "ltr-timeout=300" \
      --run-sdust --no-plots --reboundary
    ```

  - Sample its thread count during the first run (`ps -L`). The peak should stay near 32 (`--threads 32` with
    `OMP_NUM_THREADS=8`). If it runs well past 32, lower `--threads` to keep the budget, and record it.
  - Cleanup:
    - keep the `*.work` directories;
    - if the commit is not 5042a1e, first re-check the delete list below against that commit's code (the memory note
      checked it at 5042a1e);
    - delete only `*.bounded.fa.db`, `*.bounded.fa.aa`, `*.fxi`, `*.rexdb.cls.lib`, `*.rexdb.cls.pep` and
      `*.rexdb.dom.faa` inside them;
    - then `python -m ltrquest.record check` must print `reuse` (user memory).
  - The `lq/<name>/` layout:
    - `sim/` links the source run's FASTAs and `truth/`;
    - `sim/samples.tsv` lists A1, B1, C1 with `lq/<name>/{A1,B1,C1}_LTRs`, and O1 with `.`.
  - Then `run_lq.sh` calls `run_one.sh <name> --rundir lq/<name> --from geno`. That runs `geno`, the views, LTRmix on
    the LTRquest prefixes, and `eval`.
  - Task 9's `eval_run.py` scores these runs through its LTRquest branch: `match_by_coords` at slop 10 bp, with
    unmatched elements counted.
  - The same genomes with truth-derived annotation are the paired comparison.
- [ ] **Step 5: Memo.** Record:
  - dates and the snapshot sha;
  - commands;
  - per-kind wall times against the estimates;
  - failures;
  - the LTRquest commit and its `record check` output.

---

### Task 11: Simulation results and decisions

**Files:**
- Outside the repo: `benchmark_pav/plan3/sim/{tables/*.tsv, SIM_RESULTS.md}`, `benchmark_pav/dead_ends.md`.
- Repo:
  - always, `docs/DESIGN.md` 7.1, 7.4 and 7.6 (the outcome);
  - if a variant is adopted, `src/ltrpav/analysis/constants.py`, `tests/test_paint.py` and `tests/test_cli_analysis.py`;
  - if rule 7 does not confirm the test, `src/ltrpav/analysis/direction.py` (the rows' note) and
    `tests/test_direction.py`.

- [ ] **Step 1: Rescore with the final scoring code.** Rerun `eval_run.py` and `eval_ltrmix.py` on every run (LTRquest
  runs included), then `summarize.py`.
  - Run it detached: about 150 runs take more than 15 minutes.
  - Every `eval.json` must carry the same eval-script sha256s.
- [ ] **Step 2: Write `SIM_RESULTS.md`.** Every bar is judged by `RULES.md`, PASS or MISS.
  1. **The null.** Rule 1 and rule 2 for D_pav, dD, truth D and LTRmix's four D. Truth D against called D separates
     the statistic from genotyping.
  2. **Power.** Mean Z and SD per (f, ta), the probit f80, the f4-ratio against the true f, and the Z projected by locus
     count.
  3. **Painting, head to head** (view `roles`, recipients inferred, wrong recipients counted alike for both tools):
     AUROC, bp precision and recall, recall and precision by tract length (bp, and informative loci per tract), and the
     realized FDR.
  4. **Models and variants:** rules 4-6, applied as written.
  5. **Direction:** rule 7. State the predictions, what was observed, the posctl confirmation, false calls (default and
     bottleneck), ptlike, and D_dir against its null.
  6. **One-sided dropout:** D_pav's null and power under recipient dropout (DESIGN 7.1's claim), and the variants
     judged on the dropout nulls alone.
  7. **Genotypes:** rule 3, plus the LTRquest runs against their truth-annotated pairs.
  8. **LTRmix on one truth:** its D tests, painting, presence/absence accuracy and s, beside LTRpav's (tables only; the
     analysis is Plan 4).
  9. **Plan 2's open gaps.**
     - s: LTRpav's identity s and LTRmix's s against the true 0.36%.
     - D: rule 8.

     Untested causes become Plan 4 leads.
  10. **Realism:** the extended table, with each gap named and its effect on the results stated (density, outgroup
      conflict, state mix).
  11. **Decision 11:** `nodonor`'s null count and power, on their own; Task 14 sets the genus `zd` case beside them.
      The rule is not changed; the user decides decision 11 after Plan 3.
- [ ] **Step 3: Misses.** Each MISS gets a `dead_ends.md` entry: what, result, evidence, cause tested, what would change
  it. Investigate with truth D and the per-pair genotype scores; never change a bar or a rule.
- [ ] **Step 4: Record the decisions.**
  - Always edit DESIGN 7.1 and 7.4 (each variant: adopted, or "evaluated, not adopted" with the numbers), and 7.6 (rule
    7's outcome and its consequence).
  - If rule 7 did not confirm the test, change the direction rows' note in `analysis/direction.py` to "not validated by
    simulation (Plan 3)", and update the expected note in `tests/test_direction.py`.
  - If rule 5 adopts a variant, change the default constant and the tests' expected defaults.
  - Run the suite and the engine-key check, then commit:
    - on adoption, `"Make <variant> the painting default after the simulated null and power (Plan 3)"`;
    - otherwise, `"Record the simulated painting and direction outcomes (Plan 3)"`.
  - If `src/` changed (an adoption, or the direction note), take snapshot 2 for Tasks 13-16, and check that its engine
    fingerprints equal snapshot 1's. If only DESIGN changed, snapshot 1 stays: DESIGN is not in `src`.

---

### Task 12: Real inputs and the genotyping queue

**Files** (in `benchmark_pav/plan3/real/`): `edta_prep.py`, `test_edta_prep.py`, `cap_variant.py`,
`{six,genus,citrus,edta}/samples.tsv`, `stability/{mm2,cap5k}/samples.tsv`, `annot_edta/*.gff3.gz`, `genotype_all.sh`,
`memo.md`.

**Interfaces:**
- `edta_prep.py GFF3 FASTA PREFIX OUT`:
  - Keeps `Method=structural` lines whose type ends in `LTR_retrotransposon` or equals `long_terminal_repeat`. LTRpav's
    loader pairs EDTA's sibling LTRs through their `repeat_region` parent, which needs no `repeat_region` line.
  - Prefixes every seqid with `PREFIX_`. A bare integer N becomes `PREFIX_chrN` when only that form is in the `.fai`
    (Zn).
  - Drops and counts records whose seqid is not in the `.fai`. Writes gzip.
- `cap_variant.py --flank-cap BP genotype ...`:
  - Sets the cap on the route that `ltrpav.cli.get_route` returns, as `bakeoff/run_variant.py` (`--flank-cap`) does.
  - Then calls `ltrpav.cli.genotype_main`, and writes `variant.json`.
  - The anchor stage key holds the cap through the route's `params`.

- [ ] **Step 1: EDTA prep test.** `test_edta_prep.py` writes a toy EDTA GFF3 on seqid `1`, in the layout of
  `inputs/annot_TIL18/te.gff3.gz`:
  - a `repeat_region` (`ID=repeat_region_1;Method=structural;tsd=GTTTT`);
  - its `target_site_duplication` and two `long_terminal_repeat` children (`Parent=repeat_region_1`);
  - a `Copia_LTR_retrotransposon` with `Parent=repeat_region_1`;
  - one `Method=homology` LTR-RT line;
  - one record on an unknown seqid.

  Against a toy `.fai` with `Zn_chr1`, assert:
  - the output loads with `load_annotation` as one element on `Zn_chr1`;
  - the homology line is dropped;
  - the unknown seqid is counted.
- [ ] **Step 2: Prepare annotations** for B73v5, TIL18, TIL01 (`inputs/annot_*`), TIL25, Zh and Zn (raw EDTA).
  - Each is written as `annot_edta/<sheet label>.gff3.gz`; B73's file is `B73.gff3.gz`, with seqid prefix `B73v5`.
  - Record kept elements, dropped seqids and the loader's count.
  - Expected structural counts (LTRmix genus run): TIL01 58,346, TIL18 51,214, TIL25 48,503, Zh 55,801, Zn 60,696.
  - B73, TIL18 and TIL01 must also equal the loader's count on `main3/qc_fixed/edta/*.structural.gff3`.
- [ ] **Step 3: Samples sheets** (absolute paths; `label fasta annotation group role`).
  - `six`:
    - B73 `run/B73v5_LTRs`, maize;
    - PT, TIL25, TIL11 `benchmark/ltrquest_extra/<L>_LTRs`: maize, mexicana, parviglumis;
    - TIL18, TIL01 `run/`: mexicana, parviglumis;
    - Zd `.`, diploperennis, outgroup.
  - `genus`:
    - TIL01, TIL18, TIL25, Zh, Zn with `annot_edta/<L>.gff3.gz`: parviglumis, mexicana, mexicana, huehuetenangensis,
      nicaraguensis;
    - Zd `.`, diploperennis, with no role: an ingroup genome.
  - `citrus`:
    - CsA, CsB, Cr from `lineage2/ltrquest_a/<L>_LTRs`;
    - Cm, CaM, CaP from `ltrquest_b`;
    - groups sweet, sweet, mandarin, pummelo, sour, sour.
  - `edta`: B73, TIL18 and TIL01 with `annot_edta`; Zd outgroup. Groups as in `six`: maize, mexicana, parviglumis,
    and diploperennis. `compare_papers.py` checks the roles against them.
  - `stability/{mm2,cap5k}`: B73, TIL18 and TIL01 (LTRquest); Zd outgroup; the same groups.
- [ ] **Step 4: Queue.** `genotype_all.sh` runs sequentially at 32 threads, each block skipped by its marker:
  1. six;
  2. genus;
  3. citrus;
  4. edta;
  5. `stability/mm2` (`--anchor mm2`). Its first pair, `--pair B73,TIL18`, runs alone with a tree-PSS sampler (main3's
     `mem_sampler.sh`, every 5 s). If the peak exceeds 250 GB:
     - the block stops;
     - the overrun goes in `dead_ends.md`, and the user is told: it is a measured cost of a selectable route (DESIGN 9);
     - the engine-fix task follows only if the overrun traces to a defect.
  6. `stability/cap5k` (`cap_variant.py --flank-cap 5000`).

  Each block runs `ltrpav-genotype --samples <d>/samples.tsv --outdir <d>/geno --threads 32`, then `ltrpav-merge`,
  under `/usr/bin/time -v`.
  - Snapshot `inputs/*.fai` before and after.
  - Launch detached after the grid and the LTRquest runs. Verify the PID; wait with a Monitor until-loop on
    `queue.done` or `queue.exit`.
  - Write `memo.md`.

---

### Task 13: Six genomes: controls, direction, f4-ratio, PT loci, and the default trio view

**Files** (in `benchmark_pav/plan3/real/`):
- `six/views/{all,main,pos,neg,til25,hpc1}/`, `six/score_six.py`, `six/six_results.tsv`, `six/RESULTS.md`;
- `common/compare_papers.py`: PRELIM's logic plus an output-name prefix; Task 16 owns its final edits;
- `memo.md` (append), `benchmark_pav/dead_ends.md`.

- [ ] **Step 1: Views** (`view.sh`, snapshot 1 or 2).
  - `all`: `ltrpav-stats` then `ltrpav-paint` (every trio, roles from the data; direction rows for maize/mexicana, with
    parviglumis as the sister taxon and Zd as the outgroup).
  - `main`: `--trio B73,TIL01,TIL18`. This is the default trio view that Tasks 14-16 read; Task 16 adds `--identity` in
    its own copy.
  - `pos`: `--trio PT,B73,TIL18`.
  - `neg`: `--trio TIL11,TIL01,TIL18`.
  - `til25`: `--trio B73,TIL01,TIL25`.
  - `hpc1`: `--trio PT,TIL01,TIL25`.
- [ ] **Step 2: Copy `compare_papers.py`.** Copy `main3_analyses/compare_papers.py` (post-final-wave) to
  `common/compare_papers.py`.
  - Add only an output-name prefix, `--prefix`: its outputs `prelim_papers.tsv` and `prelim_tables/` are otherwise
    hard-coded.
  - The analysis directory is its existing `--run DIR`. The logic stays PRELIM's.
  - Record the source sha256.
  - Run it on view `main`: `--run six/views/main --prefix six_main`.
- [ ] **Step 3: `score_six.py` writes `six_results.tsv`** with columns `item ltrpav ltrmix bar verdict note`. Bars are
  DESIGN 10.4's; LTRmix's values come from `$P/benchmark/results/six/analysis/trio_summary.tsv`.
  1. **Positive control.** D_pav(PT, B73; TIL18) > 0 with Z > 3, PASS or MISS. This is LTRmix's own positive-control
     trio. D_pav(PT, TIL01; TIL18) and D_pav(B73, TIL01; TIL18) are reported beside it.
  2. **Negative control** {TIL11, TIL01; TIL18}: |Z| < 3 is PASS. Otherwise MISS, explained when the gene-space SNP D
     (+0.052, Z 3.0; `benchmark/gene_snp`) and LTRmix's D3 agree in sign.
  3. **TIL25 as donor:** reported, since DESIGN 10.4 sets no bar. Give D_pav(B73, TIL01; TIL25), its Z, and whether
     Z > 3. LTRmix's tests did not reach Z > 3 there; the SNPs give +0.050, Z 2.4.
  4. **Direction, mexicana <-> maize.** The DFOIL-alt signature and D_dir, read under `RULES.md` rule 7.
     - The simulated power is the `ptlike` runs': predicted and observed codes, and calls over 3 runs.
     - If they read "none", the row says that DFOIL-alt is not expected to orient a pulse into one maize lineage under
       this demography, and that direction is therefore not estimable here. Not a miss.
     - The posctl confirmation is cited, so a "none" is not read as an implementation fault.
  5. **f4-ratio of B73,** when TIL25 qualifies as the second donor. Reported against ELAI 17.0%.
  6. **HPC1 in PT** (Barnes; a 10.3 row).
     - Place B73's HPC1 gene (`loci.v5.tsv`: chr3:8,497,916-8,499,434) on PT with `minimap2 -x asm5`. LTRmix placed it
       at PT chr3:9.088 Mb.
     - Report PT's maximum posterior within +-50 kb in view `hpc1`, and any tract with its q.
  7. **Inv4m in PT:** a B73~PT inverted block overlapping chr4:172.9-188.1 Mb (`inversions.tsv`). Reported.
     - Every six-genome inversion block is reported with the caller's known residual (parked from Plan 2): on main3,
       11 blocks were sparse on their pair's second genome, where own-pair rows inside the y span are exempt.
     - A block sparse on its second genome is flagged as such.
  8. **Decision 11:** the count of trios with an unannotated donor; 0 is expected. The user decides decision 11 after
     Plan 3.
- [ ] **Step 4: `RESULTS.md`.** The table, each MISS with its investigation (also in `dead_ends.md`), and the caveat that
  PT is a Toronto Agreement release.
- [ ] **Step 5: Memo.** Append this task's dates, commands and outputs to `real/memo.md`, with the `claude --resume` name.

---

### Task 14: *Zea* genus event, sweet orange, EDTA portability

**Files** (in `benchmark_pav/plan3/real/`): `genus/{views,score_genus.py,RESULTS.md}`,
`citrus/{views,score_citrus.py,RESULTS.md}`, `edta/{views,RESULTS.md}`; `memo.md` (append); and
`benchmark_pav/dead_ends.md`.

- [ ] **Step 1: Genus** (EDTA annotations; no outgroup). Views:
  - `all`;
  - `p1` (`--trio Zh,TIL18,Zn`);
  - `p2` (`--trio TIL01,TIL18,Zn`);
  - `ctrl` (`--trio TIL18,TIL25,Zn`);
  - `zd` (`--trio Zh,TIL18,Zd`).

  Bars (DESIGN 10.4):
  - P1, D > 0 with Z > 3 for Zh: PASS or MISS;
  - control |Z| < 3: PASS or MISS;
  - P2 reported.

  For each trio, report the resolved fractions of D's loci in R and in S. This is the synteny problem that broke
  LTRmix's D_ins: Zn inside synteny 0.95 / 0.58 / 0.35.

  `zd` is decision 11's case. Report:
  - the discovery genomes the four-point fallback used (findings.txt);
  - the genomes the unnarrowed DESIGN 7.1 wording would add (listed);
  - D and Z, beside the simulated `nodonor` results (Task 11). The rule is not changed; the user decides decision 11
    after Plan 3.
- [ ] **Step 2: Sweet orange** (no outgroup). Views:
  - `c1` (`--trio CsB,Cm,Cr`);
  - `c2` (`--trio CsA,Cr,Cm`);
  - `k1` (`--trio CaM,Cr,Cm`);
  - `k2` (`--trio CaP,Cm,Cr`).

  Bars (DESIGN 10.4, as LTRmix 6c):
  - **Called tracts.** Every true tract of at least 1.7 Mb in `CsB.M.bed` and `CsA.P.bed` is called: tracts by the
    tract rule at any q cover >= 50% of it. PASS or MISS per tract. Recall at q <= 0.05 is also reported.
  - **C1.** D > 0 with Z > 3, reported. LTRmix: +0.469, Z 4.8.
  - **Controls.** |Z| < 3 and no tract at q <= 0.05: PASS or MISS.
  - **Base pairs.** bp precision and recall at any q and at q <= 0.05, reported.
- [ ] **Step 3: Portability.**
  - Make view `edta/views/main` with `view.sh` on `edta/geno`.
  - Run `ltrpav-stats` and `ltrpav-paint` with `--trio B73,TIL01,TIL18`.
  - Then run `compare_papers.py --run edta/views/main --prefix edta_main`.

  `RESULTS.md` sets these rows beside view `six/views/main` (Task 13):
  - D_pav, dD;
  - chromosome ranking;
  - window r at 1 and 10 Mb;
  - AUROC, spacing;
  - Inv4m.

  Reported, with no bar. LTRmix found the genome-wide tests hold on EDTA while windows weaken (`benchmark/edta/out`).
- [ ] **Step 4: Memo.** Append dates, commands and outputs to `real/memo.md`.

---

### Task 15: Stability: route, flank cap, block size

**Files** (in `benchmark_pav/plan3/real/stability/`): `{mm2,cap5k}/views/main`, `block/`, `RESULTS.md`; and
`real/memo.md` (append).

- [ ] **Step 1: Route and cap.** Make views `--trio B73,TIL01,TIL18` on `mm2/geno` and `cap5k/geno`, and run
  `compare_papers.py --run <view> --prefix <variant>` on each. Report, beside view `six/views/main`:
  - D_pav, dD;
  - n informative, spacing;
  - window r at 1 and 10 Mb;
  - resolved fractions;
  - per-block wall time and peak RSS (`/usr/bin/time -v`), and per-pair wall times from the genotype log.
- [ ] **Step 2: Block size.** In copies `block/b{1,2,5,10,20}` of view `six/views/main`, run
  `ltrpav-stats --trio B73,TIL01,TIL18 --block-size {1000000,2000000,5000000,10000000,20000000}`. In copies of
  `six/views/all`, rerun the direction rows. Report D_pav Z, dD Z and the direction Z under each.
- [ ] **Step 3: `RESULTS.md`.** One table, "varied and reported, not tuned" (DESIGN 10.4). Any change of verdict under a
  variant is stated plainly.
- [ ] **Step 4: Memo.** Append dates, commands and outputs to `real/memo.md`.

---

### Task 16: DESIGN 10.3 rerun at the end, and wrap-up

**Files:**
- Outside the repo:
  - `benchmark_pav/plan3/real/papers/{views/main, final_papers.tsv, FINAL.md}`;
  - `benchmark_pav/plan3/real/common/compare_papers.py`: its final edits, with the new sha256 recorded;
  - `benchmark_pav/plan3/RESULTS.md`, `benchmark_pav/dead_ends.md`, `$P/memo_ltrpav.md`.
- Repo: `docs/DESIGN.md` 12, "Plan 3 outcome" (3-6 lines).

- [ ] **Step 1: Final view.** `papers/views/main` is a copy of `six/views/main` with
  `ltrpav-stats --trio B73,TIL01,TIL18 --identity --threads 32`, then `ltrpav-paint --trio B73,TIL01,TIL18`. Run it
  detached (the identity layer takes ~20 min) and verify the PID.
- [ ] **Step 2: Final edits, then compare.** Edit `common/compare_papers.py`:
  - the verdict constants become `PASS, MISS = "PASS", "MISS"` (they read "PASS (prelim)" and "MISS (prelim)");
  - new rows read `sim/tables`: rules 1-2, and the null distributions of Z and dD;
  - record the new sha256.

  Then `compare_papers.py --run papers/views/main --prefix final` writes `final_papers.tsv`. Verdicts read PASS or MISS,
  without "(prelim)":
  - The D_pav row keeps its bar, D > 0 and Z > 3, and states rules 1-2's outcome beside it. If the null was not
    calibrated, the row also gives the empirical null quantile of Z and says the verdict rests on it.
  - The "gene flow, not lineage sorting" row reports dD against the simulated null distribution of dD.

  Diff against `main3_analyses/prelim_papers.tsv` and explain every changed row; main3 was engine 7d71073.
- [ ] **Step 3: Write `FINAL.md`:**
  - the 10.3 table, with LTRmix's columns as in PRELIM;
  - the misses, with their `dead_ends.md` entries;
  - what changed from PRELIM, and why;
  - CLAUDE.md's closing four items, labeled by how far each was tested: the headline sentence, the mechanism, the
    generality (six genomes, genus, citrus), the predictions.

  Then `benchmark_pav/plan3/RESULTS.md`: one page linking every benchmark's RESULTS.md, with one line per bar (PASS or
  MISS) and the Plan 4 leads. The leads include:
  - parts of the s and D gaps the simulations could not test;
  - the missing `00++`/`00--` DFOIL-alt entries, and whether any PAV statistic can orient a population-level pulse;
  - painting resolution;
  - decoy cross-fitting, if the decoy model failed the null;
  - the overview's known limits with 20 trios: a page of about 264 mm, and large scaffolds that can be called
    chromosomes.
- [ ] **Step 4: Record.**
  - Add a Plan 3 section to `memo_ltrpav.md`:
    - dates;
    - snapshot sha(s);
    - envs and versions (msprime, the LTRquest commit);
    - the calibration values;
    - inputs and exact commands;
    - outputs;
    - wall times against the estimates;
    - gotchas;
    - the `claude --resume` name.
  - Add DESIGN 12, "Plan 3 outcome", with calibrate.sh's exact calibration values beside the `src` drafting defaults.
  - Run the suite.
  - Commit: `"Record Plan 3 benchmark outcome"`.
- [ ] **Step 5: Hand off to the user.** Report:
  - the bars, PASS or MISS, per benchmark;
  - the null, calibration and power;
  - the variant and direction decisions;
  - misses and their investigations;
  - decision 11's evidence (`nodonor`, genus `zd`), for the user's decision after Plan 3;
  - Plan 4's inputs.

---

## Spec coverage

| DESIGN | Task |
|---|---|
| 10.2 genome-level simulator: msprime with admixture, LTRmix demography default, real backbone, SNPs, small indels, real families, identical LTRs, nesting, solo-LTRs, deletions, gaps | 1-5 |
| 10.2 annotations from truth with dropout and jitter; a few runs annotated by LTRquest | 4, 5, 10 |
| 10.2 grid: f 0-0.50, admixture times, one-sided dropout 0-40%, 30 null replicates, 2 genomes per taxon | 8, 10 |
| 10.2 LTRmix on the same simulated genomes (head-to-head on one truth) | 8, 9, 11 |
| 10.2 bars: null |Z| > 3 <= 5%; power curves; tract precision and recall by length; direction accuracy | 9, 11 |
| 10.1 simulated high-tier precision (population sims) | 9, 11 |
| 10.5 presence/absence accuracy of each tool (inputs for Plan 4) | 9 |
| 7.1 painting "any discovery" variant evaluated with one-sided dropout | 7, 9, 11 |
| 7.4 painting emissions (EM degeneracy carry-over): decoy-anchored model tested on sims only | 6, 7, 9, 11 |
| 7.6 direction kept only if sims recover it; unequal Ne in null and gene-flow runs | 1, 8, 9, 11, 13 |
| 7.1 decision 11 (four-point fallback): default run, where it matters reported | 8, 9, 11, 13, 14 |
| 10.3 rerun at the end | 13, 16 |
| 10.4 six genomes: PT, negative control, TIL25 donor, direction with simulated power | 13 |
| 10.4 *Zea* genus event (EDTA), sweet orange, portability, stability | 14, 15 |
| 8 msprime optional extra; env + lock; tests on synthetic fixtures | 1-7 |
| 11 steps 4-5 | 8-16 |
| Plan 2 open gaps (split s, D_pav vs D_ins) | 9, 11, 16 |
