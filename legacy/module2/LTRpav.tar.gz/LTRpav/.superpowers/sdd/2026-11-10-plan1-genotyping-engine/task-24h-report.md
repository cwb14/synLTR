# Task 24H report: engine fixes before the whole-genome run

Status: DONE_WITH_CONCERNS. Branch plan1-engine, base 568f90d, four commits, none pushed, existing identity, no
trailers. D = /data2/chris/maize_introgression/benchmark_pav/bakeoff; scratch D/task24h_scratch (memo.md there
lists every command). Gate: `pgrep -af 'run_variant.py|bakeoff.py measure'` matched only its own shell; with a
self-excluding pattern it printed nothing (exit 1) before the first edit and again at the end.

| item | commit | subject |
|---|---|---|
| 0 | 4ae76b8 | Use LASTZ for window alignment, as the bake-off chose |
| 1 | 3781931 | Require present calls to cross into the element at their site |
| 2 | cef7324 | Merge windows on the padded cap |
| 3 | 4d9eb8f | Exempt hosts' present images in e_in_annot |
| 4 | 7d71073 | Chain LASTZ's minus strand to bound satellite windows (controller's item 4) |

Verification after each commit: `pytest -W error` with the ltrpav_bench bin first on PATH, exit 0 (773, 779, 781,
783, 784 tests); `ruff check .` clean. The lastz, CLI and smoke tests also pass in the `ltrpav` env (64 passed).

## 0. LASTZ backend, ported as the default (4ae76b8)

**What changed.**
- `localign.py`: built-in backend `lastz` (`_align_lastz`, `lastz_args`, `parse_cigarx`, `LASTZ_SCORING`,
  `LASTZ_SEED`), registered beside `mappy`. Options are the bake-off's (PARAMS.md 4): the preset's scoring,
  ydrop = gap open + extend x MIN_SEG, gappedthresh MIN_SEG, step 1, 12of19 transition seed, plus strand
  `--chain`, minus strand unchained, `--ambiguous=iupac`, temp FASTAs in /dev/shm when writable.
- `constants.py`: `DEFAULT_BACKEND = "lastz"` (reason: the bake-off's 0.930 vs 0.898). `cli.BACKEND`,
  `genotype_pair` and `align_window` all default to it; mappy stays registered (`backend="mappy"`). No CLI option.
- Fail fast: `cli._backend` (`_BACKEND_BINARIES`), checked by `ltrpav run` and `ltrpav-genotype` after the route
  check: one line `error: window aligner 'lastz' needs lastz on PATH (not found)`, exit 1, nothing written.
- Port deviations (none in results): an unknown preset raises ValueError up front (the bake-off's try block turned
  it into an empty map); `stdin=DEVNULL`; lastz is looked up per window, not at import; the warning drops the
  `bakeoff-guard` prefix (logger `ltrpav.localign`). A LASTZ error or malformed CIGAR still gives an empty AlnMap
  (U) and one warning.
- Environment: `environment.yml` already pinned `lastz=1.04.60` (since the scaffold, ed1e53a) and the `ltrpav`
  env already held lastz 1.04.60 hab16a5f_0, the build ltrpav_bench uses. `mamba install -n ltrpav -c conda-forge
  -c bioconda lastz=1.04.60 --dry-run`: "All requested packages already installed". Nothing installed or edited.
- DESIGN: 5.3 rewritten (LASTZ, its key settings, pointer to REPORT.md 7 and PARAMS.md 4). Three stale sentences
  fixed: 5.1's "candidate", section 9's "mappy stays the default until then", build decision 6.

**Tests** (+40).
- `tests/test_lastz.py`: the 21 toy cases x the 7 classifier seeds on whole-case windows (P, E, D_left, D_both
  included) and P, E, T, O on WINDOW_PAD flanks, checking states plus required and forbidden flags, tiers and U
  reasons; default backend is lastz (constants, cli, align_window, genotype_pair); `lastz_args` per preset (ydrop
  166/176/279, asm20 scoring == SCORE); `parse_cigarx`; IUPAC and N bases; a failing or malformed lastz gives an
  empty map and one warning; missing lastz raises. LASTZ-dependent tests skip without lastz.
- `tests/test_localign.py`: the identity, insertion, divergence and inversion tests run on both backends.
- `tests/test_cli.py`: the missing-binary test covers lastz (run with the default route, run with mm2, genotype)
  and sets PATH itself: a directory of stubs of FastGA, blastn, makeblastdb and lastz minus the missing one. It
  passes with PATH=/usr/bin:/bin (the Task 24G deferred minor). The end-to-end tests skip without lastz; the toy
  run's manifest records `backend: lastz`.
- Tests that exercise mappy or backend-agnostic mechanics (test_classify, test_genotype, mappy tests of
  test_localign) now name mappy.

**Real data.**
- 6 sims x 2 directions, default `ltrpav run`, 16 threads: calls byte-identical to `runs/<sim>/flank-mm2_2k_lastz`
  in all 12; loci.tsv, pav_matrix.tsv, qc.tsv, pav.vcf.gz, pav.unplaced.tsv, GFF3/BED and windows identical too.
  8.1-9.5 s per sim.
- chr10 B73v5->TIL18 with the flank-mm2_2k anchors ("anchors done, skip", 7,344 blocks, d 0.0338): calls and
  windows byte-identical to `chr10/runs/flank-mm2_2k_lastz`; 40.6 s.

## 1. Rule 5a tightened (3781931)

**What changed** (`classify.py`, no new constant).
- (a) A crossing run must hold >= MIN_SEG aligned A bases on both sides of the junction: the flank as before, and
  the element's own bases (children's spans left out, the classifier's convention).
- (b) The TSD exception holds only if the element's B image lies strictly between rule 3's lo and hi.
  - I read "the element's B image" as the image the exception reads beside: the B images of the LTR ends,
    extrapolated (`_ltr_image`). An AlnMap is collinear by construction, so the element's aligned image always
    lies between lo and hi: the literal aligned-image test could never fire, nor be tested.
  - `_solo_tsd` is split into `_ltr_image` and `_tsd_beside`, with the same computation.
- The module docstring (rule 5a) and DESIGN 5.4 are updated.

**Tests** (+6).
- A run reaching MIN_SEG - 1 bases into the element gives U unanchored, on either side.
- MIN_SEG bases pass.
- A TSD-exception image starting inside the left flank's image (TSD reads still matching) gives U.
- An image between the flank images keeps T.
- The two U tests fail under the old rule (checked).

**Measured once** (`item1/measure_5a_tight.py`).
- Setup: one LASTZ alignment per ok window, classified off and on. The off lines equal the item-0 engine's calls,
  and the on lines the tightened engine's, in all 6 datasets: 0 lines differ.
- chr10 B73v5->TIL18 (3,734 windows): 30 calls become U, all through (a); (b) changes none.
  - 19 own: T/medium 16, P/high 2, P/medium 1.
  - 11 nested, inheriting their host's U: P/high 3, E/high 3, O/medium 4, U 1.
- chr10 TIL18->B73v5 (3,539 windows): 29 calls become U, all through (a).
  - 21 own: T/medium 18, P/high 1, S/medium 1, T/low 1.
  - 8 inherited: E/high 3, E/medium 1, O/medium 1, T/medium 1, U 2.
- Sims R1_s1 and R2_s1, both directions: 0 changes, so right->U 0 and wrong->U 0.
- **Count with lastz:** 3 of 4,285 high-tier own present calls change. B1's mappy scan found about 17 of 4,141.
- Diagnostic (`diag_kinds.py`): how lastz's own present calls passed the old rule.

  | tier | deep | thin | TSD exception |
  |---|---|---|---|
  | high | 4,267 | 6 | 12 |
  | medium | | 41 | 5 |
  | low | | 1 | |

  - The TSD exception keeps 3 of the 6 high-tier thin calls.
  - Every TSD-exception image lies between lo and hi, which is why (b) changes nothing.
- Read-out context (B73v5<->TIL18):
  - The read-out calls 24 of the 40 own lost calls present (19 in the same state); the rest are U 8, missing 7
    and absent 1.
  - The 3 high-tier P lost: the read-out calls them U, U and P/high.
  - Of the 9 high-tier nested calls lost through inheritance (P 3, E 6), the read-out makes the same call in 7.
- Read-out case 12 still passes:
  - lo is 88,186, the image is 88,187-103,292 and hi is 103,292.
  - The copy's own TSD bases align as 1-bp tails, so lo and hi sit beside the copy, 88 kb from the true site.

## 2. Window merge on the padded cap (cef7324)

**What changed** (`window.py`).
- `_try_merge` refuses a merged window longer than `PADDED_CAP = WINDOW_CAP + 2 * WINDOW_PAD - 1` on A or B.
- That is the longest window make_windows builds: an anchor span aR - aL of WINDOW_CAP, padded by WINDOW_PAD - 1
  bases before aL and WINDOW_PAD from aR.
- **Choice:** the padded span, compared with WINDOW_CAP + 2 x WINDOW_PAD less one. This matches make_windows's
  unpadded test exactly.
  - With the full 2 x WINDOW_PAD, a merge could exceed one window's cap by 1 bp.
  - Merged windows keep only padded, clipped coordinates, so their unpadded span cannot be read back.
  - At a sequence end, a clipped window makes the test at most WINDOW_PAD - 1 bp looser.

**Tests** (+2, and one line changed).
- `_try_merge` at the boundary: PADDED_CAP is accepted; one base more is refused, on A and on B.
- make_windows builds exactly PADDED_CAP at an anchor span of WINDOW_CAP, and span_cap at one base more.
- Two identical windows with an anchor span of WINDOW_CAP - 100 merge into one. This test fails on the old rule.

**Real data.**
- Rebuilt chr10 windows, mm2 and flank-mm2_2k, all 12 directions. Each old-rule rebuild equals the run's windows
  file line for line. Merge groups:

  | run | direction | identical windows | size (bp) |
  |---|---|---|---|
  | mm2 | TIL18->TIL01 | 22 -> 1 | 500,416 x 312,154 |
  | mm2 | TIL01->TIL18 | 10 -> 1 | 312,154 x 500,416 |
  | flank-mm2_2k | TIL01->TIL18 | 13 -> 1 | 359,811 x 500,693 |

  No other direction has a merge group.
- mm2 genotyped before (3781931 snapshot) and after, with LASTZ:

  | direction | windows | calls | differing beyond wid | wid only | time before / after |
  |---|---|---|---|---|---|
  | TIL18->TIL01 | 3,262 -> 3,241 | 8,319 | 30 | 4,921 | 690 / 805 s |
  | TIL01->TIL18 | 3,301 -> 3,292 | 9,304 | 14 | 5,613 | 549 / 532 s |

  - State counts are identical.
  - The differing calls are the merge groups' own, and only anchor_left/anchor_right change: the merged window
    takes its anchors from its outermost windows.
  - Every other window is unchanged.
  - Run time is dominated by one centromeric window each (see concerns). The merged windows take 0.9 s.
- flank-mm2_2k TIL01->TIL18 cannot be genotyped under the 15-min probe limit.
  - Its merged window alone takes over 14.4 min in LASTZ's minus strand (killed).
  - The old engine aligned that window 13 times in one chunk.

## 3. e_in_annot exempts hosts' present images (4d9eb8f)

**What changed** (`loci.py`).
- In e_in_annot, the B element h around an E call is also exempt when it overlaps (>= 1 bp) the B site of an
  ancestor called P, S or T on the same B seqid.
- annot_agree keeps its rule.
- `_Catalog.ancestor_roots` became `ancestors`, which returns nodes; roots are taken at the call site.
- The QC docstring and a DESIGN 10.1 note are updated: the metric is an upper bound on E error, dominated by hosts
  annotated only in B (Q4: 55%); the bar stays; Task 25 reports the miss and its decomposition.
- **Why e_in_annot only.** I measured it. In the shared filter, "overlaps" also exempts B elements nested inside
  the host's image, which are the nested elements' own orthologs. That removes 436-741 correct nested P calls per
  direction from annot_agree and lowers it by 0.013-0.017.

**Tests** (+2).
- A nested E inside hb is not counted. Here the host's P image overlaps hb (overlap 0.375, no locus link).
- E calls in unrelated B elements are still counted, a nested one included: e_in_annot is 2/3, and annot_agree
  stays at 1/4.
- A host called E does not exempt.
- The first test fails on the old code.

**Recompute** of the chr10 mm2 run, whose files were only read.
- The harness reproduces the run's qc.tsv exactly with the old code (85 rows).
- New file: D/task24h_scratch/item3/qc_after/qc.tsv. Only the six e_in_annot rows change:

  | direction | e_in_annot before | after | E calls counted (of all E) |
  |---|---|---|---|
  | B73v5>TIL18 | 0.1905 | 0.1571 | 268 -> 221 (of 1,407) |
  | B73v5>TIL01 | 0.1808 | 0.1467 | 260 -> 211 (of 1,438) |
  | TIL18>B73v5 | 0.1904 | 0.1560 | 249 -> 204 (of 1,308) |
  | TIL18>TIL01 | 0.1845 | 0.1498 | 250 -> 203 (of 1,355) |
  | TIL01>B73v5 | 0.1852 | 0.1443 | 276 -> 215 (of 1,490) |
  | TIL01>TIL18 | 0.1773 | 0.1509 | 276 -> 235 (of 1,557) |

- The exempted B elements, per direction: 31-52 cover at least 80% of the host's image (B's annotation of the
  host); 7-11 lie inside it; 3-7 overlap it partly.

## Item 4. LASTZ's minus strand chained (7d71073)

Controller ruling on concern 1: chain the minus strand like the plus strand, still in its own run. The acceptance
criteria were declared before measuring. The commit is "Chain LASTZ's minus strand to bound satellite windows".

**What changed.**
- `localign.lastz_args` now includes `--chain`, so both strands run chained. Each strand is still its own LASTZ
  run, so the minus strand's hits reach `inv`. No new parameter.
- The backend docstrings and DESIGN 5.3 are updated.
- The rule 5a docstring now notes the TSD exception's residual (read-out case 12).
- Tests (+1, 784 in all): `test_lastz_args_follow_the_preset` now expects `--chain`, and a new stub-LASTZ test
  checks that each window gets two runs (plus, then minus), both chained, and that the minus hit reaches `inv`.
  The toy inv_site cases still pass.

**Acceptance 1 (pass).** The engine's own backend call (`align_window(..., "lastz")`) on each known slow window:

| window | before (unchained minus) | now | segments | inverted hits |
|---|---|---|---|---|
| mm2 TIL18->TIL01 wid 1277, 401,806 x 168,670 bp | 11-12 min | 16.8 s | 1,044 | 187 |
| flank-mm2_2k TIL01->TIL18 wid 1466, 359,811 x 500,693 bp | over 14.4 min | 36.7 s | 1,961 | 169 |

**Acceptance 2 (pass).** Default config on the 6 sims, both directions, scored with `ltrpav-sim score` and pooled
with 03_score_sims.py's own functions:

| run | P high precision | E high precision | crf | crf high | unresolved |
|---|---|---|---|---|---|
| bake-off reproduction (check) | 0.9993 (2799/2) | 0.9940 (1320/8) | 0.9300 (4613/4960) | 0.8837 | 162 |
| chained (new) | 0.9993 (2799/2) | 0.9940 (1325/8) | 0.9306 (4616/4960) | 0.8847 | 155 |
| HEAD before the chain (4d9eb8f) | 0.9993 (2799/2) | 0.9940 (1319/8) | 0.9294 (4610/4960) | | 167 |

- The reproduction row equals the bake-off's numbers exactly, which validates the pooling.
- Calls the chain changes on the sims: 12, all from U. U->E 6 (all now right), U->D 4 (2 right), U->O 2 (right).
- Items 1-3 against the bake-off, on all six sims: 5 calls became U (right->U 3, wrong->U 2: T->U 4, E->U 1). All
  are in the four sims item 1's measurement did not cover.

**Item (3) numbers (report, not a gate).**
- chr10 B73v5->TIL18, flank-mm2_2k anchors, chained against the unchained engine:
  - 126 of 9,064 calls change state (U->O 101, U->D 20, U->E 5); no tier changes within a state.
  - U inv_site falls from 325 to 180. The 145 that moved became O 101, D 20, U ambiguous 19 and E/high 5. The
    read-out calls them O 80, D 28, U 25, E 8, T 3, S 1.
  - High tier: D 897 -> 906, E 1,883 -> 1,888; P and S unchanged.
  - Read-out: P/E agreement 0.9977 both before and after (3,418 -> 3,423 pairs). Contradictions stay at 15 (15
    high, 8 both high). High-tier P/E agree with the read-out's P/E in 3,364/3,372 -> 3,369/3,377 cases.
- chr10 TIL01->TIL18 end to end, fresh outdir, default config: done in 89.0 s at 16 threads, peak RSS 1.27 GB.
  - Anchoring took 22 s, including 8 s to index TIL18; genotyping 64 s.
  - 3,774 windows; 9,304 calls: P 1,878, S 98, T 317, E 2,117, D 2,043, O 1,613, G 8, U 1,230.
  - The satellite tail is gone. Its merged window alone took over 14.4 min before.

**Deferred by the controller.**
- CI's missing lastz: the pip-only CI skips the lastz and end-to-end CLI tests.
- Bake-off scripts that call `align_window` without a backend now get LASTZ.

## Concerns

1. **LASTZ is slow on centromeric satellites (Task 25 risk). Resolved by item 4.** The unchained minus strand explodes on these
   windows:

   | window | unchained minus strand | chained minus strand | chained plus strand |
   |---|---|---|---|
   | mm2 TIL18->TIL01, 402 x 169 kb | 11-12 min | 7.3 s | 4.7 s |
   | flank-mm2_2k TIL01->TIL18 merged, 360 x 501 kb | over 14.4 min | 10.7 s | 16.7 s |

   - The second window comes from the default route.
   - B73v5->TIL18 and the sims never hit such a window, so the bake-off did not see this.
   - Teosinte genomes, with their knobs and CentC arrays, could produce multi-hour chunks.
   - Options, all of which change calls: chain the minus strand too; use LASTZ's `--maxwordcount` or dynamic
     masking; a per-window guard. Not ported, because the brief said to port exactly.
2. **(b) is inert as specified.** It changes 0 of 17 TSD-exception calls on chr10 and leaves read-out case 12
   standing. Closing that loophole needs another rule, for example the image adjoining the flank runs' images.
   That is a controller decision; I measured once and did not adjust.
3. **(a) costs through inheritance.** A thin T/medium host that becomes U takes its nested calls with it: 9
   high-tier nested calls lost, 7 of them the read-out's own call.
4. **Item 3's rule as written also exempts 7-11 E calls per direction** whose h lies inside the host's image (a
   nested B element, not the host's ortholog). A containment test would keep them counted.
5. **CI installs with pip only.** The lastz tests and the end-to-end CLI tests now skip there. CI needs a lastz
   install (apt or bioconda) to cover them.
6. **API defaults changed.** `align_window` and `genotype_pair` now default to lastz. Scripts that call
   `align_window` without a backend (the bake-off's measure_5a.py and b1_thin_anchor.py) would now run LASTZ.
7. **Minor:**
   - A worker killed mid-window leaves its /dev/shm temp directory behind (removed once by hand).
   - Two pairs of identical but non-consecutive mm2 windows stay unmerged, because make_windows only merges into
     the last window. This predates the task.
   - The brief's "Return ONLY" names three commits; there are four, as its Constraints require.
