#!/usr/bin/env python3
"""Fig. 1 (fig1_painting): LTR-RT libraries alone paint maize B73's mexicana ancestry and its inversions.

Rebuilds everything from the ltrmix outputs (benchmark/results/main3), the ELAI truth (benchmark/truth), the LTR-RT
library tables (run/) and the assemblies (inputs/, one ortholog triple re-extracted with samtools faidx and aligned
with mafft). Writes fig1_painting.pdf (figure + short legend + long legend), fig1_painting.png (300 dpi, figure only)
and fig1_painting_numbers.tsv into this script's folder; caches parsed inputs in ./work.

Run:  source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix; python fig1_painting.py [-v]
"""
import argparse
import itertools
import math
import os
import subprocess
import sys

os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")
import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.collections import LineCollection, PatchCollection
from matplotlib.patches import Rectangle, Polygon, FancyBboxPatch
from scipy.stats import spearmanr, rankdata

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(HERE, "work")
ROOT = "/data2/chris/maize_introgression"
MAIN = f"{ROOT}/benchmark/results/main3"
TRUTH = f"{ROOT}/benchmark/truth"
RUN = f"{ROOT}/run"
INPUTS = f"{ROOT}/inputs"
STEM = "fig1_painting"
DATE = "2026-11-07"
VERBOSE = False

# colors fixed across the benchmark figures (SPEC.md shared block)
MEX, PAR, MAIZE, CTX, ELAI = "#D55E00", "#0072B2", "#333333", "#BBBBBB", "#009E73"
MEX_L, PAR_L = "#EDB48A", "#8CBFDC"  # pale tints for insertion-only classes
CLASS_COL = {"near_donor": MEX, "donor_only": MEX_L, "near_sister": PAR, "sister_only": PAR_L,
             "near_both": "#777777", "shared": "#999999", "private": "#D9D9D9", "unresolved": "#FFFFFF"}
CHROMS = [f"chr{i}" for i in range(1, 11)]
MM = 1 / 25.4
FIG_W = 180.0  # mm

# panel B region and panel C triple: chosen by the SPEC rule in select_example() (asserted at run time)
REGION = ("chr6", 141_000_000, 144_000_000)
TRIPLE = {"B73v5": "B73v5_chr6:142407372-142416245#LTR/Copia/SIRE",
          "TIL18": "TIL18_chr6:174620822-174629720#LTR/Copia/SIRE",
          "TIL01": "TIL01_chr6:139673199-139682085#LTR/Copia/SIRE"}
INV_LIT = {"Inv1n": ("chr1", 65_000_000, 115_000_000), "Inv4m": ("chr4", 172_883_881, 188_131_462)}


def log(msg, verbose_only=False):
    if verbose_only and not VERBOSE:
        return
    print(f"[{STEM}] {msg}", file=sys.stderr, flush=True)


# ---------------------------------------------------------------------------------------------------------------------
# fonts and style
# ---------------------------------------------------------------------------------------------------------------------
def setup_style():
    for f in ("LiberationSans-Regular", "LiberationSans-Bold", "LiberationSans-Italic", "LiberationSans-BoldItalic",
              "LiberationMono-Regular", "LiberationMono-Bold"):
        for d in ("/usr/share/fonts/truetype/liberation", "/usr/share/fonts/truetype/liberation2"):
            p = f"{d}/{f}.ttf"
            if os.path.exists(p):
                font_manager.fontManager.addfont(p)
                break
    plt.rcParams.update({
        "font.family": "Liberation Sans", "font.size": 6.5, "pdf.fonttype": 42, "ps.fonttype": 42,
        "axes.linewidth": 0.5, "axes.labelsize": 6.5, "xtick.labelsize": 6, "ytick.labelsize": 6,
        "xtick.major.width": 0.5, "ytick.major.width": 0.5, "xtick.major.size": 2, "ytick.major.size": 2,
        "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
        "mathtext.fontset": "custom", "mathtext.rm": "Liberation Sans", "mathtext.it": "Liberation Sans:italic",
        "mathtext.bf": "Liberation Sans:bold", "mathtext.cal": "Liberation Sans:italic",
        "mathtext.sf": "Liberation Sans"})


# ---------------------------------------------------------------------------------------------------------------------
# data
# ---------------------------------------------------------------------------------------------------------------------
def cached(name, fn):
    os.makedirs(WORK, exist_ok=True)
    p = os.path.join(WORK, f"{name}.pkl")
    if os.path.exists(p):
        return pd.read_pickle(p)
    log(f"building {name}", True)
    x = fn()
    pd.to_pickle(x, p)
    return x


def load_elements():
    def f():
        e = pd.read_csv(f"{MAIN}/elements.B73v5.tsv", sep="\t")
        e["c"] = e.chrom.str.extract(r"_(chr\d+)$")[0]
        e["len"] = e.end - e.start + 1
        e["mid"] = (e.start + e.end) // 2
        return e
    return cached("elements", f)


def load_elai():
    def f():
        t = pd.read_csv(f"{TRUTH}/elai_summary.v5.tsv", sep="\t", usecols=["chrom_v5", "pos_v5", "B73.amp"],
                        dtype={"chrom_v5": str})
        t = t[t.chrom_v5.isin([str(i) for i in range(1, 11)])]
        t = t.assign(chrom="chr" + t.chrom_v5).rename(columns={"pos_v5": "pos"})[["chrom", "pos", "B73.amp"]]
        return t[t["B73.amp"] > -900].reset_index(drop=True)
    return cached("elai", f)


def load_lib(g):
    def f():
        import glob
        keep = ["seq_id", "seq_len", "ltr5_start", "ltr5_end", "ltr3_start", "ltr3_end", "k2p", "motif", "tsd",
                "strand", "family", "domains", "nest_status"]
        parts = []
        for fn in sorted(glob.glob(f"{RUN}/{g}_LTRs_depth*_clean_ltr.tsv")):
            d = pd.read_csv(fn, sep="\t", dtype=str)
            d.columns = [c.lstrip("#") for c in d.columns]
            parts.append(d[keep])
        return pd.concat(parts, ignore_index=True)
    return cached(f"lib_{g}", f)


def parse_id(s):
    """'G_chrN:start-end#cls' -> (chrom, start, end)."""
    c, rest = s.split(":", 1)
    a, b = rest.split("#")[0].split("-")
    return c, int(a), int(b)


def load_orthologs(other):
    """B73 -> other: present 1:1 orthologs with both copies on the same chromosome number; flag pairs in inverted
    collinear blocks (blocks.tsv, sign -1)."""
    def f():
        o = pd.read_csv(f"{MAIN}/orthologs.B73v5.{other}.tsv.gz", sep="\t")
        o = o[o[f"status_in_{other}"] == "present"].copy()
        ids = o[other].str.extract(r"^(?P<oc>[^:]+):(?P<os>\d+)-(?P<oe>\d+)")
        o["oc"], o["os"], o["oe"] = ids.oc, ids.os.astype(int), ids.oe.astype(int)
        o["c"] = o.chrom.str.extract(r"_(chr\d+)$")[0]
        o["occ"] = o.oc.str.extract(r"_(chr\d+)$")[0]
        n_all = len(o)
        o = o[o.c.notna() & (o.c == o.occ)].copy()
        o["bmid"] = (o.start + o.end) / 2
        o["omid"] = (o.os + o.oe) / 2
        bl = pd.read_csv(f"{MAIN}/blocks.tsv", sep="\t")
        bl = bl[(bl.genome_a == "B73v5") & (bl.genome_b == other) & (bl.sign < 0)]
        inv = np.zeros(len(o), bool)
        for _, r in bl.iterrows():
            inv |= ((o.chrom == r.chrom_a) & (o.oc == r.chrom_b) & (o.start >= r.start_a) & (o.end <= r.end_a) &
                    (o.os >= r.start_b) & (o.oe <= r.end_b)).values
        o["inv"] = inv
        o.attrs["n_present"] = n_all
        return o[["c", "bmid", "omid", "inv", "divergence", "same_tsd"]].assign(n_present=n_all)
    return cached(f"orth_{other}", f)


def chrom_lengths(g):
    f = pd.read_csv(f"{INPUTS}/{g}.fa.fai", sep="\t", header=None, usecols=[0, 1], names=["chrom", "len"])
    f["c"] = f.chrom.str.extract(r"_(chr\d+)$")[0]
    return f[f.c.notna()].set_index("c")["len"]


def windows(e, t, win, score_col, w_col=None):
    """Same as benchmark/scripts/eval_real.py windows(): per window, weighted mean element score and mean ELAI
    dosage (>= 5 SNPs); windows indexed from 0 per chromosome."""
    rows = []
    for c in CHROMS:
        ee, g = e[e.c == c], t[t.chrom == c]
        if len(ee) == 0 or len(g) == 0:
            continue
        n = int(max(ee.end.max(), g.pos.max()) // win) + 1
        wi = ((ee.start + ee.end) // 2 // win).astype(int).values
        w = ee[w_col].values if w_col else np.ones(len(ee))
        sc = np.bincount(wi, ee[score_col].values * w, n)
        sw = np.bincount(wi, w, n)
        ti = (g.pos // win).astype(int).values
        tm = np.bincount(ti, g["B73.amp"].values, n)
        tn = np.bincount(ti, minlength=n)
        rows.append(pd.DataFrame(dict(c=c, w=np.arange(n), score=np.where(sw > 0, sc / np.maximum(sw, 1e-12), np.nan),
                                      truth=np.where(tn >= 5, tm / np.maximum(tn, 1), np.nan), nsnp=tn)))
    return pd.concat(rows, ignore_index=True)


def shift_null(w, nperm=1000, seed=1):
    """Same as eval_real.py shift_test(); also returns the null correlations."""
    ok = w.score.notna() & w.truth.notna()
    r = spearmanr(w.score[ok], w.truth[ok]).correlation
    rng = np.random.default_rng(seed)
    null = np.empty(nperm)
    for k in range(nperm):
        parts = []
        for c, g in w.groupby("c", sort=False):
            parts.append(np.roll(g.score.values, rng.integers(1, len(g)) if len(g) > 1 else 0))
        s = np.concatenate(parts)
        m = ~np.isnan(s) & w.truth.notna().values
        null[k] = spearmanr(s[m], w.truth.values[m]).correlation
    return r, (1 + (null >= r).sum()) / (1 + nperm), int(ok.sum()), null


DON = ["near_donor", "donor_only"]
SIS = ["near_sister", "sister_only"]


def window_tests():
    """Spearman r between window means and ELAI for the ancestry posterior and the model-free class share, with the
    circular-shift null (1,000 shifts, as in eval_real.py)."""
    def f():
        el, t = load_elements(), load_elai()
        el = el[el.c.notna()].copy()
        don, sis = el["class"].isin(DON), el["class"].isin(SIS)
        el["is_don"] = don.astype(float)
        rows = []
        for win in (100_000, 500_000, 1_000_000, 2_000_000, 5_000_000, 10_000_000):
            w = windows(el, t, win, "post_ancestry_TIL18", "len")
            r, p, n, null = shift_null(w)
            rows.append(dict(score="posterior", win=win, r=r, p=p, n=n, null_lo=np.quantile(null, 0.025),
                             null_hi=np.quantile(null, 0.975), null_med=np.median(null)))
            w2 = windows(el[don | sis], t, win, "is_don")
            r2, p2, n2, null2 = shift_null(w2)
            rows.append(dict(score="class_share", win=win, r=r2, p=p2, n=n2, null_lo=np.quantile(null2, 0.025),
                             null_hi=np.quantile(null2, 0.975), null_med=np.median(null2)))
            log(f"windows {win / 1e6:g} Mb: posterior r={r:.3f} p={p:.4f}; class share r={r2:.3f}", True)
        return pd.DataFrame(rows)
    return cached("window_tests", f)


def element_truth():
    """Per-element ELAI dosage within +-20 kb (>= 3 SNPs), as eval_real.py per_element_truth()."""
    def f():
        el, t = load_elements(), load_elai()
        e = el[el.c.notna()].reset_index(drop=True)
        out = np.full(len(e), np.nan)
        nsnp = np.zeros(len(e), int)
        for c, g in t.groupby("chrom"):
            p, v = g.pos.values, g["B73.amp"].values
            m = (e.c == c).values
            s, en = e.start.values[m] - 20_000, e.end.values[m] + 20_000
            i, j = np.searchsorted(p, s), np.searchsorted(p, en)
            cs = np.r_[0, np.cumsum(v)]
            n = j - i
            out[np.where(m)[0]] = np.where(n > 0, (cs[j] - cs[i]) / np.maximum(n, 1), np.nan)
            nsnp[np.where(m)[0]] = n
        return e.assign(dos=out, nsnp=nsnp)[["c", "start", "end", "class", "post_ancestry_TIL18", "dos", "nsnp"]]
    return cached("element_truth", f)


def auc(score, label):
    label = np.asarray(label, bool)
    n1, n0 = label.sum(), (~label).sum()
    r = rankdata(score)
    return float((r[label].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


# ---------------------------------------------------------------------------------------------------------------------
# example selection (SPEC rule) and the base-pair triple
# ---------------------------------------------------------------------------------------------------------------------
def select_example():
    """Panel B region: non-overlapping 3-Mb windows (eval_real.py window definition) with >= 30 informative elements
    (near_donor, donor_only, near_sister, sister_only); among windows with ELAI ancestry above the genome mean, keep
    those whose posterior AND ELAI are both within the 25th-75th percentile of that subset, exclude windows touching
    an inverted block, and take the one closest to the subset medians (percentile distance)."""
    def f():
        el, t = load_elements(), load_elai()
        el = el[el.c.notna()].copy()
        el["inf"] = el["class"].isin(DON + SIS).astype(float)
        w = windows(el, t, 3_000_000, "post_ancestry_TIL18", "len")
        wi = windows(el, t, 3_000_000, "inf")  # mean of indicator; need counts
        cnt = []
        for c in CHROMS:
            ee = el[el.c == c]
            n = int(w[w.c == c].w.max()) + 1
            k = ((ee.start + ee.end) // 2 // 3_000_000).astype(int).values
            cnt.append(np.bincount(k, ee.inf.values, n))
        w["n_inf"] = np.concatenate(cnt)
        w["elai"] = w.truth / 2
        w = w[(w.n_inf >= 30) & w.score.notna() & w.elai.notna()].copy()
        gmean = t["B73.amp"].mean() / 2
        hi = w[w.elai > gmean].copy()
        q = hi[["score", "elai"]].quantile([0.25, 0.5, 0.75])
        hi["pr_post"], hi["pr_elai"] = hi.score.rank(pct=True), hi.elai.rank(pct=True)
        cand = hi[hi.score.between(q.score[0.25], q.score[0.75]) & hi.elai.between(q.elai[0.25], q.elai[0.75])].copy()
        bl = pd.read_csv(f"{MAIN}/blocks.tsv", sep="\t")
        bl = bl[(bl.genome_a == "B73v5") & (bl.sign < 0)]
        cand["start"], cand["end"] = cand.w * 3_000_000, (cand.w + 1) * 3_000_000
        cand["inv"] = [((bl.chrom_a == f"B73v5_{r.c}") & (bl.end_a >= r.start) & (bl.start_a <= r.end)).any()
                       for r in cand.itertuples()]
        cand["dist"] = np.hypot(cand.pr_post - 0.5, cand.pr_elai - 0.5)
        cand = cand.sort_values("dist")
        return dict(n_windows=len(w), n_hi=len(hi), gmean=gmean, q=q, cand=cand)
    return cached("example_region", f)


def read_fa_seq(path):
    return "".join(l.strip() for l in open(path) if not l.startswith(">")).upper()


def read_aln(p):
    d, k = {}, None
    for l in open(p):
        l = l.strip()
        if l.startswith(">"):
            k = l[1:]
            d[k] = []
        elif k:
            d[k].append(l.upper())
    return {k: "".join(v) for k, v in d.items()}


_TS = {("A", "G"), ("G", "A"), ("C", "T"), ("T", "C")}


def k2p(a, b):
    n = ts = tv = 0
    for x, y in zip(a, b):
        if x in "ACGT" and y in "ACGT":
            n += 1
            if x != y:
                ts += (x, y) in _TS
                tv += (x, y) not in _TS
    P, Q = ts / n, tv / n
    d = -0.5 * math.log(1 - 2 * P - Q) - 0.25 * math.log(1 - 2 * Q)
    a_, b_ = 1 - 2 * P - Q, 1 - 2 * Q
    c1, c2 = 1 / a_, 0.5 * (1 / a_ + 1 / b_)
    se = math.sqrt(max((c1 * c1 * P + c2 * c2 * Q - (c1 * P + c2 * Q) ** 2) / n, 0))
    return d, se, n


def triple_data(flank=50):
    """Re-extract the three copies (+-flank) from the assemblies, check TSD/ends/self-K2P, align the full copies and
    the six LTRs with mafft (G-INS-i), and classify every LTR site with the other LTR as outgroup (ltrmix D_self)."""
    def f():
        tdir = os.path.join(WORK, "triple")
        os.makedirs(tdir, exist_ok=True)
        info, seqs, ltrs = {}, {}, {}
        for g, nm in TRIPLE.items():
            lib = load_lib(g).set_index("seq_id").loc[nm]
            c, s, e = parse_id(nm)
            fa = os.path.join(tdir, f"{g}.fa")
            with open(fa, "w") as fo:
                subprocess.run(["samtools", "faidx", f"{INPUTS}/{g}.fa", f"{c}:{s - flank}-{e + flank}"], stdout=fo,
                               check=True)
            sq = read_fa_seq(fa)
            el = sq[flank:-flank]
            assert len(el) == int(lib.seq_len), (g, len(el), lib.seq_len)
            l5 = el[int(lib.ltr5_start) - 1:int(lib.ltr5_end)]
            l3 = el[int(lib.ltr3_start) - 1:int(lib.ltr3_end)]
            seqs[g], ltrs[g] = sq, (l5, l3)
            info[g] = dict(name=nm, chrom=c, start=s, end=e, length=len(el), tsd5=sq[flank - 5:flank],
                           tsd3=sq[len(sq) - flank:len(sq) - flank + 5], end5=el[:2], end3=el[-2:], tsd_lib=lib.tsd,
                           motif=lib.motif, k2p_lib=float(lib.k2p), strand=lib.strand, family=lib.family,
                           ltr5=(int(lib.ltr5_start), int(lib.ltr5_end)), ltr3=(int(lib.ltr3_start), int(lib.ltr3_end)),
                           domains=lib.domains, nest=lib.nest_status)
        with open(os.path.join(tdir, "ltrs6.fa"), "w") as fo:
            for g in TRIPLE:
                fo.write(f">{g}_5\n{ltrs[g][0]}\n>{g}_3\n{ltrs[g][1]}\n")
        with open(os.path.join(tdir, "full3.fa"), "w") as fo:
            for g in TRIPLE:
                fo.write(f">{g}\n{seqs[g]}\n")
        for a, b in (("ltrs6.fa", "ltrs6.aln"), ("full3.fa", "full3.aln")):
            with open(os.path.join(tdir, b), "w") as fo:
                subprocess.run(["mafft", "--globalpair", "--maxiterate", "1000", "--quiet", "--thread", "2",
                                os.path.join(tdir, a)], stdout=fo, check=True)
        A = read_aln(os.path.join(tdir, "ltrs6.aln"))
        F = read_aln(os.path.join(tdir, "full3.aln"))
        for g in TRIPLE:
            d, se, n = k2p(A[f"{g}_5"], A[f"{g}_3"])
            info[g].update(k2p_self=d, k2p_self_se=se, k2p_sites=n)
        pdist = {}
        for a, b in itertools.combinations(TRIPLE, 2):
            m = [(p, q) for p, q in zip(F[a], F[b]) if p in "ACGT" and q in "ACGT"]
            pdist[(a, b)] = (sum(p != q for p, q in m) / len(m), sum(p != q for p, q in m), len(m))
        rows = []
        for side, other in (("5", "3"), ("3", "5")):
            for j in range(len(A["B73v5_5"])):
                d_, r_, s_ = A[f"TIL18_{side}"][j], A[f"B73v5_{side}"][j], A[f"TIL01_{side}"][j]
                o = {A[f"{g}_{other}"][j] for g in TRIPLE}
                if "-" in (d_, r_, s_) or len(o) != 1:
                    continue
                o = o.pop()
                if o == "-" or (r_ == d_ == s_):
                    continue
                pat = ("ABBA" if (r_ == d_ and s_ != d_ and s_ == o) else "BABA" if (s_ == d_ and r_ != d_ and r_ == o)
                       else "BBAA" if (r_ == s_ and d_ != r_ and d_ == o) else
                       "TIL01" if (r_ == d_ == o) else "B73v5" if (s_ == d_ == o) else "TIL18" if (r_ == s_ == o)
                       else "other")
                rows.append(dict(ltr=side, col=j, B73v5=r_, TIL18=d_, TIL01=s_, other=o, pattern=pat))
        return dict(info=info, seqs=seqs, A=A, F=F, pdist=pdist, sites=pd.DataFrame(rows), flank=flank)
    return cached("triple", f)


# ---------------------------------------------------------------------------------------------------------------------
# figure helpers
# ---------------------------------------------------------------------------------------------------------------------
class Page:
    """One figure page; a full-page overlay axes uses figure millimeters as data units (y down)."""

    def __init__(self, w_mm, h_mm):
        self.w, self.h = w_mm, h_mm
        self.fig = plt.figure(figsize=(w_mm * MM, h_mm * MM))
        self.o = self.fig.add_axes([0, 0, 1, 1], zorder=-5)
        self.o.set_xlim(0, w_mm)
        self.o.set_ylim(h_mm, 0)
        self.o.axis("off")

    def ax(self, x, y, w, h, **kw):
        return self.fig.add_axes([x / self.w, 1 - (y + h) / self.h, w / self.w, h / self.h], **kw)

    def overlay(self, z=5):
        a = self.fig.add_axes([0, 0, 1, 1], zorder=z)
        a.set_xlim(0, self.w)
        a.set_ylim(self.h, 0)
        a.axis("off")
        a.patch.set_alpha(0)
        return a

    def letter(self, x, y, s):
        self.o.text(x, y, s, fontsize=9, fontweight="bold", va="top", ha="left")


def it(s):
    """Italic via mathtext, spaces and hyphens kept."""
    return r"$\mathit{" + s.replace(" ", r"\ ").replace("-", r"\text{-}") + "}$"


MONO = font_manager.FontProperties(family="Liberation Mono", size=5.6)
MONO_W = 0.6001 * 5.6 * 25.4 / 72  # mm per character (Liberation Mono advance = 0.6 em)


def stack_rows(starts, ends, gap):
    """Greedy IGV 'expanded' rows: an element goes to the first row whose last end + gap < its start."""
    order = np.argsort(starts, kind="stable")
    row_end, rows = [], np.zeros(len(starts), int)
    for i in order:
        for r, e in enumerate(row_end):
            if starts[i] > e + gap:
                rows[i], row_end[r] = r, ends[i]
                break
        else:
            rows[i] = len(row_end)
            row_end.append(ends[i])
    return rows


def nice_ticks(lo, hi, step):
    return np.arange(math.ceil(lo / step) * step, hi + 1e-9, step)


# ---------------------------------------------------------------------------------------------------------------------
# panel A: ten chromosomes, three genomes, one bp scale
# ---------------------------------------------------------------------------------------------------------------------
A_X0, A_COLW = 11.6, 16.8              # first column start, column width (mm)
A_P, A_B, A_M = (0.0, 1.0), (4.9, 9.1), (13.0, 14.0)  # bar spans within a column (mm)
A_TICK = 1.25
A_Y0, A_H = 13.6, 86.2                 # chromosome area top (mm) and height
A_WIN = 5_000_000                      # trace window (benchmark window size with r = 0.306)


def panel_A(P, numbers):
    ax = P.overlay(z=2)
    el = load_elements()
    el = el[el.c.notna()]
    t = load_elai()
    lens = {g: chrom_lengths(g) for g in ("B73v5", "TIL18", "TIL01")}
    ymax = max(l.max() for l in lens.values())
    s = A_H / (ymax / 1e6)

    def Y(bp):
        return A_Y0 + np.asarray(bp, float) / 1e6 * s

    # position axis
    ax.plot([7.6, 7.6], [Y(0), Y(300e6)], color="k", lw=0.5, solid_capstyle="butt")
    for v in (0, 100, 200, 300):
        ax.plot([7.0, 7.6], [Y(v * 1e6)] * 2, color="k", lw=0.5)
        ax.text(6.6, Y(v * 1e6), f"{v}", ha="right", va="center", fontsize=6)
    ax.text(1.4, Y(150e6), "Position (Mb)", rotation=90, ha="center", va="center", fontsize=6.5)
    o18, o01 = load_orthologs("TIL18"), load_orthologs("TIL01")
    wins = windows(el, t, A_WIN, "post_ancestry_TIL18", "len")
    bl = pd.read_csv(f"{MAIN}/blocks.tsv", sep="\t")
    cols = {}
    for k, c in enumerate(CHROMS):
        cx = A_X0 + k * A_COLW
        cols[c] = cx
        Lb, Lm, Lp = lens["B73v5"][c], lens["TIL18"][c], lens["TIL01"][c]
        for o, xa, xb, other in ((o01, cx + A_P[1], cx + A_B[0], "TIL01"), (o18, cx + A_B[1], cx + A_M[0], "TIL18")):
            ss_ = o[o.c == c]
            for inv, col, lw, al, z in ((False, "#ABABAB", 0.12, 0.32, 1), (True, "#333333", 0.16, 0.6, 2)):
                ss = ss_[ss_.inv == inv]
                if other == "TIL01":
                    seg = np.stack([np.c_[np.full(len(ss), xa), Y(ss.omid)], np.c_[np.full(len(ss), xb), Y(ss.bmid)]], 1)
                else:
                    seg = np.stack([np.c_[np.full(len(ss), xa), Y(ss.bmid)], np.c_[np.full(len(ss), xb), Y(ss.omid)]], 1)
                ax.add_collection(LineCollection(seg, colors=col, linewidths=lw, alpha=al, zorder=z))
            bb = bl[(bl.genome_a == "B73v5") & (bl.genome_b == other) & (bl.sign < 0) &
                    (bl.chrom_a == f"B73v5_{c}") & (bl.chrom_b == f"{other}_{c}")]
            xo, xb_ = (cx + A_P[1], cx + A_B[0]) if other == "TIL01" else (cx + A_M[0], cx + A_B[1])
            for r in bb.itertuples():
                if r.end_a - r.start_a < 2e6:
                    continue
                for ya, yb in ((r.start_a, r.end_b), (r.end_a, r.start_b)):
                    ax.plot([xb_, xo], [Y(ya), Y(yb)], color="k", lw=0.4, zorder=3, solid_capstyle="butt")
        for x_, L_ in ((cx + A_P[0], Lp), (cx + A_M[0], Lm)):
            ax.add_patch(Rectangle((x_, Y(0)), A_P[1] - A_P[0], Y(L_) - Y(0), facecolor="#EDEDED", edgecolor=MAIZE,
                                   lw=0.4, zorder=4))
        ax.add_patch(Rectangle((cx + A_B[0], Y(0)), A_B[1] - A_B[0], Y(Lb) - Y(0), facecolor="white", edgecolor=MAIZE,
                               lw=0.5, zorder=4))
        e = el[el.c == c]
        for cls, xa, xb, col in (("near_sister", cx + A_B[0] - A_TICK, cx + A_B[0], PAR),
                                 ("near_donor", cx + A_B[1], cx + A_B[1] + A_TICK, MEX)):
            y = Y(e[e["class"] == cls].mid.values)
            seg = np.stack([np.c_[np.full(len(y), xa), y], np.c_[np.full(len(y), xb), y]], 1)
            ax.add_collection(LineCollection(seg, colors=col, linewidths=0.3, alpha=0.8, zorder=5))
        ww = wins[wins.c == c]
        ym = Y(np.minimum((ww.w.values + 0.5) * A_WIN, Lb))
        bx0, bw = cx + A_B[0] + 0.3, A_B[1] - A_B[0] - 0.6
        ok_t = ww.truth.notna().values
        for wv in ww.w.values[~ok_t]:
            y0_, y1_ = wv * A_WIN, min((wv + 1) * A_WIN, Lb)
            if y1_ > y0_:
                ax.add_patch(Rectangle((cx + A_B[0], Y(y0_)), A_B[1] - A_B[0], Y(y1_) - Y(y0_), facecolor="none",
                                       edgecolor="#A0A0A0", hatch="////////", lw=0, zorder=5))
        ax.plot(bx0 + bw * np.where(ok_t, ww.truth.values / 2, np.nan), ym, color=ELAI, lw=0.6, zorder=6)
        ax.plot(bx0 + bw * ww.score.values, ym, color="k", lw=0.6, zorder=7)
        ax.text(cx + (A_B[0] + A_B[1]) / 2, 8.2, c, ha="center", va="center", fontsize=6.5)
        for x_, s_, colr in ((cx + sum(A_P) / 2, "P", PAR), (cx + sum(A_B) / 2, "B", MAIZE), (cx + sum(A_M) / 2, "M", MEX)):
            ax.text(x_, 11.5, s_, ha="center", va="center", fontsize=6, color=colr)
    # inversion names (only the two with published coordinates)
    r1 = bl[(bl.genome_a == "B73v5") & (bl.genome_b == "TIL01") & (bl.chrom_a == "B73v5_chr1") & (bl.sign < 0) &
            (bl.start_a < 70e6) & (bl.end_a > 100e6)].iloc[0]
    ax.text(cols["chr1"] - 1.0, Y((r1.start_b + r1.end_b) / 2), "Inv1n", rotation=90, ha="center", va="center",
            fontsize=6, fontweight="bold")
    r4 = bl[(bl.genome_a == "B73v5") & (bl.genome_b == "TIL18") & (bl.chrom_a == "B73v5_chr4") & (bl.sign < 0) &
            (bl.start_a > 170e6) & (bl.end_a < 190e6)].iloc[0]
    ax.text(cols["chr4"] + A_M[1] + 1.1, Y((r4.start_b + r4.end_b) / 2), "Inv4m", rotation=90, ha="center",
            va="center", fontsize=6, fontweight="bold")
    # zoom marks for panel B on all three genomes of chr6
    c, b0, b1 = REGION
    cx = cols[c]
    ax.add_patch(Rectangle((cx + A_B[0] - A_TICK - 0.25, Y(b0) - 0.35), A_B[1] - A_B[0] + 2 * A_TICK + 0.5,
                           Y(b1) - Y(b0) + 0.7, facecolor="none", edgecolor="k", lw=0.7, zorder=9))
    for g, span in zoom_spans().items():
        x_ = cx + (A_P[0] if g == "TIL01" else A_M[0])
        ax.add_patch(Rectangle((x_ - 0.3, Y(span[0])), 1.6, Y(span[1]) - Y(span[0]), facecolor="none",
                               edgecolor="k", lw=0.6, zorder=9))
    ax.text(cx + A_B[1] + A_TICK + 0.6, Y((b0 + b1) / 2), "B", ha="left", va="center", fontsize=7, fontweight="bold",
            zorder=10, bbox=dict(boxstyle="square,pad=0.08", fc="white", ec="none"))
    key_A(ax)
    # numbers
    w5 = wins[wins.score.notna() & wins.truth.notna()]
    numbers += [("A", "B73-TIL18 1:1 LTR-RT orthologs drawn (homologous chromosomes)", len(o18), "orthologs.B73v5.TIL18.tsv.gz"),
                ("A", "B73-TIL01 1:1 LTR-RT orthologs drawn (homologous chromosomes)", len(o01), "orthologs.B73v5.TIL01.tsv.gz"),
                ("A", "B73-TIL18 1:1 orthologs, all", int(o18.n_present.iloc[0]), "orthologs.B73v5.TIL18.tsv.gz"),
                ("A", "B73-TIL01 1:1 orthologs, all", int(o01.n_present.iloc[0]), "orthologs.B73v5.TIL01.tsv.gz"),
                ("A", "ortholog pairs inside inverted blocks drawn, B73-TIL18 / B73-TIL01",
                 f"{int(o18.inv.sum())} / {int(o01.inv.sum())}", "blocks.tsv + orthologs"),
                ("A", "5-Mb windows with posterior and ELAI (trace)", len(w5), "elements.B73v5.tsv + elai_summary.v5.tsv")]
    for cls in ("near_donor", "near_sister", "near_both", "donor_only", "sister_only", "shared", "private", "unresolved"):
        numbers.append(("A", f"B73 elements (chr1-10), class {cls}", int((el["class"] == cls).sum()), "elements.B73v5.tsv"))
    return ax


def runs(ax, x, y, parts, fs=6, **kw):
    """Draw [(text, style)] runs left to right from x (mm); style in {"", "i", "b"}; returns the end x."""
    for s, st in parts:
        ax.text(x, y, s, fontsize=fs, va="center", ha="left", style="italic" if "i" in st else "normal",
                weight="bold" if "b" in st else "normal", **kw)
        x += _width_pt(s, st, fs) / 72 * 25.4
    return x


def key_A(ax):
    """Key in the empty lower-right corner of panel A (columns chr7-chr10 below 240 Mb)."""
    x0, y0, dy = 114.5, 76.6, 2.42
    fs = 6

    def sw(x, y, col, kind="box", **kw):
        if kind == "box":
            ax.add_patch(Rectangle((x, y - 0.7), 2.4, 1.4, facecolor=col, edgecolor="none", zorder=8))
        elif kind == "tick":
            ax.plot([x + 0.3, x + 2.1], [y, y], color=col, lw=1.1, zorder=8, solid_capstyle="butt")
        elif kind == "line":
            ax.plot([x, x + 2.4], [y, y], color=col, lw=kw.get("lw", 0.8), zorder=8, alpha=kw.get("alpha", 1))
        elif kind == "hatch":
            ax.add_patch(Rectangle((x, y - 0.8), 2.4, 1.6, facecolor="none", edgecolor="#A0A0A0", hatch="////////",
                                   lw=0, zorder=8))
        elif kind == "cross":
            ax.plot([x, x + 2.4], [y - 0.8, y + 0.8], color="k", lw=0.4, zorder=8)
            ax.plot([x, x + 2.4], [y + 0.8, y - 0.8], color="k", lw=0.4, zorder=8)

    ax.text(x0, y0, "P", color=PAR, fontsize=fs, va="center", fontweight="bold")
    runs(ax, x0 + 2.0, y0, [("TIL01, ", ""), ("Z. mays", "i"), (" ssp. ", ""), ("parviglumis", "i")], fs)
    ax.text(x0 + 33.5, y0, "B", color=MAIZE, fontsize=fs, va="center", fontweight="bold")
    ax.text(x0 + 35.5, y0, "maize B73", fontsize=fs, va="center")
    y = y0 + dy
    ax.text(x0, y, "M", color=MEX, fontsize=fs, va="center", fontweight="bold")
    runs(ax, x0 + 2.0, y, [("TIL18, ssp. ", ""), ("mexicana", "i")], fs)
    y += dy * 1.15
    ax.text(x0, y, "B73 element (box in B; tick in A if near-identical):", fontsize=fs, va="center")
    items = [(MEX, "near-identical to M copy"), (MEX_L, "shared with M only"),
             (PAR, "near-identical to P copy"), (PAR_L, "shared with P only"),
             (CLASS_COL["shared"], "in all three, older"), (CLASS_COL["private"], "in B73 only")]
    for i, (col, lab) in enumerate(items):
        xx, yy = x0 + (i % 2) * 31.5, y + dy * (1 + i // 2)
        sw(xx, yy, col)
        ax.text(xx + 3.1, yy, lab, fontsize=fs, va="center")
    y += dy * 4.1
    sw(x0, y, ELAI, "line")
    ax.text(x0 + 3.1, y, "ELAI ancestry (SNPs)", fontsize=fs, va="center")
    sw(x0 + 31.5, y, "k", "line")
    ax.text(x0 + 34.6, y, "LTR-RT posterior", fontsize=fs, va="center")
    y += dy
    # mini B73 box: 0 = parviglumis-like side, 1 = mexicana-like side
    ax.add_patch(Rectangle((x0, y - 0.8), 4.2, 1.6, facecolor="white", edgecolor=MAIZE, lw=0.5, zorder=8))
    ax.text(x0 + 0.55, y, "0", fontsize=5, va="center", ha="center", zorder=9)
    ax.text(x0 + 3.65, y, "1", fontsize=5, va="center", ha="center", zorder=9)
    runs(ax, x0 + 5.0, y, [("mexicana", "i"), (" ancestry in B (5-Mb windows)", "")], fs)
    y += dy
    sw(x0, y, "#ABABAB", "line", lw=0.6)
    ax.text(x0 + 3.1, y, "ortholog pair", fontsize=fs, va="center")
    sw(x0 + 21.0, y, "#333333", "line", lw=0.6)
    ax.text(x0 + 24.1, y, "inverted", fontsize=fs, va="center")
    sw(x0 + 36.5, y, None, "cross")
    ax.text(x0 + 39.6, y, "inverted block", fontsize=fs, va="center")
    sw(x0 + 47.5, y - dy, None, "hatch")
    ax.text(x0 + 50.6, y - dy, "no ELAI", fontsize=fs, va="center")


def zoom_spans():
    """TIL01 and TIL18 stretches for panel B: the B73 window shifted by the median ortholog offset."""
    el = load_elements()
    c, b0, b1 = REGION
    x = el[(el.chrom == f"B73v5_{c}") & (el.start >= b0) & (el.end <= b1)]
    out = {}
    for g in ("TIL01", "TIL18"):
        y = x[x[f"in_{g}"] == "present"]
        pos = y[f"ortholog_{g}"].map(lambda s: sum(parse_id(s)[1:]) / 2)
        off = float(np.median(pos.values - y.mid.values))
        out[g] = (b0 + off, b1 + off)
    return out


# ---------------------------------------------------------------------------------------------------------------------
# panel B: one typical 3-Mb region, every element to size
# ---------------------------------------------------------------------------------------------------------------------
B_X0, B_X1 = 23.0, 169.0


def lib_elements(g, c, lo, hi):
    L = load_lib(g)
    ids = L.seq_id.str.extract(r"^(?P<c>[^:]+):(?P<s>\d+)-(?P<e>\d+)")
    m = (ids.c == f"{g}_{c}") & (ids.e.astype(int) >= lo) & (ids.s.astype(int) <= hi)
    d = pd.DataFrame(dict(name=L.seq_id[m], start=ids.s[m].astype(int), end=ids.e[m].astype(int)))
    return d.reset_index(drop=True)


def panel_B(P, yB, numbers):
    ax = P.overlay(z=3)
    el, t = load_elements(), load_elai()
    c, b0, b1 = REGION
    spans = zoom_spans()
    span_bp = b1 - b0
    W = B_X1 - B_X0

    def X(pos, g):
        lo = b0 if g == "B73v5" else spans[g][0]
        return B_X0 + (np.asarray(pos, float) - lo) / span_bp * W

    thr = 0.0012927
    gap_bp = 0.12 / W * span_bp
    rowh, step = 1.05, 1.32
    lanes = {"TIL01": yB + 5.0, "B73v5": yB + 15.6, "TIL18": yB + 39.4}
    eb = el[(el.chrom == f"B73v5_{c}") & (el.end >= b0) & (el.start <= b1)].copy()
    eb["row"] = stack_rows(eb.start.values, eb.end.values, gap_bp)
    linked = {"TIL01": set(eb.ortholog_TIL01[eb.in_TIL01 == "present"]), "TIL18": set(eb.ortholog_TIL18[eb.in_TIL18 == "present"])}
    tl = {}
    for g in ("TIL01", "TIL18"):
        d = lib_elements(g, c, int(spans[g][0]), int(spans[g][1]))
        d["row"] = stack_rows(d.start.values, d.end.values, gap_bp)
        d["linked"] = d.name.isin(linked[g])
        tl[g] = d
    nrow = {"TIL01": tl["TIL01"].row.max() + 1, "B73v5": eb.row.max() + 1, "TIL18": tl["TIL18"].row.max() + 1}
    log(f"panel B rows: {nrow}", True)
    # rows grow away from the B73 lane for TIL01 (upward) and downward for B73 and TIL18
    def ytop(g, row):
        if g == "TIL01":
            return lanes[g] + (nrow[g] - 1 - row) * step
        return lanes[g] + row * step
    for g, d in (("TIL01", tl["TIL01"]), ("TIL18", tl["TIL18"])):
        for r in d.itertuples():
            x0_, x1_ = X(max(r.start, spans[g][0]), g), X(min(r.end, spans[g][1]), g)
            ax.add_patch(Rectangle((x0_, ytop(g, r.row)), max(x1_ - x0_, 0.08), rowh,
                                   facecolor="#8F8F8F" if r.linked else "#D4D4D4", edgecolor="none", zorder=4))
    for s_, e_, cl, row in zip(eb.start, eb.end, eb["class"], eb.row):
        x0_, x1_ = X(max(s_, b0), "B73v5"), X(min(e_, b1), "B73v5")
        ax.add_patch(Rectangle((x0_, ytop("B73v5", row)), max(x1_ - x0_, 0.08), rowh, facecolor=CLASS_COL[cl],
                               edgecolor="#9A9A9A" if cl == "unresolved" else "none", lw=0.3, zorder=4))
    # lane bottoms / tops for links
    y01_bot = lanes["TIL01"] + nrow["TIL01"] * step
    yb_top = lanes["B73v5"] - 0.25
    yb_bot = lanes["B73v5"] + nrow["B73v5"] * step
    y18_top = lanes["TIL18"] - 0.25
    # traces box (B73 coordinates)
    tb0, tb1 = yb_bot + 4.4, yb_bot + 11.6
    # links
    for g, ya, yb_, col_near in (("TIL01", yb_top, y01_bot + 0.1, PAR), ("TIL18", tb1 + 0.35, y18_top, MEX)):
        x = eb[eb[f"in_{g}"] == "present"]
        segs, cols, lws = [], [], []
        for r in x.itertuples():
            d = r._asdict()
            oc, os_, oe = parse_id(d[f"ortholog_{g}"])
            if not (spans[g][0] <= (os_ + oe) / 2 <= spans[g][1]):
                continue
            near = d[f"div_{g}"] <= thr
            segs.append([(X(r.mid, "B73v5"), ya), (X((os_ + oe) / 2, g), yb_)])
            cols.append(col_near if near else "#9A9A9A")
            lws.append(0.55 if near else 0.4)
        ax.add_collection(LineCollection(segs, colors=cols, linewidths=lws, zorder=3))
        numbers.append(("B", f"links B73-{g} drawn in window (near-identical)",
                        f"{len(segs)} ({sum(1 for cc in cols if cc != '#9A9A9A')})", "elements.B73v5.tsv"))
    # axes (one per genome, same bp scale)
    def axis(g, y, up, lab):
        lo, hi = (b0, b1) if g == "B73v5" else spans[g]
        ax.plot([B_X0, B_X1], [y, y], color="k", lw=0.5, zorder=6)
        for v in nice_ticks(lo, hi, 500_000):
            xx = X(v, g)
            ax.plot([xx, xx], [y, y + (-0.7 if up else 0.7)], color="k", lw=0.5, zorder=6)
            ax.text(xx, y + (-1.0 if up else 1.0), f"{v / 1e6:.1f}", ha="center", va="bottom" if up else "top", fontsize=5.5)
        ax.text(B_X1 + 0.6, y + (-1.0 if up else 1.0), "Mb", ha="left", va="bottom" if up else "top", fontsize=5.5)
        ax.text(B_X0 - 2.0, y, lab, ha="right", va="center", fontsize=6)
    axis("TIL01", lanes["TIL01"] - 0.4, True, "")
    axis("B73v5", yb_bot + 0.3, False, "")
    axis("TIL18", lanes["TIL18"] + nrow["TIL18"] * step + 0.3, False, "")
    lab = {"TIL01": ("TIL01 chr6", PAR), "B73v5": ("B73 chr6", MAIZE), "TIL18": ("TIL18 chr6", MEX)}
    for g in ("TIL01", "B73v5", "TIL18"):
        yc = lanes[g] + nrow[g] * step / 2
        ax.text(B_X0 - 2.0, yc, lab[g][0], ha="right", va="center", fontsize=6, color=lab[g][1])
    # trace box
    tax = P.ax(B_X0, tb0, W, tb1 - tb0)
    tax.set_xlim(b0, b1)
    tax.set_ylim(0, 1)
    tax.set_xticks([])
    tax.set_yticks([0, 0.5, 1])
    tax.set_yticklabels(["0", "0.5", "1"], fontsize=5.5)
    tax.spines["bottom"].set_visible(False)
    tax.tick_params(axis="y", length=1.5, pad=1)
    te = t[(t.chrom == c) & (t.pos >= b0) & (t.pos <= b1)]
    tax.plot(te.pos, te["B73.amp"] / 2, color=ELAI, lw=0.55, zorder=3)
    eo = eb[eb.c.notna()].sort_values("mid")
    tax.plot(eo.mid, eo.post_ancestry_TIL18, color="k", lw=0.6, zorder=4)
    tax.text(-0.042, 0.5, it("mexicana") + "\nancestry", transform=tax.transAxes, ha="right", va="center",
             fontsize=6, linespacing=1.0)
    tax.text(1.006, eo.post_ancestry_TIL18.iloc[-1], "posterior", transform=tax.get_yaxis_transform(), ha="left",
             va="center", fontsize=5.5, color="k")
    tax.text(1.006, float(te["B73.amp"].iloc[-30:].mean() / 2), "ELAI", transform=tax.get_yaxis_transform(), ha="left",
             va="center", fontsize=5.5, color=ELAI)
    # triple marked
    tri = {g: parse_id(n) for g, n in TRIPLE.items()}
    for g in ("TIL01", "B73v5", "TIL18"):
        cc, s_, e_ = tri[g]
        d = eb if g == "B73v5" else tl[g]
        row = int(d.loc[d.start == s_, "row"].iloc[0])
        ax.add_patch(Rectangle((X(s_, g) - 0.35, ytop(g, row) - 0.3), X(e_, g) - X(s_, g) + 0.7, rowh + 0.6,
                               facecolor="none", edgecolor="k", lw=0.6, zorder=7))
    cc, s_, e_ = tri["TIL18"]
    row = int(tl["TIL18"].loc[tl["TIL18"].start == s_, "row"].iloc[0])
    ax.text(X(e_, "TIL18") + 0.8, ytop("TIL18", row) + rowh / 2, "C", fontsize=7, fontweight="bold", va="center",
            ha="left", zorder=8, bbox=dict(boxstyle="square,pad=0.05", fc="white", ec="none"))
    numbers += [("B", "region (B73 v5)", f"{c}:{b0}-{b1}", "rule: select_example()"),
                ("B", "TIL01 / TIL18 stretches (median ortholog offset)",
                 f"{spans['TIL01'][0]:.0f}-{spans['TIL01'][1]:.0f} / {spans['TIL18'][0]:.0f}-{spans['TIL18'][1]:.0f}",
                 "elements.B73v5.tsv"),
                ("B", "B73 elements in window", len(eb), "elements.B73v5.tsv"),
                ("B", "B73 classes in window", str(eb["class"].value_counts().to_dict()), "elements.B73v5.tsv"),
                ("B", "TIL01 / TIL18 elements drawn", f"{len(tl['TIL01'])} / {len(tl['TIL18'])}", "run/*_clean_ltr.tsv"),
                ("B", "ELAI SNPs in window", len(te), "elai_summary.v5.tsv")]
    blk = eb[(eb.start >= 142_380_000) & (eb.end <= 142_840_000)]
    for lo, hi, nm in ((b0, 142_380_000, "left"), (142_380_000, 142_840_000, "TIL18-like block"), (142_840_000, b1, "right")):
        gg = te[(te.pos >= lo) & (te.pos < hi)]
        ee = eb[(eb.mid >= lo) & (eb.mid < hi)]
        numbers.append(("B", f"{nm} {lo / 1e6:.2f}-{hi / 1e6:.2f} Mb: ELAI mean dosage/2; mean posterior; n elements",
                        f"{gg['B73.amp'].mean() / 2:.3f}; {ee.post_ancestry_TIL18.mean():.3f}; {len(ee)}",
                        "elai_summary.v5.tsv; elements.B73v5.tsv"))
    numbers.append(("B", "TIL18-like block classes", str(blk["class"].value_counts().to_dict()), "elements.B73v5.tsv"))
    return dict(tb1=tb1, X=X, y18=lanes["TIL18"], step=step, rowh=rowh, tl=tl)


# ---------------------------------------------------------------------------------------------------------------------
# panel C: one ortholog triple at base-pair resolution
# ---------------------------------------------------------------------------------------------------------------------
C_STRETCH = (326, 368)   # LTR-alignment columns shown at bp resolution (3' LTR), chosen to contain ABBA + a TIL01 site
GL = {"B73v5": "B73", "TIL18": "TIL18", "TIL01": "TIL01"}
GC = {"B73v5": MAIZE, "TIL18": MEX, "TIL01": PAR}


def panel_C(P, yC, numbers):
    ax = P.overlay(z=4)
    T = triple_data()
    info, A, F, sites, fl = T["info"], T["A"], T["F"], T["sites"], T["flank"]
    order = ["B73v5", "TIL18", "TIL01"]
    ncol = len(F["B73v5"])
    x0, x1 = B_X0, B_X1

    def XC(col):
        return x0 + np.asarray(col, float) / ncol * (x1 - x0)

    # sequence position -> alignment column for each copy
    colmap = {}
    for g in order:
        cm, k = [], 0
        for j, ch in enumerate(F[g]):
            if ch != "-":
                cm.append(j)
        colmap[g] = np.array(cm)
    yb = {"B73v5": yC + 6.2, "TIL18": yC + 9.1, "TIL01": yC + 12.0}
    bh = 1.5
    for g in order:
        I = info[g]
        cm = colmap[g]
        e0, e1 = cm[fl], cm[fl + I["length"] - 1]
        l5 = (cm[fl + I["ltr5"][0] - 1], cm[fl + I["ltr5"][1] - 1])
        l3 = (cm[fl + I["ltr3"][0] - 1], cm[fl + I["ltr3"][1] - 1])
        y = yb[g]
        ax.plot([XC(0), XC(ncol)], [y + bh / 2] * 2, color="#777777", lw=0.5, zorder=2)
        ax.add_patch(Rectangle((XC(e0), y), XC(e1) - XC(e0), bh, facecolor="#ECECEC", edgecolor="none", zorder=3))
        for a_, b_ in (l5, l3):
            ax.add_patch(Rectangle((XC(a_), y), XC(b_) - XC(a_), bh, facecolor="#5A5A5A", edgecolor="none", zorder=4))
        for tsd_col in (cm[fl - 5], cm[fl + I["length"]]):
            ax.add_patch(Rectangle((XC(tsd_col), y - 0.1), max(XC(tsd_col + 5) - XC(tsd_col), 0.25), bh + 0.2,
                                   facecolor="k", edgecolor="none", zorder=5))
        ax.text(x0 - 1.5, y + bh / 2, GL[g], ha="right", va="center", fontsize=6, color=GC[g])
        if g == "B73v5":
            for d in I["domains"].split(";"):
                nm, rng = d.split("@")
                a_, b_ = (int(v) for v in rng.split("-"))
                p0, p1 = a_ - I["start"], b_ - I["start"]
                ax.add_patch(Rectangle((XC(cm[fl + p0]), y), XC(cm[fl + p1]) - XC(cm[fl + p0]), bh, facecolor="#B9B9B9",
                                       edgecolor="none", zorder=4))
                ax.text(XC(cm[fl + (p0 + p1) // 2]), y - 0.5, nm.split("|")[0], ha="center", va="bottom", fontsize=5.5)
            for (a_, b_), nm in ((l5, "5′ LTR"), (l3, "3′ LTR")):
                ax.text(XC((a_ + b_) / 2), y - 0.5, nm, ha="center", va="bottom", fontsize=5.5)
            ax.annotate("", xy=(XC(e1) + 2.6, y + bh / 2), xytext=(XC(e1) + 0.9, y + bh / 2),
                        arrowprops=dict(arrowstyle="-|>,head_length=0.25,head_width=0.12", lw=0.5, color="k"), zorder=5)
    # differences from the B73 copy (substitutions) on the TIL18 and TIL01 rows
    diff_n = {}
    for g in ("TIL18", "TIL01"):
        cols = [j for j, (p, q) in enumerate(zip(F["B73v5"], F[g])) if p in "ACGT" and q in "ACGT" and p != q]
        diff_n[g] = len(cols)
        seg = [[(XC(j + 0.5), yb[g] - 0.15), (XC(j + 0.5), yb[g] + bh + 0.15)] for j in cols]
        ax.add_collection(LineCollection(seg, colors="k", linewidths=0.45, zorder=6))
    # ABBA LTR sites: B73 and TIL18 share the derived base (map LTR-alignment columns to full-alignment columns)
    ltr_cols = {}
    for side in ("5", "3"):
        g = "B73v5"
        I = info[g]
        a_ = I["ltr5"][0] if side == "5" else I["ltr3"][0]
        k, m = 0, {}
        for j, ch in enumerate(A[f"{g}_{side}"]):
            if ch != "-":
                m[j] = colmap[g][fl + a_ - 1 + k]
                k += 1
        ltr_cols[side] = m
    ab = sites[sites.pattern == "ABBA"]
    seg = [[(XC(ltr_cols[r.ltr][r.col] + 0.5), yb["B73v5"] - 0.25), (XC(ltr_cols[r.ltr][r.col] + 0.5), yb["TIL18"] + bh + 0.25)]
           for r in ab.itertuples()]
    ax.add_collection(LineCollection(seg, colors=MEX, linewidths=0.9, zorder=7))
    # 1-kb scale bar
    kb = 1000 / ncol * (x1 - x0)
    xk = 60.0
    ax.plot([xk, xk + kb], [yC + 15.0] * 2, color="k", lw=0.6)
    ax.text(xk + kb / 2, yC + 15.4, "1 kb", ha="center", va="top", fontsize=5.5)
    # ---- bottom: bp blocks (5' junction | 3' LTR stretch with the other LTR as outgroup | 3' junction)
    ry = {"B73v5": yC + 21.1, "TIL18": yC + 23.6, "TIL01": yC + 26.1, "og": yC + 28.6}
    cw = MONO_W
    nflank, nltr = 9, 7

    def seqrow(xs, y, s, styles):
        for i, ch in enumerate(s):
            st = styles[i] if styles else {}
            if st.get("bg"):
                ax.add_patch(Rectangle((xs + i * cw, y - 0.95), cw, 1.9, facecolor=st["bg"], edgecolor="none", zorder=5))
            ax.text(xs + (i + 0.5) * cw, y, ch, fontproperties=MONO, ha="center", va="center",
                    color=st.get("fc", "k"), zorder=6, fontweight=st.get("fw", "normal"))

    xs5 = 21.5
    for g in order:
        sq = T["seqs"][g]
        s = sq[fl - 5 - nflank:fl + nltr]
        stl = [{}] * nflank + [{}] * 5 + [dict(bg="#DADADA")] * nltr
        seqrow(xs5, ry[g], s, stl)
        ax.add_patch(Rectangle((xs5 + nflank * cw, ry[g] - 1.0), 5 * cw, 2.0, facecolor="none", edgecolor="k", lw=0.6, zorder=7))
        ax.text(xs5 - 1.2, ry[g], GL[g], ha="right", va="center", fontsize=6, color=GC[g])
    ax.text(xs5 + (nflank + 2.5) * cw, ry["B73v5"] - 1.6, "TSD", ha="center", va="bottom", fontsize=5.5)
    ax.text(xs5 + (nflank + 5 + nltr / 2) * cw, ry["B73v5"] - 1.6, "5′ LTR", ha="center", va="bottom", fontsize=5.5)
    xs3 = 178.0 - (nltr + 5 + nflank) * cw
    for g in order:
        sq = T["seqs"][g]
        n = len(sq)
        s = sq[n - fl - nltr:n - fl + 5 + nflank]
        stl = [dict(bg="#DADADA")] * nltr + [{}] * 5 + [{}] * nflank
        seqrow(xs3, ry[g], s, stl)
        ax.add_patch(Rectangle((xs3 + nltr * cw, ry[g] - 1.0), 5 * cw, 2.0, facecolor="none", edgecolor="k", lw=0.6, zorder=7))
    ax.text(xs3 + (nltr + 2.5) * cw, ry["B73v5"] - 1.6, "TSD", ha="center", va="bottom", fontsize=5.5)
    ax.text(xs3 + nltr / 2 * cw, ry["B73v5"] - 1.6, "3′ LTR", ha="center", va="bottom", fontsize=5.5)
    # LTR stretch: rows = 3' LTR of each copy; outgroup = 5' LTR (identical in all three at every shown column)
    c0, c1 = C_STRETCH
    xsm = 79.0
    st_sites = sites[(sites.ltr == "3") & (sites.col >= c0) & (sites.col <= c1)].set_index("col")
    og = "".join(A["TIL18_5"][c0:c1 + 1])
    same_og = all(A[f"{g}_5"][c0:c1 + 1] == og for g in order)
    for g in order:
        s = A[f"{g}_3"][c0:c1 + 1]
        stl = []
        for j in range(c0, c1 + 1):
            if j in st_sites.index:
                pat = st_sites.loc[j, "pattern"]
                if pat == "ABBA" and g in ("B73v5", "TIL18"):
                    stl.append(dict(bg=MEX, fc="white", fw="bold"))
                elif pat == "TIL01" and g == "TIL01":
                    stl.append(dict(bg=PAR, fc="white", fw="bold"))
                else:
                    stl.append(dict(fw="bold"))
            else:
                stl.append({})
        seqrow(xsm, ry[g], s, stl)
    stl = [dict(fw="bold") if j in st_sites.index else {} for j in range(c0, c1 + 1)]
    seqrow(xsm, ry["og"], og, stl)
    for g in order:
        ax.text(xsm - 1.2, ry[g], f"{GL[g]} 3′ LTR", ha="right", va="center", fontsize=6, color=GC[g])
    ax.text(xsm - 1.2, ry["og"], "5′ LTR, all copies", ha="right", va="center", fontsize=6)
    for j in st_sites.index:
        xx = xsm + (j - c0 + 0.5) * cw
        ax.plot([xx], [ry["B73v5"] - 1.75], marker="v", ms=2.2, color="k", mec="none", zorder=7)
    ax.text(xsm + (c1 - c0 + 1) / 2 * cw, ry["B73v5"] - 2.4, f"3′ LTRs, {c1 - c0 + 1} bp", ha="center",
            va="bottom", fontsize=5.5)
    # connectors from the element map to the blocks
    def conn(xa, xb, ya, yb_):
        ax.plot([xa, xb], [ya, yb_], color="#8A8A8A", lw=0.4, zorder=1)
    ymap = yb["TIL01"] + bh + 0.3
    cm = colmap["B73v5"]
    conn(XC(cm[fl - 5 - nflank]), xs5, ymap, ry["B73v5"] - 4.0)
    conn(XC(cm[fl + nltr]), xs5 + (nflank + 5 + nltr) * cw, ymap, ry["B73v5"] - 4.0)
    n_b = len(T["seqs"]["B73v5"])
    conn(XC(cm[n_b - fl - nltr]), xs3, ymap, ry["B73v5"] - 4.0)
    conn(XC(cm[min(n_b - fl + 5 + nflank, n_b - 1)]), 178.0, ymap, ry["B73v5"] - 4.0)
    ca, cb = ltr_cols["3"][c0], ltr_cols["3"][c1]
    ax.add_patch(Rectangle((XC(ca) - 0.2, yb["B73v5"] - 0.5), XC(cb) - XC(ca) + 0.4, yb["TIL01"] + bh - yb["B73v5"] + 1.0,
                           facecolor="none", edgecolor="k", lw=0.5, zorder=8))
    conn(XC(ca) - 0.2, xsm, ymap + 0.2, ry["B73v5"] - 4.0)
    conn(XC(cb) + 0.2, xsm + (c1 - c0 + 1) * cw, ymap + 0.2, ry["B73v5"] - 4.0)
    # numbers
    for g in order:
        I = info[g]
        numbers += [("C", f"{GL[g]} copy", f"{I['name']} ({I['length']} bp, strand {I['strand']})", "run/*_clean_ltr.tsv"),
                    ("C", f"{GL[g]} TSD 5'/3' (assembly) vs library", f"{I['tsd5']}/{I['tsd3']} vs {I['tsd_lib']}", "inputs/*.fa"),
                    ("C", f"{GL[g]} ends", f"{I['end5']}..{I['end3']}", "inputs/*.fa"),
                    ("C", f"{GL[g]} self-LTR K2P re-aligned (SE; sites) vs annotation",
                     f"{I['k2p_self']:.4f} ({I['k2p_self_se']:.4f}; {I['k2p_sites']}) vs {I['k2p_lib']:.4f}", "mafft G-INS-i")]
    for (a_, b_), (p, n, m) in T["pdist"].items():
        numbers.append(("C", f"p-distance {GL[a_]}-{GL[b_]} (differences / aligned sites)", f"{p:.5f} ({n}/{m})", "mafft G-INS-i"))
    numbers.append(("C", "substitutions vs B73 copy drawn: TIL18 / TIL01", f"{diff_n['TIL18']} / {diff_n['TIL01']}", "mafft"))
    vc = sites.pattern.value_counts().to_dict()
    numbers.append(("C", "polarized LTR sites (other LTR as outgroup): ABBA/BABA/BBAA/private TIL01/B73/TIL18",
                    f"{vc.get('ABBA', 0)}/{vc.get('BABA', 0)}/{vc.get('BBAA', 0)}/{vc.get('TIL01', 0)}/{vc.get('B73v5', 0)}/{vc.get('TIL18', 0)}",
                    "mafft, ltrmix D_self rule"))
    numbers.append(("C", "outgroup 5' LTR identical in all three copies over the shown stretch", str(same_og), "mafft"))
    lib = load_lib("B73v5")
    fam = lib[lib.family == info["B73v5"]["family"]].seq_len.astype(int)
    numbers.append(("C", f"family {info['B73v5']['family']} length median / this copy's percentile (B73)",
                    f"{int(fam.median())} / {(fam < info['B73v5']['length']).mean():.2f}", "run/B73v5_*_clean_ltr.tsv"))
    return dict(diff_n=diff_n, vc=vc, same_og=same_og)


# ---------------------------------------------------------------------------------------------------------------------
# panels D-F: agreement with ELAI at three scales
# ---------------------------------------------------------------------------------------------------------------------
def style_ax(a):
    a.tick_params(length=2, width=0.5, pad=1.5)
    for s_ in ("left", "bottom"):
        a.spines[s_].set_linewidth(0.5)


def panel_D(P, x, y, w, h, numbers):
    a = P.ax(x, y, w, h)
    style_ax(a)
    bc = pd.read_csv(f"{MAIN}/benchmark_chromosomes.tsv", sep="\t", index_col=0)
    low = {"chr5", "chr8", "chr9"}
    xs, ys = bc.ELAI_B73, bc.post_mean
    # lowest three by both: shade the corner below the 4th-lowest values
    x4, y4 = np.sort(xs.values)[3], np.sort(ys.values)[3]
    a.add_patch(Rectangle((0, 0), (np.sort(xs.values)[2] + x4) / 2, (np.sort(ys.values)[2] + y4) / 2,
                          facecolor="#EFEFEF", edgecolor="none", zorder=0))
    for c in bc.index:
        hi = c in low
        a.plot(xs[c], ys[c], "o", ms=3.4, color="k" if hi else "white", mec="k", mew=0.6, zorder=3)
    offs = {"chr1": (0.005, 0.0), "chr7": (-0.005, 0.0), "chr3": (0.005, 0.0), "chr2": (0.005, 0.005),
            "chr6": (0.005, -0.006), "chr10": (0.005, 0.0), "chr4": (-0.005, 0.0), "chr5": (0.005, 0.0),
            "chr8": (0.005, 0.0), "chr9": (0.005, 0.0)}
    for c in bc.index:
        dx, dy = offs.get(c, (0.004, 0))
        a.text(xs[c] + dx, ys[c] + dy, c.replace("chr", ""), fontsize=6, ha="left" if dx > 0 else "right",
               va="center", fontweight="bold" if c in low else "normal")
    # chromosome 1 without Inv1n (same formulas, interval removed) -- computed here
    el, t = load_elements(), load_elai()
    e1 = el[(el.c == "chr1") & ~((el.mid >= INV1N_B73[0]) & (el.mid <= INV1N_B73[1]))]
    t1 = t[(t.chrom == "chr1") & ~((t.pos >= INV1N_B73[0]) & (t.pos <= INV1N_B73[1]))]
    px, py = t1["B73.amp"].mean() / 2, np.average(e1.post_ancestry_TIL18, weights=e1.len)
    a.annotate("", xy=(px, py), xytext=(xs["chr1"], ys["chr1"]),
               arrowprops=dict(arrowstyle="-|>,head_length=0.3,head_width=0.15", lw=0.5, color="#666666",
                               shrinkA=2.2, shrinkB=1.8), zorder=2)
    a.plot(px, py, "o", ms=3.4, color="#BDBDBD", mec="#777777", mew=0.6, zorder=3, linestyle="none")
    a.text(px - 0.005, py, "1 without\nInv1n", fontsize=5.5, ha="right", va="center", color="#555555",
           linespacing=1.0)
    a.set_xlim(0.04, 0.26)
    a.set_ylim(0.295, 0.47)
    a.set_xticks([0.05, 0.1, 0.15, 0.2, 0.25])
    a.set_yticks([0.3, 0.35, 0.4, 0.45])
    a.set_xlabel("ELAI " + it("mexicana") + " ancestry\n(SNPs, mean per chromosome)", labelpad=1.5, linespacing=1.0)
    a.set_ylabel("LTR-RT posterior\n(mean per chromosome)", labelpad=1.5, linespacing=1.0)
    br = pd.read_csv(f"{MAIN}/benchmark_real.tsv", sep="\t")
    row = br[br.item == "three lowest by post_mean"].iloc[0]
    numbers += [("D", f"{c} ELAI mean ancestry / posterior mean", f"{xs[c]:.4f} / {ys[c]:.4f}", "benchmark_chromosomes.tsv")
                for c in bc.index]
    numbers += [("D", "three lowest by posterior; bar", f"{row.value}; {row.bar}", "benchmark_real.tsv"),
                ("D", "Spearman posterior vs ELAI per chromosome", row.note, "benchmark_real.tsv"),
                ("D", "chr1 without Inv1n block (B73 60.95-108.99 Mb): ELAI / posterior (computed here)",
                 f"{px:.4f} / {py:.4f}", "elements.B73v5.tsv + elai_summary.v5.tsv"),
                ("D", "Spearman class share vs ELAI per chromosome",
                 br[br.item == "three lowest by class_share"].note.iloc[0], "benchmark_real.tsv")]
    return a


INV1N_B73 = (60_951_927, 108_988_827)   # B73-TIL01 inverted block, blocks.tsv


def panel_E(P, x, y, w, h, numbers):
    a = P.ax(x, y, w, h)
    style_ax(a)
    wt = window_tests()
    br = pd.read_csv(f"{MAIN}/benchmark_real.tsv", sep="\t")
    sizes = np.array(sorted(wt.win.unique())) / 1e6
    for sc, col, ls, mk, lab in (("posterior", "k", "-", "o", "posterior"), ("class_share", "#8A8A8A", "-", "s", "class share")):
        d = wt[wt.score == sc].sort_values("win")
        if sc == "posterior":
            a.fill_between(d.win / 1e6, d.null_lo, d.null_hi, color="#E3E3E3", lw=0, zorder=0)
        a.plot(d.win / 1e6, d.r, ls=ls, color=col, lw=0.8, marker=mk, ms=2.6, mec=col, mfc=col if sc == "posterior" else "white",
               mew=0.6, zorder=3)
        a.annotate(lab, (10, d.r.iloc[-1]), xytext=(4, 0), textcoords="offset points", fontsize=5.5, ha="left",
                   va="center", color=col)
        for r in d.itertuples():
            # check against the benchmark table
            nm = "posterior vs ELAI" if sc == "posterior" else "model-free class share vs ELAI"
            v = br[br.item == f"{nm}, {r.win / 1e6:g} Mb"].value.iloc[0]
            rt = float(v.split(",")[0].split("=")[1])
            assert abs(rt - r.r) < 0.0015, (sc, r.win, rt, r.r)
            numbers.append(("E", f"{lab} Spearman r, {r.win / 1e6:g} Mb windows (table value; p; n)", v, "benchmark_real.tsv"))
            numbers.append(("E", f"{lab} circular-shift null 2.5-97.5%, {r.win / 1e6:g} Mb (computed here)",
                            f"{r.null_lo:.3f} to {r.null_hi:.3f}", "eval_real.py shift_test logic, 1,000 shifts"))
    a.axhline(0, color="k", lw=0.5, zorder=1)
    a.text(0.105, 0.03, "null", fontsize=5.5, color="#7A7A7A", ha="left", va="bottom")
    a.set_xscale("log")
    a.set_xlim(0.08, 11)
    a.set_xticks([0.1, 1, 10])
    a.set_xticklabels(["0.1 Mb", "1 Mb", "10 Mb"])
    a.minorticks_off()
    a.set_ylim(-0.1, 0.45)
    a.set_yticks([0, 0.1, 0.2, 0.3, 0.4])
    a.set_xlabel("window size", labelpad=1.5)
    a.set_ylabel("Spearman r with ELAI\n(windows along B73)", labelpad=1.5, linespacing=1.0)
    return a


def panel_F(P, x, y, w, h, numbers):
    a = P.ax(x, y, w, h)
    style_ax(a)
    et = element_truth()
    et = et[et.nsnp >= 3]
    br = pd.read_csv(f"{MAIN}/benchmark_real.tsv", sep="\t")
    hi, lo = et[et.dos >= 1.0], et[et.dos <= 0.2]
    for d, col, lab in ((lo, PAR, "ELAI ≤ 0.2"), (hi, MEX, "ELAI ≥ 1")):
        v = np.sort(d.post_ancestry_TIL18.values)
        yv = np.arange(1, len(v) + 1) / len(v)
        a.step(v, yv, where="post", color=col, lw=0.8)
    v = np.sort(et.post_ancestry_TIL18.values)
    a.step(v, np.arange(1, len(v) + 1) / len(v), where="post", color="#9A9A9A", lw=0.6, ls=(0, (2.5, 1.5)), zorder=1)
    a.text(0.62, 0.66, "all", fontsize=5.5, color="#7A7A7A", ha="left", va="center")
    a.text(0.30, 0.86, f"ELAI dosage ≤ 0.2\nn = {len(lo):,}", fontsize=5.5, color=PAR, ha="center", va="center",
           linespacing=1.0)
    a.text(0.74, 0.30, f"ELAI dosage ≥ 1\nn = {len(hi):,}", fontsize=5.5, color=MEX, ha="center", va="center",
           linespacing=1.0)
    a.set_xlim(0, 1)
    a.set_ylim(0, 1.0)
    a.set_xticks([0, 0.5, 1])
    a.set_yticks([0, 0.5, 1])
    a.set_xlabel("LTR-RT posterior of the element", labelpad=1.5)
    a.set_ylabel("cumulative fraction\nof B73 elements", labelpad=1.5, linespacing=1.0)
    a1 = auc(pd.concat([hi, lo]).post_ancestry_TIL18, np.r_[np.ones(len(hi)), np.zeros(len(lo))])
    t1 = float(br[br.item == "AUROC ancestry posterior, ELAI >= 1.0 vs <= 0.2"].value.iloc[0])
    t2 = float(br[br.item == "AUROC ancestry posterior, ELAI >= 1.5 vs <= 0.2"].value.iloc[0])
    assert abs(a1 - t1) < 0.001, (a1, t1)
    numbers += [("F", "AUROC posterior, ELAI dosage >= 1 vs <= 0.2 (n_pos, n_neg)", f"{t1} ({len(hi)}, {len(lo)})", "benchmark_real.tsv"),
                ("F", "AUROC posterior, ELAI dosage >= 1.5 vs <= 0.2", f"{t2} ({int((et.dos >= 1.5).sum())})", "benchmark_real.tsv"),
                ("F", "elements with >= 3 ELAI SNPs within 20 kb (pooled reference curve)", len(et), "elements + ELAI"),
                ("F", "median posterior, dosage >= 1 / <= 0.2 (computed here)",
                 f"{hi.post_ancestry_TIL18.median():.3f} / {lo.post_ancestry_TIL18.median():.3f}", "elements.B73v5.tsv")]
    return a


# ---------------------------------------------------------------------------------------------------------------------
# legend pages (rich text: *italic*, **bold**)
# ---------------------------------------------------------------------------------------------------------------------
from matplotlib.textpath import TextToPath
_T2P = TextToPath()


def _width_pt(s, style, size):
    if "s" in style:
        size = size * 0.7
    fp = font_manager.FontProperties(family="Liberation Sans", size=size,
                                     style="italic" if "i" in style else "normal",
                                     weight="bold" if "b" in style else "normal")
    w, h, d = _T2P.get_text_width_height_descent(s, fp, ismath=False)
    return w


def _tokens(par):
    """Split '*italic*' and '**bold**' markup into (word, style, space_after) tokens."""
    out, style, buf, i = [], "", "", 0
    while i < len(par):
        if par.startswith("^{", i):
            if buf:
                out.append((buf, style))
                buf = ""
            j = par.index("}", i)
            out.append((par[i + 2:j], style + "s"))
            i = j + 1
        elif par.startswith("**", i):
            if buf:
                out.append((buf, style))
                buf = ""
            style = style.replace("b", "") if "b" in style else style + "b"
            i += 2
        elif par[i] == "*":
            if buf:
                out.append((buf, style))
                buf = ""
            style = style.replace("i", "") if "i" in style else style + "i"
            i += 1
        else:
            buf += par[i]
            i += 1
    if buf:
        out.append((buf, style))
    words = []  # (text, style, glue_before)
    for txt, st in out:
        parts = txt.split(" ")
        for k, p in enumerate(parts):
            if p == "":
                if words:
                    words[-1] = (words[-1][0], words[-1][1], words[-1][2], True)
                continue
            glue = k > 0 or (txt.startswith(" "))
            words.append((p, st, glue, False))
    toks = []
    for k, (p, st, glue, sp_after) in enumerate(words):
        space_before = k > 0 and (glue or words[k - 1][3])
        toks.append((p, st, space_before))
    return toks


def layout_text(paragraphs, width_mm, size=10, lead=1.25, par_gap=0.55):
    width_pt = width_mm / 25.4 * 72
    sp = _width_pt(" ", "", size)
    lines = []  # list of (list of (x_pt, text, style), is_par_start)
    for par in paragraphs:
        toks = _tokens(par)
        cur, x = [], 0.0
        for text, st, space_before in toks:
            w = _width_pt(text, st, size)
            add = (sp if (space_before and cur) else 0.0)
            if cur and x + add + w > width_pt:
                lines.append((cur, False))
                cur, x, add = [], 0.0, 0.0
            cur.append((x + add, text, st))
            x += add + w
        lines.append((cur, True))
    return lines


def legend_page(pdf, paragraphs, width_mm=FIG_W, size=10, margin=10):
    lead_mm = size * 1.25 / 72 * 25.4
    lines = layout_text(paragraphs, width_mm - 2 * margin, size)
    n_par_gaps = sum(1 for _, end in lines if end)
    h = 2 * margin + len(lines) * lead_mm + n_par_gaps * lead_mm * 0.45
    fig = plt.figure(figsize=(width_mm * MM, h * MM))
    y = margin
    for toks, end in lines:
        for x_pt, text, st in toks:
            sup = "s" in st
            fig.text((margin + x_pt / 72 * 25.4) / width_mm,
                     1 - (y + lead_mm * 0.8 - (size * 0.36 / 72 * 25.4 if sup else 0)) / h, text,
                     fontsize=size * (0.7 if sup else 1),
                     family="Liberation Sans", style="italic" if "i" in st else "normal",
                     weight="bold" if "b" in st else "normal", va="baseline", ha="left")
        y += lead_mm
        if end:
            y += lead_mm * 0.45
    pdf.savefig(fig)
    plt.close(fig)


# ---------------------------------------------------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------------------------------------------------
def check_example(numbers):
    """Assert that the hard-coded region and triple are what the SPEC rule and the structural checks select."""
    ex = select_example()
    cand = ex["cand"]
    top = cand[~cand.inv].iloc[0]
    assert (top.c, int(top.start), int(top.end)) == REGION, (top.c, top.start, top.end)
    numbers += [("B", "3-Mb windows with >= 30 informative elements", ex["n_windows"], "elements.B73v5.tsv"),
                ("B", "of these, ELAI ancestry above genome mean", ex["n_hi"], "elai_summary.v5.tsv"),
                ("B", "ELAI genome mean ancestry (dosage/2)", f"{ex['gmean']:.4f}", "elai_summary.v5.tsv"),
                ("B", "posterior quartiles (25/50/75%) of those windows",
                 "/".join(f"{v:.3f}" for v in ex["q"].score), "elements.B73v5.tsv"),
                ("B", "ELAI quartiles (25/50/75%) of those windows", "/".join(f"{v:.3f}" for v in ex["q"].elai),
                 "elai_summary.v5.tsv"),
                ("B", "candidates in both middle-50% ranges (outside inverted blocks)",
                 f"{len(cand)} ({int((~cand.inv).sum())})", "rule"),
                ("B", "chosen window posterior / ELAI / informative elements",
                 f"{top.score:.3f} / {top.elai:.3f} / {int(top.n_inf)}", "rule")]
    T = triple_data()
    for g, I in T["info"].items():
        assert I["tsd5"] == I["tsd3"] == I["tsd_lib"] == "GCTTA", (g, I["tsd5"], I["tsd3"])
        assert I["end5"] == "TG" and I["end3"] == "CA", g
        assert abs(I["k2p_self"] - I["k2p_lib"]) <= max(1.96 * I["k2p_self_se"], 1 / I["k2p_sites"]), g
    return ex, top


def main():
    global VERBOSE
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("-v", "--verbose", action="store_true", help="per-step progress and sanity checks")
    ap.add_argument("--rebuild", action="store_true", help="delete cached inputs in ./work and recompute everything")
    a = ap.parse_args()
    VERBOSE = a.verbose
    setup_style()
    log("start")
    if a.rebuild and os.path.isdir(WORK):
        import glob, shutil
        for f in glob.glob(os.path.join(WORK, "*.pkl")):
            os.remove(f)
        shutil.rmtree(os.path.join(WORK, "triple"), ignore_errors=True)
        log("caches cleared")
    numbers = []
    ex, top = check_example(numbers)
    log("example region and triple verified")
    P = Page(FIG_W, PAGE_H)
    P.letter(0.5, 0.6, "A")
    panel_A(P, numbers)
    log("panel A drawn", True)
    yB = 102.0
    P.letter(0.5, yB, "B")
    bres = panel_B(P, yB, numbers)
    log("panel B drawn", True)
    yC = 152.5
    P.letter(0.5, yC, "C")
    cres = panel_C(P, yC, numbers)
    log("panel C drawn", True)
    yD = 186.5
    for xl, s in ((0.5, "D"), (62.5, "E"), (121.5, "F")):
        P.letter(xl, yD, s)
    panel_D(P, B_X0, yD + 2.0, 34.0, 33.0, numbers)
    panel_E(P, 78.0, yD + 2.0, 33.0, 33.0, numbers)
    panel_F(P, 136.0, yD + 2.0, B_X1 - 136.0, 33.0, numbers)
    log("panels D-F drawn", True)
    # numbers that only the legend uses
    br = pd.read_csv(f"{MAIN}/benchmark_real.tsv", sep="\t").set_index("item")
    st = pd.read_csv(f"{MAIN}/stats.tsv", sep="\t")
    t = load_elai()
    numbers += [("legend", "Inv4m (Inv4m chr4 172.9-188.1 Mb row)", br.loc["Inv4m (chr4:172.9-188.1 Mb)", "value"], "benchmark_real.tsv"),
                ("legend", "Inv1n (chr1 65.0-115.0 Mb row)", br.loc["Inv1n (chr1:65.0-115.0 Mb)", "value"], "benchmark_real.tsv"),
                ("legend", "ancestry tracts (FDR)", br.loc["HMM ancestry: donor-like posterior excess over decoy", "note"], "benchmark_real.tsv"),
                ("legend", "near-identity threshold (divergence)", st[st.test == "hmm_ancestry"].near_threshold.iloc[0], "stats.tsv"),
                ("legend", "ELAI B73 dosage > 1.8, fraction of called SNPs chr1-10 (computed here)",
                 f"{(t['B73.amp'] > 1.8).mean():.4f} (n = {len(t)})", "elai_summary.v5.tsv"),
                ("legend", "ZmPRR37a +-50 kb", br.loc["ZmPRR37a +-50 kb (expect mexicana)", "value"], "benchmark_real.tsv"),
                ("legend", "B73 ELAI mean ancestry", br.loc["B73 ELAI mean ancestry (dosage/2)", "value"], "benchmark_real.tsv")]
    bl = pd.read_csv(f"{MAIN}/blocks.tsv", sep="\t")
    for ga, gb, lo, hi in (("B73v5", "TIL01", 50e6, 120e6), ("TIL18", "TIL01", 50e6, 140e6), ("B73v5", "TIL18", 160e6, 200e6)):
        cc = "chr1" if hi <= 140e6 else "chr4"
        x = bl[(bl.genome_a == ga) & (bl.genome_b == gb) & (bl.sign < 0) & (bl.chrom_a == f"{ga}_{cc}") &
               (bl.chrom_b == f"{gb}_{cc}") & (bl.end_a > lo) & (bl.start_a < hi)]
        for r in x.itertuples():
            numbers.append(("A/legend", f"inverted block {ga}-{gb} {cc}", f"{ga} {r.start_a}-{r.end_a} / {gb} "
                            f"{r.start_b}-{r.end_b}; {r.n_anchor} anchors", "blocks.tsv"))
    el = load_elements()
    inv = el[(el.c == "chr1") & (el.mid >= INV1N_B73[0]) & (el.mid <= INV1N_B73[1])]
    vc = inv["class"].value_counts()
    don, sis = vc.reindex(DON).fillna(0).sum(), vc.reindex(SIS).fillna(0).sum()
    ti = t[(t.chrom == "chr1") & (t.pos >= INV1N_B73[0]) & (t.pos <= INV1N_B73[1])]
    inv_post = np.average(inv.post_ancestry_TIL18, weights=inv.len)
    inv_elai = ti["B73.amp"].mean() / 2
    numbers += [("legend", "Inv1n block (B73 chr1 60.95-108.99 Mb): donor-like share of informative elements (computed here)",
                 f"{don / (don + sis):.3f} ({int(don)} vs {int(sis)})", "elements.B73v5.tsv"),
                ("legend", "Inv1n block: posterior (length-weighted) / ELAI ancestry (computed here)",
                 f"{inv_post:.3f} / {inv_elai:.3f}", "elements.B73v5.tsv + elai_summary.v5.tsv")]
    # robustness: window and chromosome agreement without the Inv1n block (same formulas, computed here)
    e10 = el[el.c.notna()]
    rob = {}
    for win in (1_000_000, 10_000_000):
        w = windows(e10, t, win, "post_ancestry_TIL18", "len")
        ok = w.score.notna() & w.truth.notna()
        mid = (w.w + 0.5) * win
        keep = ok & ~((w.c == "chr1") & (mid >= INV1N_B73[0]) & (mid <= INV1N_B73[1]))
        rob[win] = spearmanr(w.score[keep], w.truth[keep]).correlation
        numbers.append(("legend", f"Spearman r posterior vs ELAI, {win / 1e6:g} Mb, without Inv1n windows (computed here)",
                        f"{rob[win]:.3f} (n = {int(keep.sum())})", "elements.B73v5.tsv + elai_summary.v5.tsv"))
    bc = pd.read_csv(f"{MAIN}/benchmark_chromosomes.tsv", sep="\t", index_col=0)
    nx = dict((r[1], r[2]) for r in numbers)
    px_, py_ = (float(v) for v in nx["chr1 without Inv1n block (B73 60.95-108.99 Mb): ELAI / posterior (computed here)"].split(" / "))
    bc.loc["chr1", ["ELAI_B73", "post_mean"]] = [px_, py_]
    rob["chrom"] = spearmanr(bc.ELAI_B73, bc.post_mean).correlation
    numbers.append(("legend", "Spearman per chromosome with chr1 recomputed without Inv1n (computed here)",
                    f"{rob['chrom']:.2f}", "benchmark_chromosomes.tsv + this script"))
    png = os.path.join(HERE, f"{STEM}.png")
    P.fig.savefig(png, dpi=300)
    log(f"wrote {png}")
    nm = dict((r[1], r[2]) for r in numbers)
    short, long_ = legends(numbers, ex, top, cres, don, sis, inv_post, inv_elai, rob)
    pdfp = os.path.join(HERE, f"{STEM}.pdf")
    with PdfPages(pdfp) as pdf:
        pdf.savefig(P.fig)
        legend_page(pdf, short)
        legend_page(pdf, long_)
    plt.close(P.fig)
    log(f"wrote {pdfp}")
    pd.DataFrame(numbers, columns=["panel", "item", "value", "source"]).to_csv(
        os.path.join(HERE, f"{STEM}_numbers.tsv"), sep="\t", index=False)
    log("done")


def legends(numbers, ex, top, cres, don, sis, inv_post, inv_elai, rob):
    N = {r[1]: r[2] for r in numbers}
    wt = window_tests().set_index(["score", "win"])
    r5 = wt.loc[("posterior", 5_000_000), "r"]
    r1, r10 = wt.loc[("posterior", 1_000_000), "r"], wt.loc[("posterior", 10_000_000), "r"]
    rc1, rc10 = wt.loc[("class_share", 1_000_000), "r"], wt.loc[("class_share", 10_000_000), "r"]
    nl = wt.xs("posterior").null_hi.max()
    T = triple_data()
    I = T["info"]
    pd_bm, pd_bp = T["pdist"][("B73v5", "TIL18")], T["pdist"][("B73v5", "TIL01")]
    vc = cres["vc"]
    age = I["B73v5"]["k2p_self"] / (2 * 3e-8) / 1e3
    short = [
        "**Transposon copies alone map where a genome carries ancestry from another population.** "
        "LTR-retrotransposon copies that maize shares nearly unchanged with *mexicana*, but not with *parviglumis*, "
        "trace where gene flow brought *mexicana* ancestry into maize at chromosome and megabase scale, and their "
        "order along the chromosomes exposes large inversions.",
        "**A**, All ten chromosomes of *parviglumis* TIL01, maize B73 and *mexicana* TIL18 at one scale, joined copy "
        "by copy. Copies shared nearly unchanged with *mexicana* cluster along the chromosomes, and the ancestry "
        "inferred from them follows the published SNP-based ancestry; twisted ribbons show inversions, Inv1n carried "
        "by *parviglumis* and Inv4m by *mexicana*.",
        "**B**, A typical 3-Mb stretch: a block of maize copies shared nearly unchanged with *mexicana* sits between "
        "blocks shared with *parviglumis*, and the inferred ancestry switches with it; the SNP-based ancestry rises "
        "only slightly there.",
        "**C**, One transposon that inserted before the subspecies split (the same target-site duplication in all "
        "three genomes): the maize and *mexicana* copies share mutations that the *parviglumis* copy lacks, and the "
        "element's other LTR shows that these mutations are new.",
        "**D–F**, Agreement with SNP-based ancestry for whole chromosomes, windows and single elements: the same "
        "three chromosomes are least *mexicana*-like by both methods, and the moderate agreement along chromosomes "
        "grows with window size.",
    ]
    long_ = [
        "**LTR-retrotransposon libraries alone paint the *mexicana* ancestry of maize B73 and recover its "
        "inversions.** Genomes: maize B73 (reference v5), *Zea mays* ssp. *parviglumis* TIL01 and ssp. *mexicana* "
        "TIL18, each reduced to its LTR-retrotransposon (LTR-RT) library (127,636, 137,847 and 124,641 elements); "
        "inference used no genome sequence, SNPs or outgroup. Orthologs: 1:1 copies matched between libraries and "
        "ordered into collinear blocks. Near-identical: a B73 copy closer to its ortholog than 95% of TIL01–TIL18 "
        f"ortholog pairs (divergence ≤ {float(N['near-identity threshold (divergence)']) * 100:.2f}%). Posterior: "
        "probability that a B73 element lies in *mexicana*-like ancestry, from a two-state hidden Markov model over "
        "the informative elements (near-identical to, or an insertion shared with, only one of the two). ELAI: "
        "published local ancestry of B73 from 845 maize lines (Yang et al. 2023, *Science*), *mexicana* dosage (0–2) "
        "halved, lifted to v5. Ages at 3 × 10^{−8} substitutions per site per year.",
        "**A**, Each chromosome of TIL01 (P), B73 (B) and TIL18 (M) at one scale. Gray lines join orthologous "
        f"LTR-RT pairs on homologous chromosomes ({N['B73-TIL01 1:1 LTR-RT orthologs drawn (homologous chromosomes)']:,} "
        f"B73–TIL01, {N['B73-TIL18 1:1 LTR-RT orthologs drawn (homologous chromosomes)']:,} B73–TIL18; pairs on "
        "unplaced scaffolds not drawn); dark lines "
        "lie in inverted blocks; black crosses outline inverted blocks ≥ 2 Mb. Ticks: B73 elements near-identical to "
        f"their TIL01 copy (blue, n = {N['B73 elements (chr1-10), class near_sister']:,}) or TIL18 copy (vermillion, "
        f"n = {N['B73 elements (chr1-10), class near_donor']:,}; the {N['B73 elements (chr1-10), class near_both']} "
        "near-identical to both are not ticked). Inside B73: posterior (black) and ELAI (green) in "
        f"5-Mb windows, 0 at the *parviglumis* side, 1 at the *mexicana* side (Spearman r = {r5:.2f}). Inv4m: "
        "B73–TIL18 inverted block at 172.85–187.84 Mb vs published 172.88–188.13 Mb (26 anchors). Inv1n "
        "(published ~65–115 Mb, B73 v2): TIL01 is inverted relative to B73 (B73 60.95–108.99 Mb, 20 anchors) and to "
        "TIL18 (TIL18 62.9–99.6 Mb, 21 anchors) while B73 and TIL18 are collinear, so TIL01 carries it; few "
        "orthologs are found inside it. Other inverted blocks are drawn but unnamed (no published coordinates). "
        "Box: region in B.",
        f"**B**, B73 chr6:141–144 Mb and the TIL01 and TIL18 stretches at the same scale (shifted by the median "
        "ortholog offset). Every element is a box drawn to size, stacked where they overlap; B73 elements colored by "
        "class, TIL elements dark gray when linked to a B73 element in view. Links join orthologs (colored when "
        "near-identical). Traces: posterior per element (black) and ELAI per SNP (green). Elements at "
        "142.39–142.83 Mb are near-identical to, or shared only with, TIL18 (posterior ≈ 1) and are flanked by "
        "elements shared with TIL01 (posterior ≈ 0); ELAI rises only modestly there "
        f"({N['TIL18-like block 142.38-142.84 Mb: ELAI mean dosage/2; mean posterior; n elements'].split(';')[0]} vs "
        f"{N['left 141.00-142.38 Mb: ELAI mean dosage/2; mean posterior; n elements'].split(';')[0]} and "
        f"{N['right 142.84-144.00 Mb: ELAI mean dosage/2; mean posterior; n elements'].split(';')[0].strip()} on "
        "either side). Most B73 elements are private (light gray).",
        f"**C**, The SIRE (Copia) element at B73 chr6:{I['B73v5']['start']:,}–{I['B73v5']['end']:,} and its TIL18 "
        "and TIL01 orthologs, re-extracted from the assemblies and aligned (MAFFT G-INS-i). The same 5-bp "
        "target-site duplication (TSD, GCTTA) and TG…CA ends in all three show one insertion; its LTRs differ by "
        f"K2P {I['B73v5']['k2p_self']:.4f}/{I['TIL18']['k2p_self']:.4f}/{I['TIL01']['k2p_self']:.4f} (B73/TIL18/TIL01, "
        f"within sampling error of the annotation; ~{age:.0f} kyr), older than the subspecies split. Ticks: substitutions relative "
        f"to the B73 copy ({pd_bm[1]} in TIL18, {pd_bp[1]} in TIL01, of ~{pd_bm[2]:,} sites). In the LTRs, the "
        "element's other LTR gives the state at insertion: at "
        f"{vc.get('ABBA', 0)} sites B73 and TIL18 share the new base and TIL01 keeps the old one (vermillion), at "
        f"{vc.get('BABA', 0) + vc.get('BBAA', 0)} sites TIL01 shares a new base with either, and "
        f"{vc.get('TIL01', 0)} new bases are TIL01's alone (blue in the stretch; {vc.get('B73v5', 0) + vc.get('TIL18', 0)} "
        "are B73's or TIL18's alone). The stretch shows the aligned 3′ "
        "LTRs with the 5′ LTR (identical in all three there) as outgroup.",
        "**D**, Per chromosome, length-weighted mean posterior vs ELAI mean ancestry. Chromosomes 5, 8 and 9, "
        "depleted of *mexicana* ancestry in Yang et al., are the three lowest by both (filled; shaded corner); an "
        f"exact match has p = 1/120; Spearman ρ = 0.64 (n = 10). Gray: chromosome 1 without the Inv1n block "
        "(computed here).",
        "**E**, Spearman correlation between window means and ELAI by window size, for the posterior (black) and "
        "the model-free share of *mexicana*-like among informative elements (open squares; "
        f"r = {rc1:.2f} at 1 Mb, {rc10:.2f} at 10 Mb). Band: 95% of 1,000 circular shifts of the posterior within "
        f"each chromosome (upper bound ≤ {nl:.2f}); shifts keep each chromosome's mean, so this null lies above 0. "
        f"p = 0.001 at every size, the floor of the test (r = {r1:.2f} at 1 Mb, {r10:.2f} at 10 Mb).",
        "**F**, Posterior of single elements whose ±20-kb surroundings carry ELAI *mexicana* dosage ≥ 1 or ≤ 0.2 "
        "(≥ 3 SNPs): AUROC 0.72 (0.78 for dosage ≥ 1.5, n = 781). Dashed: all such elements pooled, what both "
        "curves would show if ELAI carried no information.",
        "**Exceptions and caveats.** Inside Inv1n (B73 chr1 61–109 Mb) TIL01 carries the divergent inverted "
        "arrangement, so B73 shares insertions there almost only with TIL18 "
        f"({don / (don + sis) * 100:.0f}% of informative elements *mexicana*-like, posterior {inv_post:.2f}); ELAI is "
        f"also elevated ({inv_elai:.2f}, twice the genome mean of 0.17), so this agreement may reflect the inversion "
        "polymorphism rather than gene flow. It lifts chromosome 1 in D (without it ρ = "
        f"{rob['chrom']:.2f}) and adds a little to E (without its windows r = {rob[1_000_000]:.2f} at 1 Mb, "
        f"{rob[10_000_000]:.2f} at 10 Mb). Near-identity also arises from "
        "incomplete lineage sorting and from recent sharing with this particular TIL18 genome. Individual tracts are "
        "not resolved: no ancestry tract passes the target-decoy false discovery rate (1,686 tracts vs 1,597 decoys), "
        "and ZmPRR37a is missed (5 of 6 elements within 50 kb are private to B73). ELAI is itself diffuse (B73 "
        f"dosage > 1.8 at {float(N['ELAI B73 dosage > 1.8, fraction of called SNPs chr1-10 (computed here)'].split()[0]) * 100:.2f}% "
        "of called SNPs).",
        f"**Region in B.** Of {ex['n_windows']} non-overlapping 3-Mb windows with ≥ 30 informative elements, "
        f"{ex['n_hi']} have ELAI ancestry above the genome mean; {int((~ex['cand'].inv).sum())} of these lie in the "
        "middle 50% of both posterior and ELAI and outside inverted blocks; B is the one closest to both medians "
        f"(posterior {top.score:.2f}, ELAI {top.elai:.2f}). Of the window's five elements with orthologs in all three "
        "genomes (one near-identical to TIL18, one to TIL01, three older), C shows the one near-identical to TIL18; "
        "it passed every structural check (TSD, ends, LTR divergence; length 8,874 bp vs family median 9,304 bp).",
        f"Analysis: asc-oulab:/data2/chris/maize_introgression/benchmark · Script: {os.path.abspath(__file__)} · {DATE}",
    ]
    return short, long_


PAGE_H = 233.0

if __name__ == "__main__":
    main()
