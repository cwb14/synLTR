"""Cost sample of the identity layer on main3 (read-only view): aligns a seeded random sample of the layer's
loci with the module's own workers, then fits the split on the sample's S-D pairs. Usage:
bench_main3.py VIEW N_LOCI THREADS [--fits]"""
import logging, math, sys, time
from pathlib import Path
import numpy as np
from ltrpav.samples import read_samples
from ltrpav.analysis.catalog import load_catalog, STATE_CODE
from ltrpav.analysis.relations import pav_distances, discover
from ltrpav.analysis.stats import block_size, u95
from ltrpav.analysis.trio import Trio, _patterns
from ltrpav.analysis.paint import RD, classes
from ltrpav.analysis import identity as idm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
view, n_sample, threads = Path(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
fits = "--fits" in sys.argv
t = time.monotonic()
cat = load_catalog(view, read_samples(view / "samples.tsv"), view / "samples.tsv")
print(f"catalog: {len(cat.lid):,} loci in {time.monotonic() - t:.1f} s", flush=True)
trio = Trio("B73", "TIL01", "TIL18", True)
R, S, D = trio.R, trio.S, trio.D
dist = pav_distances(cat)[0]
size = block_size(cat)
gd = cat.g(D)
c = discover(cat, R, S, D, dist, "E")
partners = [y for y in cat.labels if y in (R, S)]
pmask = {y: cat.member[:, gd] & (cat.proj[D][:, cat.g(y)] == STATE_CODE["P"]) for y in partners}
idx, cls = classes(cat, R, S, D)
rd_class = np.zeros(len(cat.lid), dtype=bool); rd_class[idx[cls == RD]] = True
reads = c.rows | rd_class
for m in pmask.values():
    reads = reads | m
loci = np.flatnonzero(reads)
copies = [g for g in cat.labels if g in (R, S, D) and cat.annotated[g]]
t = time.monotonic()
elements = {g: idm._elements(cat, g, loci) for g in copies}
jobs = [idm._job(cat, int(i), copies, elements, pmask, D) for i in loci]
print(f"plan: {len(loci):,} loci ({int(np.count_nonzero(np.logical_or.reduce(list(pmask.values())))):,} pair loci, "
      f"{int(c.rows.sum()):,} counted, {int(rd_class.sum()):,} RD class); "
      f"{sum(len(j[1][5]) for j in jobs if j[1] is not None):,} pairs "
      f"({', '.join(f'{y} {int(m.sum()):,}' for y, m in pmask.items())}); {sum(len(j[0]) for j in jobs):,} copies; "
      f"built in {time.monotonic() - t:.1f} s", flush=True)
rng = np.random.default_rng(1)
pick = np.sort(rng.choice(len(loci), size=min(n_sample, len(loci)), replace=False))
sl, sj = loci[pick], [jobs[j] for j in pick]
n_pairs = sum(len(j[1][5]) for j in sj if j[1] is not None)
n_copies = sum(len(j[0]) for j in sj)
t = time.monotonic()
res = idm._align_all(cat, sj, threads)
dt = time.monotonic() - t
print(f"sample: {len(sl):,} loci, {n_pairs:,} pairs, {n_copies:,} copies aligned in {dt:.1f} s at {threads} threads: "
      f"{n_pairs / dt:.2f} pairs/s, {len(sl) / dt:.2f} loci/s, {(n_pairs + n_copies) / dt:.2f} alignments/s "
      f"(pairs + self)", flush=True)
full_pairs = sum(len(j[1][5]) for j in jobs if j[1] is not None)
full_copies = sum(len(j[0]) for j in jobs)
rate = (n_pairs + n_copies) / dt
print(f"extrapolated full trio: {(full_pairs + full_copies) / rate / 60:.1f} min at {threads} threads "
      f"(~{(full_pairs + full_copies) / rate / 60 * threads / 32:.1f} min at 32 if linear)", flush=True)
tab = idm._Tables(cat, sl, sj, res, D)
for y in partners:
    v = tab.pairs.get(y, [])
    st = np.array([s for _, s, _ in v]); dd = np.array([d for _, _, d in v])
    print(f"{y}-{D} pairs: {len(v)} aligned, sites median {np.median(st) if len(st) else 0:.0f}, "
          f">= {idm.IDENT_MIN_SITES}: {int((st >= idm.IDENT_MIN_SITES).sum())}, 0 sites: {int((st == 0).sum())}, "
          f"median div (>=200) {np.median(dd[st >= 200] / st[st >= 200]) if (st >= 200).any() else float('nan'):.5f}")
print(f"orientation inferred {tab.n_inferred}, skipped {tab.n_skipped}; self rows {len(tab.self_)}; "
      f"short {dict(tab.short)}", flush=True)
if fits:
    _, k, n = tab.fit_pairs(S)
    t = time.monotonic(); s, m = idm.fit_split(k, n); t1 = time.monotonic() - t
    print(f"sample split ({len(n)} {S}-{D} pairs): s = {s:.6f}, m = {m:.6f} ({t1:.2f} s per fit)", flush=True)
    t = time.monotonic(); w, mg, s_mix, m_mix, mh, nll = idm.fit_mix(k, n, s, m); t2 = time.monotonic() - t
    aic_iso = 2 * idm.split_nll(np.log([s, m]), k, n) + 4
    print(f"sample mixture: w {w.round(4).tolist()}, m_flow {mg:.5f}, s_mix {s_mix:.6f}, m_mix {m_mix:.6f}, "
          f"m_tail {mh:.4f}; AIC {2 * nll + 12:.1f} vs {aic_iso:.1f} ({t2:.1f} s)", flush=True)
    _, kr, nr = tab.fit_pairs(R)
    print(f"sample below split: {R}-{D} {np.mean(kr / nr < s):.4f} of {len(nr)}, {S}-{D} {np.mean(k / n < s):.4f} "
          f"of {len(n)}", flush=True)
    a, b = _patterns(cat, c.gstar, R, S)
    has, bound = tab.self_u95(D, len(cat.lid))
    rd, sd = c.rows & a & has, c.rows & b & has
    print(f"sample young (u95 < s): {R}+{D} {int((rd & (bound < s)).sum())} of {int(rd.sum())}, "
          f"{S}+{D} {int((sd & (bound < s)).sum())} of {int(sd.sum())}; sites_needed {u95(np.array([0]), np.array([1.0]))[0] / s:,.0f}",
          flush=True)
    for x in idm.CDF_POINTS:
        print(f"  cdf {x:g}: obs {np.mean(k / n <= x):.4f} fit {idm.pred_cdf(x, n, s, m):.4f}")
    if "--scale" in sys.argv:
        full = int(round(23_796 * len(n) / max(1, sum(1 for j in sj if j[1] is not None and any(y[0] == S for y in j[1][5])))))
        reps = -(-full // len(n))
        kk, nn = np.tile(k, reps)[:full], np.tile(n, reps)[:full]
        t = time.monotonic(); s2, m2 = idm.fit_split(kk, nn); t3 = time.monotonic() - t
        t = time.monotonic(); idm.fit_split(kk[: int(full * 0.997)], nn[: int(full * 0.997)], start=(s2, m2)); t4 = time.monotonic() - t
        print(f"full-scale fit timing on {full:,} tiled S-D pairs: fit {t3:.1f} s, one jackknife refit {t4:.2f} s "
              f"(x ~425 blocks of 5 Mb = {425 * t4 / 60:.1f} min serial)", flush=True)
        t = time.monotonic(); idm.fit_mix(kk, nn, s2, m2); t5 = time.monotonic() - t
        print(f"full-scale fit_mix: {t5:.1f} s", flush=True)
