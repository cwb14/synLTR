# Task 9 report: sequence-identity layer (DESIGN 7.5)

Status: DONE_WITH_CONCERNS (code complete and tested; the concerns are for Task 10 and Task 12)
Commit: 9a3b854 "Add optional sequence-identity layer with rate-free split" (BASE 512e344)
Files: src/ltrpav/analysis/identity.py (new), tests/test_identity.py (new), src/ltrpav/analysis/constants.py
(MG_MAX, IDENT_MIN_SITES appended verbatim). No engine module touched.

## Tests
- tests/test_identity.py: 13 tests. The brief's 7 are verbatim, except one ruff-only rename in the slow test
  (unused unpacked names prefixed `_`, RUF059). I added 6: ambiguous columns skipped, plus overlapping LTR intervals
  counted once; split_nll bit-identical to LTRmix's nll and bounded as m -> 0; skip without D's annotation;
  write_identity format; the young/below-split path end to end, including a reverse-strand (b_strand "-") pair;
  a worker error surfacing as one RuntimeError.
- Suite: `python -m pytest -W error -m "not slow"`: 1037 passed, 2 deselected (154 s). ruff: clean.
- Slow test, run once (Step 4): `python -m pytest -W error tests/test_identity.py`: 12 passed in 288 s
  (test_fit_mix_guards_against_gene_flow 272 s). Its values from a separate print run: s_iso 0.001151,
  w = 0.9114 / 0.0419 / 0.0467, s_mix 0.002095, m_flow 0.000502. The re-review had w_flow 0.042 and s 0.00210
  against 0.00115, so the port reproduces LTRmix.
- The Step-4 run had 12 tests; the 13th (the worker error, 2 s) was added after it and passes in the suite.

## What it does (as the brief; details in the module docstring)
- The loci it reads: the pair loci (D's members with D's own call into R or S equal to P), the D_pav counted
  rows (`discover(..., "E")`), and R's RD painting class (`paint.classes`, reused).
- Self rows: every annotated copy of R, S or D at those loci whose LTRs align over >= MIN_SEG sites.
- Pair rows: one per pair locus and partner. x = D's element, y = the partner's site from D's own call
  +- WINDOW_PAD, aligned with `align_window(x, y, "asm20", DEFAULT_BACKEND)`. y is reverse-complemented when
  pstrand differs from D's; `orient` is used when either strand is unknown.
- The split is LTRmix's isolation fit (Nelder-Mead on the logs) with a delete-one-block jackknife SE on D's
  blocks, each refit from the full fit, under trio.py's testability rule. Beside it: the 18-start `fit_mix`
  guard, the AICs, and the five CDF points.
- On the counted rows: the young counts, sites_needed = u95(0, 1) / s, and the fractions below s.
- Workers are a fork ProcessPoolExecutor over chunks (8 per worker), each opening its own Fasta and dying with
  the parent (`genotype._die_with_parent`). Results come back in locus order; with one thread it runs in-process.

## Decisions and deviations (the most defensible choice; each one recorded)
1. **Numerical fix to LTRmix's likelihood. This is the one real deviation.**
   - LTRmix clamps Q at 1e-300. As m -> 0, s/m grows while log Q stays stuck at the clamp, so the likelihood
     grows without bound.
   - Shown on 6 pairs with k = 1, n = 800 (task-9-probe/proto_nll.py): LTRmix's verbatim `fit` ends at
     m = 6e-310 with nll = -inf. Under -W error it raises (RuntimeWarning: divide by zero).
   - The brief's own end-to-end toy (6 identical S-D pairs) is exactly such data.
   - The fix: where Q < 1e-280, use the exact finite sum Q(k+1, x) = e^-x sum_{j<=k} x^j / j!, computed in log
     space with s/m cancelled. The likelihood then tends to the Poisson limit.
   - Where Q >= 1e-280 it is LTRmix's code, operation for operation: the test asserts split_nll == LTRmix's nll
     exactly at 3 parameter points.
   - Checked against 60-digit decimal arithmetic (task-9-probe/check_tail.py): relative error <= 4e-15 in 8
     cases, both branches.
   - Both Nelder-Mead calls run under np.errstate, since +inf vertices make scipy's own convergence check warn.
2. **Bases compared.** Only A, C, G and T are compared. The brief names N; other IUPAC codes are skipped too,
   since an R facing an A is no certain substitution.
3. **`orient` on a tie** (both strands equally aligned, >= MIN_SEG) returns 0: no strand is inferred, and the
   pair is counted as skipped.
4. **s and m get se only, z nan.** Both are positive by construction, so a z would test nothing anyone asked.
5. **D_young has a jackknife se and z (beyond the brief).** It uses D's blocks, s held at its estimate, under
   trio.py's testability rule. Every other D in the package has one, and a bare D invites over-reading
   (+1 from 3 vs 0 loci). It is nan when a class is empty.
6. **Scopes.** identity_split uses "S;D". identity_young and identity_below_split use the trio scope.
   Statistic names are cdf_obs_<x:g> (cdf_obs_0, cdf_obs_0.001, ...).
7. **loci declarations.** Split rows: "disc=D;P=S;sites>=200". Below-split rows: "disc=D;P=R|S;sites>=200".
   Young rows: the D_pav loci string plus ";self=D".
8. **identity.tsv columns.**
   - div is diffs/sites on self rows too.
   - u95 is "." on pair rows.
   - young is 1/0 only on D's self rows at counted R+D/S+D loci, "." elsewhere.
   - Rows go per locus (catalog order): self rows (sheet order), then pair rows (sheet order).
9. **One error line.** A worker's error, or a dead worker, becomes one RuntimeError ("identity layer: ..."),
   which cli._HANDLED turns into a single error line.
10. **Reading s_mix.** The mixture's findings line states what s_mix means: the shift of the isolation
    component alone, correcting for gene flow only through w_flow, and the tail is an upper tail only when its
    mean exceeds s_mix + m_mix. The reason is concern 1 below. It is a wording change only: no rule or
    threshold was added.

## main3 cost sample
Read-only through a symlinked view, <= 16 threads, under timeout 15m, nothing written in main3. Host load was
~120-130 throughout, so timings carry noise.
- **The full trio (B73, TIL01; TIL18)** reads 44,695 loci: 35,079 pair loci, 14,067 counted, 2,699 RD
  class. That is 50,836 pairs (B73 27,040, TIL01 23,796) and 86,972 self alignments.
- **Sample of 3,000 loci (seed 1), 16 threads:** 3,338 pairs + 5,791 self alignments in 85.8 s.
  - **38.9 pairs/s**, 106 alignments/s counting both kinds.
  - Full trio: about 22 min at 16 threads, about 11 min at 32 if it scales linearly.
- **All 23,796 TIL01-TIL18 pairs, pairs only, 16 threads:** 255 s, **93 pairs/s**.
- **Fits at full scale:** fit + 509-block jackknife + 18-start fit_mix + CDF = 273 s, serial. The jackknife
  could use the pool if needed.
- **For Task 12:** about 22 min of alignment at 16 threads (or ~11 at 32) plus ~5 min of fits per trio.
  Launch it detached.

## main3 identity numbers (preliminary; Task 12 runs the full layer)
- **The split, on all 23,796 TIL01-TIL18 pairs**
  - 23,739 pairs have >= 200 LTR sites; median 1,706 sites, median div 0.01257.
  - 3,167 pairs (13%) had an unknown strand and all were oriented by the alignment; none skipped. LTRquest
    leaves 12% of elements' strand ".", e.g. 14,724 of TIL18's.
  - **s = 0.000747 ± 0.0000945** (509 blocks of 5 Mb) and m = 0.01546 ± 0.00040. LTRmix's isolation fit is
    0.048% (bootstrap 0.034-0.063%).
  - Mixture: weights 0.534 / **0.0000** / 0.466, s_mix = 0.00248, m_mix 0.01484, tail mean 0.01493, AIC
    205,980.8 against 205,990.0. LTRmix's mixture: 0.070%.
  - CDF check, observed / fitted: 0: 0.0231/0.0265; 0.001: 0.0461/0.0493; 0.002: 0.0853/0.0985;
    0.003: 0.1290/0.1525; 0.005: 0.2149/0.2556.
  - frac_SD_below 0.0328.
- **Sample of 3,000 loci**
  - frac_RD_below 0.0835 (1,796 pairs), frac_SD_below 0.0358 (1,535). LTRmix: 7.6% against 3.5%.
  - Young: 0 of 97 R+D and 0 of 54 S+D. sites_needed is 4,394 at the sample's s, and 4,012 at the full s.
- **Validation (2,000 loci, seed 2): realigned LTR-LTR div against the annotation's K2P.**
  - 3,708 copies; Pearson 0.967, Spearman 0.989; median |div - K2P| 0.0011.
  - Identical LTRs: 53 by realignment, 52 by K2P, 50 shared.

## Concerns
1. **s_mix on main3 is not a gene-flow correction.**
   - What the fit did: the gene-flow weight is 0. The "upper tail" takes 47% of pairs at mean 0.0149, below
     the isolation component's 0.0173. The mixture thus splits the pairs into a shifted group and an unshifted
     one, and s_mix (0.25%) is the first group's shift only.
   - What to do with it: Task 12 item 13 (s_mix against LTRmix's 0.070%) should read it this way. The
     findings line now states both facts.
   - What I did not do: change the model. It is LTRmix's, and changing it after seeing main3 would be tuning.
2. **The isolation s is above LTRmix's.** Ours is 0.075%; ± 1.96 se gives 0.056-0.093%, which overlaps
   LTRmix's interval (0.034-0.063%) only narrowly. Candidate causes, not investigated:
   - the pair sets: D's own P calls here, LTRmix's ortholog table there;
   - the alignment: the whole element +- 500 bp with LASTZ asm20 here, LTRmix's LTR-only alignment there.
3. **Task 10's stats stage key with --identity** should hold the lastz version
   (`localign.backend_version(DEFAULT_BACKEND)`, a binary, not a module) as a parameter. The fingerprint's
   import closure must also include ltrpav.localign, which identity imports.
4. **Private helpers imported.** trio's _blocks, _patterns, _why, _guard, _fmt and NOT_TESTABLE (the deferred
   public-helper-module minor). Also the engine-private genotype._die_with_parent, reused rather than
   reimplementing the orphan-worker guard.
5. **Decoy tracts' youngest_u95.** The layer does not read S's decoy RD loci as such, so a decoy tract gets a
   youngest_u95 only where its RD loci coincide with layer loci. Target and decoy youngest_u95 are therefore not
   comparable. q-values do not use it.
6. **LTRmix's own rate_free_split.py** has the runaway in its `nll` on homogeneous or small pair sets.
   LTRmix's main3 fits are unaffected in practice: their optimum is far from the clamp.

## Commands
Scripts are kept in .superpowers/sdd/2026-11-11-plan2-analyses/task-9-probe/ (git-ignored). The view lives in
the session scratchpad: symlinks to main3's loci.tsv, manifest.json, qc.tsv, pairs/ and work/elements; a copy of
samples.tsv (absolute FASTA paths); real work/ and work/fai.
```
export NUMPY_MADVISE_HUGEPAGE=0 PATH=/home/chris/bin/mambaforge/envs/ltrpav/bin:$PATH
timeout 15m python bench_main3.py <view> 3000 16 --fits --scale        # cost sample, sample fits, fit timings
setsid -f nohup env ... timeout 15m python split_main3.py <view> 16 > split_main3.log 2>&1 < /dev/null   # all S-D pairs
setsid -f nohup env ... timeout 15m python selfk_main3.py <view> 2000 16 > selfk_main3.log 2>&1 < /dev/null  # self div vs K2P
python check_tail.py; python proto_nll.py                               # tail vs 60-digit decimals; LTRmix runaway
python -m pytest -W error tests/test_identity.py                       # Step 4, slow test included
```

## Follow-up: controller rulings on the review (commit 28faca2)
Commit: 28faca2 "Pad the donor copy, orient by the call's strand; NA for empty mixture components".
Files: identity.py, catalog.py (pbstrand), constants.py (MIX_MIN_PAIRS), test_identity.py, test_catalog.py.

- **M1, padded donor copy.**
  - x is now D's element +- WINDOW_PAD, the engine's window shape, so D's flanks anchor the chain on the
    site's diagonal.
  - LTR intervals are shifted by the left pad actually fetched, which is clipped at a sequence start.
  - Substitutions are still counted in the LTR columns only.
  - Test: test_job_pads_the_donor_copy, including an element 200 bp from a sequence start (pad 200).
- **M2, orientation from the call's b_strand.**
  - The catalog now keeps each call's b_strand, `Catalog.pbstrand`, read in the same pass as pstrand
    (pstrand = own strand x pbstrand). It is +1 in A's own column and 0 for a call without a site.
  - The layer orients every pair by it. `orient` is no longer used by the layer; it stays as the brief's public
    utility, and its docstring says so.
  - A pair without a usable b_strand is skipped, counted and reported in one WARNING line.
  - Tests: test_identity_counts_a_call_without_b_strand (a pair file edited to b_strand "."); test_catalog
    pins pbstrand where S's strand is "." and its window is reversed.
  - The brief's end-to-end test changes with the ruling. Its "." S pair at locus 7 is now aligned on its
    call's b_strand ("+"): an unrelated site, so 0 LTR sites and div ".". No pair is skipped.
- **M3, strand tests.** test_identity_pair_strands covers three cases; reversed windows carry their flanks:

  | D strand | partner strand | b_strand | pstrand | counts |
  |---|---|---|---|---|
  | - | - | + | -1 | (800, 2) |
  | - | + | - | +1 | (800, 3) |
  | . | reversed window | - | 0 | (800, 4) |

  - Mutation check: reading pstrand as the relative strand fails this test and no other.
  - Removing the padding fails the M1 test.
- **M5, empty mixture components.**
  - The bound: `MIX_MIN_PAIRS = 1.0` in analysis/constants.py. The weights are a softmax of free logits, so
    their lower bound, 0, is approached but never reached. A component with weight x pairs < 1 is at that
    bound: s_mix and m_mix, m_flow or m_tail are written NA ("." in stats.tsv) with a note, and the findings
    line names the empty components. The weights themselves are kept.
  - Test test_mix_params_empty_components covers: the review's case (w_tail 0.0, m_tail 6.4e284); main3's
    w_flow 5e-15; an empty isolation component; the one-pair boundary. The young toy's rows are covered too
    (gene flow and tail NA).
- **M4:** no change (informational).

Tests:
- test_identity.py: 17 tests, of which 16 are fast.
- Suite (`-W error -m "not slow"`): 1041 passed, 2 deselected (159 s).
- Slow test, run once: passed (263 s).
- ruff: clean.

main3 rerun: all 23,796 TIL01-TIL18 pairs through the layer's own job and worker code, 16 threads,
read-only view, timeout 15m (task-9-probe/rerun_main3.py).
- **Throughput:** no pair lacks b_strand. Aligned in 225 s, **105.6 pairs/s**. Before: 93.2, which
  included the second alignment `orient` ran for the 13% "." pairs. Host load ~120 both times.
- **The split:**
  - 23,779 pairs with >= 200 LTR sites (before 23,739).
  - **s = 0.0007422 ± 0.0000939** (510 blocks; before 0.000747 ± 0.0000945).
  - **m = 0.01564 ± 0.00041** (before 0.01546).
  - frac_SD_below 0.0323 (before 0.0328).
  - CDF check, observed / fitted: 0: 0.0231/0.0265; 0.001: 0.0459/0.0491; 0.002: 0.0849/0.0978;
    0.003: 0.1287/0.1512; 0.005: 0.2139/0.2534.
- **Mixture:**
  - Weights 0.941 / 2.5e-14 / 0.059. The gene-flow component is empty, so m_flow is NA.
  - s_mix 0.000822, m_mix 0.01561, tail mean 0.01561. The tail mean is not above s_mix + m_mix = 0.01643.
  - AIC 206,817.2 against 206,813.1: the mixture no longer fits better than isolation.
  - Before the fix it was 0.534 / 0 / 0.466 with s_mix 0.00248 and ΔAIC -9.2. Small changes in the pair counts
    moved the mixture's optimum this far, so s_mix is fragile on main3. Task 12 should read it that way.
- **The reviewer's 96 slid pairs** (placement.tsv):
  - **87 of 96 changed** (sites, diffs).
  - By the reviewer's own placement metric, **13 of 96** still put the slid LTR more than 30 bp off its site
    end, so 83 are resolved.
  - Median div: before 0.0277, after 0.0225, minimap2 0.0081.
  - Within 0.005 of minimap2's div: 47 of 96 (before 30). 84 of the 96 are "." elements, M4's class.
- **Other pairs:** 3,813 of the other 23,700 changed counts. Not characterized pair by pair; s moved by 0.6%.

Commands:
```
setsid -f nohup env NUMPY_MADVISE_HUGEPAGE=0 PATH=.../envs/ltrpav/bin:$PATH timeout 15m python rerun_main3.py <view> 16 \
  /data2/chris/maize_introgression/benchmark_pav/plan2_reviews/task9/placement.tsv > rerun_main3.log 2>&1 < /dev/null
python -m pytest -W error -m "not slow"; python -m pytest -W error tests/test_identity.py -m slow; ruff check .
```
