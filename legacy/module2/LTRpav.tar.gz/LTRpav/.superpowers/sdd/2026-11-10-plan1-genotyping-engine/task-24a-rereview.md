# Task 24 phase A: re-review of fix round 1 (file-based)

D = /data2/chris/maize_introgression/benchmark_pav/bakeoff. Reviewed from the current files. Scratch: D/rereview24a/.
Counts: 10 ADDRESSED, 0 PARTIAL, 0 NOT ADDRESSED (M6 not fixed by design; its memory rule is recorded).

## Verdicts
- I1 ADDRESSED. bakeoff.py:106-132 (`check_rundir` refuses anything not strictly inside runs/ or chr10/runs/;
  `fresh_rundir` deletes and recreates), :288 (run_measured always starts from it), :494-ish `measure` CLI refuses
  with exit 2 before anything runs and `--skip-done` skips only on status.json. 04_chr10.sh uses `--seed` instead of
  the old manual rm/cp (lines 49-55). The seeds are validated before deletion (:120-124).
- M1 ADDRESSED. bakeoff.py:246-254: ok on 0; timeout on 124, or on 137 with wall >= limit; killed on other signal
  deaths (code < 0, > 128, or GNU time "terminated by signal", parsed at :231); else failed. status.json records signal.
- M2 ADDRESSED, with a scoped deviation from the literal ruling. Markers are deleted at start (02_run_sims.py:84-85;
  04_chr10.sh:37). The live-run check is scoped to the driver's own root plus a second copy of the driver
  (bakeoff.py:143-171; 02:39-43; 04:59-62); the 64-thread gate is unscoped (04:100). The ruling said "no run_variant.py
  process exists" anywhere; the scoping keeps the intended 32+32 concurrency and covers the hazard (orphan writing into a
  directory about to be cleaned). The controller should confirm the deviation. See New problems (Minor).
- M3 ADDRESSED. 02_run_sims.py:77 `choices=SIMS`; the only rmtree left is the guarded `fresh_rundir` (bakeoff.py:125-126).
- M4, M7 ADDRESSED. memo_bakeoff.md:50-51.
- M5 ADDRESSED. PARAMS.md: section 4 line 95 (Y = 40 under this scoring, `--show=defaults`); section 9.5 lines 195-205
  (1.5-1.7x on the genotype stage under the 2,000-window default, 1.3x at 50 chunks; controller's adaptive-chunking
  ruling; patch removed); section 10 lines 212-213 (every 2 s, intervals 2.1-2.9 s).
- M6 (not fixed, by ruling) CONFIRMED RECORDED. PARAMS.md:214-215: phase B judges memory on max(max_rss_kb,
  peak_tree_pss_kb) of the chr10 runs, no weight on sims' tree peaks.
- M8 ADDRESSED. `role` column in TABLE_COLUMNS (bakeoff.py:74); YARDSTICKS (:73); `--yardstick awpaf_yardstick`
  (04_chr10.sh:78); `name_role` (:~332) shows the old phase-A run as awpaf_yardstick/yardstick (chr10/runs.tsv checked:
  mm2, mm2_lastz, mm2_wfa candidate; awpaf_yardstick yardstick). The old run's directory was not renamed or rerun, as asked.
  Table `rundir` for the old run still reads chr10/runs/awpaf (the new runs go to chr10/runs/awpaf_yardstick), harmless.
- M9 ADDRESSED. Seqid check: 06_anchorwave_readout.py:251-253 (A and B seqid per direction). Cache stamp: :399-401
  (MAF path/size/mtime/sha256 plus the script's sha256), compared at :409.
- Item 10 (CHUNK_WINDOWS patch) ADDRESSED. grep for chunk-windows/CHUNK_WINDOWS in *.py *.sh finds nothing;
  `progress()` (bakeoff.py:257-280) no longer assumes a chunk size.
- Item 11 complied by report (no ltrpav import in its probes); not re-verified beyond the report.

## Addendum order check: PASS
04_chr10.sh: read-out (:69-75), awpaf_yardstick (:78), mm2 (:83), mm2_lastz (:84), then `routes mm2_N50
flank-mm2_2k flank-mm2_5k flank-mm2_10k flank-mm2_20k flank-blast_10k` (:85), mm2_wfa (:86), fastga hybrid (:87),
then the 64-thread mm2 gated on runs/batch.exit (:99-103). Timeouts (2h/45m/2h), threads (32/32/64) and the variants are
unchanged; `--anchor "${v%%_*}"` still yields mm2, flank-mm2, flank-blast, fastga, hybrid. `bash -n` passes;
py_compile passes on the five Python files I tried (it wrote bytecode into D/__pycache__; harmless).

## Read-out real test: PASS
Copy D/rereview24a/06_scratch.py (only change: the FASTA-index cache dir moved to the scratch outdir, line 407; also
passed --maf explicitly because HERE changed). Output only in D/rereview24a/{paf,ro}. Inputs read from chr10/ read-only.
- Completes, exit 0, 29.3 s wall (the MAF-to-PAF regeneration included, 8.5 s; each direction ~8-9 s), max RSS 2.2 GB,
  1 thread. Log: D/rereview24a/ro.log, ro.time.txt.
- B73v5 -> TIL18: 9064 calls: P 2217, S 106, T 622, E 1621, D 1914, O 2132, G 3, U 449 (12875 netted blocks, 3771
  windows, 3560 anchored). Identical to the stock read-out.
- TIL18 -> B73v5: 8319 calls: P 2193, S 94, T 601, E 1419, D 1519, O 1954, G 7, U 532 (12880 blocks, 3584/3311
  windows). Identical to the stock read-out.
- The calls and windows files are byte-identical (zcat | cmp) to chr10/anchorwave_readout/ for both directions. No
  difference to explain: the syntenic net kept 12875/12880 pieces, 0 dropped as out of place, 0 inversions, because
  AnchorWave's alignment is collinear and the stock net already kept the same pieces. The runtime path (anchor_pair +
  PafRoute, seqid assert, new cache stamp) therefore works, and the read-out result is unchanged by the new net.

## New problems
Critical: none. Important: none.
Minor:
1. A refused start still clobbers markers. 02_run_sims.py:84-85 and 04_chr10.sh:37 delete batch.done/batch.exit before
   the live check, and on refusal 04's EXIT trap (:38) writes batch.exit = 1 and 02's `finally` writes it too. An
   accidental second launch while a real batch runs deletes that batch's batch.exit (and later overwrites it with 1),
   which could release 04's 64-thread wait (:99) early. Move the check before the deletion, or skip the marker write
   when refusing.
2. The 64-thread gate (04:99-100) has no `--driver 02_run_sims.py`; the first loop's `pgrep -f 'bakeoff/02_run_sims.py'`
   matches the documented full-path launch, but a relative-path launch would be missed, and the idle test could then pass
   in the short gap between two sims runs. Low probability; `idle --quiet --driver 02_run_sims.py` closes it.

## Out-of-scope observations
- The read-out's per-direction "windows_ok" and calls match the stock run exactly, so after the engine's net change the
  paf: yardstick run itself (mappy windows) is the real test of the new net on the same input.
- chr10/work_fai does not exist; the original read-out writes its FASTA-index cache there when it reruns (04 step 2
  under a fresh chr10). Harmless.
