"""Analysis constants; each has a one-line reason. Nothing here is tuned to a dataset."""

BLOCK_BP = 5_000_000       # jackknife block: >> LD in outcrossing grasses, hundreds of blocks per genome
BLOCK_FRAC = 100           # or 1/100 of the smallest genome, so a small genome still gives ~100 blocks
BLOCK_MIN = 10_000         # smallest block size accepted, --block-size included
JK_MIN_BLOCKS = 3          # fewest distinct blocks a delete-one jackknife takes a variance from
AGE_EDGES = (0.0, 0.01)    # age bins by LTR-LTR K2P: identical, below 1%, older (few bins)
Z_SIG = 3.0                # |Z| >= 3 counts as significant: the conventional bar for D statistics
P_WARN = 0.05              # conventional level of the sister-pair and lineage-sorting symmetry tests
RESOLVE_WARN = 0.1         # heuristic: warn when two genomes' resolved fractions differ by > 0.1
PI_MAX = 0.5               # donor-like fraction <= 1/2: a recipient more donor-like than sister-like is the donor's sister
BF_TRACT = 3.0             # tract loci need posterior odds >= 3x prior odds (Kass & Raftery 1995, "positive")
Q_TRACT = 0.05             # a tract is reported donor-like at target-decoy q <= 0.05: the conventional 5% FDR
HMM_L_GRID = (1e4, 5e7, 41)  # mean tract lengths tried by EM: 10 kb-50 Mb, 41 log steps
HMM_ITERS = 100            # EM rounds at most
HMM_TOL = 1e-7             # EM stops when the log-likelihood moves by < 1e-7 of itself
CALLABLE_FLANK = 20        # heuristic: RS loci on each side of the shortest-callable upper bound
CALLABLE_MAX = 200         # shortest-callable search limit (loci); a longer minimum is not callable
INV_MIN_LOCI = 5           # heuristic: shortest reversed run reported as an inverted block; named in findings.txt
INV_FOREIGN_MAX = 1.0      # contiguity: a block's extent on each genome holds fewer loci placed on
                           # non-partner sequences than block loci, the merge rule's own tolerance; cost: a
                           # real inversion whose region's second copy lies on a non-partner sequence (or
                           # beside a pair kept from one side only) is dropped
MG_MAX = 1e-3              # mixture fit: post-split gene-flow component's mean divergence <= 0.1%
IDENT_MIN_SITES = 200      # LTR sites an ortholog pair needs to enter the split fit (one substitution
                           # is 0.5% of 200 sites)
MIX_MIN_PAIRS = 1.0        # mixture: a component with weight x pairs < 1 pair sits at its weight's bound, 0: parameters NA
