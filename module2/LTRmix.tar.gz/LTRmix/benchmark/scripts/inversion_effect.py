#!/usr/bin/env python3
"""Benchmark check: how do inverted blocks (from ltrmix's own inversions.tsv) change the recipient's evidence classes
and posteriors? Per inverted block >= 1 Mb of the recipient (vs sister or vs donor) and for the collinear rest:
class counts, posteriors, ortholog divergence, ELAI ancestry and the raw-assembly outcome of 'absent' calls."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")
import argparse

import numpy as np
import pandas as pd


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--res", default="results/main3", help="ltrmix output directory")
    ap.add_argument("--recipient", default="B73v5")
    ap.add_argument("--sister", default="TIL01")
    ap.add_argument("--donor", default="TIL18")
    ap.add_argument("--elai", default="truth/elai_summary.v5.tsv", help="ELAI table (chrom_v5, pos_v5, B73.amp)")
    ap.add_argument("--absence", default="absence/B73v5.TIL01.tsv.gz", help="absence_check output, recipient vs sister")
    ap.add_argument("--min-span", type=float, default=1e6)
    ap.add_argument("--out", default="analysis/inversion_effect.tsv")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args()
    R, S, D = a.recipient, a.sister, a.donor
    e = pd.read_csv(f"{a.res}/elements.{R}.tsv", sep="\t")
    e["mid"] = (e.start + e.end) // 2
    e["len"] = e.end - e.start + 1
    inv = pd.read_csv(f"{a.res}/inversions.tsv", sep="\t")
    inv = inv[(inv.genome_a == R) & (inv.span_a_bp >= a.min_span)]
    el = pd.read_csv(a.elai, sep="\t", usecols=["chrom_v5", "pos_v5", "B73.amp"])
    el = el[el["B73.amp"] > -900]
    el["chrom"] = R + "_chr" + el.chrom_v5.astype(str)
    el["anc"] = el["B73.amp"] / 2
    ab = pd.read_csv(a.absence, sep="\t").rename(columns={R: "name"})
    ab = ab[ab.status_in_TIL01 == "absent"][["name", "genome_state"]]

    e["group"] = "collinear"
    blocks = []
    for k, r in inv.iterrows():
        nm = f"vs_{r.genome_b}:{r.chrom_a.split('_')[-1]}:{r.start_a / 1e6:.1f}-{r.end_a / 1e6:.1f}"
        blocks.append((nm, r.chrom_a, r.start_a, r.end_a, r.n_anchor))
        sel = (e.chrom == r.chrom_a) & (e.mid >= r.start_a) & (e.mid <= r.end_a)
        e.loc[sel & (e.group == "collinear"), "group"] = "inverted"

    def summ(sub, chrom=None, lo=None, hi=None):
        c = sub["class"].value_counts()
        nd, do, ns, so = (int(c.get(x, 0)) for x in ("near_donor", "donor_only", "near_sister", "sister_only"))
        w = sub["len"].to_numpy(float)
        pa = float(np.average(sub[f"post_ancestry_{D}"], weights=w)) if len(sub) else np.nan
        pr = float(np.average(sub[f"post_recent_{D}"], weights=w)) if len(sub) else np.nan
        if chrom is None:
            ee = el.merge(sub[["chrom"]].drop_duplicates(), on="chrom")
            # ELAI over the collinear rest: SNPs not inside any listed inverted block
            m = np.ones(len(ee), bool)
            for _, cb, s0, s1, _ in blocks:
                m &= ~((ee.chrom == cb) & (ee.pos_v5 >= s0) & (ee.pos_v5 <= s1))
            elai = float(ee.anc[m].mean())
        else:
            elai = float(el.anc[(el.chrom == chrom) & (el.pos_v5 >= lo) & (el.pos_v5 <= hi)].mean())
        absn = ab.merge(sub[["name"]], on="name")
        gs = absn.genome_state.value_counts()
        nab = len(absn)
        res_s = float((sub[f"in_{S}"] != "unresolved").mean())
        res_d = float((sub[f"in_{D}"] != "unresolved").mean())
        return dict(n_el=len(sub), resolved_vs_sister=round(res_s, 3), resolved_vs_donor=round(res_d, 3),
                    near_donor=nd, near_sister=ns, donor_only=do, sister_only=so,
                    near_share_donor=round(nd / max(nd + ns, 1), 3), ins_share_donor=round(do / max(do + so, 1), 3),
                    post_ancestry=round(pa, 3), post_recent=round(pr, 3),
                    med_div_sister=round(float(sub[f"div_{S}"].median()), 4),
                    med_div_donor=round(float(sub[f"div_{D}"].median()), 4),
                    elai=round(elai, 3), absent_checked=nab,
                    absent_empty=round(gs.get("empty", 0) / max(nab, 1), 2),
                    absent_occupied=round((gs.get("occupied", 0) + gs.get("both", 0)) / max(nab, 1), 2),
                    absent_undetermined=round(gs.get("undetermined", 0) / max(nab, 1), 2))

    rows = []
    for nm, cb, s0, s1, na in blocks:
        sub = e[(e.chrom == cb) & (e.mid >= s0) & (e.mid <= s1)]
        rows.append(dict(region=nm, n_anchor=na, mb=round((s1 - s0) / 1e6, 1), **summ(sub, cb, s0, s1)))
    rest = e[e.group == "collinear"]
    rows.append(dict(region="collinear_rest", n_anchor=np.nan, mb=np.nan, **summ(rest)))
    rows.append(dict(region="all", n_anchor=np.nan, mb=np.nan, **summ(e)))
    out = pd.DataFrame(rows)
    os_ = _os.path.dirname(a.out)
    if os_:
        _os.makedirs(os_, exist_ok=True)
    out.to_csv(a.out, sep="\t", index=False)
    pd.set_option("display.width", 250)
    pd.set_option("display.max_columns", 30)
    print(out.to_string(index=False))


if __name__ == "__main__":
    main()
