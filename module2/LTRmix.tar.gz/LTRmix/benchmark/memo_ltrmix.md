# memo: LTRmix — admixture/introgression from LTR-RTs alone, benchmarked on B73/TIL18/TIL01
date: 2026-11-06/07
purpose: method (LTRmix/ltrmix.py) to detect and characterize admixture from LTR-RT libraries alone; benchmark vs
  Yang et al. 2023 Science (ELAI, 845 lines) and Barnes et al. 2022 PNAS (HPC1)
host: asc-oulab (shared lab server; setsid/nohup launchers)
env: ltrmix (mamba; numpy 2.4.6, numba 0.68.1, scipy 1.17.1, python-edlib 1.3.9, msprime 1.4.4, minimap2 2.31,
  openpyxl 3.1.5 for xlsx truth tables);
  lock: benchmark/logs/env_ltrmix.lock.yml; tool deps only: LTRmix/environment.yml

## inputs
LTR-RT libraries: run/{B73v5,TIL18,TIL01}_LTRs_depth*_clean_ltr.{fa,tsv} (LTRquest 5042a1e; memo.md)
genus test: PanAnd EDTA intact calls + assemblies Zh-RIMHU001, Zn-PI615697, Zx-TIL25 (MaizeGDB; md5 OK)
citrus test: NCBI GCA_022201045.1 (CsA), GCA_022201065.1 (CsB), GCA_059628685.1 (Cr), GCA_047301065.1 (Cm),
  GCA_046470815.1 (CaM), GCA_046470805.1 (CaP); proteins GCF_022201045.2; md5 OK; seqids -> lineage2/seqids.*.tsv
extra genomes (benchmark only): MaizeGDB Zm-PT-REFERENCE-HiLo-1.0 (PT_MEXI5; Toronto Agreement release),
  Zx-TIL25-REFERENCE-PanAnd-1.0, Zv-TIL11-REFERENCE-PanAnd-1.0, Zd-Gigi-REFERENCE-PanAnd-1.0 (outgroup); md5 OK;
  inputs/{PT,TIL25,TIL11,Zd}.fa (seqids prefixed); LTRquest 5042a1e same flags -> benchmark/ltrquest_extra/
truth: figshare 21579528 elai.845.txt.gz (md5 670f662e2cea6ae5852eb617f1b407dd; plain curl works, a browser
  User-Agent gets a WAF 403) -> benchmark/truth/elai_summary.v5.tsv (lifted with MaizeGDB
  B73_RefGen_v4_to_Zm-B73-REFERENCE-NAM-5.0.chain; 877,575/878,439 SNPs); loci.v5.tsv; hf.v5.bed
annotations for comparators: inputs/annot_*/te.gff3.gz (EDTA structural), MaizeGDB v4/v5 gene GFF3

## commands
```bash
conda activate ltrmix
python LTRmix/ltrmix.py --genome B73v5=run/B73v5_LTRs --genome TIL18=run/TIL18_LTRs --genome TIL01=run/TIL01_LTRs \
  --outdir benchmark/results/main3 -t 32 -v                       # 9 min, 53 GB RSS
python benchmark/scripts/eval_real.py benchmark/results/main3 --nperm 1000
cd LTRmix && python -m pytest -q tests/                           # 19 tests: trios + overview figure
python LTRmix/ltrmix_plot.py <trio outdir> [--mu RATE]            # redraw overview.{png,pdf}; ltrmix draws it per trio
benchmark/sim/make_grid.sh && benchmark/sim/run_grid.sh           # 78 msprime+LTR-RT simulations (sim_ltr_admix.py)
benchmark/sim/run_grid_m2.sh                                      # 8 four-genome runs (f-ratio)
python benchmark/scripts/sim_summary.py benchmark/sim
python benchmark/scripts/wg_kmer.py --mode {all,noLTR} --out benchmark/wgk/wgk_<mode>; eval_wgk.py
python benchmark/scripts/gene_snp_D.py --outdir benchmark/gene_snp -t 16
python benchmark/scripts/edta_to_lib.py ...; benchmark/edta/run_edta.sh
python benchmark/scripts/absence_check.py --ortho <orthologs.A.B.tsv.gz> --genome-a <A.fa> --genome-b <B.fa> --out A.B
benchmark/scripts/06_after_ltrquest.sh                            # six-genome ltrmix + TIL11/TIL25 spike-in
benchmark/genus/run_genus.sh                                      # 2nd event: PanAnd EDTA libs TIL01,TIL18,TIL25,Zh,Zn
benchmark/genus/wgk/run_wgk_trio.sh                               # annotation-free k-mer D on whole assemblies (58 min, 129 GB)
benchmark/lineage2/01_download.sh; 02_annotate_and_run.sh         # citrus: 6 NCBI haplotypes, LTRquest 5042a1e, ltrmix
python benchmark/lineage2/03_truth.py                             # Wu 2023 Hortic Res Suppl. Table 4 -> truth/*.bed
python benchmark/lineage2/04_eval.py                              # citrus scoring -> lineage2/eval/{trios,tracts,truth_tracts}.tsv
benchmark/results/rerun_all_v2.sh                                 # after the D_ins symmetric-coverage fix: main3, sims, EDTA, genus
python benchmark/scripts/young_shared.py --lib run/TIL18_LTRs --orth-r <orthologs.TIL18.B73v5> --orth-s <orthologs.TIL18.TIL01> --out <tsv>
benchmark/figures/rebuild_all.sh                                  # Figs 1-3 from current results
python benchmark/figures/fig4_six_genomes/fig4_six_genomes.py; python benchmark/figures/fig5_generality/fig5_generality.py
benchmark/scripts/06_after_ltrquest.sh -> results/six (20 trios, 1.5 h, 32 threads) and spike/ (TIL25 tracts in TIL11)
python benchmark/scripts/analyze_six.py results/six; python benchmark/scripts/eval_spike.py
benchmark/results/forced/run_forced.sh                            # post hoc: donor fixed (scripts/forced_trio.py)
benchmark/gene_snp/run_more.sh; run_more2.sh                      # SNP ABBA/BABA for 7 trios (gene_snp_D.py --p1 --p2 --p3)
benchmark/absence/young/run.sh                                    # raw-assembly check of young shared insertions (--names)
python benchmark/scripts/analyze_six.py; python benchmark/scripts/eval_spike.py
```

## key outputs
benchmark/results/six/analysis/{trio_summary.tsv,six_findings.txt,ltr_vs_snp.tsv}; results/six/NOTE_fratio.txt
benchmark/lineage2/eval/*.tsv (citrus vs published tracts); benchmark/genus/out/analysis/trio_summary.tsv, genus/wgk/wgk_trio.tsv
benchmark/REPORT.md (results + scorecard), benchmark/results/main3/ (real trio), benchmark/sim/sim_summary.tsv,
benchmark/figures/ (SPEC.md + figures), benchmark/dead_ends.md

## gotchas
- msprime: an ancestral population of a split is inactive (sampled at the split time) unless initially_active=True:
  parviglumis was sampled 9,000 generations ago and biased every null; fixed + asserted.
- whole-genome minimap2 asm20 on maize assemblies reached 545 GB RSS (killed); use gene-space alignments.
- killing a multiprocessing parent leaves orphaned workers (re-parented to init, ~30 GB each): kill by elapsed time.
- pkill -f / awk patterns can match your own shell: kill by PID.
- k-mer index cache on a busy disk was slower than rebuilding (removed).
- one-sided annotation dropout biases D_kmer and D_ins (simulations): check completeness_ratio in stats.tsv.
- NumPy transparent-huge-page advice stalled big allocations for minutes (direct compaction) on this server:
  NUMPY_MADVISE_HUGEPAGE=0 before importing numpy (set in ltrmix.py, ltrmix_plot.py, benchmark scripts).
- ltrmix v2 (2026-11-07 17:00): D_ins and identity spectrum count only donor copies resolved in both sisters
  (asymmetric counting inflated D_ins when donor synteny was incomplete); maize D_ins 0.189 -> 0.195; all reruns in
  results/main3 (v1 kept as main3.v1), sim/, edta/out (out.v1), genus/out (out.v1).
- six-genome run: the data pair B73 + TIL18 (not TIL18 + TIL25), so a hypothesis-driven trio needs
  scripts/forced_trio.py; TIL25 is no closer to TIL18 than parviglumis is, which made the spike-in uninformative and
  leaves no valid second donor for the f-ratio (second-donor rule tightened in ltrmix, 21:05).
- PanAnd EDTA GFF seqids: '1' in Zn vs 'chr1' in FASTA; edta_to_lib.py maps both. curl -C - on a complete file
  returns 416 ('FAIL' lines in run_genus.log are harmless when the file is already there).

## Inversion effect on the posterior (2026-11-09)
purpose: do inverted blocks distort B73's ancestry posterior? | env: ltrmix | input: benchmark/results/main3,
truth/elai_summary.v5.tsv, absence/B73v5.TIL01.tsv.gz
```bash
cd benchmark
P=$(mamba env list | awk '$1=="ltrmix"{print $NF}')/bin/python
$P scripts/inversion_effect.py   # -> analysis/inversion_effect.tsv (per inverted block >= 1 Mb: classes, posteriors, divergence, ELAI, raw absence outcome)
$P scripts/inversion_mask.py     # -> analysis/inversion_mask.tsv (mask old-arrangement blocks: chromosome ranks, window r)
```
- old-arrangement block: median recipient ortholog divergence to the genome with the other arrangement > genome-wide
  median TIL01-TIL18 divergence (0.0119). 9 blocks, 8,168 elements (6.4%).
- masked: chr5/8/9 still lowest; rho 0.64 -> 0.62; window r 0.29 -> 0.22 (1 Mb), 0.36 -> 0.25 (10 Mb); still > 200
  circular shifts (95%: 0.08, 0.20). Genome mean 0.383 -> 0.382.
- informative-element spacing: B73 median 25 kb / mean 67 kb; citrus trios 24-49 kb / 50-144 kb. HMM mean tract fitted:
  B73 197 kb (ancestry), citrus CsB 2.5 Mb.

## Rate-free split test (2026-11-09)
purpose: decide 'shared insertion younger than the split' without a clock rate | env: ltrmix | input: run/{TIL18,TIL01,B73v5}_LTRs, benchmark/results/main3/orthologs.TIL18.*.tsv.gz
```bash
P=$(mamba env list | awk '$1=="ltrmix"{print $NF}')/bin/python
$P benchmark/scripts/rate_free_split.py -t 8   # ~2 min; -> benchmark/analysis/rate_free_split.tsv
```
- split in LTR-divergence units: s = 0.00048 (isolation; block bootstrap 0.00034-0.00063); 3-component mixture
  (isolation + gene flow mean <= 0.1% + upper tail) s = 0.00070, gene-flow weight 0.0012. Mixture recovered a planted
  s = 0.0018 with 4% gene flow (0.00171); isolation-only fit gave 0.00024 there.
- insertions with u95 < s: 0 vs 0 (rate-based 3e-8/30 kyr threshold 0.0018: 13 vs 1). Identical LTRs need ~6,200 sites.
- implied LTR rate for a 30-60 kyr split: 0.4-1.2e-8 (LTRquest default 3e-8). Ortholog pairs below s: B73-TIL18 7.6%, TIL01-TIL18 3.5%.
- docs corrected: REPORT short answer, section 2 (+ rate-free paragraph), 9, 10, Fig 2 note; README; DESIGN; ltrmix.py comments.
- citrus (2026-11-09): `rate_free_split.py --res benchmark/lineage2/out --donor Cr=benchmark/lineage2/ltrquest_a/Cr_LTRs
  --sister Cm=benchmark/lineage2/ltrquest_b/Cm_LTRs --recipient CsB=benchmark/lineage2/ltrquest_a/CsB_LTRs
  --out benchmark/analysis/rate_free_split.citrus.tsv`: s = 0.0100 (0.0079-0.0124), mixture 0.0185; certified
  CsB+Cr 9-37 vs Cm+Cr 0-2. Isolation fit under-fits Cm-Cr identical pairs (0.83% vs 0.14%).
