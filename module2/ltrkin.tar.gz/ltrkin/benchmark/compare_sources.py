#!/usr/bin/env python3
"""Compare two `ltrkin source` runs on the same reference (e.g. ltrkin genotypes vs assembly-truth genotypes).
Per new copy: present in both runs, and whether the tied nearest-fixed sources agree (any overlap / identical
set), with the divergence of the best source in each run.
usage: compare_sources.py A.sources.tsv B.sources.tsv [labelA labelB]"""
import sys

import pandas as pd

a, b = (pd.read_csv(p, sep="\t") for p in sys.argv[1:3])
la, lb = (sys.argv[3], sys.argv[4]) if len(sys.argv) > 4 else ("A", "B")
sa = a.groupby("new_id").source_id.apply(set)
sb = b.groupby("new_id").source_id.apply(set)
both = sa.index.intersection(sb.index)
ov = [len(sa[i] & sb[i]) > 0 for i in both]
same = [sa[i] == sb[i] for i in both]
print(f"new copies with a source: {la} {len(sa)}, {lb} {len(sb)}, both {len(both)} "
      f"({len(both) / len(sb):.3f} of {lb}); only {la} {len(sa.index.difference(sb.index))}, "
      f"only {lb} {len(sb.index.difference(sa.index))}")
if len(both):
    print(f"sources overlap {sum(ov) / len(both):.3f}; identical tied set {sum(same) / len(both):.3f}")
    da = a.groupby("new_id").divergence.min().reindex(both)
    db = b.groupby("new_id").divergence.min().reindex(both)
    for lim in (0.002, 0.005, 0.01):
        m = (db <= lim)
        if m.any():
            o = pd.Series(ov, index=both)[m]
            print(f"  {lb} best divergence <= {lim}: n {int(m.sum())}, overlap {o.mean():.3f}")
