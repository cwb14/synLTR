"""Read phasing: distinct haplotypes carrying each allele (synthetic diploid with 1% heterozygosity)."""
import pysam
import pytest

from ltrkin.annot import read_gff3, infer_tsd
from ltrkin.phase import haplotypes
from ltrkin.reads import evidence

from synth import build


@pytest.fixture(scope="module")
def het(tmp_path_factory):
    return build(str(tmp_path_factory.mktemp("het")), seed=4, het=0.01)


def _h(d, eid, ploidy=2):
    fa = pysam.FastaFile(d["ref"])
    bam = pysam.AlignmentFile(d["full"])
    el = next(e for e in read_gff3(d["gff"]) if e.id == eid)
    el.tsd = infer_tsd(fa, el)
    rd = []
    evidence(bam, fa, el, el.tsd_len, 20, reads_out=rd)
    return haplotypes(rd, fa, el.chrom, el.start, el.end, ploidy)


def test_two_haplotypes_carry_full(het):
    h, n = _h(het, "E3_hom")
    assert h["F"] == 2 and n >= 2


def test_hemizygous_has_one(het):
    h, _ = _h(het, "E4_hemi")
    assert h["F"] <= 1


def test_heterozygous_empty(het):
    h, _ = _h(het, "E1_het_empty")
    assert h["F"] == 1 and h["E"] == 1


def test_identical_haplotypes_uninformative(data):
    h, _ = _h(data, "E3_hom")          # no heterozygosity: never more than one distinct haplotype
    assert h["F"] <= 1


def test_haploid_off(het):
    h, _ = _h(het, "E3_hom", ploidy=1)
    assert h == {"F": 0, "S": 0, "E": 0}


def test_low_quality_bases_are_ignored(het):
    """Bases below the quality threshold are neither reference nor alternative: with a threshold above every base
    quality there is nothing to phase."""
    fa = pysam.FastaFile(het["ref"])
    bam = pysam.AlignmentFile(het["full"])
    el = next(e for e in read_gff3(het["gff"]) if e.id == "E3_hom")
    el.tsd = infer_tsd(fa, el)
    rd = []
    evidence(bam, fa, el, el.tsd_len, 20, reads_out=rd)
    assert haplotypes(rd, fa, el.chrom, el.start, el.end, 2)[0]["F"] == 2
    assert haplotypes(rd, fa, el.chrom, el.start, el.end, 2, min_q=60) == ({"F": 0, "S": 0, "E": 0}, 0)
