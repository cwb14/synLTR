# fig2_clock memo

date: 2026-11-07
purpose: Fig. 2 of the LTRmix benchmark: the LTR clock separates gene flow from lineage sorting (B73 / TIL01 / TIL18)
env: `source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix` (matplotlib 3.11.2, numpy 2.4.6, pandas 3.1.1, edlib, samtools 1.25, minimap2 2.31-r1302); Liberation Sans / Mono registered from /usr/share/fonts/truetype/liberation*
session: figure agent for the LTRmix benchmark (no resume name)
inputs (read-only, all under /data2/chris/maize_introgression):
- benchmark/results/main3/stats.tsv (D_ins_by_age, D_kmer, D_ins, D3_triples, D_self_outgroup, identity_spectrum, f_lower_bound, completeness_ratio, hmm near_threshold); findings.txt (12,445 triples; 21 FDR tracts; median divergence 0.0104)
- benchmark/results/main3/orthologs.{B73v5.TIL18,B73v5.TIL01,TIL01.TIL18,TIL01.B73v5}.tsv.gz (every shared insertion), elements.B73v5.tsv, tracts.B73v5.bed
- run/TIL18_LTRs_depth*_clean_ltr.tsv (full-precision K2P of the donor copy), run/{B73v5,TIL18,TIL01}_LTRs_depth*_clean_ltr.tsv (elements in B)
- benchmark/edta/out/stats.tsv; benchmark/sim/eval/null_s1{01..30}.json, sim/eval/fn0.2_f0_r*.json, sim/out/{f0.18_Ta*,fn0.2_f0_r*}/stats.tsv
- benchmark/wgk/wgk_{all,noLTR}.TIL18.tsv (k-mer D recomputed with eval_wgk.py's 5-Mb jackknife); benchmark/gene_snp/run_gene_snp.log
- benchmark/absence/B73v5.TIL01.tsv.gz (raw-assembly check: random 20,000 of 93,756 absent calls); inputs/{B73v5,TIL18,TIL01}.fa via samtools faidx

## Run
```bash
cd /data2/chris/maize_introgression/benchmark/figures/fig2_clock
source /home/chris/bin/etc/profile.d/conda.sh; conda activate ltrmix
python fig2_clock.py -v            # ~15 s, 1.3 GB peak; --figure-only writes just the PNG
```
outputs: fig2_clock.pdf (p1 figure, p2 short legend, p3 long legend; fonttype 42), fig2_clock.png (300 dpi, 180 x 232 mm),
fig2_clock_numbers.tsv (159 legend numbers with sources)

## Layouts considered
1. (chosen) Exemplar order, mechanism -> one real case -> every insertion -> numbers with nulls:
```
+-----------------+----------------------------------------------+
| A schematic     | B 96-kb region, TIL01 / B73 / TIL18 at one   |
| (tubes tree:    |   bp scale; every LTR-RT drawn; ribbons      |
|  old insertions |   shaded by identity; insertions absent from |
|  sort either    |   TIL01 as wedges to their empty sites       |
|  way, young one |                                              |
|  only via gene  |                                              |
|  flow; clock)   |                                              |
+-----------------+----------------------------------------------+
| C the young element: both copies, LTR-pair arcs, copy          |
|   differences; junctions at bp: shared TSD, TIL01 empty site   |
+----------------------------------------------------------------+
| D every shared insertion on the age axis (B73+TIL18 above,     |
|   TIL01+TIL18 below, n per stratum); D per stratum +-2 SE,     |
|   EDTA replicate, 30 null simulations; split band              |
+-------------------------------+--------------------------------+
| E identity spectrum            | F genome-wide D +-2 SE, LTR-  |
|   (both pairs, excess shaded)  |   only tests and comparators  |
+-------------------------------+--------------------------------+
```
2. Age axis as backbone: schematic tree drawn on the kyr axis above D, real example in a right column. Rejected: a
   cartoon on a data axis reads as data; a log age axis distorts the tree.
3. Two columns (A, B, C left; D, E, F right). Rejected: D needs full width for 18,790 marks on a log age axis with n per
   stratum; B needs width to show 96 kb at a readable bp scale.
Choice: layout 1 follows ltr_rddm / ltr_removal (statistic led by a mechanism schematic and one real element) and puts
the control (TIL01) as a full partner in B, C, D and E. Per-insertion view: linear-count histograms were tried (working
plot) and rejected: the young strata (the result) become a sliver beside the old bulk; jittered strips keep every
insertion visible with n per stratum printed.

## Data checks (in the script; it exits on failure)
- shared insertions listed from recipient-side ortholog tables (B73 records with a TIL18 ortholog and status 'absent' in
  TIL01; TIL01 records likewise) reproduce stats.tsv nA/nB in all 8 strata (11,172 / 7,618) only with the library's
  full-precision K2P; the ortholog tables' 5-digit K2P moves 3 elements across the 0.005 / 0.01 boundaries.
  (Donor-side listing from orthologs.TIL18.* gives 11,307 / 7,675: not what ltrmix counts.)
- identity spectrum: histogram of raw ortholog divergences reproduces n_target / n_mirror per bin exactly.
- comparators: whole-genome k-mers +0.1073 +- 0.0120 (Z 8.9), LTR-masked +0.1009 +- 0.0108 (Z 9.4), recomputed from
  wgk tables = REPORT.md section 1; gene-space SNPs +0.168 +- 0.0182 (Z 9.2) from run_gene_snp.log.
- null sims signed toward B (flip when recipient_called == 'P'): young +0.018 +- 0.077 (SD), old +0.000 +- 0.015.
- gene-flow sims (f >= 0.18, sister inference intact, 12 runs): young D 0.28-0.51, old 0.05-0.15 per run (legend only).
- simulation caveats recomputed from sim/out/*/stats.tsv: completeness 1.014-1.047 (f0.18, 6 runs), 1.234-1.291 under
  20% one-sided dropout (3 runs) with spurious |D_kmer| 0.24-0.27, |D_ins| 0.33-0.35 (SPEC.md quoted 1.015-1.04 / 1.23-1.29).

## Example (B, C): rule and structural checks
rule: K2P = 0 (TIL18 copy) insertions shared by B73 and TIL18, absent from TIL01 (122) -> in the absence-check table
(26) -> TIL01 genome_state 'empty' (17) -> both copies K2P = 0, same_tsd 'yes', same 5-bp TSD in both libraries,
tg...ca motif in both, confidence high in both, nest_status '.' in both (3):
- B73v5_chr1:300732131-300741649 Gypsy/Retand 9,519 bp, LTR 653 (chosen)
- B73v5_chr3:218596987-218597929 Copia/Ale 943 bp (family median ~5.3 kb: atypical length)
- B73v5_chr7:84612013-84617570 Copia/Ale 5,558 bp, LTR 316, family of 10 copies
why the Retand: commonest superfamily among the 122 (57); family merged_fam00002 is B73's largest (19,021 copies,
length quartiles 7,387/9,306/9,728); LTR 653 within the 122's quartiles (263/605/669); neighborhood typical (6
near_donor elements within 100 kb; median 5, quartiles 1-8 over the 122). Caveat stated in the legend: it lies in an
FDR-passing recent tract (chr1:297.26-301.20 Mb, q = 0.048), as do 33/122 (27%). No ELAI SNPs at 300.4-301.6 Mb.
checks (re-extracted with samtools faidx, aligned with edlib):
- TSD CCTTG at both ends of the B73 and the TIL18 copy; 20-bp flanks identical B73 = TIL18
- TG...CA ends in both copies; lengths 9,519 / 9,517 bp
- 5' vs 3' LTR: 653/653 identical in both copies (K2P 0 reproduced)
- B73 vs TIL18 copy: 11 substitutions + 2 single-base indels, all internal (divergence 0.00116 = ortholog table)
- TIL01 empty site: probe (10 bp left flank + CCTTG + 10 bp right flank) unique in TIL01_chr1:312035001-312095000, at
  TSD 312,062,964-312,062,968; flanks joined across one CCTTG; absence table genome_state 'empty'
- one left-flank site B73 = TIL18 = G, TIL01 = A (13 bp before the TSD)
region (B): minimap2 -cx asm10 --cs of TIL18 / TIL01 windows to B73 chr1:300,695,001-300,800,000; split at indels >= 50 bp:
B73-TIL18 one 99.7-kb block, 112 mismatches (99.89%); B73-TIL01 blocks 98.5-99.1% with 5 gaps = the 5 B73+TIL18-only
insertions (ages 0, 67, 67, 169, 250 kyr from the TIL18 copies).

## Figure check (answered by the figure agent)
1. A shows the biology in genome/element coordinates, every element drawn: A is the mechanism schematic (as asked in
   SPEC.md and as in the ltr_rddm / ltr_removal exemplars); B, the first data panel, shows three genomes in bp
   coordinates with every annotated LTR-RT drawn; D draws all 18,790 shared insertions. Yes for A-B together; strictly,
   A itself is a schematic.
2. Raw evidence for a typical, verified example: yes, C (bp junctions and LTR identity re-extracted from the assemblies;
   selection rule and checks above).
3. Control as a full partner at the same scale: yes, TIL01 track in B (same bp scale), TIL01 row in C, TIL01+TIL18
   strip in D (same axis), TIL01-TIL18 spectrum in E.
4. Every null drawn: yes, D (D = 0 line; 30 null simulations as dots with mean +- 2 SD bands), E (mirror pair), F (0).
5. On-figure text: letters, axis labels, ticks, direct labels (schematic labels in A, ages in B, "LTRs identical (653 of
   653 bp)" in C), keys and n per stratum in D. Yes.
6. Full-resolution crops: nothing clipped or colliding; smallest text 6 pt; thinnest lines 0.4 pt dashed guides; panel
   tops aligned (A/B, E/F), E's plot edge aligned with D's (25 mm), letters at panel corners in reading order. Yes.
7. Each panel answers a different question (logic; real region; bp proof; age dependence with nulls; copy identity;
   genome-wide tests vs comparators); PDF = figure + short legend (no methods) + long legend ending with the analysis
   line. Yes.

## Gotchas
- matplotlib did not see the system Liberation fonts: registered with font_manager.addfont in setup_rc().
- Legend word-wrap measures text at 2,400 dpi; at 72 dpi hinting over-measured digits and left gaps.
- Liberation Sans lacks superscript minus/digits: 10$^{-8}$ goes through mathtext (custom fontset = Liberation).
- Strip dots are rasterized in the PDF (saved at 600 dpi) to keep the file small; everything else is vector.
