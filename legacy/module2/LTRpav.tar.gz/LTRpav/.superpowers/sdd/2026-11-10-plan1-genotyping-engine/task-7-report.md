# Task 7 report
Implemented src/ltrpav/annotation/bed.py (find_ltrs, load_bed), tests/toy.py, tests/test_annot_bed.py.
- find_ltrs: mappy asm20, n=min(len//2,6000), constraints per brief, largest mlen wins, None if n<MIN_SEG or no hit.
- load_bed: skips blank/#/track/browser; pre-validates all records vs fasta.lengths() (ValueError: count + first 5); no_ltrs counted.
Tests: 5 in test_annot_bed (planted, random None, too short, load_bed incl. skip + strand + default name, bad records). Full suite passes (28 tests), ruff clean.
TDD: RED = ModuleNotFoundError ltrpav.annotation.bed at collection; GREEN = `mamba run -n ltrpav pytest` all pass.
Self-review: bed with start>=end also counted as bad record; no concerns.
