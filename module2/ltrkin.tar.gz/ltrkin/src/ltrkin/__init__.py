"""ltrkin: genotype LTR retrotransposon insertions from long reads and assign their likely source copies."""
__version__ = "0.2.1"
