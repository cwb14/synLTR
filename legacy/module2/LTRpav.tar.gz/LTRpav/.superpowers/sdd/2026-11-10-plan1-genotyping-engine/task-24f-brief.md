# Task 24F: syntenic anchor net and adaptive chunking

The controller inserted this task, before the bake-off reruns (ledger, Task 24 rulings).

## Why
The aligner bake-off (Task 24) found that the flat 1:1 net in `chain.net_blocks` admits paralogous fills. These
are short chains, about one TE long, that pair a B73-only TE copy with a TIL18-only copy elsewhere. On real chr10
they make up 26-34% of the net in all six directions, and they leave 37-49% of elements unresolved
("breakpoint" and "span_cap" windows).

DESIGN.md 5.1 defines an anchor as "a stretch of A aligned 1:1 to B in an orthologous (collinear, uniquely best)
chain". The flat net enforces 1:1 and best, but not collinear. Read these before coding:
- the diagnosis, `diag-breakpoints-report.md` in this directory: section Q5 holds the proposal, the measurement
  and the correction;
- its prototype, `/data2/chris/maize_introgression/benchmark_pav/bakeoff/diag_breakpoints/synnet.py`.

The prototype measured the first version of the rule. This task implements the **corrected** rule below.

## Gate: the repo is in use
Two bake-off batches run the engine from this working tree through an editable install. The `ltrpav_bench` env
imports `ltrpav` from `/data2/chris/maize_introgression/LTRpav/src`, and every run starts a new Python process.

**Do not modify any file in the repo until all of these hold:**
- `/data2/chris/maize_introgression/benchmark_pav/bakeoff/runs/batch.exit` exists;
- `/data2/chris/maize_introgression/benchmark_pav/bakeoff/chr10/batch.exit` exists;
- `pgrep -af 'run_variant.py|02_run_sims.py|04_chr10.sh'` prints nothing.

Until then, read, design, and write drafts under your scratch directory
`/data2/chris/maize_introgression/benchmark_pav/bakeoff/task24f_scratch/`. If the gate is still closed when you
are ready to edit, wait in bounded steps:
`timeout 15m bash -c 'until [ -f .../runs/batch.exit ] && [ -f .../chr10/batch.exit ]; do sleep 30; done'`,
then re-check `pgrep`. Expected about 07:45-08:00. Never signal those processes.

## Requirements

### 1. Syntenic net (`src/ltrpav/chain.py`)
These stay exactly as now:
- chain order (decreasing chain_score);
- competition credit (`_credit`) and margins;
- trimming (`_trim`);
- the MIN_CHAIN_SCORE test on the pieces a chain keeps.

New: before a chain claims anything, test each of its trimmed pieces x against the chains already kept (all
better):
- **A-parent of x:** the kept chain with the smallest A extent that contains x's A span on x's A sequence. A
  chain's A extent runs from its first kept piece's a_start to its last kept piece's a_end. The **B-parent** is
  defined the same way in B.
- **Support in A's frame.** x is supported if any of these holds:
  - (a) x has no A-parent;
  - (b) x's B span lies on the A-parent's B sequence, inside the B gap between the A-parent's two kept pieces
    that flank x on A (the same strand as the parent is syn; the opposite strand is an inversion);
  - (c) x's chain has at least one trimmed piece with no A-parent (chain-level top support).
- **Support in B's frame:** the same three tests, mirrored.
- **Keep x only if it has support in both frames.** A dropped piece claims nothing, so later chains may still fill
  its positions. Its competition credit stands, because it is a rival alignment. The chain keeps its remaining
  pieces if they carry >= MIN_CHAIN_SCORE matches; otherwise the chain is dropped, as now.
- **No new parameter, threshold, slop or size escape.**

**Why "both frames, with chain-level top support"** (the diagnosis's correction, chosen for structural reasons,
not scores):
- A paralog fill sits in an A gap of a better chain and lands outside that chain's B gap; its chain is never top
  level in A. It is dropped.
- In the prototype, the B-frame-only "top" escape let 35 paralog chains in A gaps through into TIL18 sequence
  that no chain covered (the centromere gap). Without context, "top in B" is not synteny.
- The real 5.6-Mb chr10 inversion is kept: its chain is top level in A over 217 pieces and in B.

**Named costs** (accepted; document them in the docstring and in DESIGN 5.1):
- Real transpositions shorter than CHAIN_MAX_GAP are dropped like paralogs.
- An ortholog on an unplaced B scaffold whose A side falls in a chromosome chain's gap is dropped.

In both cases the elements come out missing (U/D/O), not P/E.

**Efficiency.** A parent lookup must not scan every kept chain per piece. A whole-genome direction (about 10^5
pieces and 10^4 kept chains) must net in well under a minute; today's chr10 net takes 0.4 s. Use per-sequence
indexes of kept chain extents (stabbing query plus containment) and state the complexity in the docstring.

**Logging.** Add one INFO line per net: pieces kept (top in both frames, syn, inv, chain-supported), pieces
dropped and their A bp. Details go at DEBUG.

**Cache keys.** Netted anchors from the old net must never be reused. Add a net identifier, for example
`"net": "syntenic"`, to `_CHAIN_PARAMS` (`anchor/__init__.py`) or the equivalent stage key. Check every cache
downstream of `net_blocks`, including the flank route's windows (`anchor/flanks.py:274`), and test that an old
anchors checkpoint is recomputed.

### 2. Adaptive chunking (`src/ltrpav/genotype.py`, `constants.py`)
- Windows per chunk = max(CHUNK_MIN, min(CHUNK_WINDOWS, ceil(n_windows / CHUNK_TARGET))), with:
  - CHUNK_TARGET = 256: about 4 chunks per worker at 64 threads balances load, and the value does not depend on
    `--threads`, so a resumed run reuses its chunks at any thread count;
  - CHUNK_MIN = 8: the bake-off measured 8, and smaller chunks add per-chunk file and marker overhead;
  - CHUNK_WINDOWS = 2,000, kept as the cap.

  Each constant gets a one-line reason in `constants.py`. Apply the same rule wherever else windows are chunked.
- The calls must not depend on chunking: a test runs a toy pair at 1 and 3 threads and compares the calls files
  byte for byte, plus a unit test of the chunk size for n = 0, 1, 100, 5,600 and 60,000.

### 3. Small fixes
- `constants.py`: MAPPY_BEST_N keeps the value 5, but its comment must say that minimap2's *generic* default -N is
  5, that its asm presets use 50, and that the bake-off's mm2_N50 variant tests the choice.
- DESIGN.md 5.1:
  - Replace "keep a 1:1 orthologous chain set (best chain per position on both genomes)" with the syntenic net:
    one sentence for the rule, the named costs, and the citations (Kent et al. 2003 PNAS 100:11484, UCSC
    netSyntenic/netFilter -syn; Song et al. 2022 PNAS 119:e2113075119, AnchorWave; Goel et al. 2019 Genome Biol
    20:277, SyRI).
  - Also fix the two stale lines of Task 24 ruling 16: 5.3's "mappy with long join" (the engine maps
    strand-split, without long join), and the flag list near line 217 that names boundary_offset (no such flag
    exists).
  - Update the `chain.py` module docstring.

### 4. Tests (`tests/test_chain.py` and others; small synthetic blocks)
- **Existing tests stay green.** If one encodes a paralog fill being kept, change it and give the reason in the
  report.
- **New cases:**
  - a paralog fill out of place in both frames is dropped;
  - an in-gap fill on the same strand with its B span inside the parent's B gap is kept;
  - an in-gap inverted fill is kept;
  - a chain that is top level in both frames is kept;
  - the crept-in inversion is kept by chain-level support: a top-level inverted chain, some of whose pieces fall
    inside a better chain's A extent;
  - the leak case is dropped: the A span lies in a chain gap, the B span lies in B sequence that no kept chain
    covers, and the chain has no A-top piece;
  - a transposition shorter than CHAIN_MAX_GAP is dropped (documents the cost);
  - a dropped piece's competition credit still lowers the margin of the piece it overlaps;
  - margins are unchanged when nothing is dropped;
  - a performance test: a synthetic net of at least 50k blocks finishes in a few seconds;
  - the old-cache recompute test.
- Run the full suite under `-W error`, and `ruff check .` from the repo root. Both must be clean.

### 5. Real-data check (outside the test suite; no genotyping)
Re-net the cached raw blocks of all six chr10 directions with the new code and rebuild the windows. The inputs are
`D/chr10/runs/mm2/work/anchors/<A>__<B>.mm2.raw.npz` and `D/chr10/runs/mm2/work/elements/`, with
`D = /data2/chris/maize_introgression/benchmark_pav/bakeoff`. Read only; work in your scratch directory.

Report per direction:
- window status counts and top-level elements in ok windows, against the prototype's
  `D/diag_breakpoints/m1_window_status.tsv`;
- net time;
- kept and dropped piece counts.

Expect a little less than the prototype kept, because the leak is now dropped. Explain any large difference.
Also time the net on the largest available input.

## Constraints
- Probes use at most 8 threads, each under `timeout 15m` in the foreground. Export `NUMPY_MADVISE_HUGEPAGE=0` for
  every Python process. Use env `ltrpav_bench`.
- No subagents. American English.
- Commit once, with the subject "Make the anchor net syntenic and chunk windows adaptively". Use the existing git
  identity, set nothing, and add no trailers or AI attribution of any kind: the user is the sole author.
- Do not push.

## Report
Write `task-24f-report.md` in this directory:
- what changed, file by file;
- the rule as implemented, with its complexity;
- test summary;
- the real-data check table;
- the cache-key change;
- every deviation, with its reason.

Return ONLY:
- status;
- the commit;
- a one-line test summary;
- the chr10 B73v5 -> TIL18 window statuses, before and after;
- concerns.
