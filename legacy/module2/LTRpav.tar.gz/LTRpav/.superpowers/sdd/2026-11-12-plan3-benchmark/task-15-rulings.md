# Task 15: controller rulings (binding; they override task-15-brief.md where the two differ)

## R1. Code and inputs
- **Snapshot 2** for every analysis: `SNAP_SHA=6282541` (`benchmark_pav/plan3/snap/6282541`) via `common/env.sh` or
  `common/view.sh`. Check that `ltrpav.__file__` resolves inside it first.
- **Genotypes:** `real/stability/mm2/geno` (`--anchor mm2`) and `real/stability/cap5k/geno` (5-kb flank cap via
  `real/cap_variant.py`). Each block has `block.done`. Never write in a `geno/`; views link to it
  (`common/view.sh RUN VIEW SHEET`, with each block's `samples.tsv`).
- **Baseline:** `real/six/views/main` (Task 13, `--trio B73,TIL01,TIL18`). Read it only; never run anything in it.
- **Wall times and peak memory per block:** the queue's per-worker step files. mm2: `genotype_first.w4.time`,
  `genotype.w4.time`, `merge.w4.time`, logs `*.w4.log`. cap5k: `*.w5.*`. The six block's run 4 (pairs 23-36):
  `six/genotype.w1.time`. Earlier runs: `six/genotype.{log,time}.run1-3`. Per-pair wall times come from the genotype
  logs.
  - The genotyping ran under load from other jobs, so wall times are upper bounds. State the load (each step's start
    line, or the queue log) beside them.
  - Peak memory: GNU time's maximum RSS is the largest single process; the sampler's tree PSS (`*.mem.tsv`) is the
    whole tree. Give both.

## R2. Block-size check (Step 2)
- Work in copies, as the brief says (`block/b{1,2,5,10,20}` of `six/views/main`, and copies of `six/views/all` for the
  direction rows). `ltrpav-stats --block-size` without `--identity` deletes identity.tsv (Task 7 review m1). It is
  harmless in copies without an identity layer; never run it in a view Task 16 will use.
- Copy views without the large linked inputs. A view links to its run (see view.sh), so copy the view directory with
  links preserved (`cp -a`) and check that nothing is written through a link into `six/geno`.

## R3. Reporting
- "Varied and reported, not tuned" (DESIGN 10.4). State plainly any change of verdict under a variant. Name the
  variant that changed it.
- Where you report a D_pav Z, also give its empirical null quantile against the default nulls (max |Z| 1.97) and the
  bottleneck nulls (max |Z| 3.14). Verdicts rest on the bottleneck null (controller ruling (I4), 2026-11-14).
- compare_papers.py (`real/common/`) misreads two rows on six-genome views ("1 roles" and "14 direction"; Task 16
  fixes them) and writes `ltrmix_crosscheck.tsv` without the prefix. If either affects your views, report it.
- Append your memo entry with `cat >> real/memo.md` (append only; never rewrite the file). If you write a dead_ends
  entry, add it the same way to `benchmark_pav/dead_ends.md`.
- At most 8 threads and 15 minutes per command. Snapshot `inputs/*.fai` before and after. Never kill a process.
