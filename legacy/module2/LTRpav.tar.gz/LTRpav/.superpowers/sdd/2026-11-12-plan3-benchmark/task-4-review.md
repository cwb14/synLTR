# Task 4 review: truth, annotations and tracts in sample coordinates

Range 7f5cedb..bd04678 (35257ce Task 3 minors; bd04678 poptruth). Read-only review. Scratch:
`/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t4review/`
(written `$R` below). Env `ltrpav` (nothing installed), `NUMPY_MADVISE_HUGEPAGE=0`, at most 15 threads, every probe
under `timeout 15m`.

## Spec Compliance

| | Requirement | Where | Evidence |
|---|---|---|---|
| ✅ | `alive`: fate intact or partial, each LTR >= COV_PRESENT of its own | poptruth.py:70-72 | oracle (alive set rebuilt from provenance; row sets equal in every pair); test_alive |
| ✅ | `pair_truth`: TRUTH_COLUMNS, one row per alive element of X, name = eid, 1-based ends, origin backbone/sim, events_x/y | poptruth.py:179-190 | oracle compares every column of every row (331,029 rows); test_truth_P_inherited_intact |
| ✅ | G: an N within REFINE_PAD of e's image or site in Y | :111-119, :143-144 | oracle 55,033 G rows; test_truth_G_gap_near_site pins all four pad edges |
| ⚠️ | G never for a copy without image or a broken window (named limit 1, ruling C3) | :28-30 | measured: Strengths item 4 |
| ✅ | Not inherited, simulated host Y did not inherit: outermost such host's truth, plus host_empty on E | :121-128, :146-150 | oracle: 24,798 host_empty rows (5,042 two deep), 46,263 host D, 3,852 host G, 6,724 host O |
| ✅ | O on target overlap: same chrom and host system, target intervals overlap (R2: abs(dpos) < 5); "carries" = holds with an image (C2) | :100-109, :130-134, :150-151 | oracle 3,306 O-overlap rows; test_truth_O_same_target (+4 O, +5 E, -4 O, deleted E, other host E) |
| ✅ | E when cy.site >= 0, else D (R1: no site_lost) | :152 | oracle reads the window from provenance (SNPs, small indels, other insertions transparent): 83,305 E by the site test (108,103 with host_empty), 24,819 window-broken D |
| ✅ | Inherited: S, O (replaced), P, T, D against X's own bases (C1 kept_runs; C2 S needs 0.8 of an LTR) | :153-165 | oracle: 68,229 P, 3,259 T, 12,815 D, 1,646 S, 832 O-replaced; 1,174 shared-loss P rows; 963 of them T under the brief's literal one-liner |
| ✅ | `annotate`: Plan 1's _annotation rules via jitter_bounds and read_tsd; K2P = Copy.k2p; family/superfamily; Name = eid; loads | :193-207 | annotation probe (Strengths, item 5); test_annotation_dropout_bounds, test_annotation_loads |
| ✅ | pair.py: two helpers factored out, draws in the caller in the same order, `ltrpav-sim pair` byte-identical (R3) | pair.py:305-337 | 168 write_pair files byte-identical at 7f5cedb and bd04678; clamp branch byte-identical; test_sim.py:606-625 pins BASE digests |
| ✅ | `tract_bed`: ends lifted with lift_pos; every backbone base lands on the right side | poptruth.py:210-222 | provenance tract check (Strengths, item 6); test_tracts_lifted |
| ❌ | "A payload inserted inside a tract belongs to it" | :38-42, :219 | not met where a tract end lies in a stretch the sample deleted (0.05% of tract bp measured): Important I1, plan-mandated. At a kept end it is reversed against popevents' genealogy: Minor m1 (accepted C3) |
| ✅ | `insertion_rows`: columns of Task 5's insertions.tsv (C4) | :225-249 | test_insertion_rows (exact rows) |
| ✅ | Score join (R4): no new column; scorer reads genome, name, state, flags | score.py:69, :117 | test_score_joins runs `ltrpav-sim score` from the tree: P, E, S precision and recall 1.0 |
| ✅ | Brief's 17 named tests present (test_pair_annotation_unchanged in test_sim.py, Choice 7) | test_poptruth.py, test_sim.py:616 | 20 tests in test_poptruth.py + 1 |
| ✅ | First commit fixes Task 3 M1-M5 | 35257ce | see Strengths, item 7 |
| ✅ | kept_runs (C1): correct for every fate, changes no other field or draw | popbuild.py:145, :749-753, :812-817 | oracle 410,900 copy records equal to provenance; popbuild outputs byte-identical to 7f5cedb on 30 scenarios |
| ✅ | Global constraints: engine untouched, identity cwb14, no trailers, ruff clean | git log; `git diff --name-only` (sim/ and tests/ only) | checked |

## Strengths

1. **Truth agrees with an independent oracle on every row.** `$R/truth_oracle.py`.
   - **Method.** The Task 3 reviewer's naive builder (`$R/oracle.py`) rebuilds each sample as a list of tagged tokens
     (system, coordinate). Each rebuilt sequence is first checked byte-equal to popbuild's, so its token map is
     the provenance of popbuild's own bases.
   - Truth is then read from that provenance, the event lists and Y's gapped sequence alone. It reads no popbuild
     Copy field (fate, site, kept_runs, image, events) and none of poptruth. Fate (for alive) and events come from
     the Task 3 oracle's own rebuilt records. What it reads:
     - X's own bases that Y holds, per LTR, for P/T/D;
     - the solo or replace event Y carries;
     - the window's tokens in Y, transparent to small-indel deletions, in host order, with anything between
       them counted;
     - Ns in Y's gapped sequence within REFINE_PAD of the image or target bases.
   - **Coverage.** 260 drawn landscapes; 331,029 rows over all ordered pairs; every column compared; **0
     mismatches.**
     - Landscapes: 16-leaf and 7-leaf toy trees, msprime genealogies with many trees, forced shared anchors,
       partial-loss-heavy mixes.
     - Gaps: one third at 0, one third at 150 and one third at 600 per Mb.
   - **Named cases, each exercised in this sweep** (counts are rows):

     | Case | Rows |
     |---|---|
     | shared losses read P | 1,174 |
     | ... of which T under the brief's literal one-liner | 963 |
     | private losses on both sides | 534 (P 144, T 195, D 44, G 150, S 1) |
     | host_empty (two deep) | 24,798 (5,042) |
     | clipped solo (T / D) | 92 / 388 |
     | S | 1,646 |
     | O replaced / O overlap | 832 / 3,306 |
     | G (image / site) | 39,952 / 11,229 |
     | E with a SNP in the window | 22,451 |
     | E with a small-indel deletion / insertion in the window | 1,371 / 1,350 |
     | E with another insertion inside the window | 906 |
     | window-broken D | 24,819 |

   - **The oracle can fail.** On a 48-landscape subset (`$R/mut_*.log`), the unmutated code gives 0 mismatches
     on 36,489 rows. Five of six planted poptruth mutants are caught:

     | Mutant | Rows flagged |
     |---|---|
     | P by Y's own_kept / own (the brief's literal one-liner) | 82 |
     | S on fate solo alone | 4 |
     | O counting copies held without an image | 2,872 |
     | innermost not-inherited host | 1,077 |
     | E for every absent copy | 12,284 |
     | G pad 1 bp short | 0 |

     - The G-pad mutant survives because random 100-bp N runs almost never end exactly REFINE_PAD from a site.
     - test_truth_G_gap_near_site kills it; I checked.
     - So the pad edges rest on that unit test, and the rest of the G rule on the oracle.
2. **kept_runs is right for every fate.** 410,900 copy records, every fate, nested backbone elements, minus-strand
   and nested-in-minus insertions: kept_runs equals the own coordinates the sample's tokens hold, LTRs in genome
   order. **0 mismatches.**
   - Popbuild's other outputs are **byte-identical to 7f5cedb** (`$R/identity_dump.py`, `ident_*.pkl`):
     - 30 drawn landscapes built with payload draws on (mu 2e-7, copy_noise 0.01), then add_gaps at 400/Mb;
     - compared: sequences, lift maps, every Copy field except kept_runs, gapped sequences and gap lists;
     - so the field adds no draw and changes nothing else.
3. **pair.py is byte-identical** (`$R/pair_dump.py`).
   - write_pair at 7f5cedb and bd04678, each snapshot imported alone, on test_sim's world, 4 parameter sets
     (default; dropout 0.3 + jitter 1; jitter 1; jitter 0.5) x 6 seeds: all 168 files (48 GFF3) identical.
   - The LTR-clamp and sequence-end branches, untested in the suite, were probed directly (`$R/clamp_dump.py`):
     1-3 bp LTRs, elements at both sequence ends, jitter 1, 300 seeds. 1,500 records identical at both versions.
   - By inspection the draws (`rng.random(2)`, `rng.integers(-3, 4, 2)`) stay in the caller, in order
     (pair.py:311-312).
4. **Named limit 1 measured.** On the oracle subset, D rows where Plan 1's flank anchors (the nearest X bases
   beside e that Y holds) lie within REFINE_PAD of an N:
   - 143 of 4,364 (3.3%) at 150 gaps/Mb;
   - 821 of 4,705 (17%) at 600/Mb;
   - linear scaling gives about 0.3% at a realistic 15/Mb, within the implementer's < 1% estimate. The limit is
     small and named.
5. **Annotations load and follow Plan 1** (`$R/annot_check.py`). 16 drawn landscapes, every sample, half of
   them gapped, dropout 0, jitter 0 and 1: 3,166 records, **0 problems**. Checked:
   - the annotated set is the alive set;
   - eid = make_eid and Name = eid;
   - ends within +-3, inner LTR ends fixed;
   - TSD equals the bases beside the reported ends (None otherwise);
   - all 1,280 insertion TSDs read without jitter equal Copy.tsd;
   - K2P_d = Copy.k2p, family, superfamily and strand;
   - every record survives write_gff3 -> load_annotation (1,636 nested records with parents).
6. **Tracts: every backbone base lands right** (`$R/tract_check.py`, `tract_classify.py`, `tract_quant.py`).
   - Method: the token provenance gives every genome base a backbone point.
   - Over 27,786 random and adversarial tracts (194 M base checks), every backbone base in [l, r) lies in the
     lifted record and every other base outside it.
   - A record is kept exactly when a backbone base of the tract survives.
   - Payload bases follow the docstring's rule everywhere except at a tract end inside a deleted stretch (I1).
7. **Task 3 minors M1-M5, each checked.**
   - **M1.** The Task 3 reviewer's four surviving mutants are each killed by exactly the new test for its rule:
     - clip_not_reported: test_clipped_event;
     - derived_snp_ignores_gone: test_backbone_k2p_skips_removed_snps;
     - rep_at_start: test_replace_anchored_at_end;
     - indel_after_payload_flip: test_indel_bases_after_ltr_payloads.
   - **M2, M3:** docstring clauses at popbuild.py:61-62 and :37-39.
   - **M4:** popbuild.py:433-435, :446-451, :461-488. The input checks reject bad positions and off-branch times
     before any draw. The pos bound [5, L) is justified: pos = L had no tree and crashed. The backbone loss tree
     (element start) matches draw_events (popevents.py:498-509).
   - **M5:** popbuild.py:908-949. The count is returned and documented, and test_gap_off_chromosome_counted uses
     an exact Binomial(300, 1/2) bound.
8. **Tests are exact and honest.**
   - One test per truth rule, with exact states on engineered histories, including boundary pairs:
     - pad edges +-1;
     - LTR 239/240;
     - MIN_SEG 79/80;
     - dpos 4/5.
   - Bounds come from stated distributions (binomial 3 sd).
   - test_pair_annotation_unchanged pins BASE digests rather than re-running the new code (R3).

## Issues

### Critical
None.

### Important

**I1 (plan-mandated). tract_bed misplaces payloads at a tract end the sample deleted** (poptruth.py:38-42, :219).
- **Brief.** It mandates the method ("lifts each backbone tract's ends with lift_pos") and also the rule ("a payload
  inserted inside a tract belongs to it"). The two conflict at a deleted end.
- **The implementation** follows the method, while its docstring asserts the rule ("a payload anchored inside one,
  l < pos <= r, lies in it"). That assertion is false there.
- Backbone bases are always right. Tract truth is a scoring yardstick (bp precision and recall, tract FDR, element
  AUROC "inside a true tract"), so this is reported as Important. The measured size is small: the controller may
  rule a named limit (docstring + test) sufficient.
- **Cause.** lift_pos maps a deleted base to the next kept base (popbuild Lift), and that base lies after whatever
  is anchored before it.
  - At a right end r: a payload anchored at the stretch's first kept base r1 > r is counted in the tract,
    though it is outside it by the docstring's rule and by its tree.
  - At a left end l: a payload anchored at l1 is left out, though it is inside by both.
- **Example.** partial7 seed 1, S4, tract [10,207, 11,502).
  - Bases 11,502-12,606 are deleted in S4.
  - The 5 payload bases anchored at 12,607 (genome 18,792-18,796) lie in the lifted [17,634, 18,797).
- **Measured** (`$R/tract_quant.py`): uniform ends, 16,800 tracts of 1-20 kb, 12 lossy landscapes; 33% of ends lie
  in a stretch the sample deleted.
  - Backbone bases: none misplaced.
  - Payload bases misplaced: 59,253 (0.12% of payload bases in tracts; 0.05% of all tract bp).
  - 8.3% of tracts are touched.
  - Replacing sequences sit where their loss's tree (drawn at the element start) puts them, except at an exact
    element-start end.
- Adversarial ends (`$R/tract_classify.py`): ends on anchors, +-1 and random, 10,986 tracts.
  - 1,732 tracts hold a misplaced item;
  - every one is an item anchored at the first kept base after a deleted end.
- **Impact:** far below any tract bar (bp precision and recall by length bins from 50 kb).
- **Coverage gap.** test_tracts_lifted misses it:
  - its deletion [45,000, 49,000) ends before the tract end 50,000;
  - its deleted tract has nothing anchored after it.
- **Fix, either:**
  - name it in the docstring as a limit of this size; or
  - lift a deleted end to just before what is anchored at the next kept base. That needs the anchored lengths,
    or a Lift that records the junction.

  Either way, add one test with a payload anchored at the first kept base after a deleted tract end.

### Minor

**m1. A payload exactly at a kept tract end goes against popevents' genealogy** (poptruth.py:38-42; accepted
convention, C3).
- popevents draws a primary insertion on the tree at its continuous position x, with pos = int(x)
  (popevents.py:485-504), so its lineage is base pos's.
- The convention (l < pos <= r) therefore puts:
  - a payload at pos == l (tree inside) outside;
  - one at pos == r (tree outside) inside.
- The docstring's reason ("the tract holding base pos - 1, the last target base") does not say this.
- Accepted under C3. It is rare: about 2 x tracts x insertions / L per chromosome.
- Fix: one clause in the docstring naming the mismatch.

**m2. jitter_bounds' LTR-clamp and sequence-end branches have no test** (pair.py:323-331; ruling C6).
- The code moved verbatim, and the probe above shows both branches byte-identical to 7f5cedb.
- Fix: a direct unit test of jitter_bounds with a 1-bp LTR and an element at position 0 and at `length`
  (3 asserts).

**m3. test_poptruth imports builder helpers from another test module** (test_poptruth.py:30, `from test_popbuild
import ...`; Choice 8). This couples two test files. Move `build`, `events`, `ins_at`, `loss_at`, `toy7` and `DONORS`
to `poptoy` when Task 3's tests are next touched.

## Assessment

**Needs fixes:** one plan-mandated Important (I1), small. Minimal fix: name the limit in tract_bed's docstring and
add one test; or lift deleted ends anchor-aware; or a controller ruling accepting it as named.
- **Spec:** compliant, except I1.
  - Every other brief item, R1-R5 and the ledger rulings C1-C4 are implemented as ruled.
  - ⚠️ G limit: an accepted named limit.
  - ❌ tract payload rule: I1 (plan-mandated); m1 is an accepted convention.
- **Truth tables:** no fix needed. pair_truth, alive, kept_runs and annotate are verified exact (below).
- **Quality:** an independent truth oracle, which reads only provenance and sequence and which catches 5 of 6 planted
  mutants (the sixth, a 1-bp pad shift, is killed by test_truth_G_gap_near_site), agrees with pair_truth on all
  331,029 rows of 260 landscapes, and with kept_runs on 410,900 records.
  Popbuild and `ltrpav-sim pair` are byte-identical to 7f5cedb where they must be. Annotations round-trip.
  Tracts place every backbone base right; payloads are right except at tract ends the sample deleted (I1, 0.05% of
  tract bp). Name or fix that before Task 5 writes `tracts.<label>.bed`.

**Suite** (implementer's detached run, `p3t4/suite.log`, `suite.done`):
- started 20:21:54, 6 s after commit bd04678, on a clean tree; mutants ran in copies of src;
- `suite.done` = 0;
- 1,249 tests, all passed (no F, E, s or x; no summary line printed).
- Focused re-run here: 50 tests passed, `-W error`; `ruff check` clean.

## Re-review (fix round 1)

Commit 239eb8f on bd04678; rulings: progress.md "Task 4: Ruling (I1)" (name, do not re-engineer; a test pins the
named behavior) and "(m1-m3)" (fix all). Read-only; focused tests only.

| Finding | Ruling | Status | Where | Evidence |
|---|---|---|---|---|
| I1 | name the deleted-end limit with its size; pin it in a test | ✅ addressed | poptruth.py:38-46 (module docstring), :215-220 (tract_bed docstring); test_poptruth.py:409-427 | The false claim is gone. The docstring now says backbone bases are exact, payloads between kept ends lie in the record, and a deleted end lifts to the next kept base with a payload there on the wrong side (0.05% of tract bp, 8.3% of tracts, never a backbone base). test_tracts_deleted_end is checked by hand (below). |
| m1 | docstring clause naming the genealogy mismatch at a kept end | ✅ addressed | poptruth.py:41-43 | "one anchored exactly at r lies in the tract and one anchored exactly at l does not, the reverse of its genealogy (popevents draws an insertion's tree at base pos)" |
| m2 | an LTR-clamp test | ✅ addressed | test_sim.py:628-640 | 7 exact cases, each recomputed by hand. It kills the LTR-clamp mutant (b - a for b - 1 - a) and a mutant without the sequence-end clamps; checked here. |
| m3 | shared builder helpers into tests/poptoy.py | ✅ addressed | poptoy.py:9-12, :124-182; test_popbuild.py:22; test_poptruth.py:30 | see Regressions |

**test_tracts_deleted_end, checked by hand.**
- S0 deletes [20,000, 22,000) and [59,600, 61,600); the payloads are anchored at 22,000 and 61,600.
- For tract [21,000, 60,500) the record is [20,000 + pl, 57,600 + pl + pr): the left payload is left out and the
  right one put in, both pinned exactly.
- S2 keeps both ends: the record [21,000, 60,500 + pl) pins the anchor convention.

**Regressions (m3).**
- **Helpers.** TREE7, EXACT, fixed_donors/DONORS, toy7, below, ins_at, loss_at, events, build and other in poptoy.py
  are textually the bd04678 helpers. The only differences:
  - module qualification (`poptoy.rand_bases` -> `rand_bases`, `poptoy.toy_ts` -> `toy_ts`);
  - build's `rng(seed)` -> `np.random.default_rng(seed)`, the same generator.
- **Test bodies.** Every test body in test_popbuild.py, from `expected_body` on, is identical to bd04678's.
  test_poptruth.py changes only its import line and adds one test.
- **Inventory.** Test counts: test_popbuild 28 -> 28 (same names), test_poptruth 20 -> 21, test_sim 28 -> 29.
  Nothing was dropped.
- **Imports.** No module imports test_popbuild any more.
- **poptoy's new imports** (popbuild, popevents, popmodel) need no msprime at import time.
- The four poptoy users (test_popbuild, test_poptruth, test_popevents, test_popmodel) pass.
- **Focused run here** (`-W error -m "not slow"`): test_poptruth, test_popbuild, test_popmodel, test_popevents,
  test_jitter_bounds_clamps and test_pair_annotation_unchanged, 92 passed. `ruff check .` clean.
- **Source.** No source logic changed: poptruth.py's diff is docstrings only.

**New issues.** None Critical or Important.
- Nit, no action needed: the docstring's "8.3% of tracts touched" was measured on 1-20 kb tracts in lossy toy
  landscapes. The bp share (0.05%) is the transferable figure.

**Suite** (`p3t4/fix1/suite.log`, `suite.done`): started 21:21:32, 1 s after commit 239eb8f; `suite.done` = 0; 1251 tests, all passed (no F, E, s or x; no summary line printed). That is 1,249 + 2 new tests.

**Verdict: Approved.** I1, m1, m2 and m3 are addressed as ruled; no regression.
