# Task 4 report: truth, annotations and tracts in sample coordinates

Status: DONE_WITH_CONCERNS. The concerns are at the end. Concern 1 needs a ruling: to follow Plan 1's P rule I added
a field to popbuild's Copy, which is outside the brief's file list.

BASE 7f5cedb, branch plan3-benchmark. Scratch: `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t4/`
(written `$S` below).

## Commits
| Commit | Subject |
|---|---|
| 35257ce | Popbuild review minors: four rule tests, named simplifications, input checks |
| bd04678 | Add population truth, annotations and lifted tracts |

- Both commits use the existing identity (cwb14). No trailers, no push.
- `git diff --stat 7f5cedb bd04678` lists 7 files, all under `src/ltrpav/sim/` and `tests/`.

## Files
- **35257ce:**
  - `src/ltrpav/sim/popbuild.py`: docstrings (M2, M3, and an "Input checks" paragraph); `_check` and the new
    `_check_times` (M4); `add_gaps` now returns per-genome counts (M5). `_payloads` reuses the trees from
    `_check_times`.
  - `tests/test_popbuild.py`: 6 new tests.
- **bd04678:**
  - `src/ltrpav/sim/poptruth.py` (new, 249 lines): `alive`, `pair_truth`, `annotate`, `tract_bed`, `insertion_rows`,
    `INSERTION_COLUMNS`.
  - `src/ltrpav/sim/pair.py`: `jitter_bounds` and `read_tsd` are factored out of `_annotation`, which now calls them.
    The draws stay in the caller, in the same order.
  - `src/ltrpav/sim/popbuild.py`: `Copy.kept_runs` (Choice 1), with its docstring entry.
  - `tests/test_poptruth.py` (new, 21 tests).
  - `tests/test_popbuild.py`: exact `kept_runs` assertions in two tests, plus a sum invariant on a drawn landscape.
  - `tests/test_sim.py`: `test_pair_annotation_unchanged` (Choice 7).
  - `tests/test_popmodel.py`: `ltrpav.sim.poptruth` joins the import-without-msprime check.

## First commit: Task 3 review minors
- **M1. Four rule tests,** exact values. Each kills its mutant (log: `$S/mut1/mutants.log`, 11/11 killed).

  | Test | Rule pinned | Mutants killed |
  |---|---|---|
  | `test_clipped_event` | The "clipped" event (:664) follows own loss kinds when another element's removal takes own bases. Cases: `[del_partial, clipped]`, `[del_partial]`, `[clipped]`, `[]`. It also holds on an insertion's system (a nested del_flank takes host bases). | append dropped; `!= eid` flipped to `==`; system read as the backbone only |
  | `test_backbone_k2p_skips_removed_snps` | Derived SNPs count only on kept own LTR bases (:711). Of 4 derived SNPs, 2 are taken by a neighbor's flank and 1 by an indel deletion, so k2p = JC(p0 + 1/300); a sample with nothing removed gets JC(p0 + 4/300). | gone-check removed |
  | `test_replace_anchored_at_end` | The replacing sequence goes after insertions anchored at the element's start and before those anchored at its end (:567). The exact sequence is `bb[:s] + pay_start + rep + pay_end + bb[end:]`. | anchored at start; ordered after end anchors |
  | `test_indel_bases_after_ltr_payloads` | Indel bases go after the LTR payload at one anchor (:574), so the TSD copies stay beside the body. The bases are drawn once: a sample with only the indel gets the same bases. | indel ordered before payloads |
- **M2.** The k2p docstring entry now says source K is read as K at the root (ruling C1), so each sample adds the
  derived SNPs of its root-to-sample path: about 2 mu T_root above source K.
- **M3.** The Payloads paragraph names it as a simplification that replacing sequences and inserted indel bases take
  no substitutions.
- **M4.** `_check` validates hand-built input:
  - **Positions.** An insertion's base pos and its target bases lie in its host's system: [TSD_DEFAULT, L) on the
    backbone, [TSD_DEFAULT, len(body)) in a host.
    - The review wrote [TSD_DEFAULT, L]. I used L exclusive because base pos must exist, and pos = L also had no
      tree: `_trees_at` returned None and the build crashed with AttributeError.
  - **Times.** `_check_times` requires node time <= time < parent time on the tree at the event's position:
    - an insertion: its own position; a nested one: its primary's;
    - a backbone loss: the element's start; an insertion's loss: its primary's position.

    A root has no branch above it. A node missing from the tree is checked here too (the check moved from
    `_payloads`).
  - **Element bounds.** I also added a check that backbone elements lie on the backbone.
  - **Test.** `test_positions_and_times_checked` covers each bound on both sides for primaries, nested insertions,
    backbone losses and insertion losses, plus the root case and an unknown node. It also builds the exact bounds
    that must pass: pos 5 and L - 1, nested 5 and 2,599, and a time equal to the node's.
  - **Mutants killed:** loosened pos bounds, the parent time allowed, loss times unchecked.
- **M5.** `add_gaps` returns `list[int]`: per genome, the near runs that fell wholly off a chromosome. The docstring
  says so, and the runs are still not written.
  - `test_gap_off_chromosome_counted` pins it. The only near targets are a chromosome's two ends, so exactly half of
    the near runs fall off. With 300 near runs, the count is within 3 SE of 150, and `off + len(gaps) == n`.
  - `test_gap_rate_and_near_share` now asserts `[0]` where nothing falls off.
  - Mutant killed: not counted.
- Suite of popbuild + popevents + popmodel before the commit: all passed. ruff clean.

## Second commit: tests and what each pins
All tests build genomes with popbuild from TREE7 (`toy_ts`; samples S0-S6) with hand-placed events, and assert exact
states. The builder helpers are imported from `test_popbuild` (Choice 8).

| Test | Pins |
|---|---|
| `test_alive` | intact, or partial with each LTR >= 0.8 x own (240/300 alive; 239/300 on either LTR dead); solo, deleted, replaced and absent are never alive |
| `test_truth_P_inherited_intact` | the full rows of S0 in S1, exact: TRUTH_COLUMNS in order, name = eid, 1-based start/end, origin backbone/sim, empty flags and events; P in every carrier |
| `test_truth_P_shared_loss` | a del_partial shared by X and Y (own_kept / own 0.57 and 0.55) reads **P**; S4 → P / E; the reverse (intact X = S4 read in S0) reads T; `events_x` = `del_partial` |
| `test_truth_E_never_inserted` | not inherited, window intact → E (`site` 99,995), including an insertion inside a backbone element; no flags or events_y |
| `test_truth_S_solo_in_y` | Y's own solo → S (backbone, and an insertion on strand −); `events_y` solo. A solo then clipped to 100 of 300 bp reads **T** (Plan 1's ≥ 0.8 LTR condition; Choice 2) |
| `test_truth_T_partial` | Y holds 3,100/4,600 → T. Each copy has its own private 1,000-bp loss: S2 holds 2,600 of S0's 3,600 (0.72) → T both ways, though both own_kept = 3,600. The LTR boundary: 239/300 of an LTR → T, 240/300 → P. MIN_SEG boundary: 80 → T, 79 → D |
| `test_truth_D_deleted_in_y` | own del_flank in Y → D; a nested insertion taken with its host → D (events_y `deleted`); also E:host_empty for the nested one where Y never got the host |
| `test_truth_D_site_deleted` | R1: a removal reaching the window's first base (p − 15) → site −1 → D; one ending just before it → E; a nested insertion whose host Y holds but lost → D, and E where the host stays |
| `test_truth_O_replaced` | Y's own replace → O (backbone and insertion) |
| `test_truth_O_same_target` | Y holds an insertion whose target overlaps e's: Δpos +4 → O, +5 (touching) → E, −4 → O. An overlapping one whose copy Y deleted → E. The same pos in another host's system → E |
| `test_truth_host_empty` | depth 1 and 2: outermost not-inherited host's truth plus host_empty when E (Y has h but not e → e2 reads e's E); host D → D for all; an N at the host's site → G for host and nested |
| `test_truth_G_gap_near_site` | an N in Y at site − 150 → G, at −151 → E; at site + 5 − 1 + 150 → G, at +155 → E. Same on an inherited image: P outside the pad, G inside the image |
| `test_truth_E_with_snp_and_indel_beside_site` | a SNP in the target and 2-bp indels (deletion and insertion) 5 bp from the target → E |
| `test_truth_E_with_other_insertion_in_window` | Y-only insertions whose targets lie 4 bp from e's target, either side, inside the window → E |
| `test_truth_input_checks` | same label, different chromosomes, missing copies → ValueError |
| `test_annotation_dropout_bounds` | 2,000 copies, dropout 0.1: count within 0.9n ± 3 sd; non-alive copies are never annotated. With jitter 1: ends within ±3, LTR inner ends fixed, outer ends moved with them, > 90% moved |
| `test_annotation_loads` | 7 alive copies (backbone, nested backbone, primary ±, nested in a primary, inside a backbone element, partial) → write_gff3 → load_annotation: count, Name == eid, eid = make_eid, coordinates, strand, TSD == Copy.tsd (5 bp), K2P_d == Copy.k2p (not None), family/superfamily, nesting parents |
| `test_tracts_lifted` | exact lifted tracts for S0 (payloads, nested payload, deletion, an indel on each side, a tract inside a deleted element dropped) and S2; identity in S4. Every copy whose point lies in a tract lies in a lifted tract, and one wholly outside lies outside all (30 checked). A payload at r is in the tract, one at l is not. A bad chromosome index → ValueError |
| `test_insertion_rows` | exact rows: columns and order, host "." / iid, carriers, survivors (alive) and the fate per sample; bad chromosome or carrier → ValueError |
| `test_score_joins` | truth TSV (both directions in one file) + elements TSV + calls equal to the truth → `ltrpav-sim score` from the current tree: P, E and S precision and recall 1.0000; n_scored 4; no missing calls |
| `test_pair_annotation_unchanged` (test_sim.py) | sha256 of `write_pair`'s A.gff3 and B.gff3, computed at 7f5cedb, at (dropout 0.1, jitter 0.05, seed 11) and (0.3, 1.0, 12) |
| `test_popbuild`: `kept_runs` | exact runs for a backbone solo, a minus-strand insertion solo (LTRs flipped to genome order), a union of del_partials, an indel deletion, and an absent copy; on a drawn landscape, every copy's run sums equal (ltr_kept[0], own_kept, ltr_kept[1]) |

**Mutants (`$S/mut2/mutants.log`).** 25 of 25 poptruth mutants are killed:
- G pad ±1; G never; G on the site only;
- innermost host; no host_empty; host rule skipped;
- O overlap 3 bp; touching counts; any host; copies without an image;
- E for any absent copy;
- S on fate alone; O replaced dropped;
- P by Y's own_kept / own (the brief's literal reading); P by a count ratio; P ignoring LTRs;
- T strict; alive strict; alive without the LTR rule;
- tract: empty kept; tract: start after anchors at l;
- annotate without jitter; annotate with no K;
- survivors = carriers.

"P ignoring LTRs" survived the first run, so I added the LTR boundary to `test_truth_T_partial`.

`test_pair_annotation_unchanged` kills a draw-order mutant of `_annotation`. An LTR-clamp mutant (b − a for
b − 1 − a) survives it: the clamp acts only on LTRs under 4 bp, which the world never has. The code moved verbatim.

## TDD evidence
- **M1 tests** pin rules that already existed, so they passed on the current code. The evidence is the mutant
  run above: 4 of 7 of the reviewer's survivors are now killed, plus 4 more mutants.
- **M4 and M5 tests** were run before the implementation and failed:
  - `test_positions_and_times_checked`: AttributeError, `'NoneType' object has no attribute 'time'` (the pos = L
    crash);
  - `test_gap_off_chromosome_counted`: TypeError, cannot unpack None;
  - `test_gap_rate_and_near_share`: `assert None == [0]`.

  They passed after the implementation.
- **Task 4:** `tests/test_poptruth.py` failed at collection with `ModuleNotFoundError: No module named
  'ltrpav.sim.poptruth'` (`$S/tdd_red.log`). The `kept_runs` assertions in test_popbuild failed with AttributeError
  in 3 tests. Then:
  - after implementation: 19 of 20 passed on the first run;
  - the failure was my own miscounted threshold in `test_tracts_lifted` (30 expected checks, not ≥ 40);
  - then all passed.
- `test_pair_annotation_unchanged` was written with digests computed from a `git archive 7f5cedb` snapshot
  (`$S/pairdigest/digest.py`, `base.txt`). It passed before and after the refactor.

## Choices
1. **P, T and S are read against X's own bases, through a new `Copy.kept_runs`. This deviates from the brief's
   summary, and it touches popbuild.**
   - The brief says "P when own_kept >= COV_PRESENT * own". Read literally, Y's copy is measured against the
     element's original length. But the brief also says these are Plan 1's rules, and Plan 1's P is "Y holds
     >= COV_PRESENT of e's own ids", where e is the element as it stands in X.
   - The two differ whenever X and Y share a loss. Under C1 every backbone element sits at the root with about one
     expected loss on the root-to-sample path, so shared losses are the norm.
   - In the 5-Mb probe (below), the literal rule changes 1,995 of 11,248 inherited P/T/D rows:
     - P → T: 1,566 in pairs across taxa, 408 in pairs within a taxon;
     - T → P: 21.

     The engine would call those elements P, since Y holds X's copy whole. So the literal rule would score correct
     calls as errors.
   - A count ratio (Y's own_kept / X's own_kept) is not enough. When X and Y each have a private loss (common in
     outgroup pairs, where nothing is shared), it calls 0.72 coverage P (pinned in `test_truth_T_partial`).
   - The exact rule needs the kept bases themselves, which the Copy did not record. So popbuild now records them:
     - `kept_runs`: (left LTR, own, right LTR) runs in the element's own system, LTRs in genome order;
     - it defaults to `((), (), ())` and adds no draws;
     - each run sum equals ltr_kept or own_kept (tested).
   - Verified independently in the probe: 0 mismatches over 368,578 backbone positions against the lift map
     (p is kept iff `lift_pos(p) != lift_pos(p + 1)`).
   - Truth reads these runs; it re-derives nothing (R2).
   - If this is ruled out, the alternative is the literal rule and its 18% wrong rows.
2. **S needs Plan 1's condition:** Y's copy is solo and holds >= COV_PRESENT of X's shorter own LTR. The brief's
   summary says "S on fate solo". A solo that a later deletion clipped to 100 of 300 bp therefore reads T (tested).
   The fate alone would call it S.
3. **"Y carries another insertion" (O) is read as "Y holds it with an image"**, Plan 1's "still spans sequence".
   - An overlapping insertion whose copy Y deleted is not O. Its own flank deletion usually breaks e's window, so e
     reads D.
   - Overlap means the target-base intervals [pos − 5, pos) intersect in the same chromosome and host system (R2):
     |Δpos| < 5. Tested at 4 and 5.
4. **G** checks an N within REFINE_PAD of Y's image ([start, end)) or Y's site ([site, site + 5)).
   - **Named limit:** a copy Y holds without an image (deleted), or an absent one with a broken window, has no site in
     Task 3's records, so it is never G. Plan 1 read flank anchors there.
   - Effect: a uniform gap within 150 bp of a deletion junction leaves truth D where the engine may say G. With
     uniform gaps at per_mb, that is about per_mb × 300 bp / 1 Mb of D rows (under 1% at 15 gaps/Mb).
5. **Tract boundaries** follow the brief exactly: [lift_pos(l), lift_pos(r)).
   - A payload anchored at r (before base r) falls in the tract; one anchored at l does not. The payload goes with
     its last target base, pos − 1.
   - Genealogically an insertion's tree is base pos's, so an insertion exactly at a breakpoint is attributed to the
     neighboring tract. This is rare, and named in the docstring.
   - Tracts whose bases are all removed are left out. Adjacent tracts whose gap was deleted stay as two touching
     records.
6. **insertion_rows columns.**
   - The Task 4 brief gives only the signature. I took the columns from `task-5-brief.md` line 52: "iid, chrom, host,
     pos, time, node, depth, family, carriers, survivors, fate per sample".
     - To find them I read lines 30-80 of task-5-brief.md. That is outside the reading list; I used nothing else
       from it.
   - My readings:
     - chrom = seqid;
     - carriers and survivors are comma-joined sample labels;
     - survivors = samples whose copy is alive (the samples with a truth row for it);
     - per sample, a `fate_<label>` column holding Copy.fate;
     - "." for no host, no family or no survivors.
   - `INSERTION_COLUMNS` holds the fixed part.
   - It checks that genomes share chromosomes, that every carrier index has a genome, and that each copy lies on the
     given chromosome index (`Copy.chrom == ch`).
7. **`test_pair_annotation_unchanged` lives in `tests/test_sim.py`, not test_poptruth.py.**
   - It tests pair.py, needs no msprime, and reuses test_sim's `world`.
   - In test_poptruth.py, the module-level `importorskip("msprime")` would skip it without the extra.
8. **test_poptruth imports the event helpers from `test_popbuild`** (`build`, `events`, `ins_at`, `loss_at`, `toy7`,
   `DONORS`) rather than copying about 40 lines. Moving them to `poptoy` would touch Task 3's test file more.
9. **Truth rows are ordered by (chrom, start, −end, eid) in X**, as Plan 1's alive_elements. annotate uses the same
   order, so its RNG draws are fixed by the genome alone.
10. **G checks use `bytes.find(b"N", lo, hi)` on Y's chromosome**: no cumulative N array, so memory is flat on
    Gb-scale genomes. popbuild upper-cases every sequence, so only "N" occurs.

## pair.py byte identity (R3)
- **Before and after.** pair.py is unchanged from 7f5cedb up to the refactor (`git diff --quiet 7f5cedb HEAD`).
- **Test.** `test_pair_annotation_unchanged` holds BASE digests computed from a `git archive 7f5cedb` snapshot.
- **Every output** (`$S/pairdigest/outputs.py`; `base_all.txt`, `head_all.txt`). Each snapshot, imported alone (its
  `ltrpav.__file__` asserted inside it), wrote:
  - write_pair on test_sim's world, for 5 seeds (11-15) × 2 parameter sets (scale 3 at the defaults; scale 2 with
    dropout 0.3 and jitter 1.0): 70 files (A.fa, B.fa, A.gff3, B.gff3, truth.tsv, samples.tsv, params.json);
  - `ltrpav-sim pair` (the CLI) on a planted FASTA and GFF3 for seeds 4 and 9: 14 files.
- **Result:** `cmp` shows all 84 sha256 lines identical between 7f5cedb and bd04678.
- **Sensitivity:** the test kills a draw-order mutant of `_annotation`.

## Engine fingerprints
- Method: `git archive` snapshots of 12d3e6c and bd04678, each imported alone. Outputs: `$S/fp_12d3e6c.txt` and
  `$S/fp_bd04678.txt`.
- Result: all 7 `STAGE_MODULES` fingerprints are **identical**:
  - elements a78af75d…;
  - anchor, raw, blastdb ebbfd97f…;
  - mm2_index 28f6fc79…;
  - genotype_pair, genotype_chunk 52071c27….
- No `ltrpav.sim` module is in any stage set, so pair.py and truth.py were safe to edit (checked before editing);
  truth.py is unchanged.

## 5-Mb probe
`$S/probe/probe_truth.py`, log `probe.log`, `probe.time`. Run in the foreground under `timeout 15m` with 4 BLAS/OMP
threads.

**Setup:** Task 3's landscape:
- Demog f = 0.18, ancestry seed 11, 57,794 trees;
- elements every ~5 kb with source K 0.01; 50 donors; default Rates;
- 2,325 insertions and 1,926 losses;
- built for all 7 samples, with gaps at 10 per Mb.

**Results:**
- **pair_truth:** 42 ordered pairs in 1.2 s, 24,468 rows.
- **Invariants, 0 violations:**
  - an inherited copy never reads E;
  - a non-inherited one never reads P, S or T;
  - host_empty only on E;
  - backbone elements are always inherited.
- **States:**

  | Origin | Inherited by Y | States |
  |---|---|---|
  | backbone | yes | P 3,098, G 1,006, O 650, T 628, D 560, S 424 |
  | sim | yes | P 5,297, D 1,231, G 885, T 434, S 180, O 172 |
  | sim | no | E 7,289, D 2,489, G 123, O 2 |

  G is high because this landscape is dense: elements cover about 70% of the backbone, and a gap inside an image is
  G.
- **Literal P rule** (Choice 1): it would change 1,995 of 11,248 inherited P/T/D rows.
- **kept_runs against the lift map:** 0 mismatches over 368,578 positions.
- **Annotation round trip:**
  - annotate → write_gff3 → load_annotation for all 7 genomes in 2.5 s; every element loads;
  - annotated share 0.883-0.912 (dropout 0.1);
  - the TSD is read for 70-78% of annotated copies; SNPs in the flanks make up the rest, which `infer_tsd` covers on
    load.
- **Tracts:** popmodel.tracts gave 57 tracts in 2 samples. 287 copies lie inside a tract and 4,428 outside; 0 are
  misplaced.
- **insertion_rows:** 2,325 rows, 17 columns.
- **Cost:** 1:14 wall, 0.38 GB peak RSS.

## Suite
- Run detached as specified (bash -c wrapper):
  - the wrapper PID 761641 has SID 761641 and PPID 1;
  - pytest (761649) runs in that session.
- Log: `$S/suite.log`; exit code in `$S/suite.done`. Result: see the end of this file.
- `ruff check .`: All checks passed.

## Concerns
1. **Needs a ruling: X-relative P, T and S through `Copy.kept_runs`** (Choice 1). It is a popbuild field outside the
   brief's file list. I believe it is required for correct truth, because the literal rule mislabels about 18% of
   inherited rows. If it is ruled out, revert the field and the three coverage lines in `_Truth._state`.
2. **S needs Plan 1's 80%-of-an-LTR condition** (Choice 2), and O reads "carries" as "holds with an image" (Choice
   3). Both follow Plan 1 rather than the brief's one-line summary.
3. **Named limits:**
   - deleted copies and broken windows are never G (Choice 4);
   - a tract-boundary insertion goes with base pos − 1 (Choice 5);
   - O does not ask whether X also carries the overlapping insertion (in the docstring).
4. **For Task 5:**
   - **Chromosome indexes.** `build_chrom`'s `chrom` must be the 0-based index into `PopGenome.seqs`.
     - `pair_truth`, `annotate`, `add_gaps`, `tract_bed` and `insertion_rows` all index `seqids`, `seqs` and `lift`
       by `Copy.chrom`, and `insertion_rows` checks it.
     - `draw_events`' `chrom` keyword only numbers iids, so it may be 1-based (c01-c10).
   - **Backbone eids must be unique across chromosomes.** Truth names are eids, and `ltrpav-sim score` requires a
     unique name per genome X. Plan 1's numbering (bb0001…) restarts per call. iids already carry the chromosome.
   - **One truth file per ordered pair, or both directions in one file.** score keeps rows with genome == X, so several
     Ys for one X in one file would collide. `truth/<X>__<Y>.tsv` is right.
   - **Arguments in sample order.** `insertion_rows(genomes, ...)` takes the genomes in sample order (sample_labels
     order: Ins.carriers indexes them). `tract_bed(g, {c: tracts(ts_c, d).get(sample_index, [])})`.
   - **add_gaps' new return value** (off-chromosome near runs per genome) belongs in params.json's realized counts.
   - **Field order and nested rows.** annotate takes the per-genome stream `[seed, 200, g]`. Rows are dicts in column
     order (`TRUTH_COLUMNS`; `INSERTION_COLUMNS` + `fate_<label>`).
5. The LTR-clamp branch of `jitter_bounds` (LTRs under 4 bp) is not exercised by any test. The code is moved
   verbatim, and the byte-identity runs cover the other branches.

## Fix round 1 (review task-4-review.md; controller rulings I1, m1-m3)

Commit 239eb8f "Name the deleted tract-end limit, test jitter_bounds clamps, share pop test helpers". It changes
poptruth.py's docstrings only, plus tests. The truth tables are unchanged, as ruled.

**Earlier suite (bd04678):** `suite.done` = 0; 1,249 pass markers; no F, E, s or x; no summary line printed.

- **I1.** The module docstring's Tracts paragraph and tract_bed's docstring now name the limit and its measured size.
  - The limit: a tract end that falls in a stretch the sample deleted lifts to the next kept base. A payload anchored
    at that base then lands on the wrong side: inside the record at a right end, outside it at a left end.
  - The size, from the review: 0.05% of tract bp, 8.3% of tracts touched, never a backbone base.
  - The false claim "a payload inserted inside a tract belongs to it" is gone. It now reads: every backbone base
    lands exactly; payloads between kept ends lie in the record.
  - `test_tracts_deleted_end` pins the behavior with exact intervals:
    - In S0, deletions [20,000, 22,000) and [59,600, 61,600) cover the left end 21,000 and the right end 60,500 of
      tract [21,000, 60,500). Payloads are anchored at 22,000 and 61,600 (the first kept bases).
      - The record is [20,000 + pl, 57,600 + pl + pr): the left payload, at [20,000, ...), is left out, and the
        right payload, at 57,600 + pl, is inside.
    - In S2 the ends are kept: the record is [21,000, 60,500 + pl), so the anchor convention holds.
- **m1.** A clause in the same paragraph: at a kept end a payload is read by the anchor convention (C3), base
  pos − 1. One anchored at r is in the tract and one at l is not, the reverse of its genealogy (popevents draws the
  tree at base pos).
- **m2.** `test_jitter_bounds_clamps` (test_sim.py) gives exact bounds for:
  - 2-bp/1-bp, 3-bp and 1-bp LTRs (the clamp);
  - outward moves (free);
  - an element at both sequence ends, and one 1 bp from each end;
  - jit False.

  It kills the LTR-clamp mutant (b − a) and the sequence-end mutant, which the BASE-digest test let through.
  - One expected value in my first draft was wrong (I wrote end 200 for the 3-bp right LTR; the clamp gives 198).
    I corrected the expectation, not the code.
- **m3.** TREE7, EXACT, fixed_donors and DONORS, toy7, below, ins_at, loss_at, events, build and other move from
  test_popbuild.py to tests/poptoy.py (its docstring lists them).
  - test_popbuild and test_poptruth import them from poptoy; test_popbuild keeps its own `rng`.
  - poptoy now imports popbuild and popevents, neither of which imports msprime at module level.
- **Checks.**
  - Engine fingerprints at 239eb8f: all 7 identical to 12d3e6c (`$S/fp_239eb8f.txt`).
  - `ruff check .`: all checks passed.
  - Before the commit, test_poptruth, test_popbuild, test_sim, test_popevents, test_popmodel and test_score passed
    with `-W error`.
- **Suite at 239eb8f:** detached, wrapper PID 2688811 (SID = PID, PPID 1). Log `$S/fix1/suite.log`, exit code in
  `$S/fix1/suite.done`. Result: below.
