# LTRmix: detect and characterize admixture from LTR-RTs alone

## Context

You asked whether the admixture in Yang et al. 2023 (Science) and Barnes et al. 2022 (PNAS) could have been found using
LTR-RTs alone, and for a benchmarked method, with B73/TIL18/TIL01 as the test case. Why it matters beyond maize: an
LTR-RT carries its own polarity (insertion = derived), its own clock (LTR-LTR divergence) and its own orthology
certificate (the TSD). If those are enough, admixture can be tested in any annotated genome set, with no outgroup,
SNP panel or gene annotation.

### Feasibility spike already done (throwaway code in `benchmark/feas/`, nothing tuned)

| Check | Result |
|---|---|
| Sister pair from the data, no labels given | B73+TIL01 share the most 21-mers (31.1 M, vs 20.8 M and 17.9 M) |
| Alignment-free k-mer D, 5 Mb block jackknife | D = +0.061, Z = 4.9 (rare k-mers); D = +0.110, Z = 6.5 (single-copy k-mers) |
| Yang: chr 5, 8, 9 depleted | Lowest three by mexicana-like k-mers are chr 9, 8, 5 (chance 1/120) |
| Library-only orthology | Same 5-bp TSD in 92% of syntenic pairs (98.6% within 1 kb of the diagonal) vs 0.7% off-diagonal |
| Control pair, B73-TIL18 / TIL01-TIL18 ortholog counts | Ratio ~1.0 at 97-99% identity, 3.9 at >=99.8% identity |
| Window correlation with B73 ELAI (Spearman) | r = 0.18 (100 kb) rising to 0.38 (10 Mb); circular-shift p at the 0.01 floor (only 100 shifts) |
| Inv1n region (chr1) | TIL01 near-identical orthologs vanish across 50-170 Mb; TIL18 ones are abundant at 60-100 Mb, where ELAI peaks |

Open problems the spike exposed:
1. **Direction / TIL18 purity.** chr7 has dense near-identical B73-TIL18 blocks where B73's ELAI ancestry is low. This
   could be recent maize ancestry in TIL18, which would inflate D for the wrong reason. Three genomes can't settle it.
2. **My crude diagonal breaks at inversions**, which distorts chr1 and possibly others. It needs proper chaining.
3. **ELAI is diffuse:** only 0.6% of B73 SNPs exceed dosage 1.8, and only 75.5 Mb lies in runs above 1.0. It's the
   published reference, not perfect truth, so disagreements get investigated rather than counted as automatic errors.
4. **Resolution limit:** Yang's typical tract is ~10 kb, and LTR-RTs occur about every 17 kb in B73. Most small tracts
   are likely undetectable individually. The benchmark must measure this, not assume it away.

## What "LTR-RTs alone" means (my default; tell me if you disagree)

Method inputs, per genome: LTR-RT FASTA + GFF3 (coordinates, LTR-LTR divergence, TSD), as LTRquest writes them.
No genome sequence, genes, SNP panel or outgroup, and no hard-coded taxon or chromosome names. Whole assemblies are
used only inside the benchmark, as independent checks.

## Method

**Form:** one standalone script, `LTRmix/ltrmix.py`, plus tests, README, `environment.yml` and `DESIGN.md`. The stages
run in sequence and share one data model, so a package would add nothing (same shape as `ltrharvest_phasing10.py`).

1. **Index (cached).** Sort-and-merge k-mer kernel from `benchmark/feas/kmer_fast.py`: packs (k-mer, record) into one
   64-bit key, so one sort makes every later lookup a linear merge. About 20 min for all three libraries here.
2. **Orthology.** Single-copy shared 21-mers give candidate pairs (no multi-mapping cap, unlike minimap2 `-N`).
   Collinear chaining in both orientations learns chromosome correspondence and inversions from the data. TSD equality
   measures precision, using off-diagonal pairs as the chance baseline. Output: presence patterns per insertion.
3. **Genome-wide tests, each with a block jackknife.** The sister pair is inferred from the data.
   - `D_kmer`: alignment-free.
   - `D_ins`: insertion presence/absence. Absence is ancestral, so no outgroup is needed.
   - Identity spectrum: B73-donor vs sister-donor ortholog counts per identity class.
   - `D_self`: ABBA/BABA on ortholog triples, polarized by the element's **other LTR** as a built-in outgroup.
   - All stratified by insertion age (LTR clock): a shared insertion younger than the split can't be lineage sorting.
4. **Local ancestry.** Per-element evidence, then HMM tracts along each chromosome. **False discovery rate from a mirror
   control:** the same caller runs on sister vs donor, where calls should be rare, so each identity class gets its own
   FDR and no hand-set cutoff is needed. Replication on disjoint half-libraries (idea from `ltrharvest_phasing10.py`).
   Every call carries a confidence flag; "none" is reported when evidence is absent.
5. **Characterize.** Ancestry fraction (lower bound from 3 genomes; ratio estimate with a second donor genome), direction
   (needs extra genomes), relative age from tract length and divergence, inversions from chain orientation.
6. **Report.** `findings.txt`, TSV/BED/GFF3 tables, one overview figure (per the `making-figures` skill).

## Benchmark

**Rule:** ELAI and the papers are used only to score, never to set thresholds. Bars below are fixed now; misses are
reported, investigated and logged in `dead_ends.md`, never tuned away.

### Published claims

| Paper's claim | Test | Bar |
|---|---|---|
| Yang: mexicana admixture in modern inbreds (f4) | All D versions on B73 | D > 0, Z > 3 |
| Yang: 15-25% ancestry (B73 ELAI = 17.0%) | Ratio estimate using TIL25 | CI vs 17%, reported |
| Yang: chr 5, 8, 9 depleted | Rank chromosomes | Those three lowest (p = 1/120) |
| Yang: ancestry varies along the genome | Correlation with B73 ELAI at 0.1-10 Mb; tract ROC/PR | Beats circular-shift null at p < 0.01 (1000 shifts) at >=1 Mb |
| Yang: tracts ~10 kb | Recall by ELAI tract length | Resolution limit reported |
| Yang: ZmPRR37a in B73 (chr7:183.95 Mb v5; dosage 1.55) | Called locally? | Reported as hit or miss |
| Yang: high-frequency regions | Enrichment of calls in regions derived from the ELAI file | Permutation p < 0.01 |
| Yang: Inv4m, Inv1n, chr 8/9 inversions | Chain orientation at the expected coordinates | Reported per inversion |
| Barnes: HPC1 and ZmLPCAT1 | HPC1 not mexicana-like in B73, mexicana-like in PT; ZmLPCAT1 not called in B73 | Reported per locus |

### Truth known by construction
- **Simulation through the full pipeline:** msprime ancestry plus an LTR-RT insertion/loss process with generated
  sequences; parameters taken from the data. Grid: f = 0, 2, 5, 10, 18, 25, 50%; tracts 10 kb-10 Mb; one-sided annotation
  dropout 0-40%. Bar: false-positive rate <= 5% at f = 0, with power curves reported.
- **Real-genome spike-in:** TIL11 (parviglumis) as recipient, with tracts from TIL25 (a different mexicana than the
  TIL18 reference) spliced in using syntenic element sets. All sequence and annotation noise is real, so it gives
  sensitivity and FDR by tract length with no population model.

### Controls
- **Negative trio:** TIL11/TIL01/TIL18. Expect no strong signal; bar |Z| < 3, otherwise explain it.
- **Positive real trio:** PT in place of B73. Expect D(PT) > D(B73), plus the HPC1 and Inv4m checks above.
- **Direction and TIL18 purity:** are the B73-TIL18 near-identical blocks also shared with TIL25? Is D robust to swapping
  TIL18 for TIL25? Resolves problem 1.
- **Whole-genome comparators on the same assemblies:** the same k-mer statistic on all non-LTR sequence, and SNP ABBA/BABA
  with a *Z. diploperennis* outgroup. Together these measure what restricting to LTR-RTs costs and validate `D_self`.
- **Absence check:** library-only "absent" calls tested against the raw genome for annotation false negatives.
- **Annotation portability:** rerun using the published EDTA structural calls (`inputs/annot_*`) instead of LTRquest.
- **Stability:** k and block size varied and reported, not tuned.
- **pytest:** tiny synthetic libraries with planted tracts, a decoy family and a true-negative trio.

### Generality
One independent admixed lineage with published tracts (small genome, likely Citrus or tomato, chosen after checking
assemblies). If it doesn't get done or doesn't hold, generality is labeled a hypothesis.

## Compute and data I'd add (needs your OK)

- **LTRquest on PT, TIL25, TIL11** with commit 5042a1e (still origin HEAD) and your exact flags, in
  `benchmark/ltrquest_extra/`. **`run/` is never touched.** Expect ~12 h wall at up to 120 threads, based on your earlier
  run (11.9 h, 41 CPUs average). The server is busy now (load ~450 of 256), so I'd reuse your wait-for-CPU launcher rule
  from `scripts/05_wait_and_launch.sh`, which could add hours. Launched with `setsid`/`nohup`, so it survives this session.
- **Downloads:** those 3 assemblies plus *Z. diploperennis* (~10 GB), and EP1 if capacity allows.
- **Data use:** PT_MEXI5 is released under the **Toronto Agreement** (pre-publication). Fine for benchmarking, but check
  with its producers before publishing results from it.

Already created during the spike: env `ltrmix`; `benchmark/`, `benchmark_data/` (ELAI, chain, gene models);
`LTRmix/environment.yml`.

## Files

- `LTRmix/`: `ltrmix.py`, `tests/`, `README.md`, `environment.yml`, `DESIGN.md`
- `benchmark/`: `scripts/`, `truth/`, `results/`, `REPORT.md`, `dead_ends.md`, figures
- `memo.md`: appended, or a new `memo_ltrmix.md`
- Reused: `scripts/03_prepare_inputs.sh` (seqid prefixing), `scripts/05_wait_and_launch.sh` (CPU rule), truth liftover in
  `benchmark/scripts/03_lift_truth.sh`, evaluator in `benchmark/scripts/eval_windows.py`

## Order of work

1. Launch the extra LTRquest runs and downloads (they run unattended while I work).
2. Build `ltrmix.py` stages 1-4 test-first on synthetic fixtures; run on B73/TIL18/TIL01.
3. Score against ELAI and named loci; call inversions.
4. Simulations, then negative/positive trios, direction, spike-in, comparators as the extra genomes finish.
5. Second lineage.
6. Report and hand-off.

## Verification

- `pytest` passes; a run on the three genomes from a clean output directory reproduces the benchmark tables.
- Each benchmark row above gets a number, a script and a log. Pass or miss is stated plainly.
- `REPORT.md` ends with the headline sentence, proposed mechanism, how general it is (tested or assumed) and what it
  predicts in other species. If the headline doesn't survive, it says so and lists the strongest leads.
