# Task 11, fix round 1 of 5 (review: task-11-review.md, 0 Critical, 6 Important, 10 Minor)

Read task-11-review.md in full first. These rulings bind; they override the review where the two differ.

## Principle for every generated sentence
- Every verdict word in the legends depends on the statistic that supports it, through one code path. The verdict
  words include: more, fewer, larger, holds, gene flow, no evidence, typical, thin, diffuse, concentrated.
- Each verdict comes from one small helper. Give that helper the numbers and the significance rule, and it returns
  the direction plus whether the direction is shown, not shown, or untestable.
- Significance uses the analysis constants: `Z_SIG`, `BF_TRACT`, the q cutoff. Import them; never restate them as
  literals (this is M3).
- A comparison between two numbers states both numbers. A magnitude word ("thin", "a little") appears only next to
  the number it describes.
- No `None`, `nan` or `inf` may ever reach a legend page.
  - Route every number through one formatter. A non-finite value makes the formatter drop the sentence, or write
    "not available" where the sentence must stay.
  - Add a test that renders every probe path the reviewer used and asserts that neither legend page contains
    "None", "nan" or "inf". The probe paths are: normal, `--trio S,R,D`, paint rows removed, no outgroup, D
    unannotated, and 300 scaffolds. The reviewer's probe scripts are in
    `/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/t11review/`;
    turn them into pytest fixtures.

## Rulings per finding
**I1. Condition the verdicts.**
- **D_pav.**
  - Gene flow into R needs D > 0 and Z >= Z_SIG.
  - Gene flow the other way needs D < 0 and Z <= -Z_SIG. Say it plainly: "S, not R, carries more of the insertions
    D shares with one sister: the test points against the roles", and name how the roles were set.
  - With |Z| < Z_SIG: no evidence.
  - With a non-finite Z: "the test could not be run" plus the plain reason (too few loci or blocks), not "about
    equally often".
- **The age gradient.**
  - "Most of all among young insertions" needs dD > 0 and dD's Z >= Z_SIG.
  - "Concentrated in old" needs dD's Z <= -Z_SIG.
  - Non-significant: "no clear difference between young and old".
  - Untestable: "the age gradient could not be tested".
- **"No insertion of D is shared ..."** appears only when the count really is zero. If the test simply has no
  counted loci, say that the test's counted set is empty and why, while panel E's counts stay as drawn.
- **Conditioned on their numbers:**
  - E's "R, not S, shares more with D";
  - A's "larger share than the control's";
  - D's "fewer among old insertions": the direction, and both numbers stated;
  - F's "holds in every check": every check's D has the primary's sign and |Z| >= Z_SIG. Otherwise write "holds
    in k of n checks" and name the ones that do not.
- G's "no more donor-like" and "a little more" are driven by the excess number and stated with it.

**I2. Panel B's control sentence.**
- Use the reviewer's wording or equivalent: "...10.2% of B73's insertions and 5.0% of the decoy's: plateaus this
  high also occur in the sister's control painting (roles swapped), about half as often; the tract's q weighs this
  one against the decoy's tracts."
- Keep "about half as often" (or a ratio word) only as the ratio of the two printed numbers.
- The sentence is conditional on:
  - a decoy painting;
  - a drawn tract, for "this tract's" and "the tract";
  - the share being above zero. When the decoy reaches it for 0% of insertions, say that.
- The B selection text says a verified insertion was found only when one was. Otherwise state that none passed, and
  how many were screened.

**I3. "Typical" must cover what B draws.**
- B draws the posterior plateau, but the selection ranked tracts only on loci and length. The result's mean
  posterior beats 700 of 770 recipient tracts.
- Ruling:
  - Rank tracts by mid-rank distance from the medians of all three quantities B shows: loci, length and mean
    posterior.
  - Take them in that order until one holds a clean R+D insertion.
  - The long legend states the chosen tract's percentile on each of the three among R's tracts, and its mean
    posterior's percentile among the decoy's tracts.
- Reason: the skill requires a showcase "typical of all calls", typical in what is drawn. The rule is independent of
  any known answer.
- Re-render on main3. B and C may change. Rerun the clean checks, and update memo.md's example section and figure
  check.

**I4. Stale painting.**
- The overview draws a painting only when stats.tsv holds the current paint rows. assemble leaves stale parts out,
  so their absence signals a stale or missing painting.
- Otherwise the trio is drawn as unpainted, and the legend says in plain words that no current painting exists.
- Add a test: a stale paint part (paint rows dropped from stats.tsv, files still on disk) is never drawn and prints
  no "None".

**I5. KKSC note.** Map the note's counts by label, not position. Add a test with a sheet where S precedes R.

**I6. Discovery genome and outgroup wording.**
- F's text takes the discovering genome from the D_pav row (its `loci` field or its discovery attribute), never
  assumes D, and says "fallback discovery by X" when that applies.
- The outgroup clauses ("every outgroup an empty site", "not present in the outgroup") appear only with an outgroup.
- Add tests for fallback discovery and for no outgroup.

## Minors: fix all
- **M1.** Break long tokens in `_text_page` after "/" or "_". Test with a 150-character path.
- **M2.** No pipeline jargon on the fallback paths the reviewer lists:
  - "--trio" becomes "roles as given by the user";
  - no command names;
  - `_FAIL_SHORT` applied to the no-example caveat;
  - "the FASTA of X" becomes "X's genome sequence";
  - the no-trio figure gets no title. The skill forbids titles; if the case needs explaining, put the sentence on
    the legend page.
- **M3.** Use the constants (above).
- **M4.**
  - Use R's own TSD (`e.tsd`), not `Catalog.tsd`.
  - Split the failure label into "recipient's TSD copies differ", "recipient's TSD copies differ from the annotated
    TSD" and "sequence ends", so the counts name the real failure.
  - Re-render, since the clean subset may change.
- **M5.** Cache on the Catalog object, or per call; never key it by `id()`.
- **M6.** Collect the pair file's eids in one pass, and parse mechanisms.tsv once.
- **M7.** An unreadable FASTA makes the key say "unreadable" for that file and leaves panel C out, as the docstring
  says. Test it.
- **M8.** Correct the three misattributed sources:
  - sequences_drawn/not_drawn come from the genome index lengths;
  - A_bin is a display choice ("display");
  - C_flank_identity is computed from the genome sequences.
- **M9.** Use "not present in the outgroup". Tie or drop the magnitude words. Make the sparse-block sentence state
  the rule ("drawn where their loci average at least one per display bin; N sparser blocks not drawn"), not interpret
  it.
- **M10.** Tests:
  - a numbers-to-tables test, value equality and not substring, for at least D_pav, Z, n_RD, n_SD, the E counts, G's
    two means and B's two shares;
  - branch tests for the I1 and I4-I6 cases. Use small toy fixtures; no real data.

## Process
- Commit with plain subjects, one per finding group if natural. No trailers, nothing set, never push.
- Run the full suite (`python -m pytest -W error -m "not slow"`) and `ruff check .` after the last commit.
- Re-render on the read-only main3 view `benchmark_pav/plan2_figure/run`. Inspect full-resolution crops of B and C
  and both legend pages. Answer the figure check again in memo.md.
- Append "Fix round 1" to task-11-report.md: per finding, the commit and the test.
- Return only:
  - the commits;
  - the test line;
  - one line per finding: fixed, partly or not, with the reason;
  - the new B/C example (tract, percentiles, insertion, pass count);
  - anything not done.
