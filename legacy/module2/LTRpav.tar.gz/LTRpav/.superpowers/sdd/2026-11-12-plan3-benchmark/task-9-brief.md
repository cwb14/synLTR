### Task 9: Scoring, `RULES.md`, and the pilot's scores

**Files** (in `benchmark_pav/plan3/`): `common/evalib.py`, `common/test_evalib.py`, `sim/eval_run.py`,
`sim/eval_ltrmix.py`, `sim/summarize.py`, `sim/RULES.md`.

**Interfaces:**
- **Environments.**
  - `evalib.py` is numpy only.
  - `eval_run.py` and `summarize.py` run in env `ltrpav` (snapshot; numpy, scipy).
  - `eval_ltrmix.py` runs in env `ltrmix` (pandas).
- **Consumes:**
  - stats.tsv rows by name:
    - `D_pav` (D, n_RD, n_SD; strata incl. `no_outgroup_filter`), `D_pav_gradient` (dD), `f4_ratio` (f), `roles`
      (source), `resolution`;
    - `paint` (n_tracts_q05, posterior_mean, decoy_posterior_mean, excess, n_informative, spacing_median, emission,
      e0_RD, e0_RS, e1_RD, e1_RS);
    - `dfoil` (DFO, DIL, DFI, DOL, signature), `direction` (D_dir, n_XY, n_YX);
    - `identity_split` (s), `outgroup_conflict` (frac_E), `jackknife` (block_bp);
    - sentinel rows (layer `run`, test `part`, a text value) are skipped.
  - The painting files: `posterior.<R>.tsv` (`seqid start end class post`), `tracts.<R>.bed` (`start0 end q`) and
    `decoy_tracts.<S>.bed`.
  - `qc.tsv`, `truth/`, `ltrpav-sim score`.
  - LTRmix's trio files sit in `ltrmix/` itself when LTRmix got three libraries (trio design, LTRquest runs), and in
    `ltrmix/A1_B1_C1/` with four (ltrmix.py L1615). The files:
    - `stats.tsv`;
    - `elements.<R>.tsv` (`post_ancestry_<D>`, `post_recent_<D>`; plain text);
    - `tracts.<R>.bed` and `ancestry.<R>.bed`, for the recipient LTRmix chose;
    - the root-level `orthologs.<X>.<Y>.tsv.gz`.
  - `ltrpav.analysis.stats.jackknife` and `block_ids` (public).
- **Produces** (`evalib.py`):

```python
def auroc(score: np.ndarray, label: np.ndarray) -> float                  # Mann-Whitney, nan if one class empty
def bp_overlap(a: list[tuple[int, int]], b: list[tuple[int, int]]) -> int  # merged intervals, one sequence
def recall_by_length(truth, called, bins=(0, 5e4, 2e5, 1e6, inf)) -> dict  # found when called tracts cover >= 50%
def precision_by_length(truth, called, bins=(0, 5e4, 2e5, 1e6, inf)) -> dict  # bp precision of called tracts by their
                                                                              # own length bin
def tract_fdr(called, truth) -> tuple[int, int]                         # (called tracts overlapping no true tract, all)
def dfoil_direction(signature: str, p12: str, p34: str) -> str          # "P3=>P1"-type labels -> "<taxon>><taxon>";
                                                                         # "unresolved" (ancestral, "or" labels); "none"
def truth_d(rows_dr, rows_ds, rows_do, coords, block: int, outgroup: bool) -> dict   # D, se, z, n_RD, n_SD
def resign(z: float, called_recipient: str, true_recipient: str) -> float
def match_by_coords(called: list[Element], true_rows: list[dict], slop: int) -> dict  # LTRquest element -> true eid
                                                                                       # (both ends within slop)
```

**`eval_run.py RUN`** writes `eval/eval.json`, which holds the sha256 of each eval script. It contains:
- **Design:** kind, f, ta, pulse, and the true fractions.
- **Calibration and power,** from view `main`:
  - D_pav D, se, z and n for every stratum (`no_outgroup_filter` included), and dD with its z;
  - f4 against A1's true fraction;
  - n counted and n informative.
- **Roles,** from view `roles`: whether the inferred sister pair, donor and recipient match the truth.
- **Truth D,** on true states with the tool's block rule `min(5 Mb, max(smallest // 100, 10 kb))`:
  - donor-discovered (C1's annotated elements present, R and S resolved, O1 E), with and without the outgroup filter;
  - sister-discovered (LTRmix's D_ins loci): A1's elements present in C1 with B1 E, against B1's elements present in C1
    with A1 E.
- **Head-to-head painting,** from view `roles` (kinds with pulse `C>A`):
  - the recipient LTRpav inferred for {A1, B1, C1};
  - if it is A1: element AUROC of `post` against "inside a true A1 tract", bp precision and recall (all, and at
    q <= 0.05), recall and precision by length, recall also by true length in informative loci (length / the run's
    mean spacing), the realized tract FDR at q <= 0.05, and the excess against the true fraction;
  - if it is not A1: `wrong_recipient = 1`, recall 0, AUROC NA.
- **Model comparison,** from views `main`, `any`, `decoy` and `anydecoy`:
  - the same painting scores with the recipient fixed at A1;
  - e0 and e1, and `degenerate` (e1_RD > 0.99 and e0_RS > 0.99);
  - in nulls, n target tracts at q <= 0.05 and the excess.
- **Direction,** from view `roles`, taxa (A, C):
  - the signature mapped by `dfoil_direction`, against `direction_predictions.tsv` and the truth;
  - D_dir.
- **Decision 11,** from view `nodonor`: D_pav, se, z and n, and the discovery genomes named in findings.txt.
- **Genotypes,** on every directed pair:
  - eval_run joins calls to truth per element (call eid to Name to truth row, as `score.py` does). It checks that its
    pooled totals equal `ltrpav-sim score`'s;
  - pooled per state, all and high tier; split by target class (into O1, or ingroup) and by backbone window;
  - **LTRquest annotations**, where the sheet's annotation is not the simulator's GFF3:
    - elements map to true eids by `match_by_coords` (slop `SLOP_TSD_MULT * TSD_DEFAULT`, 10 bp);
    - matched elements get the same per-state counts, and unmatched ones are counted;
    - `ltrpav-sim score` is not called, since it needs eid Names.
- **Identity** (kind null): s against the true `2 * mu * t_bc` = 0.0036.
- **Realism:** per-pair state fractions and resolved fraction (`qc.tsv`), outgroup conflict, D_pav counted and
  informative loci per Mb, painting n_informative and spacing_median, and elements per Mb. Each sits beside main3's
  values:
  - D_pav 2,041 loci, 0.97/Mb;
  - painting 7,515, spacing 84 kb;
  - conflict 0.027-0.032;
  - B73->TIL18 P 21%, E 21%, D 22%, O 17%, U 15%, S 0.9%, resolved 46%.

**`eval_ltrmix.py RUN`** (env `ltrmix`) ports `eval_sim.py`'s logic onto A1's coordinates:
- D_kmer, D_ins, D3 and D_self, each with Z re-signed toward A1 (`sim_summary.py`);
- D_ins young and old;
- f-ratio with C2;
- the recipient LTRmix chose. If it is not A1, `wrong_recipient = 1`, recall 0 and AUROC NA, as for LTRpav. A missing
  `elements.A1.tsv` is recorded, never an error.
- element AUROC (ancestry and recent);
- tract bp precision and recall, recall by length, and tract FDR at q <= 0.05;
- presence/absence accuracy: `orthologs.<X>.<Y>.tsv.gz` status against `truth/` (DESIGN 10.5);
- `rate_free_split`'s s.

**`summarize.py`** (env `ltrpav`) writes `sim/tables/{null,calibration,power,tracts,direction,dropout,variants,
genotype,ltrmix,gaps,realism,decision11}.tsv` and every bar of `RULES.md`. Power is reported per (f, ta) as:
- mean and SD of Z;
- the fraction of runs with Z > 3;
- a probit fit of P(Z > 3) on f per ta, with the f at 80% power and its profile interval;
- the Z projected by locus count: `Z_sim * sqrt(2041 / n_sim)`, labeled as a projection.

LTRpav's `no_outgroup_filter` stratum stands beside LTRmix's D tests, since LTRmix has no outgroup.

**`RULES.md`** is written verbatim from this list, and dated, before any run is scored:
1. **Null bar (DESIGN 10.2).** D_pav, pre-declared trio, stratum `all`: |Z| > 3 in at most 1 of the 30 nulls (5% of 30
   is 1.5). Report the Clopper-Pearson 95% interval.

   The same count is reported for:
   - truth D;
   - LTRmix's four D;
   - `nodonor`;
   - the bottleneck nulls.
2. **Calibration reading.** A null Z is calibrated when both hold:
   - the 95% chi-square interval of its SD over the 30 nulls includes 1;
   - its mean lies within 2 SE of 0.

   Applied to D_pav, dD, truth D and LTRmix's four D. SD(D) over the nulls is also reported against the mean jackknife
   SE. The bar stays rule 1.
3. **Genotype bar** (DESIGN 10.1 on the population sims). High-tier precision >= 0.95 for P and for E, pooled over all
   directed pairs of all runs. Reported also per target class and per backbone window.
4. **Painting null.** A model holds the null when both hold:
   - at most 1 of the 30 nulls has a target tract at q <= 0.05;
   - the mean excess over the decoy in the nulls is within 2 SE of 0.

   For `any` and `anydecoy`, the 20 one-sided dropout nulls must also pass on their own: at most 1 of 20 with a
   q <= 0.05 tract, and their excess within 2 SE of 0.
5. **Variant adoption** (`any`, `decoy`). A variant becomes the default only when all four hold:
   - it holds the null (rule 4);
   - its pooled tract-level realized FDR at q <= 0.05, over the `C>A` power runs, is at most 0.05, with a
     Clopper-Pearson upper bound of at most 0.10;
   - over the `C>A` power runs (plus the f 0.18 dropout runs for `any`), its bp recall at q <= 0.05 is higher than the
     default's, by a paired sign test at p < 0.05;
   - its bp precision at q <= 0.05 is not lower by the same test.

   Runs where either model's value is NA (no q <= 0.05 tract) are dropped from that sign test, and the NA counts are
   reported.
   - `decoy` is also adopted when the default fails rule 4 and `decoy` passes rules 4 and 5's FDR bar.
   - Both are adopted together only if `anydecoy` passes rules 4 and 5. Otherwise only the one with the larger median
     recall gain is adopted.
   - Ties keep the default.
6. **Degeneracy.** A fit is degenerate when e1_RD > 0.99 and e0_RS > 0.99.
   - Reason: emissions within 1% of 0 and 1 make the posterior a copy of each locus's class. That is main3's state
     (e1_RD 0.9993, e0_RS 0.9995).
   - Degenerate fits are reported per kind and model.
   - If fewer than 10% of the default's fits in the `C>A` power runs are degenerate, the decoy decision is labeled "not
     tested in main3's regime" and listed as a Plan 4 lead, whatever rule 5 says. The 10% line is a named heuristic for
     "the regime is rare in the simulations".
7. **Direction.** The predicted codes are `direction_predictions.tsv`.
   - The test's implementation is confirmed when every posctl run reads its predicted direction (C1>A1 as C>A, A1>C1 as
     A>C) and the posctl nulls read "none".
   - Its false calls are counted in the 30 nulls and in the bottleneck nulls.
   - Under the maize-like demography, every gene-flow scenario is predicted "none". A directional call there is counted
     as a false call when it names the wrong direction, and reported when it names the right one.
   - Direction power for the real data's scenario (PT-like) is what the `ptlike` runs read. If the prediction there is
     "none", Task 13 states that DFOIL-alt is not expected to orient it.
   - D_dir is reported against its simulated null distribution under the same Ne, default and bottleneck, as an
     exploratory readout.
   - **Consequence** (DESIGN 7.6: "kept only if simulations with known direction recover it"):
     - if posctl confirms, DFOIL-alt stays an exploratory output, reported with its measured power and false-call rate;
     - if not, Task 11 changes the direction rows' note to "not validated by simulation (Plan 3)", and removing the
       test is a Plan 4 decision.
8. **Plan 2's D gap.** The two truth D are expected to differ only through which copies count:
   - any present state against annotated intact copies;
   - dropout.

   The informative comparison is D_pav against donor-discovered truth D, D_ins against sister-discovered truth D, and
   whether D_ins/D_pav reproduces the real 0.66 on the same runs.

- [ ] **Step 1: Write `test_evalib.py`** (synthetic inputs):

```python
def test_auroc_perfect_and_tied():    # [0.9,0.8,0.1] vs [1,1,0] -> 1.0; all-equal scores -> 0.5
def test_bp_overlap_merges():         # [(0,10),(5,20)] vs [(15,30)] -> 5
def test_recall_and_precision_by_length():  # one 60-kb tract half covered -> found in 50-200 kb; precision 0.5 there
def test_tract_fdr():                 # 3 called, 1 overlapping nothing -> (1, 3)
def test_dfoil_direction():           # ("P3=>P1","A","C") -> "C>A"; "P1+P2<=>P3" -> "unresolved"; "none" -> "none"
def test_truth_d_counts():            # 6 RD, 2 SD in 4 blocks -> D 0.5, n 8; outgroup-present loci dropped
def test_resign():                    # called B1, true A1 -> -z
def test_match_by_coords():           # ends within 10 bp match; 11 bp off does not; unmatched counted
```

- [ ] **Step 2: Run** `python -m pytest -q common/test_evalib.py`. It fails, then passes once implemented.
- [ ] **Step 3: Write and date `RULES.md`** (verbatim list above), and add it to `sim/memo.md`.
- [ ] **Step 4: Score the pilot.** Run `run_one.sh` from `eval` for both pilot rows, then `summarize.py`. Every field is
  filled, or NA with a reason. The pilot changes no rule.

---

