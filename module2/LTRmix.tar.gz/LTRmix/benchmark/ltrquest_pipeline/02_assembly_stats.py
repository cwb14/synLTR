#!/usr/bin/env python3
"""Per-assembly QC for choosing among candidates: contiguity, gaps, soft-masking, telomeres.

Streams one sequence at a time, so memory peaks at the longest chromosome.
Usage: python3 -I 02_assembly_stats.py [-v] asm.fa.gz [asm2.fa.gz ...]   (TSV on stdout)
"""
import argparse
import gzip
import os
import re
import sys

GAP = re.compile(rb"[Nn]{10,}")
# Plant telomere repeat, either strand, at least 5 tandem copies.
TELO = re.compile(rb"(?:CCCTAAA){5,}|(?:TTTAGGG){5,}", re.I)
TELO_WIN = 20_000
CHROM_MIN = 50_000_000
COLS = ("assembly seqs total_Mb chrom_scale chrom_scale_frac scaffold_N50_Mb contig_N50_Mb "
        "contigs gaps N_frac lower_frac telomeres_of_chrom_ends example_ids").split()


def records(path):
    """Yield (id, sequence bytes) one record at a time."""
    name, chunks = None, []
    with gzip.open(path, "rb") as fh:
        for line in fh:
            if line.startswith(b">"):
                if name is not None:
                    yield name, b"".join(chunks)
                name, chunks = line[1:].split()[0].decode(), []
            else:
                chunks.append(line.rstrip())
    if name is not None:
        yield name, b"".join(chunks)


def n50(lengths):
    half, run = sum(lengths) / 2, 0
    for x in sorted(lengths, reverse=True):
        run += x
        if run >= half:
            return x
    return 0


def stats(path, verbose):
    scaffolds, contigs, ids = [], [], []
    n_bases = lower = gaps = chrom_ends = telo_ends = 0
    for name, seq in records(path):
        size = len(seq)
        scaffolds.append(size)
        ids.append(name)
        n_bases += seq.count(b"N") + seq.count(b"n")
        lower += sum(seq.count(c) for c in (b"a", b"c", b"g", b"t"))
        pieces = [p for p in GAP.split(seq) if p]
        contigs.extend(len(p) for p in pieces)
        gaps += max(0, len(pieces) - 1)
        if size >= CHROM_MIN:
            chrom_ends += 2
            telo_ends += bool(TELO.search(seq[:TELO_WIN])) + bool(TELO.search(seq[-TELO_WIN:]))
        if verbose:
            print(f"  {os.path.basename(path)} {name} {size}", file=sys.stderr)
    total = sum(scaffolds)
    chrom = [s for s in scaffolds if s >= CHROM_MIN]
    return [
        os.path.basename(path).split(".fa")[0], len(scaffolds), f"{total / 1e6:.1f}",
        len(chrom), f"{sum(chrom) / total:.4f}", f"{n50(scaffolds) / 1e6:.2f}",
        f"{n50(contigs) / 1e6:.2f}", len(contigs), gaps, f"{n_bases / total:.5f}",
        f"{lower / total:.4f}", f"{telo_ends}/{chrom_ends}",
        ",".join(ids[:2] + ids[-2:]),
    ]


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("fasta", nargs="+", help="gzipped assembly FASTA")
    ap.add_argument("-v", "--verbose", action="store_true", help="log each sequence to stderr")
    args = ap.parse_args()
    print("\t".join(COLS), flush=True)
    for path in args.fasta:
        if not os.path.exists(path):
            sys.exit(f"ERROR: missing input: {path}")
        print("\t".join(map(str, stats(path, args.verbose))), flush=True)


if __name__ == "__main__":
    main()
