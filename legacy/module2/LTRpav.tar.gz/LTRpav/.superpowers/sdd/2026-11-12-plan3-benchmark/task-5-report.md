# Task 5 report: `ltrpav-sim pop`: orchestration, outputs, command line

BASE 239eb8f on plan3-benchmark. Scratch: `$S` = /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t5

## Status
- Status: DONE_WITH_CONCERNS.
- Commits:
  - 0a99f40 "Move the simulators' donor picking and element shifting into sim/donors.py";
  - 78abe50 "Add ltrpav-sim pop: population simulation on a real backbone".
- Suite (detached, `-m "not slow"`, -W error): still running at handback (22:31, 68%, no F or E so far).
  - Bash PID 260989, pytest PID 260991; SID = PID, PPID 1.
  - Exit code in /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t5/suite/suite.done; log in /tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/p3t5/suite/suite.log.
- `ruff check .`: All checks passed.
- tests/test_pop_cli.py with the slow test, run once: exit 0, 11 passed.
- Engine fingerprints: all 7 identical to 12d3e6c.
- 20-Mb probe: 5:38 wall, largest process 0.80 GiB, summed PSS 1.66 GB.

## Files
- `src/ltrpav/sim/donors.py` (new):
  - `pick_donors` and `shift_element`, moved verbatim from `cli._donors` and `cli._shift`, with `MAX_DONORS`;
  - `backbone_elements(elements, seqid, start, end)` (new).
- `src/ltrpav/sim/pop.py` (new): `PopParams`, `PopResult`, `check_regions`, `simulate_pop`, `write_pop`,
  `SIMPLIFICATIONS`, `DROPPED`, `MAX_CHROMS`.
- `src/ltrpav/sim/cli.py`:
  - the `pop` subcommand;
  - `pair` imports `pick_donors` and `shift_element` from donors.py;
  - `_region`'s parsing is split into `_parse_region` (messages unchanged).
- `src/ltrpav/sim/__init__.py`: exports `PopParams`, `PopResult`, `simulate_pop` and `write_pop`.
- `docs/DESIGN.md` 10.2: one paragraph, "Built (Plan 3)".
- `tests/test_pop_cli.py` (new): 11 tests, one of them slow.

## Tests (tests/test_pop_cli.py) and what each pins
Toy input: a FASTA of s1, s2 and s3, 300 kb each. 40 planted LTR-RTs go in a GFF3, built with poptoy.toy_backbone:
13 per sequence, every third on the minus strand, plus one nested in s1's first. The module starts with
`pytest.importorskip("msprime")`. A module-scoped run serves several tests. It uses regions s1 and s2 whole, plus s3
up to a cut 1,000 bp into s3's seventh element, with seed 3, `--f 0.2 --ta 2000` and threads 1.

| Test | Pins |
|---|---|
| test_pop_writes_outputs | The exact file set: 7 FASTAs, A/B/C GFF3s, 36 truth files (6 annotated X x 6 other Y), insertions.tsv, fractions.tsv, tracts.A1/A2.bed, samples.tsv, params.json. Sheet header `label fasta annotation group role`. read_samples loads it in order A1..O1, groups A,A,B,B,C,C,O, roles (O1 `outgroup`, others None), annotation paths (O1 None), FASTA paths. Every genome holds c01..c03. Every GFF3 loads with unique names. Truth headers are TRUTH_COLUMNS, genome X only, names unique. insertions.tsv header is INSERTION_COLUMNS + fate_<label>. params.json: seed, regions, FASTA and annotation path with sha256, PopParams values, versions, trees per chromosome, the 7 dropped keys. Each total equals the sum of its per-chromosome and per-genome details. requested = realized + dropped for insertions, losses, SNPs and gaps. Realized insertions equal the table's rows. Truth counts equal the files' counts. 4 simplifications. fractions.tsv: lifted_bp equals the BED total; tract_bp is 0 outside A and > 0 in A. |
| test_pop_deterministic | Same seed and arguments at threads 2: every file (FASTA, GFF3, truth, params.json) is byte-identical to the threads-1 run. |
| test_pop_demography_json | JSON `t_o 300000, f 0.05, ta 1000, per_taxon 1, mu 2e-8` plus `--f 0.2`. params.json records t_o 300000, ta 1000, per_taxon 1, mu 2e-8 and f 0.2 (the command line wins). The sheet is A1, B1, C1, O1. `--dropout-genome A1=0` gives A1 annotated == alive > 0, dropout 0.0, and B1 and C1 0.1. |
| test_pop_streams (added) | pop.py's docstring stream contract, rebuilt step by step and compared exactly. ancestry seed is the first draw of [seed, c]; then draw_events(chrom=c) and build_chrom(c - 1). Gaps come from [seed, 100, g], annotate from [seed, 200, g], donors from [seed, 0]. The comparison covers sequences, gaps, Copy records and annotations. With gap_per_mb 1000 and regions that end and start exactly at an element, near gaps fall off. Per genome, requested == round(1000 x length / 1 Mb), realized == written, dropped == add_gaps' count, and the total is > 0. At f = 1, A1's tracts are its whole chromosomes; they equal tract_bed of popmodel.tracts at sample 0, and no other sample has any. |
| test_pop_two_regions_one_sequence | s1:1-150000 and s1:150001-300000 give FASTA headers c01 and c02, recorded as regions. Every backbone truth row named `s1:<start>-<end>` sits on its own window's chromosome. |
| test_pop_edge_element_excluded | backbone_elements(s3, 1, cut) is exactly the 6 elements inside: names, 0-based shifted coordinates, LTRs, strand, origin, parents. The crossing element is excluded. A window from base 20,001 shifts by 20,000. The nested element's parent is its host. In the run, the crossing element's name is in no truth file. |
| test_pop_regions_overlap_fails | s1:1-100000 plus s1:100000-200000 (sharing one base) exits 1 with one stderr line, `error: ... overlap ...`. No outdir is created. |
| test_pop_dropout_guards | A1=1, A1=1.5 and A1=x exit 2: argparse, one `error:` line naming --dropout-genome. O1=0.2 and Z9=0.2 exit 1, labels checked after parsing: exactly one stderr line, `error:`, naming the label. Nothing is written. |
| test_pop_region_too_short | longest = the longest of pick_donors' donors (seed 1). A region of 2 x WINDOW_PAD + longest - 1 bp exits 1 with one line naming the region and the required length; nothing is written. Exactly 2 x WINDOW_PAD + longest bp exits 0. |
| test_pop_without_msprime (added) | In a fresh interpreter with msprime and tskit made unimportable, `ltrpav-sim pop` exits 1 with stderr exactly `error: <MSPRIME_HELP>`. No outdir. |
| test_pop_end_to_end (slow) | pop with `--per-taxon 1 --seed 2 --f 0.2 --ta 2000` on the whole toy, then ltrpav-genotype (8 threads), ltrpav-merge and ltrpav-stats `--trio A1,B1,C1`: all exit 0, and stats.tsv holds D_pav rows with statistic D. `ltrpav-sim score` on pairs/C1__A1 against truth/C1__A1.tsv exits 0. Its P and E rows (tier set all) have tp > 0. Truth for this seed: C1 in A1 has P 59, E 32. |

Mutation check (`$S/mutants.py`): 21 of 22 mutants of pop.py, donors.py and cli.py are caught. The mutants:
- the chromosome, gap and annotation streams;
- draw_events' chrom;
- the tract sample index;
- overlap off by one, in both directions;
- the length rule, in both directions;
- dropout_of;
- outgroup truth;
- the recipient filter;
- role;
- the outgroup guard;
- FASTA newlines;
- tract_bp;
- requested gaps;
- the shift;
- parents;
- the CLI's Demog overrides;
- the dropout bound.

The survivor is equivalent. Changing backbone_elements' filter `e.end <= end` to `e.start <= end` lets a crossing
element through, and the LTR/bounds check `t <= length` then drops it.

## TDD evidence
- The tests were written first. Their first run failed at collection: `ImportError: cannot import name
  'backbone_elements' from 'ltrpav.sim.donors'`.
- I then added `backbone_elements` and ran again; every test failed for want of the subcommand (`$S/red.log`):
  - 6 FAILED: `SystemExit: 2`, "argument COMMAND: invalid choice: 'pop' (choose from pair, score)";
  - 3 ERROR: the module run fixture.
- After implementing: 9 passed. I then added test_pop_streams and test_pop_without_msprime and the extra checks
  noted above, for 10 non-slow tests.
- Final run of the whole file, slow test included, run once (detached, PID with SID = PID and PPID 1):
  `python -m pytest -W error tests/test_pop_cli.py` exited 0 with 11 of 11 passed. test_pop_end_to_end took 63.5 s,
  with ltrpav-genotype at 8 threads (`$S/slow/slow.log`).

## Choices
1. **Backbone element names are their source span**, `<seqid>:<start>-<end>`, 1-based inclusive
   (`backbone_elements`).
   - The names are unique across disjoint regions, because load_annotation drops duplicate spans. They also trace
     back to the real annotation.
   - R4's assertion: simulate_pop raises ValueError before simulating if a name repeats across chromosomes, naming
     both chromosomes.
   - The signature stays the brief's, with no chromosome argument; iids already carry the chromosome.
2. **R1 contract**, checked once where genomes are joined (`_join`). Every copy of chromosome c has Copy.chrom ==
   c - 1, and no element id appears on two chromosomes; either failure raises RuntimeError.
   - draw_events gets `chrom=c` (1..99); build_chrom gets c - 1 (R4).
3. **Streams**, as the docstring states:
   - donors [seed, 0];
   - chromosome c [seed, c]. Its first draw is ancestry's random_seed, in [1, 2**32 - 1). draw_events and
     build_chrom then read the same generator in that order, inside one worker;
   - gaps [seed, 100, g] and annotation [seed, 200, g], with g the sheet index.
4. **Processes (R2).**
   - A fork ProcessPoolExecutor of min(threads, chromosomes) workers, following the engine's pattern in
     genotype.py. With one worker it runs inline.
   - Donors, Demog, Rates and seed reach the workers through the initializer, which fork shares without pickling.
     Each job carries (c, backbone bytes, backbone SimElements).
   - Errors are re-raised as RuntimeError naming the chromosome and region. A dead worker is reported with the
     unfinished chromosomes.
5. **Memory (R2).**
   - A worker returns its chromosome's per-sample (sequence, copies, lift), its kept insertions, counts, tracts
     and tree count. No ChromEvents arrays come back.
   - `_join` moves each sample's per-chromosome bytes into its PopGenome and drops the worker result's reference,
     so the parent holds one copy. Chromosomes are never concatenated.
   - add_gaps is called one genome at a time with that genome's stream, so its temporary copies cover one genome.
     The results equal calling it on the whole list.
   - FASTA is written in 1-Mb blocks of 80-column lines, the same format as pair's.
   - The annotation's Element list is deleted before the pool forks.
6. **params.json** is deterministic: it records no threads and no timings, so it is byte-identical across thread
   counts (tested). Keys:
   - seed, params (asdict of PopParams), regions;
   - fasta {path, sha256};
   - annotation {path, files: [{path, sha256}]}, where files come from annotation_files, so an LTRquest prefix
     lists its tables;
   - versions {ltrpav, msprime, tskit};
   - backbone {annotation_elements, donors, longest_donor, chromosomes{cNN: region, length, elements}};
   - trees {cNN};
   - events {requested, realized, dropped}, each with total, per_chromosome and per_genome;
   - genomes {label: group, length, alive, annotated, dropout, gaps};
   - truth {X: {Y: {state: n}}};
   - fractions;
   - simplifications.
7. **Event counts.**
   - requested = what the processes drew: insertions = kept + ins_n + ins_end + ins_after_loss +
     nested_after_loss; losses = kept + loss_after_loss; snps = kept + snp_n; indels; gaps = round(gap_per_mb x
     genome length / 1 Mb).
   - realized = kept: insertions, nested, losses by kind, snps, indels and their insertion/deletion split, gaps
     written.
   - dropped = Task 2's six counters + gap_off_chromosome (R1, R4).
8. **R1 simplifications, one line each:**
   - replacing sequence and simulated solo LTRs receive no insertions;
   - replacing sequence and indel bases take no substitutions;
   - any-carrier thinning;
   - TSD bases assume one mutation per SNP site.
9. **CLI.**
   - `--demography` goes through demog_from_json. Then `--f/--ta/--pulse/--per-taxon/--bottleneck` override it
     via dataclasses.replace, so Demog re-checks the combination.
   - Value checks are argparse types (exit 2): `--dropout` in [0, 1), `--jitter` in [0, 1], `--dropout-genome
     LABEL=X` with X in [0, 1) (repeatable, or several after one flag), `--threads` and `--per-taxon` >= 1,
     `--bottleneck NE,GEN`, `--pulse` from PULSES.
   - Labels are checked by PopParams after parsing (exit 1): unknown, the outgroup, or given twice.
   - Regions are parsed by the shared `_parse_region` and checked for overlap and order before any FASTA is read.
   - msprime and tskit are checked first in simulate_pop (RuntimeError(MSPRIME_HELP), exit 1).
   - Every fail-fast check precedes the first INFO line, so each error is the only stderr line on clean input.
   - `--threads` defaults to 1, and the run is limited to 99 regions (c01..c99, two-digit iids).
10. **Region length** = `2 x WINDOW_PAD + max(len(donor.seq))`, the donor element as annotated; the boundary is
    tested exactly. A donor body (left LTR twice) can be longer than its element when the left LTR is the longer
    one.
11. **simulate_pop gains a keyword-only `cache_dir`** (default None), for a read-only FASTA directory without an
    index. The CLI passes `outdir/fai`, as pair does. Otherwise the brief's signature is unchanged.
12. **Truth files and tracts.**
    - One truth file per ordered pair (R4): X annotated (A, B, C), Y any other genome, O1 included.
    - truth/tracts.<label>.bed is written for every sample of the recipient population's taxon (A for C>A, C>A1
      and C1>A1; C for A>C and A1>C1), empty when f = 0. These are PopResult.tracts.
    - fractions.tsv covers every sample: label, group, backbone_bp, tract_bp, fraction, genome_bp, lifted_bp,
      lifted_fraction (6 decimals).
13. **samples.tsv:** `label fasta annotation group role`, paths relative to the sheet. O1 has annotation `.` and
    role `outgroup`; the others have role `.`.
14. **Imports.** `ltrpav.sim` exports the pop API. Importing ltrpav.sim and ltrpav.sim.cli still works without
    msprime: test_pop_without_msprime runs the CLI that way, and test_popmodel's import test passes in the suite.

## Pair byte-identity (`ltrpav-sim pair` after the move)
- Baseline: 239eb8f (git archive), run with PYTHONPATH set to the snapshot.
- Checked after the move commit 0a99f40, and again at the final HEAD 78abe50, since cli.py's `_region` was split
  in the main commit:
  - tests/test_sim.py with `--basetemp`: 70 passed, and all 125 files they write are sha256-identical
    (FASTA, GFF3, truth, samples, params.json).
  - Real B73 `ltrpav-sim pair` runs on B73v5_chr10:2000001-4000000 and B73v5_chr9:30000001-32000000, seeds 1 and 2,
    with `--annotation run/B73v5_LTRs` as benchmark_pav/bakeoff/01_sim.sh passes it (the LTRquest prefix): all 28
    files sha256-identical. The logs are identical apart from timestamps and the output directory.

## Peak RSS and wall time (R2): a 20-Mb, 7-genome run on B73
- Command:
  `ltrpav-sim pop --fasta inputs/B73v5.fa --annotation run/B73v5_LTRs --region B73v5_chr1:50000001-60000000
  --region B73v5_chr10:2000001-12000000 --seed 1 --threads 2`, run under `timeout 15m` and `/usr/bin/time -v`,
  detached (script `$S/rss/probe.sh`).
- Defaults throughout: f 0, per-taxon 2.
- Results:
  - wall time 5:38.46, exit 0;
  - user 572.8 s, sys 32.6 s, 178% CPU.
- Peak RSS, three ways:
  - GNU time's maximum resident set size, the largest single process: 837,172 kB (0.80 GiB);
  - the process tree's summed RSS (time, python, two workers), sampled every 0.5 s: peak 1,794 MB. This counts
    copy-on-write pages shared after the fork once per process;
  - summed PSS, which splits shared pages among the processes that share them: peak 1,659 MB. The PSS sampler
    started about 1.5 min into the run, during ancestry.
- Stages, from the log:
  - annotation load, donors and checks: 24 s;
  - the two chromosomes in parallel (ancestry, events, build): 4:36 and 4:56;
  - join, gaps, annotations, 36 truth tables, tracts and the insertion table: 14 s;
  - writing: 4 s.
- Outputs: 276 MB. Genomes are 38.4-39.8 Mb; 115,722 and 114,405 trees; 11,203 kept insertions (5,236 nested);
  8,351 losses; 1.91 M SNP sites; 202,413 indels; 680 gaps; A1 holds 2,583 alive and 2,319 annotated elements.
- The engine loaders read the probe's outputs:
  - read_samples loads the sheet: 6 annotated genomes, plus O1 with role outgroup and no annotation;
  - load_annotation reads A1.gff3 against A1.fa: 2,319 elements, none dropped as duplicates; nesting levels 0-4;
    1,759 elements with a TSD.

## Engine fingerprints
- Method: `git archive` of 12d3e6c and of 78abe50, each imported alone.
- Outputs: `$S/fp_12d3e6c.txt` and `$S/fp_78abe50.txt`.
- `cmp` shows the files identical: all 7 STAGE_MODULES fingerprints are equal.
  - elements a78af75d…;
  - anchor, raw, blastdb ebbfd97f…;
  - mm2_index 28f6fc79…;
  - genotype_pair, genotype_chunk 52071c27….
- No engine module was edited.

## Concerns
1. **Simulated insertions nearly double each genome.**
   - The 20-Mb B73 probe gives genomes of 38.4-39.8 Mb (+92-99%). The toy grew 0.74 to 1.37 Mb, and Task 3's 5-Mb
     probe grew to 7.4-8.2 Mb.
   - This follows from DESIGN 12 item 4: LTRmix's lam of 1.2e-10 per bp per generation, applied along about
     1.2 M generations of root-to-tip path at t_o 900,000, with nested insertions on top.
   - In the probe, A1 holds 2,583 alive elements: about 129 per Mb of backbone, or 67 per Mb of its own genome.
   - No code change here. It belongs in Task 6/7's calibration and density readout against main3, as the ledger
     already plans.
2. **Resource estimate for a 10 x 10-Mb grid run** (an extrapolation, not measured):
   - each worker uses about the same as here, roughly 0.8 GB or less per 10-Mb chromosome;
   - the parent holds all 7 genomes, about 7 x 195 Mb of sequence plus Copy records and truth rows, so likely
     3-5 GB;
   - at --threads 10, the wall time is roughly one chromosome's, about 5 min on today's load, plus about 1-2 min of
     truth and writing.
   - Well inside the 250-GB budget.
3. **Transient copies in add_gaps.** add_gaps (Task 3) copies a genome's chromosomes while writing gaps, so up to
   two extra copies of that one genome exist at a time. pop.py bounds this to one genome by calling it per genome.
4. **For Task 8:**
   - The file layout and params.json keys are above.
   - `--threads` defaults to 1, so pass it.
   - write_pop does not delete stale files in an existing outdir, apart from each written FASTA's .fai; use fresh
     directories.
   - Each run loads the whole annotation (about 24 s for B73's LTRquest prefix, 127,636 records) and hashes the
     FASTA (2.2 GB).
   - Backbone truth names are source spans `<seqid>:<start>-<end>`; iids are `i<cc><nnnnnn>`.
   - tracts.<label>.bed exist only for the recipient taxon's samples (empty at f = 0). fractions.tsv covers every
     sample.
   - The outputs depend only on the arguments and inputs, never on `--threads`.
5. **Equivalent mutant.** In backbone_elements, the region filter (`e.end <= end`) and the LTR/bounds check
   (`t <= length`) both exclude crossing elements, so either alone suffices. Both are kept, as in pair's
   backbone_genome.
6. **Line length.** Some lines exceed the 110-column setting, up to 117, as in the existing pop modules (popbuild
   and popevents reach 119). E501 is not enforced by the repo's ruff selection; `ruff check .` passes.
