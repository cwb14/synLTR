# Task 9 review: Sequence-identity layer, optional (DESIGN 7.5)

**Range:** 512e344..9a3b854 (one commit, 9a3b854). **Files:** `src/ltrpav/analysis/identity.py` (new),
`tests/test_identity.py` (new), `src/ltrpav/analysis/constants.py` (+2 lines). **Reviewer scratch:**
`/data2/chris/maize_introgression/benchmark_pav/plan2_reviews/task9/`. main3 was read only, through `view/` (symlinks
plus a copy of the sheet); nothing was written in main3. No LASTZ temp folders or processes were left behind.

**Verdicts:** Spec ✅ (two ⚠️ notes, both about rules the brief fixes). Task quality: **Approved**: 0 Critical,
0 Important, 5 Minor.

## Spec Compliance

✅ **Matches the brief and the controller's accepted deviations.**

- **Files and interfaces:**
  - Only the three declared files changed. No engine module was touched.
  - `MG_MAX` and `IDENT_MIN_SITES` were appended verbatim.
  - `IDENTITY_COLUMNS`, `ltr_counts`, `self_counts`, `orient`, `split_nll`, `fit_split`, `fit_mix`, `pred_cdf`,
    `identity` and `write_identity` have the brief's signatures.
- **Brief tests:**
  - The 7 tests and the helpers (`needs_lastz`, `substitute`, `INT_POSITIONS_12`) are AST-identical to the brief.
    The one exception is the declared ruff rename (`_m_flow` and the like) in the slow test.
  - `python -m pytest -W error tests/test_identity.py -m "not slow"`: 12 passed.
  - The slow `fit_mix` test, re-run detached: passed in about 5 min. The project's `addopts -q` plus `-q` hides
    the summary line.
  - `ruff check` is clean. `ruff format` is not a gate (10 of the 11 analysis files would be reformatted).
- **Commit:** author and committer are cwb14, and the message is the brief's. There are no trailers and nothing
  mentions Claude or Anthropic.
- **Aligner (C5):**
  - `align_window(x, y, "asm20", DEFAULT_BACKEND)` is used in `ltr_counts`, `_oriented` and `_locus` (:120,
    :137-139, :333).
- **Counts:**
  - `_count` (:146-161) compares bases over each AlnMap segment's overlap with the LTR intervals.
  - AlnMap segments are the collinear, gap-free plus-strand chain, never overlapping on A or B
    (`localign.AlnMap`). Minus-strand hits go to `inv` and are never counted, so no x column is counted twice.
  - Only A, C, G and T are compared (accepted).
- **Only P copies:** `pmask` = D is a member and `proj[D][:, Y] == P` (:396).
- **Loci read:**
  - the pair loci;
  - `discover(cat, R, S, D, dist, "E")` rows (all tiers);
  - R's RD class through `paint.classes` (recipient discovery: R a member, D present, S E in R's calls).
- **Row kinds (A21):**
  - self rows: >= MIN_SEG sites, u95 from `stats.u95` (D4);
  - pair rows: one per locus and partner, `div` "." below 200 sites;
  - loci with neither get no row.
- **Orientation (D10):**
  - `pstrand[A]` is own strand × b_strand (`catalog.py`:542). So `sd == sy` holds exactly when b_strand is "+",
    and the rule at :486 is the relative orientation, the right one.
  - "." goes to `orient`. A pair that cannot be oriented is counted in the brief's findings line (:420-424).
  - ⚠️ M2.
- **Split:**
  - `nll`, `fit`, `fit_mix` and `pred_cdf` are ported (bitwise, below), with the accepted `nll` deviation.
  - The 200-site filter is in `fit_pairs` (:529), and the same filter feeds the fractions below the split.
  - SE: a delete-one jackknife on D's blocks. Each refit starts from (s, m), and Task 4's rule comes through
    `_why`/`_guard`.
- **Mixture guard:** the 9 rows, AIC 2·nll + 12 against 2·nll + 4, and LTRmix's 18 starts.
- **Fit check (I7):** the five LTRmix points, `cdf_obs_<x>` against `cdf_fit_<x>`.
- **Young:**
  - On the D_pav counted rows whose D copy has a self row: young when u95 < s.
  - Rows `n_RD_young`, `n_SD_young`, `D_young` (jackknife with s fixed: accepted), and
    `sites_needed = u95(0, 1) / s` (= chi2.ppf(0.95, 2) / 2 / s).
- **Below the split:** `frac_RD_below` and `frac_SD_below` on pairs with >= 200 sites.
- **Workers:**
  - a fork `ProcessPoolExecutor(threads)` over chunks;
  - each worker opens its own `Fasta` (cache `work/fai`), and results come back in locus order;
  - one RuntimeError (a worker error or a dead worker).
- **youngest_u95 (N5):**
  - The layer writes R's self rows at R's RD-class loci (R is a member there by construction).
  - It writes D's self rows only where D is a member: the locus's member eid, so the same insertion.
  - `paint._youngest_u95` (`paint.py`:475-490) reads X's row, else D's, and never S's or another genome's.
  - `run_paint` reading identity.tsv is Task 10's (plan l. 2058-2061). Decoy coverage is as accepted.
- **Global constraints:**
  - `-W error` holds: both Nelder-Mead runs are under `np.errstate`, and non-finite values become +inf.
  - Only windows are fetched, never whole genomes.
  - Analysis code lives in `analysis/` only.
- ⚠️ Two rules the brief fixes cost a little exactness on real data:
  - the bare-element x (M1);
  - `orient` for "." strands, where the call's b_strand is already known (M2).

## Independent verification (named risks)

### 1. The substitution count
- **By hand** (`hand_check.py`, output `hand_check.out`):
  - **Pairs:** one random main3 TIL18→TIL01 pair per orientation class (D strand +/-/. × b_strand +/-; 9,346 /
    870 / 9,498 / 915 / 2,593 / 574 pairs).
  - **My own inputs:** coordinates from the element table and the raw pair file, and LASTZ run by hand with the
    engine's `lastz_args()`.
  - **The walk:** the `cigarx` is walked column by column. It checks itself: in every class, 0 "=" columns differ
    and 0 "X" columns match.
  - `_job`'s x and y coordinates, LTR intervals and strand equal mine in all six classes:
    - +1 for ("-","+");
    - -1 for ("-","-") and ("+","-");
    - 0 for ".".
  - Counts identical to `_locus`:

    | class | (sites, diffs) |
    |---|---|
    | ("+","-") | (1419, 14) |
    | ("-","+") | (2480, 52) |
    | ("-","-") | (1348, 31) |
    | (".","+"), oriented +1 | (6392, 37) |

  - The other two differ only where my naive walk is wrong:
    - ("+","+"): 4,281 against 4,277 sites. `_segments` correctly clips hit 2's first 4 columns, which overlap
      hit 1 on y.
    - (".","-"): 5 hits. My best-first fill mixes non-collinear hits that `_chain` correctly excludes.
  - Example, ("-","-") `TIL18_chr1:278782090-278789559`: 31 substitutions in 1,348 LTR sites. Each prints with
    aligned context, e.g. x 15: D C against S A (TTGTTCTCAAA / TTGTTATCAAA).
- **Which LTR is compared:** both of D's LTRs, each against the bases the collinear chain sets opposite it. That is
  the orthologous LTR when the chain stays on the site's diagonal. M1 covers the 0.4% of pairs where it does not.
- **At scale** (`indep_main3.py`):
  - **My recount:** all 23,796 pairs, with minimap2 (mappy asm20), the raw b_strand, and my own CIGAR walk and
    LTR projection.
  - **Against the implementation's own `_align_all`** on a random 2,000 (7 workers, 41 s):
    - (sites, diffs) are identical for 1,604 (80%), and the median differences are 0.
    - Known-strand classes agree closely: 1-3% differ by more than 0.005 in div, in both directions.
    - "." pairs differ more: 23 of 198 and 10 of 48, with the implementation higher in 28 of 33 (M1, M4).
  - **Orientation:** on the 255 "." pairs of that sample, `orient` agreed with b_strand 254 times and skipped none.
    The one miss is M2.

### 2. Port fidelity (`port_check.py`)
- **Method:** LTRmix's `nll`, `fit`, `_lp`, `_mix_par`, `nll_mix`, `fit_mix` and `pred_cdf` were extracted
  verbatim (AST) from `rate_free_split.py` and run beside the port in the same numpy 2.5.4 / scipy 1.18.1.
- **`split_nll`:** equals `nll` bitwise at 400 random (log s, log m) points on 5,000 pairs.
- **`_mix_nll`:** equals `nll_mix` bitwise at 300 random points.
- **`fit_split`:** equals `fit` bitwise on 4 data sets (true s 0.00075, 0.002, 0.0003 and 0; 3,000-8,000 pairs).
- **`fit_mix`:** equals LTRmix's bitwise (weights, s, nll) on 6,000 pairs with 4% gene flow:
  w (0.966089, 0.033911, 0.0), s 0.0019939965, nll 19531.285199.
- **`pred_cdf`:** identical at the five points.
- **The deviation**, checked against mpmath at 420 digits (`ref_mp.py`, 94 cases):
  - The reference is the original, uncancelled formula with mpmath's own regularized gamma.
  - Worst error on the gammaincc branch: 9e-15.
  - Worst error on the tail branch: 1.7e-12 relative (5e-12 absolute), at m <= 1e-200, where terms of about 1.8e4
    cancel.
  - Across the Q = 1e-280 switch both branches agree to <= 2e-16, so the switch is continuous.
  - At k = 1, n = 800, s = 1/800, m = 1e-300: exact -1.0000000000, port -1.0000000000, LTRmix's lp +1.25e297 (the
    runaway). The fix is correct and needed.

### 3. Jackknife blocks and the 200-site filter
- **Blocks:**
  - With D annotated, `discover` sets gstar = g(D) on every D-member row. So `_blocks` reads D's own element
    midpoints (5-Mb blocks), as LTRmix's block bootstrap does.
  - `idx` comes back in catalog order, the order of `_blocks`' boolean mask.
- **Refits:**
  - `refit` caches on the deleted block, so s and m share the refits.
  - The testability rule is Task 4's.
  - `D_young`'s blocks mirror `_d_pav`'s.
- **The 200-site filter:** applied in `fit_pairs` to the split, the fit check and both fractions. `n_pairs` counts
  after it.

### 4. Concurrency and resources
- **Lifecycle:**
  - The fork pool's workers are forked from the calling thread, so `_die_with_parent` (PR_SET_PDEATHSIG) ties them
    to it.
  - On SIGTERM, a worker kills its running lastz child and removes its temp folder.
  - `sweep_lastz_tmp` runs before and after the pool.
- **Inherited state and errors:**
  - Handles inherited through fork are dropped, never shared.
  - A worker error or a dead worker becomes one RuntimeError, and pending chunks are canceled.
- **My runs:** 7-worker runs through `_align_all` (2,000 pairs) and through the engine's `align_window` (23,796
  pairs, `placement.py`) left no folder in /dev/shm and no lastz process.

### 5. youngest_u95 from the donor's copy (N5)
Covered under Spec Compliance. The layer never writes tracts itself. It supplies the self rows that paint's existing
X-then-D lookup reads, and D's rows exist only where D is a member.

### 6. Independent recompute of main3's isolation s, TIL01-TIL18
Counts come from `indep_main3.py`; fits use LTRmix's verbatim `fit`.

| source | pairs >= 200 sites | s | m | CDF observed, x = 0 / .001 / .002 / .003 / .005 | fraction below s |
|---|---|---|---|---|---|
| minimap2, raw b_strand, my walk (independent) | 23,526 | 0.000750 | 0.01532 | 0.0235 / 0.0464 / 0.0865 / 0.1313 / 0.2196 | 0.0334 |
| implementer's report | 23,739 | 0.000747 ± 0.0000945 | 0.01546 | 0.0231 / 0.0461 / 0.0853 / 0.1290 / 0.2149 | 0.0328 |
| my driver over the engine's AlnMap (`placement.py`) | 23,745 | 0.000747 | 0.01546 | ... / 0.0461 / ... / ... / 0.2148 | 0.0329 |
| the same, LASTZ's off-end LTRs dropped (M1) | 23,574 | 0.000751 | 0.01522 | ... / 0.0463 / ... / ... / 0.2181 | 0.0334 |

- **Concern 2 of the report** (s above LTRmix's 0.048%): the alignment is ruled out as the cause, since a different
  aligner gives the same s. Two candidates remain:
  - the pair set: D's own P calls here, against LTRmix's ortholog table;
  - LTRmix's whole-record global alignment (`ltrmix.py`:717-743).

## Strengths
- **The port is exact, and the one deviation is right:** bitwise LTRmix wherever Q >= 1e-280; mpmath-exact in the
  tail; continuous at the switch; and it removes a real runaway. The report states the deviation openly, with
  evidence.
- **The count is exact and shown to be.** `_count` is short and reads the engine's own AlnMap invariants (sorted,
  non-overlapping, plus strand). The hand check reproduces it in every orientation class.
- **The headline numbers hold up** against a different aligner, an independent orientation source and LTRmix's own
  fit: s 0.000750 against 0.000747.
- **The engine's worker discipline is reused, not reinvented:** fork pool, die-with-parent, temp sweeps, and one
  error line.
- **Tests beyond the brief pin real risks:**
  - ambiguity codes and overlapping intervals;
  - LTRmix equality and the m -> 0 bound;
  - a reverse-strand partner;
  - the young and below-split path;
  - a worker failure.
- **The report is honest.** The s_mix concern (gene-flow weight 0, the tail below the isolation component) is stated
  in the findings line without changing LTRmix's model after seeing main3.

## Issues

### Critical
None.

### Important
None.

### Minor

**M1. With x as the bare element, LASTZ can slide one of D's LTRs onto paralogous sequence inside the partner's
site. That happens in 0.40% of main3's pairs, 2.65% of the "." ones.**
- **Where:**
  - `identity.py`:491-492: x is the element, with no flanks;
  - `localign.py`:205: `_chain` needs strictly increasing q_st and q_en.
- **What:**
  - Sometimes D's and the partner's copies differ by an indel near one end that is longer than LASTZ's y-drop.
  - Then the orthologous hit of that end's LTR and the main hit both start (or end) at x's edge, and `_chain`
    cannot combine them.
  - The main hit wins, extended through a paralogous, LTR-like segment 2-6 kb inside the site. That LTR's columns
    are then compared with non-orthologous bases.
- **Examples** (`discord.py`):

  | locus, element | LTR | LASTZ (diffs / sites, placement) | minimap2 |
  |---|---|---|---|
  | 287290, `TIL18_chr2:286011827-286028072` | 5' | 67 / 682, at y 2759-3443 | 3, at y 500-1183, the site's start |
  | 277616 | 3' | 118 | 11 |
  | 289936 | 5' | 66 | 2 |

  At 287290, 67 diffs is ~10%: the host's own LTR-LTR K is 0.109.
- **Scale** (`placement.py`, `placement_summary.py`, all 23,796 pairs):
  - In 96 pairs (0.40%), LASTZ puts an LTR's outer end more than 30 bp from where D's own call puts the site end,
    and minimap2 puts it on that end. By D strand: "." 84 of 3,167 (2.65%), "-" 11, "+" 1.
  - Their median div is 0.0297, against 0.0092 under minimap2.
- **Effect on the split:**
  - s goes 0.000747 -> 0.000751 with the off-end LTRs dropped (minimap2: 0.000750).
  - `frac_SD_below` goes 0.0329 -> 0.0334.
  - So the split is unaffected. The per-pair `div` of those rows is about 3× too high.
- **Fix** (needs a ruling, because the brief fixes x as D's element):
  - Fetch x as D's element ± WINDOW_PAD, the shape of the engine's own windows. Shift the LTR intervals by the pad
    actually fetched (it is clipped at a sequence start).
  - D's flanks then anchor the chain on the site's diagonal, and `_segments` clips the slid hit's overlap.
  - On the five traced pairs this fixed three (67 -> 3, 118 -> 11, 66 -> 2; `flank_test.py`). The other two are a
    tandem duplicate with 6-kb "LTRs" and an intra-LTR alignment difference.
  - Alternatively, or as well: count an LTR only when its outer end maps within T bp of the site end from D's own
    call, and report how many were dropped.
  - Re-run `placement.py` afterwards.

**M2. `orient` re-infers an orientation the call already holds, and gets it wrong on inverted-repeat-rich elements.**
- **Where:**
  - `identity.py`:486 (strand 0 when sd or sy is 0) and :326-327 (`_oriented`);
  - `catalog.py`:542 (`pstrand` = own × b_strand).
- **What:**
  - A P call's b_strand is the partner window's orientation relative to D's + strand, which is exactly what the
    pair alignment needs. It is known for "." elements too.
  - The catalog keeps only own × b_strand, which is 0 where D's strand is ".". So the layer runs `orient`: two more
    `align_window` calls (four LASTZ runs) for 13% of main3's pairs.
  - `orient` picks the wrong strand where the reverse chain is longer. Seen on 1 of the 255 "." pairs in the sample,
    `TIL18_chr1:259511749-259525481`:
    - the reverse chain is 10,436 bp, the forward 7,670 bp, with 20 inverted hits;
    - so `orient` returns -1, and the pair gets 0 LTR sites;
    - b_strand "+" gives 134 sites under LASTZ (171 under minimap2).
  - At full scale, orienting by b_strand keeps 23,745 pairs at >= 200 sites, against the layer's 23,739.
  - The lost pairs are written with 0 sites and are not counted among the "skipped". The report's "all were oriented
    by the alignment; none skipped" is true, but about 6 were oriented wrongly.
- **Fix** (needs a ruling, because D10 prescribes `orient` for "."):
  - Keep each call's b_strand in the catalog, e.g. a `pbstrand` array beside `pstrand`, read in the same pass, and
    use it for every pair.
  - Keep `orient` only for a call without it.

**M3. Two strand paths have no toy test.**
- **Where:** `tests/test_identity.py`; `identity.py`:486, :326-334.
- **What:**
  - Every toy's D copy is "+" or ".". If `pstrand` were misread as a relative strand, the code would
    reverse-complement y when D is "-" and the partner "-". That regression passes all 13 tests, yet on main3 it
    would break the ("-","-") and ("-","+") classes (10,413 pairs).
  - No end-to-end test sends a "." pair through `orient`'s -1 path (`yy = ry`, `aln = rev`).
  - Both paths are correct on main3 by hand (risk 1).
- **Fix:**
  - Add a locus with D's copy and the partner's site both on "-" (sequences in the same orientation) and assert its
    counts.
  - Add a "." locus whose partner copy is reverse-complemented and assert its counts.

**M4. "." elements carry most of the per-pair aligner disagreement, and many are not LTR retrotransposons in
shape.**
- **Where:**
  - `identity.py`:491 (the LTR bounds are taken as given);
  - the findings intro, :564-581.
- **What:**
  - 6,250 of TIL18's 14,724 "." elements (42%) have LTRs covering more than half the element, against 11% of the
    stranded ones.
  - Some are tandem duplicates with 6-kb "LTRs" 63 bp apart (`TIL18_chr9:23473005-23485170`). Some have abutting
    "LTRs" ([0, 1600) + [1600, 10849)), so the whole element counts as LTR columns. Some are nested hosts.
  - In the 2,000-pair sample, 12% and 21% of "." pairs differ from minimap2 by more than 0.005 in div, against
    1-3% of stranded pairs. This comes from slides (M1) and from intra-LTR bridging: locus 294297 has 129 / 2,540
    under LASTZ against 9 / 2,204 under minimap2.
  - The split is unaffected (risk 6). Any per-class reading of identity.tsv is not.
- **Fix:**
  - Add one findings line counting the pairs and self rows whose D LTR bounds cover more than half the element.
  - Task 12: report s and the below-split fractions without "." (or low-confidence) pairs, as a sensitivity check.
  - Not a Task 9 defect: LTRmix reads the same bounds.

**M5. A component with zero weight gets a meaningless mean in stats and findings.**
- **Where:** `identity.py`:617-628 (rows), :646-654 (findings line).
- **What:**
  - On my 6,000-pair check, `fit_mix` (bitwise LTRmix) returned w_tail 0.0 with m_tail 6.4e284.
  - The layer would write `m_tail` 6.39092e+284, and the findings line would quote "tail mean 6.391e+284" inside
    the "upper tail only when its mean exceeds..." clause.
- **Fix:**
  - Leave the fit unchanged. Where a weight is below 1e-6, write that component's mean as nan, with the note
    "component unused (weight 0)".
  - Say the same in the findings line.

### Acknowledged, not counted
- **Controller-accepted deviations:** s_mix stated as a subgroup shift; the `nll` tail sum (verified above);
  ACGT-only columns; an `orient` tie returning 0; D_young's se with s fixed; the private helpers, including
  `genotype._die_with_parent`; decoy youngest_u95 only where loci overlap.
- **Task 10's stats key with --identity** (report concern 3):
  - `package_fingerprint` hashes only the modules it is given (`checkpoint.py`:63-68); it is not an import closure.
  - So the key must name `ltrpav.localign` (`lastz_args`, the chain), `ltrpav.constants` (MIN_SEG, WINDOW_PAD,
    SCORE, LASTZ_SEED) and `ltrpav.genotype` (`tsv_field`), plus `backend_version("lastz")`.
  - The Task 8 review already left constants and genotype to Task 10 by ruling.
- **Report precision claim:** "relative error <= 4e-15 in 8 cases" is true for its cases. Over 94 cases the worst is
  1.7e-12 (m <= 1e-200), which is harmless.
- **D_young cannot resolve anything on main3:**
  - `sites_needed` is about 4,000 identical LTR sites, more than most LTRs have, so 0 of 97 and 0 of 54 are young
    in the sample.
  - The findings line states the threshold. This is a limit of the clock, not of the code.

## Assessment

**Task quality: Approved.**

- **Correctness:** the layer is correct against its specification.
  - The LTRmix port is bitwise exact, and the one numerical deviation is mpmath-exact.
  - The substitution counts are exact over the engine's alignment in every orientation class.
  - The jackknife and the 200-site filter are right, and the workers are sound.
  - The main3 split was reproduced independently: 0.000750 against 0.000747.
- **What real data exposes is small and comes from rules the brief fixes:**
  - M1: the bare-element x lets LASTZ slide an LTR in 0.4% of pairs.
  - M2: `orient` stands in for an orientation the call already holds.
  - Neither moves s. Both inflate or drop individual pair rows, mostly "." ones, and each needs a ruling.
- **The rest are cheap:** M3 is two toy loci that pin the strand rule. M4 and M5 are reporting clarity.

## Probe files (scratch)
`/data2/chris/maize_introgression/benchmark_pav/plan2_reviews/task9/`:
- `view/`: the read-only main3 view (symlinks; a real `work/` for the checksum cache).
- `port_check.py`, `ref_mp.py`, `ref_mp.json`: port fidelity against LTRmix (verbatim, by AST) and mpmath (run with
  `/home/chris/bin/mambaforge/envs/for_user/bin/python`, which has mpmath).
- `hand_check.py`, `hand_check.out`: the by-hand CIGAR walk per orientation class.
- `indep_main3.py`, `indep_main3.log`, `indep/mappy_counts.tsv`, `indep/impl_counts.tsv`: the independent recount,
  the s fit, and the implementation's 2,000-pair sample.
- `discord.py`, `flank_test.py`: M1 traces and the flanked-x test.
- `placement.py`, `placement.tsv`, `placement_summary.py`: the full-scale LTR placement audit and the paired s.
- `slow_test.log`: the slow test re-run.
