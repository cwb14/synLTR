# Plan 3: review findings applied

Review: `plan3-review.md` (1 Critical, 9 Important, 23 Minor; 33 calls judged). Plan:
`docs/plans/2026-11-12-plan3-benchmark.md`, rewritten 2026-11-12 (1,626 lines, still 16 tasks). The previous draft is
saved as scratch `plan3draft/plan3_v1.md`. Line numbers below refer to the new plan.

**Outcome:** 33 of 33 findings applied, 0 declined. The coordinator's rulings for C1 and I1-I9 were followed as written.
No Minor conflicts with DESIGN.

## New drafting probes behind the fixes

Perfect genotypes, env `ltrmix`, at most 16 threads and 15 minutes. Outputs are in scratch `plan3draft/`:
`drafting_probes_v2.txt`, `probe_direction.py`, `probe_outgroup_ext.py`.

- **Direction (C1), 19 scenarios.**
  - Every pulse under the default demography reads `0000`: population pulses both ways, f 0.5 at Ta 500, and the
    PT-like pulse into A1's lineage.
  - Lineage-to-lineage pulses under default background Ne read `+-+-` (unresolved) in both directions.
  - The small-Ne design orients both ways: every Ne 1,000, A1's lineage split at 2,000 and C1's at 30,000, f 0.5, Ta 500.
    C1>A1 reads `+-+0` (P3=>P1), A1>C1 reads `+++-` (P1=>P3), and the null reads `0000`.
  - With A1's split at 5,000 the reverse direction is unresolved, because the sister-taxon filter truncates the shared
    branch.
- **Outgroup split (I2).** Conflict at 120k, 600k, 900k and 1.2M generations: 0.20-0.23, 0.05-0.07, 0.017-0.025 and
  0.007-0.009. The rule "smallest candidate at most 0.032 in all three ingroup genomes" picks 900k.
- **Loss mix (I2), from main3's own calls.**
  - 9,219 top-level B73 elements that Zd carries. Derived states in TIL18 and TIL01, pooled: S 12%, T 51%, D 17%, O 20%.
  - Mean O `b_ins`: 12,915 and 14,295 bp.

## Critical

| Finding | Applied | Plan lines |
|---|---|---|
| **C1** Direction cannot fire in any simulated gene-flow run | Direction scenarios probed and predicted codes listed. `Demog` gains lineage populations (`sub_a`, `sub_c`) and pulse codes (`C>A1`, `C1>A1`, `A1>C1`). Grid gains 3 PT-like and 8 positive-control runs (small-Ne lineage design, the first pre-listed design that orients both ways). Task 8 writes `direction_predictions.tsv` before any scoring; RULES rule 7 replaces the old rule 5. Task 13 reports direction power from the PT-like runs and states "not estimable" if they read "none". D_dir is set against its simulated null. Missing `00++`/`00--` codes and orienting a population pulse go to Plan 4 leads. | 68-86 (probe results), 374-384 (Demog), 449 (test), 1012-1023 (predictions step), 1034 and 1036 (grid rows `ptlike`, `posctl`), 1241-1250 (rule 7), 1346 (SIM_RESULTS section 5), 1468-1474 (Task 13 item 4), 1579 (leads) |

## Important

| Finding | Applied | Plan lines |
|---|---|---|
| **I1** Painting head-to-head gives LTRpav the true recipient | The head-to-head painting is scored from view `roles`, with inferred recipients for both tools. A wrong recipient gives `wrong_recipient = 1`, recall 0 and AUROC NA, counted the same way for both. View `main` is kept for calibration and power. `eval_ltrmix.py` records a missing `elements.A1.tsv`. | 1060, 1155-1160, 1185-1186, 1342 |
| **I2** Sims denser than main3; shallow outgroup; projection by length | Simulator calibration from main3 before the pilot: t_o by the conflict rule; loss mix S:D:T:O as measured, adding a `replace` mechanism and the truth rule `O` on fate replaced; replacement length from main3's O `b_ins`. DESIGN 12 records "simulator calibration is not method tuning". Realism extended to after-genotyping values. Z projected by locus count, and recall also per informative locus. Compute re-estimated for the larger genomes. | 88-106, 142-196, 262-266, 377, 388-391, 530, 630, 707, 994-1011, 1090-1096, 1173-1180, 1197, 1358 |
| **I3** Decoy test may be vacuous; no absolute calibration | Rows `e0_RD`, `e0_RS`, `e1_RD`, `e1_RS`. Degeneracy diagnostic (rule 6, the "not tested in main3's regime" label). Realized-FDR bar: pooled at most 0.05, CP upper bound at most 0.10. NA pairs dropped from the sign tests and counted. View `anydecoy`, with a combined-adoption rule. | 861-866, 1063, 1161-1166, 1224-1237, 1238-1240 |
| **I4** Any-discovery null under one-sided dropout is diluted | 10 dropout nulls per level (20 trio nulls). Rule 4 judges `any` and `anydecoy` on them alone, beside the 30 standard nulls. | 1037, 1218-1223, 1348 |
| **I5** Three bottleneck nulls are too few | Bottleneck nulls: 30 if the gate allows, else 10 (never fewer). The gate formula counts them. | 183-196, 1035, 1097-1100 |
| **I6** "Calibrated" has no rule | Rule 2: the 95% chi-square interval of SD(null Z) includes 1, and the mean is within 2 SE of 0. Applied to D_pav, dD, truth D and LTRmix's four D. SD(D) is reported against the mean jackknife SE. | 1210-1215, 1338-1339 |
| **I7** Decision 11 testable on sims | View `nodonor`: the sheet gives C1 annotation `.`, the pair files exclude C1's own (`view.sh` PAIRS_FILTER), `ltrpav-merge` reruns in the view, then stats `--trio A1,B1,C1`. The pilot checks it. Reported beside the genus `zd` case; the rule is unchanged. | 137, 959-962, 1064, 1087-1088, 1168, 1360, 1505-1510 |
| **I8** Empty-site rule silent on SNPs and indels | Tasks 3-4: only structural events break the window. Test `test_truth_E_with_snp_and_indel_beside_site`. | 711-714, 735 |
| **I9** Bare `ltrquest` | `run_lq.sh` activates `ltrquest_<HEAD>` and checks `command -v ltrquest` is in it; the commit is recorded. Cleanup deletes only the listed scratch files, then `record check` must print `reuse`. `*.work` directories are kept. | 1294-1318 |

## Minor

| # | Applied | Plan lines |
|---|---|---|
| M1 | The pilot runs `--until ltrmix`. `pilot.tsv` is two grid rows. `RULES.md` is dated before the pilot is scored. | 1081-1089, 1272-1273 |
| M2 | `eval.json` holds the eval scripts' sha256. Task 11 rescores every run with the final code before `summarize.py`. | 1144, 1335-1336 |
| M3 | `PopResult` is defined. `tract_bed` is keyed by chromosome. `shift_element` is kept, so `pair` stays byte-identical. | 689-692, 764, 773-781, 785 |
| M4 | Task 6's byte-identity check excludes sentinel rows and the new rows. | 892-895 |
| M5 | The degenerate input is built directly, not taken from seed 4. | 881-883 |
| M6 | Envs named for each scoring script; `evalib` is numpy-only. | 1109-1113 |
| M7 | `rate_free_split.py` path, the trio directory `A1_B1_C1`, one canonical comparator tree. | 108-110, 1068, 1124 |
| M8 | The default trio view moves into Task 13 (`six/views/main`). Tasks 14, 15 and 16 read it. | 1441-1460, 1521, 1537, 1552 |
| M9 | `precision_by_length`; precision by called-tract length. | 1133, 1343 |
| M10 | Mean and SD of Z per cell; probit P(Z > 3) on f per ta; f80 with its interval. | 1194-1197, 1340 |
| M11 | The genotype bar is also reported per target class and per backbone window. | 1171, 1216-1217 |
| M12 | First mm2 pair run alone with tree-PSS sampling; stop at 250 GB; estimate 4.5 h. | 170, 1428-1431 |
| M13 | `copy_noise = 0.005` per insertion, before copying the left LTR; test added. | 387, 617-619, 649 |
| M14 | LTRmix presence/absence accuracy against truth. | 1189 |
| M15 | `no_outgroup_filter` stratum beside LTRmix's D tests. | 1199-1200 |
| M16 | msprime wheel check for Python 3.13; `pytest.importorskip` in every msprime or tskit test module. | 232-233, 435-437 |
| M17 | No env changes while detached jobs run. | 237-238, 1287 |
| M18 | Review Focus item on non-ACGTN backbone bases; Task 2 rule and test. | 280-285, 511-513, 556 |
| M19 | `--demography FILE.json` and `demog_from_json`; defaults unchanged; test. | 396, 808-809, 825 |
| M20 | Backbone-element K2P adds the sample's derived LTR SNPs to the source p; test. | 636-640, 658 |
| M21 | The per-window low-recombination middle is named a heuristic. | 412-415 |
| M22 | Rule 8 states the expected truth-D difference and the informative comparison, including the 0.66 ratio. | 1251-1259 |
| M23 | Grid table fixed (dropout row inside it; totals stated). LTRquest after `grid.tsv.done`. `lq/` layout. `match_by_coords` with a test. EDTA counts cross-checked against `main3/qc_fixed/edta`. PPID 1 or a systemd user manager. | 120, 245, 1024-1037, 1140, 1294, 1313-1316, 1406 |

## The 33 calls

The review table marks 9 calls "revise" (2, 4, 5, 10, 14, 16, 17, 18, 32). The coordinator counted 10; the 10th is
call 1's recombination note (M21). Every call's revision note was applied, the "accept" calls with notes included.

| Call | Revision applied | Plan lines |
|---|---|---|
| 1 | Low-recombination middle named a heuristic (M21) | 412-415 |
| 2 | Outgroup split by the pre-registered conflict rule before the pilot: 900k (I2) | 88-97, 377, 1003-1009 |
| 4 | LTRmix rates kept; density reported after genotyping; Z projected by locus count; degeneracy tested (I2, I3) | 1173-1180, 1197, 1238 |
| 5 | Loss split from main3's measured derived states, with a replace mechanism (I2) | 99-106, 388-391, 994-1002 |
| 6, 8 | SNPs and indels are noise in the truth (I8) | 711-714 |
| 10 | Bottleneck nulls 30 or 10; PT-like and positive-control runs; predictions first (C1, I5) | 1031-1037 |
| 11 | Dropout nulls 10 per level, judged alone (I4) | 1037, 1218-1223 |
| 13 | Gap density said to be conservative | 641 |
| 14 | Head-to-head from the `roles` view (I1) | 1155-1160 |
| 16 | e0/e1 rows and degeneracy; cross-fitting as a Plan 4 lead | 861-866, 1238-1240, 1579-1582 |
| 17 | NA handling, realized-FDR bar, combined view, dropout-only null, RULES dated before the pilot is scored | 1218-1237, 1272 |
| 18 | Direction rule rewritten around predicted codes and the positive control | 1241-1250 |
| 20 | LTRmix's recipient handled; presence/absence accuracy; no-outgroup stratum; script path | 1068, 1182-1200 |
| 21 | Expected truth-D outcome stated first | 1251-1259 |
| 22 | Pinned env, cleanup then check, `lq/` layout | 1294-1318 |
| 23 | `nodonor` view on the sims (I7) | 1064 |
| 25 | Citrus recall at q <= 0.05 also reported | 1517 |
| 27 | mm2 first pair alone with RSS; 4.5 h | 170, 1428-1431 |
| 28 | Envs frozen during runs; eval scripts fingerprinted | 237-238, 1144 |
| 30 | EDTA counts cross-checked against `main3/qc_fixed/edta` | 1406 |
| 31 | The painting's inverted-block flags go untested on the sims, noted | 717 |
| 32 | Backbone K2P from the sample's own LTRs (M20) | 636-640 |

## Compute, revised

| Item | Estimate |
|---|---|
| One 7-genome run | ~68 min at 16 threads, ~34 min effective. Genomes are ~177 Mb with ~13,900 elements, after the 900k outgroup. |
| Grid | ~77 h with 30 bottleneck nulls, ~65 h with 10 |
| Real benchmark | ~22 h |
| Total | ~99 h with 30 bottleneck nulls, so the gate is expected to choose 10: **~87 h (3.6 days)** |

The gate formula counts every added run: `N7 = 88 + bottleneck nulls`. If the projection still exceeds 96 h with 10
bottleneck nulls, the pre-registered 50-Mb fallback applies; no null is cut.
