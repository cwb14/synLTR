### Task 9: Sequence-identity layer, optional (DESIGN 7.5)

**Files:**
- Create: `src/ltrpav/analysis/identity.py`, `tests/test_identity.py`
- Modify: `src/ltrpav/analysis/constants.py` (append `MG_MAX`, `IDENT_MIN_SITES`)

**Interfaces:**
- Consumes:
  - `Catalog` (`pcls`, `pseq`, `pstart`, `pend`, `pstrand`), `Trio`, `discover`, `block_ids`, `jackknife`, `u95`;
  - `localign.align_window` with `constants.DEFAULT_BACKEND` (LASTZ, the engine's aligner), `seqio.Fasta`, `revcomp`,
    `read_elements`;
  - `MIN_SEG`, `WINDOW_PAD` (engine constants, read only);
  - `scipy.special.gammaincc`, `scipy.stats.chi2`, `scipy.optimize.minimize`.
- Produces:

```python
IDENTITY_COLUMNS = ("kind", "lid", "trio", "genome", "partner", "sites", "diffs", "div", "u95", "young")
def ltr_counts(x: str, y: str, ltrs: list[tuple[int, int]]) -> tuple[int, int]   # (sites, substitutions) in x's LTR columns
def self_counts(ltr5: str, ltr3: str) -> tuple[int, int]
def orient(x: str, y: str) -> int        # +1 / -1: y's strand that aligns x better (>= MIN_SEG bases); 0: neither aligns
def split_nll(params: np.ndarray, k: np.ndarray, n: np.ndarray) -> float          # params = (log s, log m)
def fit_split(k: np.ndarray, n: np.ndarray, start: tuple[float, float] = (1e-3, 1e-2)) -> tuple[float, float]
def fit_mix(k: np.ndarray, n: np.ndarray, s0: float, m0: float) -> tuple[np.ndarray, float, float, float, float, float]
    # (weights isolation/gene flow/tail, gene-flow mean, s, m, tail mean, nll): LTRmix fit_mix, its 18 starts
def pred_cdf(x: float, n: np.ndarray, s: float, m: float, nsim: int = 200, seed: int = 0) -> float   # LTRmix pred_cdf
def identity(cat: Catalog, trio: Trio, size: int, threads: int, dist: np.ndarray
             ) -> tuple[list[StatRow], Findings, list[tuple]]
def write_identity(rows: list[tuple], path: Path) -> None
```

Rules. This is outside the PAV-only core. Rows have layer `identity`, the findings their own section, and per-locus rows
go to `identity.tsv`.

- **Constants**, appended to `ltrpav/analysis/constants.py`:

```python
MG_MAX = 1e-3              # mixture fit: post-split gene-flow component's mean divergence <= 0.1% (LTRmix rate_free_split.py)
IDENT_MIN_SITES = 200      # LTR sites an ortholog pair needs to enter the split fit: LTRmix's validated --min-sites
```

- **Needs D annotated** (D's LTR bounds); otherwise skipped with a line.
- **The aligner** is the engine's: `align_window(x, y, "asm20", DEFAULT_BACKEND)`, LASTZ. Its preset argument is the
  engine's own default.
- **`ltr_counts`** counts aligned columns and substitutions exactly, by comparing bases over each segment's overlap with
  the LTR intervals; columns with N on either side are skipped. **`self_counts`** does the same, aligning the 5' LTR to
  the 3' LTR.
- **Loci the layer reads:**
  - the pair loci: loci D discovers where D's own call into Y (S or R) is P;
  - the D_pav counted rows, `discover(cat, R, S, D, dist, "E")` (all tiers, outgroup E);
  - the loci of R's RD painting class (R a member; R's own calls give D present, S E).
- **`identity.tsv` row kinds:**
  - **self rows:** one per annotated copy of R, S or D at those loci whose two LTRs align (`self_counts` with
    >= `MIN_SEG` sites). `genome` = the copy's genome, partner `.`, `u95` from `stats.u95`.
  - **pair rows:** one per pair locus and partner Y with two P copies. `genome` = D, `partner` = Y.
  - Loci with neither get no row.
- **Pair alignment:**
  - Y's site comes from D's own call: `pseq[D][:, Y]`, `pstart`, `pend`, `pstrand`.
  - x = D's element and y = Y's site ± `WINDOW_PAD`, both fetched on their genome's + strand. y is reverse-complemented
    when its strand differs from D's.
  - Where either strand is unknown (BED annotations write `.`), `orient(x, y)` takes the orientation from the alignment.
    A pair it cannot orient is skipped and counted, never silently: one findings line "<n> pair(s) skipped: orientation
    not inferred".
  - The LTR intervals are D's `ltr_left` and `ltr_right` in x coordinates.
  - Pairs with `sites < IDENT_MIN_SITES` are written with `div` `.` and left out of the fits.
- **Rate-free split** (LTRmix `rate_free_split.py`):
  - **Isolation model:** k ~ Poisson(n(s + X)), X ~ Exp(m), with the closed form
    `s/m - log(m n) - (k+1) log(1 + 1/(n m)) + log Q(k+1, n (1 + 1/(n m)) s)`. Nelder-Mead on the logs, fitted to the
    S–D pairs. SE of s and m by delete-one-block jackknife on D's blocks, each refit starting from the full fit.
  - **Guard, the mixture fit** (`fit_mix`): isolation, plus post-split gene flow (unshifted, mean <= `MG_MAX`), plus an
    unshifted upper tail. Post-split S–D gene flow pulls the isolation s down: LTRmix's own check found 0.024% against a
    true 0.18% at 4% gene flow. Rows: `s_mix`, `m_mix`, `w_iso`, `w_flow`, `w_tail`, `m_flow`, `m_tail`, and `aic_mix`
    against `aic_iso` (2·nll + 12 against 2·nll + 4).
  - **Fit check** (LTRmix's points): for x in 0, 0.001, 0.002, 0.003 and 0.005, `cdf_obs_<x>` (observed fraction of
    pairs with diffs/sites <= x) against `cdf_fit_<x>` (`pred_cdf` under the isolation fit).
- **Younger than the split** (on the D_pav counted rows):
  - each RD and SD locus whose D copy has a self row is young if its `u95 < s` (column `young` 1 or 0);
  - counts `n_RD_young`, `n_SD_young`, `D_young`;
  - `sites_needed = chi2.ppf(0.95, 2) / 2 / s`: identical LTR sites a single insertion needs to qualify.
- **Below the split:** fractions of R–D and of S–D pairs with `diffs / sites < s`.
- **Rows:**
  - `identity_split` (scope `S;D`): `s`, `m` (with se), the mixture rows, the fit-check rows, n pairs;
  - `identity_young` (trio): `n_RD_young`, `n_SD_young`, `D_young`, `sites_needed`;
  - `identity_below_split`: `frac_RD_below`, `frac_SD_below`.
- **Workers:** a fork `ProcessPoolExecutor(threads)` over locus chunks. Each worker opens its own `Fasta` (cache
  `work/fai`); results come back in locus order.

- [ ] **Step 1: Write the failing tests**

```python
needs_lastz = pytest.mark.skipif(shutil.which("lastz") is None, reason="lastz missing (the engine's aligner)")

def substitute(seq: str, positions: list[int]) -> str:
    """Each listed base replaced by the next one in ACGT order (always a change)."""
    s = list(seq)
    for p in positions:
        s[p] = "ACGT"[("ACGT".index(s[p]) + 1) % 4]
    return "".join(s)

INT_POSITIONS_12 = [500 + 250 * i for i in range(12)]           # inside the internal region [400, 3400)

@needs_lastz
def test_ltr_counts_exact():
    rng = random.Random(5); e = toy.make_element(rng, 400, 3000)[0]          # LTRs [0, 400) and [3400, 3800)
    y = toy.rand_seq(800, rng) + substitute(e, [10, 50, 90, 120, 3405, 3700] + INT_POSITIONS_12) + toy.rand_seq(800, rng)
    assert ltr_counts(e, y, [(0, 400), (3400, 3800)]) == (800, 6)

@needs_lastz
def test_self_counts():
    rng = random.Random(6); ltr = toy.rand_seq(400, rng)
    assert self_counts(ltr, substitute(ltr, [20, 200, 380])) == (400, 3)

@needs_lastz
def test_orient():
    rng = random.Random(7); e = toy.make_element(rng, 400, 2000)[0]
    site = toy.rand_seq(500, rng) + e + toy.rand_seq(500, rng)
    assert orient(e, site) == 1 and orient(e, revcomp(site)) == -1 and orient(e, toy.rand_seq(3800, rng)) == 0

def test_fit_split_recovers():
    rng = np.random.default_rng(1); n = np.full(50_000, 800.0)
    k = rng.poisson(n * (0.002 + rng.exponential(0.01, n.size)))
    s, m = fit_split(k, n)
    assert s == pytest.approx(0.002, rel=0.15) and m == pytest.approx(0.01, rel=0.15)

@pytest.mark.slow          # about 5 min (18 Nelder-Mead starts on 50,000 pairs; 10,000 is too few): CI deselects it
def test_fit_mix_guards_against_gene_flow():
    rng = np.random.default_rng(2); n = np.full(50_000, 800.0)
    flow = rng.random(n.size) < 0.04                                          # 4% post-split gene flow
    k = rng.poisson(n * np.where(flow, rng.exponential(3e-4, n.size), 0.002 + rng.exponential(0.01, n.size)))
    s_iso, m_iso = fit_split(k, n)
    w, m_flow, s_mix, m_mix, m_tail, nll = fit_mix(k, n, s_iso, m_iso)
    assert abs(s_mix - 0.002) < abs(s_iso - 0.002) and 0.01 < w[1] < 0.1    # re-review: w_flow 0.042, s 0.00210 vs 0.00115

def test_pred_cdf_at_zero():
    n = np.full(1000, 800.0)                                                  # P(k = 0) = e^(-ns) / (1 + nm)
    assert pred_cdf(0.0, n, 0.002, 0.01) == pytest.approx(math.exp(-1.6) / 9, abs=0.01)

@needs_lastz
def test_identity_end_to_end(tmp_path, toy_fastas):
    rng = random.Random(9)
    els = [toy.make_element(rng, 400, 2000)[0] for _ in range(7)]          # 2,800 bp; LTRs [0, 400) and [2400, 2800)
    flanks = [toy.rand_seq(2000, rng) for _ in range(8)]
    copies = {"D": els,
              "R": [substitute(e, list(range(10, 10 * i + 1, 10))) for i, e in enumerate(els[:6])] + [els[6]],
              "S": [substitute(e, [2500]) for e in els[:6]] + [toy.rand_seq(2800, rng)]}   # S's 7th site: unrelated
    fastas = {}
    for g, cs in copies.items():
        fastas[g] = tmp_path / f"{g}.fa"
        fastas[g].write_text(">chr1\n" + "".join(f + c for f, c in zip(flanks, cs)) + flanks[7] + "\n")
    pos = [2001 + 4800 * i for i in range(7)]
    loci = ([loc(p, "R:P* S:P* D:P* O:E", length=2800, ltr=400) for p in pos[:6]]
            + [loc(pos[6], "R:P* S:P D:P* O:E", length=2800, ltr=400, strand={"D": "."})])
    cat = write_run(tmp_path / "run", loci, seqids=("chr1",), fastas=fastas, fasta_dir=toy_fastas).load()
    rows, f, out = identity(cat, Trio("R", "S", "D", True), block_size(cat), 2, pav_distances(cat)[0])
    pairs = sorted((r[1], r[4], r[5], r[6]) for r in out if r[0] == "pair")       # (lid, partner, sites, diffs)
    assert [(s, d) for _, y, s, d in pairs if y == "R"] == [(800, i) for i in range(6)] + [(800, 0)]
    assert [(s, d) for _, y, s, d in pairs if y == "S"] == [(800, 1)] * 6
    selfs = {(r[3], r[1]): (r[5], r[6]) for r in out if r[0] == "self"}          # (genome, lid) -> (sites, diffs)
    assert len(selfs) == 20 and {s for s, _ in selfs.values()} == {400}
    assert [selfs[("R", lid)][1] for lid in cat.lid] == [0, 1, 2, 3, 4, 5, 0]
    assert {selfs[("S", lid)][1] for lid in cat.lid[:6]} == {1} and {selfs[("D", lid)][1] for lid in cat.lid} == {0}
    assert rows and all(r.layer == "identity" for r in rows)
    assert any("1 pair(s) skipped: orientation not inferred" in t for _, t in f.items())
```

`test_pred_cdf_at_zero` uses the model's closed form at k = 0: `P(k=0) = e^(-ns) / (1 + nm)`, with n = 800, s = 0.002,
m = 0.01. The tolerance 0.01 covers its 200-replicate simulation.

- [ ] **Step 2: Run** `python -m pytest -W error tests/test_identity.py`. Expected: FAIL.
- [ ] **Step 3: Implement** as specified.
- [ ] **Step 4: Run** `python -m pytest -W error tests/test_identity.py`. This is the one run that includes the slow
  `fit_mix` test, about 5 min; the suite command deselects it everywhere else. Expected: PASS.
- [ ] **Step 5: Commit.** `"Add optional sequence-identity layer with rate-free split"`
---

