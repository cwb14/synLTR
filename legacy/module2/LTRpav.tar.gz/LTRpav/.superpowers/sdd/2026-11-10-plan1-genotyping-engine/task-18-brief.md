### Task 18: Flank routes and hybrid

**Files:** Create `src/ltrpav/anchor/flanks.py`, `tests/test_flanks.py`

**Interfaces:**
- Produces: `@dataclass Piece: seqid: str; start: int; end: int` (0-based);
  `flank_pieces(elements: list[Element], fasta: Fasta, cap: int = FLANK_CAP, target: int = FLANK_TARGET) -> list[Piece]`;
  routes `FlankMm2Route(cap)`, `FlankBlastRoute(cap)`, `HybridRoute(primary: Route)`. `get_route` maps
  `"flank-mm2"`, `"flank-blast"` and `"hybrid"`; hybrid's primary is fastga if installed, otherwise mm2.

- [ ] **Step 1: Write the failing tests**

```python
def test_pieces_skip_elements_and_ns():   # pieces never overlap any annotated element or N run; each >= FLANK_PIECE_MIN
def test_pieces_nearest_first_and_capped():  # collected outward until >= target bp; never beyond cap
def test_flank_mm2_resolves_toy(tmp_path):   # genotype_pair with flank-mm2 recovers the toy expectations for P/E/D cases
def test_hybrid_fills_unanchored(tmp_path):
    # primary = PafRoute whose PAF lacks blocks within 15 kb of one element -> primary window "no_anchor";
    # hybrid -> that element resolved with its expected state
@pytest.mark.skipif(shutil.which("blastn") is None, reason="BLAST not installed")
def test_flank_blast_blocks(tmp_path): ...   # blocks produced; strand from sstart > send
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.**
  - **Pieces:** walk outward from each top-level element and dedupe pieces by coordinates.
  - **`FlankMm2Route`:** the same B index as Task 15, mapping pieces with `best_n=5`.
  - **`FlankBlastRoute`:**
    - Build the database with `makeblastdb -dbtype nucl` into `workdir/blastdb/<B>`. Decompress bgzip input
      through `Fasta` into a temp FASTA first.
    - Search with `blastn -task megablast -outfmt "6 qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore nident" -evalue 1e-20 -max_target_seqs 50 -max_hsps 20 -num_threads T`.
    - Each hit is a block with `matches = nident` and `alen = length`.
  - **`HybridRoute.raw_blocks`:** take the primary's raw blocks, compute provisional windows, gather pieces only for
    elements whose window is not ok, map them with the flank-mm2 method, and return the union.
- [ ] **Step 4: Run.** Expected: PASS.
- [ ] **Step 5: Commit** `"Add flank-mapping routes and hybrid"`.

---

