#!/usr/bin/env python3
"""Benchmark zygosity calls against read-phasing truth (haplotagged reads; truth independent of ltrkin's model).

For every element inside a phased region, reads that carry the full element (anchored >= 100 bp in a flank and
reaching >= 100 bp into the internal region past the LTR) are grouped by haplotag (phase block, haplotype).
Truth:
  two_hap : in some phase block both haplotypes carry it (>= 3 reads each, minor share >= 20%)
  one_hap : >= 5 tagged carrying reads, minor haplotype <= max(1 read, 5%) in every block, and the other haplotype
            of that block is sampled near the element (>= 3 tagged reads within +-10 kb)
  unknown : otherwise
Compared with ltrkin genotypes: F/F = full on both haplotypes; F/E, F/S, F/N = full on one.
Usage: haplotag_eval.py -g genotypes.tsv -b reads.bam --tags tags1.tsv[,tags2.tsv] --regions regions.bed -o prefix
  tags TSV: columns read, block_id, hap (1/2), score (net phased-allele agreement); regions BED: chrom start end.
Only reads whose tag rests on a net agreement of >= --min-tag-score phased alleles are used: weakly tagged reads
(few heterozygous SNVs nearby) mix the haplotypes and make two_hap truth spurious.
"""
import argparse
import sys

import numpy as np
import pandas as pd
import pysam

A = 100


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-g", "--genotypes", required=True)
    ap.add_argument("-b", "--bam", required=True)
    ap.add_argument("--tags", required=True, help="comma-separated haplotag TSVs (read, block_id, hap)")
    ap.add_argument("--regions", required=True, help="BED of phased regions")
    ap.add_argument("--min-mapq", type=int, default=20)
    ap.add_argument("--min-tag-score", type=int, default=5, help="minimum |score| of a haplotag [5]")
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    tags = {}
    for p in a.tags.split(","):
        t = pd.read_csv(p, sep="\t", usecols=["read", "block_id", "hap", "score"])
        t = t[t.score.abs() >= a.min_tag_score]
        tags.update(zip(t.read, zip(t.block_id, t.hap)))
    reg = pd.read_csv(a.regions, sep="\t", header=None, usecols=[0, 1, 2], names=["c", "s", "e"])
    reg = reg.groupby("c").agg(s=("s", "min"), e=("e", "max"))   # outer intervals
    g = pd.read_csv(a.genotypes, sep="\t", dtype={"element_id": str})
    bam = pysam.AlignmentFile(a.bam)
    rows = []
    for r in g.itertuples():
        if r.chrom not in reg.index or not (reg.at[r.chrom, "s"] <= r.start - 1 and r.end <= reg.at[r.chrom, "e"]):
            continue
        s0, e = r.start - 1, r.end
        a_end, b_st = s0 + r.ltr5_len, e - r.ltr3_len
        carry = {}
        for side in (s0, e):
            for x in bam.fetch(r.chrom, max(0, side - 60), side + 60):
                if x.is_unmapped or x.is_secondary or x.mapping_quality < a.min_mapq:
                    continue
                left = x.reference_start <= s0 - A and x.reference_end >= a_end + A
                right = x.reference_start <= b_st - A and x.reference_end >= e + A
                big = any(op == 2 and ln >= 0.5 * (e - s0) for op, ln in x.cigartuples)
                if (left or right) and not big and x.query_name in tags:
                    carry[x.query_name] = tags[x.query_name]
        blocks = {}
        for b, h in carry.values():
            blocks.setdefault(b, {1: 0, 2: 0})[int(h)] += 1
        near = {}
        for x in bam.fetch(r.chrom, max(0, s0 - 10000), e + 10000):
            if x.mapping_quality >= a.min_mapq and not x.is_secondary and x.query_name in tags:
                b, h = tags[x.query_name]
                near.setdefault(b, {1: set(), 2: set()})[int(h)].add(x.query_name)
        two = any(min(v.values()) >= 3 and min(v.values()) / sum(v.values()) >= 0.2 for v in blocks.values())
        ntag = sum(sum(v.values()) for v in blocks.values())
        one = (not two and ntag >= 5
               and all(min(v.values()) <= max(1, 0.05 * sum(v.values())) for v in blocks.values())
               and any(len(near.get(b, {1: set(), 2: set()})[2 if v[1] >= v[2] else 1]) >= 3 for b, v in blocks.items()))
        truth = "two_hap" if two else ("one_hap" if one else "unknown")
        rows.append(dict(element_id=r.element_id, chrom=r.chrom, start=r.start, end=r.end, clade=r.clade,
                         genotype=r.genotype, gq=r.gq, flags=r.flags, n_tagged_carriers=ntag, truth=truth))
    o = pd.DataFrame(rows)
    o.to_csv(a.out + ".elements.tsv", sep="\t", index=False)
    o["call"] = np.select([o.genotype == "F/F", o.genotype.isin(["F/E", "F/S", "F/N"])], ["both", "one"], "other")
    known = o[o.truth != "unknown"]
    conf = known[known.gq >= 20]
    tab = pd.crosstab(conf.truth, conf.call)
    with open(a.out + ".summary.txt", "w") as fh:
        fh.write(f"elements in phased regions: {len(o)}; truth known: {len(known)}; called GQ>=20 among them: {len(conf)}\n")
        fh.write(tab.to_string() + "\n")
        for lab, call_, tr in (("full on both (F/F)", "both", "two_hap"), ("full on one", "one", "one_hap")):
            tp = ((conf.call == call_) & (conf.truth == tr)).sum()
            prec = tp / max(1, (conf.call == call_).sum())
            rec = tp / max(1, (known.truth == tr).sum())
            fh.write(f"{lab}: precision {prec:.3f} ({tp}/{(conf.call == call_).sum()}), "
                     f"recall {rec:.3f} ({tp}/{(known.truth == tr).sum()})\n")
        fh.write("\nby genotype (GQ>=20):\n" + pd.crosstab(conf.genotype, conf.truth).to_string() + "\n")
    print(open(a.out + ".summary.txt").read())


if __name__ == "__main__":
    main()
