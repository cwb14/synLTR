# Task 7 review: Direction (exploratory), 87519c8..980eba0

## Spec Compliance
- ✅ DFOIL_ALT_SIGNS, signature(), DFOIL_ALT, PAIR_DISC: identical to the brief and plan2-review C2 (checked line by line); the six pattern pairs per statistic pair up as the brief's PAIR_DISC.
- ✅ Hand check (probe, scratch task7/test_probe.py): 3x1010, 3x1001, 3x0101, 15x0110 gives DFO = (6-18)/24 = -0.5, DIL = +0.5, as computed by hand.
- ✅ Discovery per pair: gstar = first listed genome that is a member; patterns read from gstar's calls; resolved (>=0) required for quartet; Z/outgroups must be E (==0); missing never counts as absent.
- ✅ n(X->Y): all X present, 1..|Y|-1 Y present, complete-case on X,Y,Z,outgroups, Z/outgroups E, merged states; D_dir, strata, caveat note, FOUR_LIST note present.
- ✅ Skips: no outgroup / needs two genomes per taxon, one findings line, rows []. Accepted deviations (test case a, NaN -> "none" with not-testable note, per-row block id, D_dir coordinate fallback) implemented as accepted.
- ✅ Tests: 8 pass with -W error; ruff clean.
- ⚠️ Resolution rows for DFOIL use the first quartet member's calls, not each pair's gstar (brief: "in the gstar calls"); consistent with the accepted block rule, minor.

## Strengths
- Pattern masks computed once per discoverer tuple (cache), vectorized; pair_counts reuses the same masks as direction, so the tested counts are the ones used.
- NaN Z handling is explicit; no direction on NaN; error on informative rows lacking a site rather than silent drop.
- Tests include the analytic branch-length signature check and the discovery-rule test.

## Issues
### Critical
none
### Important
none
### Minor
1. direction.py `_dfoil` (informative row without P1 site raises ValueError): if gb's call has no coordinates for P1 (e.g., missing pair call), the whole direction run aborts. Probe with E calls was fine; real unresolved/absent coordinates could trigger it. Consider falling back to the next quartet member's coordinates as D_dir does, or warn-and-drop. 
2. direction.py `_dfoil` resolution rows use gb only (see compliance note).
3. Imports of private helpers (_first_member, _fmt, _guard, _why): already accepted as deferred.
4. Tests do not cover: NaN-Z -> "none" signature row, age strata, D_dir coordinate fallback, unequal-Ne note text. Add one small test for the NaN path (e.g., the probe above gives DFI/DOL nan -> "none").
5. One findings line per quartet (DFOIL, 4-LIST, resolution) can be long with many genomes per taxon; acceptable for exploratory output.

## Assessment
Spec compliance: compliant (named risks 1-5 verified).
Task quality: Approved
