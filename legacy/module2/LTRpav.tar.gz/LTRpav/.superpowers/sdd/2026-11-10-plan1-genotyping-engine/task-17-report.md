# Task 17 report: FastGA route
Implemented src/ltrpav/anchor/fastga.py (FastgaRoute, name "fastga", whole_genome, reads_elements False), registered in get_route/KNOWN_ROUTES/__all__.
Symlinks <label>.fa[.gz] in workdir/fastga, `FastGA -pafx -T<n> -P<workdir>/tmp -k`, cwd there, stdout -> gzip(mtime=0) -> X__Y.fastga.paf.gz (tmp+rename), non-zero exit -> RuntimeError with stderr tail; missing binary -> RuntimeError at use; read_paf with swap when ctx.a is not the sorted-first label.
Example -pafx line (cg:Z: tag, picked up by read_paf):
a1 300130 0 100000 + b1 300000 0 100000 99012 100003 255 dv:f:0.0098 df:i:991 cg:Z:59=1X13...
Tests (tests/test_routes.py): test_fastga_route (non-empty, col1 = A seqids, reverse direction no second Popen, symlinks, no index files beside user data, coverage >0.9, no block spans an A-only element), test_fastga_splits_at_long_insertion (90 bp split, 40 bp kept), test_fastga_missing_binary; test_get_route updated.
TDD: RED = ImportError (no ltrpav.anchor.fastga); GREEN = 4 passed. Full suite passes, ruff clean.
Timing: fastga tests ~4.4 s total (toy 300 kb).
Notes: FastGA itself breaks alignments at ~>=80 bp indels; read_paf split is a backstop. Cache key params: format, split_indel (no FastGA version).

## Fix round 1
Changes (fastga.py): link names are <label>.<sha256[:12]>.fa[.gz] (checkpoint.file_checksum), so a changed FASTA gets its own index; fcntl.flock exclusive lock per genome (<label>.<sha12>.lock) held across the FastGA run, locks taken in sorted order (deduped); symlinks created atomically (tmp + os.replace) after the concurrent test exposed a FileExistsError race in _link.
Tests: test_fastga_changed_fasta_gets_fresh_index (B replaced under the same label: blocks reflect new FASTA, 2 index sets), test_fastga_concurrent_pairs_sharing_a_genome (two threads, A-B and A-C: blocks equal sequential runs, FastGA runs do not overlap; fails without the flock as checked by disabling it).
Note: checkpoint.file_checksum's tmp name is per-pid, so in-process threads racing on a cold checksum cache can collide; the test warms the cache as anchor_pair does.
Commands: pytest tests/test_routes.py (37 passed, 3 repeats), full suite pass, ruff clean.
