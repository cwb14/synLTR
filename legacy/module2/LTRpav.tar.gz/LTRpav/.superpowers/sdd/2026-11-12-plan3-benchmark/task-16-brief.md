### Task 16: DESIGN 10.3 rerun at the end, and wrap-up

**Files:**
- Outside the repo:
  - `benchmark_pav/plan3/real/papers/{views/main, final_papers.tsv, FINAL.md}`;
  - `benchmark_pav/plan3/real/common/compare_papers.py`: its final edits, with the new sha256 recorded;
  - `benchmark_pav/plan3/RESULTS.md`, `benchmark_pav/dead_ends.md`, `$P/memo_ltrpav.md`.
- Repo: `docs/DESIGN.md` 12, "Plan 3 outcome" (3-6 lines).

- [ ] **Step 1: Final view.** `papers/views/main` is a copy of `six/views/main` with
  `ltrpav-stats --trio B73,TIL01,TIL18 --identity --threads 32`, then `ltrpav-paint --trio B73,TIL01,TIL18`. Run it
  detached (the identity layer takes ~20 min) and verify the PID.
- [ ] **Step 2: Final edits, then compare.** Edit `common/compare_papers.py`:
  - the verdict constants become `PASS, MISS = "PASS", "MISS"` (they read "PASS (prelim)" and "MISS (prelim)");
  - new rows read `sim/tables`: rules 1-2, and the null distributions of Z and dD;
  - record the new sha256.

  Then `compare_papers.py --run papers/views/main --prefix final` writes `final_papers.tsv`. Verdicts read PASS or MISS,
  without "(prelim)":
  - The D_pav row keeps its bar, D > 0 and Z > 3, and states rules 1-2's outcome beside it. If the null was not
    calibrated, the row also gives the empirical null quantile of Z and says the verdict rests on it.
  - The "gene flow, not lineage sorting" row reports dD against the simulated null distribution of dD.

  Diff against `main3_analyses/prelim_papers.tsv` and explain every changed row; main3 was engine 7d71073.
- [ ] **Step 3: Write `FINAL.md`:**
  - the 10.3 table, with LTRmix's columns as in PRELIM;
  - the misses, with their `dead_ends.md` entries;
  - what changed from PRELIM, and why;
  - CLAUDE.md's closing four items, labeled by how far each was tested: the headline sentence, the mechanism, the
    generality (six genomes, genus, citrus), the predictions.

  Then `benchmark_pav/plan3/RESULTS.md`: one page linking every benchmark's RESULTS.md, with one line per bar (PASS or
  MISS) and the Plan 4 leads. The leads include:
  - parts of the s and D gaps the simulations could not test;
  - the missing `00++`/`00--` DFOIL-alt entries, and whether any PAV statistic can orient a population-level pulse;
  - painting resolution;
  - decoy cross-fitting, if the decoy model failed the null;
  - the overview's known limits with 20 trios: a page of about 264 mm, and large scaffolds that can be called
    chromosomes.
- [ ] **Step 4: Record.**
  - Add a Plan 3 section to `memo_ltrpav.md`:
    - dates;
    - snapshot sha(s);
    - envs and versions (msprime, the LTRquest commit);
    - the calibration values;
    - inputs and exact commands;
    - outputs;
    - wall times against the estimates;
    - gotchas;
    - the `claude --resume` name.
  - Add DESIGN 12, "Plan 3 outcome", with calibrate.sh's exact calibration values beside the `src` drafting defaults.
  - Run the suite.
  - Commit: `"Record Plan 3 benchmark outcome"`.
- [ ] **Step 5: Hand off to the user.** Report:
  - the bars, PASS or MISS, per benchmark;
  - the null, calibration and power;
  - the variant and direction decisions;
  - misses and their investigations;
  - decision 11's evidence (`nodonor`, genus `zd`), for the user's decision after Plan 3;
  - Plan 4's inputs.

---

## Spec coverage

| DESIGN | Task |
|---|---|
| 10.2 genome-level simulator: msprime with admixture, LTRmix demography default, real backbone, SNPs, small indels, real families, identical LTRs, nesting, solo-LTRs, deletions, gaps | 1-5 |
| 10.2 annotations from truth with dropout and jitter; a few runs annotated by LTRquest | 4, 5, 10 |
| 10.2 grid: f 0-0.50, admixture times, one-sided dropout 0-40%, 30 null replicates, 2 genomes per taxon | 8, 10 |
| 10.2 LTRmix on the same simulated genomes (head-to-head on one truth) | 8, 9, 11 |
| 10.2 bars: null |Z| > 3 <= 5%; power curves; tract precision and recall by length; direction accuracy | 9, 11 |
| 10.1 simulated high-tier precision (population sims) | 9, 11 |
| 10.5 presence/absence accuracy of each tool (inputs for Plan 4) | 9 |
| 7.1 painting "any discovery" variant evaluated with one-sided dropout | 7, 9, 11 |
| 7.4 painting emissions (EM degeneracy carry-over): decoy-anchored model tested on sims only | 6, 7, 9, 11 |
| 7.6 direction kept only if sims recover it; unequal Ne in null and gene-flow runs | 1, 8, 9, 11, 13 |
| 7.1 decision 11 (four-point fallback): default run, where it matters reported | 8, 9, 11, 13, 14 |
| 10.3 rerun at the end | 13, 16 |
| 10.4 six genomes: PT, negative control, TIL25 donor, direction with simulated power | 13 |
| 10.4 *Zea* genus event (EDTA), sweet orange, portability, stability | 14, 15 |
| 8 msprime optional extra; env + lock; tests on synthetic fixtures | 1-7 |
| 11 steps 4-5 | 8-16 |
| Plan 2 open gaps (split s, D_pav vs D_ins) | 9, 11, 16 |
