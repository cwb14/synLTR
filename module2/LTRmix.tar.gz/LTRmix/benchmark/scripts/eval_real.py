#!/usr/bin/env python3
"""Score an ltrmix run on B73/TIL18/TIL01 against published truth: Yang et al. 2023 ELAI (B73 column, lifted to v5),
named loci (Yang 2023; Barnes et al. 2022), ELAI high-frequency regions, inversion literature.
Writes OUT/benchmark_real.tsv (one row per benchmark item) and prints a summary. Nothing here feeds back into ltrmix."""
import os as _os
_os.environ.setdefault("NUMPY_MADVISE_HUGEPAGE", "0")  # avoid THP compaction stalls on a busy server
import argparse
import os

import numpy as np
import pandas as pd
from scipy.stats import rankdata, spearmanr

T = "/data2/chris/maize_introgression/benchmark/truth"
INV = [("Inv1n", "chr1", 65_000_000, 115_000_000, "parviglumis-common, absent from maize (Yang 2023; v2 coords, "
        "Pyhajarvi 2013)"),
       ("Inv4m", "chr4", 172_883_881, 188_131_462, "mexicana/highland maize; absent from B73 (v5 coords)")]


def auc(score, label):
    label = np.asarray(label, bool)
    n1, n0 = label.sum(), (~label).sum()
    if n1 == 0 or n0 == 0:
        return np.nan
    r = rankdata(score)
    return float((r[label].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def load_truth():
    t = pd.read_csv(f"{T}/elai_summary.v5.tsv", sep="\t", dtype={"chrom_v5": str})
    t = t[t.chrom_v5.isin([str(i) for i in range(1, 11)])]
    t["chrom"] = "chr" + t.chrom_v5
    t = t.rename(columns={"pos_v5": "pos"})
    return t


def per_element_truth(e, t, col="B73.amp", flank=20_000):
    out = np.full(len(e), np.nan)
    nsnp = np.zeros(len(e), int)
    for c, g in t[t[col] > -900].groupby("chrom"):
        p, v = g.pos.values, g[col].values
        m = (e.c == c).values
        s, en = e.start.values[m] - flank, e.end.values[m] + flank
        i, j = np.searchsorted(p, s), np.searchsorted(p, en)
        cs = np.r_[0, np.cumsum(v)]
        n = j - i
        out[np.where(m)[0]] = np.where(n > 0, (cs[j] - cs[i]) / np.maximum(n, 1), np.nan)
        nsnp[np.where(m)[0]] = n
    return out, nsnp


def windows(e, t, win, score_col, w_col=None):
    rows = []
    tt = t[t["B73.amp"] > -900]
    for c in [f"chr{i}" for i in range(1, 11)]:
        ee, g = e[e.c == c], tt[tt.chrom == c]
        if len(ee) == 0 or len(g) == 0:
            continue
        n = int(max(ee.end.max(), g.pos.max()) // win) + 1
        wi = ((ee.start + ee.end) // 2 // win).astype(int).values
        w = ee[w_col].values if w_col else np.ones(len(ee))
        sc = np.bincount(wi, ee[score_col].values * w, n)
        sw = np.bincount(wi, w, n)
        ti = (g.pos // win).astype(int).values
        tm = np.bincount(ti, g["B73.amp"].values, n)
        tn = np.bincount(ti, minlength=n)
        rows.append(pd.DataFrame(dict(c=c, score=np.where(sw > 0, sc / np.maximum(sw, 1e-12), np.nan),
                                      truth=np.where(tn >= 5, tm / np.maximum(tn, 1), np.nan))))
    return pd.concat(rows, ignore_index=True)


def shift_test(w, nperm=1000, seed=1):
    ok = w.score.notna() & w.truth.notna()
    r = spearmanr(w.score[ok], w.truth[ok]).correlation
    rng = np.random.default_rng(seed)
    null = np.empty(nperm)
    for k in range(nperm):
        parts = []
        for c, g in w.groupby("c", sort=False):
            parts.append(np.roll(g.score.values, rng.integers(1, len(g)) if len(g) > 1 else 0))
        s = np.concatenate(parts)
        m = ~np.isnan(s) & w.truth.notna().values
        null[k] = spearmanr(s[m], w.truth.values[m]).correlation
    return r, (1 + (null >= r).sum()) / (1 + nperm), int(ok.sum())


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("out")
    ap.add_argument("--rec", default="B73v5")
    ap.add_argument("--nperm", type=int, default=1000)
    a = ap.parse_args()
    R = []

    def row(section, item, value, bar="", verdict="", note=""):
        R.append(dict(section=section, item=item, value=value, bar=bar, verdict=verdict, note=note))

    st = pd.read_csv(os.path.join(a.out, "stats.tsv"), sep="\t")
    t = load_truth()
    b73 = t["B73.amp"].where(t["B73.amp"] > -900)
    row("truth", "B73 ELAI mean ancestry (dosage/2)", round(b73.mean() / 2, 4))
    # A. genome-wide
    for test, strat in (("D_kmer", "all"), ("D_ins", "all"), ("D3_triples", "all"), ("D_self_outgroup", "LTR sites")):
        r = st[(st.test == test) & (st.stratum == strat)].iloc[0]
        row("genome-wide", f"{test} D (Z)", f"{r.D:+.4f} ({r.Z:.1f})", "D>0, Z>3",
            "PASS" if r.D > 0 and r.Z > 3 else "MISS")
    f = st[st.test == "f_lower_bound"].iloc[0]
    row("genome-wide", "admixture-fraction lower bound (identity spectrum)", round(float(f["f"]), 4),
        "reported vs ELAI 0.170", "", "lower bound by construction")
    for mode in ("ancestry", "recent"):
        h = st[(st.test == f"hmm_{mode}") & (st.stratum == a.rec)].iloc[0]
        row("genome-wide", f"HMM {mode}: donor-like posterior excess over decoy", round(float(h.excess_over_decoy), 4),
            "reported vs ELAI 0.170", "", f"{int(h.n_tracts)} tracts vs {int(h.n_decoy_tracts)} decoys; "
            f"{int(h.n_tracts_q05)} at q<=0.05; mean tract {float(h.mean_tract_bp) / 1e3:.0f} kb")
    for _, r in st[st.test == "D_ins_by_age"].iterrows():
        row("age strata", f"D_ins {r.stratum}", f"{r.D:+.3f} ({r.Z:.1f}; n={int(r.nA)}+{int(r.nB)})")
    # B. chromosomes
    el = pd.read_csv(os.path.join(a.out, f"elements.{a.rec}.tsv"), sep="\t")
    el["c"] = el.chrom.str.extract(r"_(chr\d+)$")[0]
    el["len"] = el.end - el.start + 1
    pcol = [c for c in el.columns if c.startswith("post_ancestry_")][0]
    rcol = [c for c in el.columns if c.startswith("post_recent_")][0]
    elai_c = (t[t["B73.amp"] > -900].groupby("chrom")["B73.amp"].mean() / 2)
    chrom = pd.DataFrame(index=[f"chr{i}" for i in range(1, 11)])
    chrom["ELAI_B73"] = elai_c
    chrom["post_mean"] = el[el.c.notna()].groupby("c").apply(lambda g: np.average(g[pcol], weights=g.len))
    don = el["class"].isin(["near_donor", "donor_only"])
    sis = el["class"].isin(["near_sister", "sister_only"])
    chrom["class_share"] = el[el.c.notna()].assign(d=don, s=sis).groupby("c").apply(lambda g: g.d.sum() / max(g.d.sum() + g.s.sum(), 1))
    rs = st[st.test == "R_share_D_by_chrom"].copy()
    if len(rs):
        rs["c"] = rs.stratum.str.extract(r"_(chr\d+)$")[0]
        rs = rs[rs.c.notna()].set_index("c")
        chrom["kmer_share"] = rs["kmer_share"].astype(float)
        chrom["ins_share"] = rs["ins_share"].astype(float)
    truth_low = {"chr5", "chr8", "chr9"}
    for col in [c for c in chrom.columns if c != "ELAI_B73"]:
        low = set(chrom[col].sort_values().index[:3])
        rho = spearmanr(chrom[col], chrom.ELAI_B73).correlation
        row("chromosomes", f"three lowest by {col}", ",".join(sorted(low, key=lambda x: int(x[3:]))),
            "chr5,chr8,chr9 (p=1/120 for an exact match)", "PASS" if low == truth_low else
            f"{len(low & truth_low)}/3", f"Spearman with B73 ELAI per chromosome {rho:+.2f}")
    chrom.round(4).to_csv(os.path.join(a.out, "benchmark_chromosomes.tsv"), sep="\t")
    # C. windows (pre-registered: posterior, 1000 circular shifts, bar p<0.01 at >= 1 Mb)
    el["is_don"] = don.astype(float)
    el["is_sis"] = sis.astype(float)
    for win in (100_000, 500_000, 1_000_000, 2_000_000, 5_000_000, 10_000_000):
        w = windows(el[el.c.notna()], t, win, pcol, "len")
        r, p, n = shift_test(w, a.nperm)
        row("windows", f"posterior vs ELAI, {win / 1e6:g} Mb", f"r={r:+.3f}, p={p:.4f}, n={n}",
            "p<0.01 at >=1 Mb" if win >= 1e6 else "", ("PASS" if p < 0.01 else "MISS") if win >= 1e6 else "")
        sub = el[el.c.notna() & (don | sis)].copy()
        w2 = windows(sub, t, win, "is_don")
        r2, p2, n2 = shift_test(w2, a.nperm)
        row("windows", f"model-free class share vs ELAI, {win / 1e6:g} Mb", f"r={r2:+.3f}, p={p2:.4f}, n={n2}")
    # D. element-level ROC against ELAI dosage around each element
    dos, nsnp = per_element_truth(el[el.c.notna()].reset_index(drop=True), t)
    ee = el[el.c.notna()].reset_index(drop=True).assign(dos=dos, nsnp=nsnp)
    ee = ee[ee.nsnp >= 3]
    for hi in (1.0, 1.5):
        m = (ee.dos >= hi) | (ee.dos <= 0.2)
        for col, nm in ((pcol, "ancestry"), (rcol, "recent")):
            row("elements", f"AUROC {nm} posterior, ELAI >= {hi} vs <= 0.2", round(auc(ee[col][m], ee.dos[m] >= hi), 4),
                "", "", f"n_pos={int((ee.dos >= hi).sum())}, n_neg={int((ee.dos <= 0.2).sum())}")
    # E. tracts vs ELAI
    tt = t[t["B73.amp"] > -900]
    beds = {}
    for nm, fn in (("recent", f"tracts.{a.rec}.bed"), ("ancestry", f"ancestry.{a.rec}.bed")):
        bb_ = pd.read_csv(os.path.join(a.out, fn), sep="\t")
        bb_.columns = [c.lstrip("#") for c in bb_.columns]
        bb_["c"] = bb_.chrom.str.extract(r"_(chr\d+)$")[0]
        beds[nm] = bb_
    bed = beds["recent"]
    for (qmax, tag), (nm_, bed) in [(x, y) for x in ((0.05, "q<=0.05"), (1.01, "all")) for y in beds.items()]:
        tag = f"{nm_} {tag}"
        bb = bed[(bed.q <= qmax) & bed.c.notna()]
        ins = np.zeros(len(tt), bool)
        for _, r in bb.iterrows():
            ins |= ((tt.chrom == r.c) & (tt.pos >= r.start0) & (tt.pos <= r.end)).values
        if ins.sum():
            row("tracts", f"ELAI dosage of SNPs inside called tracts ({tag})",
                f"mean {tt['B73.amp'][ins].mean() / 2:.3f} vs genome {tt['B73.amp'].mean() / 2:.3f}; "
                f"frac dosage>=1: {(tt['B73.amp'][ins] >= 1).mean():.3f} vs {(tt['B73.amp'] >= 1).mean():.3f}",
                "", "", f"{len(bb)} tracts, {int((bb.end - bb.start0).sum() / 1e6)} Mb, {int(ins.sum())} SNPs")
    # ELAI tract recall by length (runs of dosage > 1 in B73)
    runs = []
    for c, g in tt.groupby("chrom"):
        on = (g["B73.amp"].values > 1.0)
        p = g.pos.values
        i = 0
        while i < len(on):
            if on[i]:
                j = i
                while j + 1 < len(on) and on[j + 1]:
                    j += 1
                runs.append((c, p[i], p[j]))
                i = j + 1
            else:
                i += 1
    runs = pd.DataFrame(runs, columns=["c", "s", "e"])
    runs["len"] = runs.e - runs.s
    for (qmax, tag), (nm_, bed) in [(x, y) for x in ((0.05, "q<=0.05"), (1.01, "all")) for y in beds.items()]:
        tag = f"{nm_} {tag}"
        bb = bed[(bed.q <= qmax) & bed.c.notna()]
        hit = []
        for _, r in runs.iterrows():
            x = bb[(bb.c == r.c) & (bb.end >= r.s) & (bb.start0 <= r.e)]
            hit.append(len(x) > 0)
        runs[f"hit_{tag}"] = hit
        for lo, hi_, nm in ((0, 1e4, "<10kb"), (1e4, 1e5, "10-100kb"), (1e5, 5e5, "100-500kb"), (5e5, 1e9, ">=500kb")):
            m = (runs.len >= lo) & (runs.len < hi_)
            row("tract recall", f"ELAI>1 runs {nm} overlapped by a tract ({tag})",
                f"{runs[f'hit_{tag}'][m].mean():.3f}" if m.sum() else "nan", "", "", f"n={int(m.sum())}")
    # F. named loci
    loci = pd.read_csv(f"{T}/loci.v5.tsv", sep="\t")
    for _, L in loci.iterrows():
        c = f"chr{L.chrom}"
        for fl in (50_000, 200_000):
            x = el[(el.c == c) & (el.end >= L.start - fl) & (el.start <= L.end + fl)]
            note = []
            for nm_, bd in beds.items():
                bb = bd[(bd.c == c) & (bd.end >= L.start - fl) & (bd.start0 <= L.end + fl)]
                note.append(f"{nm_} tract q={bb.q.min():.3g}" if len(bb) else f"no {nm_} tract")
            row("named loci", f"{L['name']} +-{fl // 1000} kb (expect {L.expect_B73})",
                f"{len(x)} elements; classes {x['class'].value_counts().to_dict()}; max post ancestry "
                f"{x[pcol].max() if len(x) else np.nan:.3f}, recent {x[rcol].max() if len(x) else np.nan:.3f}",
                "", "; ".join(note), L.source)
    # G. high-frequency regions
    hf = pd.read_csv(f"{T}/hf.v5.bed", sep="\t", header=None, names=["chrom", "s", "e", "name"])
    hf["c"] = "chr" + hf.chrom.astype(str)
    hf["n"] = hf.name.str.extract(r"_n(\d+)$")[0].astype(int)
    for nmin, tag in ((3, "all 52 clusters"), (10, ">=10 SNPs")):
        H = hf[hf.n >= nmin]
        inside = np.zeros(len(el), bool)
        for _, r in H.iterrows():
            inside |= ((el.c == r.c) & (el.end >= r.s - 50_000) & (el.start <= r.e + 50_000)).values
        mi = el[pcol][inside].mean()
        mo = el[pcol][~inside & el.c.notna()].mean()
        # circular-shift null of region positions per chromosome
        rng = np.random.default_rng(2)
        null = []
        sizes = {c: int(el[el.c == c].end.max()) for c in el.c.dropna().unique()}
        for _ in range(200):
            ins2 = np.zeros(len(el), bool)
            for _, r in H.iterrows():
                off = rng.integers(0, sizes[r.c])
                s2, e2 = (r.s + off) % sizes[r.c], (r.e + off) % sizes[r.c]
                if e2 < s2:
                    continue
                ins2 |= ((el.c == r.c) & (el.end >= s2 - 50_000) & (el.start <= e2 + 50_000)).values
            null.append(el[pcol][ins2].mean())
        p = (1 + (np.array(null) >= mi).sum()) / 201
        row("high-frequency regions", f"mean posterior within 50 kb ({tag}, n={len(H)})",
            f"{mi:.3f} vs {mo:.3f} outside; shift p={p:.3f}", "p<0.01", "PASS" if p < 0.01 else "MISS")
    # H. inversions
    if not os.path.exists(os.path.join(a.out, "blocks.tsv")):
        INV.clear()
        blocks = None
    else:
        blocks = pd.read_csv(os.path.join(a.out, "blocks.tsv"), sep="\t")
    for nm, c, s, e, note in INV:
        res = []
        for (ga, gb), g in blocks.groupby(["genome_a", "genome_b"]):
            g = g[g.chrom_a.str.endswith(c) & g.chrom_b.str.endswith(c)]
            if not len(g):
                continue
            dom = 1 if g[g.sign == 1].n_anchor.sum() >= g[g.sign == -1].n_anchor.sum() else -1
            coord_a = ga.startswith("B73")
            inv = g[(g.sign != dom)]
            if coord_a:
                ov = inv[(inv.end_a >= s) & (inv.start_a <= e)]
                xy = [(r.start_a, r.end_a, r.n_anchor) for r in ov.itertuples()]
            elif gb.startswith("B73"):
                ov = inv[(inv.end_b >= s) & (inv.start_b <= e)]
                xy = [(r.start_b, r.end_b, r.n_anchor) for r in ov.itertuples()]
            else:   # TIL18-TIL01: use TIL18 coordinates around the B73 interval (+-20 Mb tolerance)
                ov = inv[(inv.end_a >= s - 2e7) & (inv.start_a <= e + 2e7)]
                xy = [(r.start_a, r.end_a, r.n_anchor) for r in ov.itertuples()]
            # each block listed on its own: neighbouring inversions must not be summed into one
            desc = ", ".join(f"{x0 / 1e6:.1f}-{x1 / 1e6:.1f} Mb ({n} anchors)" for x0, x1, n in sorted(xy))
            res.append(f"{ga}-{gb} ({(ga if not gb.startswith('B73') else gb)} coordinates): "
                       f"{len(ov)} inverted block(s){': ' + desc if desc else ''}")
        row("inversions", f"{nm} ({c}:{s / 1e6:.1f}-{e / 1e6:.1f} Mb)", "; ".join(res), "", "", note)
    out = pd.DataFrame(R)
    out.to_csv(os.path.join(a.out, "benchmark_real.tsv"), sep="\t", index=False)
    with pd.option_context("display.max_colwidth", 140, "display.width", 250):
        print(out.to_string(index=False))


if __name__ == "__main__":
    main()
