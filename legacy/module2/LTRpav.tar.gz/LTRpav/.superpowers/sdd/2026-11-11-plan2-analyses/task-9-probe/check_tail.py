from decimal import Decimal as Dm, getcontext
import numpy as np
from scipy.special import gammaincc
from ltrpav.analysis.identity import _lp, _Q_MIN
getcontext().prec = 60

def exact_lp(k, n, s, m):
    """s/m - log(mn) - (k+1) log(1 + 1/(nm)) + log Q(k+1, x), Q = e^-x sum_{j<=k} x^j/j!, at 60 digits."""
    s, m, n = Dm(repr(s)), Dm(repr(m)), Dm(n)
    c = 1 + 1 / (n * m)
    x = c * n * s
    term, tot = Dm(1), Dm(1)
    for j in range(1, k + 1):
        term = term * x / j
        tot += term
    return s / m - (m * n).ln() - (k + 1) * c.ln() - x + tot.ln()

for k, n, s, m in [(5, 1000, 0.7, 0.01), (0, 800, 1.0, 0.05), (40, 3000, 0.4, 0.002), (3, 800, 0.00125, 1e-7),
                   (120, 2500, 0.6, 0.01), (2, 500, 0.002, 1e-12), (8, 800, 0.0005, 0.004), (60, 2000, 0.002, 0.01)]:
    x = (1 + 1 / (n * m)) * n * s
    tail = gammaincc(k + 1, x) < _Q_MIN
    ex = float(exact_lp(k, n, s, m))
    got = float(_lp(np.array([float(k)]), np.array([float(n)]), s, m)[0])
    print(f"k={k:4d} n={n:5d} s={s:<8g} m={m:<8g} tail={str(tail):5s} exact={ex:.12g} got={got:.12g} "
          f"relerr={abs(got - ex) / abs(ex):.1e}")
