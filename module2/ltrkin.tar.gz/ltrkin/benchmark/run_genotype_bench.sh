#!/bin/bash
# Simulated-reads benchmark of `ltrkin genotype` with a Sniffles2 baseline (docs/benchmark_genotype_sim.md).
# Usage: run_genotype_bench.sh OUTDIR [stage ...]
#   stages (default: all, in this order): truth reads align subsample ltrkin sniffles eval
# Resumable: every step writes to a temporary name and renames on success; finished outputs are skipped.
# Run detached (2-3 h): setsid -f nohup run_genotype_bench.sh OUTDIR > OUTDIR/logs/run.log 2>&1 < /dev/null
set -euo pipefail
O=$(readlink -f "${1:?usage: run_genotype_bench.sh OUTDIR [stage ...]}"); shift
STAGES=${*:-truth reads align subsample ltrkin sniffles eval}

# run in the benchmark env (benchmark/environment.yml) with ltrkin installed or LTRKIN set
LTRKIN=${LTRKIN:-ltrkin}
export NUMPY_MADVISE_HUGEPAGE=0 OMP_NUM_THREADS=1
SRC=$(dirname "$(readlink -f "$0")")
# inputs (v0.1 benchmark: the P. supina reference assembly, its LTRquest annotation and region Ps4B:30000000-60000000)
REF=${REF:?set REF=reference FASTA}
GFF=${GFF:?set GFF=LTR-RT GFF3 of that reference}
REGION=${REGION:?set REGION=chrom:start-end, the region whose sites are planted}
SEED=1
JOBS=${JOBS:-8}        # parallel single-threaded jobs (badread); the server allows 8 threads in total
MM_T=${MM_T:-7}        # minimap2 threads (+1 for samtools sort)
CHUNKS=4               # badread chunks per haplotype and technology
CHUNK_X=5              # per-haplotype depth of one chunk: 4 x 5x = 20x per haplotype = 40x total
DEPTHS="40 20 10"      # total depth (both haplotypes); 20x and 10x are nested random subsets of 40x
TECHS=${TECHS:-hifi ont}   # technologies to process

mkdir -p "$O"/{logs,reads,bam,ltrkin,sniffles,eval}
log() { echo "[$(date '+%F %T')] $*"; }

# read simulators: HiFi = badread PacBio HiFi recipe (pbsim3 cannot reach HiFi accuracy: see the doc);
# ONT = badread R10.4.1 2023 model with the default length, junk, chimera and glitch settings
sim_cmd() {  # tech hap chunk -> command line
  local tech=$1 hap=$2 c=$3 seed   # one seed per technology, haplotype and chunk
  case $tech in
    hifi) seed=$(( SEED * 1000 + ${hap#hap} * 100 + c ));
          echo "badread simulate --reference $O/truth/$hap.fa --quantity ${CHUNK_X}x --error_model pacbio2021 \
--qscore_model pacbio2021 --identity 30,3 --length 17000,5000 --start_adapter_seq '' --end_adapter_seq '' \
--junk_reads 0 --random_reads 0 --chimeras 0 --glitches 0,0,0 --seed $seed" ;;
    ont)  seed=$(( SEED * 1000 + 500 + ${hap#hap} * 100 + c ));
          echo "badread simulate --reference $O/truth/$hap.fa --quantity ${CHUNK_X}x --error_model nanopore2023 \
--qscore_model nanopore2023 --identity 95,99,2.5 --length 15000,13000 --seed $seed" ;;
  esac
}

stage_truth() {
  [[ -s $O/truth/truth.tsv ]] && { log "truth: exists"; return; }
  python "$SRC/sim_genotype_truth.py" -f "$REF" -g "$GFF" -r "$REGION" -o "$O/truth" --seed $SEED --check \
    2> "$O/logs/truth.log"
}

stage_reads() {
  local jobs=$O/logs/reads.jobs
  : > "$jobs"
  for tech in $TECHS; do for hap in hap1 hap2; do for c in $(seq 1 $CHUNKS); do
    local out=$O/reads/$tech.$hap.c$c.fq.gz
    [[ -s $out ]] && continue
    # read names get the haplotype as prefix (minimap2 drops the badread comment that names the source)
    echo "$(sim_cmd $tech $hap $c) 2> $O/logs/reads.$tech.$hap.c$c.log | awk 'NR%4==1{sub(/^@/,\"@${hap}_\")}1' \
| gzip -1 > $out.tmp && mv $out.tmp $out" >> "$jobs"
  done; done; done
  log "reads: $(wc -l < "$jobs") badread jobs, $JOBS at a time"
  [[ -s $jobs ]] && xargs -P "$JOBS" -I{} -d '\n' bash -c '{}' < "$jobs"
  for f in "$O"/reads/*.fq.gz; do [[ -s $f ]] || { log "missing $f"; exit 1; }; done
  log "reads: done"
}

stage_align() {
  for tech in $TECHS; do
    local bam=$O/bam/${tech}_d40.full.bam preset=map-$tech n
    [[ -s $bam.bai ]] && { log "align $tech: exists"; continue; }
    n=$(ls "$O"/reads/$tech.hap[12].c*.fq.gz 2>/dev/null | wc -l)
    (( n == 2 * CHUNKS )) || { log "align $tech: $n of $((2 * CHUNKS)) read files present; run the reads stage"; exit 1; }
    mkdir -p "$O/ref"; [[ -s $O/ref/ref.$preset.mmi ]] || minimap2 -x $preset -d "$O/ref/ref.$preset.mmi" "$REF" 2> /dev/null
    log "align $tech"
    /usr/bin/time -v -o "$O/logs/align.$tech.time" bash -c "zcat $O/reads/$tech.hap*.c*.fq.gz \
| minimap2 -t $MM_T -ax $preset -R '@RG\tID:sim\tSM:${tech}_d40' $O/ref/ref.$preset.mmi - 2> $O/logs/align.$tech.log \
| samtools sort -@ 1 -m 3G -T $O/bam/tmp.$tech -o $bam.tmp.bam -"
    mv "$bam.tmp.bam" "$bam"
    samtools index "$bam"
  done
}

stage_subsample() {
  for tech in $TECHS; do
    local src=$O/bam/${tech}_d40.full.bam
    for d in $DEPTHS; do
      local s=${tech}_d$d full=$O/bam/${tech}_d$d.full.bam prim=$O/bam/${tech}_d$d.primary.bam
      if [[ $d != 40 && ! -s $full.bai ]]; then
        # samtools -s SEED.FRAC keeps whole templates by read-name hash: same seed -> 10x is a subset of 20x
        local frac; frac=$(python -c "print(f'{$d/40:.4f}'.split('.')[1])")
        samtools view -H "$src" | sed "s/SM:${tech}_d40/SM:$s/" > "$O/bam/$s.hdr.sam"
        samtools view -b -s "42.$frac" "$src" | samtools reheader "$O/bam/$s.hdr.sam" - > "$full.tmp"
        mv "$full.tmp" "$full"; samtools index "$full"; rm -f "$O/bam/$s.hdr.sam"
      fi
      if [[ ! -s $prim.bai ]]; then
        samtools view -b -F 0x904 -o "$prim.tmp" "$full"; mv "$prim.tmp" "$prim"; samtools index "$prim"
      fi
      log "subsample: $s ready"
    done
  done
}

stage_ltrkin() {
  local jobs=$O/logs/ltrkin.jobs
  : > "$jobs"
  for tech in $TECHS; do for d in $DEPTHS; do for mode in full primary; do
    local p=$O/ltrkin/${tech}_d$d.$mode
    [[ -s $p.genotypes.tsv ]] && continue
    echo "/usr/bin/time -v -o $p.time $LTRKIN genotype -r $REF -a $O/truth/region.gff3 -o $p -t 4 -v \
$O/bam/${tech}_d$d.$mode.bam > $p.log 2>&1" >> "$jobs"
  done; done; done
  log "ltrkin: $(wc -l < "$jobs") runs, 2 at a time (4 workers each)"
  [[ -s $jobs ]] && xargs -P 2 -I{} -d '\n' bash -c '{}' < "$jobs"
  log "ltrkin: done"
}

stage_sniffles() {
  local jobs=$O/logs/sniffles.jobs
  : > "$jobs"
  for tech in $TECHS; do for d in $DEPTHS; do for mode in full primary; do
    local p=$O/sniffles/${tech}_d$d.$mode
    [[ -s $p.vcf ]] && continue
    echo "/usr/bin/time -v -o $p.time sniffles --input $O/bam/${tech}_d$d.$mode.bam --genotype-vcf \
$O/truth/planted_sv.vcf --vcf $p.vcf.tmp.vcf --sample-id ${tech}_d$d -t 4 --allow-overwrite > $p.log 2>&1 \
&& mv $p.vcf.tmp.vcf $p.vcf" >> "$jobs"
  done; done; done
  log "sniffles: $(wc -l < "$jobs") runs, 2 at a time (4 threads each)"
  [[ -s $jobs ]] && xargs -P 2 -I{} -d '\n' bash -c '{}' < "$jobs"
  log "sniffles: done"
}

stage_eval() {
  python "$SRC/eval_genotype_sim.py" -d "$O" -o "$O/eval" 2> "$O/logs/eval.log"
  log "eval: $O/eval"
}

for st in $STAGES; do
  log "stage $st"
  "stage_$st"
done
log "all requested stages done"
