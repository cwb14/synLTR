#!/usr/bin/env python3
"""Compare two scorings of the simulated-reads benchmark (eval_genotype_sim.py outputs), e.g. before and after a code
change: summary metrics per run, per-site flips (fixed / newly wrong), named sites across runs, and context elements.
Usage: compare_genotype_runs.py --before DIR/eval_before_fix --after DIR/eval [--tool ltrkin] [--mode full]
       [--sites ID,ID] -o out_prefix
Writes <out>.summary.tsv, <out>.flips.tsv, <out>.sites.tsv and prints markdown tables.
"""
import argparse
import os

import pandas as pd

KEYS = ["tool", "tech", "depth", "mode"]


def load(d, tool, mode):
    c = pd.read_csv(os.path.join(d, "calls.tsv"), sep="\t", dtype={"call": str})
    c = c[(c.tool == tool) & (c["mode"] == mode)]
    s = pd.read_csv(os.path.join(d, "summary.tsv"), sep="\t")
    s = s[(s.tool == tool) & (s["mode"] == mode)]
    b = pd.read_csv(os.path.join(d, "by_class.tsv"), sep="\t")
    b = b[(b.tool == tool) & (b["mode"] == mode)]
    x = pd.read_csv(os.path.join(d, "context.tsv"), sep="\t")
    x = x[(x.tool == tool) & (x["mode"] == mode)]
    return c, s, b, x


def metrics(s, b):
    rec = b.pivot_table(index=["tech", "depth"], columns="truth_class", values="recall_all")
    out = s.set_index(["tech", "depth"])[["conc_all", "conc_gq20", "call_rate_gq20"]].join(
        rec[["F/S", "F/N (hemi)", "F/F", "F/E"]])
    return out


def pct(v):
    return f"{100 * v:.1f}"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--before", required=True, help="eval directory of the earlier scoring")
    ap.add_argument("--after", required=True, help="eval directory of the later scoring")
    ap.add_argument("--tool", default="ltrkin")
    ap.add_argument("--mode", default="full", help="BAM mode [full]")
    ap.add_argument("--sites", default="", help="comma-separated element IDs (or ID suffixes) to report across runs")
    ap.add_argument("-o", "--out", required=True, help="output prefix")
    a = ap.parse_args()
    cb, sb, bb, xb = load(a.before, a.tool, a.mode)
    ca, sa, ba, xa = load(a.after, a.tool, a.mode)
    mb, ma = metrics(sb, bb), metrics(sa, ba)
    rows = []
    print("| Run | Concordance, all calls | Concordance, GQ>=20 | Call rate, GQ>=20 | Recall F/S | Recall F/N hemi | "
          "Recall F/F | Recall F/E |")
    print("|---|---|---|---|---|---|---|---|")
    for (tech, depth) in sorted(mb.index, key=lambda k: (k[0], k[1])):
        r0, r1 = mb.loc[(tech, depth)], ma.loc[(tech, depth)]
        cells = [f"{pct(r0[c])} -> {pct(r1[c])}" for c in ["conc_all", "conc_gq20", "call_rate_gq20", "F/S",
                                                            "F/N (hemi)", "F/F", "F/E"]]
        name = f"{'HiFi' if tech == 'hifi' else 'ONT'} {depth}x"
        print(f"| {name} | " + " | ".join(cells) + " |")
        rows.append(dict(tech=tech, depth=depth, **{f"{c}_before": r0[c] for c in r0.index},
                         **{f"{c}_after": r1[c] for c in r1.index}))
    pd.DataFrame(rows).to_csv(a.out + ".summary.tsv", sep="\t", index=False)
    m = cb.merge(ca, on=["element_id", "tech", "depth"], suffixes=("_before", "_after"))
    fl = m[m.correct_before != m.correct_after]
    fl = fl[["tech", "depth", "element_id", "truth_class_before", "call_before", "gq_before", "call_after", "gq_after",
             "correct_after"]].rename(columns={"truth_class_before": "truth_class"})
    fl.to_csv(a.out + ".flips.tsv", sep="\t", index=False)
    print(f"\nflips (correct status changed): {len(fl)}; fixed {int(fl.correct_after.sum())}, "
          f"newly wrong {int((~fl.correct_after).sum())}")
    print(fl.sort_values(["correct_after", "element_id", "tech", "depth"]).to_string(index=False))
    if a.sites:
        want = [s.strip() for s in a.sites.split(",") if s.strip()]
        sel = m[m.element_id.apply(lambda e: any(e.endswith(w) for w in want))].copy()
        sel["before"] = sel.call_before + " (GQ " + sel.gq_before.astype(int).astype(str) + ")"
        sel["after"] = sel.call_after + " (GQ " + sel.gq_after.astype(int).astype(str) + ")"
        sel["run"] = sel.tech.str.replace("hifi", "HiFi").str.replace("ont", "ONT") + " " + sel.depth.astype(str) + "x"
        out = sel[["element_id", "truth_class_before", "run", "before", "after"]].rename(
            columns={"truth_class_before": "truth"}).sort_values(["element_id", "run"])
        out.to_csv(a.out + ".sites.tsv", sep="\t", index=False)
        print("\n" + out.to_string(index=False))
    xm = xb.merge(xa, on=KEYS + ["ctx"], suffixes=("_before", "_after"))
    print("\ncontext (truth F/F): concordance before -> after")
    for r in xm.itertuples():
        print(f"  {r.tech} {r.depth}x {r.ctx}: {pct(r.conc_all_before)} -> {pct(r.conc_all_after)}; "
              f"GQ>=20 correct {pct(r.conc_gq20_before)} -> {pct(r.conc_gq20_after)}")


if __name__ == "__main__":
    main()
