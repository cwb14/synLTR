# Task 16B report (Steps 3b-4: plan3/RESULTS.md, records, commit, suite)

Status: DONE_WITH_CONCERNS (all parts done; the detached full suite was launched and not waited for).

## 1. compare_papers.py: the residual M3 note fix (ledger "Ruling (residual M3)")

- Old sha256 47d2c20dc926a253094e815c8a0ef52dcc4f0060f4a7a58dc353fbd878a02145 (16A; kept as
  `real/common/compare_papers.py.task16a`, beside Task 13's `compare_papers.py.task13`).
- New sha256 1baa28dcd2b3b8fab20a64df4cd5afa45798e64bed4edd406346215b167204f2.
- Diff of the script (against 16A's): the docstring's History gains a Task 16B line; `add_gradient_own`'s `why` note
  gives the K = 0 insertions as shares of the informative loci, in the nulls and in the view alike.
- Test first: `test_dd_rows_state_that_no_simulated_null_exists` now expects the shares; red against 47d2c20d
  (1 failed, 18 passed; appended to `test_compare_papers.red.out` as red phase 4), green against 1baa28dc (19 passed;
  `test_compare_papers.out`). test_compare_papers.py sha256 022a06dc...467b3e. ruff F/E9/B: the same 8 findings as
  16A's file (PRELIM's own), test file clean.

The script diff (against 16A's, `diff compare_papers.py.task16a compare_papers.py`):
```
33a34,36
> Task 16B: the note of the row on dD's simulated null gives the K = 0 insertions as shares of the informative loci, in
> the nulls and in the view alike (it had set a mean count per null beside the view's count; 16A's version is kept as
> compare_papers.py.task16a).
1126,1130c1129,1136
<     why = (f"why (SIM_RESULTS section 1): the K = 0 stratum holds {k0.min()}-{k0.max()} informative loci per 50-Mb "
<            f"default null (mean {k0.mean():.1f} of {nn.mean():.0f}), because an insertion shared through lineage "
<            f"sorting alone is older than the split of the donor from the sisters, so its two LTRs are rarely "
<            f"identical (expected divergence at least 0.0036 there); this view's K = 0 stratum holds {yrd + ysd} "
<            f"(n_RD {yrd}, n_SD {ysd})")
---
>     _, _, _, ard, asd = dpav_row(st, scope, "all")
>     sh_null = 100 * k0.sum() / nn.sum() if nn.sum() else math.nan        # = mean K = 0 count / mean informative
>     sh_view = 100 * (yrd + ysd) / (ard + asd) if ard + asd else math.nan
>     why = (f"why (SIM_RESULTS section 1): insertions at K = 0 make up {fd(sh_null, '.1f')}% of the informative loci in "
>            f"a 50-Mb default null (mean {k0.mean():.1f} of {nn.mean():.0f}; {k0.min()}-{k0.max()} per null), because "
>            f"an insertion shared through lineage sorting alone is older than the split of the donor from the "
>            f"sisters, so its two LTRs are rarely identical (expected divergence at least 0.0036 there); they make up "
>            f"{fd(sh_view, '.1f')}% in this view ({yrd + ysd:,} of {ard + asd:,}; n_RD {yrd}, n_SD {ysd})")
```
The null share is the pooled one, 35 of 9,042 informative loci over the 30 default nulls = 0.387% (equal to mean 1.17
of mean 301.4; the mean of the per-null shares is 0.389%), printed 0.4%; the view's is 40 of 2,036 = 1.96%, printed
2.0%. Both as FINAL.md:117-121 gives them.

Reruns (all on snapshot 2, from real/, one thread each, 5 at once, `scratchpad/p3t16b/run_compare.sh LOG ARGS`, whose
log header records the script's sha256 1baa28dc...; every run exit 0, 1:18-1:39, peak RSS 0.6-1.2 GB):
```
run_compare.sh papers/logs/compare_papers.16b --run papers/views/main --prefix final
run_compare.sh papers/logs/control_main3.16b --run ../../main3_analyses --prefix main3 --out papers/control_main3
run_compare.sh stability/logs/mm2.compare_final --run stability/mm2/views/main --prefix final_mm2
run_compare.sh stability/logs/cap5k.compare_final --run stability/cap5k/views/main --prefix final_cap5k
run_compare.sh stability/logs/default4.compare_final --run stability/default4/views/main --prefix final_default4
# then, in papers/: python diff_prelim.py ../../../main3_analyses/prelim_papers.tsv control_main3/main3_papers.tsv \
#   views/main/final_papers.tsv final_vs_prelim.tsv
```

**Diff 1, papers/views/main/final_papers.tsv** (before: scratchpad/p3t16b/before/views_main, sha256 19016fae...;
after 0dfd2d1b...): 152 rows both; exactly one row differs, row 16 "simulated null of dD: rule 2 (a reading)", and
in it only the `note` column (checked column by column). `final_tables/` and `final_ltrmix_crosscheck.tsv` are
byte-identical. Verdicts 19 PASS, 5 MISS, 128 reported, as before.
```
16c16
< ... why (SIM_RESULTS section 1): the K = 0 stratum holds 0-6 informative loci per 50-Mb default null (mean 1.2 of
    301), because an insertion shared through lineage sorting alone is older than the split of the donor from the
    sisters, so its two LTRs are rarely identical (expected divergence at least 0.0036 there); this view's K = 0
    stratum holds 40 (n_RD 32, n_SD 8); no null is invented, so dD's Z stays descriptive
---
> ... why (SIM_RESULTS section 1): insertions at K = 0 make up 0.4% of the informative loci in a 50-Mb default null
    (mean 1.2 of 301; 0-6 per null), because an insertion shared through lineage sorting alone is older than the
    split of the donor from the sisters, so its two LTRs are rarely identical (expected divergence at least 0.0036
    there); they make up 2.0% in this view (40 of 2,036; n_RD 32, n_SD 8); no null is invented, so dD's Z stays
    descriptive
```
(The unchanged first five columns of the row are elided as "...".)

**Diff 2, papers/control_main3/main3_papers.tsv** (rerun so that FINAL.md's "main3 scored by the final script" stays
true; after 530df22f...): 113 rows; the same row 16, note only ("they make up 2.0% in this view (40 of 2,041; n_RD
32, n_SD 8)"); `main3_tables/` and `main3_ltrmix_crosscheck.tsv` byte-identical.

**Diff 3, papers/final_vs_prelim.tsv** (regenerated with 16A's command): one line differs, line 114, the same row's
final note; the tallies are 16A's (changed 78, same 25, removed 6, added 4 by the script and 45 by the view; causes
E1 24, E2 1, E3 4, E4 2, E5-E8 1 each, W1 56, W2 1, W3 42, W4 21, W5 5).

**Recorded:** FINAL.md (provenance line :14-20 and Files :347-349, :354-356; later also section 4's first sentence,
which now points to the new dead_ends entry; sha256 now 4fa8d0339998a814d37dfc541997dff7e014dcec82430d5ace59a6fcac27a984,
358 lines; the 20 table lines unchanged) and real/memo.md (new section "Task 16": compare_papers.py 1baa28dc..., 16A's 47d2c20d
kept as `.task16a`, test file 022a06dc..., final_papers.tsv 0dfd2d1b..., final_vs_task15.tsv f358b413...).
final_vs_prelim.tsv after regeneration: sha256 eed94661...13af.

## 2. Stability reruns (ledger "Ruling (Task 16A beside Task 15)")

The installed script (1baa28dc) on Task 15's three 4-genome views (B73, TIL18, TIL01, Zd; stats and paint run with
`--trio B73,TIL01,TIL18`), new prefixes `final_mm2`, `final_cap5k`, `final_default4`, outputs beside Task 15's in each
`stability/<view>/views/main/`. Compared with Task 15's tables (script `compare_papers.py.task13`, 1e04f43e) by
`stability/diff_task15.py` (sha256 3192dd12...; rows matched on section and item with diff_prelim.py's key, then the
item name compared like the other columns) -> `stability/final_vs_task15.tsv` (324 rows; sha256
f358b41380c18b0505723b58bc2c903461cfcf9d5ec430fe57b85366ae991117; log `stability/logs/diff_task15.log`).

Correction (after the coordinator's 19:17 message): the sha256 0fb466e2... that an earlier version of this section
cited was not my script's output. A second copy of this agent, run by the original controller session until 19:15,
wrote its own `diff_final.py` table to the same path at 19:12:56, just before I hashed it; it later reran my
`diff_task15.py` (19:15:13, Python 3.10, c2103bd3...) and kept its files in `scratchpad/p3t16b/mine/`. My first
version also compared value columns only and so missed the renamed pooled mechanisms row. The script now compares item
names, writes no bytecode (both runs had left a `papers/__pycache__/`, removed; it did not exist before), passes ruff
F/E9/B, and the numbers below are from its single final run, with env ltrpav's Python.

| view | Task 15 rows | final rows | same | changed | added | verdict changes beyond dropping "(prelim)" |
|---|---|---|---|---|---|---|
| mm2 | 102 | 106 | 73 | 29 | 4 | none |
| cap5k | 105 | 109 | 76 | 29 | 4 | none |
| default4 | 105 | 109 | 76 | 29 | 4 | none |

The 29 changed rows are 28 with a value change and 1 renamed ("multi-element absences, the six ingroup pairs pooled" ->
"..., the 6 directed ingroup pairs pooled"; its values are unchanged). The changed and added rows are the same 33 in
each view, all the script's edits:
- 24 verdicts lose "(prelim)" (E1): chromosomes 4 rows, windows 16, ZmPRR37a 1, high-frequency regions 2, D_pav 1.
  Verdicts stay 19 PASS / 5 MISS; 2 "skipped" rows identical.
- D_pav primary row (E2), `ltrpav` and `note`: now gives the simulated nulls reaching |Z| (0 of 30 default, max 1.97;
  0 of 30 bottleneck, max 3.14; empirical p 0.032) and rests the verdict on the bottleneck nulls. Z: mm2 6.89, cap5k
  7.49, default4 7.42. PASS in all three.
- 4 added rows (E3): rule 1, rule 2's reading, the empirical null distribution of Z, the simulated null of dD (its
  note with the M3 shares: mm2 1.9% (34 of 1,773), cap5k 1.8% (37 of 2,042), default4 2.0% (40 of 2,041)).
- the two dD rows' notes (E4): the "no simulated null of dD" caveat.
- "1 roles" note (E7): Task 15's tables said "roles are inferred, never set", which was false (all three views ran
  `--trio`); now "roles fixed by --trio; the trio's own sharing rows and the sign of D_pav agree with them". Same
  sharing counts.
- "4 amount" note (E5): "no second donor in main3" becomes the view's own f4 status (skipped: no second donor).
- the pooled mechanisms row (E6): renamed with its pair count ("the 6 directed ingroup pairs pooled"), values equal.
- Not changed in these views: the direction row (E8; skipped, 4 genomes).
`<prefix>_tables/` and the LTRmix cross-checks are byte-identical to Task 15's (Task 15's unprefixed
`ltrmix_crosscheck.tsv` stays beside the new prefixed one).

**16A's note: two section-3 notes are fixed PRELIM text.** Checked on every view (final_<view>_papers.tsv):

| view | D_pav (verified) | library-style D | dD verified / library | added D/O patterns: D (SE) | added - verified | resolution B73 / TIL01 by age: K=0; 0<K<0.01; K>=0.01; all |
|---|---|---|---|---|---|---|
| papers (final) | +0.2898 | +0.2866 | +0.398 / +0.437 | +0.2791 (0.054) | -0.011 (0.2 SE) | 0.748/0.729; 0.691/0.680; 0.745/0.723; 0.728/0.710 |
| mm2 | +0.2860 | +0.2749 | +0.397 / +0.462 | +0.2512 (0.055) | -0.035 (0.6 SE) | 0.739/0.714; 0.681/0.662; 0.720/0.696; 0.709/0.686 |
| cap5k | +0.2948 | +0.2867 | +0.412 / +0.427 | +0.2674 (0.055) | -0.027 (0.5 SE) | 0.753/0.739; 0.703/0.689; 0.746/0.728; 0.733/0.716 |
| default4 | +0.2905 | +0.2872 | +0.397 / +0.436 | +0.2793 (0.053) | -0.011 (0.2 SE) | 0.748/0.730; 0.691/0.681; 0.746/0.724; 0.728/0.710 |

- "they carry the same asymmetry as the empty-site patterns ... verification changes neither D nor its age
  gradient": holds in all three. The added patterns' D lies within 0.6 of its own SE of the verified D (SE = D/Z);
  the library-style D is within 0.011 of D_pav and its dD within 0.015-0.065 (at most 0.5 SE of dD). One reading to
  know: under mm2 the verified dD's Z is 2.83 and the library-style dD's 3.70, so the row's estimates agree but only
  the library reading crosses Z 3 there.
- "the two sisters are resolved alike in every age bin": holds; B73 is resolved 0.010-0.025 more often than TIL01 in
  every bin of every view (largest under mm2, 0.019-0.025), and the K = 0 gap is never more than 0.001 above the
  old-bin gap (mm2 0.025 against 0.024; smaller elsewhere).
  Neither note needs to be computed for these views.

## 3. plan3/RESULTS.md

`benchmark_pav/plan3/RESULTS.md`, 99 lines at delivery (sha256 d9206daf...c5); after fix round 1, 115 lines, sha256
47f76d902e4b5e5eee3b5d78a98225a2024f8af4fd6c4244aee8608db0a78224 (the version quoted below).
33 bar lines, one per bar (simulations 9 PASS / 7 MISS, one per RULES.md bar as SIM_RESULTS counts them; real genomes
12 PASS / 5 MISS: the five DESIGN 10.3 claims as six lines because the chromosome claim has two readings, then six
genomes 2, genus 2, sweet orange 7); links to sim/SIM_RESULTS.md, real/{papers/FINAL.md, six, genus, citrus, edta,
stability}/RESULTS.md and dead_ends.md (all resolve); 10 Plan 4 leads covering the brief's list (decoy cross-fitting
answered: not needed, the decoy model held the null), R3's list, the ledger's parked items and each RESULTS.md's
leads. Every number was re-read from its source (SIM_RESULTS, FINAL.md, the real RESULTS.md files, the tracts files).
Fact found while checking the outcome's wording: two real paintings did certify tracts at q <= 0.05, both in all-trio
views without a truth and not discussed in their RESULTS.md: six/views/all PT (sister TIL01, donor TIL18) 27 tracts,
85.1 Mb, smallest q 0.037; genus/views/all Zh (sister TIL25, donor Zn) 20 tracts at q 0.05, 197.1 Mb. So the outcome
says "in maize or sweet orange" (the paintings with a known answer), and lead 1 names the two as unscored.

Quoted in full:

````markdown
# Plan 3: how well LTRpav works

2026-11-14. LTRpav calls LTR retrotransposon insertions present or absent in each genome assembly and tests for gene
flow with the insertions a donor shares with one of two sisters. Plan 3 scored it on simulated and on real genomes
against bars fixed beforehand; no default changed. Every MISS is investigated in [../dead_ends.md](../dead_ends.md).
LTRpav snapshots: 4f3973e (simulations), 12d3e6c (real genotypes), 6282541 (real analyses).

**Outcome.**
1. The genome-wide test found the known gene flow in all three real admixture events (maize, the *Zea* genus, sweet
   orange; Z 6.4-16.9, against at most 3.14 in 60 simulated sets without gene flow, a guide rather than a like-for-like
   null) and, in 20 simulated sets without gene flow where one sister was less completely annotated, gave no false
   signal (0 against LTRmix D_ins's 18 of 20; McNemar p 8e-6).
2. Its map of introgressed stretches is coarse: it found 4 of sweet orange's 5 long tracts (1.7-23.8 Mb) but not
   maize's ~10-kb tracts, against informative insertions a median 85 kb apart (element AUROC 0.71; tract recall 1.0-1.7
   times chance), and it certified no tract at a 5% false discovery rate in the paintings with a known answer (B73 in
   the papers' view, sweet orange); two paintings with no known answer did (lead 1).
3. D_pav does not tell the six-genome controls apart: it gives them the same excess (+0.139 and +0.145, Z 3.16 and
   3.20) where SNP D (+0.112, +0.052) and LTRmix's D_ins (Z 4.57, 1.19) separate them; the negative control misses at
   the 5-Mb rule, and the two swap verdicts with 10-20-Mb blocks; the direction test is not validated (its positive
   control read its prediction in 2 of 8 runs, both nulls).

**Terms.** D_pav = (n_RD − n_SD) / (n_RD + n_SD) over the donor's insertions that one sister carries and the other
verifiably lacks (the *informative* insertions; n_RD in the recipient, n_SD in its sister); lineage sorting alone gives
0 on average. Z = D / SE (block jackknife: 5-Mb blocks in real genomes, ~1 Mb in the simulations); the bar is Z > 3. A
*null* is a simulated genome set without gene flow. The *painting* marks donor-like *tracts* along the recipient; *q*
estimates a tract's false discovery rate; *AUROC* is the chance that an insertion inside a true tract scores above one
outside (0.5 is chance).

## Simulations: 9 PASS, 7 MISS ([sim/SIM_RESULTS.md](sim/SIM_RESULTS.md); 144 runs on 50 Mb of B73 sequence)

| Bar (sim/RULES.md) | Verdict | Number |
|---|---|---|
| 1. D_pav: \|Z\| > 3 in at most 1 of 30 nulls | PASS | 0 of 30 (95% CI 0-0.12) |
| 3. High-tier genotype precision ≥ 0.95, present (P) and empty (E) | PASS | P 0.997, E 0.997 |
| 4. Default painting holds the null (≤ 1 of 30 nulls with a q ≤ 0.05 tract; excess over the decoy ≈ 0) | PASS | 0 of 30 nulls |
| 4. `any` (painting from all genomes' calls) holds the null | PASS | 0 of 30; 0 of 20 dropout nulls |
| 4. `decoy` (decoy-anchored model) holds the null | PASS | 0 of 30 |
| 4. `anydecoy` holds the null | PASS | 0 of 30; 0 of 20 dropout nulls |
| 5. `any`: false discovery ≤ 5% at q ≤ 0.05 | MISS | no q ≤ 0.05 tract in 36 gene-flow runs |
| 5. `any`: recall above the default's | MISS | 0 of 42 run pairs usable |
| 5. `any`: precision not below the default's | PASS | vacuous: 0 usable pairs |
| 5. `decoy`: false discovery ≤ 5% | MISS | no q ≤ 0.05 tract |
| 5. `decoy`: recall above the default's | MISS | 0 of 36 pairs usable |
| 5. `decoy`: precision not below | PASS | vacuous: 0 usable pairs |
| 5. `anydecoy`: false discovery ≤ 5% | MISS | 0 of 21 tracts false; 95% upper bound 0.16 > 0.10 |
| 5. `anydecoy`: recall above the default's | MISS | 1 of 42 pairs usable (p 0.5) |
| 5. `anydecoy`: precision not below | PASS | 1 usable pair |
| 7. Direction test confirmed by its positive control | MISS | 2 of 8 runs read their prediction (both nulls) |

No bar: D_pav's null Z is not calibrated (SD 0.72, 95% 0.57-0.96), so real Z is read against 30 bottleneck nulls
(largest \|Z\| 3.14); dD, the excess in young insertions, has no null (testable in 1 of 30). Power at 50 Mb: Z > 3 in
10 of 36 gene-flow runs; scaled to the real count of informative insertions (6 times), simulated power is still
optimistic, because real genomes resolve fewer calls (0.46 against 0.76).

## Real genomes: 12 PASS, 5 MISS

The five DESIGN 10.3 claims take six lines here, because the chromosome claim has two readings (FINAL.md counts rows:
19 PASS, 5 MISS).

| Benchmark | Bar | Verdict | Number |
|---|---|---|---|
| [Maize vs papers](real/papers/FINAL.md) | Mexicana (TIL18) gene flow into B73, against TIL01 (Z > 3) | PASS | +0.290, Z 7.39; 0 of 60 nulls reach it |
| | Painting tracks Yang's SNP ancestry (ELAI), ≥ 1-Mb windows | PASS | r 0.26-0.38, p 0.001 (16 rows) |
| | Chromosomes 5, 8, 9 least mexicana, by painting | PASS | exact, p 1/120 (2 rows) |
| | The same, by share of donor-like insertions | MISS | chr4, 5, 9 (2 rows) |
| | ZmPRR37a mexicana | MISS | no informative insertion within 50 kb |
| | 52 high-frequency regions enriched | MISS | p 0.37-0.39 (2 rows) |
| [Six *Zea* genomes](real/six/RESULTS.md) | Positive control: highland maize PT > B73 (Z > 3) | PASS | +0.139, Z 3.16 (2.92 at 10-Mb blocks) |
| | Negative control: parviglumis TIL11 = TIL01 (\|Z\| < 3) | MISS | +0.145, Z 3.20 (2.80 at 10-Mb blocks) |
| [*Zea* genus](real/genus/RESULTS.md) | *Z. nicaraguensis* into ssp. *huehuetenangensis* (Z > 3) | PASS | +0.480, Z 6.36 |
| | Control: two mexicana equal (\|Z\| < 3) | PASS | −0.070, Z −0.68 (LTRmix's D_ins: Z 3.26) |
| [Sweet orange](real/citrus/RESULTS.md) | Mandarin tract CsB chr1, 23.8 Mb (≥ 50% covered) | PASS | 99% |
| | CsB chr2, 3.6 Mb | PASS | 51% |
| | CsB chr3, 7.2 Mb | PASS | 75% |
| | CsB chr9, 1.7 Mb | PASS | 82% |
| | Pummelo tract CsA chr2, 7.5 Mb | MISS | 34% (95% painted from all genomes' calls) |
| | Control: sour orange, mandarin half (\|Z\| < 3) | PASS | +0.45, Z 2.61 (29 informative) |
| | Control: sour orange, pummelo half (\|Z\| < 3) | PASS | −0.12, Z −0.54 (34 informative) |

No bar: with EDTA's annotation ([real/edta](real/edta/RESULTS.md)) D_pav is +0.305, Z 5.94. Under every alignment
route, flank cap and jackknife block of 1-20 Mb ([real/stability](real/stability/RESULTS.md)) Z stays 6.0-8.4, and no
maize bar row changes with route or cap.

## Plan 4 leads

1. **Certifying tracts:** q reaches 5% only when ≥ 20 tracts outscore every decoy tract: the default did in 1 of 36
   simulated gene-flow runs and in no real painting with a known answer; two unscored real paintings did (PT, 27 tracts;
   *huehuetenangensis*, 20). At any q, the `decoy` and `anydecoy` models beat the default's AUROC and base-pair
   precision in 29-31 of 33-34 simulated runs: candidates for the default once a q works at this marker density.
2. **Resolution:** the default fits 44-kb tracts against 80-kb marker spacing (simulated recall 5-9% for tracts ≥ 1 Mb,
   LTRmix 40%); `any` covers the real CsA chr2 tract (95%) but certified no simulated tract. Decoy cross-fitting: not
   needed (the decoy model held the null).
3. **Direction:** DFOIL-alt names no direction when a class is empty; a positive control with four non-empty classes;
   the missing `00++`/`00--` codes; can any presence/absence statistic orient a population-level pulse?
4. **Verdicts near Z = 3:** a rule for them, and a null with long-range dependence (real SE grows 1.18 times from 1- to
   5-Mb blocks, simulated SE does not); Task 13's age contrast (Z 3.18) at other block lengths.
5. **Unexplained asymmetries:** D_pav gives both six-genome controls +0.14 where SNP D (+0.112, +0.052) and LTRmix's
   D_ins separate them; TIL25 shares more TIL01 insertions than TIL18 does (Z 3.23); sour orange's mandarin half
   leans pummelo (Z 2.61).
6. **Untested in simulation:** null spread by demography (variance 2.7 times larger with a bottleneck); a null for dD;
   why the identity split s runs low (59% of truth); whether LTRmix's D_ins (41% below truth) is diluted by its
   absent calls.
7. **Annotation and realism:** D_pav higher with LTRquest's annotation in 3 of 3 simulated runs (+0.07 to +0.13); real
   genomes have younger outgroup-shared elements and less nesting.
8. **Decision 11 (the user's):** with an unannotated donor, the fallback that finds insertions in other annotated
   genomes held the null (0 of 30) but drew on the sisters' own clade in 9 of 66 simulated runs; with *Z.
   diploperennis* as the unannotated donor, the genus test (Zh against TIL18) reads Z −0.57 on 23 informative
   insertions, and for TIL01 against TIL25 the rule admitted TIL18 on a 0.009 margin; the note on the direction test's
   pattern counts (FOUR_LIST_NOTE) cites a Plan 3 check that was not run.
9. **Overview with 20 trios:** a page of about 264 mm; large scaffolds can be called chromosomes.
10. **Housekeeping:** harden the genotyping queue's script (genotype_all.sh: argument checks, locks, stop handling);
    the stale-results warning's advice omits `--identity` (the option that keeps the sequence-identity layer); three
    engine tests fail instead of skipping without lastz, and two simulator tests depend on msprime's random streams, so
    other msprime builds may pick another test seed (CI notes); scrub CLAUDE.md mentions from the git history before
    any push.
````

## 4. memo_ltrpav.md, "Plan 3" section (outline)

`$P/memo_ltrpav.md`, appended after the Plan 1-2 sections (untouched; checked by diff), 59 lines, file sha256
944e7ae5c5aa37569574ca139549013bdb82373db9e8f26daed0490b2545eea7. Keys, in the Plan 1-2 style:
- `date:` 2026-11-12 to 11-14, with the code, grid and real-genotyping spans;
- `purpose:`, `session:` (`claude --resume 6b33811c-ca10-4dfe-94dc-c7d4becddd02`), `repo:` (branch, commits, the
  records commit), `dir:` with pointers to sim/memo.md and real/memo.md for every command and per-step time;
- `snapshots:` 12d3e6c (real genotyping), 4f3973e (grid and scoring), 6282541 (real analyses); engine fingerprints
  equal;
- `env:` ltrpav with msprime 1.4.2, tskit 1.0.4, numpy, scipy, pysam, mappy/minimap2 2.31, lastz 1.04.60, bcftools 1.24
  (the pin and why), pytest, ruff; ltrquest_5042a1e (LTRquest 5042a1e); ltrmix; thread settings;
- `calibration:` calibrate.sh's exact values beside the src defaults (loss_split, replace_mean, t_o) and the budget
  gate (111.6 h at 100 Mb -> 50 Mb; 70.1 h -> 30 bottleneck nulls);
- `inputs:` FASTAs (fai checked), LTRquest 5042a1e and EDTA annotations, main3, truths, SNP D, LTRmix;
- a command block: calibrate, make_grid, the two grid runners, the LTRquest runs, rescore_all.sh, the queue and its
  w1-w5 workers, a real view step, the final view and the final compare_papers;
- `wall time against the plan's estimates:` grid 33.4 h (gate 70.1 h; per run 0.591 h and 0.236 h against pilot and
  plan), LTRquest 33-39 min per run (plan 1.4 h), real genotyping per block against the plan's ~22 h (six 11.4 h over
  four sessions against ~9 h; genus 4:36 against ~3 h; citrus 0:42; EDTA 2:02; stability 3:44 + 3:18 against ~7 h),
  analyses (identity 19:56 against ~20 min);
- `outputs:` RESULTS.md, SIM_RESULTS, the real RESULTS.md files and FINAL.md, the dead_ends sections, DESIGN 12; the
  headline numbers;
- `checks:` 147 runs rescored, 0 differ; fai and genotype trees unchanged; the 6282541 suite;
- `gotchas:` the 2026-11-14 parallel workers (five queue workers, two grid runners, lock collisions); the thread
  ceiling that counts every project (up to ~160 here beside poa_synthesis's ~64-96, at most 200 on the weekend,
  queue.pause 12:17-13:40, 100 on workdays); no edits to running scripts; env.sh and SNAP_SHA; view.sh's relative
  links; stats without --identity; the LTRquest PATH defect; simulations easier than real genomes; compare_papers'
  kept versions; Zn chromosome-only; find aliased to bfs.

## 5. DESIGN 12, "Plan 3 outcome"

Inserted after "Build decisions (plan 3)" and its Environment paragraph, before section 13 (6 lines of text):

```
### Plan 3 outcome (2026-11-14; `benchmark_pav/plan3/RESULTS.md`)

Calibration (`calibrate.sh`), with the `src` drafting defaults in brackets: loss_split 0.12293054234062797,
0.1638439581351094, 0.510941960038059, 0.20228353948620362 [0.123, 0.164, 0.511, 0.202]; replace_mean
13,538.154280338664 bp [13,538]; t_o 900,000 [900,000]. Simulations: PASS 9, MISS 7; D_pav holds the null (0 of 30)
but its null Z is not calibrated (real Z is read against the bottleneck nulls), dD has no null, no painting variant is
adopted and direction is not validated. Real genomes: PASS 12, MISS 5; the final 10.3 rerun keeps PRELIM's verdicts
(D_pav +0.290, Z 7.39), and the six-genome controls swap with the block length. No default changed; decision 11 open.
```
calibrate.sh's exact values are those in sim/calibration.tsv and demography.json; the bracketed values are
src/ltrpav/sim/popmodel.py's `Rates.loss_split`, `Rates.replace_mean` and `Demog.t_o`.

## 6. Commit

`a44f532` "Record Plan 3 benchmark outcome" on plan3-benchmark (parent 6282541), author and committer cwb14, the
global git identity; no trailer, no attribution; 1 file, docs/DESIGN.md, 9 insertions. No src change, so no new
snapshot. Not pushed (no remote).
Focused checks before it: `ruff check .` in the repo, all passed; no test reads DESIGN.md, so no repo test is touched.
Outside the repo: test_compare_papers.py 19 passed against 1baa28dc (red first: red phase 4); compare_papers.py ruff
F/E9/B gives 16A's 8 PRELIM findings, none new; the test file and diff_task15.py are clean.

## 7. Suite launch

Launched 2026-11-14 19:30:54, as briefed (env ltrpav's bin first on PATH; NUMPY_MADVISE_HUGEPAGE=0):
```
setsid -f nohup bash -c 'cd /data2/chris/maize_introgression/LTRpav && export NUMPY_MADVISE_HUGEPAGE=0 PATH=/home/chris/bin/mambaforge/envs/ltrpav/bin:$PATH && python -m pytest -W error -m "not slow" -q -rfEs > SUITE_DIR/suite.log 2>&1; echo $? > SUITE_DIR/suite.exit' < /dev/null > /dev/null 2>&1
```
SUITE_DIR = /tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3t16b/suite.
Leader PID 594586 (PPID 1, SID = PID), pytest PID 594588 (its /proc exe is env ltrpav's python3.12); at 19:31 the log
showed 16% with no failure. Not waited for; the controller reads suite.log and suite.exit.

## 8. Concerns

1. **A second copy of this agent** (the original controller session's, 19:09-19:15) worked beside me. I re-checked
   every file I touched: compare_papers.py, its test and logs, FINAL.md, real/memo.md, the papers and control outputs
   and final_vs_prelim.tsv carry my hashes (final_vs_prelim.tsv reproduces byte for byte). It rewrote only
   stability/final_vs_task15.tsv (plus its own scratch files in p3t16b/mine/), which my final diff run replaced; it
   made no commit and launched no suite. The 0fb466e2 hash in my first report version was its table; corrected above.
2. **One page.** RESULTS.md is 99 source lines: 33 bar rows (the brief's one line per bar), 3 outcome sentences, terms
   and 10 leads. Rendered it is a dense page or a little over; shrinking it further means grouping bars (for example
   the nine rule-5 bars in three lines).
3. **New fact, not in any RESULTS.md:** two all-trio paintings certify tracts at q <= 0.05 (PT 27 tracts, Zh 20; no
   truth to score them). RESULTS.md labels them unscored in lead 1; six/ and genus/RESULTS.md were not edited.
4. **Beyond the rulings' letter, for consistency:** control_main3 rerun and final_vs_prelim.tsv regenerated (FINAL.md
   says "main3 scored by the final script"; both show only the one note changed); 16A's script kept as
   compare_papers.py.task16a; real/memo.md got a full "Task 16" section (Step 1, 16A, 16B) where none existed;
   dead_ends.md got a short "2026-11-14 Plan 3 final comparison" entry (the brief lists dead_ends.md under Task 16, and
   16A left it to 16B or the controller), and FINAL.md section 4's first sentence now points to it.
5. **The memo's worker launch line** is the form real/memo.md describes (setsid nohup, nice 10, `--tag wN`); the exact
   launch lines are the controller's (ledger entries of 08:15-16:59).
6. **Stability tables:** Task 15's `<view>_papers.tsv` (old script; its roles note wrongly says "roles are inferred,
   never set") stay beside the new `final_<view>_*`; stability/RESULTS.md was not edited (no verdict changed).
7. Suite result pending (controller).

## Fix round 1 (review task-16b-review.md; wording only, no rerun, no repo change)

Every number and verdict is kept; the 33 bar lines are unchanged (21 PASS, 12 MISS; links all resolve). Files:
RESULTS.md 47f76d90... (115 lines, was 99), memo_ltrpav.md ade3cfa7..., sim/memo.md b96a475e..., real/memo.md
8e3ac737.... The repo is untouched (HEAD a44f532).

- **I1** RESULTS.md:10-12. The annotation result is now framed as simulated: "...in 20 simulated sets without gene
  flow where one sister was less completely annotated, gave no false signal (0 against LTRmix D_ins's 18 of 20;
  McNemar p 8e-6)".
- **I2** RESULTS.md:17-20. Outcome sentence 3 now states that D_pav does not tell the six-genome controls apart:
  +0.139 and +0.145 (Z 3.16, 3.20) where SNP D (+0.112, +0.052) and LTRmix's D_ins (Z 4.57, 1.19) separate them; the
  negative control misses at the 5-Mb rule, and the two swap verdicts with 10-20-Mb blocks; then the direction test,
  with its positive control's 2 of 8. Still three sentences; lead 5 keeps the detail.
- **I3** RESULTS.md:15-16. "in maize or sweet orange" -> "in the paintings with a known answer (B73 in the papers'
  view, sweet orange); two paintings with no known answer did (lead 1)".
- **I4** memo_ltrpav.md:201. The gotcha now says what happened, from the ledger's "Controller error and correction
  (12:20)" and the queue logs: this project's ~160 threads (grid 64 + queue 96 once w3 started at 10:53, the other
  project not counted) beside poa_synthesis's ~64-96 made ~225-255, over the weekend ceiling of 200, from 10:53; the
  controller noticed at 12:17-12:20 and set queue.pause, which stops new blocks only (nothing killed), so the count
  fell under 200 as the running blocks ended (six 12:22, genus 12:52); the pause was lifted at 13:40 when the grid freed
  its 64 threads; lesson: count every project's jobs by their thread flags before launching. One wording difference
  from the coordinator's note ("between 10:53 and 12:17"): the excess did not end at 12:17, because the pause stops
  only new blocks (after six ended, 128 + 64-96 = 192-224; after genus, 96 + 64-96 = 160-192).
- **M1** RESULTS.md:14-15. "against informative insertions a median 85 kb apart (element AUROC 0.71; tract recall
  1.0-1.7 times chance)" (FINAL.md row 7: 0.712; 1.3x, 1.7x, 1.6x, 1.0x).
- **M2** RESULTS.md:10-11, 23-24. "a guide rather than a like-for-like null" after the 60 simulated sets; "0 on
  average"; "5-Mb blocks in real genomes, ~1 Mb in the simulations".
- **M3** RESULTS.md:35. Rule 4's label is the bar: "≤ 1 of 30 nulls with a q ≤ 0.05 tract; excess over the decoy ≈ 0"
  (bars.tsv rows 23-25: at most 1 of 30, and the mean excess within 2 SE of 0).
- **M4** RESULTS.md:51-53. "scaled to the real count of informative insertions (6 times), simulated power is still
  optimistic, because real genomes resolve fewer calls (0.46 against 0.76)" (SIM_RESULTS section 10).
- **M5** RESULTS.md:57-58. "The five DESIGN 10.3 claims take six lines here, because the chromosome claim has two
  readings (FINAL.md counts rows: 19 PASS, 5 MISS)."
- **M6** RESULTS.md:26-27, 105-115. AUROC defined in Terms; lead 8 glosses the fallback, names the genus test (Zh
  against TIL18, unannotated *Z. diploperennis* as donor) and the near-tie (TIL01 against TIL25), and says what
  FOUR_LIST_NOTE is (the note on the direction test's pattern counts, citing a Plan 3 check that was not run); lead 10
  glosses genotype_all.sh (the genotyping queue's script: argument checks, locks, stop handling) and `--identity` (the
  option that keeps the sequence-identity layer).
- **M7** RESULTS.md:88-90, 113-115. Lead 1 adds the any-q advantage (`decoy` and `anydecoy` beat the default's AUROC
  and base-pair precision in 29-31 of 33-34 simulated runs; SIM_RESULTS lead 1); lead 10 adds Task 2 concern 4 (two
  simulator tests depend on msprime's random streams, so other msprime builds may pick another test seed;
  task-2-report.md:203-204, ledger :20).
- **M8** memo_ltrpav.md:179 and sim/memo.md:355. The rescore launch wrote `> sim/rescore.nohup` (ledger :215;
  sim/rescore/nohup.out never existed); both lines now say so and name the script's own summary log,
  sim/rescore/rescore.log (byte-identical to sim/rescore.nohup, cmp).
- **M9** memo_ltrpav.md:184. The six-genome view line now shows view, stats and paint.
- **Nit, real/memo.md:319-321.** The two bare `python` calls now use env ltrpav's python (`PY=...`). Not changed:
  DESIGN.md:873's "13,538.154280338664" separator (DESIGN 12 is approved; no repo change).

Concern: RESULTS.md grew from 99 to 115 lines with the requested text; it is now more than one printed page.

## Fix round 2 (re-review ruling; text only, outside the repo)

- memo_ltrpav.md:201: the excess now starts "from the 08:18 speed-up (by flag count; the low load average at launch,
  21-47, hid it) until the running blocks ended (six 12:22, genus 12:52)"; this project ~160 by flags from 08:18 (grid
  64 + LTRquest 32 + queue 64; w3 at 10:53 only took LTRquest's 32); sources: the ledger's "Controller error and
  correction (12:20)" and "Correction (controller, 2026-11-14 ~20:00)"; lesson names flags, not load. File sha256
  0f5981a7....
- RESULTS.md:55: the claims note folded into the heading, "Real genomes: 12 PASS, 5 MISS (by line; FINAL.md's rows: 19
  PASS, 5 MISS)" (old :57-58 removed).
- RESULTS.md:90-92: the FOUR_LIST_NOTE clause moved from lead 8 into lead 3 (Direction).
- RESULTS.md:85-86 (lead 1's added sentence), :103-105 (lead 8), :107-109 (lead 10): explanations trimmed.
- No bar line merged (33: 21 PASS, 12 MISS); no number or verdict changed (every number of the old file is still
  present, except the label "10.3" in the folded sentence). RESULTS.md 109 lines, sha256 e5f2fa40....
