# Task 11 Part P report: rescore tooling, scoring smoke test, LTRmix's absent calls

Date: 2026-11-14 (08:24-09:00). Status: DONE_WITH_CONCERNS.

**Minors round** (10:12-10:27, the last section) fixes review findings m2 and m4-m8 and writes the delta package
`task-11p-review-package-2.diff`. **Fix round 2** (09:45-09:52) implements the ruling "rule 5 with no calls" in
summarize.py and writes the review package `task-11p-review-package.diff`. **Fix round 1** (09:05-09:45, the section before it)
supersedes three things below: ltrmix_absent.py's cause order (now
library first) and its refusal of LTRquest runs (now listed as not attributed), and rescore_all.sh's default
`--jobs 8` (now 4). Defects 1 and 2 are fixed there. The fixed scoring scripts are installed in sim/, with their new
sha256s in sim/memo.md.

Paths below: `P=/data2/chris/maize_introgression`, `SIM=$P/benchmark_pav/plan3/sim`,
`SCR=/tmp/claude-1007/-data2-chris-maize-introgression/6b33811c-ca10-4dfe-94dc-c7d4becddd02/scratchpad/p3t11p`.

## Headlines
1. `sim/rescore_all.sh` is built and tested. The in-place rescore of null_s101 and f0.18_Ta5000_r1 reproduces both
   eval files exactly apart from timestamps, and all 72 score files of each run are byte-identical.
2. **Scoring defect 1 (blocks rule 5).** Rule 5's pooled-FDR bar (any, decoy, anydecoy) is NA for good: "34 of 36
   usable", although all 36 C>A power runs are finished. In two of them (f0.02_Ta50_r1, r2) A1 inherited no tract.
   No rescore can change this, so no variant can ever be adopted under rule 5 as the code stands.
3. **Scoring defect 2 (minor, asymmetric).** In f0.02_Ta50_r1 both tools infer the wrong recipient. LTRpav's
   unconditional head-to-head recall counts it as 0, while LTRmix's drops it. This breaks "wrong recipients counted
   alike for both tools".
4. **The "62% truth-present" premise is a misreading.** The 62% (30,816 of 49,585 in null_s101) is eval_ltrmix's absent
   fp: every absent call whose truth is not E. That fp includes truth D, O and G, which are not present. Truly present
   copies (P, S, T) are 38% of LTRmix's absent calls (P alone 32%, the same as the toy-scale 30-35%), so there was no
   rise from toy to 50 Mb. Pooled over the 66 finished null and power runs, the truly present absent calls split into
   S/T 15.2%, annotation dropout 17.0%, orthology miss 67.7% and other 0%. All counts reconcile exactly with
   eval_ltrmix.json.

## 1. `sim/rescore_all.sh` (Task 11 Step 1)

```
rescore_all.sh [--jobs N] [--names N1,N2,..] [--logdir DIR] [--tables DIR] [--no-summarize] [--dry-run]
```
- **Run set.**
  - Every grid.tsv row whose `sim/runs/<name>/run.done` exists. The `*.100Mb` pilot copies are not grid rows, so
    they are never in the set.
  - Then every LTRquest run `sim/lq/<name>` with run.done, labeled `lq/<name>`. The expected names are run_lq.sh's
    defaults (null_s101, null_s102, f0.18_Ta5000_r1) plus any other `sim/lq/*/` directory.
  - Rows and LTRquest runs without run.done are listed as missing and are not fatal. An unknown name in `--names`
    is a usage error (exit 2).
- **Eval.** Each run gets run_one.sh's eval step verbatim, in the run directory and under `common/env.sh`:
  `python sim/eval_run.py RUNDIR`, then `$LTRMIX_PY sim/eval_ltrmix.py RUNDIR`.
  - It holds `RUNDIR/.lock` (`flock -n`, as run_one.sh does). A run that a runner holds fails with exit 3 and is not
    touched.
  - A failing eval_run.py stops that run before eval_ltrmix.py. Each failure exits explicitly, because `set -e` is
    ignored inside a subshell on the left of `||`.
  - The script also exports `OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1`. The grid ran its evals with
    8 here; the eval code has no BLAS calls, and the in-place test below shows identical output.
- **Check.** After the evals, every rescored eval.json and eval_ltrmix.json must:
  - name the run in its sim.done;
  - have been written by this invocation (mtime at or after the start);
  - record the sha256 of each script on disk (eval_run.py, eval_ltrmix.py, evalib.py, make_grid.py, RULES.md);
  - for eval_ltrmix.json, also record the sha256 of the eval.json beside it (summarize's staleness test).

  Every run that differs is listed in rescore.log and check.out, with the reason, and the script exits 1.
- **Tables.** `python sim/summarize.py --out TABLES`, then `python sim/ltrmix_absent.py -o TABLES/ltrmix_absent.tsv`.
  - `--tables` defaults to `sim/tables`.
  - The step is skipped with `--no-summarize`, and also when any eval or the check failed (exit 1, no rescore.done).
  - summarize.py reads only grid runs. The LTRquest runs are rescored but not summarized (concern 4).
- **Output** (in LOGDIR, default `sim/rescore`):
  - `rescore.log`: the summary, appended per invocation and also printed on stderr;
  - `runs/<name>.log` and `lq/<name>.log`: each run's stamped commands and output;
  - `check.out` and `check.err`, `summarize.out` (the bars), `summarize.err`, `ltrmix_absent.err`;
  - `rescore.exit`, and `rescore.done` (written only on full success).

  One rescore_all.sh may run per LOGDIR (`flock` on `LOGDIR/.lock`). `--dry-run` prints the set and every command,
  and writes nothing.
- **Threads.** `--jobs N` defaults to 8. Each eval_run.py runs up to 8 `ltrpav-sim score` processes, its default, kept
  to match run_one.sh exactly. So `--jobs N` peaks near 8N processes during score phases.
  - Measured: about 12-18 s per run at load 120-145, plus about 1.5 min for ltrmix_absent.py over about 104 runs.
  - About 147 runs at `--jobs 4` (peak about 32 threads) is about 11-12 min of evals plus about 2 min of tables. At
    `--jobs 8` (peak about 64) it is about 6 min of evals.
  - Launch detached either way:

```bash
cd $P/benchmark_pav/plan3/sim && mkdir -p rescore
setsid -f nohup ./rescore_all.sh --jobs 4 > rescore/nohup.out 2>&1 < /dev/null
# then: cat rescore/rescore.exit; ls rescore/rescore.done; tail rescore/rescore.log
```

### How rescore_all.sh was tested
All tests ran with `--jobs 1` (at most 8 threads), except the stub test.

| test | what | result |
|---|---|---|
| dry-run, default set | `./rescore_all.sh --dry-run` | 102 runs with run.done of 147 selected; 45 missing (42 grid rows in progress or not started; 3 LTRquest runs); 102 eval blocks + check + tables; nothing written (no `sim/rescore`) |
| dry-run, options | `--names null_s101,f0.18_Ta5000_r1 --no-summarize`; `--names lq/null_s101`; `--names null_s101,nope,lq/xx`; `--names null_s101.100Mb`; `--jobs 0` | 2 runs, no tables step; lq run listed missing; unknown names exit 2 (the .100Mb copy is refused); exit 2 |
| **in place** | `--names null_s101,f0.18_Ta5000_r1 --no-summarize --jobs 1 --logdir $SCR/rescore_test` | exit 0, 36 s (18 s per run), check: 2 runs, 0 differ; rescore.done; comparison below |
| failure paths (A) | a scratch mirror of sim/ (`$SCR/mirror`): run dirs link the real inputs but have their own eval/ and .lock. Four rows: null_s102 with its mirror lock held, null_s101, f0.18_Ta5000_r1 without views/, and bn_null_s30 absent | null_s102 FAILED exit 3 ("in use", untouched); null_s101 ok; f0.18 FAILED exit 1 at eval_run.py (eval_ltrmix.py not run); bn_null_s30 and 3 lq runs listed missing; "failed: tables not rebuilt"; exit 1; no rescore.done; the real runs unchanged (full file listings with sizes and mtimes compared) |
| sha mismatch (B) | mirror make_grid.py with one line appended | "CHECK FAILED ... null_s101: eval.json records make_grid.py 5c6a541b, on disk abd56f4d"; exit 1 |
| check branches | the check's embedded Python, extracted verbatim, on 7 crafted eval dirs | each of wrong run name, not rewritten, unknown script, missing script key, eval.json sha mismatch and unreadable JSON is listed with its reason (exit 1); the clean dir passes (exit 0) |
| parallel plumbing | `$SCR/mirror2`: stub eval scripts that sleep 3 s (one exits 1), 4 runs, `--jobs 4` | 3.2 s wall (parallel); 3 ok, 1 FAILED; results collected out of order; the stale eval files are flagged by the check |
| success with tables (C) | mirror, `--names null_s101`, tables to `$SCR/mirror/sim/tables` (summarize and ltrmix_absent read the real finished runs, read-only), rerun after the last edit | exit 0, 96 s; check ok; summarize "144 grid runs; ok/ok 104"; ltrmix_absent 104 runs reconciled; rescore.done; 15 tables written; the real `sim/tables` untouched (still dated 2026-11-13 03:58) |

### In-place rescore comparison (Task 11 Step 1's test)
The old `eval/` directories were copied to `$SCR/old_eval/<name>/` before the rescore and compared after it with
`$SCR/probe/compare_eval.py`: a JSON diff in which only `created`, `elapsed_s` and eval_ltrmix's
`inputs.eval.json` may change, plus a byte comparison of `score/`. That last field is the sha256 of eval.json, which
holds the timestamps. The comparator was itself checked on a planted copy with one added key, one changed count and
one changed score file; it reported all three (exit 1).

| run | eval.json | eval_ltrmix.json | score/ | outside eval/ |
|---|---|---|---|---|
| null_s101 | 0 differences; created 2026-11-13T03:57:54 -> 2026-11-14T08:44:49, elapsed 12.0 -> 15.9 s | 0 differences; created, elapsed, inputs.eval.json b82d5763 -> 55988bbb | 72 files, byte-identical | unchanged (names, sizes, mtimes) |
| f0.18_Ta5000_r1 | 0 differences; created 03:58:08 -> 08:45:07, elapsed 12.5 -> 16.0 s | 0 differences; created, elapsed, inputs.eval.json c98ea17d -> 41b2746c | 72 files, byte-identical | unchanged |

Both runs' eval files are current, so summarize loads them as ok (smoke test and test C: ok/ok).

## 2. Scoring smoke test (finished runs, into scratch)

```bash
cd $P/benchmark_pav/plan3 && . common/env.sh && export NUMPY_MADVISE_HUGEPAGE=0 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
/usr/bin/time -v -o $SCR/smoke/summarize.time python sim/summarize.py --out $SCR/smoke/tables -v \
  > $SCR/smoke/summarize.out 2> $SCR/smoke/summarize.err
```
- **Run.** Started 08:46:18 at load 145, with 102 runs having run.done. Wall 9.0 s (user 3.1 s, system 0.8 s), max RSS
  177 MB, exit 0, no traceback. All 14 tables were written.
- **Status:** 144 grid runs: ok/ok 102, absent/absent 38, unscored/unscored 4 (in progress). No run was stale or
  failed.
- **Sets loaded** (summarize's own `sets()`; LTRpav and LTRmix counts were identical in every set):

| set | grid runs | loaded | missing |
|---|---|---|---|
| null | 30 | 30 | 0 |
| bneck_null | 30 | 21 | 9 (7 absent, 2 unscored) |
| bneck_gf | 3 | 0 | 3 absent |
| power (C>A) | 36 | 36 | 0 |
| drop_null | 20 | 0 | 20 absent |
| drop_gf (f 0.18) | 6 | 4 | 2 unscored |
| posctl | 8 | 0 | 8 absent (posctl_null 0 of 2) |
| ptlike | 3 | 3 | 0 |
| reverse | 8 | 8 | 0 |
| cta (head to head) | 45 | 40 | 5 (3 absent, 2 unscored) |
| all | 144 | 102 | 42 |

- **NA audit.**
  - Every `na` entry of the 102 loaded eval.json and eval_ltrmix.json files was collected and grouped by field and
    reason (`$SCR/smoke/na_census.tsv`: 324 groups, 68 distinct reasons). Every reason or note clause in the 14
    tables was listed as well.
  - No table cell carries summarize's fallback "not in the eval file", and no eval NA lacks a reason.
  - Two NA patterns are defects (below). Every other NA is documented: in the eval scripts' docstrings, the Task 9
    report, summarize's readings, or ltrpav's own notes. The families are:
    - design fields not set;
    - no true A1 tract (f 0, or pulse A>C);
    - a wrong or unidentified recipient (one null run has roles by sheet order, ruling I2);
    - no q <= 0.05 tract, and empty length or locus bins;
    - identity, rate_free_split and nodonor exist only for some kinds;
    - the trio design has no C2 and no direction;
    - LTRmix's young D_ins stratum has fewer than 10 loci;
    - LTRmix paints only its recipient, and C2 fails LTRmix's second-donor check;
    - no LTRquest genome (the coords pool);
    - "no G/O/T call (high)": by design T and O calls carry no evidence of their own and G gets tier ".", so none can
      be high tier (ltrpav classify.py docstring);
    - the K=0 jackknife "not testable" notes.
- **Not a defect, but a permanent NA to know about:** rule 2's dD row is NA in 29 of the 30 nulls. The youngest age
  stratum K=0 has "no informative locus" or is "not testable by the block jackknife". These are ltrpav-stats notes,
  documented, and RULES.md allows "NA with its reason". The row will stay NA after the grid ends.

### Defect 1: rule 5's pooled-FDR bar can never be decided (eval_run.py and summarize.py together)
- **What.** bars.tsv rule 5 "<v>: pooled tract FDR at q <= 0.05" for any, decoy and anydecoy (and the matching
  variants.tsv rows) reads verdict NA: "n runs < required: 34 of 36 usable; 2 NA (2 x pulse into A1 but no tract
  survived in A1 (tracts.A1.bed empty))". All 36 C>A power runs are finished and current.
- **Cause.**
  - In f0.02_Ta50_r1 and f0.02_Ta50_r2, A1 inherited no tract: `sim/truth/tracts.A1.bed` is empty and A1's true
    fraction is 0.0. That is plausible at f 0.02 and Ta 50, with only a few long ancestry segments per genome.
  - eval_run.py `paint_section` (around line 599) then sets `models.<m>.accuracy` to NA as a whole, `tract_fdr_q05`
    included. Yet the realized FDR is defined there: every q <= 0.05 tract would be false. Both runs have
    `n_tracts_q05` 0 in all four models.
  - summarize.py `rule5` (around lines 926-930) reads `tract_fdr_q05.n_called` through `series()`. The two NA runs
    make `nc.short` nonzero, so `fdr_ok` is None.
- **Consequence.**
  - The truth is final, so no rescore changes it. "all four hold" can never be true, so rule 5 cannot adopt any
    variant.
  - The clause "decoy is also adopted when the default fails rule 4 and decoy passes ... rule 5's FDR bar" cannot
    fire either.
  - Counting the two runs as 0 false of 0 called would leave every pooled FDR value unchanged with the current data.
  - The sign tests are not blocked: they drop the two runs as NA pairs and report them.
- **Minimal reproduction** (read-only, about 5 s), `$SCR/probe/repro_rule5_fdr.py`, run from plan3/ after
  `. common/env.sh`:
```
C>A power runs: 36, with a current eval.json: 36
  f0.02_Ta50_r1: models.any.accuracy NA (pulse into A1 but no tract survived in A1 (tracts.A1.bed empty)); n_tracts_q05 any/decoy/anydecoy/main = [0, 0, 0, 0]; A1 true fraction 0.0
  f0.02_Ta50_r2: (same)
any: pooled tract FDR at q <= 0.05: verdict NA; n_required 36, n 34, n_na 2; n runs < required: 34 of 36 usable; 2 NA (2 x pulse into A1 but no tract survived in A1 (tracts.A1.bed empty))
decoy: ... (same)   anydecoy: ... (same)
```
- **Not fixed.** Ways the controller could rule:
  - eval_run.py records `tract_fdr_q05` (n_false = n_called) when the truth is empty, and keeps recall NA;
  - or summarize treats that NA reason as 0 of n_called;
  - or the bar's required set excludes runs without a true tract.

  The same early return exists in eval_ltrmix.py `paint_mode` (around line 365): it returns before
  `n_tracts_q05_file` and `tract_fdr_q05`, so LTRmix's head-to-head realized FDR also drops such runs. This has no
  effect now: LTRmix's hmm rows show 0 q <= 0.05 tracts in A1 in r2, and it painted B1 in r1.

### Defect 2: an empty truth is scored as recall 0 for LTRpav but NA for LTRmix (eval_run.py vs eval_ltrmix.py)
- **What.** In f0.02_Ta50_r1 (A1 true fraction 0.0), both tools infer recipient B1, so wrong_recipient is 1 for both.
  - eval_run.py `head_to_head_section` (around line 640) writes the wrong-recipient accuracy (bp_recall 0.0) over the
    "no tract survived" NA.
  - eval_ltrmix.py `paint_mode` checks for the empty truth first and returns NA.
  - summarize.py `tract_rows` therefore puts LTRpav's 0.0 into `bp_recall_{all,q05}_uncond_mean` (n 1) and leaves
    LTRmix out (n 0).
- **Consequence.**
  - In tracts.tsv, LTRpav's unconditional recall for the groups f0.02_Ta50, "power (all)" and "C>A (all)" carries one
    zero that LTRmix's lacks. Recall is undefined there for both tools.
  - This contradicts Step 2.3's "wrong recipients counted alike for both tools". The conditional metrics and
    n_wrong_recipient (1 for both) are unaffected.
- **Minimal reproduction** (read-only), `$SCR/probe/repro_uncond_recall.py`:
```
A1 true fraction 0.0
LTRpav: wrong_recipient 1; head_to_head.paint.accuracy = dict, all.bp_recall 0.0
LTRmix: wrong_recipient 1; head_to_head.paint.ancestry.accuracy = NA (pulse into A1 but no tract survived in A1 (tracts.A1.bed empty))
  tract_rows: LTRpav (roles): bp_recall_all_uncond_mean = 0.0 (n 1)
  tract_rows: LTRmix ancestry: bp_recall_all_uncond_mean = None (n 0)
  tract_rows: LTRmix recent: bp_recall_all_uncond_mean = None (n 0)
```
- **Not fixed.**

## 3. `sim/ltrmix_absent.py`: why LTRmix calls truly present copies absent

```
python sim/ltrmix_absent.py [RUN ...] [--runs DIR] [--grid TSV] [--kinds K1,K2] [-o TSV] [-v]
```
- **Which runs.** Without RUN, every grid row (in grid order) whose run has run.done and eval/eval_ltrmix.json.
  `--kinds` keeps only those grid kinds.
- **Output.** One row per run, then pooled rows: one per kind when there are several kinds, then one over every run.
  The TSV goes to stdout or `-o` (written atomically). It runs in env ltrpav, takes about 1-2 s per run and uses one
  process.
- **The absent call is eval_ltrmix.py's own.** Its functions are imported, not copied: `Mix` (the library set),
  `read_tsv`, `record_names` (the eid join through sim/<x>.gff3's Name), `truth_rows`, and STATES, PRESENT and
  STATUS.
  - For each ordered library pair (x, y), a record of orthologs.x.y with `status_in_y == "absent"` and a truth name
    is one call, and its truth is the element's state in y.
  - A run whose libraries are not built from the simulated GFF3 (eval_ltrmix joins them by coords, as for the
    LTRquest runs) is refused with a clear error.
- **Classes**, one per call:
  - **E:** correct absent calls (eval_ltrmix's absent tp).
  - **D, O, G:** not present, not E. They are counted in eval_ltrmix's absent fp but not attributed.
  - **Truth P, S or T:** truly present, with exactly one cause, the first that applies:
    - **a, S_or_T:** truth S or T in y.
    - **b, annotation_dropout:** truth P, and y's GFF3 (the annotation the run gave LTRmix) lists no copy of the
      element.
    - **c, orthology_miss:** truth P, and the copy is annotated in y and has a record in y's library, but LTRmix did
      not pair them.
    - **d, other, with its reason:** for example annotated in y but missing from y's library, or the two ortholog
      files disagree.
- **Sub-counts** ("of which"):
  - `a_T_annotated`: T copies that y's annotation does list (alive partial copies, so a library record existed);
  - `b_not_alive`: the copy is not among y's alive elements (its truth rows), so it was never annotatable rather
    than randomly dropped;
  - `c_partner_elsewhere`: LTRmix paired y's record with another record of x.
- **Columns.** absent_calls = truth_E + not_E; not_E = truth_present + truth_D + truth_O + truth_G;
  truth_present = a + b + c + d.
  - frac_a to frac_d are fractions of truth_present.
  - frac_present_of_absent and frac_not_E_of_absent are fractions of all absent calls. The second is the pilot's
    "62%".
- **Reconciliation, enforced per run.** The absent calls by truth state must equal eval_ltrmix.json's
  `presence_absence.confusion[state]["absent"]` for all seven states. truth_E and not_E must equal its pooled absent
  tp and fp; these are written as `eval_absent_tp` and `eval_absent_fp`. Any difference is an error (exit 1, nothing
  written), and the code also asserts a + b + c + d = truth_present.

### Tests (`sim/test_ltrmix_absent.py`, red then green)
- **Red.** `python -W error -m pytest -q -p no:cacheprovider sim/test_ltrmix_absent.py` failed first:
  `ModuleNotFoundError: No module named 'ltrmix_absent'`, written before the tool. Then 7 passed.
- **Fixture.** A trio run (A1 B1 C1 in ltrmix/ itself). A1's elements e01-e16 give one absent call of every class in
  A1 -> B1: E, S, T not annotated, T annotated, P dropped and alive, P not alive, P unpaired, P paired elsewhere,
  P annotated but not in the library (d), D, O and G. There is also a present call, an unresolved call, and an
  element A1 itself dropped.
  - B1 -> A1 adds a b and a c seen from the other side; C1 -> A1 adds an E and an S.
  - Hand-worked totals: 16 absent calls, E 2, not_E 14, D 1, O 1, G 1, truth-present 11; a 4 (S 2, T 2,
    T annotated 1), b 3 (not alive 1), c 3 (partner elsewhere 1), d 1.
- **The 7 tests:**
  - every call's class against the hand table;
  - totals and fractions;
  - the CLI reconciling with an eval_ltrmix.json built by eval_ltrmix's own `presence_absence_section`; a tampered
    confusion cell exits 1 and writes nothing;
  - the error names the state;
  - grid discovery (unfinished and absent rows skipped; `--kinds null` with none left is an error);
  - per-kind pooled rows;
  - refusal of a coords-joined library.
- **Mutants.** 11 mutants were run against the tests (`$SCR/mut/mutate.py`), and every one fails at least one test:
  b before a, T_annotated dropped, alive check inverted, library check removed, partner ignored, unresolved counted
  as absent, confusion check removed, fractions of absent instead of present, per-kind pools dropped, join check
  removed, D/O/G attributed as "other".
- **Full suite:** `sim/test_ltrmix_absent.py sim/test_summarize.py sim/test_eval_ltrmix.py common/test_evalib.py`:
  46 passed. No cache directory was written in sim/.

### Run on the finished null and power runs (`$SCR/absent/null_power.tsv`)
```bash
python sim/ltrmix_absent.py --kinds null,power -o $SCR/absent/null_power.tsv   # 66 runs, 2 min 20 s (cold cache), 1 process
```

| | null_s101 | f0.18_Ta5000_r1 | pooled null (30) | pooled power (36) | **pooled null + power (66)** |
|---|---|---|---|---|---|
| LTRmix absent calls | 49,585 | 48,959 | 1,483,479 | 1,767,152 | **3,250,631** |
| truth E (correct; eval tp) | 18,769 | 18,550 | 571,098 | 670,505 | 1,241,603 |
| not E (eval fp; the "62%") | 30,816 (0.621) | 30,409 (0.621) | 912,381 (0.615) | 1,096,647 (0.621) | 2,009,028 (0.618) |
| of which truth D / O / G | 8,823 / 2,023 / 997 | 8,690 / 1,988 / 1,058 | 253,156 / 59,984 / 29,458 | 299,575 / 71,093 / 35,485 | 552,731 / 131,077 / 64,943 |
| of which truth-present (P S T) | 18,973 (0.383 of absent) | 18,673 (0.381) | 569,783 (0.384) | 690,494 (0.391) | 1,260,277 (0.388) |
| a: S or T | 3,026 (0.159) | 2,762 (0.148) | 88,077 (0.155) | 104,016 (0.151) | 192,093 (0.152) |
| b: annotation dropout | 3,306 (0.174) | 3,098 (0.166) | 97,213 (0.171) | 117,217 (0.170) | 214,430 (0.170) |
| c: orthology miss | 12,641 (0.666) | 12,813 (0.686) | 384,493 (0.675) | 469,261 (0.680) | 853,754 (0.677) |
| d: other | 0 | 0 | 0 | 0 | 0 |
| a_S / a_T / a_T_annotated | 1,195 / 1,831 / 1,116 | 1,101 / 1,661 / 1,007 | 36,246 / 51,831 / 29,875 | 42,384 / 61,632 / 36,397 | 78,630 / 113,463 / 66,272 |
| b_not_alive | 6 | 2 | 49 | 122 | 171 |
| c_partner_elsewhere | 94 | 112 | 2,869 | 3,497 | 6,366 |
| reconciled with eval_ltrmix.json | yes (tp 18,769, fp 30,816) | yes (18,550, 30,409) | yes | yes | yes (1,241,603, 2,009,028) |

Fractions in a-d rows are of truth-present calls. Per run (66 runs): frac_present_of_absent 0.372-0.408, frac_c
0.666-0.693.
- **Reconciliation.** The 49,585 absent calls in null_s101 are E 18,769 + P 15,947 + S 1,195 + T 1,831 + D 8,823 +
  O 2,023 + G 997, matching eval_ltrmix.json's confusion column cell by cell. Its absent fp 30,816 = 18,973
  truth-present + 11,843 D/O/G.
- **All kinds** (test C, 104 finished runs at 08:57): 4,973,161 absent calls, truth-present 0.389. Of the
  truth-present calls, a 0.152, b 0.173, c 0.675, d 0; all reconciled. The trio dropout runs show b 0.31, as the next
  check explains.
- **Independent check: a planted signal** (`$SCR/probe/dropout_check.py`). The dropout runs raise A1's annotation
  dropout by design, so cause b should rise only where the target genome y is A1, in step with the measured dropout.

| run | y = A1: measured dropout, b share of P-absent calls | y = B1 | y = C1 |
|---|---|---|---|
| fn0.2_f0.18_r3 (A1 dropout 0.2) | 0.198, 0.372 | 0.098, 0.199 | 0.101, 0.221 |
| fn0.4_f0.18_r1 (A1 dropout 0.4) | 0.399, 0.617 | 0.100, 0.208 | 0.094, 0.203 |
| null_s101 | 0.102, 0.201 | 0.103, 0.217 | 0.100, 0.206 (C2 0.105, 0.205) |

Fit on the null (b share 0.206 at dropout 0.10): LTRmix calls an annotated P copy absent at about 0.43 of the rate for
an unannotated one. That ratio predicts b shares of 0.37 and 0.61 at the measured dropouts of 0.198 and 0.399; the
observed shares are 0.372 and 0.617.

## Files written
- `$SIM/rescore_all.sh` (new, executable): sha256 7f514be2a06433a6b72990b276469c67e6e09f74ff3abfb869a9fc5cde21d80e.
- `$SIM/ltrmix_absent.py` (new, executable): sha256 15001213ef53b2bf22292f8d4c4c440d9968cbb1d8d4daf84deacbc5069126a1.
- `$SIM/test_ltrmix_absent.py` (new): sha256 8268dd3b1dcfc79d1506eebde61abb8325c80a3aeb596b55f4648ae76676aa00.
- `$SIM/runs/null_s101/eval/` and `$SIM/runs/f0.18_Ta5000_r1/eval/`: eval.json, eval_ltrmix.json and score/,
  rescored in place, identical apart from timestamps.
- This report.
- Scratch (`$SCR`):
  - old_eval/ (the pre-rescore copies, kept), rescore_test/ (the in-place test's logs);
  - smoke/ (tables, NA census, time), absent/ (pilot2.tsv, null_power.tsv);
  - mirror/ and mirror2/ (failure, parallel and tables tests, with their own logs and tables), checktest/, mut/;
  - probe/ (explore, compare_eval, sets_and_na, the two repro scripts, dropout_check).
- **Unchanged (sha256 checked at the end):** run_one.sh e4136cd6, run_grid.sh 03d3a03d, common/env.sh 5728e569,
  lq/run_lq.sh 146d7bb9, RULES.md 4111826d, eval_run.py 6fbe0794, eval_ltrmix.py 3287f3d0, evalib.py f9f61a20,
  summarize.py c0c9dd3a, make_grid.py 5c6a541b.
  - Nothing else in plan3 changed outside the runners' own output.
  - No repo file was edited. The only eval files newer than 08:24 besides the two test runs come from the runners'
    own eval steps (checked against their run.log).
- **sim/memo.md was not edited**, since it is outside the brief's write list. Memo-ready commands are above:
  rescore_all.sh launch, smoke summarize, ltrmix_absent.

## Concerns
1. **Defect 1** blocks rule 5's FDR bar, and with it any variant adoption, until the controller rules. A RULES.md
   reading is needed: does a C>A power run without a true A1 tract count toward the realized FDR?
2. **Defect 2** biases only LTRpav's unconditional head-to-head recall (one extra zero today). It needs a ruling
   before section 3 of SIM_RESULTS.md is read.
3. **R1's premise.** "62% of absent calls truly present" appears in the brief, R1, memo.md and the Task 9 report.
   It is the absent-call fp share, which includes D/O/G; the truly present share is 38-39%.
   - For the presence/absence head-to-head: LTRmix's single "absent" call lumps E, D and O. Against E alone, as
     eval_ltrmix scores it and as LTRpav's absent class is defined, its precision is 0.38. If an absent call counted
     as right whenever no copy is present (E, D or O), it would be 0.59; G, an assembly gap, is 2%.
   - Which reading is fair is a ruling, not a fact the tool can settle.
   - Cause a's rationale ("libraries hold intact elements") fails for 58% of the T calls: the y copy was annotated
     and alive, so those are closer to orthology misses on truncated copies.
4. **summarize.py reads only grid runs.** rescore_all rescores the LTRquest runs, but no table covers them, and
   ltrmix_absent.py refuses them (coords join). Section 7's "LTRquest runs against their truth-annotated pairs" will
   need their eval files read directly, or a summarize call on a one-off grid.
5. **Threads.** `--jobs 8` (the brief's default) peaks near 64 processes; choose `--jobs` against the live budget.
   The run takes about 10-15 min, so launch it detached.
6. The in-place test used `OMP_NUM_THREADS=1` where the grid used 8. The output was identical; the eval code has no
   BLAS calls.

## Fix round 1 (2026-11-14, rulings R4)

Rulings applied (task-11-rulings.md R4; ledger from "Ruling (defect 1)"):
1. eval_run.py and eval_ltrmix.py, empty A1 truth: tract_fdr_q05 recorded (n_false = n_called), the rest NA.
2. eval_run.py head_to_head: an empty truth is checked first. A wrong recipient's accuracy is NA, as in
   eval_ltrmix.py, and wrong_recipient is still counted.
3. ltrmix_absent.py `--pa`: both tools on one truth, binary beside strict_E.
4. ltrmix_absent.py causes go by the library first.
5. ltrmix_absent.py lists the LTRquest runs as not attributed (the ledger's "Ruling (LTRquest runs)").
6. rescore_all.sh: default `--jobs 4`.

**How the fixes were made safely.** The grid runners start eval_run.py and eval_ltrmix.py for every run they finish,
so every change was written and tested first in a scratch copy of sim/ (`$SCR/fix/sim`):
- copies of the changed files and of summarize.py;
- symlinks for make_grid.py, RULES.md and direction_predictions.tsv;
- common/ linked.

The copied suite passed unchanged there (37 passed) before any edit. The finished files were then moved into sim/
atomically (`$SCR/fix/install.sh`).

### Tests first (each new test failed before its fix)
```bash
cd $SCR/fix && python -W error -m pytest -q -p no:cacheprovider sim/<test file>   # after . common/env.sh (plan3/)
```

| fix | test (red, before the fix) | after |
|---|---|---|
| 1, eval_run.py `paint_section` | new `sim/test_eval_run.py`: synthetic view (tracts at q 0.01, 0.04, 0.3), fake stats with no row. `test_empty_truth_records_the_realized_fdr` (FDR 2 of 2; recall, precision and their bp NA with the reason; n_called 3 and 2), `test_empty_truth_without_a_q05_tract` (0 of 0, fdr NA "no tract at q <= 0.05"), `test_empty_truth_right_recipient_records_the_fdr`: **failed** (accuracy was NA, so the dict could not be indexed) | pass |
| 2, eval_run.py `head_to_head_section` | `test_empty_truth_wrong_recipient_is_na_not_recall_zero`: **failed** (bp_recall 0.0 written). `test_wrong_recipient_with_a_true_tract_still_scores_recall_zero` (regression) passed before and after | pass |
| 1, eval_ltrmix.py `paint_mode` | `test_eval_ltrmix.py::test_empty_truth_records_the_realized_fdr` (ancestry FDR 1 of 1; recent 0 of 0, fdr NA; n_tracts_q05_file 1 and 0; recall, precision and their bp NA; n_elements 4, inside 0, true_bp 0): **failed** (accuracy NA). `test_empty_truth_wrong_recipient_is_na` (regression; LTRmix already did this) passed before and after | pass |
| 3, 4, 5, ltrmix_absent.py | `test_ltrmix_absent.py`: library-first causes, plus element e17 (its two ortholog files disagree: d), LTRpav confusion and score files in the fixture, and the hand-worked readings. 7 **failed** of 10 (causes, totals, CLI, pools, the readings, the LTRpav reconcile, the one-truth check); later 2 more **failed** (the LTRquest listing: explicit run and discovery) | 13 pass |

Red runs: test_eval_run.py 4 failed, 1 passed; test_eval_ltrmix.py 1 failed, 6 passed; test_ltrmix_absent.py 7
failed, 3 passed; then the LTRquest listing 2 failed, 11 passed.

**Mutants** (`$SCR/mut/mutate2.py`, `mutate3.py`). 14 mutants targeted the new logic:
- the state checked before the library; d-asym as c; GFF3-not-library as b;
- binary absent = E only; G not excluded; strict counting D calls absent;
- no one-truth check; no LTRpav reconcile; no LTRmix strict reconcile;
- n_neither not counted; unresolved as absent; c_S_or_T dropped; fn counting only other-class calls;
- the high tier read from all.

The tests killed 13 of them at first. The survivor (no LTRmix strict reconcile) was killed by an added test
(`test_pa_ltrmix_strict_must_match_eval_ltrmix`). All 8 still-applicable first-round mutants are killed as well:
22 of 22.

**Fixture readings** (pooled over the 6 pairs; truth P 15, S 2, T 2, E 28, D 1, O 1, G 1 = 50 items, the same per pair
for both tools), each as (tp, fp, fn):

| tool | tier set | binary present | binary absent | strict_E present | strict_E absent |
|---|---|---|---|---|---|
| LTRmix | all | 5, 0, 14 | 4, 12, 26 | 5, 0, 14 | 2, 15, 26 |
| LTRpav | all | 18, 1, 1 | 28, 0, 2 | 18, 1, 1 | 25, 1, 3 |
| LTRpav | high | 16, 1, 3 | 27, 0, 3 | 16, 1, 3 | 24, 1, 4 |

The LTRmix strict values I worked by hand equal what eval_ltrmix.py's own `presence_absence_section` computes on the
fixture; the tool enforces that.

### Real-data check of fixes 1 and 2 (scratch only; no run was rescored in place)
- **What was run.** The 36 C>A power runs were rescored with the fixed eval_run.py and eval_ltrmix.py into scratch
  mirror run directories (`$SCR/fix/sim/runs/<name>`: every input linked, own eval/ and .lock). The scratch
  rescore_all.sh did it, at `--jobs 1` (8 threads), 09:22-09:34, 18.6 s per run at load 150-190:
```bash
cd $SCR/fix/sim && timeout 15m ./rescore_all.sh --names "$(cat $SCR/fix/power_names.txt)" --no-summarize --jobs 1 \
  --logdir $SCR/fix/rescore_log
```
- **Two process slips, both caught.**
  - My first launch used a hand-typed name list with f0.35 for the grid's f0.50. rescore_all.sh refused it (exit 2)
    before touching anything.
  - I then edited that scratch copy of rescore_all.sh (a long-line wrap) while it ran. Bash reads a running script
    as it goes, so after the 36 evals (36 ok) it hit "line 225: unexpected EOF" and exited 2 before its check step.
    CLAUDE.md forbids editing a running script in place; this was my error, not a script defect. The evals had
    finished, so I ran the skipped check separately: the same embedded Python, extracted, with the rescore's start
    time. "checked 36 run(s): 0 differ; eval_run.py 3fb7a8c3, eval_ltrmix.py 9de7eab6, evalib.py f9f61a20,
    make_grid.py 5c6a541b, RULES.md 4111826d".
  - The final rescore_all.sh was then run end to end, untouched while it ran: `--names f0.02_Ta50_r2 --jobs 1` with
    the tables step, in scratch. Exit 0, rescore.done, summarize "ok/ok 36", ltrmix_absent.tsv and pa_readings.tsv
    written, 57 s.
- **Comparison with the grid's own eval files** (`$SCR/probe/compare_fix.py`; volatile: created, elapsed_s, run_dir,
  the two scripts' sha256s, inputs.eval.json, design.source, which embeds eval_run.py's sha256):
```
34 run(s) identical apart from the volatile fields (and score/ byte-identical)
f0.02_Ta50_r1 eval.json: 99 differing path(s), 0 outside the accuracy fields
f0.02_Ta50_r1 eval_ltrmix.json: 0 differing path(s)                       # LTRmix's wrong recipient: NA before and after
f0.02_Ta50_r2 eval.json: 90 differing path(s), 0 outside the accuracy fields
f0.02_Ta50_r2 eval_ltrmix.json: 34 differing path(s), 0 outside the accuracy fields (incl. n_tracts_q05_file)
```
  ("the accuracy fields": models.<m>.accuracy, head_to_head.paint.accuracy, LTRmix's
  head_to_head.paint.<mode>.{accuracy, n_tracts_q05_file}, and their entries in the na map. The 72 score files of
  every run are byte-identical.)
- **The two empty-truth runs, as rescored.**
  - f0.02_Ta50_r1: each of the four LTRpav models has tract_fdr_q05 {n_false 0, n_called 0, fdr NA}, with recall NA
    for the empty truth. LTRpav's head-to-head infers B1, so its accuracy is NA (empty truth) and wrong_recipient
    is 1. LTRmix also infers B1: accuracy NA, wrong_recipient 1.
  - f0.02_Ta50_r2: the same four models. LTRpav's head-to-head infers A1: an accuracy block with the FDR (0 of 0).
    LTRmix infers A1: blocks with the FDR (0 of 0) and n_tracts_q05_file 0 in both modes.
- **Rule 5 on the fixed code.** summarize.py is the unchanged scratch copy, reading the 36 mirrored runs:
  `$SCR/fix/tables_mirror/bars.tsv`; `$SCR/probe/repro_rule5_fdr_decided.py`, which prints "decided" instead of
  the verdict.
```
summarize.py: 144 grid runs; LTRpav/LTRmix status: absent/absent 108, ok/ok 36
  f0.02_Ta50_r1: models.any.accuracy.tract_fdr_q05 = {'n_false': 0, 'n_called': 0, 'fdr': None}; bp_recall NA (pulse into A1 but no tract survived ...)
  f0.02_Ta50_r2: (same)
any: pooled tract FDR at q <= 0.05: NA (no tract at q <= 0.05 in the C>A power runs: the FDR is undefined); n_required 36, n 36, n_missing 0, n_na 0
decoy: pooled tract FDR at q <= 0.05: NA (no tract at q <= 0.05 in the C>A power runs: the FDR is undefined); n_required 36, n 36, n_missing 0, n_na 0
anydecoy: pooled tract FDR at q <= 0.05: decided; n_required 36, n 36, n_missing 0, n_na 0
```
  - The bar now reads all 36 C>A power runs (n_na 0) for every variant, and anydecoy's is decided.
  - `any` and `decoy` call no q <= 0.05 tract in any of the 36 runs. Runs with such a tract: main 1, any 0, decoy 0,
    anydecoy 1. So their pooled FDR is 0 / 0, and summarize reports its own documented NA, "the FDR is undefined".
  - The old "34 of 36" NA had masked this second reason. It is a property of the data, final with the 36 runs, not a
    scoring defect (concern 1).
- **repro_uncond_recall.py on the fixed code** (defect 2):
```
A1 true fraction 0.0
LTRpav: wrong_recipient 1; head_to_head.paint.accuracy = NA (pulse into A1 but no tract survived in A1 (tracts.A1.bed empty))
LTRmix: wrong_recipient 1; head_to_head.paint.ancestry.accuracy = NA (pulse into A1 but no tract survived in A1 (tracts.A1.bed empty))
  tract_rows: LTRpav (roles): n_wrong_recipient = 1 (n 1)
  tract_rows: LTRpav (roles): bp_recall_all_uncond_mean = None (n 0)
  tract_rows: LTRmix ancestry: n_wrong_recipient = 1 (n 1)
  tract_rows: LTRmix ancestry: bp_recall_all_uncond_mean = None (n 0)
```
- **Side effect on tracts.tsv** (the f0.02_Ta50 group, before and after).
  - LTRpav (roles) unconditional recall goes from 0 (n 1) to NA (n 0): the fix.
  - The empty-truth runs whose recipient is right now count in `n_scored`: +1 for LTRpav roles and both LTRmix modes
    (r2), +2 for each A1-fixed model. They also count in the run column `n` of the pooled bp rows.
  - Every pooled value is unchanged, since those runs add 0 to every bp sum and 0 of 0 to the FDR. In the larger
    groups ("power (all)", "C>A (all)") the same holds; only LTRpav's unconditional mean loses the spurious zero.

### LTRmix's absent calls and both tools' readings, recomputed with the rulings (finished null and power runs)
```bash
python sim/ltrmix_absent.py --runs sim/runs --grid sim/grid.tsv --lq sim/lq --kinds null,power \
  -o $SCR/absent/fix_null_power.tsv --pa $SCR/absent/fix_null_power_pa.tsv     # scratch copy before the install; 62 s
# 66 grid run(s) finished and scored by eval_ltrmix; 78 another kind; 1 LTRquest run(s)
# lq/null_s101: not attributed: coordinate-joined libraries (A1, B1, C1)
```
Causes, by the library first (fractions of truth-present calls):

| | null_s101 | f0.18_Ta5000_r1 | pooled null (30) | pooled power (36) | **pooled null + power (66)** |
|---|---|---|---|---|---|
| truth-present absent calls | 18,973 | 18,673 | 569,783 | 690,494 | 1,260,277 |
| c orthology miss (in y's library) | 13,757 (0.725) | 13,820 (0.740) | 414,368 (0.727) | 505,658 (0.732) | **920,026 (0.730)** |
| of which S or T copies / paired elsewhere | 1,116 / 96 | 1,007 / 113 | 29,875 / 2,935 | 36,397 / 3,554 | 66,272 / 6,489 |
| a S or T, not annotated | 1,910 (0.101) | 1,755 (0.094) | 58,202 (0.102) | 67,619 (0.098) | **125,821 (0.100)** |
| b annotation dropout (P) | 3,306 (0.174) | 3,098 (0.166) | 97,213 (0.171) | 117,217 (0.170) | **214,430 (0.170)** |
| d other | 0 | 0 | 0 | 0 | 0 |
| reconciled with eval_ltrmix.json | yes | yes | yes | yes | yes |

The old cause a split cleanly: a_old 3,026 = 1,910 (not annotated) + 1,116 (in the library, now c) in null_s101, and
192,093 = 125,821 + 66,272 pooled. The finished LTRquest run lq/null_s101 is listed as "not attributed:
coordinate-joined libraries (A1, B1, C1)", with NA counts and no share in the pools.

**Presence/absence on one truth** (pooled over the 66 runs: 4,560,768 scored items per tool, identical truth pair by
pair; binary excludes 130,670 truth-G items). Each cell is precision / recall:

| tool | tier set | binary present | binary absent | strict_E present | strict_E absent |
|---|---|---|---|---|---|
| LTRmix | all | 0.99963 / 0.4923 | 0.6044 / 0.9942 | 0.9491 / 0.4923 | 0.3820 / 0.9945 |
| LTRpav | all | 0.99966 / 0.9708 | 0.99992 / 0.9354 | 0.99964 / 0.9708 | 0.99655 / 0.8722 |
| LTRpav | high | 0.99994 / 0.8485 | 0.99995 / 0.6972 | 0.99994 / 0.8485 | 0.99670 / 0.8477 |

- The strict_E rows equal eval_ltrmix.json's own counts for both tools, run by run (enforced).
- In null_s101, LTRmix's binary absent call: tp 29,615 = E 18,769 + D 8,823 + O 2,023; fp 18,973 = the
  truth-present absent calls.
- Per run and per tier set the table is `$SCR/absent/fix_null_power_pa.tsv`, and rescore_all.sh writes it to
  `sim/tables/pa_readings.tsv`. These are tables, not findings (the analysis is Plan 4).

### Install and tests in place
- **The install.** `$SCR/fix/install.sh` refuses if a live file changed since it was copied, then writes each file
  beside its target and moves it over. It ran at 09:39:07. The grid runners kept going; runs they finish after
  that are scored by the new scripts.
- **One test failed in place:** `test_grid_discovery_and_kinds`. The new `--lq` default (sim/lq) found the real
  finished lq/null_s101; scratch had no lq/, so it had passed there. The test now passes its own empty `--lq`, and
  was reinstalled the same way at 09:39:53.
- **Then:**
```bash
cd $P/benchmark_pav/plan3 && . common/env.sh
python -W error -m pytest -q -p no:cacheprovider sim/test_eval_run.py sim/test_eval_ltrmix.py sim/test_ltrmix_absent.py \
  sim/test_summarize.py sim/test_gff3_to_ltrmix.py common/test_evalib.py
# 63 passed (eval_run 5, eval_ltrmix 7, ltrmix_absent 13, summarize 25, gff3_to_ltrmix 4, evalib 9)
sim/rescore_all.sh --dry-run    # settings: --jobs 4; 113 runs with run.done of 147; writes nothing (no sim/rescore)
```
- **Live check.** The first grid run scored after the install, runs/bn_null_s24 (09:4x), records eval_run.py
  3fb7a8c3 and eval_ltrmix.py 9de7eab6, with run.exit 0. The installed scripts work in the running grid.
- **sha256** (old -> new):

| file | old | new |
|---|---|---|
| sim/eval_run.py | 6fbe0794b2cfa784949931aef0298f7e8f15aeadb9cbc1957210038b46a2a367 | 3fb7a8c3900dcc6d8ac6a9acbd1f9c52dc75a73117ccd591c51ad2be2dff85c5 |
| sim/eval_ltrmix.py | 3287f3d0b54871f63dca3bcdfb217827aea4a6796c703ca860a0462ad6fbf285 | 9de7eab6ad730ef887eeda37777f1f11c0201b7a3a06598ab410133b7508bb43 |
| sim/ltrmix_absent.py | 15001213ef53b2bf22292f8d4c4c440d9968cbb1d8d4daf84deacbc5069126a1 | 416f0ed9eafc2f72dd8cd4e5b11bab31dd45d55f028d63c3164e498019e5e9c5 |
| sim/rescore_all.sh | 7f514be2a06433a6b72990b276469c67e6e09f74ff3abfb869a9fc5cde21d80e | ec60c3c706add9eecb8a70d802b61c6709dcdc0b4f01354966dd72a0f4812bd3 |
| sim/test_eval_run.py | (new) | 855751defbd16d7a730703d7f2769886cd2478761d6da092cd81af92f89fa4ef |
| sim/test_eval_ltrmix.py | 3b449b85de3b15e17df0f0a97e0a426da7cb74982f44808a3cfd68de4e554ab4 | 37ff2a769da1c50a8fdd2a9f6b19028796e2f56f4bb625f25c563024d307fc32 |
| sim/test_ltrmix_absent.py | 8268dd3b1dcfc79d1506eebde61abb8325c80a3aeb596b55f4648ae76676aa00 | 83fa82ee6ac4de4e3f63614ca55bf99419f9498f707612ba1b613b3e2caacc4c |

  Unchanged: summarize.py c0c9dd3a, common/evalib.py f9f61a20, RULES.md 4111826d, make_grid.py 5c6a541b,
  run_one.sh e4136cd6, run_grid.sh 03d3a03d, common/env.sh 5728e569, lq/run_lq.sh 146d7bb9.
- **sim/memo.md.** I appended "## Scoring fixes after the Part P smoke test" (dated 2026-11-14): each change with its
  one-line reason, and old and new sha256s. It also records the install time, the consequence (older eval files are
  stale until the full rescore), the scratch validation, and a correction of the Task 9 gotcha ("62% truth-present"
  is 62% not-E).

### Files written in fix round 1
- **sim/ (installed):** eval_run.py, eval_ltrmix.py, ltrmix_absent.py, rescore_all.sh, test_eval_ltrmix.py,
  test_ltrmix_absent.py, test_eval_run.py (new). sim/memo.md: one appended entry.
- **This report:** this section.
- **Scratch:** `$SCR/fix/` (the development copy and its orig/; the 36 mirrored runs with their rescored eval/;
  rescore_log/, rescore_final/, tables_mirror/; install.sh, post_rescore.sh, memo_entry*.md), `$SCR/mut/`
  (mutate2.py, mutate3.py and their work dirs), `$SCR/probe/` (compare_fix.py, compare_fix_paths.py,
  repro_rule5_fdr_decided.py, same_truth.py), `$SCR/absent/fix_null_power{,_pa}.tsv`.
- No run was rescored in place, no repo file was touched, and nothing was killed.

### Concerns after fix round 1
1. **Rule 5 for `any` and `decoy`.** Their pooled FDR now reads all 36 runs, but it is 0 / 0: neither variant calls
   a q <= 0.05 tract in any C>A power run. summarize reports NA ("the FDR is undefined"), so their rule 5 cannot be
   decided by the FDR clause as written. Only anydecoy's FDR bar is decided. This needs a reading before Step 2.
   For example: is a variant with no q <= 0.05 tract at all simply not adoptable? RULES.md is not mine to change.
2. **Older eval files are stale.** Every eval file written before 09:39:07 records the old eval_run.py and
   eval_ltrmix.py sha256s, so summarize marks those runs stale until the full rescore. That rescore is planned anyway
   (rescore_all.sh after the grid; about 15 min at `--jobs 4`). Tables made before it read only runs finished after
   the install.
3. **tracts.tsv counts.** "n_scored" and the run counts of the pooled bp rows now include empty-truth runs with a
   right recipient. The values are unchanged; only the counts move.
4. **My mid-run edit of a scratch script.** It cost one check step, rerun separately and then re-proved end to end.
   No real file was affected.

## Fix round 2 (2026-11-14, ruling "rule 5 with no calls")

**Ruling applied.** Rule 5's pooled FDR with no q <= 0.05 tract over the C>A power runs is 0/0, whose Clopper-Pearson
upper bound is 1 > 0.10, so the bar reads FAIL with the reason, never NA. The decoy clause reads the same bar, so it
fails too. A bar with a run genuinely missing still reads NA.

**Test first** (scratch copy of sim/, as in round 1): `test_summarize.py::test_rule5_fdr_with_no_calls`, on the
existing `adoption_world` fixture (all 144 grid rows, synthetic eval files).
- **Setup:** `any` and `decoy` have 0 calls in all 36 C>A power runs; `main` and `anydecoy` have 10 calls with none
  false. The default fails rule 4, which puts the decoy clause in play.
- **Expected:**
  - any and decoy read FAIL, count 0, n 36, n_na 0, interval [0, 1], with the reason "no q <= 0.05 tract in any of
    the 36 C>A power runs: realized FDR 0/0, Clopper-Pearson upper bound 1 > 0.10";
  - the matching variants.tsv rows say the same;
  - decoy holds the null, but the adoption bar's reason reads "default-fails clause FAIL" and its verdict
    "default (main)";
  - anydecoy is unchanged ("0 of 360 tracts false", PASS);
  - with one run missing (`skip_pav`) the bar is NA ("n runs < required ...").
- **Red:** `assert ('NA', 0, 36, 0, 0) == ('FAIL', 0, 36, 0, 0)`; 1 failed.

**Implementation** (summarize.py `rule5`, plus a docstring line on the reading): the `elif not kc` branch, which runs
only when no run is missing or NA, now sets `lo, hi = 0.0, 1.0`, `fdr_ok = False` and the reason above. `nc.short`
(missing or NA runs) is still checked first. Green: test_summarize.py 26 passed.

**Mutants** (`$SCR/mut/r2`): all three fail the new test.
- no-calls checked before missing runs, which would turn an incomplete bar into FAIL;
- verdict left None;
- interval left NA.

**Scratch summarize on the finished runs.** The 36 C>A power runs, rescored in fix round 1 with the fixed eval
scripts (`$SCR/fix/sim/runs`), summarized by the new scratch summarize.py:
```bash
cd $SCR/fix && python sim/summarize.py --runs $SCR/fix/sim/runs --grid $SCR/fix/sim/grid.tsv --out $SCR/fix/tables_mirror_r2
# summarize.py: 144 grid runs; LTRpav/LTRmix status: absent/absent 108, ok/ok 36
any: verdict FAIL; n_required 36, n 36, n_missing 0, n_na 0, count 0, ci [0, 1]; reason: no q <= 0.05 tract in any of the 36 C>A power runs: realized FDR 0/0, Clopper-Pearson upper bound 1 > 0.10
decoy: verdict FAIL; (same)
anydecoy: row identical to before the change: True (n 36 of 36, decided)
```
Against fix round 1's mirror tables, exactly 3 of 56 bars.tsv rows changed (the any and decoy FDR rows, and the
adoption row computed from them), and 4 of 64 variants.tsv rows (those plus any's "all four hold"). Their other
verdicts are not reported here.

**Install and tests.**
- summarize.py and test_summarize.py were installed at 09:47:20, refusing if the live file had changed (it had not)
  and moved over atomically.
- In place, `python -W error -m pytest -q -p no:cacheprovider sim/test_eval_run.py sim/test_eval_ltrmix.py
  sim/test_ltrmix_absent.py sim/test_summarize.py sim/test_gff3_to_ltrmix.py common/test_evalib.py`: 64 passed (eval_run
  5, eval_ltrmix 7, ltrmix_absent 13, summarize 26, gff3_to_ltrmix 4, evalib 9).
- summarize.py c0c9dd3ab598c034ebed4f895acf06a679bab3ef1ed1af0e9c77cbbe48a944bb ->
  c4a2b30d8e812fe364b8ab672818ce2ff86e5656ec24826a017d4f5a44c0513c.
- test_summarize.py 1768cc3b81cb0d0eaaab64ae414d470c1f365aab03006e35c9826f662002325a ->
  a8c55b94e96884f800499da8ec48c7636937841f53ccbd9080851ea664105bc9.

**sim/memo.md.** My "Scoring fixes after the Part P smoke test" entry now lists summarize.py's change (reason: the bar
asks for evidence of FDR control, and 0 of 0 calls gives none), its old and new sha256s, test_summarize.py's, and the
round-2 validation, and the test count is 64. The previous version is kept in scratch
(`$SCR/fix/memo.md.before_r2`).

### Review package
`LTRpav/.superpowers/sdd/2026-11-12-plan3-benchmark/task-11p-review-package.diff` (1,632 lines; built by
`$SCR/fix/build_package.sh`).
- **Header:** every file created or changed in Part P with its old and new sha256s, the run data rescored in place
  (not in the package), and the unchanged protected files.
- **Changed existing files:** `diff -u` from the pre-Part-P version to the current one, for eval_run.py,
  eval_ltrmix.py, summarize.py, test_eval_ltrmix.py, test_summarize.py and memo.md.
- **New files, full text** as diffs from /dev/null: rescore_all.sh, ltrmix_absent.py, test_ltrmix_absent.py,
  test_eval_run.py.
- **Base:** my scratch copies taken with `cp -p` at the start of fix round 1, before any edit (`$SCR/fix/sim/orig/`).
  Part P itself changed no existing script. Each base equals the sha256 sim/memo.md records for the scored scripts
  (Task 9 section): 6fbe0794, 3287f3d0, c0c9dd3a, 3b449b85, 1768cc3b, all matching. memo.md has no recorded sha256,
  so its base is reconstructed (the current file without my entry), as the header says.
- **Proof of completeness:** the package, applied with `patch -p1` to the base files, reproduces all 10 live files
  byte for byte (sha256 compared; the build fails otherwise).

### Files written in fix round 2
- **sim/:** summarize.py, test_summarize.py (installed). sim/memo.md: my entry edited.
- **Reports:** task-11p-review-package.diff (new) and this section.
- **Scratch:** `$SCR/fix/` (summarize copies, `orig/*.r2`, `tables_mirror_r2/`, `memo.md.before_r2`,
  `memo.pre_part_p.md`, `build_package.sh`), `$SCR/mut/r2/`, `$SCR/pkgcheck/`.
- No run was rescored in place, no repo file was touched, and nothing was killed.

### Concerns after fix round 2
1. **Stale eval files (unchanged from round 1).** The finished runs' eval files written before 09:39 record the old
   eval_run.py and eval_ltrmix.py sha256s, so summarize reads them as stale until Step 1's full rescore
   (rescore_all.sh `--jobs 4`, detached, after the grid). summarize.py's own change needs no rescore, since it
   reads the eval files.
2. **Rule 5's no-calls reading is now final for any and decoy on these 36 runs.** Their sign tests also have no usable
   pair, and only anydecoy's FDR rests on calls (1 run with a q <= 0.05 tract).

## Minors round (2026-11-14 10:12-10:27; review m2, m4-m8; ledger "Ruling (Part P minors ...)")

**Base.** The live files equalled the versions the review saw: all 10 sha256s matched task-11p-review-package.diff. I
snapshotted them (`$SCR/fix/reviewed/`) and developed in the scratch copy of sim/ as before.

**m2: record what is defined with an empty A1 truth, in both tools** (eval_run.py `empty_truth_accuracy`,
eval_ltrmix.py `paint_mode`).
- **Recorded per tag (any q, q <= 0.05):** n_called; bp_called (the merged bp of the called tracts); bp_true_positive
  0; bp_precision = 0 / bp_called (0.0 with any call, NA "no called tract (...)" without); precision_by_length (evalib
  with the empty truth, 0 in every bin that holds a call).
- **Still NA, with the empty-truth reason:** AUROC, bp_recall, recall_by_length, recall_by_loci and true_tracts, which
  need a true tract. The tract FDR is as before.
- **The keys equal the normal block's.** Docstrings updated in both scripts.
- **Red first:** test_eval_run.py's two empty-truth tests and test_eval_ltrmix.py's empty-truth test now expect these
  values, by hand: eval_run 15,000 / 5,000 called bp; eval_ltrmix ancestry 1,500 and 1,500, recent 3,000 and 0. All
  failed before the fix (`4 failed, 10 passed`, counting the m7(a) test, which also asserts the m2 fields), and pass
  after it.

**m4.** summarize.py `rule5` checks `nc.n_required == 0` first: NA "no C>A power run in the grid", never FAIL.
- Red first: `test_rule5_fdr_with_no_power_runs` (30 nulls, no power run) read FAIL "in any of the 0 C>A power runs"
  for all three variants. It is 1 failed before the fix and passes after.
- A probe on the reviewed code confirmed the FAIL first.

**m5 and m6** (rescore_all.sh), tested in a new `sim/test_rescore_all.py`. It uses a synthetic sim/: the script
copied beside a link to common/, a 2-row grid, and stub scoring scripts whose eval files pass the script's own sha256
check. No real run is read.
- **m5:** `need_value` makes a missing or empty value of --jobs, --names, --logdir or --tables exit 2 with the usage
  text. An empty `--names ""` can no longer start a full rescore.
- **m6:** `--names` turns the tables step off with one note: "--names restricts the set, so the tables step
  (summarize.py, then ltrmix_absent.py) is skipped: it runs only on a full rescore". It appears in the dry-run output
  and in rescore.log. A full rescore still runs both.
- **Red first:** against the reviewed script, 7 failed and 1 passed (the full-rescore test, which shows the stubs
  work); 8 passed after the fix.
- **One test edit.** My first dry-run assertion was too broad, since the note itself names summarize.py; it now checks
  the command forms. It still fails 7 of 8 on the reviewed script.

**m7 (coverage) and m8.**
- (a) `test_eval_ltrmix.py::test_empty_truth_without_elements_file`: the tract FDR and the called bp are recorded,
  while AUROC and n_elements carry "elements.A1.tsv missing ...".
- (b) `test_eval_run.py::test_empty_truth_sheet_order_recipient_is_na`: R = A1 by sheet order gives wrong_recipient
  1, inferred_recipient NA, and accuracy NA (empty truth).
- (c) The no-calls test now also has a run present but NA: "n runs < required: 35 of 36 usable; 1 NA (...)".
- m8: the blank line before `test_rule6_decided_with_missing_runs`. ruff with the blank-line rules passes, and
  `ruff check --preview --select E,F,W --line-length 120` finds nothing beyond the reviewed versions' own counts (test
  file 3 -> 2).

**Real-data check of m2** (scratch mirror; no run rescored in place). The final scratch rescore_all.sh rescored
f0.02_Ta50_r1, f0.02_Ta50_r2 and f0.50_Ta500_r2, which also exercises m6 on real runs:
```
2026-11-14 10:22:27 rescore_all.sh: --names restricts the set, so the tables step (summarize.py, then ltrmix_absent.py) is skipped: it runs only on a full rescore
2026-11-14 10:23:06 rescore_all.sh: evals: 3 ok, 0 failed (39 s)
2026-11-14 10:23:06 rescore_all.sh: check: checked 3 run(s): 0 differ; scripts on disk: eval_run.py 3dd0ca38, eval_ltrmix.py af75cbad, ...
```
Compared with the same runs' fix-round-2 eval files (volatile fields excepted):
```
f0.50_Ta500_r2 eval.json: 0 differing path(s); eval_ltrmix.json: 0; score/ 72 files byte-identical
f0.02_Ta50_r1 eval.json: 84 path(s), only bp_called, bp_true_positive, bp_precision, precision_by_length and their na entries; eval_ltrmix.json: 0 (LTRmix's wrong recipient: NA)
f0.02_Ta50_r2 eval.json: 100 path(s), same fields; eval_ltrmix.json: 42 path(s), same fields
f0.02_Ta50_r2 LTRpav main: all bp_called 9702556, bp_true_positive 0, bp_precision 0.0; q05 bp_called 0, bp_precision NA (no called tract (q <= 0.05)); bp_recall NA (pulse into A1 but no tract survived ...)
f0.02_Ta50_r2 LTRmix ancestry: all bp_called 17097432, bp_precision 0.0; q05 bp_called 0
```
**How summarize pools bp precision, and the effect.** tract_rows sums bp_true_positive and bp_called over the scored
runs: wrong_recipient 0 in the head-to-head, every accuracy block for the A1-fixed models. Treating a missing value as
0, it divides the sums, and it averages the per-run bp_precision "over runs with a called tract". Before m2 the
empty-truth runs added nothing; now they add their called bp, all false. Computed with summarize's own `tract_rows`
over the 36 C>A power runs, with the two runs' eval files before and after (`$SCR/probe/m2_pooling.py`):
```
LTRpav (roles)          bp_precision_all_pooled 0.288742 -> 0.282765  [132533167 / 459002463 bp -> 132533167 / 468705019 bp]
LTRmix ancestry         bp_precision_all_pooled 0.473632 -> 0.460703  [288552132 / 609232575 bp -> 288552132 / 626330007 bp]
LTRmix recent           bp_precision_all_pooled 0.523716 -> 0.522936  [295796371 / 564802806 bp -> 295796371 / 565645386 bp]
LTRpav main (A1 fixed)  bp_precision_all_pooled 0.486644 -> 0.469394  [220706373 / 453527112 bp -> 220706373 / 470194417 bp]
(same for any, decoy, anydecoy; every q05 pool is unchanged, since those runs call nothing at q <= 0.05; the per-run means
 now count the runs' 0, e.g. LTRpav main all-q mean n 34 -> 36)
```
The true-positive bp are unchanged and the called bp grow by exactly those runs' false bp, for every tool alike. No bar
reads these pools (rule 5 reads q <= 0.05 tracts, and those runs have none).

**Install and tests.**
- Installed at 10:24:02, refusing if a live file had changed since the review (none had), each file written beside
  its target and moved over it: eval_run.py, eval_ltrmix.py, summarize.py, rescore_all.sh, test_eval_run.py,
  test_eval_ltrmix.py, test_summarize.py and the new test_rescore_all.py. ltrmix_absent.py and its test are unchanged.
- In place:
```bash
python -W error -m pytest -q -p no:cacheprovider sim/test_eval_run.py sim/test_eval_ltrmix.py sim/test_ltrmix_absent.py \
  sim/test_summarize.py sim/test_rescore_all.py sim/test_gff3_to_ltrmix.py common/test_evalib.py
# 75 passed (eval_run 6, eval_ltrmix 8, ltrmix_absent 13, summarize 27, rescore_all 8, gff3_to_ltrmix 4, evalib 9)
sim/rescore_all.sh --dry-run --jobs        # "--jobs needs a value", usage, exit 2
sim/rescore_all.sh --dry-run --names null_s101   # prints the tables note; no sim/rescore created
```
- No grid run had reached its eval step between the install and 10:25. The installed eval scripts are byte-identical
  to those of the scratch rescore above (same sha256s).

**sha256** (reviewed -> new):

| file | reviewed | new |
|---|---|---|
| sim/eval_run.py | 3fb7a8c3900dcc6d8ac6a9acbd1f9c52dc75a73117ccd591c51ad2be2dff85c5 | 3dd0ca38238c5ba775957ea2a90dc95176b43dcbc2e19def3d0f71be891c6316 |
| sim/eval_ltrmix.py | 9de7eab6ad730ef887eeda37777f1f11c0201b7a3a06598ab410133b7508bb43 | af75cbad848f7289a3ffb825a44fda26a2cecbfe2006c27038eb3a2e9f00dad2 |
| sim/summarize.py | c4a2b30d8e812fe364b8ab672818ce2ff86e5656ec24826a017d4f5a44c0513c | a2636db2487bf09df90043a93f7e5d5d0c6ecc9444d7f74676ebd556bb088a0d |
| sim/rescore_all.sh | ec60c3c706add9eecb8a70d802b61c6709dcdc0b4f01354966dd72a0f4812bd3 | 6a33ebd7b01b3ec8862b3ae7af64123392cc3b6f95c874ea953ec3c7d48eba99 |
| sim/test_eval_run.py | 855751defbd16d7a730703d7f2769886cd2478761d6da092cd81af92f89fa4ef | 7764fc5603136d32bcebb01fa3c1dff47aa4ede291009cdf3a20eef1788c9337 |
| sim/test_eval_ltrmix.py | 37ff2a769da1c50a8fdd2a9f6b19028796e2f56f4bb625f25c563024d307fc32 | eb7c3f07535e24d36bc72a0702d7895931c758c03a5d2b12841e0869a18ea3bb |
| sim/test_summarize.py | a8c55b94e96884f800499da8ec48c7636937841f53ccbd9080851ea664105bc9 | adaf3dab18b6188ef0596438533a1cdb6c74d0b707bf2f09e32856070dc160f8 |
| sim/test_rescore_all.py | (new) | b6e98a10c31b84c8337e06e6c29f4a3466dbd1f7e3c7bb327aa8dcd4984fe2ed |
| sim/memo.md | 609dc74a2b798500a0b03fdccb59bf9462673a69dfa22a4971a6813c6c83fb99 | 4b7920b470e8249c0e65657b093102168210ecdeefa76facb2a78fb14561df69 |

Unchanged: ltrmix_absent.py 416f0ed9, test_ltrmix_absent.py 83fa82ee. Protected files unchanged: RULES.md 4111826d,
evalib.py f9f61a20, make_grid.py 5c6a541b, run_one.sh e4136cd6, run_grid.sh 03d3a03d, env.sh 5728e569, run_lq.sh
146d7bb9.

**sim/memo.md.** My entry now records, per file, the minors-round sha256s with a one-line reason per change:
- m2: record what is defined, NA only a ratio that needs a true tract;
- m4: an empty set is no evidence either way;
- m5: usage errors exit 2, as documented;
- m6: tables come only from a full rescore.

It also records the new tests, the install time, the real-data check and the 75-test command. The previous version is
`$SCR/fix/memo.md.before_minors`.

**Delta package.** `task-11p-review-package-2.diff` (532 lines; `$SCR/fix/build_package2.sh`) holds `diff -u` from the
reviewed versions to the current ones for the 8 changed files, plus test_rescore_all.py in full, with a header of
reviewed and new sha256s. Its base was checked against task-11p-review-package.diff's header, and the package applied
to that base reproduces all 9 live files byte for byte.

**Files written in the minors round:**
- sim/: eval_run.py, eval_ltrmix.py, summarize.py, rescore_all.sh, test_eval_run.py, test_eval_ltrmix.py,
  test_summarize.py, and test_rescore_all.py (new); sim/memo.md (my entry);
- task-11p-review-package-2.diff and this section;
- scratch: `$SCR/fix/` (reviewed/, m2_before/, rescore_m2/, redcheck/, build_package2.sh) and `$SCR/probe/m2_pooling.py`.

No run was rescored in place, nothing in the repo was touched, and nothing was killed.

**Concern.** Every eval file written before 10:24:02 was made by an earlier eval_run.py or eval_ltrmix.py, so
summarize reads it as stale until Step 1's full rescore. That rescore must use these final scripts:
`sim/rescore_all.sh --jobs 4`, detached, after the grid ends.
