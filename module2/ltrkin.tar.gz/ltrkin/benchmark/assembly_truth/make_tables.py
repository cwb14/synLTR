#!/usr/bin/env python3
"""Markdown tables for docs/benchmark_v0.2.md from the evaluation summaries (confirmed truth unless stated).
usage: make_tables.py [version tag, default v02] > tables.md"""
import os
import sys

import pandas as pd

V = sys.argv[1] if len(sys.argv) > 1 else "v02"
TOOLS = ["v01", V, "sniffles", "kanpig"]
NAME = {"v01": "v0.1", V: "v0.2", "sniffles": "Sniffles2", "kanpig": "kanpig"}


def load(S, ref, kind):
    p = f"{S}/eval/{ref}.{kind}.summary.tsv"
    if not os.path.exists(p):
        return None
    m = pd.read_csv(p, sep="\t")
    if kind == "diploid":
        m["depth"] = m.cond.str.extract(r"d(\d+)_").astype(int)
    return m


def conc_table(S):
    out = [f"### {S}: concordance on confirmed truth, % (mean of seeds; hap1 reference / hap2 reference)", "",
           "| depth | " + " | ".join(NAME[t] for t in TOOLS) + " | n sites |", "|---" * (len(TOOLS) + 2) + "|"]
    tabs = {}
    for ref in ("hap1", "hap2"):
        m = load(S, ref, "diploid")
        if m is None:
            continue
        x = m[(m.stratum == "truth_source") & (m.level == "confirmed") & (m.scope == "all")]
        tabs[ref] = (x.groupby(["depth", "tool"]).concordance.mean().unstack(), x.groupby("depth").n.first())
    if not tabs:
        return []
    depths = sorted(set().union(*[set(t[0].index) for t in tabs.values()]))
    for d in depths:
        cells = []
        for t in TOOLS:
            vals = [f"{100 * tabs[r][0].loc[d, t]:.1f}" if r in tabs and d in tabs[r][0].index and t in tabs[r][0]
                    else "-" for r in ("hap1", "hap2")]
            cells.append(" / ".join(vals))
        n = " / ".join(str(int(tabs[r][1].loc[d])) if r in tabs and d in tabs[r][1].index else "-" for r in ("hap1", "hap2"))
        out.append(f"| {d}x | " + " | ".join(cells) + f" | {n} |")
    return out + [""]


def class_table(S, depth):
    out = [f"### {S}: per class at {depth}x (hap1 / hap2 reference)", "",
           "| tool | F/F recall | F/E recall | empty precision | F/S recall | F/N recall | GQ >= 20 correct | GQ >= 20 call rate |",
           "|---|---|---|---|---|---|---|---|"]
    rows = {}
    for ref in ("hap1", "hap2"):
        m = load(S, ref, "diploid")
        if m is None:
            continue
        x = m[(m.stratum == "truth_source") & (m.level == "confirmed") & (m.scope == "all") & (m.depth == depth)]
        rows[ref] = x.groupby("tool").mean(numeric_only=True)
    for t in TOOLS:
        cells = []
        for col in ("recall_F/F", "recall_F/E", "E_precision", "recall_F/S", "recall_F/N", "conc_gq20", "call_rate_gq20"):
            vals = [f"{rows[r].loc[t, col]:.3f}" if r in rows and t in rows[r].index else "-" for r in ("hap1", "hap2")]
            cells.append(" / ".join(vals))
        out.append(f"| {NAME[t]} | " + " | ".join(cells) + " |")
    return out + [""]


def all_truth(S, depth):
    vals = []
    for ref in ("hap1", "hap2"):
        m = load(S, ref, "diploid")
        if m is None:
            continue
        y = m[(m.stratum == "all") & (m.scope == "all") & (m.depth == depth)].groupby("tool").concordance.mean()
        vals.append(f"{ref}: " + ", ".join(f"{NAME[t]} {100 * y[t]:.1f}" for t in TOOLS if t in y))
    return [f"All scored truth at {depth}x (incl. alignment-only and junction-rescued sites): " + "; ".join(vals), ""]


def haploid(S):
    out = [f"### {S}: presence/absence with the other haplotype's reads only (confirmed truth)", "",
           "| depth per haplotype | model | concordance | decided calls correct | absent recall | absent precision | present recall | present precision | solo recall |",
           "|---|---|---|---|---|---|---|---|---|"]
    for ref in ("hap1", "hap2"):
        h = load(S, ref, "haploid")
        if h is None:
            continue
        x = h[(h.stratum == "truth_source") & (h.level == "confirmed") & h.tool.str.startswith(V)]
        for r in x.itertuples():
            out.append(f"| {r.cond[1:]}x ({ref}) | ploidy {r.tool[-1]} | {r.pav_conc:.3f} | {r.pav_conc_decided:.3f} | "
                       f"{r.absent_recall:.3f} | {r.absent_precision:.3f} | {r.present_recall:.3f} | "
                       f"{r.present_precision:.3f} | {r.solo_recall:.3f} |")
    return out + [""]


lines = []
for S in ("Camara", "Mfalcata"):
    lines += conc_table(S) + class_table(S, 20) + all_truth(S, 20) + haploid(S)
print("\n".join(lines))
