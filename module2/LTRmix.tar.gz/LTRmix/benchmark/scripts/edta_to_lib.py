#!/usr/bin/env python3
"""Convert EDTA structural (intact) LTR-RT calls to an ltrmix generic library: FASTA of the LTR-to-LTR span (minus-
strand elements reverse-complemented, as LTRquest writes them) + table (seq_id, k2p from ltr_identity, tsd, strand,
ltr5_len = genome-left LTR, ltr3_len = genome-right LTR). Annotation-portability benchmark only."""
import argparse
import gzip
import math
import re


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("gff")
    ap.add_argument("genome")
    ap.add_argument("label")
    ap.add_argument("out")
    a = ap.parse_args()
    reg = {}
    with gzip.open(a.gff, "rt") as f:
        for line in f:
            if line.startswith("#"):
                continue
            p = line.rstrip("\n").split("\t")
            if len(p) < 9 or "Method=structural" not in p[8]:
                continue
            at = dict(x.split("=", 1) for x in p[8].split(";") if "=" in x)
            if not at.get("Classification", "").startswith("LTR"):
                continue
            rid = at.get("Parent") if p[2] != "repeat_region" else at.get("ID")
            if rid is None:
                continue
            r = reg.setdefault(rid, dict(chrom=p[0], ltrs=[]))
            if p[2] == "long_terminal_repeat":
                r["ltrs"].append((int(p[3]), int(p[4])))
            elif p[2].endswith("LTR_retrotransposon"):
                r.update(start=int(p[3]), end=int(p[4]), strand=p[6], ident=float(at.get("ltr_identity", "nan")),
                         tsd=at.get("tsd", ""), cls=at.get("Classification", "LTR/unknown"))
    seqs, name, buf = {}, None, []
    with open(a.genome) as f:
        for line in f:
            if line.startswith(">"):
                if name:
                    seqs[name] = "".join(buf)
                name, buf = line[1:].split()[0], []
            else:
                buf.append(line.strip())
    seqs[name] = "".join(buf)
    comp = str.maketrans("ACGTacgt", "TGCAtgca")
    n = 0
    with open(a.out + ".fa", "w") as fa, open(a.out + ".tsv", "w") as tb:
        tb.write("seq_id\tk2p\ttsd\tstrand\tltr5_len\tltr3_len\n")
        for rid, r in reg.items():
            if "start" not in r or len(r["ltrs"]) != 2:
                continue
            c = f"{a.label}_{r['chrom']}"
            if c not in seqs and f"{a.label}_chr{r['chrom']}" in seqs:   # GFF '1' vs FASTA 'chr1'
                c = f"{a.label}_chr{r['chrom']}"
            if c not in seqs:
                continue
            s = seqs[c][r["start"] - 1:r["end"]]
            if r["strand"] == "-":
                s = s.translate(comp)[::-1]
            lt = sorted(r["ltrs"])
            l5, l3 = lt[0][1] - lt[0][0] + 1, lt[1][1] - lt[1][0] + 1
            pd_ = 1 - r["ident"]
            k2p = -0.75 * math.log(1 - 4 * pd_ / 3) if 0 <= pd_ < 0.74 else float("nan")
            nm = f"{c}:{r['start']}-{r['end']}#{r['cls']}"
            fa.write(f">{nm}\n{s}\n")
            tb.write(f"{nm}\t{k2p:.6g}\t{r['tsd'] if re.fullmatch('[ACGTacgt]+', r['tsd'] or '') else '.'}\t"
                     f"{r['strand'] if r['strand'] in '+-' else '.'}\t{l5}\t{l3}\n")
            n += 1
    print(f"{a.label}: {n} structural LTR-RTs")


if __name__ == "__main__":
    main()
