# Review of the Plan 3 draft (simulation grid and real benchmark)

Reviewed 2026-11-12: `docs/plans/2026-11-12-plan3-benchmark.md` (1,313 lines, 16 tasks), its summary
`plan3-draft-summary.md` (33 calls), the brief `plan3-drafter-brief.md` (R1-R10), DESIGN.md (all), CLAUDE.md,
`benchmark_pav/main3_analyses/PRELIM.md`, the writing-plans skill, and as needed: `src/ltrpav/sim/` and the committed
analysis package (`git show HEAD:`, not the working tree the fix wave is editing), LTRmix's `ltrmix.py`,
`benchmark/scripts/{sim_ltr_admix,eval_sim,rate_free_split,edta_to_lib}.py`, the LTRmix grid and REPORT (genus 6b,
citrus 6c, six genomes), main3's memo and `qc_fixed/qc.tsv`, main3_analyses' `stats.tsv`, `inputs/`, the bake-off
REPORT and `run_variant.py`, the user's LTRquest memories.

Probes (scratch `plan3review/`, env `ltrmix` for msprime, under 16 threads and 15 min each; perfect genotypes, no
genotyping):
- `probe_outgroup.py`: the draft's demography at 10 Mb, outgroup split 120k / 300k / 600k generations, 58 backbone
  elements/Mb carried by every sample.
- `probe_dfoil.py`: DFOIL-alt pattern statistics on the 7-genome design (quartet A1, A2, C1, C2; B1, B2, O absent; the
  pattern pairs of `direction.PAIR_DISC`), for no pulse, a population-wide C>A pulse, a pulse from population C into
  A1's lineage only, and lineage-to-lineage pulses in both directions between subpopulations A1p and C1p; three
  10-Mb chromosomes pooled per condition.

## Strengths

- **Scope matches R1-R10.** Every carry-over in R2 has a home; the engine is untouched by construction (Global
  Constraints, with an engine-fingerprint check after every package commit); `ltrpav run` is kept out of the loops
  (R3); maize/citrus scoring lives in `benchmark_pav/plan3/` (R9); the snapshot rule (git archive + PYTHONPATH) keeps
  concurrent edits away from a running grid. I checked the mechanism: env `ltrpav`'s editable install is a plain
  path `.pth` (`_editable_impl_ltrpav.pth`), so PYTHONPATH wins, and the plan also asserts `ltrpav.__file__`.
- **The compute estimate is grounded.** The per-call rate (140 calls/s at 16 threads, `geno20`) matches main3's
  (~137 calls/s at 32 threads); the index build is seconds at 150 Mb (1.2 s at 27.7 Mb in the probe log); msprime at
  10 Mb took 35 s in my rerun. The 100-Mb reduction is argued from Hudson's quadratic cost, keeps all 30 nulls and
  every f and Ta, and the 96-h pilot gate with its 50-Mb fallback is written before any result.
- **The simulator design is careful where it matters.** `initially_active` for the extant ancestral populations
  (LTRmix's gotcha), haploid samples from diploid populations, tracts from migration records through ancestors, a
  one-pass builder (Plan 1's 7.8-min whole-array cost named), per-chromosome seeds independent of `--threads`, truth by
  Plan 1's rules with "inherited by Y", and a test per truth rule.
- **The adoption rules are written in the plan, before any grid row exists, and never refer to main3 or the papers**
  (rules 3-5; "Ties keep the default"). The null bar arithmetic is right (5% of 30 = 1.5, so at most 1 run), with a
  Clopper-Pearson interval.
- **Interfaces were checked against real code.** `paint(..., discovery=...)`, `classes`, `fit_hmm`, `block_size`,
  `get_route` and route `params` in the anchor key, the `paint`/`D_pav`/`D_pav_gradient`/`f4_ratio`/`dfoil`/`direction`
  /`identity_split` row names, `spacing_median`, the LTRmix CLI, LTRmix's per-trio directories, `rate_free_split.py`'s
  exit after its `s` line on generic libraries, the GFF3 loader's `tsd=` and sibling-LTR handling (so `edta_prep` may
  drop `repeat_region` lines), every input path and `.fai` (all present; `/data2` has 130 TB free).
- **The real benchmark follows DESIGN 10.4 and LTRmix exactly where it should:** the positive control is LTRmix's own
  trio {B73, PT; TIL18} (call 24 matches LTRmix REPORT line 153), the genus trios and control are LTRmix's 6b trios,
  the citrus trios and the >= 50%-coverage rule are 6c's, the 10.3 rerun is rightly re-genotyped (main3 is engine
  7d71073; f4eabba, 06c2f53 and later engine commits came after it).
- **Format.** Header, Global Constraints, a Review Focus whose five lines each name a test in the owning task, Files
  and Interfaces for every code task, test names with assertions, exact commands and values, a spec-coverage table.
  At 1.8x the spec's length it is decisions, not a transcript.

## Findings

### Critical

**C1. The direction test cannot fire in any simulated gene-flow run, so rule 5's verdict is fixed in advance and the
six-genome "simulated power" measures the wrong scenario.** (Task 8 grid; Task 9 `dfoil_direction` and rule 5; Task 11
§4; Task 13 item 4; calls 10, 18.)
- What is wrong. Build decision 9 reads direction only from the DFOIL-alt signature (`direction.signature`, table
  `DFOIL_ALT_SIGNS`); D_dir is "not read as direction". DFOIL's directional codes ("P3=>P1" etc.) need gene flow
  between single lineages: P1's sharing with P3 against P4, and P1 against P2. Every gene-flow run in the grid is a
  pulse from population C into population A, sampled as A1, A2 and C1, C2:
  - both A genomes receive equally, so DFO and DIL cancel; C1 and C2 are equally related to the donor population, so
    DFI and DOL cancel: expected code `0000`, read "none";
  - even a pulse into A1's lineage alone gives `00++` (pattern counts: P1 gains 1010, 1011 and 1001 together), which
    is not in `DFOIL_ALT_SIGNS`, so "none" again;
  - and a lineage-to-lineage pulse, DFOIL's own case, reads `+-+-` in both directions under this demography (probe
    below), the table's "direction unresolved" class.
- Evidence. The derivation above, and `probe_dfoil.py` (three 10-Mb chromosomes pooled, perfect genotypes, f 0.5,
  Ta 500; z from binomial counts, no block correction, so optimistic):
  - no pulse: DFO +0.165 (z 1.8), DIL +0.026, DFI 0.000, DOL -0.099;
  - population-wide C>A pulse: DFO -0.020, DIL +0.099 (z 1.7), DFI -0.135 (z -2.7), DOL -0.045: no consistent code;
  - pulse from population C into A1's lineage only: DFO -0.041, DIL -0.041, DFI +0.339 (z 6.8), DOL +0.339 (z 6.8),
    a clear `00++`, which `signature()` reads as "none".
  - D_dir does not separate them either: n(C->A) against n(A->C) is 72/25 (D_dir +0.48) with no pulse and 146/50
    (+0.49) with the population pulse. Unequal Ne sets the asymmetry, as decision 9 says.
  - Even DFOIL's own design does not orient here. With subpopulations A1p (split from A at 5,000 generations) and C1p
    (from C at 30,000), each Ne 10,000, a lineage-to-lineage pulse C1p>A1p gives DFO +0.59, DIL -0.57, DFI +0.70,
    DOL -0.27 (|z| 5-18) and the reverse A1p>C1p gives +0.42, -0.24, +0.35, -0.30 (|z| 4-7): the same code `+-+-`,
    "P1<=>P3 or P2<=>P4 (direction unresolved)". Its null (same subpopulations, no pulse): all |z| <= 1.2. The
    table's comment says the directional slot needs deep-root timing; with the taxa's own within-taxon coalescence
    (Ne 30-70k) that condition does not hold.
  These are perfect-genotype probes of my port of the pattern pairs, with binomial z rather than the jackknife, so
  they show expected codes, not error rates.
- Why it matters. Rule 5 needs "each direction called correctly in at least one run", so it fails except by noise,
  and the MISS cannot be investigated: nothing separates "the implementation is wrong" from "the statistic cannot
  orient gene flow under this demography". Task 13 then reports the six-genome direction "with its simulated power at
  f 0.18, ta 5000", a power of about zero for a scenario unlike the real one (PT carries far more mexicana than B73:
  gene flow into one sampled maize lineage, from a mexicana population that TIL18 and TIL25 both sample). R2's
  direction carry-over is not evaluable as designed.
- Fix (about 11 seven-genome runs, about 5.5 h; inside the gate).
  1. Before the grid, a perfect-genotype msprime probe (minutes; the patterns above) gives the expected DFOIL-alt code
     of every direction scenario in the grid. Write those codes into `RULES.md` as predictions: here, "none" for
     population pulses and an undirected code for lineage pulses.
  2. Add a positive control only where that probe predicts a directional code: search a short, pre-listed set of
     subpopulation designs (split times and subpopulation Ne, for example Ne 1,000-5,000 inside A1p and C1p so their
     lineages coalesce near the split), and keep the first that gives "P3=>P1" for C1p>A1p and "P1=>P3" for A1p>C1p;
     3 runs each plus 2 nulls. `Demog` gains the subpopulation fields; the model test gets one case. If no listed
     design orients, say so in `RULES.md`: then rule 5's outcome is predicted before scoring, and the sims document a
     limit of DFOIL-alt, not a bug.
  3. Add the PT-like scenario (population C into A1p only), 3 runs at f 0.18, Ta 5000, and make it the "simulated
     power" Task 13 reports, with the code the real data could produce (`00++`/`00--`, unoriented).
  4. Report D_dir against its simulated null distribution under the same Ne (default and bottleneck) as a labeled
     exploratory readout (the probe suggests it may not move under a population pulse either). The missing
     `00++`/`00--` entries, and whether any PAV statistic can orient a population-level pulse, are Plan 4 leads, not
     Plan 3 code changes.

### Important

**I1. The painting head-to-head gives LTRpav the true recipient and LTRmix none.** (Task 9 `eval_run.py` painting,
`eval_ltrmix.py`; Task 11 §3 and §8; calls 14, 20.)
- What is wrong. LTRpav's painting is scored from view `main`, `--trio A1,B1,C1`: the recipient comes from the truth.
  LTRmix infers its recipient and writes `elements.<R>.tsv`, `tracts.<R>.bed` and `ancestry.<R>.bed` only for the R it
  picks (`ltrmix.py` 1615-1626); `eval_sim.py` reads `elements.B.tsv` only if it exists. Wherever LTRmix picks B1
  (low f, nulls), its painting scores are NA or missing while LTRpav's are scored.
- Why it matters. DESIGN 10.2 wants "head-to-head on one truth"; the brief asks which calls bias it in LTRpav's
  favor. This one does, most at low f, where a recipient is hardest to infer.
- Fix. Score the head-to-head painting from LTRpav's `roles` view (no `--trio`), and treat a wrong recipient the same
  way for both tools: count it per tool, score recall 0 and AUROC NA, report the count. Keep view `main` for
  calibration and power only. `eval_ltrmix.py` must handle a missing `elements.A1.tsv` (record the recipient LTRmix
  chose) rather than fail.

**I2. The simulated genomes are 3-6x denser in informative insertions than main3 after genotyping (5-10x before),
and their outgroup is far shallower; the plan reports this but then projects by length.** (Task 9 "Realism" and
`summarize.py`'s projected Z; Task 11 §2, §3, §10; calls 2, 4, 5.)
- Evidence (perfect genotypes, `probe_outgroup.py`, 10 Mb; main3 from `stats.tsv`):
  - D_pav-informative loci 10.0/Mb against main3's 0.97/Mb (2,041 loci / 2.1 Gb);
  - painting-informative 18.4/Mb against 3.6/Mb (7,515 / 2.1 Gb; median spacing 84 kb);
  - outgroup conflict (ingroup E where O carries the insertion) 0.20-0.23 at the draft's t_o 120k, 0.14 at 300k,
    0.06 at 600k, against main3's 0.027-0.032, which is itself an upper bound (errors included);
  - state mix: main3 B73->TIL18 is P 21%, E 21%, D 22%, O 17%, U 15%, S 0.9%, resolved 46% (`qc_fixed/qc.tsv`). The
    simulator makes almost no `O` (same-site insertions only) and, with loss split 4:3:2, makes solo-LTRs the
    commonest loss, against DESIGN 1a (maize loses LTR-RTs mainly by deletion) and main3's S:D of about 1:24.
  Genotyping narrows the gap but does not close it: Plan 1's pair sims resolve 78% of calls (`geno20`: 1,345 of
  1,716 A->B calls P/S/T/E) against main3's 46%, so after genotyping the sims stay about 6x (D_pav) and 3x
  (painting) denser than main3.
- Why it matters.
  - `summarize.py`'s projected genome-scale Z, `mean D / (mean se * sqrt(L_sim / 2.18 Gb))`, assumes equal density,
    so it overstates the real Z by about the square root of the density ratio (2-3x).
  - Tract recall by bp length transfers to maize only at equal spacing; here spacing is about 3x shorter.
  - Call 4's justification ("pairwise-differential density within ~1.5x") uses a metric that is not the one the
    bars depend on.
  - A shallow outgroup removes far more loci through the outgroup filter and changes which patterns the direction
    counts see; whether that helps or hurts direction is not known.
  - The EM degeneracy (I3) may not occur at this density.
- Fix.
  1. Extend the Realism table to after-genotyping values from each run's own outputs: D_pav counted and informative
     loci per Mb, painting `n_informative` and `spacing_median`, `outgroup_conflict frac_E`, and per-pair state
     fractions and resolved fraction from `qc.tsv`, each beside main3's.
  2. Report power and resolution in density-invariant units: project Z by locus count,
     `Z_sim * sqrt(2041 / n_sim)` (main3's D_pav loci), not by length; give tract recall by tract length also in
     informative loci per tract (true length / the run's mean spacing).
  3. Outgroup (call 2): before the pilot, choose t_o by a pre-registered rule on a perfect-genotype msprime probe
     (minutes): the smallest of {120k, 300k, 600k, 1.2M} whose outgroup conflict is at most main3's upper bound 0.03,
     or keep 120k and carry the deviation as a named caveat in every direction and outgroup-filter result. Setting a
     simulation parameter to a measured property of the data is not threshold tuning (CLAUDE.md); it must be done
     before any scoring.
  4. Loss split (call 5): take it from DESIGN 1a's literature (deletions dominant) or name 4:3:2 a heuristic and say
     what it biases (more `S`, which counts as present, so optimistic informative density).

**I3. The decoy-anchored emission test may be vacuous, and rule 4 can adopt it without any absolute calibration.**
(Task 6; Task 9 rules 3-4; calls 16, 17.)
- What is wrong.
  - The degeneracy that motivates the model (main3: e1 RD 0.9993, e0 RS 0.9995) is recorded only inside the
    `donor_state` note; no row holds e0 or e1, and no rule says whether the sims reproduce it. At the sims' density
    (I2) the default may never degenerate; rule 4 then compares two models in a regime unlike the one that failed.
  - Rule 4's "bp precision at q <= 0.05 is not lower by the same test" is undefined when a model calls no q <= 0.05
    tract (0/0), which is main3's state and likely the default's in many runs.
  - Nothing bounds the realized false discovery rate under gene flow. e0 is fitted to the decoy and the q-values come
    from the same decoy, so the decoy fits state 0 better than the target does: anti-conservative by construction.
    Rule 3 checks this only under the global null; LTRmix's `eval_sim.py` already reports `tract_fdr` per q level.
  - If both variants pass rule 4, their combination is adopted untested.
- Fix.
  1. Task 6 writes numeric rows `e0_RD, e0_RS, e1_RD, e1_RS` beside `donor_state`.
  2. `RULES.md` adds a degeneracy diagnostic (a fit is degenerate when e1[RD] > 0.99 and e0[RS] > 0.99) reported per
     kind and model; if fewer than 10% of the default's fits in the C>A power runs are degenerate, the decoy decision
     is labeled "not tested in main3's regime" and listed as a Plan 4 lead, whatever rule 4 says.
  3. Rule 4 adds an absolute bar: pooled tract-level realized FDR at q <= 0.05 over the C>A power runs at most 0.05,
     with its Clopper-Pearson upper bound at most 0.10; precision pairs where either model is NA are dropped from the
     sign test, and the counts of NA pairs are reported.
  4. One more view, `anydecoy` (`--discovery any --emission decoy`), in every run (seconds); both variants are adopted
     together only if `anydecoy` also passes rules 3 and 4, else only the one with the larger median recall gain.

**I4. The any-discovery variant's null under one-sided dropout is diluted and underpowered.** (Task 9 rule 3; calls
11, 17.)
- What is wrong. DESIGN 7.1 makes adoption conditional on holding the null with one-sided annotation dropout. Rule 3
  adds the 6 dropout nulls (3 at 0.2, 3 at 0.4) to the 30 standard nulls, which have no one-sided dropout. A variant
  that makes false tracts in 1 of the 6 one-sided nulls still passes ("at most 1 of 36"), and the excess test is
  averaged over runs where the risk does not arise.
- Fix. Evaluate the one-sided dropout nulls on their own: 10 per level (+14 trio runs, about 2.5 h), and require at
  most 1 of the 20 with a q <= 0.05 tract and their excess within 2 SE of 0, in addition to rule 3 on the 30 nulls.

**I5. Three bottleneck nulls cannot bound the false-direction rate that matters most.** (Task 8 grid row `bneck`;
rule 5; calls 9, 10, 18.)
- What is wrong. Unequal Ne is the named confounder of direction (DESIGN 14, build decision 9; in the probe's null,
  without a bottleneck, n(C->A) is already 72 against n(A->C) 25). "None of the 3 bottleneck nulls" passes with
  probability 0.51 at a true false-call rate of 20%.
- Fix. 30 bottleneck nulls, as DESIGN's null standard (+27 seven-genome runs, about 13.5 h; with C1 and I4 the plan
  comes to about 88 h, inside the 96-h gate), or at least 10 with "0 of 10" (0.11 at 20%; about 78 h in all).
  Pre-register which: 30 if the pilot projection with them is at most 96 h, else 10. The D_pav null under the
  bottleneck becomes measurable too.

**I6. "Whether the jackknife Z is calibrated" has no rule.** (Task 11 §1; Task 9 rule 1; call 19.)
- What is wrong. Section 1 of `SIM_RESULTS.md` "says whether the jackknife Z is calibrated" with no criterion, and
  the 1-of-30 bar is weak: it passes with probability 0.55 at a true |Z| > 3 rate of 5% and 0.18 at 10%.
- Fix. Pre-register in `RULES.md`: calibrated when the 95% chi-square interval of the SD of null Z (30 runs) includes
  1 and the mean null Z lies within 2 SE of 0; report also SD(D) across nulls against the mean jackknife SE. Apply it
  to D_pav, dD, truth D and LTRmix's four D. The bar stays DESIGN's; this is the reading Task 11 needs.

**I7. Decision 11 can be tested on the simulations for seconds per run, and the plan declines to.** (Task 11 §11;
Task 14 `zd`; call 23.)
- What is wrong. The plan states that no simulated trio uses the fallback. But the catalog takes "annotated" from the
  samples sheet (`catalog.py`: `annotated = [s.label for s in samples if s.annotation is not None]`), so a view whose
  sheet gives C1 annotation `.` runs DESIGN 7.1's fallback with the default four-point narrowing (C2 eligible; A2, B2
  not).
- Why it matters. Decision 11 awaits the user's confirmation; the genus `zd` trio reports one real case without truth.
  The sims give the narrowed rule's null |Z| rate and power with known truth, the only evidence that bears on whether
  the default holds the null.
- Fix. A `nodonor` view (stats only, `--trio A1,B1,C1`) on the 30 nulls and the C>A power runs; its null count and
  power reported in §11 beside the genus case. Pilot it: if the catalog or merge rejects C1's pair files under the
  modified sheet, the view links only the annotated genomes' pair files and reruns `ltrpav-merge` (not cached, cheap).
  The rule is not changed (R2).

**I8. The truth's empty-site rule does not say that point mutations and small indels are noise.** (Task 3 `Copy.site`
"window intact"; Task 4 truth `E`; call 8.)
- What is wrong. Plan 1's truth says point mutations are transparent to the site test ("a 1-bp indel beside an empty
  site leaves it E"). The draft defines `E` as "window of w shared bases on each side intact" without saying what
  breaks it. Between simulated genomes of two taxa the path is about 0.6 M generations: about 1.8% of bases carry a
  SNP and about 0.2% an indel, so a 25-bp window (two w flanks plus the TSD) carries a SNP at about a third of sites
  and an indel at about 4%.
- Why it matters. The two readings give different truths. Read strictly, true empty sites become `D`, the
  classifier's `E` calls (which tolerate these differences) score as errors, and rule 2's high-tier `E` precision bar
  can miss for a scoring reason.
- Fix. State it in Tasks 3-4: only structural events (losses, deletions, other insertions) break the window; SNPs and
  small indels never do. Add `test_truth_E_with_snp_and_indel_beside_site`.

**I9. The LTRquest command is the bare `ltrquest`.** (Task 10 Step 4; call 22.)
- What is wrong. The user's standing correction (memory `ltrquest-use-latest-github`): the `ltrquest` on PATH is a
  stale build; run the HEAD commit from its pinned env. The draft installs the env but calls `ltrquest` unqualified.
  It also orders "delete TEsorter scratch, after `record check` reports reuse"; the memory says delete, then confirm
  `reuse`.
- Fix. Run as `05_ltrquest_extra.sh` does: `conda activate ltrquest_<commit>`, check `command -v ltrquest` lies in that
  env, record the commit in the memo; delete only the listed scratch files, then `python -m ltrquest.record check`
  must print `reuse`.

### Minor

- **M1. Pilot ordering (Task 8 Step 7, Task 9 Steps 3-4).** The pilot runs `run_one.sh` before Task 9's `eval`
  scripts exist, and `pilot.tsv` is never defined. Run the pilot through `ltrmix` only (`run_one.sh --until ltrmix`),
  define `pilot.tsv` as the two grid rows, and write and date `RULES.md` (verbatim from the plan) before scoring the
  pilot: the pilot rows are grid rows.
- **M2. Scoring code is not frozen during the grid.** Record each eval script's sha256 in `eval.json`, and in Task 11
  Step 1 rerun `eval_run.py` and `eval_ltrmix.py` on every run with the final scoring code before `summarize.py`.
- **M3. Interface gaps.** `PopResult` is used but never defined; Task 1's `tracts` is keyed by sample, one call per
  chromosome, while `tract_bed(g, sample_tracts: dict[int, ...])` takes one genome, so its key must be the chromosome
  (say so, or rename the parameter); `backbone_elements`
  returns `SimElement` while `ltrpav-sim pair` still needs `_shift`'s `Element` to stay byte-identical. Define
  `PopResult`'s fields, key `tract_bed` by chromosome, and keep an Element-returning helper for `pair`.
- **M4. Task 6 Step 4's "byte-identical apart from the emission row"** will fail on the sentinel rows (they hold the
  stage key, which the analysis fingerprint changes). Exclude sentinel rows from the comparison.
- **M5. `test_em_degenerates_decoy_does_not` pins degeneracy to seed 4** without evidence that seed 4 degenerates.
  Build the degenerate input directly (sparse loci, perfectly class-segregated runs), or state the seed search.
- **M6. Environments for the scoring scripts.** Env `ltrpav` has no pandas (env `ltrmix` has pandas 3.1). Say which
  env runs `eval_run.py`, `eval_ltrmix.py` and `summarize.py`; keep `evalib.py` numpy-only.
- **M7. Paths and names.** `rate_free_split.py` is `$P/benchmark/scripts/rate_free_split.py`; LTRmix's trio directory
  for {A1, B1, C1} is `A1_B1_C1` (label order). Pick one canonical LTRmix comparator tree (`benchmark/` and
  `LTRmix/benchmark/` are copies).
- **M8. Forward references.** Task 14 Step 3 and Task 15 Step 1 set their rows "beside Task 16's view", which does not
  exist yet. Move Task 16 Step 1 (the default B73/TIL01/TIL18 view) into Task 13.
- **M9. DESIGN 10.2 asks for tract precision by tract length**; only recall by length is planned. Add precision by
  called-tract length bins (same bins).
- **M10. Power with 2 replicates per cell.** Report mean Z and its SD per (f, Ta) and a probit fit of P(Z > 3) on f
  per Ta, with the f at 80% power and its interval; the run fraction alone is 0, 0.5 or 1.
- **M11. The genotype bar is pooled over runs that share one backbone.** Also report precision per target class
  (into O1 against ingroup) and per backbone window, so a backbone-driven error is visible.
- **M12. `--anchor mm2` on whole maize genomes was never confirmed at scale** (the bake-off confirmed only the winner;
  its mm2 estimate is <= 58 GB). Run the first pair alone with RSS sampling before the rest (DESIGN 3); the estimate
  is nearer 4.5 h than 3 h (0.39/0.19 x main3's 14.6 min x 9 pairs).
- **M13. Copy noise.** LTRmix's simulator adds 0.5% noise per insertion copy; here every copy of a donor is the same
  master plus its own branch mutations, so paralogs from one donor can be as similar as orthologs. That may handicap
  LTRmix's library orthology relative to its own sims. Add `copy_noise = 0.005` to the body before copying the left
  LTR (keeps identical LTRs), or state the choice and its expected effect.
- **M14. LTRmix's presence/absence accuracy** (DESIGN 10.5's "genotype accuracy of each tool's presence/absence")
  is cheapest now: score `orthologs.X.Y.tsv.gz` status against `truth/` in `eval_ltrmix.py`.
- **M15. Equal-information comparison.** LTRmix gets no outgroup; put LTRpav's `no_outgroup_filter` D_pav stratum
  beside LTRmix's D tests in the tables.
- **M16. CI.** msprime on Python 3.13 needs a wheel or GSL; confirm, and make every msprime/tskit test module use
  `pytest.importorskip`.
- **M17. No environment changes while detached jobs run.** The snapshot freezes ltrpav's code, not envs `ltrpav` or
  `ltrmix`.
- **M18. Review Focus.** Add backbone bases outside ACGTN (soft-masked lowercase, IUPAC from other users' FASTAs):
  upper-case on load, no SNP at a non-ACGT site, no TSD read across one. B73v5 itself is uppercase ACGTN.
- **M19. Simulator generality.** `ltrpav-sim pop` exposes f, Ta, direction and bottleneck but no Ne, split times or
  rates, so a user cannot simulate another system's demography. Add `--demography FILE.json` (Demog and Rates
  fields), defaults unchanged.
- **M20. Backbone element K2P (call 32).** Each LTR also takes the genealogy's SNPs from the local root (about
  2·mu·T, ~2.4%), so the source K understates the sample's own. Compute it from the sample's LTRs as for simulated
  copies (low impact: backbone elements never enter D_pav or the painting).
- **M21. Recombination map.** LTRmix's low-rate middle 40% was per simulated chromosome; here it is applied to every
  10-Mb window, arm windows included. Name it a heuristic, or use uniform r outside the two pericentromeric windows.
- **M22. Plan 2's D gap (Task 11 §9).** Say before scoring what the two truth D are expected to differ by: only which
  copies count (any present state against annotated intact copies) and dropout. The informative comparison is D_ins
  and D_pav each against truth D on the same runs, and whether the sims reproduce the real ratio (0.19/0.29 = 0.66).
- **M23. Small items.** The grid table's dropout row sits after a paragraph and leaves the table; state that the
  LTRquest runs start after `grid.done` (thread budget); give `lq/<name>/` the run layout `eval_run.py` expects
  (links to `sim/` and `truth/`) and name the coordinate-join function with a test; reuse or cross-check
  `main3/qc_fixed/edta/*.structural.gff3` for B73/TIL18/TIL01; CLAUDE.md accepts PPID 1 or a systemd user manager.

## The 33 calls

| # | Call | Judgment | Revision |
|---|---|---|---|
| 1 | Ten 10-Mb B73 windows, one per chromosome | accept | Name the per-window low-recombination middle a heuristic (M21). |
| 2 | Outgroup split 120k, Ne 150k | revise | Outgroup conflict 0.20-0.23 against main3's <= 0.03: choose t_o by a pre-registered probe rule before the pilot, or carry the deviation as a named caveat (I2). |
| 3 | Taxa A, B, C, O in `src/` | accept | |
| 4 | LTRmix's TE rates kept | revise | Keep for comparability, but the informative densities are 3-10x main3's: project Z by locus count, recall in loci per tract, test the degeneracy (I2, I3). |
| 5 | Loss split 4:3:2 | revise | Solo becomes the commonest loss, against DESIGN 1a and main3's S:D ~1:24; use a literature ratio or name it a heuristic and its bias (I2). |
| 6 | Small indels at mu/10 on the backbone only | accept | The truth must treat them as noise (I8). |
| 7 | Nesting by a subtree process, depth <= 2 | accept | |
| 8 | Truth from event records | accept | State that SNPs and small indels never break an E window; add the test (I8). |
| 9 | Bottleneck Ne 5,000 for 2,000 generations | accept | Nb/d 2.5 matches the cited 2.45; replicates are the issue (I5). |
| 10 | 8 reverse and 6 bottleneck runs | revise | 30 (at least 10) bottleneck nulls (I5); predict each scenario's DFOIL-alt code by probe, add a probe-checked positive control and the PT-like runs (C1). |
| 11 | All 80 main runs 7-genome; dropout runs as trios | accept | Raise one-sided dropout nulls to 10 per level and judge them alone (I4). |
| 12 | Dropout 0.1, jitter 0.05; one-sided 0.2, 0.4 | accept | |
| 13 | Gaps 2.5/Mb, 100 bp, a third near sites | accept | Conservative against real G (0.02-0.08% of calls); say so. |
| 14 | Pre-declared trio | revise | Keep for calibration and power; score the head-to-head painting from the roles view, wrong recipients counted alike (I1). |
| 15 | Painting scored only in C>A runs | accept | |
| 16 | Decoy-anchored e0 | revise | Model accepted; add e0/e1 rows and the degeneracy diagnostic (I3). Cross-fitting the decoy (e0 on half its sequences, q on the other) is a Plan 4 lead if the null fails. |
| 17 | Adoption rules | revise | Add NA handling, an absolute realized-FDR bar, the combined view, and the one-sided-dropout null judged alone (I3, I4); date RULES.md before the pilot is scored (M1). |
| 18 | Direction kept | revise | Pre-register the probe-predicted codes ("none" under population pulses, unoriented `+-+-` even for lineage pulses in this demography), add a positive control only if a listed design orients, enlarge the bottleneck null (C1, I5). |
| 19 | "At most 5% of 30" read as at most 1 | accept | Arithmetic right; add the pre-registered calibration reading (I6). |
| 20 | LTRmix on A1, B1, C1, C2 libraries | accept | Handle LTRmix's own recipient choice (I1); add LTRmix's presence/absence accuracy (M14) and the no-outgroup stratum beside it (M15); give `rate_free_split.py`'s path (M7). |
| 21 | Plan 2's gaps on the sims | accept | State the expected truth-D outcome first (M22). |
| 22 | LTRquest runs reuse three grid runs | accept | Run from the pinned env, record the commit, delete then check (I9); define the `lq/` layout (M23). |
| 23 | Zd genotype-only in the genus run | accept | Also add the `nodonor` view on the sims (I7). |
| 24 | Positive control D_pav(PT, B73; TIL18) > 0, Z > 3 | accept | It is LTRmix's own positive control (REPORT l. 153). |
| 25 | Citrus "called" at >= 50% cover, any q | accept | LTRmix 04_eval's rule; also report recall at q <= 0.05. |
| 26 | 10.3 rerun from the six-genome run | accept | Necessary as well as cheaper: main3 predates the engine's later commits. |
| 27 | Stability: mm2, 5-kb cap, 1-20 Mb blocks | accept | First mm2 pair alone with RSS sampling; ~4.5 h (M12). |
| 28 | Frozen code by git archive + PYTHONPATH | accept | Verified the editable install is a path `.pth`; freeze envs during runs (M17) and fingerprint the eval scripts (M2). |
| 29 | Two 16-thread runs at a time | accept | |
| 30 | EDTA prep | accept | Cross-check counts against `main3/qc_fixed/edta/` (M23). |
| 31 | No simulated inversions | accept | Note that the painting's inverted-block flags go untested on the sims. |
| 32 | K2P sources | revise | Backbone copies: compute K2P from the sample's own LTRs (M20). |
| 33 | No figures | accept | |

## Verdict

**Ready after fixes.** The structure, the engine boundary, the compute plan and most calls are sound, and no fix
changes the architecture. Order of the fixes:
- C1 before Task 1 is final (subpopulation fields in `Demog`) and before Task 8's grid table: the probes say the
  direction test will most likely read "none" or "unresolved" in every simulated gene-flow run, so that prediction,
  and any positive control, must be in `RULES.md` before scoring; the honest Plan 3 result may well be "DFOIL-alt
  cannot orient gene flow under this demography", which is worth knowing only if it was predicted and controlled.
- I2-I7 before the pilot: they change `RULES.md`, the views and the grid size.
- I8 in Tasks 3-4, I9 in Task 10.
With C1, I4 and I5 the projection is about 78-88 h, still inside the 96-h gate (the gate's formula must count the
added runs).
