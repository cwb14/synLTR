"""Command line: ltrkin genotype | source."""
import argparse
import os
import sys

from . import __version__


def main(argv=None):
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    ap = argparse.ArgumentParser(prog="ltrkin", description="Genotype LTR-RT insertions from long reads and assign "
                                 "their likely source copies.")
    ap.add_argument("--version", action="version", version=f"ltrkin {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)

    g = sub.add_parser("genotype", help="full / solo / empty / null alleles of annotated elements per sample",
                       description="Genotype every annotated LTR-RT in each BAM/CRAM (long reads aligned to the "
                       "reference). Writes <out>.genotypes.tsv and <out>.vcf.gz.")
    g.add_argument("bams", nargs="+", help="coordinate-sorted, indexed BAM/CRAM files, one per sample")
    g.add_argument("-r", "--reference", required=True, help="reference FASTA the reads were aligned to")
    g.add_argument("-a", "--annotation", required=True, help="LTR-RT GFF3 (LTRquest, EDTA, LTR_retriever, LTRharvest or DANTE_LTR; may be gzipped)")
    g.add_argument("-o", "--output", required=True, help="output prefix")
    g.add_argument("-t", "--threads", type=int, default=4, help="worker processes [4]")
    g.add_argument("--ploidy", type=int, default=2, help="copies of each chromosome per sample [2]")
    g.add_argument("--min-mapq", type=int, default=20, help="minimum mapping quality of an anchoring read [20]")
    g.add_argument("-v", "--verbose", action="store_true", help="progress and model parameters")

    s = sub.add_parser("source", help="likely source copy of each new insertion",
                       description="For each new (polymorphic) copy, the nearest fixed copy and the evidence to judge "
                       "it. Writes <out>.copies.tsv, <out>.sources.tsv and <out>.locality.tsv.")
    s.add_argument("-r", "--reference", required=True, help="reference FASTA")
    s.add_argument("-a", "--annotation", required=True, help="LTR-RT GFF3 used for genotyping")
    s.add_argument("-g", "--genotypes", required=True, nargs="+", help="ltrkin genotype TSV file(s)")
    s.add_argument("-o", "--output", required=True, help="output prefix")
    s.add_argument("-t", "--threads", type=int, default=4, help="threads (minimap2 and alignment workers) [4]")
    s.add_argument("-v", "--verbose", action="store_true", help="progress")

    a = ap.parse_args(argv)
    if a.threads < 1:
        sys.exit("ltrkin: --threads must be >= 1")
    if a.cmd == "genotype":
        if a.ploidy < 1:
            sys.exit("ltrkin: --ploidy must be >= 1")
        for p in a.bams + [a.reference, a.annotation]:
            if not os.path.exists(p):
                sys.exit(f"ltrkin: file not found: {p}")
        from .genotype import run
        run(a)
    else:
        for p in a.genotypes + [a.reference, a.annotation]:
            if not os.path.exists(p):
                sys.exit(f"ltrkin: file not found: {p}")
        from .source import run
        run(a)


if __name__ == "__main__":
    main()
