# `ltrkin genotype`: simulated-reads benchmark

Date: 2026-11-10. ltrkin 0.1.0. Planted-truth diploid on real *P. supina* sequence (Ps4B:30-60 Mb, 430 planted sites),
HiFi- and ONT-like reads at 10x, 20x and 40x, with Sniffles2 2.8.1 `--genotype-vcf` as the baseline. Outputs were
kept outside the repository (tables in the run's `eval/`).
Scripts: `benchmark/run_genotype_bench.sh` and the Python files it calls.

## Final results (round 4: `reads.py` 21:16, MD5 ed2fced0; 26 tool tests pass)
Full BAMs, 430 planted sites (215 F/F, 108 F/E, 44 F/S, 42 F/N hemizygous, 21 internal deletions).
- Concordance: correct genotypes / planted sites (no-calls count as wrong).
- GQ>=20: correct / calls with GQ >= 20.
- Call rate: share of sites called with GQ >= 20.
- Recall per truth class, no GQ filter.

| Read set | ltrkin: concordance / GQ>=20 / call rate | ltrkin recall F/F / F/E / F/S / F/N | Sniffles2: concordance / GQ>=20 / call rate | Sniffles2 recall F/F / F/E / F/S / F/N |
|---|---|---|---|---|
| HiFi 10x | 92.8 / 100.0 / 45.6 | 89.3 / 97.2 / 97.7 / 90.5 | 76.3 / 71.2 / 15.3 | 100.0 / 64.8 / 56.8 / 0.0 |
| HiFi 20x | 95.3 / 99.7 / 70.2 | 90.7 / 100.0 / 100.0 / 100.0 | 78.1 / 74.8 / 28.6 | 100.0 / 71.3 / 59.1 / 0.0 |
| HiFi 40x | 99.5 / 100.0 / 83.3 | 99.1 / 100.0 / 100.0 / 100.0 | 79.8 / 74.3 / 33.5 | 100.0 / 75.0 / 65.9 / 0.0 |
| ONT 10x | 90.2 / 100.0 / 42.8 | 85.6 / 97.2 / 100.0 / 81.0 | 76.7 / 79.0 / 14.4 | 100.0 / 65.7 / 56.8 / 0.0 |
| ONT 20x | 95.8 / 100.0 / 64.7 | 96.3 / 100.0 / 100.0 / 76.2 | 78.8 / 77.5 / 27.9 | 100.0 / 74.1 / 56.8 / 0.0 |
| ONT 40x | 98.4 / 100.0 / 79.8 | 98.6 / 100.0 / 100.0 / 90.5 | 79.5 / 75.9 / 32.8 | 100.0 / 75.0 / 63.6 / 0.0 |

**What holds**
- **Empty and solo alleles: no false call in any run.** Every planted empty and solo site is found at 20x and 40x.
- **GQ is calibrated.** One wrong call at GQ >= 20 over all six runs (an F/F site called F/N at GQ 27).
- **Context elements:** among the 911 elements left full on both haplotypes, only one non-F/F call reaches GQ >= 20.
- **Other checks:**
  - Primary-only BAMs match full BAMs within 0.3 points.
  - The depth model is unaffected by the uncovered rest of the chromosome.
  - Runtime is 4-47 s per BAM.

**Remaining failure modes (ltrkin)**
1. **F/F against F/N is decided by read counts.** A haplotype that lacks the site gives no reads, so F/N rests only on
   about half the expected number of full reads, under a flat prior.
   - At 20x: 20 of 215 F/F sites are called F/N (HiFi) and 10 of 42 hemizygous sites F/F (ONT), all at GQ <= 27.
   - Every error at 20x and 40x is of this kind.
   - The fix is positive evidence for a missing haplotype, not a prior (proposal 1 below).
2. **ONT error deletions at anchors.** An ONT read whose only anchor lies inside a sequencing-error deletion of >= 50 bp
   is dropped. That is 1-3 genuine reads per ONT run at the 215 F/F sites (0.02-0.04% of full reads; none in HiFi), and
   it flipped one call (13006, ONT 10x, GQ 4).
   - A related edge case: at 12788 (unscored), ONT reads cross a neighbor's 26.7-kb deletion as a ladder of shorter
     deletions with short spurious matches. Their anchors land on matched bases, and their length change falls in
     12788's wide solo window (unequal LTRs). Result: F/S at GQ 10 at ONT 40x.

**Sniffles2 for comparison.** 76-80% concordance; calls with GQ >= 20 are only 71-79% correct, at a 14-34% call rate.
1. It has no allele for a missing haplotype: all 42 hemizygous sites are wrong.
2. Records without a matching SV candidate are written 0/0 with GQ 0.
3. When 2 x LTR + TSD <= 1 kb, the empty and solo records match the same deletion: 27 of 108 empty sites become S/E.
4. Solo deletions of young long-LTR elements fall outside its 1-kb matching window.
5. Its GQ carries no information.

**Code versions.** Four rounds of ltrkin runs used the same BAMs; Sniffles2 ran once. This benchmark changed no code
in `src` or `tests`.

| Round | `reads.py` | Change | ltrkin outputs / tables |
|---|---|---|---|
| 1 | 18:23 | (allele posteriors and `pav` from `genotype.py`/`model.py` 19:06) | `ltrkin_before_fix/`, `eval_before_fix/` |
| 2 | 20:46 | solo length interval; an anchor inside a >= 50-bp alignment deletion is invalid | `ltrkin_round2/`, `eval_round2/` |
| 3 | 21:02 | one-sided full/present reads need an aligned base 100 bp inside the junction; a read spanning the site with an anchor inside a >= 50-bp deletion counts as "other" | `ltrkin_round3/`, `eval_round3/` |
| 4 | 21:16 (MD5 ed2fced0) | the "other" rule applies only if that deletion reaches more than 60 bp (`SLOP`) into the element | `ltrkin/`, `eval/` |

## Effect of the `reads.py` changes (full BAMs)
Each cell is round 1 -> 2 -> 3 -> 4, in %.

| Run | Concordance, all calls | Concordance, GQ>=20 | Call rate, GQ>=20 | Recall F/S (44) | Recall F/N hemizygous (42) | Recall F/F (215) |
|---|---|---|---|---|---|---|
| HiFi 10x | 92.1 -> 92.8 -> 92.8 -> 92.8 | 100.0 -> 100.0 -> 100.0 -> 100.0 | 44.9 -> 45.6 -> 45.6 -> 45.6 | 90.9 -> 97.7 -> 97.7 -> 97.7 | 90.5 -> 90.5 -> 90.5 -> 90.5 | 89.3 -> 89.3 -> 89.3 -> 89.3 |
| HiFi 20x | 94.2 -> 95.3 -> 95.3 -> 95.3 | 99.3 -> 99.7 -> 99.7 -> 99.7 | 69.3 -> 70.0 -> 70.2 -> 70.2 | 90.9 -> 100.0 -> 100.0 -> 100.0 | 97.6 -> 100.0 -> 100.0 -> 100.0 | 90.7 -> 90.7 -> 90.7 -> 90.7 |
| HiFi 40x | 98.4 -> 99.3 -> 99.5 -> 99.5 | 99.4 -> 100.0 -> 100.0 -> 100.0 | 82.8 -> 83.3 -> 83.3 -> 83.3 | 90.9 -> 100.0 -> 100.0 -> 100.0 | 97.6 -> 97.6 -> 100.0 -> 100.0 | 99.1 -> 99.1 -> 99.1 -> 99.1 |
| ONT 10x | 89.5 -> 90.2 -> 90.2 -> 90.2 | 100.0 -> 100.0 -> 100.0 -> 100.0 | 41.9 -> 42.8 -> 42.8 -> 42.8 | 93.2 -> 100.0 -> 100.0 -> 100.0 | 78.6 -> 81.0 -> 81.0 -> 81.0 | 86.0 -> 85.6 -> 85.6 -> 85.6 |
| ONT 20x | 94.4 -> 95.3 -> 95.8 -> 95.8 | 99.3 -> 100.0 -> 100.0 -> 100.0 | 64.0 -> 64.4 -> 64.4 -> 64.7 | 90.9 -> 100.0 -> 100.0 -> 100.0 | 71.4 -> 71.4 -> 76.2 -> 76.2 | 96.3 -> 96.3 -> 96.3 -> 96.3 |
| ONT 40x | 97.0 -> 98.4 -> 98.4 -> 98.4 | 98.8 -> 100.0 -> 100.0 -> 100.0 | 79.5 -> 79.3 -> 79.3 -> 79.8 | 90.9 -> 100.0 -> 100.0 -> 100.0 | 85.7 -> 90.5 -> 90.5 -> 90.5 | 98.6 -> 98.6 -> 98.6 -> 98.6 |

Empty-site recall is the same in all rounds (97.2% at 10x, 100% at 20x and 40x). Its precision is 100% from round 2
on (round 1: 98.2-100%).

**Reported sites** (call and GQ, rounds 1 / 2 / 3 / 4):

| Site | Truth | HiFi 10x | HiFi 20x | HiFi 40x | ONT 10x | ONT 20x | ONT 40x |
|---|---|---|---|---|---|---|---|
| 11987 (solo, LTRs 1,429 / 156 bp) | F/S | F/N 4 / F/S 99 / F/S 99 / F/S 99 | F/N 8 / F/S 99 / F/S 99 / F/S 99 | F/N 8 / F/S 99 / F/S 99 / F/S 99 | F/N 10 / F/S 43 / F/S 43 / F/S 43 | F/N 23 / F/S 88 / F/S 88 / F/S 88 | F/N 35 / F/S 99 / F/S 99 / F/S 99 |
| 12928 (26-kb hemizygous deletion) | F/N | F/N 13 / F/N 13 / F/N 13 / F/N 13 | F/E 99 / F/N 10 / F/N 24 / F/N 24 | F/E 99 / F/F 13 / F/N 13 / F/N 13 | F/E 10 / F/N 4 / F/N 8 / F/N 8 | F/E 23 / F/N 6 / F/N 20 / F/N 20 | F/E 48 / F/N 12 / F/N 31 / F/N 31 |
| 12205 (25-kb hemizygous deletion) | F/N | F/N 8 / F/N 8 / F/N 8 / F/N 8 | F/N 26 / F/N 26 / F/N 26 / F/N 26 | F/N 28 / F/N 28 / F/N 28 / F/N 28 | F/N 9 / F/N 9 / F/N 9 / F/N 9 | F/F 3 / F/F 3 / F/N 4 / F/N 4 | F/E 40 / F/N 11 / F/N 13 / F/N 13 |
| 12555 (hemizygous) | F/N | F/N 10 / F/N 10 / F/N 10 / F/N 10 | F/N 4 / F/N 4 / F/N 4 / F/N 4 | F/N 10 / F/N 10 / F/N 10 / F/N 10 | F/F 4 / F/F 6 / F/F 4 / F/F 4 | F/N 4 / F/F 4 / F/N 4 / F/N 4 | F/N 23 / F/N 19 / F/N 23 / F/N 23 |
| 13006 | F/F | F/N 4 / F/N 4 / F/N 4 / F/N 4 | F/N 6 / F/N 6 / F/N 6 / F/N 6 | F/F 13 / F/F 13 / F/F 13 / F/F 13 | F/F 4 / F/N 4 / F/N 4 / F/N 4 | F/F 12 / F/F 9 / F/F 9 / F/F 9 | F/F 31 / F/F 29 / F/F 29 / F/F 29 |
| 12788 (unscored; 7.4 kb deleted on hap2 by a neighbor's hemizygous deletion; LTRs 1,729 / 1,111 bp) | F/F or F/N | F/N 6 / F/N 6 / F/N 6 / F/N 6 | F/F 13 / F/F 13 / F/F 13 / F/F 13 | F/F 24 / F/F 24 / F/F 24 / F/F 24 | F/F 17 / F/F 20 / F/F 17 / F/F 17 | F/F 20 / F/F 25 / F/F 22 / F/F 22 | F/F 21 / F/F 4 / F/S 10 / F/S 10 |

- 11987, 12928 and 12205 are right in all six runs from round 3 on, and 12555 in five (ONT 10x: F/F at GQ 4 in every
  round).
- 13006 is a count-test error at HiFi 10x and 20x in every round. At ONT 10x it has been F/N since round 2: one genuine
  read is dropped because its right anchor lies inside a 78-bp ONT error deletion, a GQ-4 coin flip.
- **12788**, at ONT 40x:
  - Its 4 solo-labeled reads are hap2 reads that cross the neighbor's 26.7-kb deletion as a ladder of 25-30 shorter
    deletions with short spurious matches.
  - Their anchors land on matched bases, and their length change (-9,446 to -9,477 bp) falls in 12788's solo window
    (-9,497 to -8,763 bp), which is wide because the LTRs differ by 618 bp.
  - A rule rejecting reads with more than half of a 100-bp anchor window deleted would catch only 1 of these 4 reads,
    and would drop 3 genuine solo reads at ONT 40x, so it is not proposed.

**Call changes between rounds** (all six full-BAM runs, all 1,428 elements):

| Change | Wrong to right | Right to wrong |
|---|---|---|
| Round 1 -> 2, planted sites | 27: the four unequal-LTR solo sites (22 calls), 12928 (4), 12205 at ONT 40x (1) | 2: 12555 (ONT 20x, one false full-junction read) and 13006 (ONT 10x, one dropped genuine read), both GQ 4 |
| Round 2 -> 3, planted sites | 3: 12928 at HiFi 40x; 12205 and 12555 at ONT 20x | 0 |
| Round 2 -> 3, context elements in or near a planted deletion (87, unscored) | 0 | 14: 13 F/F -> F/N at intact elements next to a neighbor's deletion; 12788 F/F -> F/S at ONT 40x |
| Round 3 -> 4, all elements | 13: all 13 neighbor calls recovered | 0 |

- Other effects of round 4:
  - 12672 (partly deleted on hap2, either call accepted) moves F/N -> F/F in all runs.
  - About 15 ONT planted sites regain one read that round 3 had counted as "other", raising a few GQs (ONT call rate
    +0.3-0.5 points). No genotype changes.
- The 911 context elements that are full on both haplotypes did not change in any round.

**`other_allele` flag**: flagged sites per run (HiFi 10x, 20x, 40x / ONT 10x, 20x, 40x).

| Sites | Round 1 | Round 2 | Round 3 | Round 4 |
|---|---|---|---|---|
| hemizygous (42) | 8, 9, 8 / 6, 10, 11 | 0, 0, 0 / 0, 0, 0 | 8, 10, 9 / 7, 11, 12 | 8, 10, 9 / 7, 11, 12 |
| internal deletion, "other" (21; flag expected) | 17, 21, 21 / 11, 21, 21 | same | same | same |
| planted F/F, F/E, F/S (367; false) | 3, 4, 4 / 4, 5, 4 | 0, 0, 0 / 1, 1, 0 | 0, 0, 0 / 1, 1, 0 | 0, 0, 0 / 1, 1, 0 |
| context F/F (911; false) | 0, 0, 0 / 1, 2, 0 | 0, 0, 0 / 1, 2, 0 | 0, 0, 0 / 1, 3, 0 | 0, 0, 0 / 1, 2, 0 |

- Round 1's false flags at planted sites were mostly the unequal-LTR solo sites, whose solo reads were labeled
  "other".
- The flag fires at only 8-12 of 42 hemizygous sites, because only reads that cross the whole deletion produce it.

**How each round was checked.** Each change was predicted by replaying ltrkin's own per-read labeling with true read
origins and recalling with its model before it was run. The replay reproduces the TSV counts exactly (0/517 mismatches).
- Round 2's false full-junction reads were reads with no aligned base inside the element: 5-12 at 12928 (HiFi 20x and
  40x) and 3-15 per ONT run at hemizygous sites. Round 3 removed them.
- Round 3's neighbor regressions are fixed by round 4 exactly as predicted. The 60-bp margin is needed because the
  aligner slid one neighbor deletion 2 bp into the element (23706).

## Results (round 4)

**Headline, 20x** (430 planted sites; allele detection asks whether the call carries the planted allele).

| % (20x) | ltrkin HiFi full | ltrkin HiFi primary | Sniffles2 HiFi full | ltrkin ONT full | ltrkin ONT primary | Sniffles2 ONT full |
|---|---|---|---|---|---|---|
| Concordance, all calls | 95.3 | 95.3 | 78.1 | 95.8 | 95.6 | 78.8 |
| Concordance, GQ>=20 | 99.7 | 99.7 | 74.8 | 100.0 | 100.0 | 77.5 |
| Call rate, GQ>=20 | 70.2 | 70.2 | 28.6 | 64.7 | 64.4 | 27.9 |
| Recall F/F (215) | 90.7 | 90.7 | 100.0 | 96.3 | 95.8 | 100.0 |
| Recall F/E (108) | 100.0 | 100.0 | 71.3 | 100.0 | 100.0 | 74.1 |
| Recall F/S (44) | 100.0 | 100.0 | 59.1 | 100.0 | 100.0 | 56.8 |
| Recall F/N hemizygous (42) | 100.0 | 100.0 | 0.0 | 76.2 | 76.2 | 0.0 |
| Recall other (21; F/N or F/F) | 100.0 | 100.0 | 85.7 | 100.0 | 100.0 | 90.5 |
| E allele recall / precision, GQ>=20 | 100.0 / 100.0 | 100.0 / 100.0 | 85.2 / 94.8 | 100.0 / 100.0 | 100.0 / 100.0 | 88.9 / 98.0 |
| S allele recall / precision, GQ>=20 | 100.0 / 100.0 | 100.0 / 100.0 | 63.6 / 51.9 | 100.0 / 100.0 | 100.0 / 100.0 | 50.0 / 46.8 |

**By depth**: concordance with all calls / concordance at GQ >= 20 / call rate at GQ >= 20, in %.

| Tech | Depth | ltrkin, full BAM | ltrkin, primary BAM | Sniffles2, full BAM | Sniffles2, primary BAM (all calls) |
|---|---|---|---|---|---|
| HiFi | 10x | 92.8 / 100.0 / 45.6 | 92.8 / 100.0 / 45.6 | 76.3 / 71.2 / 15.3 | 76.5 |
| HiFi | 20x | 95.3 / 99.7 / 70.2 | 95.3 / 99.7 / 70.2 | 78.1 / 74.8 / 28.6 | 78.1 |
| HiFi | 40x | 99.5 / 100.0 / 83.3 | 99.5 / 100.0 / 83.3 | 79.8 / 74.3 / 33.5 | 79.8 |
| ONT | 10x | 90.2 / 100.0 / 42.8 | 90.5 / 100.0 / 42.6 | 76.7 / 79.0 / 14.4 | 76.7 |
| ONT | 20x | 95.8 / 100.0 / 64.7 | 95.6 / 100.0 / 64.4 | 78.8 / 77.5 / 27.9 | 78.8 |
| ONT | 40x | 98.4 / 100.0 / 79.8 | 98.4 / 100.0 / 79.1 | 79.5 / 75.9 / 32.8 | 79.8 |

ltrkin meets the literature target for isolated elements (>= 95% concordance at >= 20x HiFi; lit_review,
"Implications"). Replicate noise is about +-1-2 points: an independent 10x HiFi read set (the pilot, round-1 code) gave
90.2% against 92.1% for the round-1 10x subsample.

**Strata**: concordance with all calls, in %, full BAMs.

| Stratum | n | ltrkin HiFi 20x | ltrkin ONT 20x | Sniffles2 HiFi 20x | Sniffles2 ONT 20x | ltrkin HiFi 40x | ltrkin ONT 40x |
|---|---|---|---|---|---|---|---|
| < 5 kb | 84 | 92.9 | 95.2 | 66.7 | 70.2 | 98.8 | 96.4 |
| 5-10 kb | 190 | 95.8 | 97.9 | 84.2 | 84.2 | 100.0 | 98.9 |
| 10-17 kb | 150 | 97.3 | 93.3 | 76.7 | 76.7 | 99.3 | 98.7 |
| > 17 kb | 6 | 66.7 | 100.0 | 83.3 | 83.3 | 100.0 | 100.0 |
| young (LTR K2P <= 0.005) | 101 | 99.0 | 95.0 | 73.3 | 72.3 | 99.0 | 98.0 |
| older | 329 | 94.2 | 96.0 | 79.6 | 80.9 | 99.7 | 98.5 |
| nearest other element < 1 kb | 101 | 97.0 | 95.0 | 74.3 | 73.3 | 100.0 | 99.0 |
| 1-10 kb | 197 | 94.9 | 95.4 | 81.2 | 81.2 | 100.0 | 97.5 |
| >= 10 kb | 132 | 94.7 | 97.0 | 76.5 | 79.5 | 98.5 | 99.2 |

ltrkin shows no deficit for young elements or for elements with close neighbors. The > 17 kb stratum has 6 sites and no
planted empty site, so it cannot be read. Sniffles2 is weakest for short elements (short LTRs) and for young ones.

**Context.** The 911 unplanted elements that are full on both haplotypes (470 nested, 441 not nested) have truth F/F.
ltrkin calls them F/F at 85-88% (10x), 93-95% (20x) and 98-99% (40x); the errors are low-GQ F/N calls. Across all six
read sets only one non-F/F call reaches GQ >= 20 (one F/N, ONT 20x). Nested and non-nested context score alike.

**Depth model, error estimate, runtime.** ltrkin samples depth at 400 random points over each chromosome that carries
elements, here all of Ps4B. 140 points fall in the simulated 30 Mb; the other 260 have depth 0, and `ReadModel` drops
zero-depth points. **The model is not fooled by the uncovered rest of the chromosome.** Its depth mode matches the
independent depth of 2,000 region points within 0.5x in every read set, so the full-genome reference was kept and no
region reference was built.

| Read set | ltrkin depth mode (per haplotype) | independent region depth, mode / mean | ltrkin error estimate | mean read span (bp) | ltrkin wall time, full / primary (s) | Sniffles2 wall time, full (s) |
|---|---|---|---|---|---|---|
| HiFi 10x | 9.6 (4.8) | 9 / 9.9 | 0.0010 | 19105 | 4 / 4 | 3 |
| HiFi 20x | 20.1 (10.0) | 20 / 19.6 | 0.0010 | 19072 | 8 / 8 | 5 |
| HiFi 40x | 39.0 (19.5) | 39 / 39.4 | 0.0010 | 19055 | 15 / 15 | 10 |
| ONT 10x | 9.5 (4.8) | 9 / 9.6 | 0.0010 | 26794 | 11 / 11 | 9 |
| ONT 20x | 19.0 (9.5) | 19 / 19.4 | 0.0010 | 27233 | 23 / 23 | 18 |
| ONT 40x | 39.0 (19.5) | 39 / 38.6 | 0.0010 | 27007 | 47 / 47 | 34 |

- The error estimate sits at its floor (0.001) in every run: no confident homozygous site had a discordant read. It is
  therefore uninformative on these data.
- ltrkin used 4 workers and about 70 MB of memory; Sniffles2 used 4 threads and about 150 MB.
- Mapping: at 40x, 99.8% (HiFi) and 98.2% (ONT) of primary alignments have MAPQ >= 20, and 99.5-100% fall in the
  simulated region.
- In primary-only BAMs, the single-piece rescue recovers 81-85% of the split empty-site reads, which make up 16-19% of
  all empty-site reads.

**Allele-level calls** (`p_F/p_E/p_S`, `pav`). Every planted site carries F on hap1.
- At 20x and 40x, `pav` = "present" at all 430 sites.
- `p_E >= 0.99` and `p_S >= 0.99` find every empty and solo site with no false positive (one HiFi 40x solo site has
  `p_S` just under 0.99).
- At 10x, 1-2 sites are called "absent" at coverage gaps.
- Summing over genotypes sidesteps the F/F-against-F/N weakness for presence/absence and for new insertions.

**Calibration and flags.**
- ltrkin's GQ is calibrated (pooled over the 6 full-BAM runs):

  | GQ bin | Observed error | Claimed error |
  |---|---|---|
  | 0-9 | 23.2% | 28.1% |
  | 10-19 | 2.6% | 4.7% |
  | 20-29 | 0.3% | 0.45% |
  | >= 30 | 0 of 1,328 calls wrong | |

- Sniffles2's GQ is uninformative: 20-29% of its calls are wrong at every GQ level.
- At 20x, ltrkin's PASS calls are right 98.2% (HiFi) and 96.9% (ONT) of the time, against 81-90% for `flank_depth_low`.
  Calls flagged `other_allele` (31-33 at 20x: "other" and hemizygous sites) are right 94-100% of the time.

## Failure modes observed
Each was traced by following the reads that truly carry an allele to their alignments (badread headers give each read's
haplotype and position; `benchmark/diagnose_genotype_sim.py`), and by replaying ltrkin's own per-read labels.

**ltrkin (round 4)**
1. **F/F against F/N is a count test with a flat prior.**
   - A haplotype without the site gives no reads, so F/N differs from F/F only in the number of informative reads,
     about mu against 2 x mu, with mu about 12 per haplotype at 20x. The two Poisson distributions overlap.
   - At 20x, 20/215 (HiFi) and 8/215 (ONT) planted F/F sites are called F/N, all at GQ <= 27, and 10/42 hemizygous
     sites are called F/F at ONT 20x. At 40x: 2-3 F/F and 0-4 hemizygous errors.
   - At these sites ltrkin's count matches the truly informative reads, and every such read is aligned at the site with
     MAPQ >= 20 (except at 13042, where 12 of 46 reads have MAPQ < 20).
   - The model is calibrated: observed/expected informative reads at true F/F sites is 1.01-1.05.
   - The HiFi-ONT gap in hemizygous recall (100% against 76% at 20x) is coverage noise: the ONT read set happened to
     have 7-9% more hap1 coverage inside the 42 hemizygous elements than inside F/F elements. Replacing ltrkin's depth
     estimate with the independently measured depth changes concordance by <= 0.5 points.
2. **ONT error deletions at anchors.** A read whose only anchor lies in a >= 50-bp sequencing-error deletion is dropped:
   1-3 genuine reads per ONT run at the 215 F/F sites, none in HiFi. Reads that span the site and keep a valid anchor on
   the other side are used through it. Related: the shredded-alignment case 12788 above.
3. **Coverage gaps at 10x.** Sites with no hap1 full reads are called N/N or E/N (5 calls at 10x, all flagged
   `flank_depth_low`). An LTRquest element whose LTRs are cut at exactly 7,000 bp (12573) is called F/F at 10x HiFi
   only: its true LTRs are longer, so solo-allele reads align through the "right LTR" as junction reads.
4. **Fixed:**
   - Solo alleles of elements with unequal LTRs (round 2; 6.6% of *P. supina* elements exposed).
   - Hemizygous deletions read as empty sites (round 1) or as full junction reads (round 2), fixed in round 3.
   - Neighbor deletions in the anchor zone (round 3), fixed in round 4.

**Sniffles2 2.8.1** (one run)
1. **No missing-haplotype allele.** All 42 hemizygous sites come out F/F.
2. **Unmatched records are written 0/0 with GQ 0.** No F/F call ever passes GQ >= 20. That rules out the 215 F/F, 42
   hemizygous and most "other" sites, which accounts for most of its low call rate.
3. **Short LTRs: both records match the same deletion.** The empty and solo records lie |dPOS| + |dSVLEN| = 2 x LTR + TSD
   apart. Sniffles2 matches an input SV to any candidate within min(1,000 bp, 250 x sqrt(length)), so when that
   distance is <= 1,000 bp both records take the empty deletion's genotype. This happened at exactly the 27 empty sites
   with 2 x LTR + TSD <= 1,000 bp, and at none of the others (S/E calls; both technologies).
4. **Solo position ambiguity.** 12-13 solo sites are called F/F, mostly young elements (8-9) with long LTRs (7 of 12 >=
   1.8 kb). With near-identical LTRs the aligner can place the solo deletion anywhere along the LTR, beyond the 1-kb
   matching window, even though the input record matched the planted solo exactly.
5. **Internal 0.5-2 kb deletions matched to the solo record** give 2-3 F/S calls at "other" sites.

## Proposals for ltrkin, with evidence
1. **N needs positive evidence, not only a low count.**
   - A genotype prior on N is a trade-off, not a fix. Re-scoring the round-4 runs with ltrkin's own likelihood
     (`benchmark/whatif_genotype_model.py`, which reproduces every run exactly):

     | Run | Variant | Concordance, all calls | Call rate, GQ>=20 | Recall F/F | Recall F/N | Precision F/N |
     |---|---|---|---|---|---|---|
     | HiFi 20x | as run | 95.3 | 70.2 | 90.7 | 100.0 | 71.8 |
     | HiFi 20x | N prior 0.05 | 96.3 | 79.8 | 99.1 | 66.7 | 93.5 |
     | HiFi 20x | N prior 0.01 | 95.3 | 83.5 | 99.5 | 54.8 | 95.8 |
     | ONT 20x | as run | 95.8 | 64.7 | 96.3 | 76.2 | 84.0 |
     | ONT 20x | N prior 0.05 | 93.0 | 80.2 | 100.0 | 42.9 | 100.0 |
     | HiFi 40x | as run | 99.5 | 83.3 | 99.1 | 100.0 | 96.2 |
     | HiFi 40x | N prior 0.01 | 96.5 | 89.1 | 100.0 | 64.3 | 100.0 |

     The prior levels are fixed values for a sensitivity range, not tuned.
   - The "other" reads now kept at hemizygous sites, reads crossing a deletion that covers the whole site, are positive
     evidence that one haplotype lacks the site. They could enter the likelihood as N evidence (25-122 per run at the 42
     hemizygous sites); the flank depth ltrkin already measures (`flank_ratio`) could too.
   - Until then, F/N rests on counts only; the allele-level `pav` call avoids the issue for presence/absence.
2. **Minor: ONT error deletions at a lone anchor.** These cost 1-3 reads per ONT run here. A size cut that separates
   them from structural deletions (the false cases were 1.7-16.7 kb; the dropped genuine read had a 78-bp error
   deletion) would need its own evidence; not tested.
3. **The error estimate stays at its floor** (0.001) when classes are well separated. It cannot see length-model
   problems, because "other" reads are excluded from it.
4. **More depth points** where elements cover little of a chromosome. Only 140 of the 400 points landed in covered
   sequence here; the estimate held (within 0.5x), but the F/F-against-F/N test is sensitive to its error.
5. **Done in rounds 2-4:**
   - solo length interval;
   - anchors inside >= 50-bp deletions are invalid;
   - junction reads need an aligned internal base;
   - reads crossing a deletion that reaches into the element count as "other", which restores the `other_allele`
     flag.

## Design

**Base sequence.** *P. supina* Ps4B:30,000,000-60,000,000 (30,000,001 bp; pericentromeric, no gaps) from
`assemblies/reference/supina.nuclear.fa`, with its 1,428 LTRquest elements (all with two LTRs; `ref_named` GFF3).
hap1 = the region unchanged (the reference).

**Planted sites** (`benchmark/sim_genotype_truth.py`, seed 1).
- Eligible: `depth=0`, neither containing nor inside another element (by coordinates), no partial overlap with another
  element, >= 50 kb from the region ends.
  - 920 elements are `depth=0` and not in a containment; 96 of them partially overlap another element (shared LTRs) and
    2 are too close to the region ends, leaving 822.
- A state is drawn for every eligible element: F 50%, E 25%, S 10%, H 10%, O 5% (O needs an internal region >= 1 kb).
- Events are then kept left to right when their footprint (element +- TSD; for H the whole deletion) starts >= 25 kb
  after the previous kept footprint.
- 430 sites are planted: F 215, E 108, S 44, H 42, O 21. The 392 eligible elements dropped by the spacing rule, the 508
  nested and the 96 overlapping elements stay full on both haplotypes (context, not scored); 87 context elements lie in
  or within 1 kb of a planted deletion and appear only in the call-change table.
- TSD = identical 4-6-mers on both sides (longest k). It was found at 275/430 sites (5 bp 231, 4 bp 38, 6 bp 6), and it
  equals LTRquest's TSD at all 236 planted sites where LTRquest reports one at offset 0,0.
- hap2 states. hap2 = 27,631,998 bp.
  - E removes the element and the right TSD copy (the element only, without a TSD).
  - S removes the internal region and the right LTR, so the left LTR stays between both TSD copies.
  - H removes the element plus U(3, 15) kb of each flank.
  - O removes U(500, 2,000) bp of the internal region, >= 100 bp from each LTR.
- The brief says solo = "keep one LTR and one TSD copy". LTR-LTR recombination leaves the solo LTR between both TSD
  copies (as in `tests/synth.py` and DESIGN.md), so both stay. The 5-bp difference is far below either tool's
  tolerance.
- Truth genotypes: F/F, F/E, F/S, F/N; O accepts F/N or F/F.

**Truth checks.**
1. By hand, two sites per state (`truth/check.txt`): coordinates, TSDs, the hap2 sequence across each junction against
   the expected flank + TSD + flank (E) or flank + TSD + LTR + TSD + flank (S), and the deleted lengths.
2. Independently, each hap2 junction window (+-max(3 kb, left LTR + 2 kb)) was realigned to hap1 (+-60 kb, minimap2
   asm5). Results:
   - 190/215 deletions are recovered exactly.
   - 20 solo deletions are recovered at the right length but shifted inside the LTR (equivalent: the solo LTR matches
     both LTRs).
   - 5 are not recovered, each explained by the sequence:
     - one element whose LTRs LTRquest cut at exactly 7,000 bp;
     - one whose right flank resembles its own 5' end;
     - two hemizygous deletions with repeats in their flanks;
     - one solo whose LTRs differ by a 6-bp indel.
3. `benchmark/test_sim_genotype_truth.py` (pytest, synthetic genome, 5 tests) checks exclusion of nested and
   overlapping elements, TSDs, each state's hap2 sequence, the spacing, the VCF records and a clean junction check.
4. A rebuild gives byte-identical outputs.
5. The read headers were checked against the alignments: 200/200 minus-strand reads align at their converted forward
   coordinates.

**Reads.** hap1 and hap2 were simulated separately at equal depth: 4 chunks x 5x per haplotype, 40x in total (exactly
20.00x of each haplotype). The 20x and 10x sets are nested read-name subsamples of the 40x alignments (`samtools view -s
42.5`, `42.25`).
- **HiFi-like:** badread 0.4.2 `--error_model pacbio2021 --qscore_model pacbio2021 --identity 30,3 --length 17000,5000`,
  with no adapters, junk, random reads, chimeras or glitches. Mean length 17.0 kb, N50 18.0 kb, median identity 99.90%.
- **ONT-like:** badread `--error_model nanopore2023 --qscore_model nanopore2023 --identity 95,99,2.5 --length
  15000,13000`, with the default adapters, 1% junk, 1% random reads, 1% chimeras and glitches. Mean length 15.0 kb,
  N50 22.7 kb, median identity 95.5% (4.4% of reads below 90%), net indel -74 bp per 10 kb.
  - These reads are noisier than the project's R10.4.1 SUP data (99.3%, -8 bp per 10 kb; lit_review section D) and
    longer (the project's ONT median read is 1-2 kb).
- **Not pbsim3 for HiFi, as briefed.**
  - pbsim3 3.0.5 caps `--accuracy-mean` at 0.99 for both `errhmm` and `qshmm`, and ERRHMM-SEQUEL holds accuracy bins of
    72-94% only (a CLR model). A request for 0.999 gave reads of 96.0% mean accuracy (SD 4.5%; 1.7% insertions, 1.5%
    deletions).
  - pbsim3 makes HiFi only from multi-pass subreads plus `ccs`, which is not installed and would cost roughly 10-20
    CPU-hours here.
  - Badread's own HiFi recipe (README: pacbio2021 models trained on Sequel IIe HiFi reads, identity 30,3) gives the
    requested accuracy.

**Alignment.** minimap2 2.31 `-ax map-hifi` / `-ax map-ont` against prebuilt indexes of the full *P. supina* assembly
(233 sequences, 703 Mb), so near-identical copies anywhere compete for reads. Read group `ID:sim SM:<tech>_d<depth>`;
`samtools sort` and `index`. Primary-only copies: `samtools view -F 0x904`.

**Genotyping.** `ltrkin genotype -r supina.nuclear.fa -a truth/region.gff3 -t 4 -v`, where `region.gff3` holds every
annotation line of the region's 1,428 elements in reference coordinates. All elements are genotyped; only the planted
ones are scored.

**Baseline: Sniffles2 2.8.1 `--genotype-vcf`.**
- Input: two symbolic DEL records per planted element:
  - empty (element + TSD; POS = the base before the element);
  - solo (internal + right LTR; POS = the last base of the left LTR), so the solo record matches the planted solo
    exactly.
- How 2.8.1 force-calls (source: `parallel.py` `GenotypeTask`, `genotyping.py`):
  - It first runs its own SV discovery in the region, keeping candidates that fail QC.
  - Each input SV is matched to the nearest discovered candidate of the same type with |dPOS| + |dSVLEN| <=
    min(1,000 bp, 250 x sqrt(shorter length)).
  - A matched record takes that candidate's genotype: binomial with error 0.05 (0/0), 0.5 (0/1) or 0.95 (1/1); GQ capped
    at 60.
  - An unmatched record is written 0/0 with GQ 0 when reads cover it, ./. otherwise.
  - It reads `SA` tags, so primary-only BAMs keep split-read evidence; ltrkin does not read `SA` tags.
- Mapping to ltrkin's alleles:
  - empty 0/0 + solo 0/0 = F/F (GQ = the lower of the two);
  - empty 0/1 = F/E; solo 0/1 = F/S;
  - 1/1 = E/E or S/S; both alt = S/E;
  - both ./. = no call.
  - F/N is impossible and counts as wrong.

**Metrics** (`benchmark/eval_genotype_sim.py`). Per technology x depth x BAM mode x tool, on the 430 planted sites:
- concordance, all calls = correct genotypes / planted sites, no GQ filter. No-calls count as wrong; ltrkin's N/N is
  written `./.` in its VCF and counts as a no-call.
- concordance, GQ >= 20 = correct / calls with GQ >= 20; call rate = calls with GQ >= 20 / planted sites;
- recall per truth class and precision per called genotype (`by_class.tsv`, `precision.tsv`, `confusion.tsv`);
- empty- and solo-allele detection (`allele_detection.tsv`);
- strata by length, age (`K2P_d` <= 0.005) and nearest other element (`strata.tsv`);
- context elements (`context.tsv`), GQ calibration (`gq_calibration.tsv`), flags (`flags.tsv`), depth check
  (`depth_check.tsv`).

## Commands
Everything runs through `benchmark/run_genotype_bench.sh OUTDIR [stages]`. The stages are truth, reads, align,
subsample, ltrkin, sniffles and eval; each step writes to a temporary name and is skipped when its output exists.
Environment: `ltrkin_bench` on PATH, `NUMPY_MADVISE_HUGEPAGE=0 OMP_NUM_THREADS=1`, at most 8 threads; ltrkin from
PATH (or `LTRKIN=<path to ltrkin>`).

```bash
B=<repo>/benchmark; O=<output directory>
export REF=<P. supina reference FASTA> GFF=<its LTRquest GFF3> REGION=Ps4B:30000000-60000000   # minimap2 indexes built on first use
setsid -f nohup $B/run_genotype_bench.sh $O > $O/logs/run.log 2>&1 < /dev/null       # all stages (~1.5 h, 8 threads)
# what the stages run:
python $B/sim_genotype_truth.py -f $REF -g <LTRquest supina gff3.gz> -r Ps4B:30000000-60000000 -o $O/truth --seed 1 --check
badread simulate --reference $O/truth/hap{1,2}.fa --quantity 5x --error_model pacbio2021 --qscore_model pacbio2021 \
  --identity 30,3 --length 17000,5000 --start_adapter_seq '' --end_adapter_seq '' --junk_reads 0 --random_reads 0 \
  --chimeras 0 --glitches 0,0,0 --seed <1000 + 100 x hap + chunk>                   # 4 chunks per haplotype
badread simulate --reference $O/truth/hap{1,2}.fa --quantity 5x --error_model nanopore2023 \
  --qscore_model nanopore2023 --identity 95,99,2.5 --length 15000,13000 --seed <1500 + 100 x hap + chunk>
zcat reads/<tech>.hap*.fq.gz | minimap2 -ax map-<tech> -R '@RG\tID:sim\tSM:<tech>_d40' ref/ref.map-<tech>.mmi - \
  | samtools sort -o bam/<tech>_d40.full.bam                                        # then samtools index
samtools view -b -s 42.5 bam/<tech>_d40.full.bam | samtools reheader <header with SM <tech>_d20> -   # 42.25 for 10x
samtools view -b -F 0x904 -o bam/<sample>.primary.bam bam/<sample>.full.bam
ltrkin genotype -r $REF -a $O/truth/region.gff3 -o ltrkin/<sample>.<mode> -t 4 -v bam/<sample>.<mode>.bam
sniffles --input bam/<sample>.<mode>.bam --genotype-vcf $O/truth/planted_sv.vcf --vcf sniffles/<sample>.<mode>.vcf -t 4
python $B/eval_genotype_sim.py -d $O -o $O/eval
# each ltrkin round after a code change (previous outputs moved to ltrkin_<round>/ and eval_<round>/ first):
$B/run_genotype_bench.sh $O ltrkin eval
python $B/compare_genotype_runs.py --before $O/eval_round3 --after $O/eval --sites 12928,12205,12555,13006,12788 -o $O/eval/round4_vs_round3
# analyses in this note:
python $B/diagnose_genotype_sim.py -d $O --run hifi_d20.full -o $O/eval/diag.hifi_d20.full.tsv   # per wrong call
python $B/whatif_genotype_model.py -d $O -o $O/eval/whatif.tsv
pytest $B/test_sim_genotype_truth.py
```

## Not done, and limits
- **Read simulator.** HiFi reads come from badread, not pbsim3 (reason above).
- **One replicate.** One seed and one read set per technology; the 20x and 10x sets are subsets of 40x, not independent.
  Differences of 1-2 points between runs are within replicate noise. The HiFi-ONT gap in hemizygous recall is coverage
  noise.
- **Thin strata.** The > 17 kb stratum has 6 sites and no empty site: 178 of the region's 196 elements of >= 17 kb are
  nested and were not eligible.
- **Nested sites.** No nested site was planted (by design), so empty or solo alleles of inner or outer nested elements
  are untested. Nested elements are scored only as F/F context.
- **Adjacent elements.** Planted events never touch a scored element directly. The neighbor-deletion effect was seen
  only at unscored context elements, and its frequency in real data is unmeasured.
- **Baselines.** Only Sniffles2 was run. SVJedi-graph, kanpig, cuteSV and the ad hoc caller v2 (DESIGN.md benchmark
  plan) were not.
- **ONT realism.** The ONT simulation follows the brief (95% identity, 15 kb mean). It is noisier and longer than the
  project's ONT data, so it is not a stand-in for C11/P3. 5x per haplotype (10x total) was the lowest depth tested.
- **Proposals not run in the tool.** Proposals 1 and 2 were not implemented or run in ltrkin; proposal 1's prior
  variants were evaluated by re-scoring only.
- **Real-data benchmarks** (zygosity against read phasing, presence/absence against assemblies) are separate items in
  DESIGN.md.
- **Thread budget.** Short single-threaded diagnostics ran alongside the 8-thread pipeline steps a few times.
