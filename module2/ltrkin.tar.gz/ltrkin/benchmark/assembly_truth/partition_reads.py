#!/usr/bin/env python3
"""Assign each read to the haplotype it aligns to best, from its separate alignments to hap1 and hap2.

Same principle as HipHap (github.com/jheinz27/hiphap): a read's score on a haplotype is the sum of minimap2 AS over
its primary and supplementary alignments; the higher score wins; exact ties (identical haplotypes there) are
assigned by the parity of a hash of the read name, so they split 50/50 and per-haplotype depth stays calibrated.
Reads aligned to one haplotype only go to it.
usage: partition_reads.py hap1.bam hap2.bam out_prefix   ->  out_prefix.hap1.names, .hap2.names, .stats
"""
import sys
import zlib

import pysam


def scores(path):
    d = {}
    with pysam.AlignmentFile(path, threads=8) as f:
        for x in f.fetch(until_eof=True):
            if x.is_unmapped or x.is_secondary:
                continue
            try:
                a = x.get_tag("AS")
            except KeyError:
                continue
            d[x.query_name] = d.get(x.query_name, 0) + a
    return d


s1, s2 = scores(sys.argv[1]), scores(sys.argv[2])
pre = sys.argv[3]
n = {"hap1": 0, "hap2": 0, "tie_hap1": 0, "tie_hap2": 0, "only1": 0, "only2": 0}
with open(pre + ".hap1.names", "w") as f1, open(pre + ".hap2.names", "w") as f2:
    for name in s1.keys() | s2.keys():
        a, b = s1.get(name), s2.get(name)
        if b is None:
            w, k = 1, "only1"
        elif a is None:
            w, k = 2, "only2"
        elif a > b:
            w, k = 1, "hap1"
        elif b > a:
            w, k = 2, "hap2"
        else:
            w = 1 + (zlib.crc32(name.encode()) & 1)
            k = f"tie_hap{w}"
        n[k] += 1
        (f1 if w == 1 else f2).write(name + "\n")
with open(pre + ".stats", "w") as fh:
    tot = sum(n.values())
    for k, v in n.items():
        fh.write(f"{k}\t{v}\t{v / tot:.4f}\n")
print(open(pre + ".stats").read(), file=sys.stderr)
