### Task 11: Simulation results and decisions

**Files:**
- Outside the repo: `benchmark_pav/plan3/sim/{tables/*.tsv, SIM_RESULTS.md}`, `benchmark_pav/dead_ends.md`.
- Repo:
  - always, `docs/DESIGN.md` 7.1, 7.4 and 7.6 (the outcome);
  - if a variant is adopted, `src/ltrpav/analysis/constants.py`, `tests/test_paint.py` and `tests/test_cli_analysis.py`;
  - if rule 7 does not confirm the test, `src/ltrpav/analysis/direction.py` (the rows' note) and
    `tests/test_direction.py`.

- [ ] **Step 1: Rescore with the final scoring code.** Rerun `eval_run.py` and `eval_ltrmix.py` on every run (LTRquest
  runs included), then `summarize.py`.
  - Run it detached: about 150 runs take more than 15 minutes.
  - Every `eval.json` must carry the same eval-script sha256s.
- [ ] **Step 2: Write `SIM_RESULTS.md`.** Every bar is judged by `RULES.md`, PASS or MISS.
  1. **The null.** Rule 1 and rule 2 for D_pav, dD, truth D and LTRmix's four D. Truth D against called D separates
     the statistic from genotyping.
  2. **Power.** Mean Z and SD per (f, ta), the probit f80, the f4-ratio against the true f, and the Z projected by locus
     count.
  3. **Painting, head to head** (view `roles`, recipients inferred, wrong recipients counted alike for both tools):
     AUROC, bp precision and recall, recall and precision by tract length (bp, and informative loci per tract), and the
     realized FDR.
  4. **Models and variants:** rules 4-6, applied as written.
  5. **Direction:** rule 7. State the predictions, what was observed, the posctl confirmation, false calls (default and
     bottleneck), ptlike, and D_dir against its null.
  6. **One-sided dropout:** D_pav's null and power under recipient dropout (DESIGN 7.1's claim), and the variants
     judged on the dropout nulls alone.
  7. **Genotypes:** rule 3, plus the LTRquest runs against their truth-annotated pairs.
  8. **LTRmix on one truth:** its D tests, painting, presence/absence accuracy and s, beside LTRpav's (tables only; the
     analysis is Plan 4).
  9. **Plan 2's open gaps.**
     - s: LTRpav's identity s and LTRmix's s against the true 0.36%.
     - D: rule 8.

     Untested causes become Plan 4 leads.
  10. **Realism:** the extended table, with each gap named and its effect on the results stated (density, outgroup
      conflict, state mix).
  11. **Decision 11:** `nodonor`'s null count and power, on their own; Task 14 sets the genus `zd` case beside them.
      The rule is not changed; the user decides decision 11 after Plan 3.
- [ ] **Step 3: Misses.** Each MISS gets a `dead_ends.md` entry: what, result, evidence, cause tested, what would change
  it. Investigate with truth D and the per-pair genotype scores; never change a bar or a rule.
- [ ] **Step 4: Record the decisions.**
  - Always edit DESIGN 7.1 and 7.4 (each variant: adopted, or "evaluated, not adopted" with the numbers), and 7.6 (rule
    7's outcome and its consequence).
  - If rule 7 did not confirm the test, change the direction rows' note in `analysis/direction.py` to "not validated by
    simulation (Plan 3)", and update the expected note in `tests/test_direction.py`.
  - If rule 5 adopts a variant, change the default constant and the tests' expected defaults.
  - Run the suite and the engine-key check, then commit:
    - on adoption, `"Make <variant> the painting default after the simulated null and power (Plan 3)"`;
    - otherwise, `"Record the simulated painting and direction outcomes (Plan 3)"`.
  - If `src/` changed (an adoption, or the direction note), take snapshot 2 for Tasks 13-16, and check that its engine
    fingerprints equal snapshot 1's. If only DESIGN changed, snapshot 1 stays: DESIGN is not in `src`.

---

