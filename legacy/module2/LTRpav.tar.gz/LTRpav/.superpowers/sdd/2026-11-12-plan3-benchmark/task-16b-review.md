# Re-review (fix round 1)

Scope: the changed text only. RESULTS.md 47f76d90 (115 lines) against the reviewed d9206daf (rebuilt in scratch
p3t16b-review/RESULTS.d9206daf.md; its sha256 matches), memo_ltrpav.md ade3cfa7, sim/memo.md b96a475e and
real/memo.md 8e3ac737 against the implementer's pre-fix copies (p3t16b/before_fix1/). No other file changed after the
review: FINAL.md is still 4fa8d033, the repo is still at a44f532 and the tree is clean.

**Bar lines unchanged.** A scripted comparison finds 33 bar lines in both versions, 21 PASS and 12 MISS, with identical
verdict and number cells. The only cell that changed is rule 4's label at :35 (M3). All 8 links resolve.

| Finding | Verdict | Where, and the check |
|---|---|---|
| I1 | ADDRESSED | RESULTS.md:10-12, "in 20 simulated sets without gene flow ... 0 against LTRmix D_ins's 18 of 20; McNemar p 8e-6" (SIM_RESULTS:415, 7.6e-6) |
| I2 | ADDRESSED | :17-21: +0.139 and +0.145, Z 3.16 and 3.20 (six/RESULTS.md:104, 108); SNP D +0.112, +0.052 and D_ins Z 4.57, 1.19 (same rows); the negative control MISS at 5 Mb and the swap at 10-20 Mb (stability table); 2 of 8, both nulls (SIM_RESULTS:83) |
| I3 | ADDRESSED | :15-16, "in the paintings with a known answer (B73 in the papers' view, sweet orange); two paintings with no known answer did (lead 1)". No B73 tract file in any view has a q ≤ 0.05 tract (recount) |
| I4 | ADDRESSED (⚠️ start time) | memo_ltrpav.md:201. The end of the breach is confirmed by the queue logs: queue.pause stops only new blocks (genotype_all.sh:9-10, 127). w1 ran six to 12:22:37 and logged "paused before genus"; w2 ran genus to 12:52:48 and logged "paused before edta"; w3 ran EDTA to 13:38:27. By flags that leaves 128 + 64-96 = 192-224 threads after 12:22 and 96 + 64-96 = 160-192 after 12:52, so the count was under 200 by 12:52 at the latest. The implementer's correction of "until 12:17" is right. The start "from 10:53" is the ledger's reading (progress.md:204-205). The logs cannot confirm it: this project's flag count was already ~160 from 08:18 (grid 64, w1 and w2 64, LTRquest `--threads 32`), and w3 only took LTRquest's 32 threads at 10:53; when the other project's ~64-96 threads started is not recorded (load 21-47 at 08:15, 182 at 10:53). Optional: "by 10:53 at the latest" or "by 12:20, when it was counted" |
| M1 | ADDRESSED | :14-15, AUROC 0.71 and tract recall 1.0-1.7 times chance (FINAL.md:95: 0.712; 1.3x, 1.7x, 1.6x, 1.0x); median 85 kb |
| M2 | ADDRESSED | :10-11, "a guide rather than a like-for-like null" (FINAL.md:27-28); :23-24, "0 on average" and "5-Mb blocks in real genomes, ~1 Mb in the simulations" (SIM_RESULTS:35) |
| M3 | ADDRESSED | :35, "≤ 1 of 30 nulls with a q ≤ 0.05 tract; excess over the decoy ≈ 0" (bars.tsv rows 23-25) |
| M4 | ADDRESSED | :52-53, "scaled to the real count of informative insertions (6 times), simulated power is still optimistic, because real genomes resolve fewer calls (0.46 against 0.76)" (2,036/337; SIM_RESULTS:618, 628) |
| M5 | ADDRESSED | :57-58 (FINAL.md:42, 19 PASS and 5 MISS rows) |
| M6 | ADDRESSED | :25-27 define AUROC; lead 8 (:105-109) explains the fallback and the trios; TIL18 was admitted for (TIL01, TIL25; Zd) on a 0.009 margin (genus/RESULTS.md:156-158). FOUR_LIST_NOTE is described correctly: direction.py:56 claims the dropout runs check saturation, and they do not (task-11c-review.md:14). Lead 10 (:111-115) glosses genotype_all.sh and `--identity` |
| M7 | ADDRESSED | :88-89, decoy and anydecoy better in 29-31 of 33-34 runs (SIM_RESULTS:306-308: decoy AUROC 30 of 33, precision 29 of 33; anydecoy 30 of 34, 31 of 34; lead 1 at :707); :113-114, the msprime seed note (task-2-report.md:203-204) |
| M8 | ADDRESSED | memo_ltrpav.md:179 and sim/memo.md:355 now read `> sim/rescore.nohup`; it is byte-identical (cmp) to sim/rescore/rescore.log; sim/rescore/nohup.out does not exist |
| M9 | ADDRESSED | memo_ltrpav.md:184 runs view, stats and paint (as real/memo.md:137-138) |
| Nit | ADDRESSED / declined | real/memo.md:319-321 now use env ltrpav's python (`PY=`). The DESIGN.md:873 separator was left unchanged to avoid a repo change after approval. Accepted |

**New issues.** None that blocks. One nit: lead 8 (:108-109) now says FOUR_LIST_NOTE concerns the direction test's
pattern counts, so it reads oddly under "Decision 11". It fits lead 3 (Direction).

**Length.** At 115 lines this is about two printed pages, not one. It still skims well: the message sits in the first
27 lines (purpose, three outcome items, terms), and below them come two verdict tables and a numbered list. To get
back toward one page without touching any bar line (about 8 lines saved):
- fold :57-58 into the :55 heading;
- move the FOUR_LIST_NOTE clause (:108-109) into lead 3;
- trim the glosses in leads 8 and 10 (:105-115) and lead 1's new sentence (:88-89).

Two groups of bar lines share one verdict each: the four rule-4 rows (:35-38, all PASS) and the three
"precision not below" rows (:41, :44, :47, all PASS). Merging either group would hide no verdict, but it would break
R3's one line per bar and the ledger ruling "grouping bars would hide verdicts", so I would not merge them.

**Assessment (fix round 1): Approved.** All 4 Important and 9 Minor findings are addressed, and every number the round
added matches its source. The two notes above (the I4 start time and the FOUR_LIST_NOTE placement) are optional.

---

# Task 16B review: Plan 3 closing records (6282541..a44f532 and the files outside git)

Read-only on benchmark_pav/, the repo and memo_ltrpav.md. Probes in
scratchpad/p3t16b-review (snapshot 2 via env.sh, one thread each): compare_papers reruns with 1baa28dc on
papers/views/main, main3 and stability/mm2, and with 47d2c20d on papers/views/main and main3 (1:39 max, 1.2 GB);
diff_prelim.py and diff_task15.py rerun to scratch outputs; the test file run against both script versions; a
recount of every real tract BED. The detached suite was not rerun (it finished: see the table).

## Spec compliance

| Requirement | | Evidence |
|---|---|---|
| R3: one page linking SIM_RESULTS and the six real result files | ✅ | RESULTS.md:5, 23, 53, 59, 61, 63, 71, 72; all 8 links resolve (scripted check) |
| R3: one line per bar, PASS or MISS; counts | ✅ | :27-42 (16 sim lines: 9 PASS, 7 MISS = SIM_RESULTS:47); :53-69 (17 real lines: 12 PASS, 5 MISS). Every line agrees with its source (table below) |
| R3: Plan 4 leads cover the brief's list and R3's eight items | ✅ | s/D gaps lead 6; `00++`/`00--` and population pulse lead 3; resolution lead 2; decoy cross-fitting lead 2 (answered: decoy held the null, bars.tsv rows 31-33); 264 mm and scaffolds lead 9; DFOIL-alt saturation and a non-empty control lead 3; `any` on CsA chr2 lead 2; LTRquest 3 of 3 lead 7; controls not separated lead 5; FOUR_LIST_NOTE lead 8; genotype_all.sh and `--identity` lead 10 |
| Leads cover the ledger's parked items | ❌ (one) | lastz tests, CLAUDE.md scrub, block-length leads, Task 12 M2/M3 (genotype_all.sh), Task 11a m1 (`--identity`) are in; Task 2 concern 4 ("Plan 4 CI note", progress.md:20) is not (M7) |
| Opening: plain, honest, states the fragile results | ❌ | :15-16 omit that D_pav does not separate the six-genome controls and that the negative control misses at the 5-Mb rule (I2); :9-11 put a simulated result in a sentence about real events without saying so (I1); :13-14 "in maize" is contradicted by lead 1's PT tracts (I3). No null is presented as a finding |
| PT/Zh unscored-tract statement (lead 1, :77-79) | ✅ | recount: six/views/all/tracts.PT.bed (sister TIL01, donor TIL18) 27 tracts at q ≤ 0.05, 85.1 Mb, smallest q 0.0370; genus/views/all/tracts.Zh.bed (TIL25; Zn) 20 tracts at q 0.0500, 197.1 Mb; no other real painting has one (stability/block/all_b* repeat PT's); neither genus/RESULTS.md (:175 covers p1, p2, ctrl, zd) nor six/RESULTS.md mentions them |
| Ledger "Residual M3": note fixed, rerun, only that note changed, sha recorded | ✅ | compare_papers.py:34-36, 1129-1136 (the whole diff against .task16a); my 1baa28dc rerun reproduces final_papers.tsv (0dfd2d1b), final_tables/ and final_ltrmix_crosscheck.tsv byte for byte; my 47d2c20d rerun gives 19016fae and differs only at line 16, column `note`; FINAL.md:14, 354 and real/memo.md:306 carry 1baa28dc |
| Test red, then green | ✅ | reproduced: 47d2c20d 1 failed, 18 passed (test_compare_papers.py:284); 1baa28dc 19 passed; red.out has one phase-4 entry; ruff (no cache) F/E9/B: compare_papers.py 8 findings, as 16A; test file and diff_task15.py clean; repo `ruff check` clean |
| control_main3 and final_vs_prelim.tsv changed only as stated | ✅ | 1baa28dc rerun = control_main3/ byte for byte (530df22f); 47d2c20d vs 1baa28dc on main3: line 16 note only ("40 of 2,041"); diff_prelim.py reproduces final_vs_prelim.tsv (eed94661), which differs from 16A's only at line 114; tallies as reported (78/25/6/4+45) |
| Ledger "Task 16A beside Task 15": stability reruns | ✅ | 1baa28dc rerun of mm2 = final_mm2_* byte for byte; diff_task15.py reproduces final_vs_task15.tsv f358b413 under env ltrpav's Python 3.12 and the default 3.10 alike; per view 29 changed (24 verdict, 4 note only, 1 item only: the pooled mechanisms rename) and 4 added, the same 33 rows in each view; no verdict change beyond "(prelim)"; 19 PASS, 5 MISS, 2 skipped in each; tables and cross-checks byte-identical to Task 15's |
| R4: DESIGN 12, 3-6 lines, exact values beside src defaults | ✅ | DESIGN.md:869-876 (6 lines of text); values equal sim/demography.json and calibration.tsv to the last digit; brackets equal popmodel.py:133-134 (Rates) and :72 (Demog.t_o) at 6282541 |
| DESIGN 12 matches SIM_RESULTS | ✅ | PASS 9, MISS 7; 0 of 30; not calibrated; dD not demonstrated; no variant adopted; direction not validated |
| R4: memo Plan 3 section | ✅ with I4 | memo_ltrpav.md:153-210. Dates match the commits (3bf2833 11-12 15:22, 6282541 11-14 15:43). Snapshots as R4. Versions checked in the envs (Python 3.12.16, msprime 1.4.2, tskit 1.0.4, numpy 2.5.4, scipy 1.18.1, pysam 0.24.1, minimap2 2.31-r1302, lastz 1.04.60, bcftools 1.24, pytest 9.2.0, ruff 0.17.4; the LTRquest clone is at 5042a1e). Calibration exact. Wall times checked against the .time files (genus 4:35:32, citrus 42:17, EDTA 2:01:48, cap5k 3:17:47, stats 19:55.67, paint 0:47). Resume line at :156. Plan 1-2 sections unchanged |
| Could Plan 3 be rerun from the memo | ✅ | yes, with the sub-memos it names (sim/memo.md, real/memo.md); the scripts pin their own snapshots (six/run_view.sh:12, papers/run_final_view.sh:13, genotype_all.sh:23), so the block's first `. common/env.sh` does not leak into them. Small gaps M8, M9 |
| R4: commit | ✅ | a44f532: author and committer cwb14 (the global identity), message is the subject alone, docs/DESIGN.md only, no src; tree clean |
| R4: suite | ✅ (the controller's to read) | p3t16b/suite: suite.exit 0 at 19:39:18; 1,280 dots, no F or E (the log prints no summary line) |
| Overlap residue | ✅ | every sha cited in FINAL.md, real/memo.md, dead_ends.md, memo_ltrpav.md and the report matches the file on disk; 0fb466e2 and c2103bd3 appear in no record; one Task 16 section in each file; no papers/__pycache__; the other copy's files are only in scratch p3t16b/mine/ |
| Provenance of the real LTRquest annotations (memo :163, :169 "LTRquest 5042a1e annotations") | ⚠️ | not checked: made before Plan 3 |

## RESULTS.md line check

| Line | Bar or claim | Source | |
|---|---|---|---|
| 27 | rule 1: 0 of 30, CI 0-0.12 | bars.tsv row 1 (CP 0-0.1157); SIM_RESULTS:57 | agree |
| 28 | rule 3: P 0.997, E 0.997 | bars.tsv rows 20-22 (0.997096, 0.996762) | agree |
| 29 | rule 4 `main`: 0 of 30 | bars.tsv rows 23-25 | agree (label M3) |
| 30 | rule 4 `any`: 0 of 30; 0 of 20 | rows 26-30 | agree |
| 31 | rule 4 `decoy`: 0 of 30 | rows 31-33 | agree |
| 32 | rule 4 `anydecoy`: 0 of 30; 0 of 20 | rows 34-38 | agree |
| 33 | `any` FDR: no tract in 36 | row 39 (FAIL) | agree |
| 34 | `any` recall: 0 of 42 usable | row 40 | agree |
| 35 | `any` precision: vacuous PASS | row 41 | agree |
| 36 | `decoy` FDR: no tract | row 42 | agree |
| 37 | `decoy` recall: 0 of 36 usable | row 43 | agree |
| 38 | `decoy` precision: vacuous PASS | row 44 | agree |
| 39 | `anydecoy` FDR: 0 of 21 false, bound 0.16 | row 45 (0.161) | agree |
| 40 | `anydecoy` recall: 1 of 42, p 0.5 | row 46 | agree |
| 41 | `anydecoy` precision: 1 usable pair | row 47 | agree |
| 42 | rule 7: 2 of 8, both nulls | row 50; SIM_RESULTS:83 | agree |
| 44-47 | SD 0.72 (0.57-0.96); 3.14; dD 1 of 30; 10 of 36; 6 times (2,036/337); 0.46 vs 0.76 | bars.tsv rows 11-12; SIM_RESULTS:94, 157, 178, 628 | numbers agree; the "so" does not follow (M4) |
| 53 | maize D_pav +0.290, Z 7.39, 0 of 60 | final_papers.tsv primary row (+0.2898, 0 of 30 + 0 of 30); FINAL.md:88 | agree |
| 54 | windows r 0.26-0.38, p 0.001, 16 rows | FINAL.md:94 | agree |
| 55 | chromosomes by painting, exact, 1/120, 2 rows | FINAL.md:93 | agree |
| 56 | by class share: chr4, 5, 9, MISS | FINAL.md:93, 147 | agree |
| 57 | ZmPRR37a MISS | FINAL.md:96 | agree |
| 58 | 52 regions p 0.37-0.39, MISS | FINAL.md:100 | agree |
| 59 | PT > B73 +0.139, Z 3.16 (2.92 at 10 Mb) | six/RESULTS.md:104; stability table | agree |
| 60 | TIL11 = TIL01 +0.145, Z 3.20, MISS (2.80) | six/RESULTS.md:108; stability table | agree |
| 61 | genus +0.480, Z 6.36 | genus/RESULTS.md:66 | agree |
| 62 | genus control −0.070, Z −0.68 (D_ins Z 3.26) | genus/RESULTS.md:67 | agree |
| 63-66 | CsB tracts 99, 51, 75, 82% | citrus table (0.991, 0.513, 0.753, 0.820) | agree |
| 67 | CsA chr2 34% (95% with `any`) | citrus 0.340; c2_any 0.9512 | agree |
| 68 | k1 +0.45, Z 2.61, 29 informative | citrus (21 / 8) | agree |
| 69 | k2 −0.12, Z −0.54, 34 informative | citrus (15 / 19) | agree |
| 71-73 | EDTA +0.305, Z 5.94; Z 6.0-8.4; no maize bar row changes with route or cap | edta/RESULTS.md:19; stability table (6.04-8.39; 19/5 in every route and cap) | agree |
| 9-11 | Z 6.4-16.9; at most 3.14; 0 vs 18 of 20, p 8e-6 | 7.39, 6.36, 16.85; SIM_RESULTS:94, 415 (McNemar 7.6e-6) | numbers agree; framing I1 |
| 12-14 | 4 of 5 long tracts (1.7-23.8 Mb); 85 kb; no certified tract | citrus; FINAL.md:95 (85.1 kb) | disagree on "in maize" (I3); wording M1 |
| 15-16 | controls Z 3.16, 3.20; direction not validated | six/RESULTS.md; SIM_RESULTS:83 | numbers agree; omission I2 |
| 77-99 | leads 1-10 | SIM_RESULTS:134, 241, 299, 499, 566, 601, 710, 727; stability/RESULTS.md:163; six/RESULTS.md:29; genus/RESULTS.md:133; citrus k1; ledger | every number agrees |

## Strengths

- Every bar line and every number in the leads traces to its source; the counts are right.
- The residual M3 fix is exactly scoped: one note, test first, and every downstream file (final_papers.tsv, control_main3,
  final_vs_prelim.tsv, the stability tables) reproduces byte for byte from the recorded commands.
- diff_task15.py compares item names, so the renamed mechanisms row is counted; its output does not depend on the Python
  version.
- The overlap left nothing inconsistent: hashes, mtimes and single sections all agree, and the correction of 0fb466e2 in
  the report is accurate.
- The PT and Zh certified tracts were found by checking, not assumed, and are labeled unscored.
- DESIGN 12 gives the calibration values to the last digit beside the drafting defaults, in 6 lines.

## Issues

### Critical
None.

### Important

**I1. RESULTS.md:9-11, a simulated result inside a sentence about real events.** "0 against 18 of 20 runs; paired p
8e-6" is the simulated one-sided dropout nulls (SIM_RESULTS:415), but the sentence's subject is "all three real admixture
events", and the genus control (a real case where D_ins failed) makes a real-data reading plausible. Why it matters: the
user reads this sentence first. Fix: "...and, in 20 simulated genome sets without gene flow where one sister was less
completely annotated, gave no false signal (0 against LTRmix D_ins's 18 of 20; McNemar p 8e-6)".

**I2. RESULTS.md:15-16, the opening omits the controls' failure to separate.** It says the controls' verdicts "change
with analysis choices", but not that D_pav gives the positive and negative controls the same excess (+0.139, +0.145)
where SNP D (+0.112, +0.052) and LTRmix's D_ins (Z 4.57, 1.19) separate them, nor that the negative control MISSes at the
5-Mb rule (six/RESULTS.md:14, 127; FINAL.md:301). That fact is only in lead 5. Why it matters: the brief requires it, and
"change with analysis choices" reads as noise around a threshold rather than a test that cannot tell the two apart. Fix:
"3. D_pav does not tell the six-genome controls apart: both read +0.14 (Z 3.16 and 3.20), where SNP D and LTRmix's D_ins
separate them; at the 5-Mb rule the negative control misses, and with 10-20-Mb blocks the two swap verdicts. The
direction test is not validated (its positive control read its prediction in 2 of 8 runs, both nulls)."

**I3. RESULTS.md:13-14 against :77-79, "in maize" is contradicted on the same page.** "It certified no tract at a 5%
false discovery rate in maize or sweet orange", but PT is highland maize and its painting in six/views/all certifies 27
tracts at q ≤ 0.05 (85.1 Mb), as lead 1 says. Why it matters: a reader who knows PT is maize finds the page
contradicting itself. Fix: "...in the paintings with a known answer (B73, sweet orange); two paintings with no truth did
(lead 1)".

**I4. memo_ltrpav.md:201, the thread-ceiling gotcha records compliance where the ledger records a breach.** "this
project ran up to ~160 threads on the weekend beside poa_synthesis's ~64-96 (combined <= 200), and queue.pause ... held
the queue to stay under it". The ledger (progress.md:205, 12:20) says the combined use was ~225-255, over the ceiling of
200, because the other project was not counted when w3 started at 10:53; queue.pause then stopped new blocks while the
running ones finished (six 12:22, genus 12:52, EDTA 13:38) and was removed at 13:40 (progress.md:206, 216). Why it
matters: R4 asks for this gotcha, and its lesson (count every project before adding threads) is lost if the memo says
the limit held. Fix: "...this project ran ~160 threads beside poa_synthesis's ~64-96, ~225-255 combined, over the
weekend ceiling of 200, because the other project was not counted when w3 started (10:53); queue.pause (12:17-13:40)
stopped new blocks while the running ones finished; count every project before adding threads."

### Minor

- **M1. RESULTS.md:12-13.** "maize's ~10-kb tracts, whose informative insertions lie 85 kb apart": the 85 kb is B73's
  genome-wide median spacing, not a property of the tracts, and "not found" carries no statistic. Fix: "maize's ~10-kb
  tracts, against informative insertions a median 85 kb apart (element AUROC 0.71; tract recall 1.0-1.7 times chance)".
- **M2. RESULTS.md:9-10, 18-20.** "lineage sorting alone gives 0" should be "0 on average". "5-Mb blocks" holds for the real
  genomes only: the simulated nulls used ~0.96-Mb blocks (SIM_RESULTS:35), and FINAL.md:27-28, 269 calls them "a guide
  rather than a like-for-like null" (for sweet orange "a reference"). Fix: add "(a guide, not a like-for-like null)"
  after "60 simulated sets", and "5-Mb blocks in real genomes, ~1 Mb in the simulations" in Terms.
- **M3. RESULTS.md:29.** The label "(no tract at q ≤ 0.05)" is not rule 4's bar, which is at most 1 of 30 nulls with
  such a tract and a mean excess within 2 SE of 0 (bars.tsv rows 23-25). Fix: "(≤ 1 of 30 nulls with a q ≤ 0.05 tract;
  excess over the decoy ≈ 0)".
- **M4. RESULTS.md:45-47.** "real genomes give 6 times the informative insertions but resolve fewer (0.46 against 0.76),
  so simulated power is optimistic": six times the loci would raise power, so the "so" does not follow. SIM_RESULTS:618
  says the locus-count projection is optimistic. Fix: "scaled to the real count of informative insertions (6 times),
  simulated power is still optimistic, because real genomes resolve fewer calls (0.46 against 0.76)".
- **M5. RESULTS.md:49.** "12 PASS, 5 MISS" counts lines (the chromosome claim's two readings as two lines; the 16 window
  rows as one), while FINAL.md counts 19 PASS and 5 MISS rows. Fix: one clause saying that the five DESIGN 10.3 claims
  are six lines here because the chromosome claim has two readings.
- **M6. RESULTS.md:95-99.** Names a biologist cannot read: FOUR_LIST_NOTE, the trio notation "TIL01, TIL25; Zd",
  genotype_all.sh, `--identity`. Fix: a few glossing words each (for example "the note that lists the fallback's
  discovery genomes", "the genotyping queue's script").
- **M7. RESULTS.md:77-99, lead coverage.** Missing: the ledger's parked Task 2 concern 4 (progress.md:20; task-2-report.md:203-204:
  two tests depend on msprime's random streams and may pick another case seed under other msprime builds), and SIM_RESULTS lead 1's
  any-q advantage of `decoy` and `anydecoy` (higher AUROC and bp precision in 29-31 of 33-34 runs), a candidate default
  for Plan 4. Fix: add both to leads 10 and 1.
- **M8. memo_ltrpav.md:179.** The rescore line writes `> sim/rescore/nohup.out`; the run's nohup log is
  sim/rescore.nohup (progress.md:215; the line was copied from sim/memo.md:355). Fix: correct the path in both memos.
- **M9. memo_ltrpav.md:184.** Only the `stats` step of a six-genome view is shown; `view` precedes it and `paint` follows
  (real/memo.md has them). Fix: "run_view.sh main view; run_view.sh main stats B73,TIL01,TIL18; run_view.sh main paint
  B73,TIL01,TIL18".
- **Nit.** DESIGN.md:873 writes the exact replace_mean as "13,538.154280338664" while the memo (:166) and demography.json
  have no separator. real/memo.md:319-320 call bare `python` outside env.sh (3.10 here; both scripts are standard-library
  only and reproduce the same bytes, checked).

## Assessment

**Needs fixes.** Text only, with no rerun: I1-I3 in the opening of RESULTS.md and I4 in memo_ltrpav.md, plus the Minors.
Every number, file and hash checked is right, and the compare_papers fix and the stability reruns reproduce exactly. The
16B concerns ruling accepts the 99-line page only if every line is accurate, and lines 9-16 are not yet.
