# Review, Task 11 Part Q

### Spec Compliance
- ✅ Skip record matched for exactly recipient, sister, donor (eval_run.py painting_skip); wording matches snap paint.py:642 and run findings.txt (168-170); "Painting: " summary form also accepted. Tests cover other sister, donor, recipient, non-skip, age-gradient line.
- ✅ Skipped: n_tracts 0, n_tracts_q05 0, FDR 0 of 0, posterior-based fields NA with "painting skipped by LTRpav: <why>"; stats rows kept.
- ✅ No record plus missing file still raises "missing input" (tests, both paint_section and roles view).
- ✅ Live eval_run.py/test_eval_run.py sha256 equal the package's new hashes. Atomic install claimed (not re-verifiable).
- ⚠️ Did not rerun tests or the real pc_null_r1 check; relied on the report.

### Design points
- accuracy dict with NA fields plus tract_fdr_q05 0 of 0: agree. summarize.py sums get(a,"tract_fdr_q05","n_false"/"n_called") with `or 0` (lines 826-827, 929-930) and q05() (858-863) returns NO_Q05 when q05.n_called is falsy; a NA there gives None, handled. A single NA would drop the 0 of 0 from the pooled FDR, which the ruling says to record.
- Skip record over file presence: agree. posterior.A1.tsv holds all of A1's trios, so a file can exist while this trio was skipped; test_skip_record_beats_a_file_that_holds_another_trio covers it. The stats n_tracts contradiction check guards against a false excuse.

### Risks checked
- Scope excuse: regex anchors on all three names (re.escape, ^...$); safe in all directions.
- Rule 4 nulls: summarize selects nulls by kind (null), posctl_null separately (line 518); unaffected.
- Wrong-recipient skipped painting: head_to_head's wrong branch overwrites accuracy with recall 0 (consistent with "no tract called").

### Strengths
Minimal change at one seam, both callers covered; strict scope match; fail-fast kept; contradiction guard; tests include negatives.

### Issues
- Critical: none. Important: none.
- Minor: eval_run.py ~line 625: true_fractions[rr] KeyError if a skipped recipient is absent from design; same as the unskipped path, so no regression.
- Minor: report notes pc_null_r1/r2 need a rescore; old eval.json files carry the old sha.

### Assessment: **Task quality:** Approved. Matches the binding ruling, both design points are sound, and summarize.py handles the new shape.
