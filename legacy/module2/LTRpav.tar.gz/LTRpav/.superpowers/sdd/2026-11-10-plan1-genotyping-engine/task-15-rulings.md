# Task 15 — controller rulings (bind as much as the brief; they override it where they conflict)

1. PairContext fields: a: Sample, b: Sample, a_fa: Fasta, b_fa: Fasta, a_elements: list[Element],
   b_elements: list[Element] | None, outdir: Path, threads: int; read-only property `workdir` = outdir / "work".
2. The unordered-pair cache key is the two labels sorted lexicographically (not sheet order): whole-genome (W) routes cache
   raw blocks at workdir/anchors/<X>__<Y>.<route>.raw.npz with X < Y; the other direction loads them and applies
   blocks.swap_blocks (A/B index lists swapped accordingly).
3. Route protocol: `name: str`; `raw_blocks(ctx) -> np.ndarray` (BLOCK_DTYPE, unchained; A indices follow ctx.a_fa
   fai order, B indices ctx.b_fa fai order). `get_route(spec)`: "mm2" -> Mm2Route(); "paf:<dir>" -> PafRoute(Path(dir));
   any other spec -> ValueError naming the known routes (later tasks add fastga, flank-mm2, flank-blast, hybrid).
4. Mm2Route:
   - B index built once per B FASTA: if `shutil.which("minimap2")`: `minimap2 -x asm20 -t <threads> -d
     <workdir>/anchors/<B label>.asm20.mmi <B fasta>` (reuse when its checkpoint marker matches the FASTA checksum);
     else `mappy.Aligner(fn_idx_in=<fasta>, preset="asm20")`. Load with
     `mappy.Aligner(fn_idx_in=<mmi>, preset="asm20", best_n=constants.MAPPY_BEST_N)`.
   - A is read in chunks of MM2_CHUNK + MM2_OVERLAP stepping MM2_CHUNK through `Fasta.fetch` in the MAIN thread
     (pysam handles are not thread-safe); chunks > 50% N are skipped; mapping runs in a ThreadPoolExecutor(threads)
     with one mappy.ThreadBuffer per thread.
   - Chunk-core rule (from Task 10 review): a hit is kept only if its A start (chunk_start + q_st) lies in the chunk's
     core [chunk_start, chunk_start + MM2_CHUNK); the last chunk's core runs to the sequence end.
   - Each kept hit becomes a block: a = [chunk_start + q_st, chunk_start + q_en), b = [r_st, r_en), strand +1/-1,
     matches = mlen, alen = blen.
5. Same-diagonal containment collapse (from Task 10 re-review), added to chain.py `chain_blocks` right after the exact
   duplicate collapse: within a (a_chrom, b_chrom, strand) group, drop block Y when some other block X has
   X.a_start <= Y.a_start, Y.a_end <= X.a_end, X.b_start <= Y.b_start, Y.b_end <= X.b_end and the diagonal offsets
   agree within CHAIN_OVERLAP (plus strand: |(Y.b_start - Y.a_start) - (X.b_start - X.a_start)| <= CHAIN_OVERLAP;
   minus strand: |(Y.b_end + Y.a_start) - (X.b_end + X.a_start)| <= CHAIN_OVERLAP). Log the count at DEBUG on
   ltrpav.chain. Must be O(n log n) or close (a sweep over a_start with an active set), never all-pairs.
   Tests in tests/test_chain.py: a left-truncated contained copy (the Task 10 re-review probe E case: A[96000,106000)
   plus its copy A[100000,106000) on the same diagonal) gives one chain with margin 1.0; a tandem copy on another
   diagonal is NOT collapsed and still lowers the margin.
6. PafRoute(dirpath): reads <dir>/<A>__<B>.paf or .paf.gz (A = PAF column 1) or <dir>/<B>__<A>.paf[.gz] (read with
   swap=True); neither present -> FileNotFoundError naming both paths.
7. checkpoint.py as the brief; `mark_done` writes the .done.json atomically (temp file + os.replace) and last;
   `stage_key` hashes canonical JSON of (stage, inputs, params, ltrpav.__version__); `file_checksum` caches by
   (absolute path, size, mtime_ns) in a JSON file and streams sha256 in 8-MB blocks.
8. anchor_pair(ctx, route) -> (blocks, a_names, b_names, d): cache at workdir/anchors/<A>__<B>.<route.name>.npz with a
   checkpoint marker keyed by the FASTA checksums (plus the elements file checksum for routes that read elements) and
   route params; on a hit, load and return (d recomputed from the loaded blocks: d = 1 - sum(matches)/sum(alen),
   nan if empty). Otherwise raw -> chain_blocks -> net_blocks -> save -> mark_done.
