"""Command line (ltrpav.cli): `ltrpav run` end to end on three toy genomes (A and B annotated, C genotype-only),
a rerun that skips every stage, the single-stage commands, and the fail-fast errors."""
from __future__ import annotations

import gzip
import hashlib
import importlib
import json
import logging
import os
import random
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, replace
from pathlib import Path

import pysam
import pytest

import toy
from conftest import needs_lastz
from ltrpav import __version__, checkpoint, cli
from ltrpav.annotation.gff3 import write_gff3
from ltrpav.cli import anchor_main, genotype_main, main, merge_main
from ltrpav.elements import Element, make_eid, read_elements
from ltrpav.samples import Sample

SEED = 7
CASES = ["P", "E", "S", "T", "D_left", "G", "nested_E"]
LABELS = ("A", "B", "C")
PAIRS = ("A__B", "A__C", "B__A", "B__C")  # (annotated A, any other B), sheet order
OUTPUTS = ("loci.tsv", "pav_matrix.tsv", "qc.tsv", "pav.vcf.gz", "pav.vcf.gz.tbi", "pav.unplaced.tsv",
           *(f"{x}.pav.{ext}" for x in LABELS for ext in ("gff3", "bed")), "manifest.json")


@dataclass
class World:
    """Three toy genomes in `dir` (C's FASTA in the read-only directory C/) and their samples sheet; the
    annotated elements as the run names them; the expected states in (A, B, C) of every locus, by its first
    member's eid; B's element that A lacks, and the 1-based A position of the target site (TSD) it lacks it at."""

    dir: Path
    sheet: Path
    elements: dict[str, list[Element]]
    expect: dict[str, tuple[str, str, str]]
    b_only: Element
    a_site: int


def element(label: str, name: str, seqid: str, start: int, length: int, ltr: int) -> Element:
    """An element of genome `label`, 1-based inclusive from `start`, with `ltr`-bp LTRs and TSD toy.T."""
    end = start + length - 1
    return Element(genome=label, eid=make_eid(label, seqid, start, end), name=name, seqid=seqid, start=start,
                   end=end, strand="+", ltr_left=(start, start + ltr - 1), ltr_right=(end - ltr + 1, end),
                   tsd=toy.T, k=0.0, family=None, superfamily=None, clade=None, confidence=None)


def make_world(d: Path, seqids: tuple[str, str, str] = ("seqA", "seqB", "seqC")) -> World:
    """A and B: toy.build_pair over CASES, then a segment where only B holds an element (A: L T R; B: L T e T R).
    A is annotated with build_pair's elements; B with its copies of the P case's element and of nested_E's host
    (without the child), and its own element. C (genotype-only) is B with 0.5% substitutions."""
    sid = dict(zip(LABELS, seqids))
    rng = random.Random(SEED)
    pair = toy.build_pair(rng, CASES)
    draw = random.Random(SEED)
    built = [toy.case(name, draw) for name in CASES]  # build_pair draws its cases first, in order: these
    a_els = [replace(e, genome="A", eid=make_eid("A", sid["A"], e.start, e.end), seqid=sid["A"])
             for e in pair.elements]
    expect = {make_eid("A", sid["A"], e.start, e.end): ("P", pair.expect[e.eid], pair.expect[e.eid])
              for e in pair.elements}
    b_els = []
    off_a = off_b = toy.SPACER  # each case's 0-based start in A and in B
    for name, c in zip(CASES, built):
        if name in ("P", "nested_E"):  # B holds the element (nested_E: the host, without its child)
            h = next(e for e in c.elements if e.level == 0)
            ltr = h.ltr_left[1] - h.ltr_left[0] + 1
            length = h.end - h.start + 1 - sum(e.end - e.start + 1 + len(toy.T2) for e in c.elements if e.level)
            be = element("B", f"{name}.b", sid["B"], off_b + h.start, length, ltr)
            b_els.append(be)
            a_seq, b_seq = pair.a[off_a + h.start - 1:off_a + h.end], pair.b[be.start - 1:be.end]
            if name == "P":  # B's copy carries 1% substitutions
                assert len(a_seq) == len(b_seq) and sum(map(str.__eq__, a_seq, b_seq)) > 0.95 * len(a_seq)
            else:  # B's host: A's LTRs at both ends
                assert b_seq[:ltr] == b_seq[-ltr:] == a_seq[:ltr]
        off_a += len(c.a) + toy.SPACER
        off_b += len(c.b) + toy.SPACER
    assert (off_a, off_b) == (len(pair.a), len(pair.b))  # build_pair's layout
    flank_l, flank_r = toy.rand_seq(toy.FLANK, rng), toy.rand_seq(toy.FLANK, rng)
    e, ltr, _ = toy.make_element(rng, 400, 4000)
    tail = toy.rand_seq(toy.SPACER, rng)
    a = pair.a + flank_l + toy.T + flank_r + tail
    b = pair.b + flank_l + toy.T + e + toy.T + flank_r + tail
    b_only = element("B", "b_only", sid["B"], len(pair.b) + toy.FLANK + len(toy.T) + 1, len(e), ltr)
    assert b[b_only.start - 1:b_only.end] == e
    b_els.append(b_only)
    expect[b_only.eid] = ("E", "P", "P")
    c = toy.mutate(b, 0.005, rng)

    toy.write_fasta(d / "A.fa", {sid["A"]: a})
    toy.write_fasta(d / "B.fa", {sid["B"]: b})
    toy.write_fasta(d / "C" / "C.fa", {sid["C"]: c})
    write_gff3(a_els, d / "A.gff3")
    write_gff3(b_els, d / "B.gff3")
    sheet = d / "samples.tsv"
    sheet.write_text("label\tfasta\tannotation\nA\tA.fa\tA.gff3\nB\tB.fa\tB.gff3\nC\tC/C.fa\t.\n")
    (d / "C").chmod(0o555)  # read-only: C's FASTA index must go to the run's work/fai
    return World(d, sheet, {"A": a_els, "B": b_els}, expect, b_only, len(pair.a) + toy.FLANK + 1)


def read_tsv(path: Path) -> list[dict[str, str]]:
    lines = path.read_text().splitlines()
    head = lines[0].split("\t")
    return [dict(zip(head, ln.split("\t"), strict=True)) for ln in lines[1:]]


def loci_by_first(out: Path) -> dict[str, dict[str, str]]:
    """loci.tsv rows by the locus's first member eid (sheet order)."""
    return {next(r[f"{x}_eid"] for x in LABELS if r[f"{x}_eid"] != "."): r for r in read_tsv(out / "loci.tsv")}


def qc_values(out: Path) -> dict[tuple[str, str], str]:
    return {(r["scope"], r["metric"]): r["value"] for r in read_tsv(out / "qc.tsv")}


def outputs(out: Path) -> dict[Path, bytes]:
    """Every file under `out` but manifest.json and the work directory: {relative path: bytes}."""
    return {p.relative_to(out): p.read_bytes() for p in sorted(out.rglob("*"))
            if p.is_file() and p.name != "manifest.json" and p.relative_to(out).parts[0] != "work"}


def vcf_text(out: Path) -> str:
    with gzip.open(out / "pav.vcf.gz", "rt") as fh:
        return fh.read()


def sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@pytest.fixture(scope="module")
def world(tmp_path_factory):
    d = tmp_path_factory.mktemp("world")
    yield make_world(d)
    (d / "C").chmod(0o755)


@pytest.fixture(scope="module")
def first(world, tmp_path_factory):
    """`ltrpav run` on the world: (outdir, argv)."""
    out = tmp_path_factory.mktemp("run") / "out"
    argv = ["run", "--samples", str(world.sheet), "--outdir", str(out), "--threads", "2"]
    assert main(argv) == 0
    return out, argv


@pytest.fixture
def mini(tmp_path):
    """A (annotated: one element) and B, unrelated random 6-kb genomes: enough for the checks made before any
    alignment, and for a run whose one pair aligns nowhere. Returns (directory, samples sheet)."""
    rng = random.Random(1)
    toy.write_fasta(tmp_path / "A.fa", {"chr1": toy.rand_seq(6000, rng)})
    toy.write_fasta(tmp_path / "B.fa", {"chr1": toy.rand_seq(6000, rng)})
    write_gff3([element("A", "e", "chr1", 1001, 1000, 100)], tmp_path / "A.gff3")
    sheet = tmp_path / "samples.tsv"
    sheet.write_text("label\tfasta\tannotation\nA\tA.fa\tA.gff3\nB\tB.fa\t.\n")
    return tmp_path, sheet


# ---------------------------------------------------------------- ltrpav run


@needs_lastz
def test_run_toy_three_genomes(world, first):
    out, argv = first
    for name in OUTPUTS:
        assert (out / name).is_file(), name
    for pair in PAIRS:
        assert (out / "pairs" / f"{pair}.calls.tsv.gz").is_file(), pair
    assert sorted(p.name for p in (out / "work" / "elements").glob("*.tsv")) == ["A.tsv", "B.tsv"]
    # C's directory is read-only: its index was built in the run's cache, not beside it
    assert len(list((out / "work" / "fai").glob("*.C.fa.fai"))) == 1
    assert not (world.dir / "C" / "C.fa.fai").exists()

    m = json.loads((out / "manifest.json").read_text())
    assert (m["version"], m["command"]) == (__version__, ["ltrpav", *argv])
    assert m["code"] == {s: checkpoint.stage_fingerprint(s) for s in checkpoint.STAGE_MODULES}
    assert m["dependencies"]["lastz"].startswith("lastz")
    assert all(m["dependencies"][x] for x in ("scipy", "matplotlib")) and "msprime" in m["dependencies"]
    assert set(checkpoint.TOOL_VERSION_ARGS) <= set(m["dependencies"])  # lastz and makeblastdb included
    assert (m["params"]["anchor"], m["params"]["backend"]) == ("flank-mm2", "lastz")  # the defaults
    by = {s["label"]: s for s in m["samples"]}
    for x in LABELS:
        assert by[x]["checksums"]["fasta"] == sha256(by[x]["fasta"])
    for x in ("A", "B"):
        assert by[x]["checksums"]["annotation"] == sha256(world.dir / f"{x}.gff3")
    assert set(by["C"]["checksums"]) == {"fasta"}
    assert m["started"] <= m["finished"]

    assert {eid: tuple(r[f"{x}_state"] for x in LABELS) for eid, r in loci_by_first(out).items()} == world.expect

    qc = qc_values(out)
    assert qc[("A~B", "reciprocity")] == "1"
    assert qc[("A>B", "annot_agree")] == "1" and qc[("B>A", "annot_agree")] == "1"
    assert qc[("A>B", "e_in_annot")] == "0"  # nested_E's child: E inside its host's ortholog, not counted
    assert qc[("B", "gap_rate")] == "0.125"  # the G case: 1 of A's 8 calls in B
    assert ("A>C", "annot_agree") not in qc and ("A~C", "reciprocity") not in qc  # C has no annotation


@needs_lastz
def test_run_shared_seqids(first, tmp_path):
    """All three genomes name their sequence chr1. The outputs are the distinct-name run's
    with the names replaced, and each genome's coordinates are its own."""
    d = tmp_path / "world"
    d.mkdir()
    world = make_world(d, seqids=("chr1", "chr1", "chr1"))
    out = tmp_path / "out"
    try:
        assert main(["run", "--samples", str(world.sheet), "--outdir", str(out), "--threads", "2"]) == 0
    finally:
        (d / "C").chmod(0o755)

    def rename(text: str) -> str:
        for name in ("seqA", "seqB", "seqC"):
            text = text.replace(name, "chr1")
        return text

    ref = first[0]
    for name in OUTPUTS:
        if name.endswith((".tsv", ".gff3", ".bed")):
            assert (out / name).read_text() == rename((ref / name).read_text()), name
    assert vcf_text(out) == rename(vcf_text(ref))

    loci = loci_by_first(out)
    a_host = next(e for e in world.elements["A"] if e.name == "nested_E.h")
    b_host = next(e for e in world.elements["B"] if e.name == "nested_E.b")
    assert a_host.start != b_host.start  # the two genomes' coordinates differ here
    host = loci[a_host.eid]
    assert [host[k] for k in ("A_start", "A_end", "B_eid", "B_start", "B_end")] == [
        str(a_host.start), str(a_host.end), b_host.eid, str(b_host.start), str(b_host.end)]
    empty = loci[world.b_only.eid]
    assert [empty[k] for k in ("A_state", "A_seqid", "A_start", "A_end", "B_start", "B_end")] == [
        "E", "chr1", str(world.a_site), str(world.a_site + 4), str(world.b_only.start), str(world.b_only.end)]
    with pysam.VariantFile(str(out / "pav.vcf.gz")) as vcf:
        recs = {r.id: (r.contig, r.pos, [r.samples[x]["GT"] for x in LABELS]) for r in vcf}
    # the VCF is on A's coordinates: the host at its start - 1; the empty site at its TSD copy's last base
    assert recs[host["lid"]] == ("chr1", a_host.start - 1, [(1,), (1,), (1,)])
    assert recs[empty["lid"]] == ("chr1", world.a_site + 4, [(0,), (1,), (1,)])


@needs_lastz
def test_rerun_skips(first, caplog):
    out, argv = first
    before = outputs(out)
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert main(argv) == 0
    text = caplog.text
    assert text.count("elements done, skip") == 2  # A and B
    assert text.count("anchors done, skip") == len(PAIRS)
    assert text.count("calls done, skip") == len(PAIRS)
    assert "indexing" not in text
    assert outputs(out) == before  # every output but manifest.json, byte for byte


@needs_lastz
def test_run_warns_on_unrelated_pair(mini, caplog):
    d, sheet = mini
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert main(["run", "--samples", str(sheet), "--outdir", str(d / "out"), "--threads", "1"]) == 0
    warn = [r.getMessage() for r in caplog.records if r.name == "ltrpav" and r.levelno == logging.WARNING]
    assert len(warn) == 1 and "no orthologous alignment between A and B?" in warn[0]
    assert (d / "out" / "manifest.json").is_file()


# ---------------------------------------------------------------- single stages


@needs_lastz
def test_single_stage_commands(world, first, tmp_path, caplog):
    out = tmp_path / "out"
    shutil.copytree(first[0], out)  # a work directory stays valid when moved
    before = outputs(out)
    base = ["--samples", str(world.sheet), "--outdir", str(out)]
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert anchor_main([*base, "--pair", "B,A"]) == 0
        assert genotype_main([*base, "--threads", "2"]) == 0
        assert merge_main(base) == 0
    text = caplog.text
    assert text.count("anchors done, skip") == 1 + len(PAIRS)  # B,A; then genotype checks every pair's
    assert text.count("calls done, skip") == len(PAIRS)
    assert outputs(out) == before  # merge wrote the same outputs
    assert json.loads((out / "manifest.json").read_text())["command"] == ["ltrpav-merge", *base]


@needs_lastz
def test_outdir_of_older_code_is_recomputed_stage_by_stage(mini, caplog, capsys, monkeypatch, tmp_path):
    """Each stage key holds the fingerprint of the modules its output
    depends on (checkpoint.STAGE_MODULES), here read from an edited copy of the package.
    - The same code: every stage is skipped.
    - A comment in outputs/vcf.py: still skipped, and ltrpav-merge accepts the pair files.
    - An edit of classify.py: merge refuses them; a rerun recomputes the calls only.
    - An edit of constants.py: every stage reruns.
    - Another annotation of A: merge refuses its pair file."""
    d, sheet = mini
    argv = ["run", "--samples", str(sheet), "--outdir", str(d / "out"), "--threads", "1"]
    merge = ["--samples", str(sheet), "--outdir", str(d / "out")]
    skips = ("elements done, skip", "anchors done, skip", "calls done, skip")
    pair = d / "out" / "pairs" / "A__B.calls.tsv.gz"
    assert main(argv) == 0
    code = checkpoint.done_meta(pair.with_name(pair.name + ".done.json"))["code"]
    assert code == checkpoint.stage_fingerprint("genotype_pair")
    copy = tmp_path / "ltrpav"
    shutil.copytree(Path(checkpoint.__file__).parent, copy, ignore=shutil.ignore_patterns("__pycache__"))
    monkeypatch.setattr(checkpoint, "_ROOT", copy)

    def edit(module):
        (copy / module).write_text((copy / module).read_text() + "\n# an edit\n")
        checkpoint._fingerprint.cache_clear()

    def rerun():
        caplog.clear()
        with caplog.at_level(logging.INFO, logger="ltrpav"):
            assert main(argv) == 0
        return [s for s in skips if s in caplog.text]

    def refused():
        capsys.readouterr()
        if merge_main(merge) == 0:
            return None
        last = capsys.readouterr().err.splitlines()[-1]  # one error line after the log
        assert last.startswith("error: "), last
        return last

    assert rerun() == list(skips)  # the copy's bytes: the same keys
    edit("outputs/vcf.py")
    assert rerun() == list(skips) and refused() is None
    edit("classify.py")
    assert "written by other genotyping code or for another annotation: A__B" in refused()
    assert rerun() == ["elements done, skip", "anchors done, skip"] and refused() is None
    edit("constants.py")
    assert rerun() == []  # every stage recomputed
    write_gff3([element("A", "e", "chr1", 2001, 1000, 100)], d / "A.gff3")  # another annotation of A
    assert "for another annotation: A__B" in refused()


def test_elements_checkpoint_follows_the_annotation(mini, caplog):
    d, sheet = mini
    argv = ["--samples", str(sheet), "--outdir", str(d / "out"), "--pair", "A,B", "--threads", "1"]
    for _ in range(2):
        assert anchor_main(argv) == 0
    write_gff3([element("A", "e", "chr1", 2001, 1000, 100)], d / "A.gff3")  # the annotation changed
    caplog.clear()  # only the third run's records
    with caplog.at_level(logging.INFO, logger="ltrpav"):
        assert anchor_main(argv) == 0
    assert "A: 1 elements" in caplog.text and "elements done, skip" not in caplog.text
    assert [e.start for e in read_elements(d / "out" / "work" / "elements" / "A.tsv")] == [2001]


def test_checksums_name_each_input(tmp_path):
    fa = tmp_path / "g.fa"
    toy.write_fasta(fa, {"chr1": "ACGT" * 10})
    tables = [tmp_path / f"g_depth{n}_clean_ltr.tsv" for n in (0, 1)]
    for n, t in enumerate(tables):
        t.write_text(f"{n}\n")
    sums = tmp_path / "sums.json"
    assert cli._checksums(Sample("G", fa, str(tmp_path / "g"), None, None), sums) == {  # an LTRquest prefix
        "fasta": sha256(fa), **{f"annotation:{t.name}": sha256(t) for t in tables}}
    gff = tmp_path / "g.gff3"
    gff.write_text("##gff-version 3\n")
    assert cli._checksums(Sample("G", fa, str(gff), None, None), sums) == {"fasta": sha256(fa),
                                                                          "annotation": sha256(gff)}
    assert cli._checksums(Sample("G", fa, None, None, None), sums) == {"fasta": sha256(fa)}


@needs_lastz
def test_merge_needs_every_pair_file(world, first, tmp_path, capsys):
    out = tmp_path / "out"
    shutil.copytree(first[0] / "pairs", out / "pairs")
    for p in (out / "pairs").glob("B__C.*"):
        p.unlink()  # never genotyped
    (out / "pairs" / "A__C.calls.tsv.gz.done.json").unlink()  # unfinished: possibly stale
    assert merge_main(["--samples", str(world.sheet), "--outdir", str(out)]) == 1
    err = capsys.readouterr().err.splitlines()
    assert err[-1].startswith("error: ") and "A__C, B__C" in err[-1] and "A__B" not in err[-1]
    assert not (out / "manifest.json").exists()


# ---------------------------------------------------------------- errors and help


@pytest.mark.parametrize("command, argv, message", [
    (main, ["run", "--vcf-ref", "Z"], "--vcf-ref 'Z' is not a label"),
    (genotype_main, ["--pair", "A,Z"], "'Z' is not a label"),
    (anchor_main, ["--pair", "B,A"], "B has no annotation"),
])
def test_fail_fast_on_labels(mini, capsys, command, argv, message):
    d, sheet = mini
    assert command([*argv, "--samples", str(sheet), "--outdir", str(d / "out")]) == 1
    err = capsys.readouterr().err
    assert err.startswith("error: ") and message in err and err.count("\n") == 1, err  # one line
    assert not (d / "out").exists()  # nothing written


@pytest.mark.parametrize("command, argv, missing", [
    (main, ["run", "--anchor", "fastga"], "FastGA"),
    (main, ["run", "--anchor", "flank-blast"], "makeblastdb"),
    (main, ["run"], "lastz"),  # the window aligner, whatever the route
    (main, ["run", "--anchor", "mm2"], "lastz"),
    (genotype_main, ["--pair", "A,B"], "lastz"),
])
def test_fail_fast_on_missing_binary(mini, tmp_path, capsys, monkeypatch, command, argv, missing):
    """PATH holds stubs of every executable the engine runs but `missing` (the test sets it: the caller's PATH
    does not matter): one error line naming only `missing`, before anything is written."""
    d, sheet = mini
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    every = {exe for exes in (*cli._BINARIES.values(), *cli._BACKEND_BINARIES.values()) for exe in exes}
    for exe in every - {missing}:
        (bin_dir / exe).write_text("#!/bin/sh\nexit 1\n")
        (bin_dir / exe).chmod(0o755)
    monkeypatch.setenv("PATH", str(bin_dir))
    assert command([*argv, "--samples", str(sheet), "--outdir", str(d / "out")]) == 1
    err = capsys.readouterr().err
    assert err.startswith("error: ") and err.count("\n") == 1, err
    assert f"needs {missing} on PATH" in err, err
    assert not (d / "out").exists()  # nothing written


@pytest.fixture
def lastz_stub(tmp_path, monkeypatch):
    """Put a stub `lastz` (it prints a version line) first on PATH, so the tests that check inputs reach those
    checks on a host without lastz. Returns the real lastz's path, or None."""
    real = shutil.which("lastz")
    bin_dir = tmp_path / "lastz_stub"
    bin_dir.mkdir()
    (bin_dir / "lastz").write_text("#!/bin/sh\necho 'LASTZ version 1.04.00 (stub)'\n")
    (bin_dir / "lastz").chmod(0o755)
    monkeypatch.setenv("PATH", f"{bin_dir}{os.pathsep}{os.environ.get('PATH', '')}")
    return real


def test_fail_fast_on_bad_inputs(mini, capsys, lastz_stub):
    d, sheet = mini
    bad = d / "bad.tsv"
    bad.write_text(sheet.read_text().replace("B.fa", "missing.fa"))
    assert main(["run", "--samples", str(bad), "--outdir", str(d / "out")]) == 1  # SampleSheetError
    assert "FASTA file(s) not found" in capsys.readouterr().err
    gff = d / "A.gff3"
    gff.write_text(gff.read_text().replace("chr1\t", "chrX\t"))
    assert main(["run", "--samples", str(sheet), "--outdir", str(d / "out")]) == 1  # AnnotationError
    err = capsys.readouterr().err.splitlines()
    assert err[-1].startswith("error: ") and "absent from the FASTA" in err[-1]
    assert not any("Traceback" in ln for ln in err)


def test_malformed_annotation_records(mini, capsys, caplog, monkeypatch, lastz_stub):
    """A GFF3 whose gene line has a bad coordinate runs (the line is never
    read), a malformed LTR-RT line is warned with its file and line and counted in qc.tsv and manifest.json; an
    LTRquest table without ltr3_end fails with one error line naming the file and the column, no traceback."""
    d, sheet = mini
    gff = d / "A.gff3"
    text = gff.read_text()
    gff.write_text(text + "chr1\tx\tgene\t2000\t2O100\t.\t+\t.\tID=g1\n"
                   "chr1\tx\tLTR_retrotransposon\t3000\t35OO\t.\t+\t.\tID=bad\n")
    with caplog.at_level(logging.WARNING, logger="ltrpav"):
        assert anchor_main(["--samples", str(sheet), "--outdir", str(d / "out"), "--threads", "1"]) == 0
    warned = [r.getMessage() for r in caplog.records if r.name == "ltrpav.annotation"]
    assert warned[0].startswith(f"{gff}:{len(text.splitlines()) + 2}: record skipped, malformed_coordinates")
    if lastz_stub:  # the real lastz: the run itself
        monkeypatch.setenv("PATH", f"{Path(lastz_stub).parent}{os.pathsep}{os.environ['PATH']}")
        assert main(["run", "--samples", str(sheet), "--outdir", str(d / "out"), "--threads", "1"]) == 0
        assert qc_values(d / "out")[("A", "skipped_malformed_coordinates")] == "1"
        by = {s["label"]: s for s in json.loads((d / "out" / "manifest.json").read_text())["samples"]}
        assert by["A"]["skipped"] == {"malformed_coordinates": 1} and by["B"]["skipped"] == {}

    header = "seq_id\tseq_len\tstatus\tltr5_start\tltr5_end\tltr3_start\ttsd\tk2p\tstrand"
    (d / "lq_depth0_clean_ltr.tsv").write_text(f"#{header}\nchr1:1001-2000#LTR/Copia/SIRE\t1000\tpass\t1\t100\t901"
                                               "\tCACTC\t0\t+\n")
    sheet.write_text(sheet.read_text().replace("A.gff3", "lq"))
    capsys.readouterr()
    assert main(["run", "--samples", str(sheet), "--outdir", str(d / "out2")]) == 1
    err = capsys.readouterr().err.splitlines()
    assert err[-1].startswith("error: ") and "lacks required column(s) ltr3_end" in err[-1]
    assert "lq_depth0_clean_ltr.tsv" in err[-1] and not any("Traceback" in ln for ln in err)


def test_verbose_error_has_traceback(mini, capsys):
    d, sheet = mini
    assert main(["run", "--samples", str(sheet), "--outdir", str(d / "out"), "--vcf-ref", "Z", "-v"]) == 1
    err = capsys.readouterr().err
    assert "Traceback" in err and err.splitlines()[-1].startswith("error: --vcf-ref")


@pytest.mark.parametrize("command, argv", [
    (main, []), (main, ["run", "--threads", "0"]), (main, ["run", "--anchor", "bogus"]),
    (genotype_main, ["--pair", "A"]), (anchor_main, ["--pair", "A,A"]), (merge_main, ["--threads", "4"]),
])
def test_usage_errors_exit_2(mini, capsys, command, argv):
    d, sheet = mini
    with pytest.raises(SystemExit) as exc:
        command([*argv, "--samples", str(sheet), "--outdir", str(d / "out")])
    assert exc.value.code == 2
    assert not (d / "out").exists()


@pytest.mark.parametrize("command, argv", [(main, ["--help"]), (main, ["run", "--help"]),
                                           (anchor_main, ["--help"]), (genotype_main, ["--help"]),
                                           (merge_main, ["--help"])])
def test_help_is_short(capsys, monkeypatch, command, argv):
    monkeypatch.setenv("COLUMNS", "80")
    with pytest.raises(SystemExit) as exc:
        command(argv)
    out = capsys.readouterr().out
    assert exc.value.code == 0 and 5 < len(out.splitlines()) < 40, out


def test_version(capsys):
    with pytest.raises(SystemExit) as exc:
        main(["--version"])
    assert exc.value.code == 0 and capsys.readouterr().out == f"ltrpav {__version__}\n"


def test_missing_lastz_names_install_route(mini, capsys, monkeypatch):
    """With lastz hidden from the lookup the CLI uses, `ltrpav run` stops before any work with one error line
    that names lastz and the conda environment file."""
    d, sheet = mini
    real = shutil.which
    monkeypatch.setattr(shutil, "which", lambda exe, *a, **k: None if exe == "lastz" else real(exe, *a, **k))
    assert main(["run", "--samples", str(sheet), "--outdir", str(d / "out")]) == 1
    err = capsys.readouterr().err
    assert err.startswith("error: ") and err.count("\n") == 1, err
    assert "lastz" in err and "environment.yml" in err, err
    assert not (d / "out").exists()


ENTRY_POINTS = [("ltrpav", "ltrpav.cli:main"), ("ltrpav-anchor", "ltrpav.cli:anchor_main"),
                ("ltrpav-genotype", "ltrpav.cli:genotype_main"), ("ltrpav-merge", "ltrpav.cli:merge_main"),
                ("ltrpav-stats", "ltrpav.analysis.cli:stats_main"),
                ("ltrpav-paint", "ltrpav.analysis.cli:paint_main"),
                ("ltrpav-plot", "ltrpav.analysis.cli:plot_main"), ("ltrpav-sim", "ltrpav.sim.cli:main")]


def test_every_entry_point_has_version(capsys):
    """Each of the 8 console scripts prints `<name> <version>` for --version, and the list is pyproject's."""
    scripts = re.search(r"\[project\.scripts\]\n(.*?)\n\n", (Path(__file__).parents[1] / "pyproject.toml")
                        .read_text(), re.DOTALL).group(1)
    assert [tuple(re.findall(r'[^\s="]+', ln)) for ln in scripts.splitlines()] == ENTRY_POINTS
    for name, target in ENTRY_POINTS:
        module, func = target.split(":")
        with pytest.raises(SystemExit) as exc:
            getattr(importlib.import_module(module), func)(["--version"])
        assert exc.value.code == 0 and capsys.readouterr().out == f"{name} {__version__}\n", name


# per-pair anchoring detail
DETAIL = ("anchoring", "raw blocks", "pieces", "syntenic net", "reusing index", "indexed in")


@needs_lastz
def test_default_log_is_minimal(world, tmp_path, caplog):
    """At default verbosity the log has the pair counter and "done" but no per-pair anchoring detail; -v adds
    it."""
    texts = {}
    for name, extra in (("quiet", []), ("verbose", ["-v"])):
        caplog.clear()
        argv = ["run", "--samples", str(world.sheet), "--outdir", str(tmp_path / name), "--threads", "2",
                *extra]
        with caplog.at_level(logging.DEBUG, logger="ltrpav"):
            assert main(argv) == 0
        texts[name] = [r.getMessage() for r in caplog.records if r.name.startswith("ltrpav")
                       and r.levelno >= (logging.DEBUG if extra else logging.INFO)]
    quiet = "\n".join(texts["quiet"])
    assert "pair 1/" in quiet and "done in" in quiet
    assert not [d for d in DETAIL if d in quiet], quiet
    verbose = "\n".join(texts["verbose"])
    assert all(d in verbose for d in ("raw blocks", "syntenic net: kept")), verbose


@pytest.mark.parametrize("command", ["stats", "run"])
def test_missing_python_module_is_one_error_line(mini, command):
    """A Python module that cannot be imported gives one `error:` line naming it and the install route, exit
    1, no traceback; `ltrpav run` finds out before it starts genotyping."""
    d, sheet = mini
    entry = {"stats": "ltrpav.analysis.cli import stats_main as entry",
             "run": "ltrpav.cli import main as entry"}
    args = ([] if command == "stats" else ["run"]) + ["--samples", str(sheet), "--outdir", str(d / "out")]
    code = (f"import sys; sys.modules['scipy'] = None; from {entry[command]}; sys.exit(entry({args!r}))")
    res = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, cwd=d, check=False)
    assert res.returncode == 1, res.stderr
    lines = [ln for ln in res.stderr.splitlines() if ln.startswith("error:")]
    assert len(lines) == 1 and "scipy" in lines[0] and "environment.yml" in lines[0], res.stderr
    assert "Traceback" not in res.stderr and "pairs" not in res.stderr, res.stderr  # no "N genomes, N pairs"
    assert not (d / "out").exists()  # nothing was started
