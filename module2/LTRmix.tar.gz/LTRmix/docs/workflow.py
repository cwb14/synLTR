#!/usr/bin/env python3
"""Draw the LTRmix workflow diagram: workflow.png (figure) and workflow.pdf (figure + short and long legend pages).
Schematic only (no data). Run from anywhere: python workflow.py [-o OUTDIR]"""
import argparse
import datetime
import os
import socket
import textwrap

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.backends.backend_pdf import PdfPages  # noqa: E402
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch, Polygon, Rectangle  # noqa: E402
from matplotlib.path import Path  # noqa: E402
from matplotlib.patches import PathPatch  # noqa: E402

import glob  # noqa: E402

from matplotlib import font_manager  # noqa: E402

for _f in sorted(glob.glob("/usr/share/fonts/truetype/liberation*/LiberationSans*.ttf")):
    font_manager.fontManager.addfont(_f)      # the system font is not in matplotlib's cache by default
_FAM = "Liberation Sans" if any(f.name == "Liberation Sans" for f in font_manager.fontManager.ttflist) else "DejaVu Sans"
plt.rcParams.update({"font.family": _FAM, "pdf.fonttype": 42, "ps.fonttype": 42, "font.size": 7})
W, H = 180.0, 130.0                       # mm
R_C, S_C, D_C = "#3A3A3A", "#0072B2", "#D55E00"   # recipient, sister (Okabe-Ito blue), donor (vermillion)
GRAY, LGRAY, LTR_C = "#9A9A9A", "#C9C9C9", "#6B6B6B"
PANEL_FC, PANEL_EC = "#F6F6F6", "#D6D6D6"
FS_T, FS_L, FS_S = 8.0, 6.8, 6.2          # title, label, small


def mm(ax, x0, y0, x1, y1, **kw):
    ax.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, **kw))


def module(ax, x0, y0, x1, y1, num, title):
    ax.add_patch(FancyBboxPatch((x0, y0), x1 - x0, y1 - y0, boxstyle="round,pad=0,rounding_size=2.2",
                                fc=PANEL_FC, ec=PANEL_EC, lw=0.6, zorder=0))
    ax.add_patch(Circle((x0 + 4.2, y1 - 4.2), 2.3, fc="#2B2B2B", ec="none", zorder=3))
    ax.text(x0 + 4.2, y1 - 4.25, str(num), color="white", fontsize=FS_T - 0.5, fontweight="bold", ha="center",
            va="center", zorder=4)
    ax.text(x0 + 7.9, y1 - 4.2, title, fontsize=FS_T, fontweight="bold", ha="left", va="center", color="#222222")


def arrow(ax, x0, y0, x1, y1, color=GRAY, lw=1.0, ms=7):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=ms, color=color, lw=lw,
                                 shrinkA=0, shrinkB=0, zorder=2))


def line(ax, xs, ys, color=GRAY, lw=1.0, **kw):
    kw.setdefault("solid_capstyle", "butt")
    ax.plot(xs, ys, color=color, lw=lw, **kw)


def chrom(ax, x0, x1, y, color, lw=1.3):
    line(ax, [x0, x1], [y, y], color=color, lw=lw, zorder=1)


def small_el(ax, x, y, w=2.6, h=1.5, body=LGRAY, end=LTR_C, z=3):
    mm(ax, x - w / 2, y - h / 2, x + w / 2, y + h / 2, fc=body, ec="none", zorder=z)
    e = w * 0.24
    mm(ax, x - w / 2, y - h / 2, x - w / 2 + e, y + h / 2, fc=end, ec="none", zorder=z + 0.1)
    mm(ax, x + w / 2 - e, y - h / 2, x + w / 2, y + h / 2, fc=end, ec="none", zorder=z + 0.1)


def ltr_arrow(ax, x0, x1, y, h, color=LTR_C, z=3):
    tip = min(1.6, (x1 - x0) * 0.35)
    ax.add_patch(Polygon([(x0, y - h / 2), (x1 - tip, y - h / 2), (x1, y), (x1 - tip, y + h / 2), (x0, y + h / 2)],
                         closed=True, fc=color, ec="none", zorder=z))


def big_el(ax, x0, x1, y, h=3.2, tsd=1.5, ltr=7.0):
    """TSD | LTR > internal LTR > | TSD, drawn to the given span."""
    mm(ax, x0, y - tsd / 2, x0 + tsd, y + tsd / 2, fc="#111111", ec="none", zorder=4)
    mm(ax, x1 - tsd, y - tsd / 2, x1, y + tsd / 2, fc="#111111", ec="none", zorder=4)
    a0, a1 = x0 + tsd + 0.25, x0 + tsd + 0.25 + ltr
    b1, b0 = x1 - tsd - 0.25, x1 - tsd - 0.25 - ltr
    mm(ax, a1 - 0.6, y - h * 0.32, b0 + 0.6, y + h * 0.32, fc="#ECECEC", ec="#BDBDBD", lw=0.5, zorder=3)
    ltr_arrow(ax, a0, a1, y, h)
    ltr_arrow(ax, b0, b1, y, h)
    return (a0 + a1) / 2, (b0 + b1) / 2


def empty_site(ax, x, y, color="#555555", s=1.5):
    ax.add_patch(Polygon([(x - s * 0.62, y + s * 0.55), (x + s * 0.62, y + s * 0.55), (x, y - s * 0.45)],
                         closed=True, fc="white", ec=color, lw=0.7, zorder=4))


def node(ax, x, y, r, color, letter, fs=FS_T):
    ax.add_patch(Circle((x, y), r, fc=color, ec="white", lw=0.8, zorder=4))
    ax.text(x, y - 0.1, letter, color="white", fontsize=fs, fontweight="bold", ha="center", va="center", zorder=5)


def bezier(ax, p0, p1, p2, color=GRAY, lw=0.8, z=2, arrowhead=False):
    path = Path([p0, p1, p2], [Path.MOVETO, Path.CURVE3, Path.CURVE3])
    if arrowhead:
        ax.add_patch(FancyArrowPatch(path=path, arrowstyle="-|>", mutation_scale=5, color=color, lw=lw, zorder=z))
    else:
        ax.add_patch(PathPatch(path, fc="none", ec=color, lw=lw, zorder=z))


def draw(ax):
    ax.set_xlim(0, W)
    ax.set_ylim(0, H)
    ax.set_aspect("equal")
    ax.axis("off")

    # ---- 1. LTR-RT libraries ---------------------------------------------------------------------------------
    module(ax, 3, 72, 59, 126, 1, "LTR-RT libraries")
    ys = {"A": 113.0, "B": 106.5, "C": 100.0}
    pos = {"A": [15, 20.5, 27, 33, 39.5, 46, 51.5], "B": [14, 20.5, 26, 33, 38, 45, 52],
           "C": [16, 21, 27.5, 36, 41, 47, 51]}
    for g, y in ys.items():
        ax.text(8.6, y, g, fontsize=FS_L + 0.5, fontweight="bold", color="#555555", ha="center", va="center")
        chrom(ax, 11, 56, y, "#7A7A7A", lw=1.0)
        for x in pos[g]:
            small_el(ax, x, y)
    # zoom: one element of C to its structure
    zx = 36.0
    mm(ax, zx - 1.75, ys["C"] - 1.2, zx + 1.75, ys["C"] + 1.2, fc="none", ec="#555555", lw=0.5, zorder=5)
    line(ax, [zx - 1.75, 10.0], [ys["C"] - 1.2, 88.2], color="#B5B5B5", lw=0.5, ls=(0, (2, 1.5)), zorder=1)
    line(ax, [zx + 1.75, 55.0], [ys["C"] - 1.2, 88.2], color="#B5B5B5", lw=0.5, ls=(0, (2, 1.5)), zorder=1)
    l1, l2 = big_el(ax, 10.0, 55.0, 84.0)
    ax.text(10.75, 81.6, "TSD", fontsize=FS_S, ha="center", va="top", color="#111111")
    ax.text(54.25, 81.6, "TSD", fontsize=FS_S, ha="center", va="top", color="#111111")
    ax.text(l1 - 0.5, 84.0, "LTR", fontsize=FS_S, ha="center", va="center", color="white", fontweight="bold",
            zorder=6)
    ax.text(l2 - 0.5, 84.0, "LTR", fontsize=FS_S, ha="center", va="center", color="white", fontweight="bold",
            zorder=6)
    bezier(ax, (l1, 86.2), ((l1 + l2) / 2, 93.0), (l2, 86.2), color="#8A8A8A", lw=0.7)
    ax.text((l1 + l2) / 2, 90.3, "age", fontsize=FS_L, ha="center", va="center", color="#444444",
            bbox=dict(fc=PANEL_FC, ec="none", pad=0.6))

    arrow(ax, 59.6, 99, 64.4, 99)

    # ---- 2. Sister pair ---------------------------------------------------------------------------------------
    module(ax, 65, 72, 113, 126, 2, "Sister pair")
    # tree: R and S joined first (sisters), D outside; gene flow from D into R
    xR, xS, xD, yt = 75.0, 89.0, 104.0, 99.0
    yRS, yRoot = 105.0, 112.0
    tc = "#8C8C8C"
    for x in (xR, xS):
        line(ax, [x, x], [yt + 2.4, yRS], color=tc, lw=1.1)
    line(ax, [xR, xS], [yRS, yRS], color=tc, lw=1.1)
    xm = (xR + xS) / 2
    line(ax, [xm, xm], [yRS, yRoot], color=tc, lw=1.1)
    line(ax, [xD, xD], [yt + 2.4, yRoot], color=tc, lw=1.1)
    line(ax, [xm, xD], [yRoot, yRoot], color=tc, lw=1.1)
    line(ax, [(xm + xD) / 2, (xm + xD) / 2], [yRoot, yRoot + 2.2], color=tc, lw=1.1)
    ax.add_patch(FancyArrowPatch((xD - 0.3, 108.6), (xR + 0.4, 103.2), connectionstyle="arc3,rad=0.18",
                                 arrowstyle="-|>", mutation_scale=6, color=D_C, lw=0.9, ls=(0, (2.2, 1.4)),
                                 zorder=3))
    ax.text(96.5, 106.7, "gene flow", fontsize=FS_S, ha="center", va="top", color=D_C)
    node(ax, xR, yt, 2.6, R_C, "R", fs=FS_L)
    node(ax, xS, yt, 2.6, S_C, "S", fs=FS_L)
    node(ax, xD, yt, 2.6, D_C, "D", fs=FS_L)
    ax.text(xR, 95.6, "recipient", fontsize=FS_S, ha="center", va="top", color=R_C)
    ax.text(xS, 95.6, "sister", fontsize=FS_S, ha="center", va="top", color=S_C)
    ax.text(xD, 95.6, "donor", fontsize=FS_S, ha="center", va="top", color=D_C)
    # shared k-mers per pair: the most-sharing pair are the sisters; the sister sharing more with D is R
    bx0, bh = 77.0, 2.2
    rows = [("R–S", 89.4, 30.0), ("R–D", 85.9, 22.0), ("S–D", 82.4, 16.0)]
    for lab, yb, ln in rows:
        ax.text(bx0 - 1.0, yb, lab, fontsize=FS_S, ha="right", va="center", color="#333333")
        if lab == "R–S":
            mm(ax, bx0, yb - bh / 2, bx0 + ln, yb + bh / 2, fc="#B5B5B5", ec="none", zorder=3)
        elif lab == "R–D":
            mm(ax, bx0, yb - bh / 2, bx0 + 16.0, yb + bh / 2, fc=R_C, ec="none", zorder=3)
            mm(ax, bx0 + 16.0, yb - bh / 2, bx0 + ln, yb + bh / 2, fc=D_C, ec="none", zorder=3)
        else:
            mm(ax, bx0, yb - bh / 2, bx0 + ln, yb + bh / 2, fc=S_C, ec="none", zorder=3)
    line(ax, [bx0 + 16.0, bx0 + 16.0], [81.0, 87.3], color="#555555", lw=0.6, ls=(0, (1.6, 1.0)), zorder=4)
    ax.text(bx0 + 23.2, 85.9, "excess", fontsize=FS_S, ha="left", va="center", color=D_C)
    ax.text(bx0 + 15.0, 79.4, "shared k-mers", fontsize=FS_S, ha="center", va="top", color="#7A7A7A")

    arrow(ax, 113.6, 99, 118.4, 99)

    # ---- 3. Orthology & synteny -------------------------------------------------------------------------------
    module(ax, 119, 72, 177, 126, 3, "Orthology & synteny")
    yR, yD = 107.0, 87.0
    ax.text(122.6, yR, "R", fontsize=FS_L + 0.5, fontweight="bold", color=R_C, ha="center", va="center")
    ax.text(122.6, yD, "D", fontsize=FS_L + 0.5, fontweight="bold", color=D_C, ha="center", va="center")
    chrom(ax, 125.5, 174, yR, R_C)
    chrom(ax, 125.5, 174, yD, D_C)
    pairs = [(128.5, 128.0, "c"), (134.0, 133.5, "c"), (139.5, 139.5, "c"), (145.0, 145.0, "c"),
             (151.0, 159.0, "i"), (155.0, 155.0, "i"), (159.0, 151.0, "i"), (170.5, 170.0, "c")]
    for xr, xd, kind in pairs:
        col, lw = ("#B0B0B0", 0.8) if kind == "c" else ("#4A4A4A", 0.8)
        if xr == 134.0:
            col, lw = "#111111", 0.9                  # the pair whose TSDs are shown
        line(ax, [xr, xd], [yR - 1.0, yD + 1.0], color=col, lw=lw, zorder=1)
        small_el(ax, xr, yR)
        small_el(ax, xd, yD, body="#F2C3A6", end=D_C)
    # an insertion of R absent from D: its empty site
    small_el(ax, 165.0, yR)
    line(ax, [165.0, 164.8], [yR - 1.0, yD + 1.3], color="#B0B0B0", lw=0.6, ls=(0, (1.5, 1.2)), zorder=1)
    empty_site(ax, 164.8, yD + 0.75)
    ax.text(134.0, 81.6, "same TSD", fontsize=FS_S, ha="center", va="top", color="#555555")
    ax.text(155.0, 81.6, "inversion", fontsize=FS_S, ha="center", va="top", color="#4A4A4A")
    ax.text(166.0, 81.6, "absent", fontsize=FS_S, ha="center", va="top", color="#555555")
    # the TSD certificate on one pair: the same duplication flanks both copies
    for xc, yy in ((134.0, yR), (133.5, yD)):
        for xe in (xc - 1.3 - 0.75, xc + 1.3):
            mm(ax, xe, yy - 0.375, xe + 0.75, yy + 0.375, fc="#111111", ec="none", zorder=5)

    # ---- bus from 3 into 4 and 5 ------------------------------------------------------------------------------
    line(ax, [148, 148], [72, 68.8], color=GRAY, lw=1.0, zorder=1)
    line(ax, [45, 148], [68.8, 68.8], color=GRAY, lw=1.0, zorder=1)
    arrow(ax, 45, 68.8, 45, 65.4)
    arrow(ax, 135, 68.8, 135, 65.4)

    # ---- 4. Genome-wide tests ---------------------------------------------------------------------------------
    module(ax, 3, 24, 87, 65, 4, "Genome-wide tests")
    # (i) k-mers: three overlapping sets
    for (cx, cy), col in (((15.6, 53.4), R_C), ((20.4, 53.4), S_C), ((18.0, 49.3), D_C)):
        ax.add_patch(Circle((cx, cy), 3.3, fc=col, alpha=0.10, ec="none", zorder=2))
        ax.add_patch(Circle((cx, cy), 3.3, fc="none", ec=col, lw=0.8, zorder=3))
    ax.text(18.0, 43.6, "k-mers", fontsize=FS_L, ha="center", va="top")
    # (ii) insertions: present in R and D, empty site in S
    for yy, col, g in ((55.6, R_C, "R"), (51.8, S_C, "S"), (48.0, D_C, "D")):
        ax.text(38.0, yy, g, fontsize=FS_S, fontweight="bold", color=col, ha="center", va="center")
        chrom(ax, 40.0, 52.0, yy, col, lw=1.0)
    small_el(ax, 46.0, 55.6)
    empty_site(ax, 46.0, 52.35)
    small_el(ax, 46.0, 48.0, body="#F2C3A6", end=D_C)
    ax.text(46.0, 43.6, "insertions", fontsize=FS_L, ha="center", va="top")
    # (iii) ortholog triples: R closer to D than S is
    c3 = (18.0, 35.6)
    for (tx, ty), col, g in (((14.6, 38.4), R_C, "R"), ((24.0, 39.6), S_C, "S"), ((18.0, 31.4), D_C, "D")):
        line(ax, [c3[0], tx], [c3[1], ty], color=col, lw=1.0, zorder=2)
        node(ax, tx, ty, 1.35, col, g, fs=FS_S - 0.6)
    ax.text(18.0, 28.6, "triples", fontsize=FS_L, ha="center", va="top")
    # (iv) LTR sites: the element's other LTR gives the ancestral base
    yl = 35.6
    mm(ax, 43.0, yl - 0.9, 49.0, yl + 0.9, fc="#ECECEC", ec="#BDBDBD", lw=0.5, zorder=2)
    ltr_arrow(ax, 37.2, 43.4, yl, 2.8)
    ltr_arrow(ax, 48.6, 54.8, yl, 2.8)
    mm(ax, 39.4, yl - 1.4, 39.9, yl + 1.4, fc="#BBBBBB", ec="none", zorder=4)
    mm(ax, 50.8, yl - 1.4, 51.3, yl + 1.4, fc=D_C, ec="none", zorder=4)
    bezier(ax, (39.65, yl + 1.6), (45.35, yl + 5.2), (51.05, yl + 1.6), color="#8A8A8A", lw=0.6, arrowhead=True)
    ax.text(46.0, 28.6, "LTR sites", fontsize=FS_L, ha="center", va="top")
    # D by insertion age (schematic trend) with the no-gene-flow line
    x0a, x1a, y0a, y1a = 64.5, 84.0, 33.0, 57.0
    line(ax, [x0a, x0a], [y0a, y1a], color="#555555", lw=0.7)
    line(ax, [x0a, x1a], [y0a, y0a], color="#555555", lw=0.7)
    y0line = 38.0
    line(ax, [x0a, x1a], [y0line, y0line], color="#8A8A8A", lw=0.7, ls=(0, (2.5, 1.5)))
    ax.text(x0a - 1.2, y0line, "0", fontsize=FS_S, ha="right", va="center", color="#555555")
    ax.text(x0a - 2.6, 47.5, "D", fontsize=FS_L, ha="center", va="center", fontweight="bold")
    xs = [67.5, 70.5, 73.5, 76.5, 79.5, 82.5]
    yv = [53.0, 51.8, 49.0, 45.5, 43.0, 41.6]
    for x, y in zip(xs, yv):
        line(ax, [x, x], [y - 1.4, y + 1.4], color="#333333", lw=0.6)
        ax.add_patch(Circle((x, y), 0.75, fc="#222222", ec="none", zorder=3))
    ax.text(x1a, y0line - 1.1, "no gene flow", fontsize=FS_S, ha="right", va="top", color="#7A7A7A")
    ax.text((x0a + x1a) / 2, 28.6, "insertion age", fontsize=FS_L, ha="center", va="top")

    # ---- 5. Local ancestry ------------------------------------------------------------------------------------
    module(ax, 93, 24, 177, 65, 5, "Local ancestry")
    # HMM: two ancestry states
    hS, hD = (119.5, 55.6), (128.5, 55.6)
    node(ax, *hS, 2.4, S_C, "S", fs=FS_S)
    node(ax, *hD, 2.4, D_C, "D", fs=FS_S)
    bezier(ax, (hS[0] + 1.6, hS[1] + 1.9), (124.0, 59.2), (hD[0] - 1.6, hD[1] + 1.9), arrowhead=True)
    bezier(ax, (hD[0] - 1.6, hD[1] - 1.9), (124.0, 52.0), (hS[0] + 1.6, hS[1] - 1.9), arrowhead=True)
    ax.text(132.5, 55.6, "HMM", fontsize=FS_L, ha="left", va="center", color="#444444")
    # key for element ticks
    line(ax, [150.0, 150.0], [54.4, 56.8], color=D_C, lw=1.4)
    ax.text(151.3, 55.6, "D-like", fontsize=FS_S, ha="left", va="center", color=D_C)
    line(ax, [162.5, 162.5], [54.4, 56.8], color=S_C, lw=1.4)
    ax.text(163.8, 55.6, "S-like", fontsize=FS_S, ha="left", va="center", color=S_C)
    # recipient chromosome with informative elements
    xa, xb, yr = 118.0, 174.0, 46.6
    ax.text(115.0, yr, "R", fontsize=FS_L + 0.5, fontweight="bold", color=R_C, ha="center", va="center")
    chrom(ax, xa, xb, yr, R_C)
    don = [121.5, 136.0, 137.6, 139.4, 141.0, 142.8, 144.5, 146.4, 148.0, 162.0]
    sis = [119.8, 123.5, 126.4, 129.0, 131.6, 145.4, 151.5, 154.5, 157.2, 160.0, 164.6, 167.5, 170.4, 172.8]
    for x in don:
        line(ax, [x, x], [yr + 0.6, yr + 3.0], color=D_C, lw=1.1)
    for x in sis:
        line(ax, [x, x], [yr - 0.6, yr - 3.0], color=S_C, lw=1.1)
    # posterior (schematic): high across the run of D-like elements
    import numpy as np
    xx = np.linspace(xa, xb, 400)

    def bump(c, w, hgt):
        return hgt * np.exp(-0.5 * ((xx - c) / w) ** 2)
    core = 1 / (1 + np.exp(-(xx - 134.6) / 0.7)) * (1 / (1 + np.exp((xx - 149.2) / 0.7)))
    post = np.clip(0.06 + 0.88 * core + bump(121.5, 1.6, 0.28) + bump(162.0, 1.6, 0.24), 0, 1)
    p0, p1 = 34.4, 40.8
    line(ax, [xa, xb], [p0, p0], color="#D0D0D0", lw=0.5)
    line(ax, [xa, xb], [p1, p1], color="#D0D0D0", lw=0.5)
    ax.plot(xx, p0 + (p1 - p0) * post, color="#111111", lw=1.0, zorder=3)
    ax.text(xa - 1.5, (p0 + p1) / 2, "posterior", fontsize=FS_L, ha="right", va="center")
    ax.text(xb + 1.0, p0, "0", fontsize=FS_S, ha="left", va="center", color="#777777")
    ax.text(xb + 1.0, p1, "1", fontsize=FS_S, ha="left", va="center", color="#777777")
    mm(ax, 134.6, 31.0, 149.2, 32.3, fc="#111111", ec="none", zorder=3)
    ax.text(150.6, 31.65, "tract", fontsize=FS_L, ha="left", va="center")
    # decoy: the sister painted by the same model
    yd = 27.2
    chrom(ax, xa, xb, yd, S_C)
    ax.text(xa - 1.5, yd, "S decoy", fontsize=FS_L, ha="right", va="center", color=S_C)
    mm(ax, 156.0, yd - 0.75, 159.0, yd + 0.75, fc="white", ec="#777777", lw=0.6, zorder=3)

    # ---- 6. Outputs --------------------------------------------------------------------------------------------
    arrow(ax, 45, 24, 45, 19.4)
    arrow(ax, 135, 24, 135, 19.4)
    module(ax, 3, 3, 177, 19, 6, "Outputs")
    files = ["findings.txt", "stats.tsv", "elements.tsv", "tracts.bed", "inversions.tsv", "overview.pdf"]
    for i, f in enumerate(files):
        cx = 42.0 + i * 25.5
        x0f, x1f, y0f, y1f, dog = cx - 2.6, cx + 2.6, 9.2, 16.0, 1.4
        ax.add_patch(Polygon([(x0f, y0f), (x1f, y0f), (x1f, y1f - dog), (x1f - dog, y1f), (x0f, y1f)], closed=True,
                             fc="white", ec="#8A8A8A", lw=0.6, zorder=3))
        ax.add_patch(Polygon([(x1f - dog, y1f), (x1f - dog, y1f - dog), (x1f, y1f - dog)], closed=True,
                             fc="#DADADA", ec="#8A8A8A", lw=0.5, zorder=4))
        for k in range(3):
            line(ax, [x0f + 0.9, x1f - 1.2], [y1f - 2.6 - k * 1.2, y1f - 2.6 - k * 1.2], color="#C4C4C4", lw=0.5,
                 zorder=4)
        ax.text(cx, 7.6, f, fontsize=FS_S, ha="center", va="top", color="#333333")


SHORT = [
    ("", "LTRmix detects and maps gene flow between genomes from their LTR-retrotransposon libraries alone, with no "
         "genome alignment, SNPs or outgroup: an insertion is a derived, dated and certified marker, so excess "
         "sharing with one relative, concentrated in young insertions, reveals gene flow. All panels are schematic."),
    ("1  LTR-RT libraries", "Each genome contributes only its annotated intact LTR retrotransposons: their sequences, "
         "positions, target-site duplications and the divergence between each element's two LTRs, which dates it."),
    ("2  Sister pair", "The two genomes sharing the most k-mers are each other's closest relatives (sisters); the "
         "third genome is the donor. Without gene flow both sisters share equally with the donor; the sister that "
         "shares more is the recipient, and its excess is the signal of gene flow."),
    ("3  Orthology & synteny", "Copies of one insertion are matched between libraries and ordered into collinear "
         "blocks, which also reveal inversions and where an insertion is absent."),
    ("4  Genome-wide tests", "Four tests ask whether the recipient shares more with the donor than its sister does, "
         "and the excess is traced across insertion age: lineage sorting predicts none at any age."),
    ("5  Local ancestry", "Along the recipient's chromosomes, elements closer to the donor or to the sister are read "
         "by a two-state model; the sister, painted by the same model, measures the chance level."),
]

LONG = [
    ("", "Inputs: three or more LTR-RT libraries (e.g. LTRquest output, or FASTA with chrom:start-end headers plus an "
         "optional table of LTR-LTR K2P divergence, TSD, strand and LTR lengths). No genome sequence is read. "
         "Near-identical: closer than 95% of sister-donor ortholog pairs. D = (a - b) / (a + b), a counting what the "
         "recipient shares with the donor and the sister lacks, b the reverse; standard errors from a block jackknife "
         "(5-Mb blocks, or 1/100 of a small genome)."),
    ("1  LTR-RT libraries", "Each element is a sequence with its genome position; its two LTRs were identical at "
         "insertion, so their K2P divergence is its age (in substitutions per site; years only with an assumed "
         "rate), and the 5-bp target-site duplication (TSD) marks the insertion event."),
    ("2  Sister pair", "Canonical 21-mers present once in each library that carries them are counted for every pair "
         "of genomes (bars). The pair sharing most are the sisters, joined first in the tree. Both sisters split from "
         "the third genome at the same time, so without gene flow they share equally with it (dashed line); the sister "
         "sharing more is called the recipient (R), the other the sister (S), the third the donor (D), and the excess "
         "gives D from k-mers. The arrow follows these names: three genomes do not show which way the DNA moved."),
    ("3  Orthology & synteny", "Candidate pairs share low-copy 21-mers (at most 4 copies per library); reciprocal "
         "best pairs certified by an identical TSD (chance about 0.3%) or by the clock (ortholog divergence not above "
         "the element's own LTR-LTR divergence) anchor collinear chains in both orientations, longer than chains "
         "among shuffled anchors. Inside a block, an element without an ortholog is absent; blocks against the "
         "chromosome pair's main orientation are inversions."),
    ("4  Genome-wide tests", "k-mers: single-copy k-mers shared by exactly two genomes. Insertions: present in one "
         "sister and the donor, absent from the other sister, stratified by the donor copy's LTR-LTR divergence. "
         "Triples: which sister's copy is closer to the donor's. LTR sites: ABBA/BABA on sites inside LTRs, the "
         "ancestral base read from the element's other LTR. A completeness ratio flags uneven annotation. The D-by-age "
         "plot shows the pattern expected from recent gene flow, not data."),
    ("5  Local ancestry", "Elements are classed as near-identical to, or shared only with, the donor or the sister "
         "(other classes are missing data). A two-state hidden Markov model with a fitted tract length gives each "
         "element's posterior of donor-like ancestry; tracts need posterior odds at least 3 times the prior odds, and "
         "the same model run on the sister gives decoy tracts and a target-decoy false discovery rate (q)."),
    ("6  Outputs", "findings.txt (plain-language results), stats.tsv (every statistic, SE, Z), elements.<R>.tsv "
         "(classes and posteriors), tracts and ancestry BED files with q, inversions.tsv, and an overview figure."),
]


def text_page(pdf, paras, footer=None):
    wrap = 104
    lines = []
    for head, body in paras:
        if head:
            lines.append(("b", head))
        for ln in textwrap.wrap(body, wrap):
            lines.append(("n", ln))
        lines.append(("n", ""))
    if footer:
        for ln in textwrap.wrap(footer, wrap):
            lines.append(("s", ln))
    lh = 10 * 1.32 / 72                     # inches per line at 10 pt
    hgt = 0.5 + lh * len(lines)
    fig = plt.figure(figsize=(W / 25.4, hgt))
    y = 1 - 0.25 / hgt
    for kind, ln in lines:
        fig.text(0.02, y, ln, fontsize=10 if kind != "s" else 8, va="top", ha="left",
                 fontweight="bold" if kind == "b" else "normal", color="#111111" if kind != "s" else "#555555")
        y -= lh / hgt
    pdf.savefig(fig)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("-o", "--outdir", default=os.path.dirname(os.path.abspath(__file__)), help="output directory")
    ap.add_argument("-v", "--verbose", action="store_true", help="print output paths")
    a = ap.parse_args()
    fig = plt.figure(figsize=(W / 25.4, H / 25.4))
    ax = fig.add_axes([0, 0, 1, 1])
    draw(ax)
    png = os.path.join(a.outdir, "workflow.png")
    pdf_path = os.path.join(a.outdir, "workflow.pdf")
    fig.savefig(png, dpi=400)
    with PdfPages(pdf_path) as pdf:
        pdf.savefig(fig)
        text_page(pdf, SHORT)
        foot = (f"Analysis: {socket.gethostname()}:{os.path.abspath(a.outdir)} · Script: "
                f"{os.path.abspath(__file__)} · {datetime.date.today().isoformat()}")
        text_page(pdf, LONG, footer=foot)
    plt.close(fig)
    if a.verbose:
        print(png)
        print(pdf_path)


if __name__ == "__main__":
    main()
