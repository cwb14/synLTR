# Task 21 report: command-line interface and QC metrics

Status: DONE_WITH_CONCERNS (all concerns minor; none blocks).
Commits (branch plan1-engine, existing git identity, no trailers):
- `7add9c5` Add per-pair and per-genome QC metrics (loci.py, test_loci.py; passes on its own, checked in a
  temporary worktree: test_loci + test_outputs + test_genotype green)
- `e45eb64` Add CLI, QC metrics and end-to-end run

## What I implemented

### `src/ltrpav/cli.py` (new)
- `main()` = `ltrpav run`; `anchor_main()` = `ltrpav-anchor`; `genotype_main()` = `ltrpav-genotype`;
  `merge_main()` = `ltrpav-merge`. Options as in ruling 1: `--samples --outdir [--threads 8]
  [--anchor ROUTE] [-v]` for run/anchor/genotype; `[--pair A,B]` for anchor/genotype; `[--vcf-ref LABEL]`
  (default: first sheet row) for run/merge; merge takes only `--samples --outdir [--vcf-ref] [-v]`.
  `--anchor` is validated by `get_route` inside argparse (unknown route: exit 2). `ltrpav --version`.
- Exit codes: 0 done; 1 handled error (ValueError family incl. SampleSheetError/AnnotationError/CliError,
  RuntimeError, OSError): one line `error: <message>` on stderr, traceback first only with `-v`; 2 argparse;
  130 on Ctrl-C.
- Logging: a stderr handler on logger "ltrpav" for the command's duration (INFO; DEBUG with -v); removed and
  the level restored afterwards (no leakage across calls or tests). Lines: start, per-genome elements milestone
  or "skip", "pair k/n", the engine's per-pair lines, merge summary, done.
- Fail fast, before anything is written: SampleSheetError; unknown `--vcf-ref`/`--pair` label; `--pair`
  whose A is unannotated; missing binary (fastga: FastGA; flank-blast: blastn, makeblastdb; mm2/flank-mm2/hybrid
  need none); `paf:<dir>` not a directory. AnnotationError surfaces at the elements stage.
- Pipeline (ruling 2): read_samples, open every FASTA with `cache_dir = outdir/work/fai` (a read-only FASTA
  directory works in place; tested), elements stage per annotated genome, ordered pairs (annotated A, any
  B != A, sheet order), genotype, merge, outputs, manifest.json last.
- Elements stage: `load_annotation` with a per-genome Counter, written atomically to
  `work/elements/<label>.tsv` + `<label>.skipped.json` (the skip counts must survive a skip, for QC), done
  marker keyed by sha256 of the FASTA and of every annotation file (an LTRquest prefix: each table), plus the
  label. The elements are always read back from the TSV, so a fresh run and a rerun hand identical element
  lists (and digests) to the later stages.
- `run` calls `genotype_pair` per pair, which runs `anchor_pair` itself (checkpointed). Calling `anchor_pair`
  first as well would only reload the npz and log a duplicate line per pair; `ltrpav-anchor` calls
  `anchor_pair` alone.
- `ltrpav-anchor`/`ltrpav-genotype` open and load only the genomes in the pairs run (for `--pair` array jobs).
- `ltrpav-merge` requires every expected pair file AND its done marker (a file without a marker may be left
  from other inputs by an interrupted rerun); otherwise exit 1 naming the pairs, checked before any work.
- Merge: deletes manifest.json first (present only after a finished merge), `build_loci(..., skipped=...)`,
  WARNING for any pair with `resolved_frac < RESOLVED_WARN` ("... no orthologous alignment between A and B?"),
  loci.tsv, pav_matrix.tsv, qc.tsv, pav.vcf.gz (+ .tbi, pav.unplaced.tsv), `<label>.pav.gff3/.bed`,
  manifest.json (version, argv as given, params with absolute paths, sha256 of every FASTA and annotation,
  started/finished ISO UTC). The merge is not checkpointed: it always rewrites the outputs (byte-identical).

### QC metrics (`src/ltrpav/loci.py`)
`build_loci(..., skipped=None)` (new optional kwarg: genome -> loader skip Counter). The registry
`_QC_METRICS` is one line per metric function `(scope kind, fn)`, each yielding `(metric, value)`; rows come
out scope by scope: `all`, every `A>B` read (sheet order), every `A~B`, every genome.
- `all`: n_loci, n_conflict, n_multi_member, n_annot_conflict (unchanged values).
- `A>B`: frac_<state> x 8, resolved_frac (P/S/T/E), high_frac; if B is annotated: annot_agree and e_in_annot
  per ruling 5 (B site: P/S/T/E/D -> [b_start, b_end]; G/U/O none; B elements in the locus of any ancestor of
  the called element are excluded, walking parent, grandparent, ...). Overlap queries use a new
  `_Spans.overlapping` with a running maximum of ends, so a long host that starts far before the site is never
  missed (tested).
- `A~B` (annotated genomes read both ways): reciprocity = |both| / |either| over element links, links replayed
  from the kept calls with the same partner rule as `read` (nan without links).
- genome: annot_sensitivity (annotated genomes; numpy over union-find roots), gap_rate (nan without calls
  into it), skipped_<reason> (nonzero, sorted).
- The build_loci log line now prints only the `all` rows.

### Small changes outside the brief's file list (needed by the rulings)
- `anchor/__init__.py`: reuse log line "reusing N netted blocks" -> "anchors done, skip (N netted blocks,
  d = ...)", so a rerun logs "skip" for anchors (ruling 10), worded like genotype's "calls done, skip". No test
  referenced the old text.
- `annotation/__init__.py`: public `annotation_files(spec)` beside `_dispatch` (same detection rules): the
  files that key the elements checkpoint and the manifest checksums.
- `constants.py`: `RESOLVED_WARN = 0.01` (global constraint: thresholds live in constants.py).

## Tests and results
- New `tests/test_cli.py` (27 tests, all fast: first toy run ~1 s, no `slow` marks needed):
  test_run_toy_three_genomes (every output exists; pair files; elements TSVs; C's index in work/fai, none
  beside the read-only C.fa; manifest version/argv/sha256 of each FASTA and GFF3; every locus's (A, B, C)
  states equal the construction; qc: A~B reciprocity 1, annot_agree 1 for A>B and B>A, e_in_annot 0, B gap_rate
  0.125, no annot rows for unannotated C), test_run_shared_seqids (all "chr1": every TSV/GFF3/BED and the
  decompressed VCF equal the seqA/seqB/seqC run's after renaming; plus coordinate spot checks where A and B
  coordinates differ: nested host in loci.tsv, B-only element's E site in A, VCF POS/GT), test_rerun_skips
  (2 elements + 4 anchors + 4 calls "skip" lines, no "anchoring"/"indexing", every output but manifest.json
  byte-identical), test_run_warns_on_unrelated_pair, test_single_stage_commands (anchor --pair, genotype,
  merge on a copied outdir: skips, identical outputs, merge manifest command),
  test_elements_checkpoint_follows_the_annotation, test_checksums_name_each_input,
  test_merge_needs_every_pair_file (missing file and missing marker -> exit 1 naming A__C, B__C),
  test_fail_fast_on_labels (x3, one line, nothing written), test_fail_fast_on_missing_binary (x2),
  test_fail_fast_on_bad_inputs (SampleSheetError, AnnotationError), test_verbose_error_has_traceback,
  test_usage_errors_exit_2 (x6), test_help_is_short (x5, COLUMNS=80, < 40 lines), test_version.
- `tests/test_loci.py`: 9 new QC tests on synthetic call tables (state fractions; annot_agree/e_in_annot with
  parent and grandparent exclusion, D junction 1-bp overlap, partial E overlap, O ignored; site inside a long
  element past a nested one; reciprocity 1/3; reciprocity nan / absent with one direction; annot_sensitivity
  0.5 and 1.0 (medium tier and E not counted) and gap_rate 0/0/0.2; annot_sensitivity nan; skipped_<reason>;
  row order). test_qc_counters now checks the first four (`all`) rows.
- `tests/test_annotation.py`: test_annotation_files.
- Full suite: `623 passed in 71.09s`; `ruff check .`: All checks passed. CLI + loci tests also pass under
  `python -X dev -W error::ResourceWarning`.

## TDD evidence
RED, QC (`pytest tests/test_loci.py -k qc`, before any loci.py change):
```
FAILED tests/test_loci.py::test_qc_counters - TypeError: build_loci() got an ...
FAILED tests/test_loci.py::test_qc_state_fractions - TypeError: build_loci() ...
FAILED tests/test_loci.py::test_qc_annotation_agreement - TypeError: build_lo...
FAILED tests/test_loci.py::test_qc_site_inside_long_element - TypeError: buil...
FAILED tests/test_loci.py::test_qc_reciprocity - TypeError: build_loci() got ...
FAILED tests/test_loci.py::test_qc_reciprocity_needs_both_directions - TypeEr...
FAILED tests/test_loci.py::test_qc_annot_sensitivity_and_gap_rate - TypeError...
FAILED tests/test_loci.py::test_qc_annot_sensitivity_without_projection - Typ...
FAILED tests/test_loci.py::test_qc_skipped_counts - TypeError: build_loci() g...
FAILED tests/test_loci.py::test_qc_row_order - TypeError: build_loci() got an...
```
RED, CLI (`pytest tests/test_cli.py`):
```
tests/test_cli.py:20: in <module>
    from ltrpav.cli import anchor_main, genotype_main, main, merge_main
E   ModuleNotFoundError: No module named 'ltrpav.cli'
ERROR tests/test_cli.py
```
GREEN: QC `10 passed, 70 deselected`; all of test_loci (80) and test_cli green; full suite `623 passed`.
One later-added test failed first (test_elements_checkpoint_follows_the_annotation): the CLI was right
(reproduced by hand: the stage recomputes after the edit); the test read `caplog.text`, which holds the whole
call phase including the earlier run's "skip" line. Fixed with `caplog.clear()`.

## Toy `ltrpav run` by hand
World: the test's three genomes (tests/test_cli.py `make_world`, seed 7, seqids seqA/seqB/seqC; C's directory
read-only), written by a scratch script to
`/tmp/claude-1007/-data2-chris-maize-introgression/a7cbe20d-95be-480c-b88f-18a5132aaf2e/scratchpad/toyrun/world`;
run from its parent directory.
```
ltrpav run --samples world/samples.tsv --outdir out --threads 4      # exit 0
```
Log (stderr):
```
INFO ltrpav 0.1.0.dev0 run: 3 genomes (2 annotated), 4 pairs, route mm2, 4 threads -> out
INFO A: 8 elements (7 top-level), 0 annotation records skipped -> out/work/elements/A.tsv
INFO B: 3 elements (3 top-level), 0 annotation records skipped -> out/work/elements/B.tsv
INFO pair 1/4: A vs B
INFO A vs B (mm2): anchoring
INFO indexing: minimap2 -x asm20 -t 4 -I 244865 -d out/work/anchors/.B.asm20.mmi.3107612.tmp .../world/B.fa
INFO B: indexed in 0.0 s
INFO A vs B (mm2): mapped 3 chunks with 4 threads, 10 raw blocks, 0.1 s
INFO A vs B (mm2): 10 raw blocks -> 10 netted, 0.2 Mb of A anchored, d = 0.0009
INFO A vs B: 7 windows (7 anchored), 1 chunk(s) (1 computed), 8 calls (2 P, 1 S, 1 T, 2 E, 1 D, 1 G) -> out/pairs/A__B.calls.tsv.gz, 0.3 s
INFO pair 2/4: A vs C
INFO A vs C (mm2): anchoring
INFO indexing: minimap2 -x asm20 -t 4 -I 244865 -d out/work/anchors/.C.asm20.mmi.3107612.tmp .../world/C/C.fa
INFO C: indexed in 0.0 s
INFO A vs C (mm2): mapped 3 chunks with 4 threads, 10 raw blocks, 0.1 s
INFO A vs C (mm2): 10 raw blocks -> 10 netted, 0.2 Mb of A anchored, d = 0.0058
INFO A vs C: 7 windows (7 anchored), 1 chunk(s) (1 computed), 8 calls (2 P, 1 S, 1 T, 2 E, 1 D, 1 G) -> out/pairs/A__C.calls.tsv.gz, 0.2 s
INFO pair 3/4: B vs A
INFO B vs A (mm2): anchoring
INFO A vs B (mm2): reusing 10 raw blocks
INFO B vs A (mm2): 10 raw blocks -> 10 netted, 0.2 Mb of A anchored, d = 0.0009
INFO B vs A: 3 windows (3 anchored), 1 chunk(s) (1 computed), 3 calls (2 P, 1 E) -> out/pairs/B__A.calls.tsv.gz, 0.0 s
INFO pair 4/4: B vs C
INFO B vs C (mm2): anchoring
INFO C: reusing index out/work/anchors/C.asm20.mmi
INFO B vs C (mm2): mapped 3 chunks with 4 threads, 3 raw blocks, 0.1 s
INFO B vs C (mm2): 3 raw blocks -> 3 netted, 0.2 Mb of A anchored, d = 0.0050
INFO B vs C: 3 windows (3 anchored), 1 chunk(s) (1 computed), 3 calls (3 P) -> out/pairs/B__C.calls.tsv.gz, 0.1 s
INFO loci: 11 element(s) of 2 annotated genome(s), 4 pair file(s)
INFO loci: 22 call(s) read, 4 link(s), 0.0 s
INFO loci: n_loci 9, n_conflict 0, n_multi_member 0, n_annot_conflict 0 in 0.0 s
INFO 9 loci -> loci.tsv, pav_matrix.tsv, qc.tsv, pav.vcf.gz (9 on A's coordinates, 0 unplaced), <label>.pav.gff3/.bed
INFO done in 0.8 s: 9 loci -> out
```
(timestamps trimmed). qc.tsv:
```
scope	metric	value
all	n_loci	9
all	n_conflict	0
all	n_multi_member	0
all	n_annot_conflict	0
A>B	frac_P	0.25
A>B	frac_S	0.125
A>B	frac_T	0.125
A>B	frac_E	0.25
A>B	frac_D	0.125
A>B	frac_O	0
A>B	frac_G	0.125
A>B	frac_U	0
A>B	resolved_frac	0.75
A>B	high_frac	0.75
A>B	annot_agree	1
A>B	e_in_annot	0
A>C	frac_P	0.25
A>C	frac_S	0.125
A>C	frac_T	0.125
A>C	frac_E	0.25
A>C	frac_D	0.125
A>C	frac_O	0
A>C	frac_G	0.125
A>C	frac_U	0
A>C	resolved_frac	0.75
A>C	high_frac	0.75
B>A	frac_P	0.666667
B>A	frac_S	0
B>A	frac_T	0
B>A	frac_E	0.333333
B>A	frac_D	0
B>A	frac_O	0
B>A	frac_G	0
B>A	frac_U	0
B>A	resolved_frac	1
B>A	high_frac	1
B>A	annot_agree	1
B>A	e_in_annot	0
B>C	frac_P	1
B>C	frac_S	0
B>C	frac_T	0
B>C	frac_E	0
B>C	frac_D	0
B>C	frac_O	0
B>C	frac_G	0
B>C	frac_U	0
B>C	resolved_frac	1
B>C	high_frac	1
A~B	reciprocity	1
A	annot_sensitivity	1
A	gap_rate	0
B	annot_sensitivity	1
B	gap_rate	0.125
C	gap_rate	0.0909091
```
Every value matches what the construction predicts: A>B high_frac 0.75 = 6/8 (T is medium, G "."); A>B
e_in_annot 0 because nested_E's child is E at seqB:188646-188650, inside B's host 186246-191050, which is in
the locus of the child's annotated host (excluded); C gap_rate = 1 G of 11 calls into C. pav_matrix: L1-L8 =
A's P/E/S/T/D/G/host/child with B and C as built, L9 = B-only element (A E, B P, C P). bcftools reads the VCF
(9 records, GT/ST/TR as expected). A rerun logged `elements done, skip` x2, `anchors done, skip` x4,
`calls done, skip` x4 and left every output but manifest.json byte-identical (sha256 diff). The stage-by-stage
path (`ltrpav-anchor`; `ltrpav-genotype --pair` x4; `ltrpav-merge -v`) on a fresh outdir reproduced loci.tsv,
pav_matrix.tsv, qc.tsv, pav.vcf.gz(.tbi), pav.unplaced.tsv and the tracks byte for byte.

## Files changed
- new: `src/ltrpav/cli.py`, `tests/test_cli.py`
- modified: `src/ltrpav/loci.py`, `tests/test_loci.py`, `src/ltrpav/anchor/__init__.py` (one log line),
  `src/ltrpav/annotation/__init__.py` (+annotation_files), `tests/test_annotation.py`, `src/ltrpav/constants.py`
  (+RESOLVED_WARN)

## Self-review findings (fixed before commit)
- `_anchor`/`_genotype` were near-duplicates: folded into `_pairwise(args, stage, step)`.
- "1 pairs genotyped" wording -> "pair(s)".
- Help: every command's help is 13-25 lines at 80 columns.
- The elements read-back makes elements_digest identical between a fresh run and a rerun (otherwise any
  non-roundtripping field would silently rerun the genotype stage).

## Interpretations and concerns
1. annot_agree/e_in_annot rows are omitted (not nan/0) when B is unannotated; reciprocity rows exist only for
   pairs read both ways (always the case in run/merge). An e_in_annot of 0 for an unannotated B would read as
   "checked, none found".
2. `ltrpav-merge` cannot detect pair files made from an older annotation when the eids still match (e.g. an
   edited TSD or LTR boundary): build_loci catches element-set mismatches only. The pair keys need the anchors'
   divergence, which merge does not recompute.
3. A sample labeled `all` (allowed by LABEL_RE) would share the global QC scope name "all". Needs a rule in
   samples.py or another scope name; not changed here.
4. `file_checksum` caches by (path, size, mtime_ns); on this host the kernel's timestamps step every ~4 ms, so a
   same-size rewrite within one tick is taken as unchanged. Inherent to that earlier design and unlikely in
   practice; noted because the CLI's checkpoints rely on it.
5. Concurrent `--pair` jobs into one outdir: elements, indexes and markers are written atomically, but
   `Fasta`'s fai build in work/fai (pysam.faidx, for read-only unindexed FASTAs such as Zd) is not, so two jobs
   could race on the first build. A pre-indexing step, or a temp-file-and-rename build in seqio, would close it.
6. The new QC passes (annot_agree overlap queries, reciprocity link replay) are O(calls) Python on top of
   `read`'s; expected to roughly double build_loci's time, not yet measured on whole genomes.
