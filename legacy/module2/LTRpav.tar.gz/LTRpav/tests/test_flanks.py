"""Flank routes (flank-mm2, flank-blast) and the hybrid route."""
from __future__ import annotations

import gzip
import json
import random
import shutil
from typing import ClassVar

import pytest

import toy
from ltrpav.anchor import KNOWN_ROUTES, anchor_pair, get_route
from ltrpav.anchor.flanks import FlankBlastRoute, FlankMm2Route, HybridRoute, Piece, flank_pieces
from ltrpav.anchor.mm2 import Mm2Route
from ltrpav.anchor.paf import PafRoute
from ltrpav.constants import FLANK_PIECE_MIN
from ltrpav.elements import Element
from ltrpav.genotype import genotype_pair
from ltrpav.seqio import Fasta, n_runs, revcomp
from test_genotype import pair_context, read_calls


def el(start, end, level=0):
    """Element at 1-based inclusive start..end on chr1."""
    return Element(genome="g", eid=f"g|chr1:{start}-{end}", name="e", seqid="chr1", start=start, end=end,
                   strand="+", ltr_left=(start, start + 9), ltr_right=(end - 9, end), tsd=None, k=None,
                   family=None, superfamily=None, clade=None, confidence=None, level=level)


@pytest.fixture
def fa_n(tmp_path):
    """30 kb chr1 of random bases with an N run at 9000-9500 and one at 13000-13100."""
    s = list(toy.rand_seq(30_000, random.Random(3)))
    s[9000:9500] = "N" * 500
    s[13000:13100] = "N" * 100
    with Fasta(toy.write_fasta(tmp_path / "g.fa", {"chr1": "".join(s)})) as fa:
        yield fa


def test_pieces_skip_elements_and_ns(fa_n):
    els = [el(10_001, 12_000), el(10_501, 11_000, level=1), el(12_501, 12_800)]  # child; neighbor
    pcs = flank_pieces(els, fa_n, cap=5000, target=100_000)  # target above the supply: every free piece
    assert pcs and pcs == sorted(pcs, key=lambda p: (p.start, p.end))
    spans = [(e.start - 1, e.end) for e in els]
    ns = n_runs(fa_n.fetch("chr1", 0, 30_000))
    for p in pcs:
        assert p.end - p.start >= FLANK_PIECE_MIN and p.seqid == "chr1"
        assert all(p.end <= s or p.start >= t for s, t in spans + ns), p
    assert len(set(pcs)) == len(pcs)
    assert all(p.start >= 10_000 - 5000 and p.end <= 12_800 + 5000 for p in pcs)  # within cap of an element


def test_pieces_nearest_first_and_capped(fa_n):
    pcs = flank_pieces([el(20_001, 21_000)], fa_n, cap=8000, target=1500)
    left = [p for p in pcs if p.end <= 20_000]
    right = [p for p in pcs if p.start >= 21_000]
    assert (left[-1].end, right[0].start) == (20_000, 21_000)  # nearest piece abuts the element
    for side in (left, right):
        assert 1500 <= sum(p.end - p.start for p in side)
    assert sum(p.end - p.start for p in left[1:]) < 1500  # no piece taken after the target was reached
    capped = flank_pieces([el(20_001, 21_000)], fa_n, cap=1000, target=5000)
    assert min(p.start for p in capped) >= 19_000 and max(p.end for p in capped) <= 22_000
    assert isinstance(capped[0], Piece)


@pytest.fixture(scope="module")
def tpair():
    return toy.build_pair(random.Random(7))


def _states(calls, pair):
    names = {e.eid: e.name for e in pair.elements}
    return {names[k]: calls[k]["state"] for k in pair.expect}, {names[k]: v for k, v in pair.expect.items()}


def test_flank_mm2_resolves_toy(tpair, tmp_path):
    with pair_context(tmp_path, tpair.a, tpair.b, tpair.elements) as ctx:
        calls = read_calls(genotype_pair(ctx, get_route("flank-mm2"), backend="mappy"))
    got, want = _states(calls, tpair)
    for name, st in want.items():
        if name.split(".")[0] in ("P", "E", "D_left", "D_both"):
            assert got[name] == st, (name, calls)


def test_flank_mm2_cache_differs_by_cap(tpair, tmp_path):
    with pair_context(tmp_path, tpair.a, tpair.b, tpair.elements) as ctx:
        a, b = FlankMm2Route(cap=2000), FlankMm2Route(cap=5000)
        assert a.name == b.name == "flank-mm2" and not a.whole_genome and a.reads_elements
        assert a.params(ctx) != b.params(ctx)
        anchor_pair(ctx, a)
        anchor_pair(ctx, b)
        assert FlankBlastRoute().name == "flank-blast"


def test_hybrid_fills_unanchored(tpair, tmp_path):
    """The primary PAF lacks every block left of one element and within 15 kb right of it (the toy's 20-kb
    spacers would still anchor a window with a gap of only 15 kb: WINDOW_CAP is 500 kb)."""
    with pair_context(tmp_path, tpair.a, tpair.b, tpair.elements) as ctx:
        raw = Mm2Route().raw_blocks(ctx)
        target = next(e for e in tpair.elements if e.name == "E.e")
        # nothing left of the element and nothing within 15 kb right of it: no left anchor within WINDOW_CAP
        keep = raw["a_start"] >= target.end + 15_000
        assert 0 < keep.sum() < len(raw)
        pdir = tmp_path / "pafs"
        pdir.mkdir()
        _write_paf(pdir / "A__B.paf.gz", raw[keep], ctx)
        prim = PafRoute(pdir)
        calls_p = read_calls(genotype_pair(ctx, prim, backend="mappy"))
        assert calls_p[target.eid]["state"] == "U"
        calls_h = read_calls(genotype_pair(ctx, HybridRoute(prim), backend="mappy"))
        assert calls_h[target.eid]["state"] == "E", calls_h[target.eid]
        assert get_route("hybrid").name == "hybrid" and "hybrid" in KNOWN_ROUTES


def _write_paf(path, blocks, ctx):
    an, bn = list(ctx.a_fa.lengths()), list(ctx.b_fa.lengths())
    al, bl = ctx.a_fa.lengths(), ctx.b_fa.lengths()
    with gzip.open(path, "wt") as fh:
        for r in blocks:
            a, b = an[r["a_chrom"]], bn[r["b_chrom"]]
            n = int(r["a_end"] - r["a_start"])
            m = int(r["matches"])
            fh.write("\t".join(map(str, [a, al[a], r["a_start"], r["a_end"], "+" if r["strand"] > 0 else "-",
                                         b, bl[b], r["b_start"], r["b_end"], m, int(r["alen"]), 60,
                                         f"cg:Z:{m}={n - m}X"])) + "\n")


@pytest.mark.skipif(shutil.which("blastn") is None, reason="BLAST not installed")
def test_flank_blast_blocks(tmp_path):
    rng = random.Random(5)
    bb = toy.rand_seq(30_000, rng)
    a_seq = bb
    b_seq = toy.rand_seq(4000, rng) + revcomp(bb[8000:16000]) + toy.rand_seq(3000, rng)  # inverted copy
    e = el(11_001, 12_000)
    with pair_context(tmp_path, a_seq, b_seq, [e]) as ctx:
        raw = FlankBlastRoute(cap=3000).raw_blocks(ctx)
        assert len(raw) and (raw["strand"] == -1).all()
        assert (raw["a_end"] <= 11_000).sum() and (raw["a_start"] >= 12_000).sum()
        assert ((raw["b_start"] >= 4000) & (raw["b_end"] <= 12_000)).all()
        assert (raw["matches"] <= raw["alen"]).all() and (raw["matches"] > 0).all()
        # a forward copy gives strand +1
    d2 = tmp_path / "fwd"
    with pair_context(d2, a_seq, toy.rand_seq(1000, rng) + bb[8000:16000], [e]) as ctx:
        raw = FlankBlastRoute(cap=3000).raw_blocks(ctx)
        assert len(raw) and (raw["strand"] == 1).all()


def test_pieces_targets(fa_n):
    near, far = el(20_001, 21_000), el(21_501, 22_000)
    pcs = flank_pieces([near, far], fa_n, cap=3000, target=100_000, targets={near.eid})
    assert pcs and all(p.end <= 20_000 or p.start >= 21_000 for p in pcs)
    assert all(p.end <= far.start - 1 or p.start >= far.end for p in pcs)  # untargeted span still masked
    assert not any(21_500 <= p.start < 22_000 for p in pcs)
    assert max(p.end for p in pcs) <= 21_000 + 3000
    assert any(p.start >= 22_000 for p in pcs) and not any(21_000 < p.start < 21_500 and p.end > 21_500 for p in pcs)


def test_hybrid_cache_differs_by_primary(tpair, tmp_path):
    with pair_context(tmp_path, tpair.a, tpair.b, tpair.elements) as ctx:
        pdir = tmp_path / "pafs"
        pdir.mkdir()
        (pdir / "A__B.paf").write_text("")
        h1, h2 = HybridRoute(Mm2Route()), HybridRoute(PafRoute(pdir))
        assert h1.params(ctx) != h2.params(ctx)
        marker = ctx.workdir / "anchors" / "A__B.hybrid.npz.done.json"
        anchor_pair(ctx, h1)
        key1 = json.loads(marker.read_text())["key"]
        anchor_pair(ctx, h2)  # same file, new key: recomputed, not reused
        assert json.loads(marker.read_text())["key"] != key1


def _naive_pieces(elements, fasta, cap, target):
    """A plain quadratic implementation of flank_pieces (reference)."""
    lengths = fasta.lengths()
    out = set()
    for e in elements:
        if e.level != 0:
            continue
        s0, t0, n = e.start - 1, e.end, lengths[e.seqid]
        for lo, hi, left in ((max(0, s0 - cap), s0, True), (t0, min(n, t0 + cap), False)):
            if hi <= lo:
                continue
            cuts = [(max(s, lo) - lo, min(t, hi) - lo) for s, t in ((x.start - 1, x.end) for x in elements
                                                                    if x.seqid == e.seqid) if s < hi and t > lo]
            cuts += n_runs(fasta.fetch(e.seqid, lo, hi))
            free, pos = [], 0
            for s, t in sorted(cuts):
                if s - pos >= FLANK_PIECE_MIN:
                    free.append((pos, s))
                pos = max(pos, t)
            if hi - lo - pos >= FLANK_PIECE_MIN:
                free.append((pos, hi - lo))
            total = 0
            for s, t in (reversed(free) if left else free):
                if total >= target:
                    break
                out.add(Piece(e.seqid, lo + s, lo + t))
                total += t - s
    return sorted(out, key=lambda p: (p.start, p.end))


def _random_elements(rng, n, length, nested=0.2):
    els = []
    for _ in range(n):
        s = rng.randrange(1, length - 3000)
        e = s + rng.randrange(50, 2500)
        els.append(el(s, e, level=0))
    for _ in range(int(n * nested)):  # nested children inside a random parent
        p = rng.choice(els)
        if p.end - p.start > 40:
            s = rng.randrange(p.start, p.end - 20)
            els.append(el(s, rng.randrange(s + 10, p.end + 1), level=1))
    return els


def test_pieces_match_reference_on_random_case(fa_n):
    rng = random.Random(11)
    els = _random_elements(rng, 60, 30_000, nested=0.5)
    for cap, target in ((3000, 1000), (10_000, 2000)):
        assert flank_pieces(els, fa_n, cap, target) == _naive_pieces(els, fa_n, cap, target)


def test_pieces_many_elements(tmp_path):
    """20,000 elements: the bisect span lookup keeps flank_pieces near linear (a few seconds; a scan of every
    span per element side would take about 100 s). The genome is drawn with random.choices, so the fixture does
    not dominate the test's time."""
    import time
    rng = random.Random(2)
    n_bp = 40_000_000
    with open(tmp_path / "big.fa", "w") as fh:
        fh.write(">chr1\n")
        fh.writelines("".join(rng.choices("ACGT", k=1_000_000)) + "\n" for i in range(0, n_bp, 1_000_000))
    els = [el(s, s + 1500) for s in range(2000, n_bp - 5000, 2000)]  # 20,000 elements, 500-bp gaps
    with Fasta(tmp_path / "big.fa") as fa:
        t0 = time.perf_counter()
        pcs = flank_pieces(els, fa)
        assert time.perf_counter() - t0 < 30
    assert pcs and len({(p.start, p.end) for p in pcs}) == len(pcs)


def test_pieces_at_sequence_ends(fa_n):
    """An element at either end of its sequence has a flank on its inner side only, clipped to the sequence; a
    flank of N runs and free stretches under FLANK_PIECE_MIN yields no piece."""
    first, last = el(1, 1000), el(29_001, 30_000)
    pcs = flank_pieces([first, last], fa_n, cap=2000, target=2000)
    assert [(p.start, p.end) for p in pcs] == [(1000, 3000), (27_000, 29_000)]
    # left: the N run at 9000-9500 fills the 200-bp cap; right: 100 free bp, under FLANK_PIECE_MIN, then N
    assert flank_pieces([el(9_501, 12_900)], fa_n, cap=200, target=200) == []


def test_map_pieces_bounds_in_flight(tpair, tmp_path, monkeypatch):
    from concurrent.futures import ThreadPoolExecutor

    from ltrpav.anchor import flanks, mm2
    peak = []

    class Spy(ThreadPoolExecutor):
        live: ClassVar[list] = []

        def submit(self, fn, *args):
            fut = super().submit(fn, *args)
            self.live.append(fut)
            peak.append(sum(not f.done() for f in self.live))
            return fut

    monkeypatch.setattr(flanks, "ThreadPoolExecutor", Spy)
    with pair_context(tmp_path, tpair.a, tpair.b, tpair.elements, threads=2) as ctx:
        pcs = flank_pieces(ctx.a_elements, ctx.a_fa)
        raw = flanks.map_pieces(ctx, pcs)
        assert len(pcs) > 4 * 2 * mm2._QUEUED and len(raw)
    assert max(peak) <= mm2._QUEUED * 2
