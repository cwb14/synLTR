# Task 15 review: stability (anchoring route, flank cap, jackknife block length)

Reviewer: opus, 2026-11-14. Read-only on benchmark_pav/ and the repo (this file is the only write). Probes in
scratch `p3t15-review/` (reread.py, papers.py, blocks.py, readings.py, a scratch rerun of stability_table.py and its
tests, 8 mutant copies), env ltrpav on snapshot 2, 1 thread.

## Spec compliance

- ✅ Brief Step 1. mm2 and cap5k views with `--trio B73,TIL01,TIL18` (logs/mm2.stats.log:3, cap5k likewise) and
  compare_papers with `--prefix` (logs/mm2.compare.log:3). RESULTS.md:91-114 reports D_pav, dD, informative loci,
  spacing, window r at 1 and 10 Mb, three resolved fractions, GNU time wall and max RSS per block, tree PSS, and
  per-pair wall times (RESULTS.md:184-188, stability_pairs.tsv).
- ✅ Step 2. block/b{1,2,5,10,20} copy six/views/main and block/all_b{...} copy six/views/all; the stats command is
  the source's plus `--block-size` only (logs/b*.stats.log:3 against six/logs/main.stats.log:2; logs/all_b*.stats.log:3
  against six/logs/all.stats.log:2). D_pav Z, dD Z, DFOIL-alt and D_dir Z per length (RESULTS.md:92-110).
- ✅ Step 3. One table (RESULTS.md:89-114 equals stability.md byte for byte), "varied and reported, never tuned"
  (RESULTS.md:3-5), the four changes stated with their variant (RESULTS.md:30-46) and bold in the table.
- ✅ Step 4. Appended at memo.md:236-296. ⚠️ Append-only verified in part only (no pre-append copy exists): lines
  1-126 equal p3t13/memo.before_fix1.md, the Task 14 section equals genus/memo_entry_task14.md (blank lines aside),
  and the split 31,059 + 8,734 bytes matches the reported 8,735-byte append.
- ✅ R1. All 33 step logs import snap/6282541 and exit 0. No entry of six/geno (18,695), stability/mm2/geno (4,708),
  stability/cap5k/geno (4,701), six/views/main or six/views/all has an mtime or ctime after 17:32 (my `find`), and
  the implementer's before/after listings are cmp-identical. Times and memory come from the queue's step files
  (stability_table.py:61-77). The load is stated (RESULTS.md:165-173) and its sources check out (preflight.txt
  175.85; ledger lines 165, 205, 216). GNU max RSS and tree PSS are both given (RESULTS.md:190-195).
- ✅ R2. copy_view.sh:16-27 copies with `cp -a`, unlinks the 5 relative links, remakes them with view.sh and checks
  samples.tsv and each target. All 50 links in the 10 copies resolve into six/geno; none is broken. No identity.tsv
  in the sources or the copies.
- ✅ R3. Null counts beside every D_pav Z; changes named; compare_papers caveats reported (RESULTS.md:204-206); 1
  thread per command, at most 5 at once, longest 1:57, largest RSS 1.36 GB; inputs/*.fai start = end = now.
- ✅ Ledger: default4 accepted. ⚠️ Pending for the fix round (the ruling's, not a defect here): the one-line
  cross-reference beside Task 13's items 1-2 in six/RESULTS.md and the Plan 4 lead.

## Number table

| claim | reported | my re-read | |
|---|---|---|---|
| mm2 flips the dD reading | +0.397 ± 0.140, Z 2.83, against +0.397 ± 0.127, Z 3.13 (default4), 3.14 (baseline) | +0.39690 ± 0.1405, Z 2.825; default4 +0.39676 ± 0.1268, Z 3.129; baseline +0.39800, Z 3.139. findings.txt line 30 flips "significant" to "not significant". K=0 informative 27+7 = 34 against 32+8 = 40; counted K=0 loci 764 against 889 | agree |
| positive control, 10 and 20 Mb | Z 2.92 (0, 1), 2.76 (0, 2), from 3.16 | 2.922 (0, 1), 2.764 (0, 2), from 3.158 (0, 0). Bottleneck nulls' top \|Z\|: 3.143, 2.903, 2.545, so p = 2/31 = 0.065 and 3/31 = 0.097 | agree |
| negative control, 10 and 20 Mb | Z 2.80, 2.79 (0, 2), from 3.20 | 2.800 (0, 2), 2.793 (0, 2), from 3.201 (0, 0) | agree |
| TIL25 as donor at 1 Mb | Z 3.28 (0, 0); 2.79-2.99 at 2-20 Mb | 3.278 (0, 0); 2.993, 2.794, 2.804, 2.788 | agree |
| 24 DESIGN 10.3 bars | 19 PASS / 5 MISS in all four; 0 of 99, 92, 93 shared rows change | the same 24 bar keys in all four tables, 19/5 each; 0 of 99, 0 of 92, 0 of 93 verdicts differ | agree |
| main D_pav Z 6.0-8.4 | blocks 8.39, 7.87, 7.39, 6.63, 6.04; routes 7.42, 6.89, 7.49 | 8.385, 7.867, 7.385, 6.635, 6.041; default4 7.421, mm2 6.890, cap5k 7.489; null max \|Z\| 1.967 and 3.143 | agree |
| SE at 20 Mb | median 1.15x the 5-Mb SE (0.99-1.36) | 1.1505 (0.988-1.356); 10 Mb 1.0817 (0.997-1.143) | agree |
| rest of the table | D_pav ± SE, informative loci, resolved fractions (3 rows), accuracy proxies, painted loci and spacing, window r (2 rows), direction (2 rows), trios with \|Z\| >= 3, SE ratios | every cell re-read from stats.tsv, qc.tsv and the papers tables; e.g. DFOIL-alt largest \|Z\| 2.10, 1.98, 1.90, 1.78, 1.57; D_dir Z 1.03, 0.95, 0.90, 0.92, 0.87; trios 11, 10, 9, 7, 6 | agree |
| compute and memory | walls 3:43:57, 3:17:47, 4:03:44; user CPU 243,471 / 112,071 / 123,470 s; kernel 25/47/64%; RSS 26.2/17.2/12.3 GB; PSS 25.1/21.9/21.3 GB; pair sums 2:54:24, 3:43:18, 3:17:16 | 31:24.40 + 3:12:33; 3:17:47; 4:03:44; same CPU; RSS 25,538,448 / 16,757,836 / 12,001,844 KiB; PSS 24,533,942 / 21,423,456 / 20,755,079 KiB, peaks during TIL01 vs Zd, B73 vs Zd, B73 vs Zd; all 27 per-pair times match the log lines | agree |

Other checks:
- Block copies: in all 10 copies every stats row keeps its value, n and loci; only SE (31 rows in b*, 192 in all_b*)
  and Z change. The paint part and the paint files are identical to the source's. b5 and all_b5 differ from the
  baselines only in the part key and the block_bp note.
- default4: its 18 links point at six/geno/pairs; the done markers carry the same engine code (52071c27) and element
  digest (5a33ffd7) in six/geno, mm2/geno and cap5k/geno; snapshots 12d3e6c and 6282541 differ only in analysis/ and
  sim/; default4/samples.tsv equals mm2's and cap5k's. It is a faithful 4-genome default run. Per-pair qc values equal
  six/geno's. It supports "no verdict or reading changes with the genome set", not "nothing changes" (M5).
- No unstated reading change: across the four papers tables only mm2's dD reading differs; dD Z in all 20 trios
  stays on one side of 3 at every block length (B73,TIL01;TIL25 4.11-4.38, PT,TIL01;TIL18 4.37-5.22, the main trio 3.09-3.14, the rest |Z| <= 2.79).
- stability_table.py reruns byte-identically to all four outputs; 6 tests pass; ruff and `bash -n` clean.

## Strengths

- Every number and every verdict change holds up. The changes are stated plainly, each named with its variant and
  given with its null counts and empirical p.
- The default4 control is a clean design: it separates the route from the genome set at the cost of one 2-minute merge.
- The block copies are exact copies: the 5-Mb copies reproduce the baseline, and no write reached six/geno or six/views.
- The compute section is honest. It gives load, kernel share, both memory measures and per-pair times, and it uses
  the fair comparison (mm2 against cap5k in the same hours).
- The headline says the task "adds no new biology" and labels generality as untested.

## Issues

Critical: none. Important: none.

**M1. Cost metric (RESULTS.md:27-28, 176-179; task-15-report.md:143).** The bake-off's "about twice" (0.39 against
0.19-0.22 h) is wall time (DESIGN.md:561-563). Here wall is 1.13x, user CPU 2.17x and total CPU 1.54x. "Costs about
twice the CPU time ... in line with the bake-off" pairs two different metrics. Fix: "about twice the user CPU (2.17x;
all CPU 1.54x; wall 1.13x under shared load); the bake-off's 2x was wall time."

**M2. "SE still rising at 20 Mb" (RESULTS.md:146-147; report concern 1).** It is computed right and stated as a
reading, and the cause is labeled untested (RESULTS.md:158, 216-217). The 5-to-10-Mb rise is solid (19 of 20 trios,
median 1.08). The 10-to-20-Mb step is weaker: median 1.06, 17 of 20 trios, about the size of a jackknife SE's own
sampling error at 110-126 blocks (roughly 6-7%). Give that step and its noise. Also cite SIM_RESULTS section 1: in the
simulated genomes block length did not move the SE (0.061-0.063 at 0.25-5 Mb). So the real genomes carry dependence
the simulated nulls lack. That makes the null caveat at RESULTS.md:201-202 concrete.

**M3. The untested explanation is too narrow (RESULTS.md:158-161).** It names B73's *mexicana* ancestry. The SE
rise is in all 20 trios, and it is largest in TIL11,TIL01;PT (1.36), which involves neither B73 nor TIL18. List the
candidates in general terms, all untested: long ancestry tracts in any genome, inversions, low-recombination regions,
and regional differences in genotyping resolution.

**M4. The tests skip several reported rows (test_stability_table.py:207-249).** 7 non-equivalent mutants survive in
my probe:
- min instead of max GNU RSS;
- tree PSS from the last log only;
- per-pair median read as the mean (the toy pairs all take 600 s);
- n_RD and n_SD swapped in the informative-loci cell;
- the TIL25 threshold at 2.9;
- the negative control's |Z| read as Z;
- the reading's >= turned into >.

The block copies' "same" cells are hard-coded, not checked (stability_table.py:338, 350, 355, 363, 368, 378, 386,
401). The main copies' D_pav is never compared, and test lines 253-255 lock that in. Every current value is right
(re-read above), so only reruns are at risk; 16B may rerun this script. Fix: assert those rows with unequal toy
values, and check "same" (n_RD, n_SD, n, the resolution rows and the paint part equal six_main's) instead of
asserting it.

**M5. "The genome set changes nothing" (task-15-report.md:113-114, 204).** The accurate claim is
"no verdict or reading changes". D_pav and dD move by at most 0.0012 (0.03 SE or less) and Z by at most 0.03. But the
counted loci are 14,067 against 14,011, the painted informative loci 7,515 against 7,484, and the Inv4m B73~TIL18
block holds 464 loci against 700 (coverage 0.997 against 1.000). RESULTS.md:118 ("the same answers") could carry the
same qualifier.

**M6. Memo rerun (memo.md:239, 257).** At 18:22, after this task, the controller moved compare_papers.next.py over
compare_papers.py. The memo's `run_step.sh compare` now runs the new script (47d2c20d). This run used what is now
compare_papers.py.task13 (1e04f43e, the sha the memo gives). Append one line saying so. The before/after listing
command is not in the memo either: its files sit only in session scratch. Append it too.

**M7. Small slips.**
- RESULTS.md:191 "every 5-26 s": the intervals run 5-41 s (run 1: 317 of 1,687 intervals over 26 s).
- RESULTS.md:211 "at most a tenth of its SE": it is about a tenth, up to 0.12 SE (cap5k dD +0.015 = 0.12 SE).
- RESULTS.md:175: the page-fault range (1.3e10) uses mm2's main step only, while its 25% kernel share sums both
  steps (1.47e10). The memo (memo.md:294) says 20-64%.
- RESULTS.md:114: the baseline's 12.3 GB lacks the "(run 4 only)" note that the wall and CPU cells carry.
- RESULTS.md:138 "within the noise": give the measure instead (within 0.12 SE on D_pav and dD; resolved shares
  within 0.004).

**M8. Causal claim on kernel time (RESULTS.md:175-176).** "Wall time reflects the server's state as much as the
route" is untested. mm2 and cap5k ran side by side yet spent 25% and 47% of CPU in the kernel, so part of that
overhead depends on the route. Say both, and drop "as much as".

**M9. Terms for a biologist (RESULTS.md:52-80, 165-195).** D_dir is used but never defined. "Kernel (system) time",
"minor page faults", "nice 10" and "worker" are not explained. One plain line each, or cut them.

## Lead (not run; scope is the controller's)

- Task 13's negative-control age contrast (+0.249 ± 0.078, Z 3.18; investigate_neg.py) used the 5-Mb rule. Given
  this task's result, its dependence on block length is untested. It could sit beside the cross-reference to items 1-2.

## Assessment

**Approved.** Every number and claimed verdict change re-reads correctly, the copies and the default4 control are
faithful, and nothing was written into a genotype or baseline directory. M1-M9 are text, test and memo fixes; fold
them into the fix round the ledger already plans.
