### Task 10: Chaining and 1:1 orthologous net

**Files:** Create `src/ltrpav/chain.py`, `tests/test_chain.py`

**Interfaces:**
- Consumes: `BLOCK_DTYPE`, `a_to_b`, constants `CHAIN_*`, `MIN_CHAIN_SCORE`, `ANCHOR_MIN`.
- Produces: `chain_blocks(blocks: np.ndarray) -> np.ndarray` (sets `chain`, `chain_score`; drops blocks of chains
  below `MIN_CHAIN_SCORE`); `net_blocks(blocks: np.ndarray) -> np.ndarray` (1:1 trimmed blocks with `margin`,
  sorted by `(a_chrom, a_start)`).

- [ ] **Step 1: Write the failing tests**

```python
def test_chain_bridges_insertion():   # A[0,5000)->B[0,5000) and A[15000,20000)->B[5000,10000): one chain id
def test_chain_breaks_on_far_gap():   # second block 2 Mb further on both genomes: two chains
def test_minus_strand_chain():        # three '-' blocks with decreasing B: one chain
def test_net_drops_paralog():
    # chain 1: A[0,20000)->B chr0, score 20000; block A[5000,6000)->B chr1, matches 900
    out = net_blocks(chain_blocks(bl))
    assert set(out["b_chrom"]) == {0}
    m = out[(out["a_start"] <= 5000) & (out["a_end"] >= 6000)]["margin"][0]
    assert abs(m - (1 - 900 / 20000)) < 1e-3
def test_net_trims_b_overlap():       # two A regions claiming the same B interval: the lower-scoring one is trimmed on A
```

- [ ] **Step 2: Run.** Expected: FAIL.
- [ ] **Step 3: Implement.** This algorithm is fixed here; implement it as written.

```
group blocks by (a_chrom, b_chrom, strand); sort each group by a_start
y0, y1 = (b_start, b_end) if strand > 0 else (-b_end, -b_start)      # collinear = increasing in both
@njit DP over the group: f[i] = matches[i]; p[i] = -1
  for j in i-1 .. max(0, i-CHAIN_LOOKBACK):
      if a_start[i] - a_start[j] > CHAIN_MAX_GAP + maxlen: break
      da = a_start[i] - a_end[j]; db = y0[i] - y1[j]
      if da < -CHAIN_OVERLAP or db < -CHAIN_OVERLAP or da > CHAIN_MAX_GAP or db > CHAIN_MAX_GAP: continue
      gain = matches[i] - max(0, -min(da, db))                   # do not count overlapped bases twice
      s = f[j] + gain - (CHAIN_INDEL_COST*abs(da-db) + log2(1 + max(0, min(da, db))))
      if s > f[i]: f[i], p[i] = s, j
extract: visit blocks by f descending; backtrack via p until a used block or -1; chain score = f[end] - f[stop]
  (0 if stop == -1); keep chains with score >= MIN_CHAIN_SCORE
net: visit chains by score descending; keep per-chrom claimed A and B interval lists (sorted, with owner block)
  for each block: free A parts -> map to B (a_to_b) -> remove claimed B parts -> map back -> keep parts >= ANCHOR_MIN
  every claimed interval the block overlaps (A or B): comp[owner] = max(comp[owner], this chain's score)
  if the kept parts' matches (scaled by kept fraction) sum >= MIN_CHAIN_SCORE: claim them; else drop the chain
margin[k] = 1 - comp[k] / chain_score[k]   (1.0 if never challenged)
```

- [ ] **Step 4: Run.** Expected: PASS. Also time 10^6 random blocks (one-off check, not a test). Expected: under 60 s.
- [ ] **Step 5: Commit** `"Add chaining DP and 1:1 orthologous net"`.

---

