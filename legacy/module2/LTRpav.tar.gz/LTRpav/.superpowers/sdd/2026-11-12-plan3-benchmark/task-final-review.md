# Final whole-branch review: plan3-benchmark, 12d3e6c..a44f532 (19 commits, 30 files, +6,663/-173)

Reviewer: final review (read-only). Date: 2026-11-14. Scratch: `scratchpad/p3-final-review/` (git archives of 12d3e6c and
a44f532, probes). Nothing in the working tree, index, HEAD or branch was changed; the only file written in the repo
directory is this one (under the ignored `.superpowers/`).

## What I verified myself

| Check | How | Result |
|---|---|---|
| STAGE_MODULES fingerprints equal 12d3e6c's | `git archive` of both revisions; `PYTHONPATH=<archive>/src`, `stage_fingerprint` for every stage; `ltrpav.__file__` printed to prove the archive was imported | all 7 equal (anchor/raw/blastdb ebbfd97f..., elements a78af75d..., genotype_pair/chunk 52071c27..., mm2_index 28f6fc79...); the module sets are identical |
| Engine `constants.py`, `checkpoint.py` untouched | `git diff 12d3e6c a44f532 -- <file>` | 0 lines each |
| Package code only in `sim/` and `analysis/` | `git diff --name-only -- src` | no other src file changed |
| No maize names in src | grep of added src/tests lines for Zea, maize, mays, teosinte, mexicana, parviglumis, B73, TIL*, Zd/Zh/Zn, PT, chrN, Inv4m, HPC1, citrus, genome sizes | none |
| msprime optional | fresh interpreter with `sys.modules["msprime"] = sys.modules["tskit"] = None`: import ltrpav, ltrpav.sim, ltrpav.cli, ltrpav.sim.cli, ltrpav.analysis.cli; then `ltrpav-sim pop` on a toy FASTA | imports OK; exit 1, one line `error: msprime is required for ltrpav-sim pop: pip install 'ltrpav[sim]'`, no outdir created |
| No AI attribution | commit author/committer of all 19 commits; message bodies and added lines grepped for co-authored, claude, anthropic, generated with, copilot, LLM | single identity (the user's), no trailer, no attribution; `.superpowers/` ignored by its own `.gitignore`; `docs/plans/` ignored |
| Old analysis markers read as defaults, across real code versions | toy run built and analyzed (stats, paint) by the **12d3e6c** archive, then driven by the **a44f532** archive | plot refuses naming only "the analysis code changed" (no option named, no KeyError); stats and paint rerun; the same paint again skips; `--emission decoy` reruns; `--block-size 500000` reruns; new marker meta carries discovery/emission |
| Event accounting in params.json | grid run `runs/null_s101/sim/params.json` (read-only) | requested = realized + dropped holds for insertions (40,875 = 27,693 + 13,182), losses (29,110 = 20,073 + 9,037; kinds sum to 20,073), SNPs and indels (504,069 = 341,394 + 162,675) |
| Fail-fast of the pop CLI | `--pulse C>A1` without sub_a; `--ta 9000 --f 0.2`; `--bottleneck 5000,20000` | exit 1, one `error:` line each |
| A new test's tool dependence | `tests/test_cli_analysis.py::test_block_size_reaches_every_jackknife` with lastz off PATH | FAILS (`window aligner 'lastz' needs lastz on PATH`), does not skip |
| Lint | `ruff check .` on the a44f532 archive | clean |

I read every src file of the diff in full (popmodel, popevents, popbuild, poptruth, pop, donors, sim/cli, sim/__init__,
pair helpers; paint, report, stats, analysis/cli, analysis/constants, direction), the DESIGN diff, the CI/env diffs,
the test inventory, and the ledger. I did not rerun the full suite (1,280 passed at a44f532 per the ledger).

## Strengths

- **Engine isolation is exact.** Every engine stage key is unchanged, so no pair file of any earlier run is
  invalidated by this branch; the simulator sits outside every key, and the analysis package keys itself.
- **One definition of loss geometry.** `popevents.removed()` is the only place each loss kind's removed interval is
  defined; `thin_events` (existence) and the builder both use it, and `_Chrom.__init__` re-runs `thin_events` and
  refuses any event set that is not a fixed point of it (popbuild.py:373-379). Every one of the 144 grid runs passed
  this self-check, chromosome by chromosome.
- **Thinning is a sound process law.** Thinning a Poisson process by a set fixed by older events leaves a Poisson
  process on the remaining sequence; the code decides events oldest first against older kept events only, cascades
  through host chains, and names its one cross-tree approximation (any-carrier discard) with both of its effects
  (popevents.py:68-73). Task 2's independent oracle and the end-to-end genotype precision on the grid (P 0.997,
  E 0.997) are strong, independent evidence that builder and truth agree.
- **Model checks are tight and fail fast.** Demog/Rates validate every field on construction, including lineage-pulse
  prerequisites and bottleneck length; `flat_fields` guards the flat JSON at import; regions, seeds, outdir and
  dropout labels fail before anything is simulated.
- **Determinism is designed, documented and tested.** Per-purpose seed streams with their exact limits stated
  (pop.py:13-23, MAX_CHROMS/MAX_SEED with an import-time assert), no random state crossing processes, all random draws
  of a chromosome made before any sample is built; tests cover threads 1 vs 2, two hash seeds in separate processes,
  and a step-by-step stream rebuild (`test_pop_streams`).
- **Transparent accounting.** params.json records input digests, versions, trees, requested/realized/dropped events
  per chromosome and genome, truth state counts, fractions and the simplifications list.
- **The analysis additions are minimal and safe.** The default painting path is unchanged (e0 = counts + 1, EM on
  both states); `decoy` changes only the e0 initialisation-and-freeze; fallback is explicit with one WARNING; every
  painting reports its model and fitted e0/e1. Options enter the stage keys at every value, old markers read through
  `.get(name, default)`, and `_changed` does not name an absent option as changed.
- **Honest outcomes in DESIGN.** 7.1/7.4 record variants as "evaluated, not adopted" with the numbers; 7.6 records
  direction as "not confirmed" with causes separated and untested ones labeled; 12 records the calibration values
  beside the src defaults.
- **Tests:** 107 new pop tests plus 15 analysis/sim tests, all on synthetic fixtures; every msprime test module starts
  with `pytest.importorskip`; the pair refactor is pinned byte-identical.

## Issues

### Critical (Must Fix)

None.

### Important (Should Fix)

**I1. What the simulation assumes is not visible where a user looks (params.json, `--help`).**
- Where: `src/ltrpav/sim/pop.py:85-90` (SIMPLIFICATIONS, written to params.json), `src/ltrpav/sim/cli.py:59-102`
  (`pop` description and options).
- What: params.json lists 4 simplifications, but the module docstrings name more, and the most consequential is
  missing: every backbone element's source K is read as K at the root, so each sample adds about 2·mu·T_root
  (popbuild.py:61-62; at least 2·mu·t_o = 0.054 at the defaults, about 0.07 with the coalescence time in ROOT; the
  Task 8 realism readout measured the median K of outgroup-shared elements at 0.095-0.097 vs main3's 0.060). Also only in docstrings: a backbone element exists until
  its whole span is removed (popevents.py:63), an indel deletion and a removal with equal carriers are ordered
  removal-first (popbuild.py:22-24), truth's two named limits (no G without an image or with a broken window; O does
  not ask whether X carries the other insertion; poptruth.py:28-31), and the tract-end payload limit
  (poptruth.py:43-46). Separately, `--help` never states the demography and rate defaults, that they are LTRmix's
  model plus the Plan 3 calibration, the Demog/Rates field names `--demography` accepts, or that the lineage pulse
  codes need `sub_a`/`sub_c` in that JSON (the error names `sub_a`, a field `--help` never mentions).
- Why it matters: a population geneticist simulating their own backbone will read the simulated ages, densities and
  truth states against their real data. The backbone-age shift alone moves every age-stratified reading (D_pav age
  strata, dD, dating) and is invisible in the outputs; running with the defaults silently uses one specific
  (maize-like) demography and loss mix.
- Fix (sim/ only: no engine or analysis key changes, no rerun needed): add one SIMPLIFICATIONS entry per named
  approximation above (one line each, with the measured size where known); add an epilog to `pop` listing the Demog
  and Rates fields with units and defaults (source: LTRmix's demography and rates; t_o, loss_split and replace_mean
  measured in the benchmark, DESIGN 12, wording without maize names), the sub_a/sub_c requirement of the lineage
  codes, and "params.json lists the simplifications". Extend `test_pop_writes_outputs` to assert the list.

### Minor (Nice to Have)

**M1. A new test fails instead of skipping without lastz.** `tests/test_cli_analysis.py:794`
(`test_block_size_reaches_every_jackknife`, added in 78a7c05) runs `ltrpav-stats --identity` but lacks the
`@needs_lastz` mark the same file imports (line 41) and uses on its other `--identity` tests. Confirmed: it fails with
lastz off PATH. Effect: pip-only environments (the branch's CI install line) get one more failure beside Plan 2's two.
Fix: add `@needs_lastz` (test only, no key changes).

**M2. DESIGN 12 says the grid used ten 10-Mb windows; it ran on five (50 Mb).** `docs/DESIGN.md:794` (item 1) and the
"Plan 3 outcome" block (`:869-877`) do not say the pre-registered budget fallback (first five windows, 50 Mb) was
taken; 7.6 (`:456`) then mentions "at 50 Mb" without context. Every simulated power and locus-count number depends on
it. Fix: one clause in item 1 ("else the first five windows: the grid ran at 50 Mb by the gate", as item 9 does for
the null count) or in the outcome block.

**M3. `insertions.tsv` does not name its `pos` convention.** `src/ltrpav/sim/poptruth.py:48-50`, `pop.py:463`. `pos`
is a 0-based "before base pos" anchor in backbone (ancestral) coordinates, or an offset in the host's donor body when
`host` is not ".", so it maps to no output genome; the truth TSVs beside it are 1-based inclusive in X. A user will
read it as a coordinate on `c01` of some genome. Fix: state it in the docstring, the `--help` description and
params.json (CLAUDE.md: name the convention at every format boundary).

**M4. Process traces in the repo.** Workflow vocabulary that only the plan and ledger resolve: src docstrings and one
comment (`popbuild.py:6, :61, :64, :66`, the user-visible ValueError at `:377` "Task 2's existence rule";
`poptruth.py:41, :45`; `analysis/paint.py:870` "Task 6 review m4"), 15 added test lines, and 8 of the 19 commit
messages (41f70b6 "controller ruling ... the brief's draws", 42607ad "fix round 1 (review and controller rulings)",
35257ce, 239eb8f, a91987a, 2c4db4b, 3da735c, 78a7c05 "review minors"). Not attribution, so the plan's constraint
holds, but the user's standing rule excludes "comments about how a change was made". The ledger's Plan 4 scrub names
only CLAUDE.md mentions (this branch adds none). Fix: widen Plan 4's pre-push scrub to these; sim/ docstrings can be
cleaned now at no key cost, analysis/ text should wait for the next analysis change (see M5).

**M5. Stale pre-decision wording in analysis code, beyond FOUR_LIST_NOTE.** `analysis/direction.py:56` (every 4-LIST
row: "Plan 3's one-sided dropout runs check it", now false), `analysis/cli.py:131` (`--discovery any` help: "a variant
under test in simulation"; it was evaluated, not adopted), `analysis/constants.py:26` ("the default until Plan 3's
simulation grid rules"), `analysis/paint.py:34` ("measured in simulation (realized FDR, Plan 3)"). Editing any
analysis file changes the analysis fingerprint, so every existing analysis part (all Task 13-16 views) would read as
stale under the new head; bundling these with Plan 4's first analysis change is the right call.

**M6. `_rerun_advice` claims more than it does.** `analysis/report.py:314-324`: the docstring says following the advice
"makes the same variant", but it names only OPTIONS flags, not `--trio` or `--identity` the marker also records.
Following it for an `--identity` stats part reruns stats without the identity layer and deletes identity.tsv (DESIGN
7.3 warns of this). Harmless at merge (snapshot-2 code equals head, so no part is stale); it bites at the next
analysis-code change, when every part goes stale at once. Fix in Plan 4 with or before that change: append
`--trio R,S,D` and `--identity` from the marker meta (and say so in the docstring).

**M7. Seeded and hash-pinned tests depend on unpinned random streams.** `tests/test_sim.py:608` pins sha256 of
`ltrpav-sim pair` outputs, and the pop statistical tests (3-SE bounds on fixed seeds) depend on numpy Generator and
msprime streams; CI installs both unpinned, and numpy does not promise Generator streams stable across versions (NEP
19). A correct tree could then fail CI. Plan 4 CI: pin numpy/msprime in CI, or replace the hash pin by an
old-vs-new helper comparison now that the refactor is verified.

**M8. The two "works without msprime" tests are skipped exactly when msprime is absent.** `tests/test_popmodel.py:8,
:268` and `tests/test_pop_cli.py:8, :479` live in modules that start with `pytest.importorskip("msprime")`. They
simulate absence through `sys.modules`, so they need no msprime; in a pip install without the `sim` extra they never
run. CI installs the extra, so coverage exists there. Fix: move them to a module without the importorskip.

**M9. Variant paintings overwrite the run's painting with no warning on the paint command line.** `ltrpav-paint
--help` does not say a run directory holds one painting, or that a later `ltrpav run` repaints at the defaults
(stated only in DESIGN 8 and the module docstring). One sentence in the `--discovery`/`--emission` help would do; it
is analysis text, so it belongs with M5.

## Deferred-minor triage

Must fix before merge: **none**. Every deferred item is text, hardening outside the repo, CI, or a science lead; none
changes a result or a default.

Can stay deferred (one line each, from progress.md's parked/deferred/Plan 4 lines):
1. Plan 2 (c), two engine CLI tests fail rather than skip without lastz, plus this branch's
   `test_block_size_reaches_every_jackknife` (Task 11a ledger): Plan 4 CI (lastz is the default aligner, so real
   installs have it); the branch's own test is a one-decorator fix worth taking now (M1).
2. Scrub CLAUDE.md mentions before any push (Plan 4): this branch adds none; widen the scrub to the process traces in
   M4.
3. Task 2 concern 4 / Task 16B M7, tests tied to msprime's random streams: Plan 4 CI; extend to numpy and the sha pin
   (M7).
4. Task 5 m2, `add_gaps` briefly holds three copies of one genome: bounded (about 0.6 GB at 195 Mb); stays.
5. Task 11a m1, rerun advice omits `--trio`/`--identity`: stays, but land it no later than the next analysis-code
   change (M6).
6. Task 11 Part C, FOUR_LIST_NOTE stale: stays to avoid re-keying every analysis view; bundle with the other three
   stale strings (M5).
7. Plan 2 (a), inversion caller residual (sparse blocks): stays; reported as a caveat (DESIGN 12 item 36, Task 13).
8. Plan 2 (b), overview limits with 20 trios (~264 mm page; scaffolds called chromosomes): stays; Plan 4 figures.
9. Task 11 Part Q, `eval_run.py` KeyError edge: outside the repo; scoring is final; stays.
10. Task 12 M2/M3, Task 8B minors, `genotype_all.sh` and `after_grid2.sh` hardening: outside the repo, jobs finished;
    stays.
11. Science leads (D_pav higher under LTRquest annotation; DFOIL-alt's empty-class handling and a posctl with
    non-empty classes; `any` covering the real CsA chr2 tract; block-length dependence of the controls; PT/Zh
    unscored tracts; decision 11): Plan 4 leads, not code defects; stay.

## Declined to judge

- Benchmark harness, scoring scripts, RULES.md, results and verdict counts: outside the repo, reviewed task by task.
- The scientific content of the DESIGN outcome paragraphs: checked for consistency with the ledger, not recomputed.
- The calibration values themselves (t_o, loss mix, replacement mean): measured in Task 8 and reviewed there.
- Model choices fixed by the approved plan and DESIGN 12 (LTRmix's rates, the middle-40% recombination heuristic,
  exponential replacement shape, 2.5 gaps per Mb with a third near elements, the backbone as root genome): I judged
  only whether they are documented (I1), not whether they are right.
- The realism gaps the pilot measured (G calls 5.5-6.1% vs 0.02%, density, outgroup conflict): reported, not tuned,
  by ruling; outside this diff.
- README and packaging: Plan 4.
- Whether the overview figure should label a variant painting: Plan 4 figure work.
- Scale beyond the tested 10-Mb windows (Hudson's cost about L squared, parent memory for whole chromosomes): not a
  Plan 3 target; noted in DESIGN 12 item 1.
- `multiprocessing.get_context("fork")` on macOS: the plan's runs are Linux; not exercised.
- DESIGN's citations of files outside the repo (`benchmark_pav/...`): the established Plan 2 pattern; a Plan 4
  packaging choice.
- `ltrpav-sim pair` now shares the narrowed seed range (0 to 2^32-1): intended by Task 5 m3; no recorded run uses a
  larger seed.
- Plan 1/2 code not changed in this range (engine G window, inversion caller, figure).
- Lock-file contents beyond the msprime/tskit/gsl/bcftools changes (Task 1's lock procedure was reviewed).

## Recommendations

1. Before merge, cheap and key-neutral (sim/, tests/, docs/ only): I1 (SIMPLIFICATIONS and a `pop` epilog), M1
   (`@needs_lastz`), M2 (50 Mb in DESIGN 12), M3 (`pos` convention). About 30 lines; run the pop and sim test files
   and ruff; no snapshot or rerun is needed because no stage key moves.
2. With Plan 4's first analysis-code change (one re-key instead of two): M5, M6, M9, and the analysis-side process
   comments of M4.
3. Before any push (Plan 4): scrub the process traces in commit messages, src and tests (M4) along with the CLAUDE.md
   mentions.
4. Plan 4 CI: lastz-dependent tests skip; pin numpy and msprime or relax the hash pin (M7); move the
   msprime-absence tests (M8).

## Assessment: **Ready to merge?** With fixes

All binding constraints hold (engine keys identical to 12d3e6c, package code in sim/ and analysis/ only, no maize
names in src, msprime optional, synthetic tests, no attribution), the simulator's thinning, builder, truth, tracts and
seed streams are coherent and independently corroborated, and the analysis defaults are unchanged with options keyed
and old markers read safely. Merge after the small key-neutral documentation and test fixes in recommendation 1;
nothing found changes a simulated or real result.
